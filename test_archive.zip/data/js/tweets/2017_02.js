Grailbird.data.tweets_2017_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836701529214238723",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407853614574, 8.753416411397305 ]
  },
  "id_str" : "836702310478790656",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum da die DNA-Helix sich in die falsche Richtung dreht leicht zu sagen :P",
  "id" : 836702310478790656,
  "in_reply_to_status_id" : 836701529214238723,
  "created_at" : "2017-02-28 22:19:10 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 0, 11 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836700138055815172",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407851129878, 8.753416190263652 ]
  },
  "id_str" : "836700785442492420",
  "in_reply_to_user_id" : 1244114060,
  "text" : "@RaeKnowler let\u2019s hope it works out soonish, have been waiting to even get a first appointment w\/ her since beginning of December! \uD83D\uDE02",
  "id" : 836700785442492420,
  "in_reply_to_status_id" : 836700138055815172,
  "created_at" : "2017-02-28 22:13:07 +0000",
  "in_reply_to_screen_name" : "RaeKnowler",
  "in_reply_to_user_id_str" : "1244114060",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836698215667937280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407847587294, 8.75341593220497 ]
  },
  "id_str" : "836699623695724548",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice looks \u00B1 like mine :D",
  "id" : 836699623695724548,
  "in_reply_to_status_id" : 836698215667937280,
  "created_at" : "2017-02-28 22:08:30 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/DL4E8mjYsU",
      "expanded_url" : "https:\/\/twitter.com\/valerieWoW\/status\/836558699875348481",
      "display_url" : "twitter.com\/valerieWoW\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140645889533, 8.75343483191707 ]
  },
  "id_str" : "836699012468178946",
  "text" : "That makes 2 Philipp(e)s for each woman\u2026 https:\/\/t.co\/DL4E8mjYsU",
  "id" : 836699012468178946,
  "created_at" : "2017-02-28 22:06:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cable Green",
      "screen_name" : "cgreen",
      "indices" : [ 3, 10 ],
      "id_str" : "821877",
      "id" : 821877
    }, {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "indices" : [ 82, 98 ],
      "id_str" : "17462723",
      "id" : 17462723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "836681259116036096",
  "text" : "RT @cgreen: Today is the last day to register and get the discounted rate for the @creativecommons Summit. See you there! https:\/\/t.co\/rKH8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Creative Commons",
        "screen_name" : "creativecommons",
        "indices" : [ 70, 86 ],
        "id_str" : "17462723",
        "id" : 17462723
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/rKH8JmW77Q",
        "expanded_url" : "https:\/\/twitter.com\/creativecommons\/status\/831242142559399937",
        "display_url" : "twitter.com\/creativecommon\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "836638725576646657",
    "text" : "Today is the last day to register and get the discounted rate for the @creativecommons Summit. See you there! https:\/\/t.co\/rKH8JmW77Q",
    "id" : 836638725576646657,
    "created_at" : "2017-02-28 18:06:30 +0000",
    "user" : {
      "name" : "Cable Green",
      "screen_name" : "cgreen",
      "protected" : false,
      "id_str" : "821877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677633997900521473\/ziPnVm8L_normal.jpg",
      "id" : 821877,
      "verified" : false
    }
  },
  "id" : 836681259116036096,
  "created_at" : "2017-02-28 20:55:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/EBejtjCjES",
      "expanded_url" : "https:\/\/twitter.com\/OBF_BOSC\/status\/836650108523540481",
      "display_url" : "twitter.com\/OBF_BOSC\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402596081945, 8.753063723247914 ]
  },
  "id_str" : "836676883525873664",
  "text" : "It\u2019s fun and a great thing to start reviewing if you\u2019re a young researcher! https:\/\/t.co\/EBejtjCjES",
  "id" : 836676883525873664,
  "created_at" : "2017-02-28 20:38:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836667266750115841",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407819196317, 8.753416321421714 ]
  },
  "id_str" : "836667986190692352",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField \uD83D\uDC96",
  "id" : 836667986190692352,
  "in_reply_to_status_id" : 836667266750115841,
  "created_at" : "2017-02-28 20:02:47 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/Xn7TCRNxhs",
      "expanded_url" : "https:\/\/twitter.com\/biolumiJEFFence\/status\/836620237336375296",
      "display_url" : "twitter.com\/biolumiJEFFenc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407643626619, 8.753410288371597 ]
  },
  "id_str" : "836667003968634880",
  "text" : "On this day I sent out another email to a tattoo artist so that she can ink the crucial photo 51 on me. \uD83D\uDC4D\uD83D\uDD2C\uD83D\uDC89 https:\/\/t.co\/Xn7TCRNxhs",
  "id" : 836667003968634880,
  "created_at" : "2017-02-28 19:58:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836590203754143746",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236112995973, 8.62750453979802 ]
  },
  "id_str" : "836591212559806464",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 \uD83D\uDE31",
  "id" : 836591212559806464,
  "in_reply_to_status_id" : 836590203754143746,
  "created_at" : "2017-02-28 14:57:42 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 11, 24 ],
      "id_str" : "22200760",
      "id" : 22200760
    }, {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 25, 35 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 36, 43 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836589829307645955",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237591964833, 8.627533603403407 ]
  },
  "id_str" : "836590047386284032",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @vexedmuddler @edyong209 @sujaik snap, my bad! Should have checked the twitter list!",
  "id" : 836590047386284032,
  "in_reply_to_status_id" : 836589829307645955,
  "created_at" : "2017-02-28 14:53:05 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836561529906552832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235269330061, 8.627493191344058 ]
  },
  "id_str" : "836564986063372288",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette seems bedtools merge is the way to go, intersect does not allow finding intersections in a single file.",
  "id" : 836564986063372288,
  "in_reply_to_status_id" : 836561529906552832,
  "created_at" : "2017-02-28 13:13:29 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836561529906552832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172385242608, 8.62761556362266 ]
  },
  "id_str" : "836562911149584384",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette should work without with some pipe magic, but requires the genome file. Let me try.",
  "id" : 836562911149584384,
  "in_reply_to_status_id" : 836561529906552832,
  "created_at" : "2017-02-28 13:05:15 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 0, 13 ],
      "id_str" : "22200760",
      "id" : 22200760
    }, {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 35, 45 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 46, 53 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836559814494941184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237640275571, 8.627607698338403 ]
  },
  "id_str" : "836560006338199552",
  "in_reply_to_user_id" : 22200760,
  "text" : "@vexedmuddler welcome to the club! @edyong209 @sujaik \uD83D\uDE02",
  "id" : 836560006338199552,
  "in_reply_to_status_id" : 836559814494941184,
  "created_at" : "2017-02-28 12:53:42 +0000",
  "in_reply_to_screen_name" : "vexedmuddler",
  "in_reply_to_user_id_str" : "22200760",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836558491464712194",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234163876277, 8.627444772205576 ]
  },
  "id_str" : "836559432460955652",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette (and was just confused about the terminology)",
  "id" : 836559432460955652,
  "in_reply_to_status_id" : 836558491464712194,
  "created_at" : "2017-02-28 12:51:25 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836558491464712194",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234163876277, 8.627444772205576 ]
  },
  "id_str" : "836559236855386113",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette I see, I think bedtools could still work, first `bedtools slop`, then `bedtools intersect`?",
  "id" : 836559236855386113,
  "in_reply_to_status_id" : 836558491464712194,
  "created_at" : "2017-02-28 12:50:39 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836554935915401216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237928290532, 8.627483452498993 ]
  },
  "id_str" : "836557915913871362",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette basically you want to remove features that are not actually overlapping but are close to each other?",
  "id" : 836557915913871362,
  "in_reply_to_status_id" : 836554935915401216,
  "created_at" : "2017-02-28 12:45:24 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/fL1jL3j2gn",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/391661",
      "display_url" : "goodreads.com\/book\/show\/3916\u2026"
    }, {
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/TfiCKehhuI",
      "expanded_url" : "https:\/\/twitter.com\/morganmpage\/status\/836376370020220928",
      "display_url" : "twitter.com\/morganmpage\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11211071633744, 8.753981720664308 ]
  },
  "id_str" : "836477400544333824",
  "text" : "Recommend checking out The Men with the Pink Triangle, about the camps and the horrible aftermath. https:\/\/t.co\/fL1jL3j2gn https:\/\/t.co\/TfiCKehhuI",
  "id" : 836477400544333824,
  "created_at" : "2017-02-28 07:25:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rahaeli",
      "screen_name" : "rahaeli",
      "indices" : [ 3, 11 ],
      "id_str" : "722089692",
      "id" : 722089692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "836468752518623232",
  "text" : "RT @rahaeli: I've said for years that person w\/abusive\/controlling partner and stalker ex are 2 design personas every team should require f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/0xZfD9lckT",
        "expanded_url" : "https:\/\/twitter.com\/imeluny\/status\/835915196375818241",
        "display_url" : "twitter.com\/imeluny\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "836024270794932225",
    "text" : "I've said for years that person w\/abusive\/controlling partner and stalker ex are 2 design personas every team should require for all changes https:\/\/t.co\/0xZfD9lckT",
    "id" : 836024270794932225,
    "created_at" : "2017-02-27 01:24:53 +0000",
    "user" : {
      "name" : "rahaeli",
      "screen_name" : "rahaeli",
      "protected" : false,
      "id_str" : "722089692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562849468689559552\/NWzFe0kI_normal.png",
      "id" : 722089692,
      "verified" : false
    }
  },
  "id" : 836468752518623232,
  "created_at" : "2017-02-28 06:51:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 3, 14 ],
      "id_str" : "20653310",
      "id" : 20653310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "836363106947371008",
  "text" : "RT @rchampieux: Need advice - what free virtual meeting tools work well for global calls &amp; ensuring guests from low bandwidth locales can j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 132, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "836328555097182208",
    "text" : "Need advice - what free virtual meeting tools work well for global calls &amp; ensuring guests from low bandwidth locales can join? #openscience",
    "id" : 836328555097182208,
    "created_at" : "2017-02-27 21:34:00 +0000",
    "user" : {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "protected" : false,
      "id_str" : "20653310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/77507928\/c016m_normal.jpg",
      "id" : 20653310,
      "verified" : false
    }
  },
  "id" : 836363106947371008,
  "created_at" : "2017-02-27 23:51:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836345904659562496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407904625682, 8.753415769092552 ]
  },
  "id_str" : "836346070770860032",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest exactly that \uD83D\uDE22",
  "id" : 836346070770860032,
  "in_reply_to_status_id" : 836345904659562496,
  "created_at" : "2017-02-27 22:43:36 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/7uDcYCwmKV",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/health_and_science\/cover_story\/2017\/02\/guatemala_syphilis_experiments_worse_than_tuskegee.html",
      "display_url" : "slate.com\/articles\/healt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836343790478766080",
  "text" : "\u00ABGuatemala syphilis experiments worse than Tuskegee.\u00BB Tell me again how unpolitical science is? https:\/\/t.co\/7uDcYCwmKV",
  "id" : 836343790478766080,
  "created_at" : "2017-02-27 22:34:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 3, 12 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Pocket",
      "screen_name" : "Pocket",
      "indices" : [ 35, 42 ],
      "id_str" : "27530178",
      "id" : 27530178
    }, {
      "name" : "Mozilla",
      "screen_name" : "mozilla",
      "indices" : [ 63, 71 ],
      "id_str" : "106682853",
      "id" : 106682853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/UbaGcpbuba",
      "expanded_url" : "https:\/\/blog.mozilla.org\/blog\/2017\/02\/27\/mozilla-acquires-pocket\/",
      "display_url" : "blog.mozilla.org\/blog\/2017\/02\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836301498388791298",
  "text" : "RT @abbycabs: Thrilled to see what @Pocket does as part of the @mozilla family! &lt;3 new Mozillians:\nhttps:\/\/t.co\/UbaGcpbuba",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pocket",
        "screen_name" : "Pocket",
        "indices" : [ 21, 28 ],
        "id_str" : "27530178",
        "id" : 27530178
      }, {
        "name" : "Mozilla",
        "screen_name" : "mozilla",
        "indices" : [ 49, 57 ],
        "id_str" : "106682853",
        "id" : 106682853
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/UbaGcpbuba",
        "expanded_url" : "https:\/\/blog.mozilla.org\/blog\/2017\/02\/27\/mozilla-acquires-pocket\/",
        "display_url" : "blog.mozilla.org\/blog\/2017\/02\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "836292153580060673",
    "text" : "Thrilled to see what @Pocket does as part of the @mozilla family! &lt;3 new Mozillians:\nhttps:\/\/t.co\/UbaGcpbuba",
    "id" : 836292153580060673,
    "created_at" : "2017-02-27 19:09:21 +0000",
    "user" : {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "protected" : false,
      "id_str" : "395367768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789110152070823938\/O_ena-j7_normal.jpg",
      "id" : 395367768,
      "verified" : false
    }
  },
  "id" : 836301498388791298,
  "created_at" : "2017-02-27 19:46:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "indices" : [ 3, 19 ],
      "id_str" : "17462723",
      "id" : 17462723
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "836276704943427584",
  "text" : "RT @creativecommons: The Early Bird gets the.... well, you know. Last days for discounted registration for #ccsummit! https:\/\/t.co\/zue7wnHw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ccsummit",
        "indices" : [ 86, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/zue7wnHwiA",
        "expanded_url" : "https:\/\/summit.creativecommons.org\/index.php\/register\/",
        "display_url" : "summit.creativecommons.org\/index.php\/regi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "836276497774182400",
    "text" : "The Early Bird gets the.... well, you know. Last days for discounted registration for #ccsummit! https:\/\/t.co\/zue7wnHwiA",
    "id" : 836276497774182400,
    "created_at" : "2017-02-27 18:07:08 +0000",
    "user" : {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "protected" : false,
      "id_str" : "17462723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525970164341153792\/vbReKnbf_normal.png",
      "id" : 17462723,
      "verified" : true
    }
  },
  "id" : 836276704943427584,
  "created_at" : "2017-02-27 18:07:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 3, 11 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "OBF News",
      "screen_name" : "obf_news",
      "indices" : [ 32, 41 ],
      "id_str" : "20624794",
      "id" : 20624794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gsoc",
      "indices" : [ 62, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Pi4vGRV3Wr",
      "expanded_url" : "http:\/\/obf.github.io\/GSoC\/ideas\/",
      "display_url" : "obf.github.io\/GSoC\/ideas\/"
    } ]
  },
  "geo" : { },
  "id_str" : "836268962753232901",
  "text" : "RT @kaiblin: And it's official: @obf_news is participating in #gsoc 2017 again! Check out our ideas list and apply: https:\/\/t.co\/Pi4vGRV3Wr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OBF News",
        "screen_name" : "obf_news",
        "indices" : [ 19, 28 ],
        "id_str" : "20624794",
        "id" : 20624794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gsoc",
        "indices" : [ 49, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/Pi4vGRV3Wr",
        "expanded_url" : "http:\/\/obf.github.io\/GSoC\/ideas\/",
        "display_url" : "obf.github.io\/GSoC\/ideas\/"
      } ]
    },
    "geo" : { },
    "id_str" : "836263723811614720",
    "text" : "And it's official: @obf_news is participating in #gsoc 2017 again! Check out our ideas list and apply: https:\/\/t.co\/Pi4vGRV3Wr",
    "id" : 836263723811614720,
    "created_at" : "2017-02-27 17:16:23 +0000",
    "user" : {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "protected" : false,
      "id_str" : "124202458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1629590097\/kai_portrait_normal.jpg",
      "id" : 124202458,
      "verified" : false
    }
  },
  "id" : 836268962753232901,
  "created_at" : "2017-02-27 17:37:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carly Strasser",
      "screen_name" : "carlystrasser",
      "indices" : [ 3, 17 ],
      "id_str" : "190246525",
      "id" : 190246525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/p2VH6zl6Z8",
      "expanded_url" : "https:\/\/medium.com\/@OmnesRes\/my-concerns-regarding-the-asapbio-central-service-and-center-for-open-science-5c2f0d2dfca#.5qabp8phk",
      "display_url" : "medium.com\/@OmnesRes\/my-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "836268199893155840",
  "text" : "RT @carlystrasser: \u201CMy concerns regarding the ASAPbio Central Service and Center for Open Science\u201D by Jordan Anaya https:\/\/t.co\/p2VH6zl6Z8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/p2VH6zl6Z8",
        "expanded_url" : "https:\/\/medium.com\/@OmnesRes\/my-concerns-regarding-the-asapbio-central-service-and-center-for-open-science-5c2f0d2dfca#.5qabp8phk",
        "display_url" : "medium.com\/@OmnesRes\/my-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "836260287544193024",
    "text" : "\u201CMy concerns regarding the ASAPbio Central Service and Center for Open Science\u201D by Jordan Anaya https:\/\/t.co\/p2VH6zl6Z8",
    "id" : 836260287544193024,
    "created_at" : "2017-02-27 17:02:44 +0000",
    "user" : {
      "name" : "Carly Strasser",
      "screen_name" : "carlystrasser",
      "protected" : false,
      "id_str" : "190246525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1278320972\/headshot4_normal.jpg",
      "id" : 190246525,
      "verified" : false
    }
  },
  "id" : 836268199893155840,
  "created_at" : "2017-02-27 17:34:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus P\u00F6ssel",
      "screen_name" : "mpoessel",
      "indices" : [ 0, 9 ],
      "id_str" : "276597679",
      "id" : 276597679
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/836230191143862272\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/f3S7gWpsyZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C5ri5cmXQAI5Qj2.jpg",
      "id_str" : "836230157388169218",
      "id" : 836230157388169218,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C5ri5cmXQAI5Qj2.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      } ],
      "display_url" : "pic.twitter.com\/f3S7gWpsyZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836214672953049094",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236123201955, 8.627504286008978 ]
  },
  "id_str" : "836230191143862272",
  "in_reply_to_user_id" : 276597679,
  "text" : "@mpoessel just the opposite it seems. :) https:\/\/t.co\/f3S7gWpsyZ",
  "id" : 836230191143862272,
  "in_reply_to_status_id" : 836214672953049094,
  "created_at" : "2017-02-27 15:03:08 +0000",
  "in_reply_to_screen_name" : "mpoessel",
  "in_reply_to_user_id_str" : "276597679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen P.  \uD83D\uDC0D\uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "SssnakeySci",
      "indices" : [ 0, 12 ],
      "id_str" : "2364949140",
      "id" : 2364949140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "836223919615000576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17244814486651, 8.627478243117132 ]
  },
  "id_str" : "836229330565009410",
  "in_reply_to_user_id" : 2364949140,
  "text" : "@SssnakeySci trying hard to become an overachiever in at least something :p",
  "id" : 836229330565009410,
  "in_reply_to_status_id" : 836223919615000576,
  "created_at" : "2017-02-27 14:59:43 +0000",
  "in_reply_to_screen_name" : "SssnakeySci",
  "in_reply_to_user_id_str" : "2364949140",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/836214066943258624\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/5dY29ijWrt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C5rUQw9WcAAWGi5.jpg",
      "id_str" : "836214065315868672",
      "id" : 836214065315868672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C5rUQw9WcAAWGi5.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/5dY29ijWrt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "836214066943258624",
  "text" : "For once I'm starting my literature search with plenty of time before the deadline. https:\/\/t.co\/5dY29ijWrt",
  "id" : 836214066943258624,
  "created_at" : "2017-02-27 13:59:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/6jb3qfU9Zo",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/defunct-country-passports",
      "display_url" : "atlasobscura.com\/articles\/defun\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17247940357186, 8.6275752960115 ]
  },
  "id_str" : "836206867617579008",
  "text" : "Six Stories of Stunning Passports From Countries That No Longer Exist https:\/\/t.co\/6jb3qfU9Zo",
  "id" : 836206867617579008,
  "created_at" : "2017-02-27 13:30:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SNCKPCK \u2605\u5F61",
      "screen_name" : "SNCKPCK",
      "indices" : [ 3, 11 ],
      "id_str" : "55660997",
      "id" : 55660997
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SNCKPCK\/status\/835578022484922369\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/pW791P7c0t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C5iRroiWQAESjzE.jpg",
      "id_str" : "835577909679112193",
      "id" : 835577909679112193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C5iRroiWQAESjzE.jpg",
      "sizes" : [ {
        "h" : 1361,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 797,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1361,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/pW791P7c0t"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "835821152186601472",
  "text" : "RT @SNCKPCK: zoom into the dog nose https:\/\/t.co\/pW791P7c0t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SNCKPCK\/status\/835578022484922369\/photo\/1",
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/pW791P7c0t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C5iRroiWQAESjzE.jpg",
        "id_str" : "835577909679112193",
        "id" : 835577909679112193,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C5iRroiWQAESjzE.jpg",
        "sizes" : [ {
          "h" : 1361,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 797,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1361,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/pW791P7c0t"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "835578022484922369",
    "text" : "zoom into the dog nose https:\/\/t.co\/pW791P7c0t",
    "id" : 835578022484922369,
    "created_at" : "2017-02-25 19:51:39 +0000",
    "user" : {
      "name" : "SNCKPCK \u2605\u5F61",
      "screen_name" : "SNCKPCK",
      "protected" : false,
      "id_str" : "55660997",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/907449514990194688\/XuOv2M4R_normal.jpg",
      "id" : 55660997,
      "verified" : true
    }
  },
  "id" : 835821152186601472,
  "created_at" : "2017-02-26 11:57:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S.P. Mohanty",
      "screen_name" : "MeMohanty",
      "indices" : [ 0, 10 ],
      "id_str" : "381054288",
      "id" : 381054288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "835556111772168193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35927561768084, 8.587948288776527 ]
  },
  "id_str" : "835609046120005633",
  "in_reply_to_user_id" : 381054288,
  "text" : "@MeMohanty nah, didn\u2019t stay for the night. Next time!",
  "id" : 835609046120005633,
  "in_reply_to_status_id" : 835556111772168193,
  "created_at" : "2017-02-25 21:54:56 +0000",
  "in_reply_to_screen_name" : "MeMohanty",
  "in_reply_to_user_id_str" : "381054288",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 13, 28 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 50, 63 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/835554259261337600\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/p7wwAm6KC9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C5h8JtQXQAAVMdg.jpg",
      "id_str" : "835554237086121984",
      "id" : 835554237086121984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C5h8JtQXQAAVMdg.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/p7wwAm6KC9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.31111320043308, 6.077187106855533 ]
  },
  "id_str" : "835554259261337600",
  "text" : "And the next @MozillaScience mini reunion. Today: @RaoOfPhysics giving a tour at the LHC. \uD83D\uDC96\uD83D\uDD2D\uD83D\uDD2C\u2697\uFE0F\u2699\uFE0F\uD83D\uDC69\u200D\uD83D\uDD27 https:\/\/t.co\/p7wwAm6KC9",
  "id" : 835554259261337600,
  "created_at" : "2017-02-25 18:17:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/WVSJ8QCCMO",
      "expanded_url" : "http:\/\/www.haaretz.com\/world-news\/europe\/.premium-1.773405",
      "display_url" : "haaretz.com\/world-news\/eur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "835438730878017536",
  "text" : "The untold story of the Jews forced to work in Nazi death factories\nhttps:\/\/t.co\/WVSJ8QCCMO",
  "id" : 835438730878017536,
  "created_at" : "2017-02-25 10:38:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 0, 10 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "835095058999300096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925054674954, 8.587732464078936 ]
  },
  "id_str" : "835385803639558144",
  "in_reply_to_user_id" : 22839233,
  "text" : "@kaythaney exciting! All the best for your next steps! \uD83C\uDF8A\uD83C\uDF7E",
  "id" : 835385803639558144,
  "in_reply_to_status_id" : 835095058999300096,
  "created_at" : "2017-02-25 07:07:50 +0000",
  "in_reply_to_screen_name" : "kaythaney",
  "in_reply_to_user_id_str" : "22839233",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 11, 19 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "835173575036387328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.35145918191257, 7.790919067345365 ]
  },
  "id_str" : "835174470050541568",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe @Seplute looks like a super fun hack space and I never made it myself so far :(",
  "id" : 835174470050541568,
  "in_reply_to_status_id" : 835173575036387328,
  "created_at" : "2017-02-24 17:08:05 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 20, 30 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834903303188262912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.42951808594952, 7.88970725611587 ]
  },
  "id_str" : "835172589085593603",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute what about @biocrusoe ? :)",
  "id" : 835172589085593603,
  "in_reply_to_status_id" : 834903303188262912,
  "created_at" : "2017-02-24 17:00:36 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/Ti1Rr2DZQO",
      "expanded_url" : "https:\/\/twitter.com\/godtributes\/status\/835126224938754050",
      "display_url" : "twitter.com\/godtributes\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237671419112, 8.6275012176228 ]
  },
  "id_str" : "835127167096848384",
  "text" : "If there is a bioinformatics god she definitely isn\u2019t of the kind variety. https:\/\/t.co\/Ti1Rr2DZQO",
  "id" : 835127167096848384,
  "created_at" : "2017-02-24 14:00:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karin Lagesen",
      "screen_name" : "karinlag",
      "indices" : [ 3, 12 ],
      "id_str" : "571902552",
      "id" : 571902552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "835126176259661826",
  "text" : "RT @karinlag: Bioinformatics: the science where method choice is dictated not so much by suitability, as by installability.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "835110902638739456",
    "text" : "Bioinformatics: the science where method choice is dictated not so much by suitability, as by installability.",
    "id" : 835110902638739456,
    "created_at" : "2017-02-24 12:55:29 +0000",
    "user" : {
      "name" : "Karin Lagesen",
      "screen_name" : "karinlag",
      "protected" : false,
      "id_str" : "571902552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2235451984\/2011-12-15_Karin_Lagesen_normal.jpg",
      "id" : 571902552,
      "verified" : false
    }
  },
  "id" : 835126176259661826,
  "created_at" : "2017-02-24 13:56:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "March for Science",
      "screen_name" : "ScienceMarchDC",
      "indices" : [ 32, 47 ],
      "id_str" : "823565852922576897",
      "id" : 823565852922576897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/QpS5O2N1kf",
      "expanded_url" : "https:\/\/twitter.com\/ScienceMarchDC\/status\/834840542848679936",
      "display_url" : "twitter.com\/ScienceMarchDC\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "834840542848679936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235823491089, 8.627490677412474 ]
  },
  "id_str" : "835122850487013376",
  "in_reply_to_user_id" : 823565852922576897,
  "text" : "18h later: Has anyone ever seen @ScienceMarchDC apologizing for their utter BS and\/or learn from their mistakes? https:\/\/t.co\/QpS5O2N1kf",
  "id" : 835122850487013376,
  "in_reply_to_status_id" : 834840542848679936,
  "created_at" : "2017-02-24 13:42:58 +0000",
  "in_reply_to_screen_name" : "ScienceMarchDC",
  "in_reply_to_user_id_str" : "823565852922576897",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/Qwcn1P9NSl",
      "expanded_url" : "http:\/\/www.sciencemag.org\/news\/2017\/02\/study-thyself-political-scientists-assess-extent-sexual-harassment-their-annual-meeting",
      "display_url" : "sciencemag.org\/news\/2017\/02\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238436066048, 8.627472139613344 ]
  },
  "id_str" : "835118155060097025",
  "text" : "Study thyself: Political scientists assess extent of sexual harassment at their annual meeting https:\/\/t.co\/Qwcn1P9NSl",
  "id" : 835118155060097025,
  "created_at" : "2017-02-24 13:24:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/f8wtvWyXlc",
      "expanded_url" : "https:\/\/twitter.com\/fresskoma\/status\/835035678534676480",
      "display_url" : "twitter.com\/fresskoma\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235903836986, 8.627533991040437 ]
  },
  "id_str" : "835082145995636736",
  "text" : "By now we can basically convert \u2018Have I Been Pwned?\u2019 to a single-serving site that just answers YES? https:\/\/t.co\/f8wtvWyXlc",
  "id" : 835082145995636736,
  "created_at" : "2017-02-24 11:01:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    }, {
      "name" : "Boop My Nose \u2122",
      "screen_name" : "boopmynose",
      "indices" : [ 9, 20 ],
      "id_str" : "3505419687",
      "id" : 3505419687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/Q3LJhMW313",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/gedankenstuecke\/2914369447\/",
      "display_url" : "flickr.com\/photos\/gedanke\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "834915343630024705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405209996023, 8.753401549921431 ]
  },
  "id_str" : "834915550073597952",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil @boopmynose my personal contribution: https:\/\/t.co\/Q3LJhMW313",
  "id" : 834915550073597952,
  "in_reply_to_status_id" : 834915343630024705,
  "created_at" : "2017-02-23 23:59:13 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834903303188262912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140522203612, 8.75340178782363 ]
  },
  "id_str" : "834913294595014656",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute let me sleep over it!",
  "id" : 834913294595014656,
  "in_reply_to_status_id" : 834903303188262912,
  "created_at" : "2017-02-23 23:50:16 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/ZQ91GVh01y",
      "expanded_url" : "https:\/\/twitter.com\/boopmynose\/status\/834806023361789953",
      "display_url" : "twitter.com\/boopmynose\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140522203612, 8.75340178782363 ]
  },
  "id_str" : "834912871310065665",
  "text" : "Now I totally want to boop some \uD83D\uDC36 noses. https:\/\/t.co\/ZQ91GVh01y",
  "id" : 834912871310065665,
  "created_at" : "2017-02-23 23:48:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834850562726309889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406631208349, 8.753419110745703 ]
  },
  "id_str" : "834894136889200640",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute nah, can\u2019t unfortunately :(",
  "id" : 834894136889200640,
  "in_reply_to_status_id" : 834850562726309889,
  "created_at" : "2017-02-23 22:34:08 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834889321958289408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405217313682, 8.753401694512245 ]
  },
  "id_str" : "834893003802218497",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField had a good time with them when flying to BNE last year, would do again :)",
  "id" : 834893003802218497,
  "in_reply_to_status_id" : 834889321958289408,
  "created_at" : "2017-02-23 22:29:38 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo\u03B1chim Go\u03B5dhart",
      "screen_name" : "joachimgoedhart",
      "indices" : [ 3, 19 ],
      "id_str" : "135266269",
      "id" : 135266269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "834888561510002690",
  "text" : "RT @joachimgoedhart: Animation - from barplot to box&amp;dotplot:\nstep-by-step changes that improve transparency and interpretation https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/joachimgoedhart\/status\/834872819121008640\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/nDjYk77Xye",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C5YPrinWIAQRXzG.jpg",
        "id_str" : "834872021624430596",
        "id" : 834872021624430596,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C5YPrinWIAQRXzG.jpg",
        "sizes" : [ {
          "h" : 634,
          "resize" : "fit",
          "w" : 414
        }, {
          "h" : 634,
          "resize" : "fit",
          "w" : 414
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 634,
          "resize" : "fit",
          "w" : 414
        }, {
          "h" : 634,
          "resize" : "fit",
          "w" : 414
        } ],
        "display_url" : "pic.twitter.com\/nDjYk77Xye"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "834872819121008640",
    "text" : "Animation - from barplot to box&amp;dotplot:\nstep-by-step changes that improve transparency and interpretation https:\/\/t.co\/nDjYk77Xye",
    "id" : 834872819121008640,
    "created_at" : "2017-02-23 21:09:25 +0000",
    "user" : {
      "name" : "Jo\u03B1chim Go\u03B5dhart",
      "screen_name" : "joachimgoedhart",
      "protected" : false,
      "id_str" : "135266269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/904438912407482370\/L7LBq45b_normal.jpg",
      "id" : 135266269,
      "verified" : false
    }
  },
  "id" : 834888561510002690,
  "created_at" : "2017-02-23 22:11:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834844963779260416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406704010699, 8.753420038011845 ]
  },
  "id_str" : "834845758859988993",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute when\u2019s that? :)",
  "id" : 834845758859988993,
  "in_reply_to_status_id" : 834844963779260416,
  "created_at" : "2017-02-23 19:21:54 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bigdata",
      "indices" : [ 31, 39 ]
    }, {
      "text" : "bioethics",
      "indices" : [ 40, 50 ]
    }, {
      "text" : "ethics",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/D2Bs01zonv",
      "expanded_url" : "https:\/\/twitter.com\/a_blasimme\/status\/834409078780739584",
      "display_url" : "twitter.com\/a_blasimme\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834756124297551872",
  "text" : "RT @EffyVayena: We are hiring! #bigdata #bioethics #ethics https:\/\/t.co\/D2Bs01zonv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bigdata",
        "indices" : [ 15, 23 ]
      }, {
        "text" : "bioethics",
        "indices" : [ 24, 34 ]
      }, {
        "text" : "ethics",
        "indices" : [ 35, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/D2Bs01zonv",
        "expanded_url" : "https:\/\/twitter.com\/a_blasimme\/status\/834409078780739584",
        "display_url" : "twitter.com\/a_blasimme\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "834715716762923008",
    "text" : "We are hiring! #bigdata #bioethics #ethics https:\/\/t.co\/D2Bs01zonv",
    "id" : 834715716762923008,
    "created_at" : "2017-02-23 10:45:09 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 834756124297551872,
  "created_at" : "2017-02-23 13:25:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neuroskeptic",
      "screen_name" : "Neuro_Skeptic",
      "indices" : [ 0, 14 ],
      "id_str" : "316327930",
      "id" : 316327930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834755302448885761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236390254978, 8.62751750648932 ]
  },
  "id_str" : "834755871150338048",
  "in_reply_to_user_id" : 316327930,
  "text" : "@Neuro_Skeptic I\u2019m sure they\u2019ll find an equally talented replacement to somehow tell a BS story as they\u2019re whole product is nothing else.",
  "id" : 834755871150338048,
  "in_reply_to_status_id" : 834755302448885761,
  "created_at" : "2017-02-23 13:24:43 +0000",
  "in_reply_to_screen_name" : "Neuro_Skeptic",
  "in_reply_to_user_id_str" : "316327930",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834722288733786112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237062395846, 8.627518840077096 ]
  },
  "id_str" : "834723124251914240",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I also guess your parents wouldn\u2019t be super happy about that. :p",
  "id" : 834723124251914240,
  "in_reply_to_status_id" : 834722288733786112,
  "created_at" : "2017-02-23 11:14:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834705415812194304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235401351859, 8.627481725589558 ]
  },
  "id_str" : "834721342624768000",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer will they all end up in openSNP? :P",
  "id" : 834721342624768000,
  "in_reply_to_status_id" : 834705415812194304,
  "created_at" : "2017-02-23 11:07:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834697419203846144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236532725192, 8.627464615453908 ]
  },
  "id_str" : "834704836167884800",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer so that\u2019s your plan for now? :D",
  "id" : 834704836167884800,
  "in_reply_to_status_id" : 834697419203846144,
  "created_at" : "2017-02-23 10:01:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834690359498305536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236741079195, 8.627526508399065 ]
  },
  "id_str" : "834693111855063041",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock but you know how likely we bioinformaticians are for doing off-by-one errors!",
  "id" : 834693111855063041,
  "in_reply_to_status_id" : 834690359498305536,
  "created_at" : "2017-02-23 09:15:20 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 3, 15 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Bernardo Clavijo",
      "screen_name" : "bjclavijo",
      "indices" : [ 119, 129 ],
      "id_str" : "14884989",
      "id" : 14884989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "834688021647781888",
  "text" : "RT @froggleston: Want to get your hands on the *open source* algorithm that assembled hexaploid wheat? Amazing work by @bjclavijo et al @Ea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bernardo Clavijo",
        "screen_name" : "bjclavijo",
        "indices" : [ 102, 112 ],
        "id_str" : "14884989",
        "id" : 14884989
      }, {
        "name" : "Earlham Institute",
        "screen_name" : "EarlhamInst",
        "indices" : [ 119, 131 ],
        "id_str" : "93655345",
        "id" : 93655345
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wheat",
        "indices" : [ 132, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/r5Mb50P2iG",
        "expanded_url" : "https:\/\/twitter.com\/biorxivpreprint\/status\/834643987638190080",
        "display_url" : "twitter.com\/biorxivpreprin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "834685699978850305",
    "text" : "Want to get your hands on the *open source* algorithm that assembled hexaploid wheat? Amazing work by @bjclavijo et al @EarlhamInst #wheat https:\/\/t.co\/r5Mb50P2iG",
    "id" : 834685699978850305,
    "created_at" : "2017-02-23 08:45:53 +0000",
    "user" : {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "protected" : false,
      "id_str" : "53893339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742344707469086720\/UP8kTNU-_normal.jpg",
      "id" : 53893339,
      "verified" : false
    }
  },
  "id" : 834688021647781888,
  "created_at" : "2017-02-23 08:55:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/7n1bjHVmJh",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/solving-sophie39s-choice",
      "display_url" : "smbc-comics.com\/comic\/solving-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235682913569, 8.627529064605934 ]
  },
  "id_str" : "834687462773489664",
  "text" : "Reason #4232 why I shouldn\u2019t have kids. https:\/\/t.co\/7n1bjHVmJh",
  "id" : 834687462773489664,
  "created_at" : "2017-02-23 08:52:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834550161942708225",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078089509827, 8.81863755461293 ]
  },
  "id_str" : "834550385205444608",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn that\u2019s the spirit. Let\u2019s reenact Cologne and SF! \uD83C\uDF8A\uD83E\uDD42\uD83C\uDF7E",
  "id" : 834550385205444608,
  "in_reply_to_status_id" : 834550161942708225,
  "created_at" : "2017-02-22 23:48:11 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen P.  \uD83D\uDC0D\uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "SssnakeySci",
      "indices" : [ 0, 12 ],
      "id_str" : "2364949140",
      "id" : 2364949140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834549836305276929",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078089509827, 8.81863755461293 ]
  },
  "id_str" : "834550044472799232",
  "in_reply_to_user_id" : 2364949140,
  "text" : "@SssnakeySci I feel ya!",
  "id" : 834550044472799232,
  "in_reply_to_status_id" : 834549836305276929,
  "created_at" : "2017-02-22 23:46:50 +0000",
  "in_reply_to_screen_name" : "SssnakeySci",
  "in_reply_to_user_id_str" : "2364949140",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen P.  \uD83D\uDC0D\uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "SssnakeySci",
      "indices" : [ 0, 12 ],
      "id_str" : "2364949140",
      "id" : 2364949140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834549657795596289",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078089509827, 8.81863755461293 ]
  },
  "id_str" : "834550024805679104",
  "in_reply_to_user_id" : 2364949140,
  "text" : "@SssnakeySci yes, the lack of this is also the reason why the whole \u201Cscience is apolitical\u201D-meme still isn\u2019t dead :(",
  "id" : 834550024805679104,
  "in_reply_to_status_id" : 834549657795596289,
  "created_at" : "2017-02-22 23:46:45 +0000",
  "in_reply_to_screen_name" : "SssnakeySci",
  "in_reply_to_user_id_str" : "2364949140",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834549721125572608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078089509827, 8.81863755461293 ]
  },
  "id_str" : "834549888809578498",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn \uD83C\uDF79 will let you know once I got my incoming date fixed! \uD83D\uDE0D",
  "id" : 834549888809578498,
  "in_reply_to_status_id" : 834549721125572608,
  "created_at" : "2017-02-22 23:46:13 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen P.  \uD83D\uDC0D\uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "SssnakeySci",
      "indices" : [ 0, 12 ],
      "id_str" : "2364949140",
      "id" : 2364949140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834548401970827266",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06075396622499, 8.818690004498823 ]
  },
  "id_str" : "834549488425562112",
  "in_reply_to_user_id" : 2364949140,
  "text" : "@SssnakeySci totally! \uD83D\uDE2D",
  "id" : 834549488425562112,
  "in_reply_to_status_id" : 834548401970827266,
  "created_at" : "2017-02-22 23:44:37 +0000",
  "in_reply_to_screen_name" : "SssnakeySci",
  "in_reply_to_user_id_str" : "2364949140",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834546524453556224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06075396622499, 8.818690004498823 ]
  },
  "id_str" : "834549445643599872",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn I\u2019ll be in town until 1st of May, starting sometime during the time frame mentioned. Wanna have some drinks?",
  "id" : 834549445643599872,
  "in_reply_to_status_id" : 834546524453556224,
  "created_at" : "2017-02-22 23:44:27 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen P.  \uD83D\uDC0D\uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "SssnakeySci",
      "indices" : [ 0, 12 ],
      "id_str" : "2364949140",
      "id" : 2364949140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834537150741872640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06104658896, 8.818528273319039 ]
  },
  "id_str" : "834538130673803264",
  "in_reply_to_user_id" : 2364949140,
  "text" : "@SssnakeySci this course I had was a one off.",
  "id" : 834538130673803264,
  "in_reply_to_status_id" : 834537150741872640,
  "created_at" : "2017-02-22 22:59:29 +0000",
  "in_reply_to_screen_name" : "SssnakeySci",
  "in_reply_to_user_id_str" : "2364949140",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen P.  \uD83D\uDC0D\uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "SssnakeySci",
      "indices" : [ 0, 12 ],
      "id_str" : "2364949140",
      "id" : 2364949140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834537150741872640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06104658896, 8.818528273319039 ]
  },
  "id_str" : "834538073794965504",
  "in_reply_to_user_id" : 2364949140,
  "text" : "@SssnakeySci totally agree. Unfortunately it\u2019s not really part of larger curricula it seems.",
  "id" : 834538073794965504,
  "in_reply_to_status_id" : 834537150741872640,
  "created_at" : "2017-02-22 22:59:16 +0000",
  "in_reply_to_screen_name" : "SssnakeySci",
  "in_reply_to_user_id_str" : "2364949140",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen P.  \uD83D\uDC0D\uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "SssnakeySci",
      "indices" : [ 0, 12 ],
      "id_str" : "2364949140",
      "id" : 2364949140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834535992522588161",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082157759291, 8.818412991183894 ]
  },
  "id_str" : "834536314888474624",
  "in_reply_to_user_id" : 2364949140,
  "text" : "@SssnakeySci similar to my experience!",
  "id" : 834536314888474624,
  "in_reply_to_status_id" : 834535992522588161,
  "created_at" : "2017-02-22 22:52:17 +0000",
  "in_reply_to_screen_name" : "SssnakeySci",
  "in_reply_to_user_id_str" : "2364949140",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834535666461577216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06087915628174, 8.818570422733146 ]
  },
  "id_str" : "834535890139635717",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed as is seasons in the abyss, which is a good one as well. But I stand by SoH for being the best slayer pick for that list :P",
  "id" : 834535890139635717,
  "in_reply_to_status_id" : 834535666461577216,
  "created_at" : "2017-02-22 22:50:35 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen P.  \uD83D\uDC0D\uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "SssnakeySci",
      "indices" : [ 0, 12 ],
      "id_str" : "2364949140",
      "id" : 2364949140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834535497800228864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06087915628174, 8.818570422733146 ]
  },
  "id_str" : "834535583305388038",
  "in_reply_to_user_id" : 2364949140,
  "text" : "@SssnakeySci good news! \uD83D\uDC96",
  "id" : 834535583305388038,
  "in_reply_to_status_id" : 834535497800228864,
  "created_at" : "2017-02-22 22:49:22 +0000",
  "in_reply_to_screen_name" : "SssnakeySci",
  "in_reply_to_user_id_str" : "2364949140",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/x4ix5Pd3DA",
      "expanded_url" : "http:\/\/www.newyorker.com\/wp-content\/uploads\/2016\/03\/Borowitz-Justin-Trudeau.jpg",
      "display_url" : "newyorker.com\/wp-content\/upl\u2026"
    }, {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/XCwpcd6XxL",
      "expanded_url" : "https:\/\/twitter.com\/liamstack\/status\/834521514594693120",
      "display_url" : "twitter.com\/liamstack\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0609447187687, 8.818499629053049 ]
  },
  "id_str" : "834533895320240128",
  "text" : "How is \u00ABSouth of Heaven\u00BB not on that list?! \uD83C\uDDE8\uD83C\uDDE6 https:\/\/t.co\/x4ix5Pd3DA https:\/\/t.co\/XCwpcd6XxL",
  "id" : 834533895320240128,
  "created_at" : "2017-02-22 22:42:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Appropriate Tributes",
      "screen_name" : "godtributes",
      "indices" : [ 0, 12 ],
      "id_str" : "2566358196",
      "id" : 2566358196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834532918735228929",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06099073676101, 8.818549090391032 ]
  },
  "id_str" : "834533013996392448",
  "in_reply_to_user_id" : 2566358196,
  "text" : "@godtributes finally!",
  "id" : 834533013996392448,
  "in_reply_to_status_id" : 834532918735228929,
  "created_at" : "2017-02-22 22:39:10 +0000",
  "in_reply_to_screen_name" : "godtributes",
  "in_reply_to_user_id_str" : "2566358196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 103, 110 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06083634857924, 8.81866996502129 ]
  },
  "id_str" : "834532893103898625",
  "text" : "\u00ABI saved you some vaginas!\u00BB That\u2019s weird news to hear, until you get that it\u2019s about Karjalanpiirakka. @Koalha",
  "id" : 834532893103898625,
  "created_at" : "2017-02-22 22:38:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen P.  \uD83D\uDC0D\uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "SssnakeySci",
      "indices" : [ 0, 12 ],
      "id_str" : "2364949140",
      "id" : 2364949140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834517604077338624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084195324664, 8.818468451999848 ]
  },
  "id_str" : "834522445176504321",
  "in_reply_to_user_id" : 2364949140,
  "text" : "@SssnakeySci during my Eco\/Evo master studies we were all sat down for \u201Cthe talk\u201D about the whole adaptionist\/neutralist thing \uD83D\uDE02",
  "id" : 834522445176504321,
  "in_reply_to_status_id" : 834517604077338624,
  "created_at" : "2017-02-22 21:57:10 +0000",
  "in_reply_to_screen_name" : "SssnakeySci",
  "in_reply_to_user_id_str" : "2364949140",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen P.  \uD83D\uDC0D\uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "SssnakeySci",
      "indices" : [ 0, 12 ],
      "id_str" : "2364949140",
      "id" : 2364949140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834485789249699846",
  "geo" : { },
  "id_str" : "834516029422329865",
  "in_reply_to_user_id" : 2364949140,
  "text" : "@SssnakeySci totally worth failing for that!",
  "id" : 834516029422329865,
  "in_reply_to_status_id" : 834485789249699846,
  "created_at" : "2017-02-22 21:31:40 +0000",
  "in_reply_to_screen_name" : "SssnakeySci",
  "in_reply_to_user_id_str" : "2364949140",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "_katsel",
      "indices" : [ 0, 8 ],
      "id_str" : "892038837052076033",
      "id" : 892038837052076033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834510877332275200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078586577417, 8.81860240175002 ]
  },
  "id_str" : "834511522206535680",
  "in_reply_to_user_id" : 730326143295959040,
  "text" : "@_katsel hat der Hund es angeknabbert? :p",
  "id" : 834511522206535680,
  "in_reply_to_status_id" : 834510877332275200,
  "created_at" : "2017-02-22 21:13:46 +0000",
  "in_reply_to_screen_name" : "katheyrina",
  "in_reply_to_user_id_str" : "730326143295959040",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 0, 14 ],
      "id_str" : "257319757",
      "id" : 257319757
    }, {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "indices" : [ 15, 31 ],
      "id_str" : "17462723",
      "id" : 17462723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834490075807416331",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084306795375, 8.818682892568628 ]
  },
  "id_str" : "834507672745549824",
  "in_reply_to_user_id" : 257319757,
  "text" : "@lorrainechu3n @creativecommons see you there! \uD83D\uDC4B",
  "id" : 834507672745549824,
  "in_reply_to_status_id" : 834490075807416331,
  "created_at" : "2017-02-22 20:58:28 +0000",
  "in_reply_to_screen_name" : "lorrainechu3n",
  "in_reply_to_user_id_str" : "257319757",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834490977519882241",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06089049861772, 8.818536289044486 ]
  },
  "id_str" : "834503524889325568",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim Persian Americana.",
  "id" : 834503524889325568,
  "in_reply_to_status_id" : 834490977519882241,
  "created_at" : "2017-02-22 20:41:59 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/gveBXhWVFU",
      "expanded_url" : "https:\/\/twitter.com\/darth\/status\/834481575744016384",
      "display_url" : "twitter.com\/darth\/status\/8\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06092274545622, 8.818430120604383 ]
  },
  "id_str" : "834501248435048448",
  "text" : "This year just improved by a lot! https:\/\/t.co\/gveBXhWVFU",
  "id" : 834501248435048448,
  "created_at" : "2017-02-22 20:32:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    }, {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 17, 31 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834500271246016513",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06092274545622, 8.818430120604383 ]
  },
  "id_str" : "834500839179972608",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess @zoonpolitikon yeah, thanks for being more explicit :)",
  "id" : 834500839179972608,
  "in_reply_to_status_id" : 834500271246016513,
  "created_at" : "2017-02-22 20:31:18 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    }, {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 17, 31 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834499953812729860",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06101371098539, 8.818603513118086 ]
  },
  "id_str" : "834500115792613378",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess @zoonpolitikon thanks, that\u2019s the point I wanted to make with Gould.",
  "id" : 834500115792613378,
  "in_reply_to_status_id" : 834499953812729860,
  "created_at" : "2017-02-22 20:28:26 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834498894264406016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06089724604977, 8.818581718959676 ]
  },
  "id_str" : "834499221881516033",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon but give the book a try if you find the time :)",
  "id" : 834499221881516033,
  "in_reply_to_status_id" : 834498894264406016,
  "created_at" : "2017-02-22 20:24:53 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834498894264406016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06089724604977, 8.818581718959676 ]
  },
  "id_str" : "834499161433239557",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon normative focus of a certain kind of intelligence is the problem, along with discrimination of everyone not fitting.",
  "id" : 834499161433239557,
  "in_reply_to_status_id" : 834498894264406016,
  "created_at" : "2017-02-22 20:24:38 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834493682560729100",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06112676935054, 8.818566713064252 ]
  },
  "id_str" : "834498176128339968",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon I do, does thinking along the lines of Gould\u2019s critique in The Mismeasure of Men help?",
  "id" : 834498176128339968,
  "in_reply_to_status_id" : 834493682560729100,
  "created_at" : "2017-02-22 20:20:44 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/kTyonGHRFw",
      "expanded_url" : "https:\/\/twitter.com\/_katsel\/status\/827234672828674053",
      "display_url" : "twitter.com\/_katsel\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834484982110380032",
  "text" : "As I've been rightfully called out for being guilty of using it today: (re-)read this. https:\/\/t.co\/kTyonGHRFw",
  "id" : 834484982110380032,
  "created_at" : "2017-02-22 19:28:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 0, 12 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834477602802790400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06002087616367, 8.817903287716971 ]
  },
  "id_str" : "834482729416851457",
  "in_reply_to_user_id" : 12241752,
  "text" : "@denormalize snap! Totally forgot about that, already got my ticket to cross back to Europe on 1st of May :(",
  "id" : 834482729416851457,
  "in_reply_to_status_id" : 834477602802790400,
  "created_at" : "2017-02-22 19:19:21 +0000",
  "in_reply_to_screen_name" : "denormalize",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834475307314798592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06001475360735, 8.817978414221773 ]
  },
  "id_str" : "834482600681078792",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson I by now have an intuition for inch, feet and miles. But yards always escape me, despite being so close to 1:1!",
  "id" : 834482600681078792,
  "in_reply_to_status_id" : 834475307314798592,
  "created_at" : "2017-02-22 19:18:50 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834476145689010176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05997994106506, 8.817867032022379 ]
  },
  "id_str" : "834482420741242882",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson works for me as well :D",
  "id" : 834482420741242882,
  "in_reply_to_status_id" : 834476145689010176,
  "created_at" : "2017-02-22 19:18:07 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua McClure",
      "screen_name" : "joshuamcclure",
      "indices" : [ 0, 14 ],
      "id_str" : "14209307",
      "id" : 14209307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834474856418770948",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06000336291224, 8.817875042425316 ]
  },
  "id_str" : "834482233977208834",
  "in_reply_to_user_id" : 14209307,
  "text" : "@joshuamcclure too bad that an event I wanted to attend in Austin was canceled! But will let you know when I get the chance to drop by!",
  "id" : 834482233977208834,
  "in_reply_to_status_id" : 834474856418770948,
  "created_at" : "2017-02-22 19:17:23 +0000",
  "in_reply_to_screen_name" : "joshuamcclure",
  "in_reply_to_user_id_str" : "14209307",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834473051085434880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17130900216095, 8.627643767660713 ]
  },
  "id_str" : "834473351510970371",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson the worst about that is that I first have to translate the distance into meters. :p",
  "id" : 834473351510970371,
  "in_reply_to_status_id" : 834473051085434880,
  "created_at" : "2017-02-22 18:42:05 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17179045937363, 8.627528362732974 ]
  },
  "id_str" : "834472206419841029",
  "text" : "Jam session in the office! \uD83C\uDFB8\uD83E\uDD41",
  "id" : 834472206419841029,
  "created_at" : "2017-02-22 18:37:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 10, 24 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 25, 35 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/ckOxI2Tb4I",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/834469387121938438",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228302461599, 8.627350288459006 ]
  },
  "id_str" : "834471624007106560",
  "text" : "@kopshtik @beaugunderson @eltonjohn \uD83D\uDC36\uD83D\uDC40 https:\/\/t.co\/ckOxI2Tb4I",
  "id" : 834471624007106560,
  "created_at" : "2017-02-22 18:35:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235734811556, 8.627522747349154 ]
  },
  "id_str" : "834469387121938438",
  "text" : "I know it\u2019s a long shot, but are any of my Twitter friends in Seattle or Toronto having a couch for me to crash on during 23-27th April?",
  "id" : 834469387121938438,
  "created_at" : "2017-02-22 18:26:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834454560659894274",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235555800161, 8.627522978632614 ]
  },
  "id_str" : "834457264329199616",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg my bad :D",
  "id" : 834457264329199616,
  "in_reply_to_status_id" : 834454560659894274,
  "created_at" : "2017-02-22 17:38:09 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834454560659894274",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235555800161, 8.627522978632614 ]
  },
  "id_str" : "834457233295556608",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg aaah, ok!",
  "id" : 834457233295556608,
  "in_reply_to_status_id" : 834454560659894274,
  "created_at" : "2017-02-22 17:38:02 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834453318961393665",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235559710787, 8.627492810097056 ]
  },
  "id_str" : "834454280073519104",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg welche meinst du?",
  "id" : 834454280073519104,
  "in_reply_to_status_id" : 834453318961393665,
  "created_at" : "2017-02-22 17:26:18 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Junk Science",
      "screen_name" : "ScienceJunk",
      "indices" : [ 0, 12 ],
      "id_str" : "3195112389",
      "id" : 3195112389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834451409311584256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237862338594, 8.62751285776324 ]
  },
  "id_str" : "834451760198586370",
  "in_reply_to_user_id" : 3195112389,
  "text" : "@ScienceJunk amen!",
  "id" : 834451760198586370,
  "in_reply_to_status_id" : 834451409311584256,
  "created_at" : "2017-02-22 17:16:17 +0000",
  "in_reply_to_screen_name" : "ScienceJunk",
  "in_reply_to_user_id_str" : "3195112389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Junk Science",
      "screen_name" : "ScienceJunk",
      "indices" : [ 3, 15 ],
      "id_str" : "3195112389",
      "id" : 3195112389
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 17, 33 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "834451512445304833",
  "text" : "RT @ScienceJunk: @gedankenstuecke agree, being lazy is one thing, but both stupid and lazy is just a bit too much",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "834441595151843329",
    "geo" : { },
    "id_str" : "834451409311584256",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke agree, being lazy is one thing, but both stupid and lazy is just a bit too much",
    "id" : 834451409311584256,
    "in_reply_to_status_id" : 834441595151843329,
    "created_at" : "2017-02-22 17:14:53 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Junk Science",
      "screen_name" : "ScienceJunk",
      "protected" : false,
      "id_str" : "3195112389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/803154822228754432\/aJogly9K_normal.jpg",
      "id" : 3195112389,
      "verified" : false
    }
  },
  "id" : 834451512445304833,
  "created_at" : "2017-02-22 17:15:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 142, 165 ],
      "url" : "https:\/\/t.co\/8HgMT4rqRr",
      "expanded_url" : "https:\/\/twitter.com\/ScienceJunk\/status\/834389966671249410",
      "display_url" : "twitter.com\/ScienceJunk\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238306061407, 8.627504261520912 ]
  },
  "id_str" : "834441595151843329",
  "text" : "The fraud I get least: If you just publish cutouts of your gels\/blots in any case, why not at least avoid copy &amp; pasting same band twice? https:\/\/t.co\/8HgMT4rqRr",
  "id" : 834441595151843329,
  "created_at" : "2017-02-22 16:35:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834438740919668736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234910758754, 8.627488651535606 ]
  },
  "id_str" : "834438931714277376",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABMaking shit up\u00BB is literally his current job title.",
  "id" : 834438931714277376,
  "in_reply_to_status_id" : 834438740919668736,
  "created_at" : "2017-02-22 16:25:19 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/K90RCi5W8l",
      "expanded_url" : "https:\/\/twitter.com\/marc_rr\/status\/834323467138916352",
      "display_url" : "twitter.com\/marc_rr\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234910758754, 8.627488651535606 ]
  },
  "id_str" : "834438740919668736",
  "text" : "Most hilarious thing is that Ullal has the title of \u201EScientific Narrator\u201C at Karmagenes. \uD83D\uDE02 https:\/\/t.co\/K90RCi5W8l",
  "id" : 834438740919668736,
  "created_at" : "2017-02-22 16:24:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 3, 11 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "834438505472339969",
  "text" : "RT @marc_rr: Chief scientific officer of pseudo-science startup Karmagenes faked data for his PhD. Fake all the way down\nhttps:\/\/t.co\/7sfj5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/7sfj5qJi61",
        "expanded_url" : "http:\/\/retractionwatch.com\/2017\/02\/21\/former-postdoc-admitted-fraud-cell-bio-paper-lead-author-says\/",
        "display_url" : "retractionwatch.com\/2017\/02\/21\/for\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "834323467138916352",
    "text" : "Chief scientific officer of pseudo-science startup Karmagenes faked data for his PhD. Fake all the way down\nhttps:\/\/t.co\/7sfj5qJi61",
    "id" : 834323467138916352,
    "created_at" : "2017-02-22 08:46:30 +0000",
    "user" : {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "protected" : false,
      "id_str" : "454724555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1751744306\/mrr_caricature_normal.jpg",
      "id" : 454724555,
      "verified" : false
    }
  },
  "id" : 834438505472339969,
  "created_at" : "2017-02-22 16:23:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834430390471385088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231988428289, 8.627518962071115 ]
  },
  "id_str" : "834430506255130629",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor yes, they are already installed outside of Linuxbrew but it doesn\u2019t seem to understand\/accept that they\u2019re in $PATH already.",
  "id" : 834430506255130629,
  "in_reply_to_status_id" : 834430390471385088,
  "created_at" : "2017-02-22 15:51:50 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233487534985, 8.627514994981205 ]
  },
  "id_str" : "834426850197794818",
  "text" : "Hey Linuxbrew people, is there any way to turn off the installation of _all_ dependencies when installing a given package?",
  "id" : 834426850197794818,
  "created_at" : "2017-02-22 15:37:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivonne Lujano",
      "screen_name" : "ivonnelujano",
      "indices" : [ 3, 16 ],
      "id_str" : "92634871",
      "id" : 92634871
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "accesoabierto",
      "indices" : [ 61, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/Y18bzYOJnA",
      "expanded_url" : "https:\/\/twitter.com\/AbelLaerte\/status\/834393340892368897",
      "display_url" : "twitter.com\/AbelLaerte\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834396166989176832",
  "text" : "RT @ivonnelujano: Repositorio de preprints en Am\u00E9rica Latina #accesoabierto https:\/\/t.co\/Y18bzYOJnA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "accesoabierto",
        "indices" : [ 43, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/Y18bzYOJnA",
        "expanded_url" : "https:\/\/twitter.com\/AbelLaerte\/status\/834393340892368897",
        "display_url" : "twitter.com\/AbelLaerte\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "834394121619922944",
    "text" : "Repositorio de preprints en Am\u00E9rica Latina #accesoabierto https:\/\/t.co\/Y18bzYOJnA",
    "id" : 834394121619922944,
    "created_at" : "2017-02-22 13:27:15 +0000",
    "user" : {
      "name" : "Ivonne Lujano",
      "screen_name" : "ivonnelujano",
      "protected" : false,
      "id_str" : "92634871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927504655340498944\/Ndnv3YS4_normal.jpg",
      "id" : 92634871,
      "verified" : false
    }
  },
  "id" : 834396166989176832,
  "created_at" : "2017-02-22 13:35:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dani Rabaiotti",
      "screen_name" : "DaniRabaiotti",
      "indices" : [ 0, 14 ],
      "id_str" : "636216638",
      "id" : 636216638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/PznlEf6LVx",
      "expanded_url" : "https:\/\/s.yimg.com\/ny\/api\/res\/1.2\/6u5DDPIcIq5ONyR8pki1qQ--\/YXBwaWQ9aGlnaGxhbmRlcjtzbT0xO3c9ODAw\/http:\/\/media.zenfs.com\/en-US\/homerun\/etonline.tv\/d786bc218f99f334fefa7f5446eebf59",
      "display_url" : "s.yimg.com\/ny\/api\/res\/1.2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "834393170146422786",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237698542505, 8.62753266738338 ]
  },
  "id_str" : "834395706777620481",
  "in_reply_to_user_id" : 636216638,
  "text" : "@DaniRabaiotti well, if that wasn\u2019t easy\u2026 https:\/\/t.co\/PznlEf6LVx",
  "id" : 834395706777620481,
  "in_reply_to_status_id" : 834393170146422786,
  "created_at" : "2017-02-22 13:33:33 +0000",
  "in_reply_to_screen_name" : "DaniRabaiotti",
  "in_reply_to_user_id_str" : "636216638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abeba Birhane",
      "screen_name" : "Abebab",
      "indices" : [ 3, 10 ],
      "id_str" : "229005889",
      "id" : 229005889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "834395354711855106",
  "text" : "RT @Abebab: White male academics, this is how you discourage black women from entering into academia when they already have one foot out th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/nSJc2g9oWK",
        "expanded_url" : "https:\/\/twitter.com\/robkowa\/status\/834390454967947264",
        "display_url" : "twitter.com\/robkowa\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "834392426466906112",
    "text" : "White male academics, this is how you discourage black women from entering into academia when they already have one foot out the door! https:\/\/t.co\/nSJc2g9oWK",
    "id" : 834392426466906112,
    "created_at" : "2017-02-22 13:20:31 +0000",
    "user" : {
      "name" : "Abeba Birhane",
      "screen_name" : "Abebab",
      "protected" : false,
      "id_str" : "229005889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929424339962925056\/-3ujXCde_normal.jpg",
      "id" : 229005889,
      "verified" : false
    }
  },
  "id" : 834395354711855106,
  "created_at" : "2017-02-22 13:32:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 36, 44 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/LTiu1cwcwn",
      "expanded_url" : "http:\/\/www.molecularecologist.com\/2017\/02\/population-genomics-in-the-melting-pot\/",
      "display_url" : "molecularecologist.com\/2017\/02\/popula\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233473859169, 8.627569347342703 ]
  },
  "id_str" : "834357152378736642",
  "text" : "Nice post on use of DTC genetics by @JBYoder: Population genomics in the \u201Cmelting pot\u201D https:\/\/t.co\/LTiu1cwcwn",
  "id" : 834357152378736642,
  "created_at" : "2017-02-22 11:00:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834354382955233281",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232921361538, 8.627536720937343 ]
  },
  "id_str" : "834354469873864704",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski me neither, forgot the sarcasm-emoji \uD83D\uDE1B",
  "id" : 834354469873864704,
  "in_reply_to_status_id" : 834354382955233281,
  "created_at" : "2017-02-22 10:49:41 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/OX9VwAmm87",
      "expanded_url" : "https:\/\/brainsidea.wordpress.com\/2017\/02\/22\/do-twitter-or-facebook-activity-influence-scientific-impact\/",
      "display_url" : "brainsidea.wordpress.com\/2017\/02\/22\/do-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235800513655, 8.627489190773499 ]
  },
  "id_str" : "834353766832996352",
  "text" : "Surprise: Twitter boosts your citations, Facebook doesn\u2019t. \uD83D\uDE02 https:\/\/t.co\/OX9VwAmm87",
  "id" : 834353766832996352,
  "created_at" : "2017-02-22 10:46:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 0, 13 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834347333861179392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235031473573, 8.627516552730476 ]
  },
  "id_str" : "834347481534185472",
  "in_reply_to_user_id" : 1421360166,
  "text" : "@ToxXInFlames they must know that I\u2019m a PhD student, so they\u2019re not so off after all :P",
  "id" : 834347481534185472,
  "in_reply_to_status_id" : 834347333861179392,
  "created_at" : "2017-02-22 10:21:55 +0000",
  "in_reply_to_screen_name" : "ToxXInFlames",
  "in_reply_to_user_id_str" : "1421360166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ADS",
      "screen_name" : "ADS_Update",
      "indices" : [ 0, 11 ],
      "id_str" : "1506671",
      "id" : 1506671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834339581881368578",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238012173647, 8.627516547785106 ]
  },
  "id_str" : "834339719240613888",
  "in_reply_to_user_id" : 1506671,
  "text" : "@ADS_Update will certainly do!",
  "id" : 834339719240613888,
  "in_reply_to_status_id" : 834339581881368578,
  "created_at" : "2017-02-22 09:51:05 +0000",
  "in_reply_to_screen_name" : "ADS_Update",
  "in_reply_to_user_id_str" : "1506671",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Fildes",
      "screen_name" : "thomasfildes",
      "indices" : [ 0, 13 ],
      "id_str" : "581980657",
      "id" : 581980657
    }, {
      "name" : "ADS",
      "screen_name" : "ADS_Update",
      "indices" : [ 14, 25 ],
      "id_str" : "1506671",
      "id" : 1506671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/01E7rjv8v9",
      "expanded_url" : "http:\/\/intarch.ac.uk\/about\/donate.html",
      "display_url" : "intarch.ac.uk\/about\/donate.h\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "834335894274445312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233494092828, 8.62754824075802 ]
  },
  "id_str" : "834336997741322241",
  "in_reply_to_user_id" : 581980657,
  "text" : "@thomasfildes @ADS_Update nope, but you can get one as a gift if you donate to the ADS open access fund: https:\/\/t.co\/01E7rjv8v9",
  "id" : 834336997741322241,
  "in_reply_to_status_id" : 834335894274445312,
  "created_at" : "2017-02-22 09:40:16 +0000",
  "in_reply_to_screen_name" : "thomasfildes",
  "in_reply_to_user_id_str" : "581980657",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/z6SU0yIaWw",
      "expanded_url" : "https:\/\/github.com\/nextgenusfs\/funannotate\/issues\/45",
      "display_url" : "github.com\/nextgenusfs\/fu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236796812371, 8.627519773707963 ]
  },
  "id_str" : "834333297400483841",
  "text" : "Anyone ever encountered this error when using funannotate? https:\/\/t.co\/z6SU0yIaWw",
  "id" : 834333297400483841,
  "created_at" : "2017-02-22 09:25:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "illucifer",
      "indices" : [ 0, 10 ],
      "id_str" : "342973975",
      "id" : 342973975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834330436847468545",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236741456806, 8.627520026650153 ]
  },
  "id_str" : "834330663167913985",
  "in_reply_to_user_id" : 342973975,
  "text" : "@illucifer was just sent it this morning when I was also in desperate need of dogs \uD83D\uDE0D",
  "id" : 834330663167913985,
  "in_reply_to_status_id" : 834330436847468545,
  "created_at" : "2017-02-22 09:15:05 +0000",
  "in_reply_to_screen_name" : "illucifer",
  "in_reply_to_user_id_str" : "342973975",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "illucifer",
      "indices" : [ 0, 10 ],
      "id_str" : "342973975",
      "id" : 342973975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/Ei8qMRjmKa",
      "expanded_url" : "http:\/\/moby.to\/2tlmzu",
      "display_url" : "moby.to\/2tlmzu"
    } ]
  },
  "in_reply_to_status_id_str" : "834329786017280000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233898320057, 8.627515749906348 ]
  },
  "id_str" : "834330074870603776",
  "in_reply_to_user_id" : 342973975,
  "text" : "@illucifer https:\/\/t.co\/Ei8qMRjmKa",
  "id" : 834330074870603776,
  "in_reply_to_status_id" : 834329786017280000,
  "created_at" : "2017-02-22 09:12:45 +0000",
  "in_reply_to_screen_name" : "illucifer",
  "in_reply_to_user_id_str" : "342973975",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834329336723492864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233898320057, 8.627515749906348 ]
  },
  "id_str" : "834329680643768320",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik (unless you\u2019re expected super noisy long-reads but you\u2019re having basically very long \u201Eshort-reads\u201C).",
  "id" : 834329680643768320,
  "in_reply_to_status_id" : 834329336723492864,
  "created_at" : "2017-02-22 09:11:11 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834329336723492864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235259108514, 8.62754744114322 ]
  },
  "id_str" : "834329548917444608",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik nah, not really a difference for the algorithm. Doesn\u2019t matter how the long sequence was generated.",
  "id" : 834329548917444608,
  "in_reply_to_status_id" : 834329336723492864,
  "created_at" : "2017-02-22 09:10:40 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834328872493674496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235259108514, 8.62754744114322 ]
  },
  "id_str" : "834329166778605568",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik works just as well. From README: \u201EFor longer sequences, sensitive modes ( --sensitive --more-sensitive) are recommended\u201C",
  "id" : 834329166778605568,
  "in_reply_to_status_id" : 834328872493674496,
  "created_at" : "2017-02-22 09:09:09 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834328618658627584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238162353377, 8.62745669434715 ]
  },
  "id_str" : "834328715022700544",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik the simple explanation: It\u2019s blastp\/blastx on speed. :D",
  "id" : 834328715022700544,
  "in_reply_to_status_id" : 834328618658627584,
  "created_at" : "2017-02-22 09:07:21 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834328247466852352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238162353377, 8.62745669434715 ]
  },
  "id_str" : "834328465499369474",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik gives you tabular output \u00B1 identical to blastall. iirc was easy to replace in blobology case.",
  "id" : 834328465499369474,
  "in_reply_to_status_id" : 834328247466852352,
  "created_at" : "2017-02-22 09:06:21 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 47, 54 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834327769014267904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236795529869, 8.627511515840661 ]
  },
  "id_str" : "834328009725374464",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 that\u2019s what I did when I tried some @sujaik-blobology.",
  "id" : 834328009725374464,
  "in_reply_to_status_id" : 834327769014267904,
  "created_at" : "2017-02-22 09:04:33 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/xglaF6YvgK",
      "expanded_url" : "https:\/\/github.com\/bbuchfink\/diamond",
      "display_url" : "github.com\/bbuchfink\/diam\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "834327769014267904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236795529869, 8.627511515840661 ]
  },
  "id_str" : "834327910492286976",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 ok, then just use diamond instead, so much faster! https:\/\/t.co\/xglaF6YvgK",
  "id" : 834327910492286976,
  "in_reply_to_status_id" : 834327769014267904,
  "created_at" : "2017-02-22 09:04:09 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834327618216419328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236795529869, 8.627511515840661 ]
  },
  "id_str" : "834327723413749760",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 against what kind of DB? (i.e. blastn or blastx?)",
  "id" : 834327723413749760,
  "in_reply_to_status_id" : 834327618216419328,
  "created_at" : "2017-02-22 09:03:24 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "834324488326148097",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236795529869, 8.627511515840661 ]
  },
  "id_str" : "834327478416060416",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 why would you BLAST long sequences?",
  "id" : 834327478416060416,
  "in_reply_to_status_id" : 834324488326148097,
  "created_at" : "2017-02-22 09:02:26 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/6Xe3wHoE18",
      "expanded_url" : "http:\/\/journals.plos.org\/ploscompbiol\/article?id=10.1371%2Fjournal.pcbi.1005404&utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ploscompbiol%2FNewArticles+%28PLOS+Computational+Biology+-+New+Articles%29#sec002",
      "display_url" : "journals.plos.org\/ploscompbiol\/a\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236220280916, 8.627513476858054 ]
  },
  "id_str" : "834322452612268035",
  "text" : "Metacoder: An R package for visualization and manipulation of community taxonomic diversity data https:\/\/t.co\/6Xe3wHoE18",
  "id" : 834322452612268035,
  "created_at" : "2017-02-22 08:42:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08LGBTPlusProud\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08 - Be You",
      "screen_name" : "LGBTPlusProud",
      "indices" : [ 3, 17 ],
      "id_str" : "2203993285",
      "id" : 2203993285
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LGBTPlusProud\/status\/817651275466764288\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/8WbzfDUZKD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C1jhf1KXgAAGLgA.jpg",
      "id_str" : "817651269330501632",
      "id" : 817651269330501632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C1jhf1KXgAAGLgA.jpg",
      "sizes" : [ {
        "h" : 1076,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 1076,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1076,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 473
      } ],
      "display_url" : "pic.twitter.com\/8WbzfDUZKD"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/LGBTPlusProud\/status\/817651275466764288\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/8WbzfDUZKD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C1jhf1HWIAAS0U-.jpg",
      "id_str" : "817651269317828608",
      "id" : 817651269317828608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C1jhf1HWIAAS0U-.jpg",
      "sizes" : [ {
        "h" : 625,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 625,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 625,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 625,
        "resize" : "fit",
        "w" : 625
      } ],
      "display_url" : "pic.twitter.com\/8WbzfDUZKD"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/LGBTPlusProud\/status\/817651275466764288\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/8WbzfDUZKD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C1jhf1JW8AARKg8.jpg",
      "id_str" : "817651269326270464",
      "id" : 817651269326270464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C1jhf1JW8AARKg8.jpg",
      "sizes" : [ {
        "h" : 963,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 963,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 963,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8WbzfDUZKD"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/LGBTPlusProud\/status\/817651275466764288\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/8WbzfDUZKD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C1jhf1IWgAAdinD.jpg",
      "id_str" : "817651269322047488",
      "id" : 817651269322047488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C1jhf1IWgAAdinD.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8WbzfDUZKD"
    } ],
    "hashtags" : [ {
      "text" : "bivisibility",
      "indices" : [ 44, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "834204128322678784",
  "text" : "RT @LGBTPlusProud: Some gentle reminders...\n#bivisibility https:\/\/t.co\/8WbzfDUZKD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LGBTPlusProud\/status\/817651275466764288\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/8WbzfDUZKD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C1jhf1KXgAAGLgA.jpg",
        "id_str" : "817651269330501632",
        "id" : 817651269330501632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C1jhf1KXgAAGLgA.jpg",
        "sizes" : [ {
          "h" : 1076,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 1076,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1076,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 473
        } ],
        "display_url" : "pic.twitter.com\/8WbzfDUZKD"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/LGBTPlusProud\/status\/817651275466764288\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/8WbzfDUZKD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C1jhf1HWIAAS0U-.jpg",
        "id_str" : "817651269317828608",
        "id" : 817651269317828608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C1jhf1HWIAAS0U-.jpg",
        "sizes" : [ {
          "h" : 625,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 625,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 625,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 625,
          "resize" : "fit",
          "w" : 625
        } ],
        "display_url" : "pic.twitter.com\/8WbzfDUZKD"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/LGBTPlusProud\/status\/817651275466764288\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/8WbzfDUZKD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C1jhf1JW8AARKg8.jpg",
        "id_str" : "817651269326270464",
        "id" : 817651269326270464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C1jhf1JW8AARKg8.jpg",
        "sizes" : [ {
          "h" : 963,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 963,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 963,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/8WbzfDUZKD"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/LGBTPlusProud\/status\/817651275466764288\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/8WbzfDUZKD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C1jhf1IWgAAdinD.jpg",
        "id_str" : "817651269322047488",
        "id" : 817651269322047488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C1jhf1IWgAAdinD.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/8WbzfDUZKD"
      } ],
      "hashtags" : [ {
        "text" : "bivisibility",
        "indices" : [ 25, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "833290113853616128",
    "text" : "Some gentle reminders...\n#bivisibility https:\/\/t.co\/8WbzfDUZKD",
    "id" : 833290113853616128,
    "created_at" : "2017-02-19 12:20:19 +0000",
    "user" : {
      "name" : "\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08LGBTPlusProud\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08 - Be You",
      "screen_name" : "LGBTPlusProud",
      "protected" : false,
      "id_str" : "2203993285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/868993190807908352\/xyH-QLZU_normal.jpg",
      "id" : 2203993285,
      "verified" : false
    }
  },
  "id" : 834204128322678784,
  "created_at" : "2017-02-22 00:52:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Culture",
      "screen_name" : "openculture",
      "indices" : [ 3, 15 ],
      "id_str" : "19826509",
      "id" : 19826509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/co12KThrpg",
      "expanded_url" : "http:\/\/bit.ly\/2aepbtL",
      "display_url" : "bit.ly\/2aepbtL"
    } ]
  },
  "geo" : { },
  "id_str" : "834163347377496064",
  "text" : "RT @openculture: John Cage\u2019s Silent, Avant-Garde Piece 4\u201933\" Gets Covered by a Death Metal Band https:\/\/t.co\/co12KThrpg https:\/\/t.co\/Jzcl8d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/openculture\/status\/834146682950410240\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/Jzcl8d4VUt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C5N774tUoAA2XT2.jpg",
        "id_str" : "834146624758652928",
        "id" : 834146624758652928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C5N774tUoAA2XT2.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/Jzcl8d4VUt"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/co12KThrpg",
        "expanded_url" : "http:\/\/bit.ly\/2aepbtL",
        "display_url" : "bit.ly\/2aepbtL"
      } ]
    },
    "geo" : { },
    "id_str" : "834146682950410240",
    "text" : "John Cage\u2019s Silent, Avant-Garde Piece 4\u201933\" Gets Covered by a Death Metal Band https:\/\/t.co\/co12KThrpg https:\/\/t.co\/Jzcl8d4VUt",
    "id" : 834146682950410240,
    "created_at" : "2017-02-21 21:04:01 +0000",
    "user" : {
      "name" : "Open Culture",
      "screen_name" : "openculture",
      "protected" : false,
      "id_str" : "19826509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851645340830715904\/jrs1gcNM_normal.jpg",
      "id" : 19826509,
      "verified" : false
    }
  },
  "id" : 834163347377496064,
  "created_at" : "2017-02-21 22:10:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Scheel",
      "screen_name" : "annemscheel",
      "indices" : [ 3, 15 ],
      "id_str" : "320376718",
      "id" : 320376718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "834162430347468801",
  "text" : "RT @annemscheel: This gives a pretty different perspective than \"unnamed non-author grad student faked my data and nobody knew\"... https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/J9jXta9S5D",
        "expanded_url" : "https:\/\/twitter.com\/RolfZwaan\/status\/834058638838870018",
        "display_url" : "twitter.com\/RolfZwaan\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "834133404736163840",
    "text" : "This gives a pretty different perspective than \"unnamed non-author grad student faked my data and nobody knew\"... https:\/\/t.co\/J9jXta9S5D",
    "id" : 834133404736163840,
    "created_at" : "2017-02-21 20:11:15 +0000",
    "user" : {
      "name" : "Anne Scheel",
      "screen_name" : "annemscheel",
      "protected" : false,
      "id_str" : "320376718",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879074927462277121\/cjwxVBQV_normal.jpg",
      "id" : 320376718,
      "verified" : false
    }
  },
  "id" : 834162430347468801,
  "created_at" : "2017-02-21 22:06:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wright",
      "screen_name" : "JenAshleyWright",
      "indices" : [ 3, 19 ],
      "id_str" : "112764405",
      "id" : 112764405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "834153173711454209",
  "text" : "RT @JenAshleyWright: I couldn't read one more of those \"Why aren't millennials buying soap\/diamonds\/sporks?\" articles so I wrote this. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/OfEZcmmfYG",
        "expanded_url" : "https:\/\/medium.com\/@JenAshleyWright\/why-arent-baby-boomers-eating-pho-e4792e66d56e#.y3cryagcb",
        "display_url" : "medium.com\/@JenAshleyWrig\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "834127898667802624",
    "text" : "I couldn't read one more of those \"Why aren't millennials buying soap\/diamonds\/sporks?\" articles so I wrote this. https:\/\/t.co\/OfEZcmmfYG",
    "id" : 834127898667802624,
    "created_at" : "2017-02-21 19:49:23 +0000",
    "user" : {
      "name" : "Jennifer Wright",
      "screen_name" : "JenAshleyWright",
      "protected" : false,
      "id_str" : "112764405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852343966792126464\/KRpc_8UW_normal.jpg",
      "id" : 112764405,
      "verified" : true
    }
  },
  "id" : 834153173711454209,
  "created_at" : "2017-02-21 21:29:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/834149558225604608\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/43a7KY4J7Y",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C5N-lJrW8AArjkd.jpg",
      "id_str" : "834149532711710720",
      "id" : 834149532711710720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C5N-lJrW8AArjkd.jpg",
      "sizes" : [ {
        "h" : 372,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/43a7KY4J7Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "834149558225604608",
  "text" : "Ok folks, it's time for some evolutionary game theory. 1\/234 https:\/\/t.co\/43a7KY4J7Y",
  "id" : 834149558225604608,
  "created_at" : "2017-02-21 21:15:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/iYIZRyn5e7",
      "expanded_url" : "https:\/\/twitter.com\/hopihoekstra\/status\/834142940507361285",
      "display_url" : "twitter.com\/hopihoekstra\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834144671987298309",
  "text" : "RT @JBYoder: \u201Cthe construction of an academic niche?\u201D  \uD83D\uDD25\uD83D\uDD25\uD83D\uDD25 https:\/\/t.co\/iYIZRyn5e7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/iYIZRyn5e7",
        "expanded_url" : "https:\/\/twitter.com\/hopihoekstra\/status\/834142940507361285",
        "display_url" : "twitter.com\/hopihoekstra\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "834143554419118080",
    "text" : "\u201Cthe construction of an academic niche?\u201D  \uD83D\uDD25\uD83D\uDD25\uD83D\uDD25 https:\/\/t.co\/iYIZRyn5e7",
    "id" : 834143554419118080,
    "created_at" : "2017-02-21 20:51:35 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 834144671987298309,
  "created_at" : "2017-02-21 20:56:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 3, 17 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PoCInLove",
      "indices" : [ 93, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/o9y6NSqPu5",
      "expanded_url" : "https:\/\/www.buzzfeed.com\/krishrach\/people-are-celebrating-diverse-relationships-with-the-hashta",
      "display_url" : "buzzfeed.com\/krishrach\/peop\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834127828824313857",
  "text" : "RT @NazeefaFatima: Beautiful | People Are Celebrating Diverse Relationships With The Hashtag #PoCInLove https:\/\/t.co\/o9y6NSqPu5 via @Rachae\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rachael Krishna",
        "screen_name" : "RachaelKrishna",
        "indices" : [ 113, 128 ],
        "id_str" : "31167776",
        "id" : 31167776
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PoCInLove",
        "indices" : [ 74, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/o9y6NSqPu5",
        "expanded_url" : "https:\/\/www.buzzfeed.com\/krishrach\/people-are-celebrating-diverse-relationships-with-the-hashta",
        "display_url" : "buzzfeed.com\/krishrach\/peop\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "834124708379496448",
    "text" : "Beautiful | People Are Celebrating Diverse Relationships With The Hashtag #PoCInLove https:\/\/t.co\/o9y6NSqPu5 via @RachaelKrishna",
    "id" : 834124708379496448,
    "created_at" : "2017-02-21 19:36:42 +0000",
    "user" : {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "protected" : false,
      "id_str" : "37054704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930210077885202432\/DY8D8hGM_normal.jpg",
      "id" : 37054704,
      "verified" : false
    }
  },
  "id" : 834127828824313857,
  "created_at" : "2017-02-21 19:49:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/9HQrLep3dW",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/goXyMnK1Gto\/article",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834125108096675840",
  "text" : "Science Journalism: Poor replication validity of biomedical association studies reported by newspapers https:\/\/t.co\/9HQrLep3dW",
  "id" : 834125108096675840,
  "created_at" : "2017-02-21 19:38:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c0nc0rdance",
      "screen_name" : "c0nc0rdance",
      "indices" : [ 3, 15 ],
      "id_str" : "86377557",
      "id" : 86377557
    }, {
      "name" : "Richard E. Lenski",
      "screen_name" : "RELenski",
      "indices" : [ 33, 42 ],
      "id_str" : "1676175931",
      "id" : 1676175931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/uI7R1e7CLR",
      "expanded_url" : "http:\/\/www.pnas.org\/content\/105\/23\/7899.full",
      "display_url" : "pnas.org\/content\/105\/23\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834117583272026112",
  "text" : "RT @c0nc0rdance: Happened across @RELenski's paper on contingency (good read!) and had to look up this Gould quote.\nhttps:\/\/t.co\/uI7R1e7CLR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Richard E. Lenski",
        "screen_name" : "RELenski",
        "indices" : [ 16, 25 ],
        "id_str" : "1676175931",
        "id" : 1676175931
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/c0nc0rdance\/status\/833924980614197248\/photo\/1",
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/4WDXmhyZtx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C5Kw8hmUkAAIUcF.jpg",
        "id_str" : "833923434874703872",
        "id" : 833923434874703872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C5Kw8hmUkAAIUcF.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/4WDXmhyZtx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/uI7R1e7CLR",
        "expanded_url" : "http:\/\/www.pnas.org\/content\/105\/23\/7899.full",
        "display_url" : "pnas.org\/content\/105\/23\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "833924980614197248",
    "text" : "Happened across @RELenski's paper on contingency (good read!) and had to look up this Gould quote.\nhttps:\/\/t.co\/uI7R1e7CLR https:\/\/t.co\/4WDXmhyZtx",
    "id" : 833924980614197248,
    "created_at" : "2017-02-21 06:23:03 +0000",
    "user" : {
      "name" : "c0nc0rdance",
      "screen_name" : "c0nc0rdance",
      "protected" : false,
      "id_str" : "86377557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/813755190440398848\/64bv-TpE_normal.jpg",
      "id" : 86377557,
      "verified" : false
    }
  },
  "id" : 834117583272026112,
  "created_at" : "2017-02-21 19:08:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/cg3JO1Vg38",
      "expanded_url" : "https:\/\/twitter.com\/LGBTSTEM\/status\/833921847343341568",
      "display_url" : "twitter.com\/LGBTSTEM\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401804951494, 8.753304140395517 ]
  },
  "id_str" : "834102204055302144",
  "text" : "Well, if that isn\u2019t a good reason to visit York! https:\/\/t.co\/cg3JO1Vg38",
  "id" : 834102204055302144,
  "created_at" : "2017-02-21 18:07:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "indices" : [ 3, 12 ],
      "id_str" : "2442015493",
      "id" : 2442015493
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar",
      "indices" : [ 43, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "834102005564112896",
  "text" : "RT @LGBTSTEM: Excited to announce that the #LGBTSTEMinar will be at the University of York next year and The Royal Astronomical Society the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTSTEMinar",
        "indices" : [ 29, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "833921847343341568",
    "text" : "Excited to announce that the #LGBTSTEMinar will be at the University of York next year and The Royal Astronomical Society the year after.",
    "id" : 833921847343341568,
    "created_at" : "2017-02-21 06:10:36 +0000",
    "user" : {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "protected" : false,
      "id_str" : "2442015493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685082380223295488\/XGTcyfxo_normal.jpg",
      "id" : 2442015493,
      "verified" : false
    }
  },
  "id" : 834102005564112896,
  "created_at" : "2017-02-21 18:06:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ADS",
      "screen_name" : "ADS_Update",
      "indices" : [ 7, 18 ],
      "id_str" : "1506671",
      "id" : 1506671
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/834099433323249665\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/XJSBnQi8ut",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C5NQ_PBW8AAxA_R.jpg",
      "id_str" : "834099403287883776",
      "id" : 834099403287883776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C5NQ_PBW8AAxA_R.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/XJSBnQi8ut"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139596992551, 8.753243380056082 ]
  },
  "id_str" : "834099433323249665",
  "text" : "Thanks @ADS_Update! Now I can dig some data! https:\/\/t.co\/XJSBnQi8ut",
  "id" : 834099433323249665,
  "created_at" : "2017-02-21 17:56:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 3, 11 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Broad Institute",
      "screen_name" : "broadinstitute",
      "indices" : [ 125, 140 ],
      "id_str" : "35306978",
      "id" : 35306978
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CRISPR",
      "indices" : [ 89, 96 ]
    }, {
      "text" : "JenniferDoudna",
      "indices" : [ 97, 112 ]
    }, {
      "text" : "EricLander",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/JThJ1c9iX9",
      "expanded_url" : "http:\/\/www.michaeleisen.org\/blog\/?p=1981",
      "display_url" : "michaeleisen.org\/blog\/?p=1981"
    } ]
  },
  "geo" : { },
  "id_str" : "834063826358263809",
  "text" : "RT @mbeisen: Patents are destroying the soul of academic science https:\/\/t.co\/JThJ1c9iX9 #CRISPR #JenniferDoudna #EricLander @broadinstitute",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Broad Institute",
        "screen_name" : "broadinstitute",
        "indices" : [ 112, 127 ],
        "id_str" : "35306978",
        "id" : 35306978
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CRISPR",
        "indices" : [ 76, 83 ]
      }, {
        "text" : "JenniferDoudna",
        "indices" : [ 84, 99 ]
      }, {
        "text" : "EricLander",
        "indices" : [ 100, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/JThJ1c9iX9",
        "expanded_url" : "http:\/\/www.michaeleisen.org\/blog\/?p=1981",
        "display_url" : "michaeleisen.org\/blog\/?p=1981"
      } ]
    },
    "geo" : { },
    "id_str" : "834037427295580161",
    "text" : "Patents are destroying the soul of academic science https:\/\/t.co\/JThJ1c9iX9 #CRISPR #JenniferDoudna #EricLander @broadinstitute",
    "id" : 834037427295580161,
    "created_at" : "2017-02-21 13:49:52 +0000",
    "user" : {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "protected" : false,
      "id_str" : "19843630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/893602583478239236\/Gkp75Fa5_normal.jpg",
      "id" : 19843630,
      "verified" : true
    }
  },
  "id" : 834063826358263809,
  "created_at" : "2017-02-21 15:34:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "indices" : [ 3, 11 ],
      "id_str" : "10328012",
      "id" : 10328012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/m0QyZtQqFU",
      "expanded_url" : "http:\/\/smallpondscience.com\/2017\/02\/20\/im-not-expecting-unreasonable-time-commitments-from-other-academics",
      "display_url" : "smallpondscience.com\/2017\/02\/20\/im-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "834019674874642433",
  "text" : "RT @hormiga: I\u2019m not expecting unreasonable time commitments from other\u00A0academics https:\/\/t.co\/m0QyZtQqFU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/m0QyZtQqFU",
        "expanded_url" : "http:\/\/smallpondscience.com\/2017\/02\/20\/im-not-expecting-unreasonable-time-commitments-from-other-academics",
        "display_url" : "smallpondscience.com\/2017\/02\/20\/im-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "833647921752969216",
    "text" : "I\u2019m not expecting unreasonable time commitments from other\u00A0academics https:\/\/t.co\/m0QyZtQqFU",
    "id" : 833647921752969216,
    "created_at" : "2017-02-20 12:02:07 +0000",
    "user" : {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "protected" : false,
      "id_str" : "10328012",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598149093337092096\/YArgwOG7_normal.jpg",
      "id" : 10328012,
      "verified" : true
    }
  },
  "id" : 834019674874642433,
  "created_at" : "2017-02-21 12:39:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/p51BVyt7oi",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/texans-flag-emoji-chile",
      "display_url" : "atlasobscura.com\/articles\/texan\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17242718684751, 8.627477662404985 ]
  },
  "id_str" : "833972674238017536",
  "text" : "When you\u2019re always getting the emoji flags wrong. \uD83C\uDDE8\uD83C\uDDF1 (c.f. \uD83C\uDDE8\uD83C\uDDFA\/\uD83C\uDDF5\uD83C\uDDF7) https:\/\/t.co\/p51BVyt7oi",
  "id" : 833972674238017536,
  "created_at" : "2017-02-21 09:32:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rhiannon Morris",
      "screen_name" : "RheeMor",
      "indices" : [ 3, 11 ],
      "id_str" : "187763403",
      "id" : 187763403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "833969798526668801",
  "text" : "RT @RheeMor: As an undergrad I used to think that all of the phd students knew what they were doing. Now that I'm a phd student I know that\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "833787740290289667",
    "text" : "As an undergrad I used to think that all of the phd students knew what they were doing. Now that I'm a phd student I know that's a lie.",
    "id" : 833787740290289667,
    "created_at" : "2017-02-20 21:17:42 +0000",
    "user" : {
      "name" : "Rhiannon Morris",
      "screen_name" : "RheeMor",
      "protected" : false,
      "id_str" : "187763403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/916475077989883904\/AISXzVpw_normal.jpg",
      "id" : 187763403,
      "verified" : false
    }
  },
  "id" : 833969798526668801,
  "created_at" : "2017-02-21 09:21:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Polka",
      "screen_name" : "jessicapolka",
      "indices" : [ 0, 13 ],
      "id_str" : "252204344",
      "id" : 252204344
    }, {
      "name" : "Adriana Bankston",
      "screen_name" : "AdrianaBankston",
      "indices" : [ 14, 30 ],
      "id_str" : "3077472948",
      "id" : 3077472948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "833954277798322176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724040871324, 8.627549075628394 ]
  },
  "id_str" : "833967964290502657",
  "in_reply_to_user_id" : 252204344,
  "text" : "@jessicapolka @AdrianaBankston not explicitly, but don\u2019t think I\u2019ve presented a single post-print in our regular journal club since ~2015.",
  "id" : 833967964290502657,
  "in_reply_to_status_id" : 833954277798322176,
  "created_at" : "2017-02-21 09:13:51 +0000",
  "in_reply_to_screen_name" : "jessicapolka",
  "in_reply_to_user_id_str" : "252204344",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/833799581649481728\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/RB6qzuPmiP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C5JATMgWQAEPsku.jpg",
      "id_str" : "833799579535556609",
      "id" : 833799579535556609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C5JATMgWQAEPsku.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 258
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 258
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 258
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 258
      } ],
      "display_url" : "pic.twitter.com\/RB6qzuPmiP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/DFOzRKuv8N",
      "expanded_url" : "http:\/\/amzn.eu\/fh80IgK",
      "display_url" : "amzn.eu\/fh80IgK"
    } ]
  },
  "geo" : { },
  "id_str" : "833799581649481728",
  "text" : "On the cosmopolites responsibilities https:\/\/t.co\/DFOzRKuv8N https:\/\/t.co\/RB6qzuPmiP",
  "id" : 833799581649481728,
  "created_at" : "2017-02-20 22:04:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/Xfk3kLZoYo",
      "expanded_url" : "http:\/\/www.xojane.com\/issues\/feminism-men-practical-steps",
      "display_url" : "xojane.com\/issues\/feminis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "833737241293893637",
  "text" : "RT @gedankenstuecke: 35 practical steps men can take to support feminism https:\/\/t.co\/Xfk3kLZoYo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/Xfk3kLZoYo",
        "expanded_url" : "http:\/\/www.xojane.com\/issues\/feminism-men-practical-steps",
        "display_url" : "xojane.com\/issues\/feminis\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.17234033670125, 8.627538949168576 ]
    },
    "id_str" : "833612226443505664",
    "text" : "35 practical steps men can take to support feminism https:\/\/t.co\/Xfk3kLZoYo",
    "id" : 833612226443505664,
    "created_at" : "2017-02-20 09:40:17 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 833737241293893637,
  "created_at" : "2017-02-20 17:57:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/Xfk3kLZoYo",
      "expanded_url" : "http:\/\/www.xojane.com\/issues\/feminism-men-practical-steps",
      "display_url" : "xojane.com\/issues\/feminis\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234033670125, 8.627538949168576 ]
  },
  "id_str" : "833612226443505664",
  "text" : "35 practical steps men can take to support feminism https:\/\/t.co\/Xfk3kLZoYo",
  "id" : 833612226443505664,
  "created_at" : "2017-02-20 09:40:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva",
      "screen_name" : "evacide",
      "indices" : [ 3, 11 ],
      "id_str" : "14707266",
      "id" : 14707266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "833454335585562628",
  "text" : "RT @evacide: Everything about Susan Fowler's account of what it was like to be a female engineer at Uber is terrible. https:\/\/t.co\/bcqVikxO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/bcqVikxOzu",
        "expanded_url" : "https:\/\/www.susanjfowler.com\/blog\/2017\/2\/19\/reflecting-on-one-very-strange-year-at-uber",
        "display_url" : "susanjfowler.com\/blog\/2017\/2\/19\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "833443473852420096",
    "text" : "Everything about Susan Fowler's account of what it was like to be a female engineer at Uber is terrible. https:\/\/t.co\/bcqVikxOzu",
    "id" : 833443473852420096,
    "created_at" : "2017-02-19 22:29:43 +0000",
    "user" : {
      "name" : "Eva",
      "screen_name" : "evacide",
      "protected" : false,
      "id_str" : "14707266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706982492855664640\/Ly2iiCAh_normal.jpg",
      "id" : 14707266,
      "verified" : true
    }
  },
  "id" : 833454335585562628,
  "created_at" : "2017-02-19 23:12:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "833448825985589249",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405321925682, 8.753405119816106 ]
  },
  "id_str" : "833449991838560257",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 get some good rest!",
  "id" : 833449991838560257,
  "in_reply_to_status_id" : 833448825985589249,
  "created_at" : "2017-02-19 22:55:37 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "833448376284880898",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388993449523, 8.753456858909825 ]
  },
  "id_str" : "833448569403219968",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 you ruined the setup for another \uD83C\uDDE8\uD83C\uDDED-joke there! :p",
  "id" : 833448569403219968,
  "in_reply_to_status_id" : 833448376284880898,
  "created_at" : "2017-02-19 22:49:58 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "833443309934764032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388993449523, 8.753456858909825 ]
  },
  "id_str" : "833448207657160708",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 I\u2019d consider that well done!",
  "id" : 833448207657160708,
  "in_reply_to_status_id" : 833443309934764032,
  "created_at" : "2017-02-19 22:48:32 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "833441570619793410",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140674797811, 8.753418142313597 ]
  },
  "id_str" : "833442699378360324",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo can\u2019t wait for it! \uD83D\uDE0D",
  "id" : 833442699378360324,
  "in_reply_to_status_id" : 833441570619793410,
  "created_at" : "2017-02-19 22:26:38 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 3, 15 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/EulYhS2Bj6",
      "expanded_url" : "https:\/\/twitter.com\/ThePurplePage\/status\/833356802846765056",
      "display_url" : "twitter.com\/ThePurplePage\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "833401794902503424",
  "text" : "RT @jonfwilkins: Thread https:\/\/t.co\/EulYhS2Bj6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 7, 30 ],
        "url" : "https:\/\/t.co\/EulYhS2Bj6",
        "expanded_url" : "https:\/\/twitter.com\/ThePurplePage\/status\/833356802846765056",
        "display_url" : "twitter.com\/ThePurplePage\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "833399864557989889",
    "text" : "Thread https:\/\/t.co\/EulYhS2Bj6",
    "id" : 833399864557989889,
    "created_at" : "2017-02-19 19:36:26 +0000",
    "user" : {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "protected" : false,
      "id_str" : "214099847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1279449740\/Dev2DEC_normal.jpg",
      "id" : 214099847,
      "verified" : false
    }
  },
  "id" : 833401794902503424,
  "created_at" : "2017-02-19 19:44:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "indices" : [ 60, 76 ],
      "id_str" : "17462723",
      "id" : 17462723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405308168103, 8.753404703025293 ]
  },
  "id_str" : "833377799029260288",
  "text" : "Super excited, can\u2019t wait to meet so many commoners! Thanks @creativecommons for helping w\/ a scholarship to attend the Global Summit! \uD83D\uDC96\uD83C\uDF89\uD83C\uDF88\uD83C\uDF8A",
  "id" : 833377799029260288,
  "created_at" : "2017-02-19 18:08:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/esSGpyuYRX",
      "expanded_url" : "https:\/\/www.theguardian.com\/lifeandstyle\/2017\/feb\/19\/women-and-desire-the-six-ages-of-sex?CMP=Share_iOSApp_Other",
      "display_url" : "theguardian.com\/lifeandstyle\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "833312266648969216",
  "text" : "The six ages of sex https:\/\/t.co\/esSGpyuYRX",
  "id" : 833312266648969216,
  "created_at" : "2017-02-19 13:48:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "833288763598069761",
  "text" : "RT @gedankenstuecke: \u00ABOf course queer people go to pet heaven. How could they miss out on the rainbow bridge?!\u00BB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.060846325988, 8.818565122791396 ]
    },
    "id_str" : "833084309682737153",
    "text" : "\u00ABOf course queer people go to pet heaven. How could they miss out on the rainbow bridge?!\u00BB",
    "id" : 833084309682737153,
    "created_at" : "2017-02-18 22:42:32 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 833288763598069761,
  "created_at" : "2017-02-19 12:14:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.060846325988, 8.818565122791396 ]
  },
  "id_str" : "833084309682737153",
  "text" : "\u00ABOf course queer people go to pet heaven. How could they miss out on the rainbow bridge?!\u00BB",
  "id" : 833084309682737153,
  "created_at" : "2017-02-18 22:42:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "833056409172455424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06113246768179, 8.818255260319495 ]
  },
  "id_str" : "833084096813395968",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye interesting!",
  "id" : 833084096813395968,
  "in_reply_to_status_id" : 833056409172455424,
  "created_at" : "2017-02-18 22:41:41 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/ReVaHiid0P",
      "expanded_url" : "https:\/\/twitter.com\/eramirez\/status\/832667616929984512",
      "display_url" : "twitter.com\/eramirez\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406387795924, 8.75341580674677 ]
  },
  "id_str" : "832678694015496192",
  "text" : "That\u2019s an amazing project: disperse just the right amount of skittles to boost your blood sugar to the target levels! https:\/\/t.co\/ReVaHiid0P",
  "id" : 832678694015496192,
  "created_at" : "2017-02-17 19:50:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erich M. Schwarz",
      "screen_name" : "ErichMSchwarz",
      "indices" : [ 3, 17 ],
      "id_str" : "585949808",
      "id" : 585949808
    }, {
      "name" : "Blast2GO",
      "screen_name" : "blast2go",
      "indices" : [ 59, 68 ],
      "id_str" : "74696035",
      "id" : 74696035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "832656195164868608",
  "text" : "RT @ErichMSchwarz: Is there an open-source replacement for @blast2go? I need one. Or, at least, I need a way to get a evaluation license th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Blast2GO",
        "screen_name" : "blast2go",
        "indices" : [ 40, 49 ],
        "id_str" : "74696035",
        "id" : 74696035
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "832654312421494786",
    "text" : "Is there an open-source replacement for @blast2go? I need one. Or, at least, I need a way to get a evaluation license that actually works.",
    "id" : 832654312421494786,
    "created_at" : "2017-02-17 18:13:52 +0000",
    "user" : {
      "name" : "Erich M. Schwarz",
      "screen_name" : "ErichMSchwarz",
      "protected" : false,
      "id_str" : "585949808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550011861408567297\/ayERqhWs_normal.jpeg",
      "id" : 585949808,
      "verified" : false
    }
  },
  "id" : 832656195164868608,
  "created_at" : "2017-02-17 18:21:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Hagi",
      "screen_name" : "geekylonglegs",
      "indices" : [ 3, 17 ],
      "id_str" : "600679694",
      "id" : 600679694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/udOEve4h9r",
      "expanded_url" : "https:\/\/broadly.vice.com\/en_us\/article\/i-went-to-a-pro-islamophobia-rally-hosted-by-canadas-breitbart-in-my-hijab",
      "display_url" : "broadly.vice.com\/en_us\/article\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832637129565970434",
  "text" : "RT @geekylonglegs: I went to a rally for people who were defending their right to hate, this was my experience. https:\/\/t.co\/udOEve4h9r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/udOEve4h9r",
        "expanded_url" : "https:\/\/broadly.vice.com\/en_us\/article\/i-went-to-a-pro-islamophobia-rally-hosted-by-canadas-breitbart-in-my-hijab",
        "display_url" : "broadly.vice.com\/en_us\/article\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "832630522295693318",
    "text" : "I went to a rally for people who were defending their right to hate, this was my experience. https:\/\/t.co\/udOEve4h9r",
    "id" : 832630522295693318,
    "created_at" : "2017-02-17 16:39:20 +0000",
    "user" : {
      "name" : "Sarah Hagi",
      "screen_name" : "geekylonglegs",
      "protected" : false,
      "id_str" : "600679694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/919744120213704704\/JCxK89yA_normal.jpg",
      "id" : 600679694,
      "verified" : true
    }
  },
  "id" : 832637129565970434,
  "created_at" : "2017-02-17 17:05:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Kelsall",
      "screen_name" : "Stonelaughter",
      "indices" : [ 0, 14 ],
      "id_str" : "151618050",
      "id" : 151618050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "832633166846271491",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11039477312016, 8.760355571293049 ]
  },
  "id_str" : "832634727454568448",
  "in_reply_to_user_id" : 151618050,
  "text" : "@Stonelaughter fair point, maybe should have gone for \u201Cpagan rituals\u201D. :)",
  "id" : 832634727454568448,
  "in_reply_to_status_id" : 832633166846271491,
  "created_at" : "2017-02-17 16:56:03 +0000",
  "in_reply_to_screen_name" : "Stonelaughter",
  "in_reply_to_user_id_str" : "151618050",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Kelsall",
      "screen_name" : "Stonelaughter",
      "indices" : [ 0, 14 ],
      "id_str" : "151618050",
      "id" : 151618050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "832593636747517952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406491764419, 8.753417646068803 ]
  },
  "id_str" : "832631450855940097",
  "in_reply_to_user_id" : 151618050,
  "text" : "@Stonelaughter maybe because it\u2019s (amongst many other things)  also featured in the copyrighted logo of the CoS? :p",
  "id" : 832631450855940097,
  "in_reply_to_status_id" : 832593636747517952,
  "created_at" : "2017-02-17 16:43:02 +0000",
  "in_reply_to_screen_name" : "Stonelaughter",
  "in_reply_to_user_id_str" : "151618050",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "832625105876381704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401296787312, 8.753350571326393 ]
  },
  "id_str" : "832627558256480256",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick and for good measure even both of them.",
  "id" : 832627558256480256,
  "in_reply_to_status_id" : 832625105876381704,
  "created_at" : "2017-02-17 16:27:34 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "londonyc #FBPE #Mutineer",
      "screen_name" : "londonyc",
      "indices" : [ 3, 12 ],
      "id_str" : "19441006",
      "id" : 19441006
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SquashedBox\/status\/829788674804039680\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/jaTYXfdD56",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C4P_8XWWQAMDiNH.jpg",
      "id_str" : "829788168891285507",
      "id" : 829788168891285507,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C4P_8XWWQAMDiNH.jpg",
      "sizes" : [ {
        "h" : 272,
        "resize" : "fit",
        "w" : 333
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 333
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 333
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 333
      } ],
      "display_url" : "pic.twitter.com\/jaTYXfdD56"
    } ],
    "hashtags" : [ {
      "text" : "Remain",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/uprsNWSrBl",
      "expanded_url" : "http:\/\/choosefreedom.eu\/index.htm",
      "display_url" : "choosefreedom.eu\/index.htm"
    } ]
  },
  "geo" : { },
  "id_str" : "832520945160089601",
  "text" : "RT @londonyc: Claim your European citizenship - the official vote starts. RT! https:\/\/t.co\/jaTYXfdD56 https:\/\/t.co\/uprsNWSrBl\n\n#Remain",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SquashedBox\/status\/829788674804039680\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/jaTYXfdD56",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C4P_8XWWQAMDiNH.jpg",
        "id_str" : "829788168891285507",
        "id" : 829788168891285507,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C4P_8XWWQAMDiNH.jpg",
        "sizes" : [ {
          "h" : 272,
          "resize" : "fit",
          "w" : 333
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 333
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 333
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 333
        } ],
        "display_url" : "pic.twitter.com\/jaTYXfdD56"
      } ],
      "hashtags" : [ {
        "text" : "Remain",
        "indices" : [ 113, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/uprsNWSrBl",
        "expanded_url" : "http:\/\/choosefreedom.eu\/index.htm",
        "display_url" : "choosefreedom.eu\/index.htm"
      } ]
    },
    "geo" : { },
    "id_str" : "832231044732563456",
    "text" : "Claim your European citizenship - the official vote starts. RT! https:\/\/t.co\/jaTYXfdD56 https:\/\/t.co\/uprsNWSrBl\n\n#Remain",
    "id" : 832231044732563456,
    "created_at" : "2017-02-16 14:11:57 +0000",
    "user" : {
      "name" : "londonyc #FBPE #Mutineer",
      "screen_name" : "londonyc",
      "protected" : false,
      "id_str" : "19441006",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/73293931\/ldnnyc_logo_normal.jpg",
      "id" : 19441006,
      "verified" : false
    }
  },
  "id" : 832520945160089601,
  "created_at" : "2017-02-17 09:23:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian",
      "screen_name" : "glialfire",
      "indices" : [ 0, 10 ],
      "id_str" : "50975173",
      "id" : 50975173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "832507099859009536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237449900949, 8.627521881937248 ]
  },
  "id_str" : "832507190275670016",
  "in_reply_to_user_id" : 50975173,
  "text" : "@glialfire good to hear that I\u2019m not the only one! :D",
  "id" : 832507190275670016,
  "in_reply_to_status_id" : 832507099859009536,
  "created_at" : "2017-02-17 08:29:16 +0000",
  "in_reply_to_screen_name" : "glialfire",
  "in_reply_to_user_id_str" : "50975173",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/v2JisZ0fBT",
      "expanded_url" : "https:\/\/twitter.com\/barricklab\/status\/832004186954932224",
      "display_url" : "twitter.com\/barricklab\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832506872699744256",
  "text" : "RT @gedankenstuecke: I didn\u2019t know you had to perform satanic rituals to get E. coli to undergo genome evolution. https:\/\/t.co\/v2JisZ0fBT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/v2JisZ0fBT",
        "expanded_url" : "https:\/\/twitter.com\/barricklab\/status\/832004186954932224",
        "display_url" : "twitter.com\/barricklab\/sta\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.11402029487388, 8.753352037987211 ]
    },
    "id_str" : "832310767357657088",
    "text" : "I didn\u2019t know you had to perform satanic rituals to get E. coli to undergo genome evolution. https:\/\/t.co\/v2JisZ0fBT",
    "id" : 832310767357657088,
    "created_at" : "2017-02-16 19:28:45 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 832506872699744256,
  "created_at" : "2017-02-17 08:28:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/fMFhiCgxUD",
      "expanded_url" : "https:\/\/twitter.com\/arvestad\/status\/832499370276839424",
      "display_url" : "twitter.com\/arvestad\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236318557494, 8.627520692324019 ]
  },
  "id_str" : "832506764172095489",
  "text" : "The main reason why my name + \u201CUni Frankfurt\u201D is the search term I google most often: to find my office address. https:\/\/t.co\/fMFhiCgxUD",
  "id" : 832506764172095489,
  "created_at" : "2017-02-17 08:27:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karsten Borgwardt",
      "screen_name" : "kmborgwardt",
      "indices" : [ 3, 15 ],
      "id_str" : "1545546103",
      "id" : 1545546103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "832498853362429954",
  "text" : "RT @kmborgwardt: Join my lab at ETH Z\u00FCrich @ Basel as postdoc in Machine Learning or Bioinformatics: Deadline March 31. Please RT. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/uUOxkpjXpJ",
        "expanded_url" : "https:\/\/apply.refline.ch\/845721\/5186\/pub\/1\/index.html",
        "display_url" : "apply.refline.ch\/845721\/5186\/pu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "832354097407913984",
    "text" : "Join my lab at ETH Z\u00FCrich @ Basel as postdoc in Machine Learning or Bioinformatics: Deadline March 31. Please RT. https:\/\/t.co\/uUOxkpjXpJ",
    "id" : 832354097407913984,
    "created_at" : "2017-02-16 22:20:55 +0000",
    "user" : {
      "name" : "Karsten Borgwardt",
      "screen_name" : "kmborgwardt",
      "protected" : false,
      "id_str" : "1545546103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/849569935948992512\/XmRJsjb3_normal.jpg",
      "id" : 1545546103,
      "verified" : false
    }
  },
  "id" : 832498853362429954,
  "created_at" : "2017-02-17 07:56:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "832352399427723266",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11352761467179, 8.754025185034845 ]
  },
  "id_str" : "832492680739450880",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy that actually sounds cool!",
  "id" : 832492680739450880,
  "in_reply_to_status_id" : 832352399427723266,
  "created_at" : "2017-02-17 07:31:36 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "832358175932284929",
  "text" : "RT @bella_velo: If I was a grant manager I would fund travel. All the travel. It unlocks everything and allows for new voices &amp; ideas https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 145 ],
        "url" : "https:\/\/t.co\/Q811LGfrSV",
        "expanded_url" : "https:\/\/twitter.com\/nshockey\/status\/832209082866077696",
        "display_url" : "twitter.com\/nshockey\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "832347502401691648",
    "text" : "If I was a grant manager I would fund travel. All the travel. It unlocks everything and allows for new voices &amp; ideas https:\/\/t.co\/Q811LGfrSV",
    "id" : 832347502401691648,
    "created_at" : "2017-02-16 21:54:43 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 832358175932284929,
  "created_at" : "2017-02-16 22:37:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Becca\uD83D\uDD2C\uD83E\uDD8E",
      "screen_name" : "sciliz",
      "indices" : [ 0, 7 ],
      "id_str" : "106203272",
      "id" : 106203272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "832332452601462784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407409139482, 8.753339073232686 ]
  },
  "id_str" : "832334083636215809",
  "in_reply_to_user_id" : 106203272,
  "text" : "@sciliz \uD83D\uDE02",
  "id" : 832334083636215809,
  "in_reply_to_status_id" : 832332452601462784,
  "created_at" : "2017-02-16 21:01:24 +0000",
  "in_reply_to_screen_name" : "sciliz",
  "in_reply_to_user_id_str" : "106203272",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "832317663921786883",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406709788359, 8.753417919770644 ]
  },
  "id_str" : "832317707202727936",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 awesome!",
  "id" : 832317707202727936,
  "in_reply_to_status_id" : 832317663921786883,
  "created_at" : "2017-02-16 19:56:19 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "832316181679919106",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406720871015, 8.753417788575272 ]
  },
  "id_str" : "832317087976718338",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 how did your data analysis go? :p",
  "id" : 832317087976718338,
  "in_reply_to_status_id" : 832316181679919106,
  "created_at" : "2017-02-16 19:53:52 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "832313162309500929",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412187635786, 8.753313940856447 ]
  },
  "id_str" : "832313941044953092",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara when I did my first ones in 2005 it was the same. Make a pentagram out of pipette tips around the cycler.",
  "id" : 832313941044953092,
  "in_reply_to_status_id" : 832313162309500929,
  "created_at" : "2017-02-16 19:41:21 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/v2JisZ0fBT",
      "expanded_url" : "https:\/\/twitter.com\/barricklab\/status\/832004186954932224",
      "display_url" : "twitter.com\/barricklab\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402029487388, 8.753352037987211 ]
  },
  "id_str" : "832310767357657088",
  "text" : "I didn\u2019t know you had to perform satanic rituals to get E. coli to undergo genome evolution. https:\/\/t.co\/v2JisZ0fBT",
  "id" : 832310767357657088,
  "created_at" : "2017-02-16 19:28:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/Ev9P4ZJDif",
      "expanded_url" : "https:\/\/twitter.com\/cshperspectives\/status\/832286560246603776",
      "display_url" : "twitter.com\/cshperspective\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406673572456, 8.753417763130939 ]
  },
  "id_str" : "832309396533346310",
  "text" : "Bet you he isn\u2019t. https:\/\/t.co\/Ev9P4ZJDif",
  "id" : 832309396533346310,
  "created_at" : "2017-02-16 19:23:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Hahn",
      "screen_name" : "3rdreviewer",
      "indices" : [ 3, 15 ],
      "id_str" : "2678236062",
      "id" : 2678236062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "832302612540190721",
  "text" : "RT @3rdreviewer: \"83% of female scientists and 54% of male scientists in academic couples had another scientist as a partner.\" https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/8R4rBUgXnk",
        "expanded_url" : "http:\/\/www.nature.com\/nature\/journal\/v542\/n7640\/full\/nj7640-261a.html",
        "display_url" : "nature.com\/nature\/journal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "830226499886268416",
    "text" : "\"83% of female scientists and 54% of male scientists in academic couples had another scientist as a partner.\" https:\/\/t.co\/8R4rBUgXnk 1\/n",
    "id" : 830226499886268416,
    "created_at" : "2017-02-11 01:26:37 +0000",
    "user" : {
      "name" : "Matthew Hahn",
      "screen_name" : "3rdreviewer",
      "protected" : false,
      "id_str" : "2678236062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/492467467474583552\/eZiwdLds_normal.png",
      "id" : 2678236062,
      "verified" : false
    }
  },
  "id" : 832302612540190721,
  "created_at" : "2017-02-16 18:56:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WeRateDogs\u2122",
      "screen_name" : "dog_rates",
      "indices" : [ 100, 110 ],
      "id_str" : "4196983835",
      "id" : 4196983835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/T2JvdxcBkZ",
      "expanded_url" : "http:\/\/ruleofthirds.de\/they-are-good-dogs-indeed\/",
      "display_url" : "ruleofthirds.de\/they-are-good-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406929505456, 8.75341228810883 ]
  },
  "id_str" : "832274382441611264",
  "text" : "For the US crowd: How dogs are always getting cuter &amp; why barkificial intelligence doesn\u2019t beat @dog_rates yet. \uD83D\uDC36\uD83D\uDCCA https:\/\/t.co\/T2JvdxcBkZ",
  "id" : 832274382441611264,
  "created_at" : "2017-02-16 17:04:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Williams",
      "screen_name" : "harrywilliamsmx",
      "indices" : [ 0, 16 ],
      "id_str" : "864720030",
      "id" : 864720030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "832260876891717634",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.14615042139789, 8.70366314426875 ]
  },
  "id_str" : "832263341993254912",
  "in_reply_to_user_id" : 864720030,
  "text" : "@harrywilliamsmx thanks!",
  "id" : 832263341993254912,
  "in_reply_to_status_id" : 832260876891717634,
  "created_at" : "2017-02-16 16:20:18 +0000",
  "in_reply_to_screen_name" : "harrywilliamsmx",
  "in_reply_to_user_id_str" : "864720030",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Chris Pawley",
      "screen_name" : "cpawley",
      "indices" : [ 3, 11 ],
      "id_str" : "6061612",
      "id" : 6061612
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 52, 68 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Harry Williams",
      "screen_name" : "harrywilliamsmx",
      "indices" : [ 119, 135 ],
      "id_str" : "864720030",
      "id" : 864720030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/kr8OJbiA1j",
      "expanded_url" : "http:\/\/ruleofthirds.de\/they-are-good-dogs-indeed\/",
      "display_url" : "ruleofthirds.de\/they-are-good-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "832258472750235648",
  "text" : "RT @cpawley: Like dogs but love data too? Check out @gedankenstuecke 's post about doggy data https:\/\/t.co\/kr8OJbiA1j (@harrywilliamsmx - c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 39, 55 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Harry Williams",
        "screen_name" : "harrywilliamsmx",
        "indices" : [ 106, 122 ],
        "id_str" : "864720030",
        "id" : 864720030
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/kr8OJbiA1j",
        "expanded_url" : "http:\/\/ruleofthirds.de\/they-are-good-dogs-indeed\/",
        "display_url" : "ruleofthirds.de\/they-are-good-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "832250400589881344",
    "text" : "Like dogs but love data too? Check out @gedankenstuecke 's post about doggy data https:\/\/t.co\/kr8OJbiA1j (@harrywilliamsmx - check it out!)",
    "id" : 832250400589881344,
    "created_at" : "2017-02-16 15:28:52 +0000",
    "user" : {
      "name" : "Dr Chris Pawley",
      "screen_name" : "cpawley",
      "protected" : false,
      "id_str" : "6061612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/105240745\/chrisjoker_normal.jpg",
      "id" : 6061612,
      "verified" : false
    }
  },
  "id" : 832258472750235648,
  "created_at" : "2017-02-16 16:00:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "832230280727404544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239135885426, 8.627507935853108 ]
  },
  "id_str" : "832230641303425025",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I saw on GH you\u2019re doing some ML stuff right now as well!",
  "id" : 832230641303425025,
  "in_reply_to_status_id" : 832230280727404544,
  "created_at" : "2017-02-16 14:10:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WeRateDogs\u2122",
      "screen_name" : "dog_rates",
      "indices" : [ 96, 106 ],
      "id_str" : "4196983835",
      "id" : 4196983835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/T2JvdxcBkZ",
      "expanded_url" : "http:\/\/ruleofthirds.de\/they-are-good-dogs-indeed\/",
      "display_url" : "ruleofthirds.de\/they-are-good-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235247360156, 8.627552894390872 ]
  },
  "id_str" : "832225710110552064",
  "text" : "New analysis: How dogs are always getting cuter &amp; why barkificial intelligence doesn\u2019t beat @dog_rates yet. \uD83D\uDC36\uD83D\uDCCA https:\/\/t.co\/T2JvdxcBkZ",
  "id" : 832225710110552064,
  "created_at" : "2017-02-16 13:50:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erick R Scott",
      "screen_name" : "ErickRScott",
      "indices" : [ 0, 12 ],
      "id_str" : "512234952",
      "id" : 512234952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "832009823038369793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406770703199, 8.753410967195926 ]
  },
  "id_str" : "832010625798828032",
  "in_reply_to_user_id" : 512234952,
  "text" : "@ErickRScott always great to see when people use the data to teach the next generation!",
  "id" : 832010625798828032,
  "in_reply_to_status_id" : 832009823038369793,
  "created_at" : "2017-02-15 23:36:05 +0000",
  "in_reply_to_screen_name" : "ErickRScott",
  "in_reply_to_user_id_str" : "512234952",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erick R Scott",
      "screen_name" : "ErickRScott",
      "indices" : [ 0, 12 ],
      "id_str" : "512234952",
      "id" : 512234952
    }, {
      "name" : "Mete Civelek",
      "screen_name" : "mete_civelek",
      "indices" : [ 13, 26 ],
      "id_str" : "1062149982",
      "id" : 1062149982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "831660921378467841",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398236173934, 8.753603134668854 ]
  },
  "id_str" : "832009446008176640",
  "in_reply_to_user_id" : 512234952,
  "text" : "@ErickRScott @mete_civelek and we\u2019re happy to help out if you need any help with it :)",
  "id" : 832009446008176640,
  "in_reply_to_status_id" : 831660921378467841,
  "created_at" : "2017-02-15 23:31:24 +0000",
  "in_reply_to_screen_name" : "ErickRScott",
  "in_reply_to_user_id_str" : "512234952",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avery Edison",
      "screen_name" : "aedison",
      "indices" : [ 3, 11 ],
      "id_str" : "1471021",
      "id" : 1471021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "831986043234697217",
  "text" : "RT @aedison: I\u2019m hearing this meme that there\u2019s no biological basis for gender.\n\nGuys. It\u2019s time for some gamete theory. (1\/445)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "831981921567531008",
    "text" : "I\u2019m hearing this meme that there\u2019s no biological basis for gender.\n\nGuys. It\u2019s time for some gamete theory. (1\/445)",
    "id" : 831981921567531008,
    "created_at" : "2017-02-15 21:42:02 +0000",
    "user" : {
      "name" : "Avery Edison",
      "screen_name" : "aedison",
      "protected" : false,
      "id_str" : "1471021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920321005834424320\/ZyzhQo-7_normal.jpg",
      "id" : 1471021,
      "verified" : true
    }
  },
  "id" : 831986043234697217,
  "created_at" : "2017-02-15 21:58:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    }, {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 9, 20 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "831984969857822720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393856011897, 8.753696890571979 ]
  },
  "id_str" : "831985190734004224",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon @kathakatze \uD83D\uDE0D",
  "id" : 831985190734004224,
  "in_reply_to_status_id" : 831984969857822720,
  "created_at" : "2017-02-15 21:55:01 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/USEkzRMQ7v",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=FKdu01LqXdI",
      "display_url" : "youtube.com\/watch?v=FKdu01\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "831973706842923017",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406950803083, 8.753412492772192 ]
  },
  "id_str" : "831983692696395777",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze Zeit an den Hammer zu erinnern. https:\/\/t.co\/USEkzRMQ7v :P",
  "id" : 831983692696395777,
  "in_reply_to_status_id" : 831973706842923017,
  "created_at" : "2017-02-15 21:49:04 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/EChfwK44uh",
      "expanded_url" : "https:\/\/twitter.com\/DoctorZen\/status\/831946171413364737",
      "display_url" : "twitter.com\/DoctorZen\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10750527963983, 8.769861739136996 ]
  },
  "id_str" : "831947050954665986",
  "text" : "Time to retire the chalk talk and call it board walk? https:\/\/t.co\/EChfwK44uh",
  "id" : 831947050954665986,
  "created_at" : "2017-02-15 19:23:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/B44on1eiyI",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/insideout\/east\/series10\/week9_aerial_spraying.shtml",
      "display_url" : "bbc.co.uk\/insideout\/east\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "831928583564251143",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406951217103, 8.75341249509206 ]
  },
  "id_str" : "831930161847291909",
  "in_reply_to_user_id" : 14286491,
  "text" : "Spraying Norwich with zinc cadmium sulphide from a plane? Totally apolitical. https:\/\/t.co\/B44on1eiyI  \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 831930161847291909,
  "in_reply_to_status_id" : 831928583564251143,
  "created_at" : "2017-02-15 18:16:21 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/EU0DInaRrF",
      "expanded_url" : "http:\/\/www.nytimes.com\/1995\/03\/23\/opinion\/it-can-happen-here-and-did.html",
      "display_url" : "nytimes.com\/1995\/03\/23\/opi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "831928583564251143",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406969794406, 8.753412658566914 ]
  },
  "id_str" : "831929183148396554",
  "in_reply_to_user_id" : 14286491,
  "text" : "Don\u2019t worry my American friends, for good measure the army did to the basically same thing in the NYC subway system. https:\/\/t.co\/EU0DInaRrF",
  "id" : 831929183148396554,
  "in_reply_to_status_id" : 831928583564251143,
  "created_at" : "2017-02-15 18:12:28 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/dkjeSJNVbI",
      "expanded_url" : "https:\/\/www.theguardian.com\/politics\/2002\/apr\/21\/uk.medicalscience",
      "display_url" : "theguardian.com\/politics\/2002\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "831928583564251143",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406969794406, 8.753412658566914 ]
  },
  "id_str" : "831928947181047819",
  "in_reply_to_user_id" : 14286491,
  "text" : "Because, why wouldn\u2019t you just let some bacteria loose in the London Underground? https:\/\/t.co\/dkjeSJNVbI",
  "id" : 831928947181047819,
  "in_reply_to_status_id" : 831928583564251143,
  "created_at" : "2017-02-15 18:11:32 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/6FCeyehnZN",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/24737915-secret-science",
      "display_url" : "goodreads.com\/book\/show\/2473\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140670321173, 8.753415046046154 ]
  },
  "id_str" : "831928583564251143",
  "text" : "At a time where people are screaming \u00ABScience is apolitical\u00BB reading \u00ABSecret Science\u00BB seems fitting. https:\/\/t.co\/6FCeyehnZN",
  "id" : 831928583564251143,
  "created_at" : "2017-02-15 18:10:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "831907655958528000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406500894454, 8.753418010627206 ]
  },
  "id_str" : "831907950373515264",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 aye, get yourself some of that long read magic! \uD83D\uDC96",
  "id" : 831907950373515264,
  "in_reply_to_status_id" : 831907655958528000,
  "created_at" : "2017-02-15 16:48:06 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "831906833216450560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406130399183, 8.753422019553124 ]
  },
  "id_str" : "831907366606082049",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 in most cases it does :D",
  "id" : 831907366606082049,
  "in_reply_to_status_id" : 831906833216450560,
  "created_at" : "2017-02-15 16:45:46 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "831905398735122432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401172859591, 8.753349944418533 ]
  },
  "id_str" : "831906064396386305",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 cool! Have fun with it. And looking forward to see those results :)",
  "id" : 831906064396386305,
  "in_reply_to_status_id" : 831905398735122432,
  "created_at" : "2017-02-15 16:40:36 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 3, 12 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "David Golumbia",
      "screen_name" : "dgolumbia",
      "indices" : [ 111, 121 ],
      "id_str" : "14304930",
      "id" : 14304930
    }, {
      "name" : "David Carroll\uD83E\uDD85",
      "screen_name" : "profcarroll",
      "indices" : [ 122, 134 ],
      "id_str" : "15384720",
      "id" : 15384720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "831904867887247361",
  "text" : "RT @podehaye: I will directly pay for 1st ten people who reply to this message. (DMs to confirm afterwards) cc @dgolumbia @profcarroll @Jul\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Golumbia",
        "screen_name" : "dgolumbia",
        "indices" : [ 97, 107 ],
        "id_str" : "14304930",
        "id" : 14304930
      }, {
        "name" : "David Carroll\uD83E\uDD85",
        "screen_name" : "profcarroll",
        "indices" : [ 108, 120 ],
        "id_str" : "15384720",
        "id" : 15384720
      }, {
        "name" : "Jules Polonetsky",
        "screen_name" : "JulesPolonetsky",
        "indices" : [ 121, 137 ],
        "id_str" : "8919762",
        "id" : 8919762
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/iuf5HJYKGU",
        "expanded_url" : "https:\/\/twitter.com\/dgolumbia\/status\/831872145575784450",
        "display_url" : "twitter.com\/dgolumbia\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "831872497565974528",
    "text" : "I will directly pay for 1st ten people who reply to this message. (DMs to confirm afterwards) cc @dgolumbia @profcarroll @JulesPolonetsky https:\/\/t.co\/iuf5HJYKGU",
    "id" : 831872497565974528,
    "created_at" : "2017-02-15 14:27:13 +0000",
    "user" : {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "protected" : false,
      "id_str" : "2219841242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/840965162349797376\/7hdkcm04_normal.jpg",
      "id" : 2219841242,
      "verified" : false
    }
  },
  "id" : 831904867887247361,
  "created_at" : "2017-02-15 16:35:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "831904781794889728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397706605242, 8.753615037590524 ]
  },
  "id_str" : "831904828670537728",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye oh, okay. All the best!",
  "id" : 831904828670537728,
  "in_reply_to_status_id" : 831904781794889728,
  "created_at" : "2017-02-15 16:35:41 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/831903601610129408\/photo\/1",
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/7e17oCIJuu",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C4uD5pcWMAAHUxN.jpg",
      "id_str" : "831903582580518912",
      "id" : 831903582580518912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C4uD5pcWMAAHUxN.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/7e17oCIJuu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "831903253982019584",
  "geo" : { },
  "id_str" : "831903601610129408",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 good call! https:\/\/t.co\/7e17oCIJuu",
  "id" : 831903601610129408,
  "in_reply_to_status_id" : 831903253982019584,
  "created_at" : "2017-02-15 16:30:49 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "831898762830282752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406949251844, 8.753372006223106 ]
  },
  "id_str" : "831902887051685889",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 and better do some multiple testing correction on those p values :p",
  "id" : 831902887051685889,
  "in_reply_to_status_id" : 831898762830282752,
  "created_at" : "2017-02-15 16:27:58 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "831872497565974528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406617534534, 8.75341693456323 ]
  },
  "id_str" : "831902495521832961",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye still looking for people?",
  "id" : 831902495521832961,
  "in_reply_to_status_id" : 831872497565974528,
  "created_at" : "2017-02-15 16:26:25 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "good erin",
      "screen_name" : "eehouls",
      "indices" : [ 3, 11 ],
      "id_str" : "13399892",
      "id" : 13399892
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/eehouls\/status\/831888090901970945\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/Q1vryGUWIk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C4t1xd4XUAAGqMs.jpg",
      "id_str" : "831888048875065344",
      "id" : 831888048875065344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C4t1xd4XUAAGqMs.jpg",
      "sizes" : [ {
        "h" : 120,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 1250
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 1250
      }, {
        "h" : 211,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/Q1vryGUWIk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/EeASZFhRqN",
      "expanded_url" : "https:\/\/mobile.nytimes.com\/2017\/02\/14\/opinion\/an-eminent-psychiatrist-demurs-on-trumps-mental-state.html?_r=0&referer=",
      "display_url" : "mobile.nytimes.com\/2017\/02\/14\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831892958991486979",
  "text" : "RT @eehouls: thank yoooouuuuuuuuu \n\nhttps:\/\/t.co\/EeASZFhRqN https:\/\/t.co\/Q1vryGUWIk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/eehouls\/status\/831888090901970945\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/Q1vryGUWIk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C4t1xd4XUAAGqMs.jpg",
        "id_str" : "831888048875065344",
        "id" : 831888048875065344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C4t1xd4XUAAGqMs.jpg",
        "sizes" : [ {
          "h" : 120,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 1250
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 1250
        }, {
          "h" : 211,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/Q1vryGUWIk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/EeASZFhRqN",
        "expanded_url" : "https:\/\/mobile.nytimes.com\/2017\/02\/14\/opinion\/an-eminent-psychiatrist-demurs-on-trumps-mental-state.html?_r=0&referer=",
        "display_url" : "mobile.nytimes.com\/2017\/02\/14\/opi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "831888090901970945",
    "text" : "thank yoooouuuuuuuuu \n\nhttps:\/\/t.co\/EeASZFhRqN https:\/\/t.co\/Q1vryGUWIk",
    "id" : 831888090901970945,
    "created_at" : "2017-02-15 15:29:11 +0000",
    "user" : {
      "name" : "good erin",
      "screen_name" : "eehouls",
      "protected" : false,
      "id_str" : "13399892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/893307803640770560\/FcYd3zHu_normal.jpg",
      "id" : 13399892,
      "verified" : false
    }
  },
  "id" : 831892958991486979,
  "created_at" : "2017-02-15 15:48:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 0, 12 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "831205606656704514",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236858466958, 8.627519024140414 ]
  },
  "id_str" : "831879267390803970",
  "in_reply_to_user_id" : 214099847,
  "text" : "@jonfwilkins great post, thanks!",
  "id" : 831879267390803970,
  "in_reply_to_status_id" : 831205606656704514,
  "created_at" : "2017-02-15 14:54:07 +0000",
  "in_reply_to_screen_name" : "jonfwilkins",
  "in_reply_to_user_id_str" : "214099847",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/z6av8nqTmA",
      "expanded_url" : "https:\/\/twitter.com\/jonfwilkins\/status\/831205606656704514",
      "display_url" : "twitter.com\/jonfwilkins\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236858466958, 8.627519024140414 ]
  },
  "id_str" : "831879240782057474",
  "text" : "\u00ABIf our only\u00A0hope of saving American science relies on\u00A0the largesse\u00A0of racists and xenophobes, we are in even more trouble than we thought\u00BB https:\/\/t.co\/z6av8nqTmA",
  "id" : 831879240782057474,
  "created_at" : "2017-02-15 14:54:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 0, 11 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "831878722160566273",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236931657513, 8.627518573561002 ]
  },
  "id_str" : "831878824124100609",
  "in_reply_to_user_id" : 20342875,
  "text" : "@LouWoodley oh no! But at least you\u2019ll now have an excellent excuse to go again!",
  "id" : 831878824124100609,
  "in_reply_to_status_id" : 831878722160566273,
  "created_at" : "2017-02-15 14:52:21 +0000",
  "in_reply_to_screen_name" : "LouWoodley",
  "in_reply_to_user_id_str" : "20342875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 69, 80 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/nacTMvKItj",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/places\/ms-pearl-the-worlds-largest-squirrel-statue",
      "display_url" : "atlasobscura.com\/places\/ms-pear\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238011191965, 8.627491264230304 ]
  },
  "id_str" : "831876296275795970",
  "text" : "If I ever make it to Austin I\u2019ll go visit Ms. Pearl. You should too, @LouWoodley! https:\/\/t.co\/nacTMvKItj",
  "id" : 831876296275795970,
  "created_at" : "2017-02-15 14:42:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "831868815411658755",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238409166359, 8.627461096873667 ]
  },
  "id_str" : "831869056877727744",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb it\u2019s hilarious, the flight plan is so long that it breaks the website\u2019s UI. :D",
  "id" : 831869056877727744,
  "in_reply_to_status_id" : 831868815411658755,
  "created_at" : "2017-02-15 14:13:33 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234619804379, 8.627518334990611 ]
  },
  "id_str" : "831867340660801536",
  "text" : "Looked for a flight FRA\u2708\uFE0FSEA. Website recommends a 60h trip, w\/ 20h layover in LIS + 22h layover to change from JFK\uD83C\uDFC3EWR to save whopping 7\u20AC.",
  "id" : 831867340660801536,
  "created_at" : "2017-02-15 14:06:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "831816096596553729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723374746871, 8.62751230944271 ]
  },
  "id_str" : "831840805790838785",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch \uD83D\uDE4F",
  "id" : 831840805790838785,
  "in_reply_to_status_id" : 831816096596553729,
  "created_at" : "2017-02-15 12:21:17 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229621914021, 8.627513546371295 ]
  },
  "id_str" : "831783709976252416",
  "text" : "Relationships where you have to consider your layover times in order to meet somewhere. \uD83E\uDD14",
  "id" : 831783709976252416,
  "created_at" : "2017-02-15 08:34:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "831780863713099777",
  "text" : "RT @gedankenstuecke: \u00ABIf we can\u2019t fuck someone together, how are we supposed to raise a child?\u00BB A promising web series on sexuality. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/sU1c5i4l1D",
        "expanded_url" : "http:\/\/www.unicornlandseries.com\/",
        "display_url" : "unicornlandseries.com"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.06096878867024, 8.81864558496899 ]
    },
    "id_str" : "831601867394281472",
    "text" : "\u00ABIf we can\u2019t fuck someone together, how are we supposed to raise a child?\u00BB A promising web series on sexuality. https:\/\/t.co\/sU1c5i4l1D",
    "id" : 831601867394281472,
    "created_at" : "2017-02-14 20:31:50 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 831780863713099777,
  "created_at" : "2017-02-15 08:23:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OBF News",
      "screen_name" : "obf_news",
      "indices" : [ 3, 12 ],
      "id_str" : "20624794",
      "id" : 20624794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/bdblGKN1us",
      "expanded_url" : "https:\/\/github.com\/OBF\/obf-docs\/blob\/master\/Travel_fellowships.md",
      "display_url" : "github.com\/OBF\/obf-docs\/b\u2026"
    }, {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/B8JtNnGhd6",
      "expanded_url" : "https:\/\/news.open-bio.org\/2016\/03\/01\/obf-travel-fellowship-program\/",
      "display_url" : "news.open-bio.org\/2016\/03\/01\/obf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831759323252547585",
  "text" : "RT @obf_news: Reminder that our next Travel Fellowship deadline is 15 April 2017 https:\/\/t.co\/bdblGKN1us https:\/\/t.co\/B8JtNnGhd6 #opensourc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opensource",
        "indices" : [ 115, 126 ]
      }, {
        "text" : "diversity",
        "indices" : [ 127, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/bdblGKN1us",
        "expanded_url" : "https:\/\/github.com\/OBF\/obf-docs\/blob\/master\/Travel_fellowships.md",
        "display_url" : "github.com\/OBF\/obf-docs\/b\u2026"
      }, {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/B8JtNnGhd6",
        "expanded_url" : "https:\/\/news.open-bio.org\/2016\/03\/01\/obf-travel-fellowship-program\/",
        "display_url" : "news.open-bio.org\/2016\/03\/01\/obf\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "831576503804628997",
    "text" : "Reminder that our next Travel Fellowship deadline is 15 April 2017 https:\/\/t.co\/bdblGKN1us https:\/\/t.co\/B8JtNnGhd6 #opensource #diversity",
    "id" : 831576503804628997,
    "created_at" : "2017-02-14 18:51:03 +0000",
    "user" : {
      "name" : "OBF News",
      "screen_name" : "obf_news",
      "protected" : false,
      "id_str" : "20624794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/77404934\/OBF_logo_normal.png",
      "id" : 20624794,
      "verified" : false
    }
  },
  "id" : 831759323252547585,
  "created_at" : "2017-02-15 06:57:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "831623568161198081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0608301225167, 8.818710321701982 ]
  },
  "id_str" : "831624047796637696",
  "in_reply_to_user_id" : 2396006202,
  "text" : "@petergrabitz dunno, my approach is not to care and put all on GH and claim it\u2019s MIT licensed ;)",
  "id" : 831624047796637696,
  "in_reply_to_status_id" : 831623568161198081,
  "created_at" : "2017-02-14 21:59:58 +0000",
  "in_reply_to_screen_name" : "PeterRolandG",
  "in_reply_to_user_id_str" : "2396006202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/sU1c5i4l1D",
      "expanded_url" : "http:\/\/www.unicornlandseries.com\/",
      "display_url" : "unicornlandseries.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06096878867024, 8.81864558496899 ]
  },
  "id_str" : "831601867394281472",
  "text" : "\u00ABIf we can\u2019t fuck someone together, how are we supposed to raise a child?\u00BB A promising web series on sexuality. https:\/\/t.co\/sU1c5i4l1D",
  "id" : 831601867394281472,
  "created_at" : "2017-02-14 20:31:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/qligJo2cZI",
      "expanded_url" : "https:\/\/www.theguardian.com\/lifeandstyle\/shortcuts\/2017\/feb\/14\/lust-for-life-why-sex-is-better-in-your-80s?CMP=Share_iOSApp_Other",
      "display_url" : "theguardian.com\/lifeandstyle\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831587606043430912",
  "text" : "Life goals https:\/\/t.co\/qligJo2cZI",
  "id" : 831587606043430912,
  "created_at" : "2017-02-14 19:35:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 3, 18 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 56, 71 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 79, 94 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "831548464945307649",
  "text" : "RT @MozOpenLeaders: Excited 2 announce projects joining @MozillaScience WOW w\/ @MozOpenLeaders! Stay tuned for full list of projects\nhttps:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mozilla Science Lab",
        "screen_name" : "MozillaScience",
        "indices" : [ 36, 51 ],
        "id_str" : "1428575976",
        "id" : 1428575976
      }, {
        "name" : "Mozilla Open Leaders",
        "screen_name" : "MozOpenLeaders",
        "indices" : [ 59, 74 ],
        "id_str" : "791070237949034496",
        "id" : 791070237949034496
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/IxJySpY28a",
        "expanded_url" : "https:\/\/mozillascience.github.io\/WOW-2017\/#projects",
        "display_url" : "mozillascience.github.io\/WOW-2017\/#proj\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "831540900367056897",
    "text" : "Excited 2 announce projects joining @MozillaScience WOW w\/ @MozOpenLeaders! Stay tuned for full list of projects\nhttps:\/\/t.co\/IxJySpY28a",
    "id" : 831540900367056897,
    "created_at" : "2017-02-14 16:29:34 +0000",
    "user" : {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "protected" : false,
      "id_str" : "791070237949034496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/842142191032123392\/GS5Ptjrs_normal.jpg",
      "id" : 791070237949034496,
      "verified" : false
    }
  },
  "id" : 831548464945307649,
  "created_at" : "2017-02-14 16:59:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 129, 152 ],
      "url" : "https:\/\/t.co\/EsSGac2qQC",
      "expanded_url" : "https:\/\/twitter.com\/OmnesResNetwork\/status\/831239479801307137",
      "display_url" : "twitter.com\/OmnesResNetwor\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236312882339, 8.62752099053494 ]
  },
  "id_str" : "831488400490426368",
  "text" : "The story is getting worse and worse. But why am I not surprised it\u2019s the \u201CFood and Brand Lab\u201D, the already likely \uD83D\uDC0D-oil topics? https:\/\/t.co\/EsSGac2qQC",
  "id" : 831488400490426368,
  "created_at" : "2017-02-14 13:00:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/5iSLBT7Poh",
      "expanded_url" : "https:\/\/twitter.com\/sexmotron\/status\/831435451412180992",
      "display_url" : "twitter.com\/sexmotron\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236435314516, 8.627529156112045 ]
  },
  "id_str" : "831486182857048065",
  "text" : "Tried that. Usually leads to the smartphone needing a new screen. https:\/\/t.co\/5iSLBT7Poh",
  "id" : 831486182857048065,
  "created_at" : "2017-02-14 12:52:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cambridge Analytica",
      "screen_name" : "CamAnalytica",
      "indices" : [ 53, 66 ],
      "id_str" : "3415205164",
      "id" : 3415205164
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 72, 81 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/HW5bjNqtPB",
      "expanded_url" : "https:\/\/toe.prx.org\/2017\/02\/doomed-to-repeat\/",
      "display_url" : "toe.prx.org\/2017\/02\/doomed\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236513602024, 8.627518575513271 ]
  },
  "id_str" : "831479005945675776",
  "text" : "ToE\u2019s \u00ABDoomed to Repeat\u00BB features some background on @CamAnalytica. \/cc @podehaye https:\/\/t.co\/HW5bjNqtPB",
  "id" : 831479005945675776,
  "created_at" : "2017-02-14 12:23:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/LUTz0BZI3a",
      "expanded_url" : "http:\/\/undark.org\/article\/math-lesson-hitlers-germany\/",
      "display_url" : "undark.org\/article\/math-l\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235265560255, 8.627478223294434 ]
  },
  "id_str" : "831452461974032384",
  "text" : "A Math Lesson From Hitler\u2019s Germany https:\/\/t.co\/LUTz0BZI3a",
  "id" : 831452461974032384,
  "created_at" : "2017-02-14 10:38:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 3, 11 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "831451622534479872",
  "text" : "RT @o_guest: \"having to endure \"gay rumors\" is NOT A PERSONAL FAILURE that should be bundled with being caught for HARKing\"\nhttps:\/\/t.co\/gx\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/gxYe1vSKQX",
        "expanded_url" : "http:\/\/www.brianwansink.com\/phd-advice\/statistical-heartburn-and-long-term-lessons#comments",
        "display_url" : "brianwansink.com\/phd-advice\/sta\u2026"
      }, {
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/lwDXucmILt",
        "expanded_url" : "https:\/\/twitter.com\/BrianWansink\/status\/831152241742594049",
        "display_url" : "twitter.com\/BrianWansink\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "831451226583752704",
    "text" : "\"having to endure \"gay rumors\" is NOT A PERSONAL FAILURE that should be bundled with being caught for HARKing\"\nhttps:\/\/t.co\/gxYe1vSKQX https:\/\/t.co\/lwDXucmILt",
    "id" : 831451226583752704,
    "created_at" : "2017-02-14 10:33:14 +0000",
    "user" : {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "protected" : false,
      "id_str" : "3865005196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844972791732584453\/mdSj6vOd_normal.jpg",
      "id" : 3865005196,
      "verified" : false
    }
  },
  "id" : 831451622534479872,
  "created_at" : "2017-02-14 10:34:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 3, 10 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "831443976557314049",
  "text" : "RT @sujaik: This is amazing - Trees along with BLAST results! Only 26 proteomes (~50\/50 eukaryotes\/non) for now. But already so useful. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/jAFlEJ9mlE",
        "expanded_url" : "https:\/\/twitter.com\/NCBI\/status\/831225270900240384",
        "display_url" : "twitter.com\/NCBI\/status\/83\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "831406687236063232",
    "text" : "This is amazing - Trees along with BLAST results! Only 26 proteomes (~50\/50 eukaryotes\/non) for now. But already so useful. https:\/\/t.co\/jAFlEJ9mlE",
    "id" : 831406687236063232,
    "created_at" : "2017-02-14 07:36:15 +0000",
    "user" : {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "protected" : false,
      "id_str" : "33651124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499041232765460480\/J2nyoivC_normal.jpeg",
      "id" : 33651124,
      "verified" : false
    }
  },
  "id" : 831443976557314049,
  "created_at" : "2017-02-14 10:04:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shayda Kashef",
      "screen_name" : "shayda_k",
      "indices" : [ 3, 12 ],
      "id_str" : "27086206",
      "id" : 27086206
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 111, 119 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/UyL7vCqak2",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=u1hnBv12-uk&sns=tw",
      "display_url" : "youtube.com\/watch?v=u1hnBv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "831439740394143744",
  "text" : "RT @shayda_k: The Devil Went Down To Georgia by one man and his washing machine \uD83D\uDC4C\uD83C\uDFFC https:\/\/t.co\/UyL7vCqak2 via @youtube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 97, 105 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/UyL7vCqak2",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=u1hnBv12-uk&sns=tw",
        "display_url" : "youtube.com\/watch?v=u1hnBv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "831423863842099200",
    "text" : "The Devil Went Down To Georgia by one man and his washing machine \uD83D\uDC4C\uD83C\uDFFC https:\/\/t.co\/UyL7vCqak2 via @youtube",
    "id" : 831423863842099200,
    "created_at" : "2017-02-14 08:44:30 +0000",
    "user" : {
      "name" : "Shayda Kashef",
      "screen_name" : "shayda_k",
      "protected" : false,
      "id_str" : "27086206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905153247425552385\/ldkcfdiE_normal.jpg",
      "id" : 27086206,
      "verified" : false
    }
  },
  "id" : 831439740394143744,
  "created_at" : "2017-02-14 09:47:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "831420395311869953",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235329435832, 8.627520278930191 ]
  },
  "id_str" : "831420854990934016",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, thanks! I met Jean-Pierre in Geneva last year, they\u2019re a fun group!",
  "id" : 831420854990934016,
  "in_reply_to_status_id" : 831420395311869953,
  "created_at" : "2017-02-14 08:32:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "indices" : [ 3, 16 ],
      "id_str" : "228437800",
      "id" : 228437800
    }, {
      "name" : "Quartz",
      "screen_name" : "qz",
      "indices" : [ 124, 127 ],
      "id_str" : "573918122",
      "id" : 573918122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "831256031556689920",
  "text" : "RT @atossaaraxia: I wrote about Assange's obsolescence as a political symbol &amp; his future at the Ecuadorian embassy for @qz https:\/\/t.co\/RE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Quartz",
        "screen_name" : "qz",
        "indices" : [ 106, 109 ],
        "id_str" : "573918122",
        "id" : 573918122
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/REG0bgFjKM",
        "expanded_url" : "https:\/\/qz.com\/908321",
        "display_url" : "qz.com\/908321"
      } ]
    },
    "geo" : { },
    "id_str" : "831242644135231489",
    "text" : "I wrote about Assange's obsolescence as a political symbol &amp; his future at the Ecuadorian embassy for @qz https:\/\/t.co\/REG0bgFjKM",
    "id" : 831242644135231489,
    "created_at" : "2017-02-13 20:44:24 +0000",
    "user" : {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "protected" : false,
      "id_str" : "228437800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707884522738728960\/VqnZwF27_normal.jpg",
      "id" : 228437800,
      "verified" : true
    }
  },
  "id" : 831256031556689920,
  "created_at" : "2017-02-13 21:37:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "indices" : [ 3, 12 ],
      "id_str" : "2442015493",
      "id" : 2442015493
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar",
      "indices" : [ 54, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "831170539700027392",
  "text" : "RT @LGBTSTEM: Voting will be open for the location of #LGBTSTEMinar 18 &amp; 19 until 20\/2 Remember to vote if you want to have a say! https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTSTEMinar",
        "indices" : [ 40, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/cnGUkpVQDV",
        "expanded_url" : "http:\/\/demochoice.org\/dcballot.php?poll=LGBTSTEM",
        "display_url" : "demochoice.org\/dcballot.php?p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "831169017222148097",
    "text" : "Voting will be open for the location of #LGBTSTEMinar 18 &amp; 19 until 20\/2 Remember to vote if you want to have a say! https:\/\/t.co\/cnGUkpVQDV",
    "id" : 831169017222148097,
    "created_at" : "2017-02-13 15:51:50 +0000",
    "user" : {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "protected" : false,
      "id_str" : "2442015493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685082380223295488\/XGTcyfxo_normal.jpg",
      "id" : 2442015493,
      "verified" : false
    }
  },
  "id" : 831170539700027392,
  "created_at" : "2017-02-13 15:57:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "831112535726231552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236098543687, 8.627520425445306 ]
  },
  "id_str" : "831169318461267968",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson is there a quinoa-shaped Venn diagram as well?",
  "id" : 831169318461267968,
  "in_reply_to_status_id" : 831112535726231552,
  "created_at" : "2017-02-13 15:53:02 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 3, 17 ],
      "id_str" : "12984852",
      "id" : 12984852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "force11",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "831047295860871168",
  "text" : "RT @CameronNeylon: FSCI@UCSD #force11 Announces Scholarly Communications Institute at UCSD July 30 - Aug 4, 2017, San Diego, CA https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "force11",
        "indices" : [ 10, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/yaUxmgeICx",
        "expanded_url" : "http:\/\/www.force11.org\/fsci",
        "display_url" : "force11.org\/fsci"
      } ]
    },
    "geo" : { },
    "id_str" : "831046459957010433",
    "text" : "FSCI@UCSD #force11 Announces Scholarly Communications Institute at UCSD July 30 - Aug 4, 2017, San Diego, CA https:\/\/t.co\/yaUxmgeICx",
    "id" : 831046459957010433,
    "created_at" : "2017-02-13 07:44:50 +0000",
    "user" : {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "protected" : false,
      "id_str" : "12984852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1766127492\/image1326973990_normal.png",
      "id" : 12984852,
      "verified" : false
    }
  },
  "id" : 831047295860871168,
  "created_at" : "2017-02-13 07:48:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "830768396732076034",
  "geo" : { },
  "id_str" : "830770134616772609",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye looks interesting!",
  "id" : 830770134616772609,
  "in_reply_to_status_id" : 830768396732076034,
  "created_at" : "2017-02-12 13:26:49 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/fhE6ThuAxQ",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/iceland-witchcraft-museum-sorcery-interview",
      "display_url" : "atlasobscura.com\/articles\/icela\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "830770040312098816",
  "text" : "It's Not Always Easy Being Iceland's Best Witchcraft Museum https:\/\/t.co\/fhE6ThuAxQ",
  "id" : 830770040312098816,
  "created_at" : "2017-02-12 13:26:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/Hyq6fk8g4s",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/tonight39s-eulogy",
      "display_url" : "smbc-comics.com\/comic\/tonight3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "830765463177142273",
  "text" : "i can totally imagine myself ending up in that situation. https:\/\/t.co\/Hyq6fk8g4s",
  "id" : 830765463177142273,
  "created_at" : "2017-02-12 13:08:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/pexlDAY3ho",
      "expanded_url" : "http:\/\/www.molecularecologist.com\/2017\/02\/music-to-an-amniotes-ears-an-accordion-model-of-genome-size-evolution\/",
      "display_url" : "molecularecologist.com\/2017\/02\/music-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "830764857347674113",
  "text" : "Music to an amniote\u2019s ears, an \u201Caccordion\u201D model of genome size evolution https:\/\/t.co\/pexlDAY3ho",
  "id" : 830764857347674113,
  "created_at" : "2017-02-12 13:05:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "830391604439572481",
  "text" : "RT @gedankenstuecke: Also: shared this GIF today and the reply was 'Oh, at first I thought this was you!' Not sure whether Joe aged very we\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/830192165552807936\/photo\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/fI67TRDUPM",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C4VvXh9W8AAYxxn.jpg",
        "id_str" : "830192156363124736",
        "id" : 830192156363124736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C4VvXh9W8AAYxxn.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/fI67TRDUPM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "830046205648461825",
    "geo" : { },
    "id_str" : "830192165552807936",
    "in_reply_to_user_id" : 14286491,
    "text" : "Also: shared this GIF today and the reply was 'Oh, at first I thought this was you!' Not sure whether Joe aged very well or I very poorly. https:\/\/t.co\/fI67TRDUPM",
    "id" : 830192165552807936,
    "in_reply_to_status_id" : 830046205648461825,
    "created_at" : "2017-02-10 23:10:11 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 830391604439572481,
  "created_at" : "2017-02-11 12:22:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 0, 11 ],
      "id_str" : "20653310",
      "id" : 20653310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "830194699658940417",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35935654486011, 8.587766598569663 ]
  },
  "id_str" : "830201682353086464",
  "in_reply_to_user_id" : 20653310,
  "text" : "@rchampieux if they ever do a biopic I can maybe play the young Joe :D",
  "id" : 830201682353086464,
  "in_reply_to_status_id" : 830194699658940417,
  "created_at" : "2017-02-10 23:48:00 +0000",
  "in_reply_to_screen_name" : "rchampieux",
  "in_reply_to_user_id_str" : "20653310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MNH GROUP",
      "screen_name" : "MNHGroup",
      "indices" : [ 3, 12 ],
      "id_str" : "289823541",
      "id" : 289823541
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 36, 52 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 67, 78 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VendrediLecture",
      "indices" : [ 14, 30 ]
    }, {
      "text" : "openscience",
      "indices" : [ 98, 110 ]
    }, {
      "text" : "citizenscience",
      "indices" : [ 111, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "830192230581272576",
  "text" : "RT @MNHGroup: #VendrediLecture avec @gedankenstuecke, fondateur de @openSNPorg - Rencontre avec l'#openscience #citizenscience \uD83C\uDF4F\n\u25B6\uFE0Fhttps:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 22, 38 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 53, 64 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MNHGroup\/status\/830116764537253888\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/ww3PvTQ8gL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C4Um5UyXAAAqzVU.jpg",
        "id_str" : "830112472594055168",
        "id" : 830112472594055168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C4Um5UyXAAAqzVU.jpg",
        "sizes" : [ {
          "h" : 558,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 880,
          "resize" : "fit",
          "w" : 1891
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 880,
          "resize" : "fit",
          "w" : 1891
        }, {
          "h" : 316,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/ww3PvTQ8gL"
      } ],
      "hashtags" : [ {
        "text" : "VendrediLecture",
        "indices" : [ 0, 16 ]
      }, {
        "text" : "openscience",
        "indices" : [ 84, 96 ]
      }, {
        "text" : "citizenscience",
        "indices" : [ 97, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/PMR8NPlbXP",
        "expanded_url" : "https:\/\/wp.me\/s8jF3i-opensnp",
        "display_url" : "wp.me\/s8jF3i-opensnp"
      } ]
    },
    "geo" : { },
    "id_str" : "830116764537253888",
    "text" : "#VendrediLecture avec @gedankenstuecke, fondateur de @openSNPorg - Rencontre avec l'#openscience #citizenscience \uD83C\uDF4F\n\u25B6\uFE0Fhttps:\/\/t.co\/PMR8NPlbXP https:\/\/t.co\/ww3PvTQ8gL",
    "id" : 830116764537253888,
    "created_at" : "2017-02-10 18:10:34 +0000",
    "user" : {
      "name" : "MNH GROUP",
      "screen_name" : "MNHGroup",
      "protected" : false,
      "id_str" : "289823541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/863352691132698624\/BKJl0ZYu_normal.jpg",
      "id" : 289823541,
      "verified" : false
    }
  },
  "id" : 830192230581272576,
  "created_at" : "2017-02-10 23:10:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/830192165552807936\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/fI67TRDUPM",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C4VvXh9W8AAYxxn.jpg",
      "id_str" : "830192156363124736",
      "id" : 830192156363124736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C4VvXh9W8AAYxxn.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/fI67TRDUPM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "830046205648461825",
  "geo" : { },
  "id_str" : "830192165552807936",
  "in_reply_to_user_id" : 14286491,
  "text" : "Also: shared this GIF today and the reply was 'Oh, at first I thought this was you!' Not sure whether Joe aged very well or I very poorly. https:\/\/t.co\/fI67TRDUPM",
  "id" : 830192165552807936,
  "in_reply_to_status_id" : 830046205648461825,
  "created_at" : "2017-02-10 23:10:11 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "830047874901741569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17191432558929, 8.627425838254906 ]
  },
  "id_str" : "830050074080194563",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks .\/configure;make;make install\n\nThen start praying.",
  "id" : 830050074080194563,
  "in_reply_to_status_id" : 830047874901741569,
  "created_at" : "2017-02-10 13:45:33 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "830047658534387715",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17271981660155, 8.627601905573997 ]
  },
  "id_str" : "830048948559704064",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks I\u2019d be fine with a metric that requires a manual.  But there\u2019s a million ways to display this exact data that doesn\u2019t require one!",
  "id" : 830048948559704064,
  "in_reply_to_status_id" : 830047658534387715,
  "created_at" : "2017-02-10 13:41:05 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Amsen",
      "screen_name" : "easternblot",
      "indices" : [ 0, 12 ],
      "id_str" : "14506075",
      "id" : 14506075
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 13, 22 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "830048584636698624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17271981660155, 8.627601905573997 ]
  },
  "id_str" : "830048660671102977",
  "in_reply_to_user_id" : 14506075,
  "text" : "@easternblot @wilbanks me too!",
  "id" : 830048660671102977,
  "in_reply_to_status_id" : 830048584636698624,
  "created_at" : "2017-02-10 13:39:56 +0000",
  "in_reply_to_screen_name" : "easternblot",
  "in_reply_to_user_id_str" : "14506075",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/iD2sAddwAl",
      "expanded_url" : "https:\/\/theoutline.com\/post\/980\/misinterpreting-hannah-arendt",
      "display_url" : "theoutline.com\/post\/980\/misin\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239626942798, 8.627451599828271 ]
  },
  "id_str" : "830046205648461825",
  "text" : "Shared this article and in return I was asked whether I knew Hannah personally. I must look dead tired these days. https:\/\/t.co\/iD2sAddwAl",
  "id" : 830046205648461825,
  "created_at" : "2017-02-10 13:30:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/9AeQHARoWq",
      "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/830042367830941696",
      "display_url" : "twitter.com\/wilbanks\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238172611765, 8.627514526282445 ]
  },
  "id_str" : "830045369279139840",
  "text" : "I needed to stare for far too long at this to finally understand what\u2019s going on. https:\/\/t.co\/9AeQHARoWq",
  "id" : 830045369279139840,
  "created_at" : "2017-02-10 13:26:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/sGaP0gVe3G",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2017\/01\/19\/093518",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237462688058, 8.627552673664027 ]
  },
  "id_str" : "830042097361252352",
  "text" : "Data Reuse as a Prisoner\u2019s Dilemma https:\/\/t.co\/sGaP0gVe3G",
  "id" : 830042097361252352,
  "created_at" : "2017-02-10 13:13:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "830030426525749251",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236071306635, 8.62752452095298 ]
  },
  "id_str" : "830030579789881347",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski might come in handy during my PhD defense. You never know.",
  "id" : 830030579789881347,
  "in_reply_to_status_id" : 830030426525749251,
  "created_at" : "2017-02-10 12:28:06 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/V9QPPhgTfD",
      "expanded_url" : "https:\/\/stronglang.wordpress.com\/2017\/02\/09\/the-rise-of-the-shitgibbon\/",
      "display_url" : "stronglang.wordpress.com\/2017\/02\/09\/the\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237531266056, 8.627597688850988 ]
  },
  "id_str" : "830029996525772800",
  "text" : "One of the most productive things I\u2019ve done today: Reading on the etymology of shit-gibbon https:\/\/t.co\/V9QPPhgTfD",
  "id" : 830029996525772800,
  "created_at" : "2017-02-10 12:25:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829850001014562817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406917290953, 8.753412573340317 ]
  },
  "id_str" : "829850154819866625",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb I get it, it\u2019s just too warm for physical activity in down under. :p",
  "id" : 829850154819866625,
  "in_reply_to_status_id" : 829850001014562817,
  "created_at" : "2017-02-10 00:31:09 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829849734672101376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406917290953, 8.753412573340317 ]
  },
  "id_str" : "829849907834060802",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb did you try punching them?",
  "id" : 829849907834060802,
  "in_reply_to_status_id" : 829849734672101376,
  "created_at" : "2017-02-10 00:30:10 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/XGp6x3tc5p",
      "expanded_url" : "https:\/\/twitter.com\/AGKBorgwardt\/status\/829792830117777412",
      "display_url" : "twitter.com\/AGKBorgwardt\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404513786774, 8.753447106495752 ]
  },
  "id_str" : "829798744426213378",
  "text" : "Yay! \uD83C\uDF89 https:\/\/t.co\/XGp6x3tc5p",
  "id" : 829798744426213378,
  "created_at" : "2017-02-09 21:06:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanna Marie",
      "screen_name" : "tinysapien",
      "indices" : [ 3, 14 ],
      "id_str" : "204890149",
      "id" : 204890149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/YbgvTXp232",
      "expanded_url" : "http:\/\/issciencepolitical.com",
      "display_url" : "issciencepolitical.com"
    } ]
  },
  "geo" : { },
  "id_str" : "829788519543484418",
  "text" : "RT @tinysapien: https:\/\/t.co\/YbgvTXp232",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/YbgvTXp232",
        "expanded_url" : "http:\/\/issciencepolitical.com",
        "display_url" : "issciencepolitical.com"
      } ]
    },
    "geo" : { },
    "id_str" : "829753536288260096",
    "text" : "https:\/\/t.co\/YbgvTXp232",
    "id" : 829753536288260096,
    "created_at" : "2017-02-09 18:07:13 +0000",
    "user" : {
      "name" : "Hanna Marie",
      "screen_name" : "tinysapien",
      "protected" : false,
      "id_str" : "204890149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/914562198806188034\/7KrVQEAP_normal.jpg",
      "id" : 204890149,
      "verified" : false
    }
  },
  "id" : 829788519543484418,
  "created_at" : "2017-02-09 20:26:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "829709461606514689",
  "text" : "RT @gedankenstuecke: Decided to donate all the money I\u2019d otherwise have spend on travel to\/in the US to social justice organizations there.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/ckQGgzpjGi",
        "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/829501395288068101",
        "display_url" : "twitter.com\/wilbanks\/statu\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.11406451274354, 8.7534145581916 ]
    },
    "id_str" : "829591992371970050",
    "text" : "Decided to donate all the money I\u2019d otherwise have spend on travel to\/in the US to social justice organizations there. https:\/\/t.co\/ckQGgzpjGi",
    "id" : 829591992371970050,
    "created_at" : "2017-02-09 07:25:18 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 829709461606514689,
  "created_at" : "2017-02-09 15:12:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "_katsel",
      "indices" : [ 3, 11 ],
      "id_str" : "892038837052076033",
      "id" : 892038837052076033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/O2hwb5yE3f",
      "expanded_url" : "http:\/\/www.thinkingautismguide.com\/2017\/02\/autism-and-burden-of-social-reciprocity.html",
      "display_url" : "thinkingautismguide.com\/2017\/02\/autism\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829700705711685633",
  "text" : "RT @_katsel: Autistic people are consistently rated lower on \u2039first impression\u203A by non-autistics: https:\/\/t.co\/O2hwb5yE3f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/O2hwb5yE3f",
        "expanded_url" : "http:\/\/www.thinkingautismguide.com\/2017\/02\/autism-and-burden-of-social-reciprocity.html",
        "display_url" : "thinkingautismguide.com\/2017\/02\/autism\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "829700425762926593",
    "text" : "Autistic people are consistently rated lower on \u2039first impression\u203A by non-autistics: https:\/\/t.co\/O2hwb5yE3f",
    "id" : 829700425762926593,
    "created_at" : "2017-02-09 14:36:11 +0000",
    "user" : {
      "name" : "Katharina",
      "screen_name" : "katheyrina",
      "protected" : false,
      "id_str" : "730326143295959040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/885460122394349569\/oHlt5LK-_normal.jpg",
      "id" : 730326143295959040,
      "verified" : false
    }
  },
  "id" : 829700705711685633,
  "created_at" : "2017-02-09 14:37:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/wfKNSdVdOg",
      "expanded_url" : "https:\/\/twitter.com\/zoonpolitikon\/status\/829632831844470784",
      "display_url" : "twitter.com\/zoonpolitikon\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236551994129, 8.627535542516762 ]
  },
  "id_str" : "829633174632280066",
  "text" : "To make it less obvious: Found a significant effect in brunette women with green eyes in the age range of 30-35. https:\/\/t.co\/wfKNSdVdOg",
  "id" : 829633174632280066,
  "created_at" : "2017-02-09 10:08:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/f6x24U6Kmt",
      "expanded_url" : "https:\/\/twitter.com\/M_Kosilo\/status\/829305142965071873",
      "display_url" : "twitter.com\/M_Kosilo\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229572022483, 8.627537387056233 ]
  },
  "id_str" : "829630454508711936",
  "text" : "Who expects anything these days? Just slice it into sub-segments until you hit p&lt;0.05. https:\/\/t.co\/f6x24U6Kmt",
  "id" : 829630454508711936,
  "created_at" : "2017-02-09 09:58:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/ckQGgzpjGi",
      "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/829501395288068101",
      "display_url" : "twitter.com\/wilbanks\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406451274354, 8.7534145581916 ]
  },
  "id_str" : "829591992371970050",
  "text" : "Decided to donate all the money I\u2019d otherwise have spend on travel to\/in the US to social justice organizations there. https:\/\/t.co\/ckQGgzpjGi",
  "id" : 829591992371970050,
  "created_at" : "2017-02-09 07:25:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 0, 13 ],
      "id_str" : "22200760",
      "id" : 22200760
    }, {
      "name" : "Wendy Patterson",
      "screen_name" : "wendympatterson",
      "indices" : [ 14, 30 ],
      "id_str" : "771302483733938178",
      "id" : 771302483733938178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829474281671241728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140635472579, 8.753413910477569 ]
  },
  "id_str" : "829474352437534720",
  "in_reply_to_user_id" : 22200760,
  "text" : "@vexedmuddler @wendympatterson same here btw!",
  "id" : 829474352437534720,
  "in_reply_to_status_id" : 829474281671241728,
  "created_at" : "2017-02-08 23:37:51 +0000",
  "in_reply_to_screen_name" : "vexedmuddler",
  "in_reply_to_user_id_str" : "22200760",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829452410410131459",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406540661905, 8.753415376656195 ]
  },
  "id_str" : "829452516853182465",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye both but prefer telegram, same username :)",
  "id" : 829452516853182465,
  "in_reply_to_status_id" : 829452410410131459,
  "created_at" : "2017-02-08 22:11:05 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ratty McRatface \uD83D\uDC00",
      "screen_name" : "godhika",
      "indices" : [ 0, 8 ],
      "id_str" : "96797688",
      "id" : 96797688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829405661117218818",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406446957649, 8.753416472744323 ]
  },
  "id_str" : "829405818877595648",
  "in_reply_to_user_id" : 96797688,
  "text" : "@godhika siehe n\u00E4chste Tweets. Au\u00DFer ACLU, die haben ihre Golden Shower schon bekommen :p",
  "id" : 829405818877595648,
  "in_reply_to_status_id" : 829405661117218818,
  "created_at" : "2017-02-08 19:05:31 +0000",
  "in_reply_to_screen_name" : "godhika",
  "in_reply_to_user_id_str" : "96797688",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/ifb9C4EFU0",
      "expanded_url" : "https:\/\/twitter.com\/vexedmuddler\/status\/829398292433928192",
      "display_url" : "twitter.com\/vexedmuddler\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406513853491, 8.753413299531758 ]
  },
  "id_str" : "829401436178042897",
  "text" : "Wondering the same. Know some of you must have good suggestions. https:\/\/t.co\/ifb9C4EFU0",
  "id" : 829401436178042897,
  "created_at" : "2017-02-08 18:48:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/aCAz3NpjXV",
      "expanded_url" : "http:\/\/www.repeatmasker.org\/RepeatModeler.html",
      "display_url" : "repeatmasker.org\/RepeatModeler.\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "829354328288800769",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232329433347, 8.62752438868536 ]
  },
  "id_str" : "829354935779282944",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 goes hand in hand w\/ RepeatMasker https:\/\/t.co\/aCAz3NpjXV",
  "id" : 829354935779282944,
  "in_reply_to_status_id" : 829354328288800769,
  "created_at" : "2017-02-08 15:43:20 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829349759022415873",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17242323232007, 8.627376379863367 ]
  },
  "id_str" : "829354122981818368",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 you can train RepeatMasker using RepeatModeler on your own genomes.",
  "id" : 829354122981818368,
  "in_reply_to_status_id" : 829349759022415873,
  "created_at" : "2017-02-08 15:40:06 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829341148732874752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235491789287, 8.627561853804686 ]
  },
  "id_str" : "829341613587566592",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 which ones are you using? :)",
  "id" : 829341613587566592,
  "in_reply_to_status_id" : 829341148732874752,
  "created_at" : "2017-02-08 14:50:23 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829326234211450880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235824465378, 8.62751564132303 ]
  },
  "id_str" : "829326363379298304",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField I searched for a GIF on the spreadsheet-table-flip pun, but couldn\u2019t find any!",
  "id" : 829326363379298304,
  "in_reply_to_status_id" : 829326234211450880,
  "created_at" : "2017-02-08 13:49:47 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236501066366, 8.627537625449591 ]
  },
  "id_str" : "829321934559141890",
  "text" : "Being forced to prepare 7 tables in Word when it decides to crash without having (auto)saved\u2026 (\u256F\u00B0\u25A1\u00B0\uFF09\u256F\uFE35 \u253B\u2501\u253B",
  "id" : 829321934559141890,
  "created_at" : "2017-02-08 13:32:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829268461088100352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17248339833331, 8.62758056393398 ]
  },
  "id_str" : "829270624736526337",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette yes, but guess that\u2019s less of an issue for the big decreases. :)",
  "id" : 829270624736526337,
  "in_reply_to_status_id" : 829268461088100352,
  "created_at" : "2017-02-08 10:08:18 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/EDs2Jcy4pd",
      "expanded_url" : "http:\/\/content.presentermedia.com\/files\/animsp\/00002000\/2681\/colored_business_pie_elevate_md_wm.gif",
      "display_url" : "content.presentermedia.com\/files\/animsp\/0\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "829268130065219585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17251347680545, 8.627586440482942 ]
  },
  "id_str" : "829268962353496065",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette would have been better like that. https:\/\/t.co\/EDs2Jcy4pd :D",
  "id" : 829268962353496065,
  "in_reply_to_status_id" : 829268130065219585,
  "created_at" : "2017-02-08 10:01:42 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/tFUPGgOp2G",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/AZemObXVMo4mY\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/AZemObXV\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "829267390693253120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234124353802, 8.62757868395775 ]
  },
  "id_str" : "829267942592372736",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette reading the paper? https:\/\/t.co\/tFUPGgOp2G",
  "id" : 829267942592372736,
  "in_reply_to_status_id" : 829267390693253120,
  "created_at" : "2017-02-08 09:57:39 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829266888983269376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237924300666, 8.627496572469017 ]
  },
  "id_str" : "829267118067740672",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette not really, because the two top causes of death still make ~400 out of 100,00?",
  "id" : 829267118067740672,
  "in_reply_to_status_id" : 829266888983269376,
  "created_at" : "2017-02-08 09:54:22 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829258161152544769",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172351648204, 8.627616427197877 ]
  },
  "id_str" : "829258560936738817",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette the graph just shows the opposite I think? A smaller total % is accumulated by the biggest causes. So more ways to die.",
  "id" : 829258560936738817,
  "in_reply_to_status_id" : 829258161152544769,
  "created_at" : "2017-02-08 09:20:22 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "829249662297239553",
  "text" : "RT @gedankenstuecke: That awkward moment when you figure out that your partner has been misreading your \u2018kissing\u2019-emoticons as \u2018crying\u2019 for\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.06084941555721, 8.818510251871329 ]
    },
    "id_str" : "829030404011220993",
    "text" : "That awkward moment when you figure out that your partner has been misreading your \u2018kissing\u2019-emoticons as \u2018crying\u2019 for nearly a year.",
    "id" : 829030404011220993,
    "created_at" : "2017-02-07 18:13:45 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 829249662297239553,
  "created_at" : "2017-02-08 08:45:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 0, 13 ],
      "id_str" : "22200760",
      "id" : 22200760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829126981778288643",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0609862162154, 8.818523069809668 ]
  },
  "id_str" : "829215362243760130",
  "in_reply_to_user_id" : 22200760,
  "text" : "@vexedmuddler oh, thanks! I will happily wait for the results of that then!",
  "id" : 829215362243760130,
  "in_reply_to_status_id" : 829126981778288643,
  "created_at" : "2017-02-08 06:28:43 +0000",
  "in_reply_to_screen_name" : "vexedmuddler",
  "in_reply_to_user_id_str" : "22200760",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829106934867435520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06106915823351, 8.818492167859295 ]
  },
  "id_str" : "829111796816543744",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye let me know when you have some plans :)",
  "id" : 829111796816543744,
  "in_reply_to_status_id" : 829106934867435520,
  "created_at" : "2017-02-07 23:37:11 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829105995771166721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06089502949808, 8.81868437033611 ]
  },
  "id_str" : "829106059881172992",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye that\u2019s what they claim.",
  "id" : 829106059881172992,
  "in_reply_to_status_id" : 829105995771166721,
  "created_at" : "2017-02-07 23:14:23 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deaf Poets Society",
      "screen_name" : "thedeafpoets",
      "indices" : [ 3, 16 ],
      "id_str" : "734517577867755521",
      "id" : 734517577867755521
    }, {
      "name" : "Lydia X. Z. Brown",
      "screen_name" : "autistichoya",
      "indices" : [ 39, 52 ],
      "id_str" : "611121924",
      "id" : 611121924
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "autistic",
      "indices" : [ 72, 81 ]
    }, {
      "text" : "LGBT",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/AtcKFwnr0M",
      "expanded_url" : "http:\/\/ow.ly\/pzcv308JXju",
      "display_url" : "ow.ly\/pzcv308JXju"
    } ]
  },
  "geo" : { },
  "id_str" : "829103992055685120",
  "text" : "RT @thedeafpoets: Great interview with @autistichoya  and other awesome #autistic #LGBT folks! https:\/\/t.co\/AtcKFwnr0M https:\/\/t.co\/5Vbuykw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lydia X. Z. Brown",
        "screen_name" : "autistichoya",
        "indices" : [ 21, 34 ],
        "id_str" : "611121924",
        "id" : 611121924
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thedeafpoets\/status\/828994655417155587\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/5Vbuykw0aJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C4EuPrVWQAEx-8v.jpg",
        "id_str" : "828994653278060545",
        "id" : 828994653278060545,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C4EuPrVWQAEx-8v.jpg",
        "sizes" : [ {
          "h" : 463,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/5Vbuykw0aJ"
      } ],
      "hashtags" : [ {
        "text" : "autistic",
        "indices" : [ 54, 63 ]
      }, {
        "text" : "LGBT",
        "indices" : [ 64, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/AtcKFwnr0M",
        "expanded_url" : "http:\/\/ow.ly\/pzcv308JXju",
        "display_url" : "ow.ly\/pzcv308JXju"
      } ]
    },
    "geo" : { },
    "id_str" : "828994655417155587",
    "text" : "Great interview with @autistichoya  and other awesome #autistic #LGBT folks! https:\/\/t.co\/AtcKFwnr0M https:\/\/t.co\/5Vbuykw0aJ",
    "id" : 828994655417155587,
    "created_at" : "2017-02-07 15:51:42 +0000",
    "user" : {
      "name" : "Deaf Poets Society",
      "screen_name" : "thedeafpoets",
      "protected" : false,
      "id_str" : "734517577867755521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765673042546610176\/HbABxnLx_normal.jpg",
      "id" : 734517577867755521,
      "verified" : false
    }
  },
  "id" : 829103992055685120,
  "created_at" : "2017-02-07 23:06:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/JXsBULqyen",
      "expanded_url" : "https:\/\/twitter.com\/freakonometrics\/status\/829069224421257217",
      "display_url" : "twitter.com\/freakonometric\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084174810729, 8.818712546480452 ]
  },
  "id_str" : "829093928322400257",
  "text" : "Somewhere stacked in there: heart attack from seeing to many hard-to-read stacked bar charts. https:\/\/t.co\/JXsBULqyen",
  "id" : 829093928322400257,
  "created_at" : "2017-02-07 22:26:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "_katsel",
      "indices" : [ 0, 8 ],
      "id_str" : "892038837052076033",
      "id" : 892038837052076033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829060208471240705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06090596775125, 8.818804589286609 ]
  },
  "id_str" : "829069021781880833",
  "in_reply_to_user_id" : 730326143295959040,
  "text" : "@_katsel congrats!",
  "id" : 829069021781880833,
  "in_reply_to_status_id" : 829060208471240705,
  "created_at" : "2017-02-07 20:47:12 +0000",
  "in_reply_to_screen_name" : "katheyrina",
  "in_reply_to_user_id_str" : "730326143295959040",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829042161656201216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091416204318, 8.818818616541998 ]
  },
  "id_str" : "829052764684681216",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik as tears of joy. :)",
  "id" : 829052764684681216,
  "in_reply_to_status_id" : 829042161656201216,
  "created_at" : "2017-02-07 19:42:36 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829042161656201216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06101082493674, 8.818647055479675 ]
  },
  "id_str" : "829042299007021056",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik let me check :D",
  "id" : 829042299007021056,
  "in_reply_to_status_id" : 829042161656201216,
  "created_at" : "2017-02-07 19:01:01 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 23, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/X56eewS7mX",
      "expanded_url" : "https:\/\/twitter.com\/MozillaScience\/status\/829039146828050432",
      "display_url" : "twitter.com\/MozillaScience\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "829040135450812416",
  "text" : "See some of you there! #mozwow \uD83D\uDE0D https:\/\/t.co\/X56eewS7mX",
  "id" : 829040135450812416,
  "created_at" : "2017-02-07 18:52:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829033251306143745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06094555344955, 8.818577616561555 ]
  },
  "id_str" : "829033350077804545",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField funny enough that\u2019s literally what I sent over yesterday!",
  "id" : 829033350077804545,
  "in_reply_to_status_id" : 829033251306143745,
  "created_at" : "2017-02-07 18:25:28 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829032991519281156",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06111159386088, 8.81873577859718 ]
  },
  "id_str" : "829033114408255489",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField \u201CI love you! \uD83D\uDE2D\uD83D\uDE25\u201D",
  "id" : 829033114408255489,
  "in_reply_to_status_id" : 829032991519281156,
  "created_at" : "2017-02-07 18:24:31 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829032281213960192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06095223697076, 8.818559382719853 ]
  },
  "id_str" : "829032803945807872",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField it\u2019s more hilarious than anything else. Should go back through all comm logs and see where it influenced things :D",
  "id" : 829032803945807872,
  "in_reply_to_status_id" : 829032281213960192,
  "created_at" : "2017-02-07 18:23:17 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "829030615383175174",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06101396405143, 8.818557662897573 ]
  },
  "id_str" : "829031121031659521",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess \u201Cwhops\u201D! \uD83D\uDE02",
  "id" : 829031121031659521,
  "in_reply_to_status_id" : 829030615383175174,
  "created_at" : "2017-02-07 18:16:36 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Shipman",
      "screen_name" : "annashipman",
      "indices" : [ 3, 15 ],
      "id_str" : "116177839",
      "id" : 116177839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "829030838054580224",
  "text" : "RT @annashipman: The BBC is looking for female experts in a number of fields (including tech) to be on air, &amp; are offering training: https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/wRl0cYykyb",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/academy\/news\/article\/art20170127102127476",
        "display_url" : "bbc.co.uk\/academy\/news\/a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "828575507792945152",
    "text" : "The BBC is looking for female experts in a number of fields (including tech) to be on air, &amp; are offering training: https:\/\/t.co\/wRl0cYykyb",
    "id" : 828575507792945152,
    "created_at" : "2017-02-06 12:06:09 +0000",
    "user" : {
      "name" : "Anna Shipman",
      "screen_name" : "annashipman",
      "protected" : false,
      "id_str" : "116177839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625284315392438276\/XF7Ag8O-_normal.jpg",
      "id" : 116177839,
      "verified" : false
    }
  },
  "id" : 829030838054580224,
  "created_at" : "2017-02-07 18:15:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Genome Biology",
      "screen_name" : "GenomeBiology",
      "indices" : [ 3, 17 ],
      "id_str" : "115039678",
      "id" : 115039678
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KSmicrobiome",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "829030556579069952",
  "text" : "RT @GenomeBiology: KP: microbiome databases show same bias as genome sequence databases ie too many US\/Europe #KSmicrobiome",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KSmicrobiome",
        "indices" : [ 91, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "829016592340090880",
    "text" : "KP: microbiome databases show same bias as genome sequence databases ie too many US\/Europe #KSmicrobiome",
    "id" : 829016592340090880,
    "created_at" : "2017-02-07 17:18:52 +0000",
    "user" : {
      "name" : "Genome Biology",
      "screen_name" : "GenomeBiology",
      "protected" : false,
      "id_str" : "115039678",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/917700997350346752\/Hv2vqWsQ_normal.jpg",
      "id" : 115039678,
      "verified" : true
    }
  },
  "id" : 829030556579069952,
  "created_at" : "2017-02-07 18:14:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084941555721, 8.818510251871329 ]
  },
  "id_str" : "829030404011220993",
  "text" : "That awkward moment when you figure out that your partner has been misreading your \u2018kissing\u2019-emoticons as \u2018crying\u2019 for nearly a year.",
  "id" : 829030404011220993,
  "created_at" : "2017-02-07 18:13:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "indices" : [ 3, 10 ],
      "id_str" : "47876842",
      "id" : 47876842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/5cfcfTCwXh",
      "expanded_url" : "http:\/\/bjoern.brembs.net\/2017\/02\/open-science-too-much-talk-too-little-action\/",
      "display_url" : "bjoern.brembs.net\/2017\/02\/open-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "828916347795017729",
  "text" : "RT @brembs: Open Science: Too much talk, too little\u00A0action https:\/\/t.co\/5cfcfTCwXh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/5cfcfTCwXh",
        "expanded_url" : "http:\/\/bjoern.brembs.net\/2017\/02\/open-science-too-much-talk-too-little-action\/",
        "display_url" : "bjoern.brembs.net\/2017\/02\/open-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "827536397653331968",
    "text" : "Open Science: Too much talk, too little\u00A0action https:\/\/t.co\/5cfcfTCwXh",
    "id" : 827536397653331968,
    "created_at" : "2017-02-03 15:17:06 +0000",
    "user" : {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "protected" : false,
      "id_str" : "47876842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524937570984013824\/uPSUsTcU_normal.png",
      "id" : 47876842,
      "verified" : false
    }
  },
  "id" : 828916347795017729,
  "created_at" : "2017-02-07 10:40:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828891215680647168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235984365225, 8.627515456036821 ]
  },
  "id_str" : "828892111722385408",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette me neither, but now I know what tool to use for my Logos :D",
  "id" : 828892111722385408,
  "in_reply_to_status_id" : 828891215680647168,
  "created_at" : "2017-02-07 09:04:14 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/V9rgeb1YcF",
      "expanded_url" : "https:\/\/twitter.com\/keyboardpipette\/status\/828862644199227392",
      "display_url" : "twitter.com\/keyboardpipett\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05947646908768, 8.817735841090812 ]
  },
  "id_str" : "828871066969899008",
  "text" : "Admit it, you just want to use it because of the name! https:\/\/t.co\/V9rgeb1YcF",
  "id" : 828871066969899008,
  "created_at" : "2017-02-07 07:40:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gender Census",
      "screen_name" : "nonbinarystats",
      "indices" : [ 3, 18 ],
      "id_str" : "924592985874030592",
      "id" : 924592985874030592
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nonbinary",
      "indices" : [ 122, 132 ]
    }, {
      "text" : "trans",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/IjKXVGyBbB",
      "expanded_url" : "http:\/\/www.smartsurvey.co.uk\/s\/NBGQ2017\/",
      "display_url" : "smartsurvey.co.uk\/s\/NBGQ2017\/"
    } ]
  },
  "geo" : { },
  "id_str" : "828759081640984576",
  "text" : "RT @NonbinaryStats: The Nonbinary\/Genderqueer Stats Survey 2017 is now open until 27th February! https:\/\/t.co\/IjKXVGyBbB\n\n#nonbinary #trans\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nonbinary",
        "indices" : [ 102, 112 ]
      }, {
        "text" : "trans",
        "indices" : [ 113, 119 ]
      }, {
        "text" : "genderqueer",
        "indices" : [ 120, 132 ]
      }, {
        "text" : "survey",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/IjKXVGyBbB",
        "expanded_url" : "http:\/\/www.smartsurvey.co.uk\/s\/NBGQ2017\/",
        "display_url" : "smartsurvey.co.uk\/s\/NBGQ2017\/"
      } ]
    },
    "geo" : { },
    "id_str" : "828642922434293761",
    "text" : "The Nonbinary\/Genderqueer Stats Survey 2017 is now open until 27th February! https:\/\/t.co\/IjKXVGyBbB\n\n#nonbinary #trans #genderqueer #survey",
    "id" : 828642922434293761,
    "created_at" : "2017-02-06 16:34:02 +0000",
    "user" : {
      "name" : "Gender Census",
      "screen_name" : "gendercensus",
      "protected" : false,
      "id_str" : "4906396203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711139630859558912\/tQkNONcZ_normal.jpg",
      "id" : 4906396203,
      "verified" : false
    }
  },
  "id" : 828759081640984576,
  "created_at" : "2017-02-07 00:15:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Friedrich",
      "screen_name" : "JoergFr",
      "indices" : [ 0, 8 ],
      "id_str" : "14508163",
      "id" : 14508163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828707595531730946",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06095332095767, 8.81858529140876 ]
  },
  "id_str" : "828723776137396224",
  "in_reply_to_user_id" : 14508163,
  "text" : "@JoergFr Die K\u00FCchenschr\u00E4nke im B\u00FCro &amp; ich haben eine \u00E4hnliche Beziehung. \uD83E\uDD15",
  "id" : 828723776137396224,
  "in_reply_to_status_id" : 828707595531730946,
  "created_at" : "2017-02-06 21:55:19 +0000",
  "in_reply_to_screen_name" : "JoergFr",
  "in_reply_to_user_id_str" : "14508163",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/CmAIuwVVfU",
      "expanded_url" : "http:\/\/www.newyorker.com\/magazine\/2017\/02\/13\/when-things-go-missing",
      "display_url" : "newyorker.com\/magazine\/2017\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "828702566234124289",
  "text" : "RT @wilbanks: \u201CWe are here to keep watch, not to keep.\u201D SHUT UP *YOU\u2019RE* CRYING https:\/\/t.co\/CmAIuwVVfU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/CmAIuwVVfU",
        "expanded_url" : "http:\/\/www.newyorker.com\/magazine\/2017\/02\/13\/when-things-go-missing",
        "display_url" : "newyorker.com\/magazine\/2017\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "828697634458234880",
    "text" : "\u201CWe are here to keep watch, not to keep.\u201D SHUT UP *YOU\u2019RE* CRYING https:\/\/t.co\/CmAIuwVVfU",
    "id" : 828697634458234880,
    "created_at" : "2017-02-06 20:11:27 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 828702566234124289,
  "created_at" : "2017-02-06 20:31:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828696750059819012",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06088488631588, 8.818534961547332 ]
  },
  "id_str" : "828696970910978050",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 it\u2019s the only RSS feed I really care to \u201Eread\u201C every single post from.",
  "id" : 828696970910978050,
  "in_reply_to_status_id" : 828696750059819012,
  "created_at" : "2017-02-06 20:08:48 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/6TIEIZzxAs",
      "expanded_url" : "http:\/\/dogswithtonguestickingoutalittle.tumblr.com\/post\/156639563659\/shadow?is_related_post=1",
      "display_url" : "\u2026thtonguestickingoutalittle.tumblr.com\/post\/156639563\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06089423489227, 8.818487544657287 ]
  },
  "id_str" : "828694037334999046",
  "text" : "someone looks like he\u2019s read the news https:\/\/t.co\/6TIEIZzxAs",
  "id" : 828694037334999046,
  "created_at" : "2017-02-06 19:57:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 0, 13 ],
      "id_str" : "22200760",
      "id" : 22200760
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 14, 24 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828676355139203072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06095461219636, 8.818814954780212 ]
  },
  "id_str" : "828676659553394689",
  "in_reply_to_user_id" : 22200760,
  "text" : "@vexedmuddler @Julie_B92 oh, thanks so much &lt;3",
  "id" : 828676659553394689,
  "in_reply_to_status_id" : 828676355139203072,
  "created_at" : "2017-02-06 18:48:06 +0000",
  "in_reply_to_screen_name" : "vexedmuddler",
  "in_reply_to_user_id_str" : "22200760",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 0, 13 ],
      "id_str" : "22200760",
      "id" : 22200760
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 14, 24 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828674918292344833",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06099142882948, 8.818622600428252 ]
  },
  "id_str" : "828675712483745794",
  "in_reply_to_user_id" : 22200760,
  "text" : "@vexedmuddler @Julie_B92 was adjustable one with a hemp(?) chord. But I\u2019ll happily get a new one. Can\u2019t find any on etsy though? :)",
  "id" : 828675712483745794,
  "in_reply_to_status_id" : 828674918292344833,
  "created_at" : "2017-02-06 18:44:20 +0000",
  "in_reply_to_screen_name" : "vexedmuddler",
  "in_reply_to_user_id_str" : "22200760",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 0, 13 ],
      "id_str" : "22200760",
      "id" : 22200760
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 14, 24 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828674012133916672",
  "geo" : { },
  "id_str" : "828674128735502340",
  "in_reply_to_user_id" : 22200760,
  "text" : "@vexedmuddler @Julie_B92 yes, i think the band just gave up after too much wearing it :D",
  "id" : 828674128735502340,
  "in_reply_to_status_id" : 828674012133916672,
  "created_at" : "2017-02-06 18:38:02 +0000",
  "in_reply_to_screen_name" : "vexedmuddler",
  "in_reply_to_user_id_str" : "22200760",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 0, 13 ],
      "id_str" : "22200760",
      "id" : 22200760
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 14, 24 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828650834372210688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17116046980971, 8.627684125684786 ]
  },
  "id_str" : "828655183173394433",
  "in_reply_to_user_id" : 22200760,
  "text" : "@vexedmuddler @Julie_B92 btw I totally love your art. Unfortunately lost my mitochondria bracelet at some point!",
  "id" : 828655183173394433,
  "in_reply_to_status_id" : 828650834372210688,
  "created_at" : "2017-02-06 17:22:45 +0000",
  "in_reply_to_screen_name" : "vexedmuddler",
  "in_reply_to_user_id_str" : "22200760",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 0, 13 ],
      "id_str" : "22200760",
      "id" : 22200760
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 14, 24 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828650834372210688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232886301024, 8.627521209904923 ]
  },
  "id_str" : "828652671020199937",
  "in_reply_to_user_id" : 22200760,
  "text" : "@vexedmuddler @Julie_B92 works fine for archiving. But it\u2019s not super discoverable compared to the former.",
  "id" : 828652671020199937,
  "in_reply_to_status_id" : 828650834372210688,
  "created_at" : "2017-02-06 17:12:47 +0000",
  "in_reply_to_screen_name" : "vexedmuddler",
  "in_reply_to_user_id_str" : "22200760",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 0, 13 ],
      "id_str" : "22200760",
      "id" : 22200760
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 14, 24 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828649801340293120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235361707918, 8.627480959258952 ]
  },
  "id_str" : "828650230686035968",
  "in_reply_to_user_id" : 22200760,
  "text" : "@vexedmuddler @Julie_B92 and for bacterial genome assemblies I personally still prefer NCBI Genome. :)",
  "id" : 828650230686035968,
  "in_reply_to_status_id" : 828649801340293120,
  "created_at" : "2017-02-06 17:03:05 +0000",
  "in_reply_to_screen_name" : "vexedmuddler",
  "in_reply_to_user_id_str" : "22200760",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 0, 13 ],
      "id_str" : "22200760",
      "id" : 22200760
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 14, 24 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/LiJlJcZN33",
      "expanded_url" : "http:\/\/www.ebi.ac.uk\/ena",
      "display_url" : "ebi.ac.uk\/ena"
    }, {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/6SB6kOyNVr",
      "expanded_url" : "https:\/\/www.ncbi.nlm.nih.gov\/sra",
      "display_url" : "ncbi.nlm.nih.gov\/sra"
    } ]
  },
  "in_reply_to_status_id_str" : "828649598306619392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234556204551, 8.62748696424361 ]
  },
  "id_str" : "828649842687741954",
  "in_reply_to_user_id" : 22200760,
  "text" : "@vexedmuddler @Julie_B92 read data to SRA\/ENA https:\/\/t.co\/LiJlJcZN33 https:\/\/t.co\/6SB6kOyNVr",
  "id" : 828649842687741954,
  "in_reply_to_status_id" : 828649598306619392,
  "created_at" : "2017-02-06 17:01:32 +0000",
  "in_reply_to_screen_name" : "vexedmuddler",
  "in_reply_to_user_id_str" : "22200760",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 0, 13 ],
      "id_str" : "22200760",
      "id" : 22200760
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 14, 24 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828638831909937152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233284301045, 8.627494935977067 ]
  },
  "id_str" : "828649315417591808",
  "in_reply_to_user_id" : 22200760,
  "text" : "@vexedmuddler @Julie_B92 technically correct, but not so useful answer: depends on the data.",
  "id" : 828649315417591808,
  "in_reply_to_status_id" : 828638831909937152,
  "created_at" : "2017-02-06 16:59:27 +0000",
  "in_reply_to_screen_name" : "vexedmuddler",
  "in_reply_to_user_id_str" : "22200760",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristina",
      "screen_name" : "biologeek",
      "indices" : [ 0, 10 ],
      "id_str" : "40189989",
      "id" : 40189989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828612661667590145",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233346376859, 8.627454949980399 ]
  },
  "id_str" : "828613572448108545",
  "in_reply_to_user_id" : 40189989,
  "text" : "@biologeek great, thanks! \uD83D\uDE0A",
  "id" : 828613572448108545,
  "in_reply_to_status_id" : 828612661667590145,
  "created_at" : "2017-02-06 14:37:25 +0000",
  "in_reply_to_screen_name" : "biologeek",
  "in_reply_to_user_id_str" : "40189989",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828599581013315585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236568799107, 8.627594121253502 ]
  },
  "id_str" : "828608616227864576",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice \uD83D\uDE4F all the best mate. You\u2019re invited over for drinks and\/or ice cream once you\u2019re done \uD83D\uDE02",
  "id" : 828608616227864576,
  "in_reply_to_status_id" : 828599581013315585,
  "created_at" : "2017-02-06 14:17:43 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristina",
      "screen_name" : "biologeek",
      "indices" : [ 0, 10 ],
      "id_str" : "40189989",
      "id" : 40189989
    }, {
      "name" : "FORTH_Hellas",
      "screen_name" : "FORTH_Hellas",
      "indices" : [ 11, 24 ],
      "id_str" : "2711593081",
      "id" : 2711593081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828570417984069632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233558575845, 8.627513802883175 ]
  },
  "id_str" : "828576785956737024",
  "in_reply_to_user_id" : 40189989,
  "text" : "@biologeek @FORTH_Hellas and sure, feel free to pass any information along and I\u2019ll see how it fits my schedule! :)",
  "id" : 828576785956737024,
  "in_reply_to_status_id" : 828570417984069632,
  "created_at" : "2017-02-06 12:11:14 +0000",
  "in_reply_to_screen_name" : "biologeek",
  "in_reply_to_user_id_str" : "40189989",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristina",
      "screen_name" : "biologeek",
      "indices" : [ 0, 10 ],
      "id_str" : "40189989",
      "id" : 40189989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828569659205156864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233558575845, 8.627513802883175 ]
  },
  "id_str" : "828576717157650432",
  "in_reply_to_user_id" : 40189989,
  "text" : "@biologeek oh, that\u2019s great to hear!",
  "id" : 828576717157650432,
  "in_reply_to_status_id" : 828569659205156864,
  "created_at" : "2017-02-06 12:10:58 +0000",
  "in_reply_to_screen_name" : "biologeek",
  "in_reply_to_user_id_str" : "40189989",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 3, 11 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Raniere Silva",
      "screen_name" : "rgaiacs",
      "indices" : [ 76, 84 ],
      "id_str" : "2784123889",
      "id" : 2784123889
    }, {
      "name" : "SSI - software.ac.uk",
      "screen_name" : "SoftwareSaved",
      "indices" : [ 85, 99 ],
      "id_str" : "136301916",
      "id" : 136301916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/a1tIdKZWK2",
      "expanded_url" : "https:\/\/www.software.ac.uk\/blog\/2017-01-30-google-summer-code-2017-starting-ways-get-involved",
      "display_url" : "software.ac.uk\/blog\/2017-01-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "828574272578789377",
  "text" : "RT @o_guest: Deadline for Google Summer of Code application is February 9th @rgaiacs @SoftwareSaved https:\/\/t.co\/a1tIdKZWK2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Raniere Silva",
        "screen_name" : "rgaiacs",
        "indices" : [ 63, 71 ],
        "id_str" : "2784123889",
        "id" : 2784123889
      }, {
        "name" : "SSI - software.ac.uk",
        "screen_name" : "SoftwareSaved",
        "indices" : [ 72, 86 ],
        "id_str" : "136301916",
        "id" : 136301916
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/a1tIdKZWK2",
        "expanded_url" : "https:\/\/www.software.ac.uk\/blog\/2017-01-30-google-summer-code-2017-starting-ways-get-involved",
        "display_url" : "software.ac.uk\/blog\/2017-01-3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "828556429648859137",
    "text" : "Deadline for Google Summer of Code application is February 9th @rgaiacs @SoftwareSaved https:\/\/t.co\/a1tIdKZWK2",
    "id" : 828556429648859137,
    "created_at" : "2017-02-06 10:50:21 +0000",
    "user" : {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "protected" : false,
      "id_str" : "3865005196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844972791732584453\/mdSj6vOd_normal.jpg",
      "id" : 3865005196,
      "verified" : false
    }
  },
  "id" : 828574272578789377,
  "created_at" : "2017-02-06 12:01:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristina",
      "screen_name" : "biologeek",
      "indices" : [ 0, 10 ],
      "id_str" : "40189989",
      "id" : 40189989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828559660634472448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233458469973, 8.62752240308278 ]
  },
  "id_str" : "828559819242164224",
  "in_reply_to_user_id" : 40189989,
  "text" : "@biologeek how\u2019s the Master\u2019s programme? :)",
  "id" : 828559819242164224,
  "in_reply_to_status_id" : 828559660634472448,
  "created_at" : "2017-02-06 11:03:49 +0000",
  "in_reply_to_screen_name" : "biologeek",
  "in_reply_to_user_id_str" : "40189989",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristina",
      "screen_name" : "biologeek",
      "indices" : [ 0, 10 ],
      "id_str" : "40189989",
      "id" : 40189989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828557102285279234",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231484640754, 8.627530812005887 ]
  },
  "id_str" : "828559784093818880",
  "in_reply_to_user_id" : 40189989,
  "text" : "@biologeek ah, nope, didn\u2019t get invited. But would be happy to give a talk there :D",
  "id" : 828559784093818880,
  "in_reply_to_status_id" : 828557102285279234,
  "created_at" : "2017-02-06 11:03:41 +0000",
  "in_reply_to_screen_name" : "biologeek",
  "in_reply_to_user_id_str" : "40189989",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristina",
      "screen_name" : "biologeek",
      "indices" : [ 0, 10 ],
      "id_str" : "40189989",
      "id" : 40189989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828547144034443264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17208577366437, 8.628175632293143 ]
  },
  "id_str" : "828553628323561473",
  "in_reply_to_user_id" : 40189989,
  "text" : "@biologeek nope, just went for fun, which event did I miss? :)",
  "id" : 828553628323561473,
  "in_reply_to_status_id" : 828547144034443264,
  "created_at" : "2017-02-06 10:39:13 +0000",
  "in_reply_to_screen_name" : "biologeek",
  "in_reply_to_user_id_str" : "40189989",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristina",
      "screen_name" : "biologeek",
      "indices" : [ 0, 10 ],
      "id_str" : "40189989",
      "id" : 40189989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828437257166139392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.8644857369809, 8.785617370166616 ]
  },
  "id_str" : "828504382102700032",
  "in_reply_to_user_id" : 40189989,
  "text" : "@biologeek unfortunately I\u2019m already back. Only spent the weekend over. But next time!",
  "id" : 828504382102700032,
  "in_reply_to_status_id" : 828437257166139392,
  "created_at" : "2017-02-06 07:23:32 +0000",
  "in_reply_to_screen_name" : "biologeek",
  "in_reply_to_user_id_str" : "40189989",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/iEoZllSHgW",
      "expanded_url" : "https:\/\/flic.kr\/p\/Rh9DVW",
      "display_url" : "flic.kr\/p\/Rh9DVW"
    } ]
  },
  "geo" : { },
  "id_str" : "828239533045141508",
  "text" : "Athens \u2714\uFE0F https:\/\/t.co\/iEoZllSHgW",
  "id" : 828239533045141508,
  "created_at" : "2017-02-05 13:51:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828196485267324928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.06384967142512, 23.79971747692055 ]
  },
  "id_str" : "828198126343299073",
  "in_reply_to_user_id" : 2968079445,
  "text" : "@AnneAdamPluen I\u2019m sure it will be fine!",
  "id" : 828198126343299073,
  "in_reply_to_status_id" : 828196485267324928,
  "created_at" : "2017-02-05 11:06:35 +0000",
  "in_reply_to_screen_name" : "AnneHTTP404",
  "in_reply_to_user_id_str" : "2968079445",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/828193169472884736\/photo\/1",
      "indices" : [ 128, 151 ],
      "url" : "https:\/\/t.co\/4dLWwjQN7N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C35VQ1TXAAAdVCf.jpg",
      "id_str" : "828193129157296128",
      "id" : 828193129157296128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C35VQ1TXAAAdVCf.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4dLWwjQN7N"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.06404730071003, 23.79988495224937 ]
  },
  "id_str" : "828193169472884736",
  "text" : "Praising your \u2018Goddess of Battle\u2019, but acting all surprised if her figurine is \u2018not dedicated by a warrior, but by a woman\u2019\u2026 \uD83E\uDD14\uD83D\uDE14 https:\/\/t.co\/4dLWwjQN7N",
  "id" : 828193169472884736,
  "created_at" : "2017-02-05 10:46:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828169528836227073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.0638845218654, 23.79975587759067 ]
  },
  "id_str" : "828188713284988928",
  "in_reply_to_user_id" : 2968079445,
  "text" : "@AnneAdamPluen any time you want!",
  "id" : 828188713284988928,
  "in_reply_to_status_id" : 828169528836227073,
  "created_at" : "2017-02-05 10:29:10 +0000",
  "in_reply_to_screen_name" : "AnneHTTP404",
  "in_reply_to_user_id_str" : "2968079445",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 0, 7 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828122003601289217",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.06392845861046, 23.79960238872819 ]
  },
  "id_str" : "828129279523307524",
  "in_reply_to_user_id" : 87993032,
  "text" : "@Koalha I can\u2019t imagine why not everybody would like the Germans :p",
  "id" : 828129279523307524,
  "in_reply_to_status_id" : 828122003601289217,
  "created_at" : "2017-02-05 06:33:00 +0000",
  "in_reply_to_screen_name" : "Koalha",
  "in_reply_to_user_id_str" : "87993032",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    }, {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 8, 15 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "828006916450373632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.06384071551708, 23.79978710665151 ]
  },
  "id_str" : "828007211335028736",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb @Koalha Schr\u00F6dinger\u2019s nationality. :p",
  "id" : 828007211335028736,
  "in_reply_to_status_id" : 828006916450373632,
  "created_at" : "2017-02-04 22:27:57 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 62, 69 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.06380799043743, 23.79968533294629 ]
  },
  "id_str" : "828003411945721858",
  "text" : "\u00ABLuckily you look so German, people mistake you for Finnish!\u00BB @Koalha, what\u2019s your verdict on that? \uD83D\uDE02",
  "id" : 828003411945721858,
  "created_at" : "2017-02-04 22:12:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.06380751895742, 23.7997398058637 ]
  },
  "id_str" : "827575617965195265",
  "text" : "Being greeted with \u201CHallo Kamerad!\u201D by a 91 year old makes you know exactly where &amp; how he picked up German\u2026 \uD83D\uDE25",
  "id" : 827575617965195265,
  "created_at" : "2017-02-03 17:52:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "827500813400436736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.93040216438279, 23.94213762136543 ]
  },
  "id_str" : "827513008532418560",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z glad you made it back online!",
  "id" : 827513008532418560,
  "in_reply_to_status_id" : 827500813400436736,
  "created_at" : "2017-02-03 13:44:10 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/827470210806464512\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/FMCM4fs8DT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C3vDwvtW8AAgjd-.jpg",
      "id_str" : "827470198760468480",
      "id" : 827470198760468480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C3vDwvtW8AAgjd-.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/FMCM4fs8DT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45391435861624, 8.556810634335672 ]
  },
  "id_str" : "827470210806464512",
  "text" : "Don\u2019t know that any instagram ads will safe the reputation of US immigration these days. https:\/\/t.co\/FMCM4fs8DT",
  "id" : 827470210806464512,
  "created_at" : "2017-02-03 10:54:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/CNHXHlzQO0",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BQC-x_CDVwf\/",
      "display_url" : "instagram.com\/p\/BQC-x_CDVwf\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4524731964, 8.56052491598 ]
  },
  "id_str" : "827468085414285312",
  "text" : "ZRH \u2708\uFE0F ATH @ Z\u00FCrich Airport https:\/\/t.co\/CNHXHlzQO0",
  "id" : 827468085414285312,
  "created_at" : "2017-02-03 10:45:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Williams",
      "screen_name" : "JasonWilliamsNY",
      "indices" : [ 0, 16 ],
      "id_str" : "1692248610",
      "id" : 1692248610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "827281388730609665",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35933838340266, 8.587767519716166 ]
  },
  "id_str" : "827281481319854080",
  "in_reply_to_user_id" : 1692248610,
  "text" : "@JasonWilliamsNY that is a perfect life goal to me!",
  "id" : 827281481319854080,
  "in_reply_to_status_id" : 827281388730609665,
  "created_at" : "2017-02-02 22:24:09 +0000",
  "in_reply_to_screen_name" : "JasonWilliamsNY",
  "in_reply_to_user_id_str" : "1692248610",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Williams",
      "screen_name" : "JasonWilliamsNY",
      "indices" : [ 0, 16 ],
      "id_str" : "1692248610",
      "id" : 1692248610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "827137982570385409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35933838340266, 8.587767519716166 ]
  },
  "id_str" : "827281013663338499",
  "in_reply_to_user_id" : 1692248610,
  "text" : "@JasonWilliamsNY that makes you weird :P",
  "id" : 827281013663338499,
  "in_reply_to_status_id" : 827137982570385409,
  "created_at" : "2017-02-02 22:22:18 +0000",
  "in_reply_to_screen_name" : "JasonWilliamsNY",
  "in_reply_to_user_id_str" : "1692248610",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felix Shaw",
      "screen_name" : "shaw2thefloor",
      "indices" : [ 0, 14 ],
      "id_str" : "2819790363",
      "id" : 2819790363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "827075458969776128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16167473281652, 8.657367710429348 ]
  },
  "id_str" : "827086155673907201",
  "in_reply_to_user_id" : 2819790363,
  "text" : "@shaw2thefloor didn\u2019t, will give it a try!",
  "id" : 827086155673907201,
  "in_reply_to_status_id" : 827075458969776128,
  "created_at" : "2017-02-02 09:28:00 +0000",
  "in_reply_to_screen_name" : "shaw2thefloor",
  "in_reply_to_user_id_str" : "2819790363",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coco's Tea Party",
      "screen_name" : "cocosteaparty",
      "indices" : [ 3, 17 ],
      "id_str" : "21591378",
      "id" : 21591378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "827058089014734848",
  "text" : "RT @cocosteaparty: The differences between the political coverage in Vogue and Teen Vogue right now is pretty stunning https:\/\/t.co\/CRofufF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cocosteaparty\/status\/826547851866038273\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/CRofufF1Yu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C3h84mDWEAEfoZY.jpg",
        "id_str" : "826547843351580673",
        "id" : 826547843351580673,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C3h84mDWEAEfoZY.jpg",
        "sizes" : [ {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        } ],
        "display_url" : "pic.twitter.com\/CRofufF1Yu"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/cocosteaparty\/status\/826547851866038273\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/CRofufF1Yu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C3h84mDWQAIEsYS.jpg",
        "id_str" : "826547843351592962",
        "id" : 826547843351592962,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C3h84mDWQAIEsYS.jpg",
        "sizes" : [ {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        } ],
        "display_url" : "pic.twitter.com\/CRofufF1Yu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "826547851866038273",
    "text" : "The differences between the political coverage in Vogue and Teen Vogue right now is pretty stunning https:\/\/t.co\/CRofufF1Yu",
    "id" : 826547851866038273,
    "created_at" : "2017-01-31 21:48:59 +0000",
    "user" : {
      "name" : "Coco's Tea Party",
      "screen_name" : "cocosteaparty",
      "protected" : false,
      "id_str" : "21591378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/889047298130542593\/WqEOIXgU_normal.jpg",
      "id" : 21591378,
      "verified" : false
    }
  },
  "id" : 827058089014734848,
  "created_at" : "2017-02-02 07:36:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1048134936716, 8.764405520651541 ]
  },
  "id_str" : "827055643924246528",
  "text" : "Germanness level: showing up 30 minutes early for a dentist appointment.",
  "id" : 827055643924246528,
  "created_at" : "2017-02-02 07:26:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/dvIHK1Dgiq",
      "expanded_url" : "https:\/\/twitter.com\/widdowquinn\/status\/826760452986327040",
      "display_url" : "twitter.com\/widdowquinn\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241376474213, 8.627520172371437 ]
  },
  "id_str" : "826805751825965056",
  "text" : "Missing answer: \u00ABRequired because people will ask you about it if you didn\u2019t include it in your analysis.\u00BB https:\/\/t.co\/dvIHK1Dgiq",
  "id" : 826805751825965056,
  "created_at" : "2017-02-01 14:53:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826780134027911168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232680228452, 8.627580379521023 ]
  },
  "id_str" : "826784997034037250",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski that\u2019s one of the numbers where I\u2019d just love to see the breakdown in the total population to see whether it\u2019s also 59% :D",
  "id" : 826784997034037250,
  "in_reply_to_status_id" : 826780134027911168,
  "created_at" : "2017-02-01 13:31:18 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826774400036851712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238474431541, 8.627501688517514 ]
  },
  "id_str" : "826774567968444417",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer cool, thanks!",
  "id" : 826774567968444417,
  "in_reply_to_status_id" : 826774400036851712,
  "created_at" : "2017-02-01 12:49:52 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826773838813814784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236282580242, 8.627455661870155 ]
  },
  "id_str" : "826774047576973312",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer works nicely but wants money after 25\/50 pages.",
  "id" : 826774047576973312,
  "in_reply_to_status_id" : 826773838813814784,
  "created_at" : "2017-02-01 12:47:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826773342388645888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236282580242, 8.627455661870155 ]
  },
  "id_str" : "826773948708831232",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin meh, none around to do it today.",
  "id" : 826773948708831232,
  "in_reply_to_status_id" : 826773342388645888,
  "created_at" : "2017-02-01 12:47:24 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EndsWithBang",
      "screen_name" : "audiophiel",
      "indices" : [ 0, 11 ],
      "id_str" : "714648944",
      "id" : 714648944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "826773379013283840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236282580242, 8.627455661870155 ]
  },
  "id_str" : "826773917859717120",
  "in_reply_to_user_id" : 714648944,
  "text" : "@audiophiel thanks!",
  "id" : 826773917859717120,
  "in_reply_to_status_id" : 826773379013283840,
  "created_at" : "2017-02-01 12:47:17 +0000",
  "in_reply_to_screen_name" : "audiophiel",
  "in_reply_to_user_id_str" : "714648944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239472679667, 8.627499820009264 ]
  },
  "id_str" : "826772965857574913",
  "text" : "Fighting another clusterfuck of supplementary materials. What are you folks using to get PDF tables into CSV?",
  "id" : 826772965857574913,
  "created_at" : "2017-02-01 12:43:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]