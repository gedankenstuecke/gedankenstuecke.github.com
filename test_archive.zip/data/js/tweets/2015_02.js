Grailbird.data.tweets_2015_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/QNYMQQPzeD",
      "expanded_url" : "https:\/\/medium.com\/notes-on-numbers\/the-fitbit-for-98ee2493e06c",
      "display_url" : "medium.com\/notes-on-numbe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571794112111898624",
  "text" : "Being the Mark Zuckerberg of open-source genetics I recommend reading: The Fitbit For\u2026 https:\/\/t.co\/QNYMQQPzeD",
  "id" : 571794112111898624,
  "created_at" : "2015-02-28 22:08:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571790813220376576",
  "geo" : { },
  "id_str" : "571792821079973888",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez my experience was mixed. But I\u2019ll try again.",
  "id" : 571792821079973888,
  "in_reply_to_status_id" : 571790813220376576,
  "created_at" : "2015-02-28 22:03:26 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571791977080987648",
  "geo" : { },
  "id_str" : "571792566850621440",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez anecdotal evidence suggests that it\u2019s much more activity because you have to run so far from gate to gate :D",
  "id" : 571792566850621440,
  "in_reply_to_status_id" : 571791977080987648,
  "created_at" : "2015-02-28 22:02:25 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571791500670996480",
  "geo" : { },
  "id_str" : "571791748722237440",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez nope, but I guess using shortest path between checkinA-&gt;checkinB is an okayish proxy for that purpose.",
  "id" : 571791748722237440,
  "in_reply_to_status_id" : 571791500670996480,
  "created_at" : "2015-02-28 21:59:10 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571790165871472640",
  "geo" : { },
  "id_str" : "571791269426536448",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez could give nice insights into how much travel was done by foot.",
  "id" : 571791269426536448,
  "in_reply_to_status_id" : 571790165871472640,
  "created_at" : "2015-02-28 21:57:16 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571790165871472640",
  "geo" : { },
  "id_str" : "571791117009731585",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez probably not, with you being such a rockstar ;-) you could try: (total travelled distance acc. 2 4sq) ~ (steps)",
  "id" : 571791117009731585,
  "in_reply_to_status_id" : 571790165871472640,
  "created_at" : "2015-02-28 21:56:40 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 10, 17 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571789784647147520",
  "geo" : { },
  "id_str" : "571790676737835008",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @mrgunn reminds me: still didn\u2019t manage to get access to min-by-min through their API\u2026",
  "id" : 571790676737835008,
  "in_reply_to_status_id" : 571789784647147520,
  "created_at" : "2015-02-28 21:54:55 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571789911470170112",
  "geo" : { },
  "id_str" : "571790026805272576",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez just some tweet somewhere, because no correlation at all (which is great workout-wise but rather boring)",
  "id" : 571790026805272576,
  "in_reply_to_status_id" : 571789911470170112,
  "created_at" : "2015-02-28 21:52:20 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571789528681222144",
  "geo" : { },
  "id_str" : "571789872727494658",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez great, I\u2019ll try to come up with something. Did a similar thing for my data a while back: fitbit steps + google latitude + weather.",
  "id" : 571789872727494658,
  "in_reply_to_status_id" : 571789528681222144,
  "created_at" : "2015-02-28 21:51:43 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571788956339068929",
  "geo" : { },
  "id_str" : "571789401707192320",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez sure, would be happy to play around with it. The usual caveat: not sure how much time I\u2019ll find for it.",
  "id" : 571789401707192320,
  "in_reply_to_status_id" : 571788956339068929,
  "created_at" : "2015-02-28 21:49:51 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/2FRC5DU9sn",
      "expanded_url" : "https:\/\/developer.forecast.io\/",
      "display_url" : "developer.forecast.io"
    } ]
  },
  "in_reply_to_status_id_str" : "571788399884947456",
  "geo" : { },
  "id_str" : "571789149990199297",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez for weather data I only toyed around with https:\/\/t.co\/2FRC5DU9sn so far. Basically just need to hand over lat\/long + date.",
  "id" : 571789149990199297,
  "in_reply_to_status_id" : 571788399884947456,
  "created_at" : "2015-02-28 21:48:51 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571788399884947456",
  "geo" : { },
  "id_str" : "571788726688489473",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez well, doing it over 4 years worth of data isn\u2019t too bad. :D",
  "id" : 571788726688489473,
  "in_reply_to_status_id" : 571788399884947456,
  "created_at" : "2015-02-28 21:47:10 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571788039367729152",
  "geo" : { },
  "id_str" : "571788218653392896",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez you should be able to get most of your data from 4sq\/swarm I guess.",
  "id" : 571788218653392896,
  "in_reply_to_status_id" : 571788039367729152,
  "created_at" : "2015-02-28 21:45:09 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571784977957855232",
  "geo" : { },
  "id_str" : "571787866164072449",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez do a correlation of your activity to the local weather conditions.",
  "id" : 571787866164072449,
  "in_reply_to_status_id" : 571784977957855232,
  "created_at" : "2015-02-28 21:43:45 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571765480957980672",
  "geo" : { },
  "id_str" : "571766751505092608",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime congratulations and all the best!",
  "id" : 571766751505092608,
  "in_reply_to_status_id" : 571765480957980672,
  "created_at" : "2015-02-28 20:19:51 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/4jcDSYgNeQ",
      "expanded_url" : "http:\/\/grantland.com\/features\/lifes-rich-pageant-meet-a-florida-man\/",
      "display_url" : "grantland.com\/features\/lifes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571645655212552192",
  "text" : "\u00ABThe moral of the story? My dick\u2019s fine! I mean, relatively; it didn\u2019t fall off\u00BB \u2013 On Florida Man http:\/\/t.co\/4jcDSYgNeQ",
  "id" : 571645655212552192,
  "created_at" : "2015-02-28 12:18:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.33267201509228, 8.760876073699402 ]
  },
  "id_str" : "571298474035163136",
  "text" : "\u00ABMoment, man sagt gar nicht \u2018Beckenbauer\u2019 um sich guten Appetit zu w\u00FCnschen?!\u00BB \u2014 \u00ABDoch, bevor man sich eine \u2018gute Rudi V\u00F6llerei\u2019 w\u00FCnscht\u2026\u00BB",
  "id" : 571298474035163136,
  "created_at" : "2015-02-27 13:19:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 80, 93 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/jaNlthW5JJ",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0116950",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571241679765839872",
  "text" : "Testing Various Phylogenetic Methods on Lexical Data http:\/\/t.co\/jaNlthW5JJ \/cc @PhilippBayer",
  "id" : 571241679765839872,
  "created_at" : "2015-02-27 09:33:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/jppixXZg74",
      "expanded_url" : "http:\/\/journals.plos.org\/ploscompbiol\/article?id=10.1371\/journal.pcbi.1004020",
      "display_url" : "journals.plos.org\/ploscompbiol\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571231454153322496",
  "text" : "Ten Simple Rules for Lifelong Learning, According to Hamming http:\/\/t.co\/jppixXZg74",
  "id" : 571231454153322496,
  "created_at" : "2015-02-27 08:52:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/R8h6K5jhhM",
      "expanded_url" : "http:\/\/www.newyorker.com\/humor\/daily-shouts\/switched-standing-desk-now",
      "display_url" : "newyorker.com\/humor\/daily-sh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570891699578380288",
  "text" : "\u00ABI even plan to switch to a treadmill desk, which is a great way to prepare for eventually using a swimming desk.\u00BB http:\/\/t.co\/R8h6K5jhhM",
  "id" : 570891699578380288,
  "created_at" : "2015-02-26 10:22:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Lehmann",
      "screen_name" : "clairlemon",
      "indices" : [ 3, 14 ],
      "id_str" : "1398479138",
      "id" : 1398479138
    }, {
      "name" : "Andrea Kuszewski \uD83E\uDDE0",
      "screen_name" : "AndreaKuszewski",
      "indices" : [ 103, 119 ],
      "id_str" : "15150453",
      "id" : 15150453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/CxfYiuZkR9",
      "expanded_url" : "http:\/\/www.sciencebasedmedicine.org\/psychology-journal-bans-significance-testing\/",
      "display_url" : "sciencebasedmedicine.org\/psychology-jou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570871287595335680",
  "text" : "RT @clairlemon: Wow. Journal in social psychology bans significance testing http:\/\/t.co\/CxfYiuZkR9 via @AndreaKuszewski",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrea Kuszewski \uD83E\uDDE0",
        "screen_name" : "AndreaKuszewski",
        "indices" : [ 87, 103 ],
        "id_str" : "15150453",
        "id" : 15150453
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/CxfYiuZkR9",
        "expanded_url" : "http:\/\/www.sciencebasedmedicine.org\/psychology-journal-bans-significance-testing\/",
        "display_url" : "sciencebasedmedicine.org\/psychology-jou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "570861898184273920",
    "text" : "Wow. Journal in social psychology bans significance testing http:\/\/t.co\/CxfYiuZkR9 via @AndreaKuszewski",
    "id" : 570861898184273920,
    "created_at" : "2015-02-26 08:24:17 +0000",
    "user" : {
      "name" : "Claire Lehmann",
      "screen_name" : "clairlemon",
      "protected" : false,
      "id_str" : "1398479138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835391075556610052\/Ek574eW1_normal.jpg",
      "id" : 1398479138,
      "verified" : true
    }
  },
  "id" : 570871287595335680,
  "created_at" : "2015-02-26 09:01:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570693826710409216",
  "geo" : { },
  "id_str" : "570733858435559425",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish totally agree, let\u2019s get matching ones.",
  "id" : 570733858435559425,
  "in_reply_to_status_id" : 570693826710409216,
  "created_at" : "2015-02-25 23:55:30 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Field",
      "screen_name" : "fiedawn",
      "indices" : [ 0, 8 ],
      "id_str" : "18589743",
      "id" : 18589743
    }, {
      "name" : "Paul Saarinen",
      "screen_name" : "taulpaul",
      "indices" : [ 9, 18 ],
      "id_str" : "82733",
      "id" : 82733
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 19, 29 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 30, 39 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570694975668809728",
  "geo" : { },
  "id_str" : "570695909094363136",
  "in_reply_to_user_id" : 18589743,
  "text" : "@fiedawn @taulpaul @eltonjohn @wilbanks and then there\u2019s Rs53576 which seems to be the usual suspect for anything social ;-)",
  "id" : 570695909094363136,
  "in_reply_to_status_id" : 570694975668809728,
  "created_at" : "2015-02-25 21:24:42 +0000",
  "in_reply_to_screen_name" : "fiedawn",
  "in_reply_to_user_id_str" : "18589743",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Field",
      "screen_name" : "fiedawn",
      "indices" : [ 0, 8 ],
      "id_str" : "18589743",
      "id" : 18589743
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 9, 19 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570653571093549057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11334044697475, 8.756205917818434 ]
  },
  "id_str" : "570654297467310081",
  "in_reply_to_user_id" : 18589743,
  "text" : "@fiedawn @eltonjohn great, looking forward to that :)",
  "id" : 570654297467310081,
  "in_reply_to_status_id" : 570653571093549057,
  "created_at" : "2015-02-25 18:39:21 +0000",
  "in_reply_to_screen_name" : "fiedawn",
  "in_reply_to_user_id_str" : "18589743",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Dawn Field",
      "screen_name" : "fiedawn",
      "indices" : [ 11, 19 ],
      "id_str" : "18589743",
      "id" : 18589743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570649860229206016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10850819023079, 8.765301376856568 ]
  },
  "id_str" : "570651050052608000",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn @fiedawn i think it\u2019s a pretty good read if you\u2019re new to the whole shebang (which I know isn\u2019t true in your case) :)",
  "id" : 570651050052608000,
  "in_reply_to_status_id" : 570649860229206016,
  "created_at" : "2015-02-25 18:26:27 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Faulkes",
      "screen_name" : "DoctorZen",
      "indices" : [ 3, 13 ],
      "id_str" : "16486812",
      "id" : 16486812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570621412421058561",
  "text" : "RT @DoctorZen: How much of your money have you spent on your science? Gas to field site? Computers? Pots and tin foil? http:\/\/t.co\/PB6IwWsP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SciSpends",
        "indices" : [ 127, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/PB6IwWsPKP",
        "expanded_url" : "http:\/\/www.southernfriedscience.com\/?p=18240",
        "display_url" : "southernfriedscience.com\/?p=18240"
      } ]
    },
    "geo" : { },
    "id_str" : "570618950423158784",
    "text" : "How much of your money have you spent on your science? Gas to field site? Computers? Pots and tin foil? http:\/\/t.co\/PB6IwWsPKP #SciSpends",
    "id" : 570618950423158784,
    "created_at" : "2015-02-25 16:18:54 +0000",
    "user" : {
      "name" : "Zen Faulkes",
      "screen_name" : "DoctorZen",
      "protected" : false,
      "id_str" : "16486812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821882802064867329\/7dtVmJ-0_normal.jpg",
      "id" : 16486812,
      "verified" : false
    }
  },
  "id" : 570621412421058561,
  "created_at" : "2015-02-25 16:28:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    }, {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 9, 20 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570596490491465728",
  "geo" : { },
  "id_str" : "570597124599099392",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish @EffyVayena thanks, that means a lot.",
  "id" : 570597124599099392,
  "in_reply_to_status_id" : 570596490491465728,
  "created_at" : "2015-02-25 14:52:10 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570546230750785536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236064589347, 8.627486685249961 ]
  },
  "id_str" : "570551658662510592",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer sweet, thanks!",
  "id" : 570551658662510592,
  "in_reply_to_status_id" : 570546230750785536,
  "created_at" : "2015-02-25 11:51:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/WRfNRISkeG",
      "expanded_url" : "http:\/\/graduable.com\/2015\/02\/24\/those-were-the-days-how-things-change-from-undergrad-to-doctorate\/",
      "display_url" : "graduable.com\/2015\/02\/24\/tho\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172237, 8.627493 ]
  },
  "id_str" : "570511162548338688",
  "text" : "How Things Change from Undergrad to Doctorate http:\/\/t.co\/WRfNRISkeG",
  "id" : 570511162548338688,
  "created_at" : "2015-02-25 09:10:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badomics",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/pNecKgU5v5",
      "expanded_url" : "http:\/\/www.methodomics.com",
      "display_url" : "methodomics.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235657795305, 8.627596414270517 ]
  },
  "id_str" : "570508685312716800",
  "text" : "After proclaiming I would quit my job if I was forced to use #badomics words I did some research &amp; found this gem: http:\/\/t.co\/pNecKgU5v5",
  "id" : 570508685312716800,
  "created_at" : "2015-02-25 09:00:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570506544204222464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16644323693561, 8.622070303554121 ]
  },
  "id_str" : "570506729777176576",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon yes, i think that\u2019s the most fun with that article. :D",
  "id" : 570506729777176576,
  "in_reply_to_status_id" : 570506544204222464,
  "created_at" : "2015-02-25 08:52:58 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/mLsv3uDRJH",
      "expanded_url" : "http:\/\/journals.plos.org\/plosmedicine\/article?id=10.1371\/journal.pmed.1001794",
      "display_url" : "journals.plos.org\/plosmedicine\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570504868387037184",
  "text" : "Open Access to Large Datasets Is Needed to Translate Knowledge of Cancer Heterogeneity into Better Patient Outcomes http:\/\/t.co\/mLsv3uDRJH",
  "id" : 570504868387037184,
  "created_at" : "2015-02-25 08:45:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/IS4jKJDTIv",
      "expanded_url" : "http:\/\/nymag.com\/daily\/intelligencer\/2015\/02\/jeff-wise-mh370-theory.html",
      "display_url" : "nymag.com\/daily\/intellig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570504246896033792",
  "text" : "How Crazy Am I to Think I Know Where MH370 Is? http:\/\/t.co\/IS4jKJDTIv",
  "id" : 570504246896033792,
  "created_at" : "2015-02-25 08:43:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 14, 24 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 25, 31 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570336753820659712",
  "geo" : { },
  "id_str" : "570336943101186049",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Fischblog @dvzrv I misread that as GOP and was kinda offended.",
  "id" : 570336943101186049,
  "in_reply_to_status_id" : 570336753820659712,
  "created_at" : "2015-02-24 21:38:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 25, 31 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/NXUfb3H3LI",
      "expanded_url" : "http:\/\/www.nature.com\/ncomms\/2014\/140512\/ncomms4873\/full\/ncomms4873.html",
      "display_url" : "nature.com\/ncomms\/2014\/14\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "570335703856361473",
  "geo" : { },
  "id_str" : "570335932898914304",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @PhilippBayer @dvzrv and somewhat fitting (well, at least there\u2019s fish in the title) http:\/\/t.co\/NXUfb3H3LI",
  "id" : 570335932898914304,
  "in_reply_to_status_id" : 570335703856361473,
  "created_at" : "2015-02-24 21:34:17 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 25, 31 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/N4urid8x96",
      "expanded_url" : "http:\/\/media0.giphy.com\/media\/NWqFfIIxiJyAE\/200.gif",
      "display_url" : "media0.giphy.com\/media\/NWqFfIIx\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "570334184931094528",
  "geo" : { },
  "id_str" : "570335327920852993",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @PhilippBayer @dvzrv this is much more up my alley! http:\/\/t.co\/N4urid8x96",
  "id" : 570335327920852993,
  "in_reply_to_status_id" : 570334184931094528,
  "created_at" : "2015-02-24 21:31:53 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 69, 82 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/uBI7XRjSiX",
      "expanded_url" : "http:\/\/www.openculture.com\/2015\/02\/hunter-s-thompson-life-coach-tips-for-finding-meaning-in-life.html",
      "display_url" : "openculture.com\/2015\/02\/hunter\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570293141447843840",
  "text" : "Hunter S. Thompson, Life Coach: Tips for Finding Meaning in Life \/cc @PhilippBayer  http:\/\/t.co\/uBI7XRjSiX",
  "id" : 570293141447843840,
  "created_at" : "2015-02-24 18:44:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570262960289005569",
  "text" : "\u00ABSure, I\u2019m a bash ninja. Every time someone asks for help with bash programming I try to make myself invisible as soon as possible.\u00BB",
  "id" : 570262960289005569,
  "created_at" : "2015-02-24 16:44:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/ac11ByJqug",
      "expanded_url" : "http:\/\/media2.giphy.com\/media\/bkRUcem1R9eCI\/200.gif",
      "display_url" : "media2.giphy.com\/media\/bkRUcem1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570166500755185664",
  "text" : "s\/internet \/\/ http:\/\/t.co\/ac11ByJqug",
  "id" : 570166500755185664,
  "created_at" : "2015-02-24 10:21:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 62, 75 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/062gtDWMLM",
      "expanded_url" : "http:\/\/www.pnas.org\/content\/112\/7\/2097",
      "display_url" : "pnas.org\/content\/112\/7\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570151175879835648",
  "text" : "Rate of language evolution is affected by population size \/cc @PhilippBayer http:\/\/t.co\/062gtDWMLM",
  "id" : 570151175879835648,
  "created_at" : "2015-02-24 09:20:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0410\u043D\u0430\u0441\u0442\u0430\u0441\u0438\u044F \u041F\u0440\u0438\u0432\u043E\u043B\u0436\u043D\u0430\u044F",
      "screen_name" : "Wutbuergerin",
      "indices" : [ 3, 16 ],
      "id_str" : "224452301",
      "id" : 224452301
    }, {
      "name" : "Muki Haklay",
      "screen_name" : "mhaklay",
      "indices" : [ 89, 97 ],
      "id_str" : "16080324",
      "id" : 16080324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/cLWeOVJO1o",
      "expanded_url" : "http:\/\/buff.ly\/17thLiZ",
      "display_url" : "buff.ly\/17thLiZ"
    } ]
  },
  "geo" : { },
  "id_str" : "570147032297549825",
  "text" : "RT @Wutbuergerin: Citizen Science and Policy: A European Perspective | Wilson Center, by @mhaklay\nhttp:\/\/t.co\/cLWeOVJO1o (via @lay_research\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Muki Haklay",
        "screen_name" : "mhaklay",
        "indices" : [ 71, 79 ],
        "id_str" : "16080324",
        "id" : 16080324
      }, {
        "name" : "lay_researcher",
        "screen_name" : "lay_researcher",
        "indices" : [ 108, 123 ],
        "id_str" : "2794586133",
        "id" : 2794586133
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/cLWeOVJO1o",
        "expanded_url" : "http:\/\/buff.ly\/17thLiZ",
        "display_url" : "buff.ly\/17thLiZ"
      } ]
    },
    "geo" : { },
    "id_str" : "570146641556189184",
    "text" : "Citizen Science and Policy: A European Perspective | Wilson Center, by @mhaklay\nhttp:\/\/t.co\/cLWeOVJO1o (via @lay_researcher)",
    "id" : 570146641556189184,
    "created_at" : "2015-02-24 09:02:06 +0000",
    "user" : {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "protected" : false,
      "id_str" : "201632630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927171665917890561\/w5htgqHc_normal.jpg",
      "id" : 201632630,
      "verified" : false
    }
  },
  "id" : 570147032297549825,
  "created_at" : "2015-02-24 09:03:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570146370734182400",
  "geo" : { },
  "id_str" : "570146621633241088",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv yeah, it\u2019s somewhat unclear atm, but I might come to Berlin before that date.",
  "id" : 570146621633241088,
  "in_reply_to_status_id" : 570146370734182400,
  "created_at" : "2015-02-24 09:02:02 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/IRuhl8DTcV",
      "expanded_url" : "https:\/\/medium.com\/@medialab\/does-the-breast-pump-still-suck-64e40eba6aec",
      "display_url" : "medium.com\/@medialab\/does\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570146097080995841",
  "text" : "Does the Breast Pump Still Suck? https:\/\/t.co\/IRuhl8DTcV",
  "id" : 570146097080995841,
  "created_at" : "2015-02-24 08:59:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570012175563165696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067263543929, 8.759890021521153 ]
  },
  "id_str" : "570112664430620675",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv uh, I might be traveling at the time, but we will see.",
  "id" : 570112664430620675,
  "in_reply_to_status_id" : 570012175563165696,
  "created_at" : "2015-02-24 06:47:06 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570009481456836608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066598999998, 8.759902099999998 ]
  },
  "id_str" : "570009749749702657",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv cool, when in April?",
  "id" : 570009749749702657,
  "in_reply_to_status_id" : 570009481456836608,
  "created_at" : "2015-02-23 23:58:09 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 133, 139 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/71YOc9l0V8",
      "expanded_url" : "http:\/\/fusion.net\/story\/47945\/this-guy-is-the-mark-zuckerberg-of-open-source-genetics\/",
      "display_url" : "fusion.net\/story\/47945\/th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "569934165887623168",
  "text" : "\u00ABThis guy is the Mark Zuckerberg of open-source\u00A0genetics\u00BB Not sure if that\u2019s a comparison I really favor. http:\/\/t.co\/71YOc9l0V8 \/cc @dvzrv",
  "id" : 569934165887623168,
  "created_at" : "2015-02-23 18:57:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miss Bosy",
      "screen_name" : "Ertraeglichkeit",
      "indices" : [ 0, 16 ],
      "id_str" : "4004999973",
      "id" : 4004999973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/9gHdVe7mt5",
      "expanded_url" : "http:\/\/www.tagesanzeiger.ch\/wissen\/medizin-und-psychologie\/Billige-Forschung-dank-Gentests\/story\/15817263",
      "display_url" : "tagesanzeiger.ch\/wissen\/medizin\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "569909709639176193",
  "geo" : { },
  "id_str" : "569909834017079296",
  "in_reply_to_user_id" : 127577609,
  "text" : "@Ertraeglichkeit ah, danke. H\u00E4tte auch dieser sein k\u00F6nnen ;-) http:\/\/t.co\/9gHdVe7mt5",
  "id" : 569909834017079296,
  "in_reply_to_status_id" : 569909709639176193,
  "created_at" : "2015-02-23 17:21:07 +0000",
  "in_reply_to_screen_name" : "nattsuhon",
  "in_reply_to_user_id_str" : "127577609",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miss Bosy",
      "screen_name" : "Ertraeglichkeit",
      "indices" : [ 0, 16 ],
      "id_str" : "4004999973",
      "id" : 4004999973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569908805145899009",
  "geo" : { },
  "id_str" : "569908920992604160",
  "in_reply_to_user_id" : 127577609,
  "text" : "@Ertraeglichkeit auf was bezieht sich dein Tweet? :-)",
  "id" : 569908920992604160,
  "in_reply_to_status_id" : 569908805145899009,
  "created_at" : "2015-02-23 17:17:29 +0000",
  "in_reply_to_screen_name" : "nattsuhon",
  "in_reply_to_user_id_str" : "127577609",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prash Suravajhala",
      "screen_name" : "prashbio",
      "indices" : [ 3, 12 ],
      "id_str" : "49546022",
      "id" : 49546022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/zrWnTIJqoT",
      "expanded_url" : "http:\/\/wp.me\/ph9ob-1Gg",
      "display_url" : "wp.me\/ph9ob-1Gg"
    } ]
  },
  "geo" : { },
  "id_str" : "569810801575497728",
  "text" : "RT @prashbio: Winston Hide, is moving to Sheffield and is looking for a few good computational biologists ...: http:\/\/t.co\/zrWnTIJqoT via @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
        "screen_name" : "phylogenomics",
        "indices" : [ 124, 138 ],
        "id_str" : "15154811",
        "id" : 15154811
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/zrWnTIJqoT",
        "expanded_url" : "http:\/\/wp.me\/ph9ob-1Gg",
        "display_url" : "wp.me\/ph9ob-1Gg"
      } ]
    },
    "geo" : { },
    "id_str" : "569773744853524480",
    "text" : "Winston Hide, is moving to Sheffield and is looking for a few good computational biologists ...: http:\/\/t.co\/zrWnTIJqoT via @phylogenomics",
    "id" : 569773744853524480,
    "created_at" : "2015-02-23 08:20:21 +0000",
    "user" : {
      "name" : "Prash Suravajhala",
      "screen_name" : "prashbio",
      "protected" : false,
      "id_str" : "49546022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621244056035655680\/XX8S7DhJ_normal.jpg",
      "id" : 49546022,
      "verified" : false
    }
  },
  "id" : 569810801575497728,
  "created_at" : "2015-02-23 10:47:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "Ernst Hafen",
      "screen_name" : "ehafen",
      "indices" : [ 12, 19 ],
      "id_str" : "159891548",
      "id" : 159891548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569532130960805891",
  "geo" : { },
  "id_str" : "569551952687849472",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena @ehafen wow, congratulations. Well deserved! :)",
  "id" : 569551952687849472,
  "in_reply_to_status_id" : 569532130960805891,
  "created_at" : "2015-02-22 17:39:01 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 53, 66 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/H4Rvqg4qb0",
      "expanded_url" : "https:\/\/egtheory.wordpress.com\/2015\/02\/21\/pairwise-public-goods\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ResearchBloggingMathematicsEnglish+%28Research+Blogging+-+English+-+Mathematics%29",
      "display_url" : "egtheory.wordpress.com\/2015\/02\/21\/pai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "569453539921154048",
  "text" : "Pairwise games as a special case of public goods \/cc @PhilippBayer  https:\/\/t.co\/H4Rvqg4qb0",
  "id" : 569453539921154048,
  "created_at" : "2015-02-22 11:07:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066598999932, 8.759902100001714 ]
  },
  "id_str" : "569446011057405953",
  "text" : "\u00ABTon Steine Scherben sind wie Mate. Man gew\u00F6hnt sich dran.\u00BB",
  "id" : 569446011057405953,
  "created_at" : "2015-02-22 10:38:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "indices" : [ 3, 12 ],
      "id_str" : "1205345400",
      "id" : 1205345400
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569267585033891841",
  "text" : "RT @DanGraur: A Phylogenetic Tree of Supreme Court Decisions #SCOTUS - The United States Supreme Court is composed of... http:\/\/t.co\/FBwVvS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 47, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/FBwVvSXw9f",
        "expanded_url" : "http:\/\/tmblr.co\/ZNTBYs1e1iCnK",
        "display_url" : "tmblr.co\/ZNTBYs1e1iCnK"
      } ]
    },
    "geo" : { },
    "id_str" : "569267050935422976",
    "text" : "A Phylogenetic Tree of Supreme Court Decisions #SCOTUS - The United States Supreme Court is composed of... http:\/\/t.co\/FBwVvSXw9f",
    "id" : 569267050935422976,
    "created_at" : "2015-02-21 22:46:56 +0000",
    "user" : {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "protected" : false,
      "id_str" : "1205345400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822591216776835072\/IO7mOPZQ_normal.jpg",
      "id" : 1205345400,
      "verified" : false
    }
  },
  "id" : 569267585033891841,
  "created_at" : "2015-02-21 22:49:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 3, 15 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/AiNtw1BD6d",
      "expanded_url" : "https:\/\/news.ycombinator.com\/item?id=9086648",
      "display_url" : "news.ycombinator.com\/item?id=9086648"
    } ]
  },
  "geo" : { },
  "id_str" : "569234061090267137",
  "text" : "RT @helgerausch: Trolling HN: https:\/\/t.co\/AiNtw1BD6d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/AiNtw1BD6d",
        "expanded_url" : "https:\/\/news.ycombinator.com\/item?id=9086648",
        "display_url" : "news.ycombinator.com\/item?id=9086648"
      } ]
    },
    "geo" : { },
    "id_str" : "569225284836327424",
    "text" : "Trolling HN: https:\/\/t.co\/AiNtw1BD6d",
    "id" : 569225284836327424,
    "created_at" : "2015-02-21 20:00:58 +0000",
    "user" : {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "protected" : false,
      "id_str" : "52747896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841604882352201729\/O7uP_eHQ_normal.jpg",
      "id" : 52747896,
      "verified" : false
    }
  },
  "id" : 569234061090267137,
  "created_at" : "2015-02-21 20:35:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 0, 8 ],
      "id_str" : "114220397",
      "id" : 114220397
    }, {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 38, 47 ],
      "id_str" : "224631899",
      "id" : 224631899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569176093862825984",
  "geo" : { },
  "id_str" : "569178850682384384",
  "in_reply_to_user_id" : 114220397,
  "text" : "@branleb @levudev Post the chatlog to @figshare and it will get an DOI you should be able to cite. :p",
  "id" : 569178850682384384,
  "in_reply_to_status_id" : 569176093862825984,
  "created_at" : "2015-02-21 16:56:27 +0000",
  "in_reply_to_screen_name" : "branleb",
  "in_reply_to_user_id_str" : "114220397",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/dhQAQSzB1u",
      "expanded_url" : "http:\/\/instagram.com\/p\/zXMxHtBwow\/",
      "display_url" : "instagram.com\/p\/zXMxHtBwow\/"
    } ]
  },
  "geo" : { },
  "id_str" : "569104805643337728",
  "text" : "Guess who doesn't enjoy the new Caj\u00F3n http:\/\/t.co\/dhQAQSzB1u",
  "id" : 569104805643337728,
  "created_at" : "2015-02-21 12:02:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/69SWY2P0mj",
      "expanded_url" : "http:\/\/www.nature.com\/news\/sex-redefined-1.16943",
      "display_url" : "nature.com\/news\/sex-redef\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568751932539596800",
  "text" : "RT @PhilippBayer: Are two sexes not enough for humans? http:\/\/t.co\/69SWY2P0mj (so many fun, strange cases!)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/69SWY2P0mj",
        "expanded_url" : "http:\/\/www.nature.com\/news\/sex-redefined-1.16943",
        "display_url" : "nature.com\/news\/sex-redef\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "568480513041821696",
    "text" : "Are two sexes not enough for humans? http:\/\/t.co\/69SWY2P0mj (so many fun, strange cases!)",
    "id" : 568480513041821696,
    "created_at" : "2015-02-19 18:41:30 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 568751932539596800,
  "created_at" : "2015-02-20 12:40:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/2rp7RYtycG",
      "expanded_url" : "http:\/\/www.countbayesie.com\/blog\/2015\/2\/18\/bayes-theorem-with-lego",
      "display_url" : "countbayesie.com\/blog\/2015\/2\/18\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568694465038311424",
  "text" : "Bayes' Theorem with Lego http:\/\/t.co\/2rp7RYtycG",
  "id" : 568694465038311424,
  "created_at" : "2015-02-20 08:51:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 86, 99 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/Hd4167U7Lv",
      "expanded_url" : "http:\/\/journals.plos.org\/plosgenetics\/article?id=10.1371\/journal.pgen.1004966",
      "display_url" : "journals.plos.org\/plosgenetics\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568679406396424192",
  "text" : "Genomics of Divergence along a Continuum of Parapatric Population Differentiation \/cc @PhilippBayer  http:\/\/t.co\/Hd4167U7Lv",
  "id" : 568679406396424192,
  "created_at" : "2015-02-20 07:51:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/lRjCLVuQPZ",
      "expanded_url" : "http:\/\/www.newyorker.com\/news\/daily-comment\/evolution-catechism?mbid=rss",
      "display_url" : "newyorker.com\/news\/daily-com\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568676708204843008",
  "text" : "\u00ABDo you have the courage to embrace an inarguable and obvious truth when it might cost you something to do so?\u00BB http:\/\/t.co\/lRjCLVuQPZ",
  "id" : 568676708204843008,
  "created_at" : "2015-02-20 07:41:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "indices" : [ 3, 18 ],
      "id_str" : "19416598",
      "id" : 19416598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568553244462616576",
  "text" : "RT @leonidkruglyak: \u201CBeing right does matter \u2014 and the science tribe has a long track record of getting things right in the end.\u201D http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/a67k3VnuH6",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/opinions\/why-science-is-so-hard-to-believe\/2015\/02\/12\/2ff8f064-b0a0-11e4-886b-c22184f27c35_story.html",
        "display_url" : "washingtonpost.com\/opinions\/why-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "568551585665523712",
    "text" : "\u201CBeing right does matter \u2014 and the science tribe has a long track record of getting things right in the end.\u201D http:\/\/t.co\/a67k3VnuH6",
    "id" : 568551585665523712,
    "created_at" : "2015-02-19 23:23:55 +0000",
    "user" : {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "protected" : false,
      "id_str" : "19416598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1095542276\/MyRecentPhoto_normal.jpg",
      "id" : 19416598,
      "verified" : false
    }
  },
  "id" : 568553244462616576,
  "created_at" : "2015-02-19 23:30:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568503832428355587",
  "text" : "RT @JBYoder: So, the deal is, if I don\u2019t have sex for a year, you\u2019ll let me let you take a pint of my blood? Where do I sign up? http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/uUSOidkkJZ",
        "expanded_url" : "http:\/\/www.slate.com\/blogs\/outward\/2015\/02\/19\/gay_men_should_try_the_celibacy_challenge_to_donate_blood_video.html",
        "display_url" : "slate.com\/blogs\/outward\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "568502151347081217",
    "text" : "So, the deal is, if I don\u2019t have sex for a year, you\u2019ll let me let you take a pint of my blood? Where do I sign up? http:\/\/t.co\/uUSOidkkJZ",
    "id" : 568502151347081217,
    "created_at" : "2015-02-19 20:07:29 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 568503832428355587,
  "created_at" : "2015-02-19 20:14:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "george davey smith",
      "screen_name" : "mendel_random",
      "indices" : [ 3, 17 ],
      "id_str" : "502151289",
      "id" : 502151289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568448455443664896",
  "text" : "RT @mendel_random: Smoking again associated with risk of being murdered .. paramilitary arm of health education taking direct action?  http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/wO0z8ybie3",
        "expanded_url" : "http:\/\/www.plosone.org\/article\/fetchObject.action?uri=info:doi\/10.1371\/journal.pone.0114852&representation=PDF",
        "display_url" : "plosone.org\/article\/fetchO\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "568447134808338433",
    "text" : "Smoking again associated with risk of being murdered .. paramilitary arm of health education taking direct action?  http:\/\/t.co\/wO0z8ybie3",
    "id" : 568447134808338433,
    "created_at" : "2015-02-19 16:28:52 +0000",
    "user" : {
      "name" : "george davey smith",
      "screen_name" : "mendel_random",
      "protected" : false,
      "id_str" : "502151289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1851264798\/mendy_normal.jpg",
      "id" : 502151289,
      "verified" : false
    }
  },
  "id" : 568448455443664896,
  "created_at" : "2015-02-19 16:34:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/qfZXhiLgPU",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/sa-visual\/2015\/02\/18\/pop-culture-pulsar-origin-story-of-joy-divisions-unknown-pleasures-album-cover-video\/?WT.mc_id=SA_Twitter",
      "display_url" : "blogs.scientificamerican.com\/sa-visual\/2015\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568407073698021376",
  "text" : "The Origin Story of Joy Division\u2019s Unknown Pleasures Album Cover http:\/\/t.co\/qfZXhiLgPU",
  "id" : 568407073698021376,
  "created_at" : "2015-02-19 13:49:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 92, 98 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/65UczdsnaT",
      "expanded_url" : "http:\/\/www.foobarflies.io\/pianette\/",
      "display_url" : "foobarflies.io\/pianette\/"
    } ]
  },
  "geo" : { },
  "id_str" : "568400045516693504",
  "text" : "\u00ABWe seamlessly transformed two classical upright pianos into Playstation 2 controllers\u00BB \/cc @dvzrv http:\/\/t.co\/65UczdsnaT",
  "id" : 568400045516693504,
  "created_at" : "2015-02-19 13:21:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/321S0TFVX0",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/02\/19\/opinion\/oliver-sacks-on-learning-he-has-terminal-cancer.html",
      "display_url" : "nytimes.com\/2015\/02\/19\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568343254221099009",
  "text" : "Oliver Sacks on Learning He Has Terminal Cancer http:\/\/t.co\/321S0TFVX0",
  "id" : 568343254221099009,
  "created_at" : "2015-02-19 09:36:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barnaby Skinner",
      "screen_name" : "BarJack",
      "indices" : [ 0, 8 ],
      "id_str" : "9375522",
      "id" : 9375522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568302890613395456",
  "geo" : { },
  "id_str" : "568329633168535552",
  "in_reply_to_user_id" : 9375522,
  "text" : "@BarJack und da sieht man das Problem mit veralteten Daten. Mittlerweile sollte es ex-smoker sein ;)",
  "id" : 568329633168535552,
  "in_reply_to_status_id" : 568302890613395456,
  "created_at" : "2015-02-19 08:41:58 +0000",
  "in_reply_to_screen_name" : "BarJack",
  "in_reply_to_user_id_str" : "9375522",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tages-Anzeiger",
      "screen_name" : "tagesanzeiger",
      "indices" : [ 10, 24 ],
      "id_str" : "202985146",
      "id" : 202985146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/9gHdVe7mt5",
      "expanded_url" : "http:\/\/www.tagesanzeiger.ch\/wissen\/medizin-und-psychologie\/Billige-Forschung-dank-Gentests\/story\/15817263",
      "display_url" : "tagesanzeiger.ch\/wissen\/medizin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568326966350389250",
  "text" : "The Swiss @tagesanzeiger has a (German) article on using data from openSNP and the ethical challenges it poses: http:\/\/t.co\/9gHdVe7mt5",
  "id" : 568326966350389250,
  "created_at" : "2015-02-19 08:31:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Field",
      "screen_name" : "fiedawn",
      "indices" : [ 0, 8 ],
      "id_str" : "18589743",
      "id" : 18589743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568148010892455937",
  "geo" : { },
  "id_str" : "568148161715445760",
  "in_reply_to_user_id" : 18589743,
  "text" : "@fiedawn that\u2019s a good match, human genetics is also only a part of my work.",
  "id" : 568148161715445760,
  "in_reply_to_status_id" : 568148010892455937,
  "created_at" : "2015-02-18 20:40:52 +0000",
  "in_reply_to_screen_name" : "fiedawn",
  "in_reply_to_user_id_str" : "18589743",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WDR aktuell",
      "screen_name" : "WDR",
      "indices" : [ 3, 7 ],
      "id_str" : "19609062",
      "id" : 19609062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/6sWbP7OtcR",
      "expanded_url" : "http:\/\/reportage.wdr.de\/onkel-willi",
      "display_url" : "reportage.wdr.de\/onkel-willi"
    } ]
  },
  "geo" : { },
  "id_str" : "568147816712945664",
  "text" : "RT @WDR: Onkel Willi. Stra\u00DFenmusiker. Lebensk\u00FCnstler. Lebende Legende. Noch. Tolle Multimedia-Reportage http:\/\/t.co\/6sWbP7OtcR http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WDR\/status\/568124216878485504\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/cd9wt7jFjN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-Jh9ukIMAEjWh4.jpg",
        "id_str" : "568124216101580801",
        "id" : 568124216101580801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-Jh9ukIMAEjWh4.jpg",
        "sizes" : [ {
          "h" : 430,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/cd9wt7jFjN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/6sWbP7OtcR",
        "expanded_url" : "http:\/\/reportage.wdr.de\/onkel-willi",
        "display_url" : "reportage.wdr.de\/onkel-willi"
      } ]
    },
    "geo" : { },
    "id_str" : "568124216878485504",
    "text" : "Onkel Willi. Stra\u00DFenmusiker. Lebensk\u00FCnstler. Lebende Legende. Noch. Tolle Multimedia-Reportage http:\/\/t.co\/6sWbP7OtcR http:\/\/t.co\/cd9wt7jFjN",
    "id" : 568124216878485504,
    "created_at" : "2015-02-18 19:05:43 +0000",
    "user" : {
      "name" : "WDR aktuell",
      "screen_name" : "WDR",
      "protected" : false,
      "id_str" : "19609062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/860059782534897664\/TKvANKjG_normal.jpg",
      "id" : 19609062,
      "verified" : true
    }
  },
  "id" : 568147816712945664,
  "created_at" : "2015-02-18 20:39:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Field",
      "screen_name" : "fiedawn",
      "indices" : [ 0, 8 ],
      "id_str" : "18589743",
      "id" : 18589743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568146902237220864",
  "geo" : { },
  "id_str" : "568147442031587328",
  "in_reply_to_user_id" : 18589743,
  "text" : "@fiedawn Biocode is now on my to-read list. Let me know if I can offer any help for the next one :)",
  "id" : 568147442031587328,
  "in_reply_to_status_id" : 568146902237220864,
  "created_at" : "2015-02-18 20:38:00 +0000",
  "in_reply_to_screen_name" : "fiedawn",
  "in_reply_to_user_id_str" : "18589743",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Field",
      "screen_name" : "fiedawn",
      "indices" : [ 0, 8 ],
      "id_str" : "18589743",
      "id" : 18589743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568146170226343936",
  "geo" : { },
  "id_str" : "568146432823336961",
  "in_reply_to_user_id" : 18589743,
  "text" : "@fiedawn Vielen Dank, I\u2019ll do so vice versa. :)",
  "id" : 568146432823336961,
  "in_reply_to_status_id" : 568146170226343936,
  "created_at" : "2015-02-18 20:33:59 +0000",
  "in_reply_to_screen_name" : "fiedawn",
  "in_reply_to_user_id_str" : "18589743",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Field",
      "screen_name" : "fiedawn",
      "indices" : [ 0, 8 ],
      "id_str" : "18589743",
      "id" : 18589743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568139908084310017",
  "geo" : { },
  "id_str" : "568143543275036675",
  "in_reply_to_user_id" : 18589743,
  "text" : "@fiedawn thanks for sharing :)",
  "id" : 568143543275036675,
  "in_reply_to_status_id" : 568139908084310017,
  "created_at" : "2015-02-18 20:22:30 +0000",
  "in_reply_to_screen_name" : "fiedawn",
  "in_reply_to_user_id_str" : "18589743",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/YTYIvsjg1o",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/02\/18\/the-city-in-cinema-videos-reve.html",
      "display_url" : "boingboing.net\/2015\/02\/18\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568041922813665280",
  "text" : "The Los Angeles futures of \"Blade Runner,\" \"Strange Days,\" \"Southland Tales,\" and\u00A0more http:\/\/t.co\/YTYIvsjg1o",
  "id" : 568041922813665280,
  "created_at" : "2015-02-18 13:38:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Christopher Mason",
      "screen_name" : "mason_lab",
      "indices" : [ 51, 61 ],
      "id_str" : "113740810",
      "id" : 113740810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ErFVhQ2nqC",
      "expanded_url" : "http:\/\/microbe.net\/2015\/02\/17\/the-long-road-from-data-to-wisdom-and-from-dna-to-pathogen\/#comment-33730",
      "display_url" : "microbe.net\/2015\/02\/17\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568013851800801280",
  "text" : "RT @pathogenomenick: I made a follow-up comment on @mason_lab's re-analysis on their subway metagenome paper: http:\/\/t.co\/ErFVhQ2nqC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christopher Mason",
        "screen_name" : "mason_lab",
        "indices" : [ 30, 40 ],
        "id_str" : "113740810",
        "id" : 113740810
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/ErFVhQ2nqC",
        "expanded_url" : "http:\/\/microbe.net\/2015\/02\/17\/the-long-road-from-data-to-wisdom-and-from-dna-to-pathogen\/#comment-33730",
        "display_url" : "microbe.net\/2015\/02\/17\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "568012720269869056",
    "text" : "I made a follow-up comment on @mason_lab's re-analysis on their subway metagenome paper: http:\/\/t.co\/ErFVhQ2nqC",
    "id" : 568012720269869056,
    "created_at" : "2015-02-18 11:42:40 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 568013851800801280,
  "created_at" : "2015-02-18 11:47:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17503279426849, 8.625637674857678 ]
  },
  "id_str" : "568005541043310592",
  "text" : "\u00ABHier, diese Paraden mit den Panzern, wie hie\u00DFen die bei euch noch mal?\u00BB \u2014 \u00ABFriedensmarsch?\u00BB",
  "id" : 568005541043310592,
  "created_at" : "2015-02-18 11:14:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567989142627491840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17368338891298, 8.629089938634353 ]
  },
  "id_str" : "567990707920744448",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown thanks, i will write up some comments :)",
  "id" : 567990707920744448,
  "in_reply_to_status_id" : 567989142627491840,
  "created_at" : "2015-02-18 10:15:12 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567666367739211776",
  "geo" : { },
  "id_str" : "567978794197372928",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown Where may I email you my comments to? :)",
  "id" : 567978794197372928,
  "in_reply_to_status_id" : 567666367739211776,
  "created_at" : "2015-02-18 09:27:51 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 0, 14 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567745490130051072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067283921477, 8.759903896830021 ]
  },
  "id_str" : "567746569852960768",
  "in_reply_to_user_id" : 20444825,
  "text" : "@genetics_blog from the data sets I toyed around with it performs pretty similar to Trinity.",
  "id" : 567746569852960768,
  "in_reply_to_status_id" : 567745490130051072,
  "created_at" : "2015-02-17 18:05:05 +0000",
  "in_reply_to_screen_name" : "strnr",
  "in_reply_to_user_id_str" : "20444825",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Dennis Moore",
      "screen_name" : "peromhc",
      "indices" : [ 13, 21 ],
      "id_str" : "4302347242",
      "id" : 4302347242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567666367739211776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236389748422, 8.627551899547692 ]
  },
  "id_str" : "567669327810560001",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown @PeroMHC thanks, will have a look. :)",
  "id" : 567669327810560001,
  "in_reply_to_status_id" : 567666367739211776,
  "created_at" : "2015-02-17 12:58:09 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/SQxTbMYxDN",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/68",
      "display_url" : "existentialcomics.com\/comic\/68"
    } ]
  },
  "geo" : { },
  "id_str" : "567600999893065728",
  "text" : "\u00ABIt\u2019s too late, Sartre, you already said \u2018radical freedom\u2019.\u00BB http:\/\/t.co\/SQxTbMYxDN",
  "id" : 567600999893065728,
  "created_at" : "2015-02-17 08:26:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/6q32xb9l80",
      "expanded_url" : "http:\/\/genomebiology.com\/2015\/16\/1\/30\/abstract",
      "display_url" : "genomebiology.com\/2015\/16\/1\/30\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567597457438416896",
  "text" : "I already hate provisional PDFs for making me scroll, but this one even has the wrong figures attached at the end\u2026 http:\/\/t.co\/6q32xb9l80",
  "id" : 567597457438416896,
  "created_at" : "2015-02-17 08:12:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Song Exploder",
      "screen_name" : "SongExploder",
      "indices" : [ 37, 50 ],
      "id_str" : "2249590315",
      "id" : 2249590315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/voqPpzECXv",
      "expanded_url" : "http:\/\/songexploder.net\/episode-28-the-long-winters\/",
      "display_url" : "songexploder.net\/episode-28-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567593472157552640",
  "text" : "Finally came around to listen to the @SongExploder episode on \u2018The Commander Thinks Aloud\u2019. 20 minutes well spent! http:\/\/t.co\/voqPpzECXv",
  "id" : 567593472157552640,
  "created_at" : "2015-02-17 07:56:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffa",
      "screen_name" : "rei_in_der_tube",
      "indices" : [ 0, 16 ],
      "id_str" : "19707954",
      "id" : 19707954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567354906550751233",
  "geo" : { },
  "id_str" : "567377741738430464",
  "in_reply_to_user_id" : 19707954,
  "text" : "@rei_in_der_tube dann kann es ja nicht mehr lange dauern bis unser Paper auch rauskommt ;)",
  "id" : 567377741738430464,
  "in_reply_to_status_id" : 567354906550751233,
  "created_at" : "2015-02-16 17:39:29 +0000",
  "in_reply_to_screen_name" : "rei_in_der_tube",
  "in_reply_to_user_id_str" : "19707954",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/rFRIO5gds1",
      "expanded_url" : "http:\/\/mbe.oxfordjournals.org\/content\/early\/2015\/02\/12\/molbev.msv032.abstract",
      "display_url" : "mbe.oxfordjournals.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567304978445135872",
  "text" : "Coevolution with bacteriophages drives host evolution &amp; constrains the acquisition of abiotic-beneficial mutations http:\/\/t.co\/rFRIO5gds1",
  "id" : 567304978445135872,
  "created_at" : "2015-02-16 12:50:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Royal Institution",
      "screen_name" : "Ri_Science",
      "indices" : [ 3, 14 ],
      "id_str" : "58431280",
      "id" : 58431280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567294757450563584",
  "text" : "RT @Ri_Science: Not sure if this is best watched before lunch or after but here's a livestream of the last McDonalds sold in Iceland http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/0lqrtXeS9f",
        "expanded_url" : "http:\/\/bit.ly\/1FRC1Xy",
        "display_url" : "bit.ly\/1FRC1Xy"
      } ]
    },
    "geo" : { },
    "id_str" : "567294120545120256",
    "text" : "Not sure if this is best watched before lunch or after but here's a livestream of the last McDonalds sold in Iceland http:\/\/t.co\/0lqrtXeS9f",
    "id" : 567294120545120256,
    "created_at" : "2015-02-16 12:07:12 +0000",
    "user" : {
      "name" : "Royal Institution",
      "screen_name" : "Ri_Science",
      "protected" : false,
      "id_str" : "58431280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/884313582866976768\/rwfTflQ5_normal.jpg",
      "id" : 58431280,
      "verified" : true
    }
  },
  "id" : 567294757450563584,
  "created_at" : "2015-02-16 12:09:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/qLQSZSwJsB",
      "expanded_url" : "https:\/\/peerj.com\/preprints\/837\/",
      "display_url" : "peerj.com\/preprints\/837\/"
    } ]
  },
  "geo" : { },
  "id_str" : "567266522448809984",
  "text" : "Draft sequencing and assembly of the genome of the world\u2019s largest fish, the whale shark https:\/\/t.co\/qLQSZSwJsB",
  "id" : 567266522448809984,
  "created_at" : "2015-02-16 10:17:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567112971638538243",
  "text" : "\u00ABHave you ever seen one of these grant applications? We're lucky Einstein didn't have to fill one out or God knows what 'E' would equal.\u00BB",
  "id" : 567112971638538243,
  "created_at" : "2015-02-16 00:07:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/8pn1EktCEO",
      "expanded_url" : "http:\/\/www.nytimes.com\/interactive\/2014\/09\/14\/sunday-review\/unplanned-pregnancies.html?_r=0",
      "display_url" : "nytimes.com\/interactive\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566976111020883968",
  "text" : "How Likely Is It That Birth Control Could Let You Down? http:\/\/t.co\/8pn1EktCEO",
  "id" : 566976111020883968,
  "created_at" : "2015-02-15 15:03:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566671237183578115",
  "geo" : { },
  "id_str" : "566671960885952513",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish the true breakfast of champions?",
  "id" : 566671960885952513,
  "in_reply_to_status_id" : 566671237183578115,
  "created_at" : "2015-02-14 18:54:58 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566669721873838080",
  "geo" : { },
  "id_str" : "566670325606531074",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish you might accidentally find a way to sober up rather quickly.",
  "id" : 566670325606531074,
  "in_reply_to_status_id" : 566669721873838080,
  "created_at" : "2015-02-14 18:48:28 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/ZZYoDMpjF9",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0114701",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566665132408053762",
  "text" : "Phylogenetic Profiling: How Much Input Data Is Enough? http:\/\/t.co\/ZZYoDMpjF9",
  "id" : 566665132408053762,
  "created_at" : "2015-02-14 18:27:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.9479008997343, 7.67437105067789 ]
  },
  "id_str" : "566546981116710912",
  "text" : "\u00ABOrr, du h\u00E4ltst voll den Verkehr auf!\u00BB \u2014 \u00ABJammer nicht. Wei\u00DFt du wie oft du den Verkehr von deiner Mutter und mir aufgehalten hast?\u00BB",
  "id" : 566546981116710912,
  "created_at" : "2015-02-14 10:38:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 52, 65 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/gS6NnhMSjA",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371\/journal.pbio.1002063",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566507312257708032",
  "text" : "Language: UG or Not to Be, That Is the Question \/cc @PhilippBayer http:\/\/t.co\/gS6NnhMSjA",
  "id" : 566507312257708032,
  "created_at" : "2015-02-14 08:00:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/EgLSRCG45I",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3640",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566506670789238784",
  "text" : "so costly a sacrifice upon the altar of the internet http:\/\/t.co\/EgLSRCG45I",
  "id" : 566506670789238784,
  "created_at" : "2015-02-14 07:58:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.61286717543792, 7.195619752068467 ]
  },
  "id_str" : "566344280986619905",
  "text" : "\u00ABIch bin so unmusikalisch. Ich brauchte sogar Nachhilfe an der Triangel!\u00BB \u2014 \u00ABGab es eine Doppelstunde zusammen mit den Klangh\u00F6lzern?\u00BB",
  "id" : 566344280986619905,
  "created_at" : "2015-02-13 21:12:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francis Rowland",
      "screen_name" : "francisrowland",
      "indices" : [ 3, 18 ],
      "id_str" : "274431472",
      "id" : 274431472
    }, {
      "name" : "Guillaume Filion",
      "screen_name" : "thegrandlocus",
      "indices" : [ 58, 72 ],
      "id_str" : "277175103",
      "id" : 277175103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/dfiCR445HQ",
      "expanded_url" : "https:\/\/ebiinterfaces.wordpress.com\/2015\/02\/13\/ux-design-bioinformatics-and-cars\/",
      "display_url" : "ebiinterfaces.wordpress.com\/2015\/02\/13\/ux-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566293217097031680",
  "text" : "RT @francisrowland: I got around to writing a response to @thegrandlocus's \"If Cars Were Made By Bioinformaticians\" https:\/\/t.co\/dfiCR445HQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Guillaume Filion",
        "screen_name" : "thegrandlocus",
        "indices" : [ 38, 52 ],
        "id_str" : "277175103",
        "id" : 277175103
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ux",
        "indices" : [ 120, 123 ]
      }, {
        "text" : "bioinformatics",
        "indices" : [ 124, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/dfiCR445HQ",
        "expanded_url" : "https:\/\/ebiinterfaces.wordpress.com\/2015\/02\/13\/ux-design-bioinformatics-and-cars\/",
        "display_url" : "ebiinterfaces.wordpress.com\/2015\/02\/13\/ux-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "566224675655917568",
    "text" : "I got around to writing a response to @thegrandlocus's \"If Cars Were Made By Bioinformaticians\" https:\/\/t.co\/dfiCR445HQ #ux #bioinformatics",
    "id" : 566224675655917568,
    "created_at" : "2015-02-13 13:17:37 +0000",
    "user" : {
      "name" : "Francis Rowland",
      "screen_name" : "francisrowland",
      "protected" : false,
      "id_str" : "274431472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684708033994309632\/KA3AN-tI_normal.jpg",
      "id" : 274431472,
      "verified" : false
    }
  },
  "id" : 566293217097031680,
  "created_at" : "2015-02-13 17:49:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/Ed0JUyxGxc",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/02\/12\/capybaras-enjoy-hot-springs.html",
      "display_url" : "boingboing.net\/2015\/02\/12\/cap\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566172134721224704",
  "text" : "Capybaras enjoy hot\u00A0springs http:\/\/t.co\/Ed0JUyxGxc",
  "id" : 566172134721224704,
  "created_at" : "2015-02-13 09:48:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/JoEIQJOzPg",
      "expanded_url" : "https:\/\/medium.com\/cuepoint\/patti-smiths-eternal-flame-fcadf12a8417",
      "display_url" : "medium.com\/cuepoint\/patti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566171176708628480",
  "text" : "\u00ABI was working before people read anything about me, &amp; the day they stopped reading about me, I was doing even more\u00BB https:\/\/t.co\/JoEIQJOzPg",
  "id" : 566171176708628480,
  "created_at" : "2015-02-13 09:45:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/0xTJ7aKo92",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/02\/12\/gif-of-a-floating-dog.html",
      "display_url" : "boingboing.net\/2015\/02\/12\/gif\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566168089637969921",
  "text" : "mesmerizing http:\/\/t.co\/0xTJ7aKo92",
  "id" : 566168089637969921,
  "created_at" : "2015-02-13 09:32:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TAXI",
      "screen_name" : "designtaxi",
      "indices" : [ 3, 14 ],
      "id_str" : "14112296",
      "id" : 14112296
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/designtaxi\/status\/566012798938140673\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/7cbiha4oHG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9rhpClCQAIHgpX.png",
      "id_str" : "566012798371512322",
      "id" : 566012798371512322,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9rhpClCQAIHgpX.png",
      "sizes" : [ {
        "h" : 296,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 296,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 296,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 296,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7cbiha4oHG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/AmOWdX4YcX",
      "expanded_url" : "http:\/\/ow.ly\/IVGgM",
      "display_url" : "ow.ly\/IVGgM"
    } ]
  },
  "geo" : { },
  "id_str" : "566163435084587008",
  "text" : "RT @designtaxi: A hilarious, hipster reboot of popular TV show \u2018Friends\u2019 set in 2015 http:\/\/t.co\/AmOWdX4YcX http:\/\/t.co\/7cbiha4oHG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/designtaxi\/status\/566012798938140673\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/7cbiha4oHG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9rhpClCQAIHgpX.png",
        "id_str" : "566012798371512322",
        "id" : 566012798371512322,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9rhpClCQAIHgpX.png",
        "sizes" : [ {
          "h" : 296,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 296,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 296,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 296,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/7cbiha4oHG"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/AmOWdX4YcX",
        "expanded_url" : "http:\/\/ow.ly\/IVGgM",
        "display_url" : "ow.ly\/IVGgM"
      } ]
    },
    "geo" : { },
    "id_str" : "566012798938140673",
    "text" : "A hilarious, hipster reboot of popular TV show \u2018Friends\u2019 set in 2015 http:\/\/t.co\/AmOWdX4YcX http:\/\/t.co\/7cbiha4oHG",
    "id" : 566012798938140673,
    "created_at" : "2015-02-12 23:15:41 +0000",
    "user" : {
      "name" : "TAXI",
      "screen_name" : "designtaxi",
      "protected" : false,
      "id_str" : "14112296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446325938121216000\/mfMTNQxO_normal.png",
      "id" : 14112296,
      "verified" : true
    }
  },
  "id" : 566163435084587008,
  "created_at" : "2015-02-13 09:14:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/YxvoMsRvJB",
      "expanded_url" : "http:\/\/www.wired.com\/2015\/02\/absurd-creature-of-the-week-scaly-foot-snail\/",
      "display_url" : "wired.com\/2015\/02\/absurd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566157369160523776",
  "text" : "\u00ABmaking the scaly-foot snail more metal than Ozzy Osbourne wrapped in tin foil\u00BB http:\/\/t.co\/YxvoMsRvJB",
  "id" : 566157369160523776,
  "created_at" : "2015-02-13 08:50:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 3, 11 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566156514189389825",
  "text" : "RT @pjacock: John von Neumann: \u201CWith four parameters I can fit an elephant, and with five I can make him wiggle his trunk\u201D http:\/\/t.co\/0vtG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/0vtGwLrjCA",
        "expanded_url" : "http:\/\/www.johndcook.com\/blog\/2011\/06\/21\/how-to-fit-an-elephant\/",
        "display_url" : "johndcook.com\/blog\/2011\/06\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "566077547805282304",
    "text" : "John von Neumann: \u201CWith four parameters I can fit an elephant, and with five I can make him wiggle his trunk\u201D http:\/\/t.co\/0vtGwLrjCA",
    "id" : 566077547805282304,
    "created_at" : "2015-02-13 03:32:59 +0000",
    "user" : {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "protected" : false,
      "id_str" : "58756672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/324343873\/peter_cliff_normal.jpg",
      "id" : 58756672,
      "verified" : false
    }
  },
  "id" : 566156514189389825,
  "created_at" : "2015-02-13 08:46:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/zQTFbaZy2U",
      "expanded_url" : "https:\/\/github.com\/citelao\/Spotify-for-Alfred",
      "display_url" : "github.com\/citelao\/Spotif\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565920342313807873",
  "text" : "Handy: Spotify for Alfred https:\/\/t.co\/zQTFbaZy2U",
  "id" : 565920342313807873,
  "created_at" : "2015-02-12 17:08:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565897135192023040",
  "text" : "\u00ABMach sicher das du das ganze Interview lang so tust als ob Neuseeland zu Australien geh\u00F6rt, da freuen die sich voll!\u00BB",
  "id" : 565897135192023040,
  "created_at" : "2015-02-12 15:36:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/tvVH4QueUX",
      "expanded_url" : "http:\/\/www.muensterschezeitung.de\/Lokales\/Staedte\/Muenster\/1878668-Taeter-zwischen-14-und-17-Jahre-alt-Jugendliche-knacken-Tresor-in-Baeckerei",
      "display_url" : "muensterschezeitung.de\/Lokales\/Staedt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565844422928396289",
  "text" : "Da ist also diese Kuchenblechmafia! http:\/\/t.co\/tvVH4QueUX",
  "id" : 565844422928396289,
  "created_at" : "2015-02-12 12:06:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/y7GMX6V4vY",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0117388",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565823138148417536",
  "text" : "Using Google ngrams: Anatomy of Scientific Evolution http:\/\/t.co\/y7GMX6V4vY",
  "id" : 565823138148417536,
  "created_at" : "2015-02-12 10:42:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565807554585194496",
  "text" : "\u00ABDu findest mein Auto ganz einfach. Es steht vor der leeren Wodka-Flasche mit dem Kreuz drauf. The X marks the spot!\u00BB",
  "id" : 565807554585194496,
  "created_at" : "2015-02-12 09:40:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herzog",
      "screen_name" : "herzog_andreas",
      "indices" : [ 0, 15 ],
      "id_str" : "1003379274",
      "id" : 1003379274
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 16, 31 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/JSyCFgO430",
      "expanded_url" : "https:\/\/www.govtrack.us\/congress\/bills\/110\/hr493\/text",
      "display_url" : "govtrack.us\/congress\/bills\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "565790766707261440",
  "geo" : { },
  "id_str" : "565791204861046784",
  "in_reply_to_user_id" : 1003379274,
  "text" : "@herzog_andreas @gedankenabfall die USA haben \u00B1 vergleichbar GINA https:\/\/t.co\/JSyCFgO430",
  "id" : 565791204861046784,
  "in_reply_to_status_id" : 565790766707261440,
  "created_at" : "2015-02-12 08:35:09 +0000",
  "in_reply_to_screen_name" : "herzog_andreas",
  "in_reply_to_user_id_str" : "1003379274",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herzog",
      "screen_name" : "herzog_andreas",
      "indices" : [ 0, 15 ],
      "id_str" : "1003379274",
      "id" : 1003379274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/JfSu3i35kK",
      "expanded_url" : "http:\/\/www.gesetze-im-internet.de\/gendg\/",
      "display_url" : "gesetze-im-internet.de\/gendg\/"
    } ]
  },
  "in_reply_to_status_id_str" : "565790766707261440",
  "geo" : { },
  "id_str" : "565791090603991041",
  "in_reply_to_user_id" : 1003379274,
  "text" : "@herzog_andreas in .de haben wir das GenDG was vieles davon regelt: http:\/\/t.co\/JfSu3i35kK",
  "id" : 565791090603991041,
  "in_reply_to_status_id" : 565790766707261440,
  "created_at" : "2015-02-12 08:34:42 +0000",
  "in_reply_to_screen_name" : "herzog_andreas",
  "in_reply_to_user_id_str" : "1003379274",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herzog",
      "screen_name" : "herzog_andreas",
      "indices" : [ 0, 15 ],
      "id_str" : "1003379274",
      "id" : 1003379274
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 16, 31 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565789295068602369",
  "geo" : { },
  "id_str" : "565789853464678400",
  "in_reply_to_user_id" : 1003379274,
  "text" : "@herzog_andreas @gedankenabfall was f\u00FCr Rahmenbedingungen sind gemeint? :)",
  "id" : 565789853464678400,
  "in_reply_to_status_id" : 565789295068602369,
  "created_at" : "2015-02-12 08:29:47 +0000",
  "in_reply_to_screen_name" : "herzog_andreas",
  "in_reply_to_user_id_str" : "1003379274",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Morton",
      "screen_name" : "simonmorton",
      "indices" : [ 0, 12 ],
      "id_str" : "14179164",
      "id" : 14179164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565621748616687617",
  "geo" : { },
  "id_str" : "565624666078060544",
  "in_reply_to_user_id" : 14179164,
  "text" : "@simonmorton sure, bgreshake@googlemail.com",
  "id" : 565624666078060544,
  "in_reply_to_status_id" : 565621748616687617,
  "created_at" : "2015-02-11 21:33:23 +0000",
  "in_reply_to_screen_name" : "simonmorton",
  "in_reply_to_user_id_str" : "14179164",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/qc7HUvIzHj",
      "expanded_url" : "http:\/\/fusion.net\/story\/40034\/the-social-network-for-people-who-want-to-upload-their-dna-to-the-internet\/",
      "display_url" : "fusion.net\/story\/40034\/th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565586412658229251",
  "text" : "On openSNP: \u00ABThe social network for people who want to upload their DNA to the\u00A0Internet\u00BB http:\/\/t.co\/qc7HUvIzHj",
  "id" : 565586412658229251,
  "created_at" : "2015-02-11 19:01:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 13, 22 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/LASfOj7qHd",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/02\/11\/363768.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+boingboing%2FiBag+%28Boing+Boing%29",
      "display_url" : "boingboing.net\/2015\/02\/11\/363\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172379, 8.627565 ]
  },
  "id_str" : "565507366175916032",
  "text" : "Your chance, @senficon!  http:\/\/t.co\/LASfOj7qHd",
  "id" : 565507366175916032,
  "created_at" : "2015-02-11 13:47:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/QOr58JkDvx",
      "expanded_url" : "http:\/\/www.bbc.com\/future\/story\/20150209-the-network-that-runs-the-world",
      "display_url" : "bbc.com\/future\/story\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565488824646897664",
  "text" : "cargo culting: The invisible network that keeps the world running http:\/\/t.co\/QOr58JkDvx",
  "id" : 565488824646897664,
  "created_at" : "2015-02-11 12:33:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/3Fq44sbOVw",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371\/journal.pbio.1002062",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565481018006962176",
  "text" : "The Blind Men and the Piwi Elephant\u2014Opening a Can of Worms http:\/\/t.co\/3Fq44sbOVw",
  "id" : 565481018006962176,
  "created_at" : "2015-02-11 12:02:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565447357165469696",
  "geo" : { },
  "id_str" : "565449016293736449",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena Oh, thanks. Even more congratulations then! :-)",
  "id" : 565449016293736449,
  "in_reply_to_status_id" : 565447357165469696,
  "created_at" : "2015-02-11 09:55:25 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/ggbjxE5sBL",
      "expanded_url" : "http:\/\/aeon.co\/magazine\/science\/how-did-science-come-to-speak-only-english\/",
      "display_url" : "aeon.co\/magazine\/scien\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565429521642684417",
  "text" : "How science ended up being monoglot http:\/\/t.co\/ggbjxE5sBL",
  "id" : 565429521642684417,
  "created_at" : "2015-02-11 08:37:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/pbQWm5QoF0",
      "expanded_url" : "http:\/\/www.textsavvy.blogspot.de\/2015\/02\/intuition-and-domain-knowledge.html",
      "display_url" : "textsavvy.blogspot.de\/2015\/02\/intuit\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232241817246, 8.627558183583668 ]
  },
  "id_str" : "565425902021263362",
  "text" : "Intuition and Domain Knowledge http:\/\/t.co\/pbQWm5QoF0",
  "id" : 565425902021263362,
  "created_at" : "2015-02-11 08:23:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565272690307923970",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer uh, could one of you restart the workers? had to reboot the server.",
  "id" : 565272690307923970,
  "created_at" : "2015-02-10 22:14:46 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Molecular Ecologist",
      "screen_name" : "molecologist",
      "indices" : [ 3, 16 ],
      "id_str" : "199360809",
      "id" : 199360809
    }, {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 101, 109 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/StVTBWfaUj",
      "expanded_url" : "http:\/\/wp.me\/p4OZed-1qO",
      "display_url" : "wp.me\/p4OZed-1qO"
    }, {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/NS58ug3S8U",
      "expanded_url" : "http:\/\/www.molecularecologist.com\/wp-content\/uploads\/2015\/02\/Smith.png",
      "display_url" : "molecularecologist.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565271785869160448",
  "text" : "RT @molecologist: Harry Smith, the founder of Molecular Ecology, has died http:\/\/t.co\/StVTBWfaUj\u2014 by @JBYoder http:\/\/t.co\/NS58ug3S8U http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.molecularecologist.com\" rel=\"nofollow\"\u003EMolecular Ecologist\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
        "screen_name" : "JBYoder",
        "indices" : [ 83, 91 ],
        "id_str" : "19984919",
        "id" : 19984919
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/molecologist\/status\/565261843539980291\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/gFOde4VJqn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9g2ptWIMAAEfYK.png",
        "id_str" : "565261843409940480",
        "id" : 565261843409940480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9g2ptWIMAAEfYK.png",
        "sizes" : [ {
          "h" : 459,
          "resize" : "fit",
          "w" : 377
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 459,
          "resize" : "fit",
          "w" : 377
        }, {
          "h" : 459,
          "resize" : "fit",
          "w" : 377
        }, {
          "h" : 459,
          "resize" : "fit",
          "w" : 377
        } ],
        "display_url" : "pic.twitter.com\/gFOde4VJqn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/StVTBWfaUj",
        "expanded_url" : "http:\/\/wp.me\/p4OZed-1qO",
        "display_url" : "wp.me\/p4OZed-1qO"
      }, {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/NS58ug3S8U",
        "expanded_url" : "http:\/\/www.molecularecologist.com\/wp-content\/uploads\/2015\/02\/Smith.png",
        "display_url" : "molecularecologist.com\/wp-content\/upl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "565261843539980291",
    "text" : "Harry Smith, the founder of Molecular Ecology, has died http:\/\/t.co\/StVTBWfaUj\u2014 by @JBYoder http:\/\/t.co\/NS58ug3S8U http:\/\/t.co\/gFOde4VJqn",
    "id" : 565261843539980291,
    "created_at" : "2015-02-10 21:31:40 +0000",
    "user" : {
      "name" : "Molecular Ecologist",
      "screen_name" : "molecologist",
      "protected" : false,
      "id_str" : "199360809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701480248899022849\/-EEVkZX8_normal.png",
      "id" : 199360809,
      "verified" : false
    }
  },
  "id" : 565271785869160448,
  "created_at" : "2015-02-10 22:11:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565174616717819904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235892432832, 8.627502896927016 ]
  },
  "id_str" : "565177542320345090",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon unfortunately not, would be interesting as well ;)",
  "id" : 565177542320345090,
  "in_reply_to_status_id" : 565174616717819904,
  "created_at" : "2015-02-10 15:56:41 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/y2Bn14Rpj6",
      "expanded_url" : "http:\/\/aeon.co\/magazine\/culture\/welcome-to-the-scarcity-games\/",
      "display_url" : "aeon.co\/magazine\/cultu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565173454094475264",
  "text" : "\u00ABMost games are ultimately designed to let you win, but here the systems conspire to make your death interesting\u00BB http:\/\/t.co\/y2Bn14Rpj6",
  "id" : 565173454094475264,
  "created_at" : "2015-02-10 15:40:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hakantee",
      "screen_name" : "hakantee",
      "indices" : [ 0, 9 ],
      "id_str" : "4902835689",
      "id" : 4902835689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565083735629254656",
  "geo" : { },
  "id_str" : "565084050030092289",
  "in_reply_to_user_id" : 48272332,
  "text" : "@hakantee seltsam, aber hast eine Antwort. :-)",
  "id" : 565084050030092289,
  "in_reply_to_status_id" : 565083735629254656,
  "created_at" : "2015-02-10 09:45:10 +0000",
  "in_reply_to_screen_name" : "hatr",
  "in_reply_to_user_id_str" : "48272332",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 52, 63 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/6wHuaI0Dm9",
      "expanded_url" : "http:\/\/journals.plos.org\/ploscompbiol\/article?id=10.1371\/journal.pcbi.1003904",
      "display_url" : "journals.plos.org\/ploscompbiol\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565081287564988416",
  "text" : "Ethical Challenges of Big Data in Public Health, by @EffyVayena et al. (congrats!) http:\/\/t.co\/6wHuaI0Dm9",
  "id" : 565081287564988416,
  "created_at" : "2015-02-10 09:34:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/tmaAmk50D6",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/67",
      "display_url" : "existentialcomics.com\/comic\/67"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231042141581, 8.6275459157707 ]
  },
  "id_str" : "565078848472375297",
  "text" : "Philosophy Humans http:\/\/t.co\/tmaAmk50D6",
  "id" : 565078848472375297,
  "created_at" : "2015-02-10 09:24:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 104, 117 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/GdAFTlT9fY",
      "expanded_url" : "http:\/\/link.springer.com\/article\/10.1007\/s12539-014-0242-9",
      "display_url" : "link.springer.com\/article\/10.100\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565059284791463936",
  "text" : "\u00ABintegrating personal genome for warfarin dosing\u00BB Using openSNP data 4 testing purposes is somewhat odd @PhilippBayer http:\/\/t.co\/GdAFTlT9fY",
  "id" : 565059284791463936,
  "created_at" : "2015-02-10 08:06:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/tI7Wl1gN8P",
      "expanded_url" : "http:\/\/stats.org.uk\/statistical-inference\/Bakan1966.pdf",
      "display_url" : "stats.org.uk\/statistical-in\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "564825402276065281",
  "geo" : { },
  "id_str" : "564826824115777536",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer it\u2019s also not like the topic is super new. :D http:\/\/t.co\/tI7Wl1gN8P",
  "id" : 564826824115777536,
  "in_reply_to_status_id" : 564825402276065281,
  "created_at" : "2015-02-09 16:43:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564824123852214272",
  "geo" : { },
  "id_str" : "564825165209829378",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer aye. I have to say I think cheap shots at p-values are okayish. w\/o \u201C30% of research is wrong\u201D no one would have noticed.",
  "id" : 564825165209829378,
  "in_reply_to_status_id" : 564824123852214272,
  "created_at" : "2015-02-09 16:36:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 49, 65 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/SsTzx61hnl",
      "expanded_url" : "https:\/\/scientistseessquirrel.wordpress.com\/2015\/02\/09\/in-defence-of-the-p-value\/",
      "display_url" : "scientistseessquirrel.wordpress.com\/2015\/02\/09\/in-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564824045812985856",
  "text" : "RT @PhilippBayer: \"In defence of the P-value\" cc @gedankenstuecke https:\/\/t.co\/SsTzx61hnl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 31, 47 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/SsTzx61hnl",
        "expanded_url" : "https:\/\/scientistseessquirrel.wordpress.com\/2015\/02\/09\/in-defence-of-the-p-value\/",
        "display_url" : "scientistseessquirrel.wordpress.com\/2015\/02\/09\/in-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "564822889107836928",
    "text" : "\"In defence of the P-value\" cc @gedankenstuecke https:\/\/t.co\/SsTzx61hnl",
    "id" : 564822889107836928,
    "created_at" : "2015-02-09 16:27:25 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 564824045812985856,
  "created_at" : "2015-02-09 16:32:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "564822889107836928",
  "geo" : { },
  "id_str" : "564823933078503424",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer i\u2019m really not sure whether the p-value needs any defending. last time i checked it was well alive and kicking :p",
  "id" : 564823933078503424,
  "in_reply_to_status_id" : 564822889107836928,
  "created_at" : "2015-02-09 16:31:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/mgrixtvxMX",
      "expanded_url" : "http:\/\/www.nature.com\/collections\/qghhqm",
      "display_url" : "nature.com\/collections\/qg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564813351344418817",
  "text" : "Nice: A collection on \u2018statistics for biologists\u2019 http:\/\/t.co\/mgrixtvxMX",
  "id" : 564813351344418817,
  "created_at" : "2015-02-09 15:49:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ps",
      "screen_name" : "PatSchloss",
      "indices" : [ 3, 14 ],
      "id_str" : "185631499",
      "id" : 185631499
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PatSchloss\/status\/564800656897089536\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Ue5YiWbTgj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9aTNFHCQAE_4Ji.png",
      "id_str" : "564800656200843265",
      "id" : 564800656200843265,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9aTNFHCQAE_4Ji.png",
      "sizes" : [ {
        "h" : 116,
        "resize" : "crop",
        "w" : 116
      }, {
        "h" : 116,
        "resize" : "fit",
        "w" : 770
      }, {
        "h" : 116,
        "resize" : "fit",
        "w" : 770
      }, {
        "h" : 102,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 116,
        "resize" : "fit",
        "w" : 770
      } ],
      "display_url" : "pic.twitter.com\/Ue5YiWbTgj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564803960603967488",
  "text" : "RT @PatSchloss: If you email me to fill out a bunch of administrative bs, be prepared for a blast from the past. http:\/\/t.co\/Ue5YiWbTgj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PatSchloss\/status\/564800656897089536\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/Ue5YiWbTgj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9aTNFHCQAE_4Ji.png",
        "id_str" : "564800656200843265",
        "id" : 564800656200843265,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9aTNFHCQAE_4Ji.png",
        "sizes" : [ {
          "h" : 116,
          "resize" : "crop",
          "w" : 116
        }, {
          "h" : 116,
          "resize" : "fit",
          "w" : 770
        }, {
          "h" : 116,
          "resize" : "fit",
          "w" : 770
        }, {
          "h" : 102,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 116,
          "resize" : "fit",
          "w" : 770
        } ],
        "display_url" : "pic.twitter.com\/Ue5YiWbTgj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564800656897089536",
    "text" : "If you email me to fill out a bunch of administrative bs, be prepared for a blast from the past. http:\/\/t.co\/Ue5YiWbTgj",
    "id" : 564800656897089536,
    "created_at" : "2015-02-09 14:59:04 +0000",
    "user" : {
      "name" : "ps",
      "screen_name" : "PatSchloss",
      "protected" : false,
      "id_str" : "185631499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/910630677636374528\/plq5smpK_normal.jpg",
      "id" : 185631499,
      "verified" : false
    }
  },
  "id" : 564803960603967488,
  "created_at" : "2015-02-09 15:12:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/BKHiH2uRZt",
      "expanded_url" : "http:\/\/chronicle.com\/article\/The-Altruism-Game\/151625?cid=megamenu",
      "display_url" : "chronicle.com\/article\/The-Al\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564801784829722624",
  "text" : "The Altruism Game http:\/\/t.co\/BKHiH2uRZt",
  "id" : 564801784829722624,
  "created_at" : "2015-02-09 15:03:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badpharma",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/P9yTWRVu0R",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=YQZ2UeOTO3I",
      "display_url" : "youtube.com\/watch?v=YQZ2Ue\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564760647238705153",
  "text" : "an addendum to #badpharma https:\/\/t.co\/P9yTWRVu0R",
  "id" : 564760647238705153,
  "created_at" : "2015-02-09 12:20:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/OBWWQBEaB7",
      "expanded_url" : "http:\/\/omicsomics.blogspot.de\/2015\/02\/how-not-to-write-sequence-assembly.html",
      "display_url" : "omicsomics.blogspot.de\/2015\/02\/how-no\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564754074827235328",
  "text" : "How not to write a sequence assembly comparison paper http:\/\/t.co\/OBWWQBEaB7",
  "id" : 564754074827235328,
  "created_at" : "2015-02-09 11:53:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/I1cDcA2QUp",
      "expanded_url" : "https:\/\/scientificbsides.wordpress.com\/2014\/12\/08\/the-biggest-problem-in-cancer-evolution-that-mostly-people-like-me-are-doing-it\/",
      "display_url" : "scientificbsides.wordpress.com\/2014\/12\/08\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564737867831054336",
  "text" : "\u00ABThe biggest problem in cancer evolution? That mostly people like me are doing\u00A0it.\u00BB https:\/\/t.co\/I1cDcA2QUp",
  "id" : 564737867831054336,
  "created_at" : "2015-02-09 10:49:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 67, 76 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/7RTYy7pgm4",
      "expanded_url" : "https:\/\/etechlib.wordpress.com\/2015\/02\/06\/informed-consent-in-a-new-era\/",
      "display_url" : "etechlib.wordpress.com\/2015\/02\/06\/inf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564737054421286912",
  "text" : "Informed Consent in a New\u00A0Era (incl. much well-deserved praise for @wilbanks) https:\/\/t.co\/7RTYy7pgm4",
  "id" : 564737054421286912,
  "created_at" : "2015-02-09 10:46:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/564712400289792000\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/vIu2nYqH1r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9ZC76AIAAAkQTc.jpg",
      "id_str" : "564712400231071744",
      "id" : 564712400231071744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9ZC76AIAAAkQTc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1061,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 481
      }, {
        "h" : 1061,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1061,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/vIu2nYqH1r"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.173403, 8.628368 ]
  },
  "id_str" : "564712400289792000",
  "text" : "Renaming the streets on campus seems to go on. http:\/\/t.co\/vIu2nYqH1r",
  "id" : 564712400289792000,
  "created_at" : "2015-02-09 09:08:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/pfBBR4x3Pr",
      "expanded_url" : "http:\/\/www.newyorker.com\/news\/news-desk\/vietnams-quiet-anniversary?mbid=rss",
      "display_url" : "newyorker.com\/news\/news-desk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564704727108431873",
  "text" : "Vietnam\u2019s Quiet Anniversary http:\/\/t.co\/pfBBR4x3Pr",
  "id" : 564704727108431873,
  "created_at" : "2015-02-09 08:37:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/SUopXgdrj1",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plosone\/PLoSONE\/~3\/KIi40YtWtYE\/info%3Adoi%2F10.1371%2Fjournal.pone.0117285",
      "display_url" : "feeds.plos.org\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "564096259389419521",
  "text" : "The Embodiment of Success and Failure as Forward versus Backward Movements http:\/\/t.co\/SUopXgdrj1",
  "id" : 564096259389419521,
  "created_at" : "2015-02-07 16:20:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563701682157416448",
  "geo" : { },
  "id_str" : "563701853570224129",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABgene that might, if you squint your eyes &amp; tilt your head sideways, be slightly significant in terms of making you believe genome studies\u00BB",
  "id" : 563701853570224129,
  "in_reply_to_status_id" : 563701682157416448,
  "created_at" : "2015-02-06 14:12:49 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/SktNgyXmuX",
      "expanded_url" : "http:\/\/www.theallium.com\/biology\/genome-study-finds-gene-believing-genome-studies\/",
      "display_url" : "theallium.com\/biology\/genome\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563701682157416448",
  "text" : "Genome Study Finds Gene for Believing Genome Studies http:\/\/t.co\/SktNgyXmuX",
  "id" : 563701682157416448,
  "created_at" : "2015-02-06 14:12:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Molecular Ecologist",
      "screen_name" : "molecologist",
      "indices" : [ 3, 16 ],
      "id_str" : "199360809",
      "id" : 199360809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/vVkKAoLj1H",
      "expanded_url" : "http:\/\/wp.me\/p4OZed-1pX",
      "display_url" : "wp.me\/p4OZed-1pX"
    } ]
  },
  "geo" : { },
  "id_str" : "563445494035542019",
  "text" : "RT @molecologist: Phonemes and Genomes http:\/\/t.co\/vVkKAoLj1H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/vVkKAoLj1H",
        "expanded_url" : "http:\/\/wp.me\/p4OZed-1pX",
        "display_url" : "wp.me\/p4OZed-1pX"
      } ]
    },
    "geo" : { },
    "id_str" : "563411912012992512",
    "text" : "Phonemes and Genomes http:\/\/t.co\/vVkKAoLj1H",
    "id" : 563411912012992512,
    "created_at" : "2015-02-05 19:00:42 +0000",
    "user" : {
      "name" : "Molecular Ecologist",
      "screen_name" : "molecologist",
      "protected" : false,
      "id_str" : "199360809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701480248899022849\/-EEVkZX8_normal.png",
      "id" : 199360809,
      "verified" : false
    }
  },
  "id" : 563445494035542019,
  "created_at" : "2015-02-05 21:14:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563418152869298177",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067199714947, 8.759902953821006 ]
  },
  "id_str" : "563418514477051904",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @PhilippBayer I\u2019ll just wait for Brussels to come home :p",
  "id" : 563418514477051904,
  "in_reply_to_status_id" : 563418152869298177,
  "created_at" : "2015-02-05 19:26:56 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/9u2Ro2d19g",
      "expanded_url" : "http:\/\/m.thisamericanlife.org\/radio-archives\/episode\/546\/burroughs-101",
      "display_url" : "m.thisamericanlife.org\/radio-archives\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "563405698864672768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10952783287513, 8.761684438221865 ]
  },
  "id_str" : "563407871120273408",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw. ICYMI http:\/\/t.co\/9u2Ro2d19g",
  "id" : 563407871120273408,
  "in_reply_to_status_id" : 563405698864672768,
  "created_at" : "2015-02-05 18:44:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563405698864672768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067199706424, 8.752942297453597 ]
  },
  "id_str" : "563406209022447619",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Senficon sure, no problem. Filling boring forms is a nice break :p",
  "id" : 563406209022447619,
  "in_reply_to_status_id" : 563405698864672768,
  "created_at" : "2015-02-05 18:38:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 109, 122 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 123, 132 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563402848848060417",
  "text" : "\u00ABopenSNP has successfully performed the annual update of its registration in the Transparency Register.\u00BB \/cc @PhilippBayer @Senficon",
  "id" : 563402848848060417,
  "created_at" : "2015-02-05 18:24:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/4dodDSHlNy",
      "expanded_url" : "http:\/\/www.gettinggeneticsdone.com\/2015\/02\/microbial-genomics-state-of-art-in-2015.html",
      "display_url" : "gettinggeneticsdone.com\/2015\/02\/microb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563270626459521024",
  "text" : "Microbial Genomics: the State of the Art in 2015 http:\/\/t.co\/4dodDSHlNy",
  "id" : 563270626459521024,
  "created_at" : "2015-02-05 09:39:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lior Pachter",
      "screen_name" : "lpachter",
      "indices" : [ 3, 12 ],
      "id_str" : "31936449",
      "id" : 31936449
    }, {
      "name" : "ingileif",
      "screen_name" : "IngileifBryndis",
      "indices" : [ 84, 100 ],
      "id_str" : "1958058648",
      "id" : 1958058648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/rVoI4wqfg9",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=eS-oenaXBBM&sns=fb",
      "display_url" : "youtube.com\/watch?v=eS-oen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563048946617315328",
  "text" : "RT @lpachter: How to speak Icelandic using only 3 words https:\/\/t.co\/rVoI4wqfg9 via @IngileifBryndis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ingileif",
        "screen_name" : "IngileifBryndis",
        "indices" : [ 70, 86 ],
        "id_str" : "1958058648",
        "id" : 1958058648
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/rVoI4wqfg9",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=eS-oenaXBBM&sns=fb",
        "display_url" : "youtube.com\/watch?v=eS-oen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "563041162815361025",
    "text" : "How to speak Icelandic using only 3 words https:\/\/t.co\/rVoI4wqfg9 via @IngileifBryndis",
    "id" : 563041162815361025,
    "created_at" : "2015-02-04 18:27:28 +0000",
    "user" : {
      "name" : "Lior Pachter",
      "screen_name" : "lpachter",
      "protected" : false,
      "id_str" : "31936449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/861688064258719744\/p8MVi-zW_normal.jpg",
      "id" : 31936449,
      "verified" : false
    }
  },
  "id" : 563048946617315328,
  "created_at" : "2015-02-04 18:58:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cszh",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/6wIwTlQfnR",
      "expanded_url" : "http:\/\/www.multimedia.ethz.ch\/conferences\/2015\/imsb\/05_thursday",
      "display_url" : "multimedia.ethz.ch\/conferences\/20\u2026"
    }, {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/CHlVrZUHNE",
      "expanded_url" : "http:\/\/www.multimedia.ethz.ch\/conferences\/2015\/imsb\/06_friday",
      "display_url" : "multimedia.ethz.ch\/conferences\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563039173675061251",
  "text" : "Nice! The videos of the citizen science workshop are now online. Day 1: http:\/\/t.co\/6wIwTlQfnR Day 2: http:\/\/t.co\/CHlVrZUHNE #cszh",
  "id" : 563039173675061251,
  "created_at" : "2015-02-04 18:19:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/uXVmn2Rh86",
      "expanded_url" : "http:\/\/instagram.com\/p\/ysF9k4Bwjl\/",
      "display_url" : "instagram.com\/p\/ysF9k4Bwjl\/"
    } ]
  },
  "geo" : { },
  "id_str" : "563038146125103106",
  "text" : "That's a really meta t-shirt http:\/\/t.co\/uXVmn2Rh86",
  "id" : 563038146125103106,
  "created_at" : "2015-02-04 18:15:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/mn6UjQOmjm",
      "expanded_url" : "http:\/\/www.reuters.com\/article\/2015\/02\/01\/us-epstein-charity-idUSKBN0L51G720150201",
      "display_url" : "reuters.com\/article\/2015\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563026720090251264",
  "text" : "RT @JBYoder: \u201CBiologist\" Robert Trivers on why it\u2019s OK that his funder paid for sex with underage girls. http:\/\/t.co\/mn6UjQOmjm http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JBYoder\/status\/563018431575105538\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/E0Bh9bk1x5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9A-R5IIQAA3eLC.png",
        "id_str" : "563018430534926336",
        "id" : 563018430534926336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9A-R5IIQAA3eLC.png",
        "sizes" : [ {
          "h" : 303,
          "resize" : "fit",
          "w" : 628
        }, {
          "h" : 303,
          "resize" : "fit",
          "w" : 628
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 303,
          "resize" : "fit",
          "w" : 628
        }, {
          "h" : 303,
          "resize" : "fit",
          "w" : 628
        } ],
        "display_url" : "pic.twitter.com\/E0Bh9bk1x5"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/mn6UjQOmjm",
        "expanded_url" : "http:\/\/www.reuters.com\/article\/2015\/02\/01\/us-epstein-charity-idUSKBN0L51G720150201",
        "display_url" : "reuters.com\/article\/2015\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "563018431575105538",
    "text" : "\u201CBiologist\" Robert Trivers on why it\u2019s OK that his funder paid for sex with underage girls. http:\/\/t.co\/mn6UjQOmjm http:\/\/t.co\/E0Bh9bk1x5",
    "id" : 563018431575105538,
    "created_at" : "2015-02-04 16:57:09 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 563026720090251264,
  "created_at" : "2015-02-04 17:30:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563011684089200640",
  "text" : "\u00ABDu Orangensch\u00E4lwettbewerbsverliererin!\u00BB \u2013 \u00ABDer Herzen!\u00BB",
  "id" : 563011684089200640,
  "created_at" : "2015-02-04 16:30:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563005096578269184",
  "geo" : { },
  "id_str" : "563005304749961216",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv \u201Cda\u00DFpa\u00DFw\u00F6rt\u201D :3",
  "id" : 563005304749961216,
  "in_reply_to_status_id" : 563005096578269184,
  "created_at" : "2015-02-04 16:04:59 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/gUCKT2SzEr",
      "expanded_url" : "https:\/\/datadrivendj.com\/tracks\/subway",
      "display_url" : "datadrivendj.com\/tracks\/subway"
    } ]
  },
  "in_reply_to_status_id_str" : "563004688829005824",
  "geo" : { },
  "id_str" : "563005170813267969",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv btw: i totally forgot to send you this earlier! https:\/\/t.co\/gUCKT2SzEr",
  "id" : 563005170813267969,
  "in_reply_to_status_id" : 563004688829005824,
  "created_at" : "2015-02-04 16:04:27 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "563004688829005824",
  "geo" : { },
  "id_str" : "563004891749445632",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv at least by now I figured out why I can\u2019t login after updates: the keyboard layout makes me enter the wrong password. ;)",
  "id" : 563004891749445632,
  "in_reply_to_status_id" : 563004688829005824,
  "created_at" : "2015-02-04 16:03:20 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563004507819638787",
  "text" : "Fun, with each minor release update OS X 10.10 removes all my keyboard layouts &amp; preferences and goes back to US english only\u2026",
  "id" : 563004507819638787,
  "created_at" : "2015-02-04 16:01:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/bRX42XCI3f",
      "expanded_url" : "http:\/\/www.pgbovine.net\/parsing-raw-data.htm",
      "display_url" : "pgbovine.net\/parsing-raw-da\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562999303661436929",
  "text" : "On parsing raw data \u00ABWrite assertions until your eyes bleed. Then write some more.\u00BB http:\/\/t.co\/bRX42XCI3f",
  "id" : 562999303661436929,
  "created_at" : "2015-02-04 15:41:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/5FACvjrzFS",
      "expanded_url" : "http:\/\/blog.thegrandlocus.com\/2015\/01\/if-cars-were-made-by-bioinformaticians",
      "display_url" : "blog.thegrandlocus.com\/2015\/01\/if-car\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562997364412387329",
  "text" : "\u00ABIf cars were made by bioinformaticians..\u00BB http:\/\/t.co\/5FACvjrzFS",
  "id" : 562997364412387329,
  "created_at" : "2015-02-04 15:33:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/wQnRnaUAex",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plosone\/PLoSONE\/~3\/svBOsGjpEqk\/info%3Adoi%2F10.1371%2Fjournal.pone.0117476",
      "display_url" : "feeds.plos.org\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562896590047027200",
  "text" : "Social Identity Threat Motivates Science-Discrediting Online Comments http:\/\/t.co\/wQnRnaUAex",
  "id" : 562896590047027200,
  "created_at" : "2015-02-04 08:52:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "562727764542115841",
  "geo" : { },
  "id_str" : "562727943123001345",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that\u2019s a shame. btw: thanks for renewing the certificate!",
  "id" : 562727943123001345,
  "in_reply_to_status_id" : 562727764542115841,
  "created_at" : "2015-02-03 21:42:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/SrKHBwRWm0",
      "expanded_url" : "https:\/\/medium.com\/medium-eng\/the-curious-case-of-disappearing-polish-s-fa398313d4df",
      "display_url" : "medium.com\/medium-eng\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562617191418580992",
  "text" : "The curious case of the disappearing Polish S https:\/\/t.co\/SrKHBwRWm0",
  "id" : 562617191418580992,
  "created_at" : "2015-02-03 14:22:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/8mcYpjMKMi",
      "expanded_url" : "http:\/\/opinionator.blogs.nytimes.com\/2015\/02\/02\/how-to-be-a-stoic\/?hp&action=click&pgtype=Homepage&module=c-column-top-span-region&region=c-column-top-span-region&WT.nav=c-column-top-span-region",
      "display_url" : "opinionator.blogs.nytimes.com\/2015\/02\/02\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562607837105627137",
  "text" : "How to Be a Stoic http:\/\/t.co\/8mcYpjMKMi",
  "id" : 562607837105627137,
  "created_at" : "2015-02-03 13:45:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 70, 83 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/reJ7UFz9uo",
      "expanded_url" : "http:\/\/bioinformatics.oxfordjournals.org\/content\/early\/2015\/01\/28\/bioinformatics.btv056.short",
      "display_url" : "bioinformatics.oxfordjournals.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562567459849641984",
  "text" : "RAMPART: a workflow management system for de novo genome assembly \/cc @PhilippBayer http:\/\/t.co\/reJ7UFz9uo",
  "id" : 562567459849641984,
  "created_at" : "2015-02-03 11:05:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/rxAwqQ2R6r",
      "expanded_url" : "https:\/\/peerj.com\/preprints\/812v1\/",
      "display_url" : "peerj.com\/preprints\/812v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562563616617283584",
  "text" : "\u00ABOur results suggest that investment in permanent researchers may be most productive avenue for funding research\u00BB https:\/\/t.co\/rxAwqQ2R6r",
  "id" : 562563616617283584,
  "created_at" : "2015-02-03 10:49:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/EGru3GSL2H",
      "expanded_url" : "http:\/\/massgenomics.org\/2015\/02\/the-value-of-the-cohort-23andmes-research-portal.html",
      "display_url" : "massgenomics.org\/2015\/02\/the-va\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562516679243350017",
  "text" : "The Value of the Cohort: 23andMe\u2019s Research Portal http:\/\/t.co\/EGru3GSL2H",
  "id" : 562516679243350017,
  "created_at" : "2015-02-03 07:43:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/Gc1uW9gypn",
      "expanded_url" : "http:\/\/www.theguardian.com\/education\/2015\/jan\/21\/welsh-language-part-me-slipping-away?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/education\/2015\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562511564226695168",
  "text" : "what it feels like to forget a language http:\/\/t.co\/Gc1uW9gypn",
  "id" : 562511564226695168,
  "created_at" : "2015-02-03 07:23:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/WoY5KfTLQP",
      "expanded_url" : "http:\/\/birdandmoon.com\/dating.html",
      "display_url" : "birdandmoon.com\/dating.html"
    } ]
  },
  "geo" : { },
  "id_str" : "562509487026995201",
  "text" : "i like long walks up the beach and down the beach and up the beach and down the beach and up the beach and down the\u2026 http:\/\/t.co\/WoY5KfTLQP",
  "id" : 562509487026995201,
  "created_at" : "2015-02-03 07:14:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andrew dalby",
      "screen_name" : "ardalby",
      "indices" : [ 3, 11 ],
      "id_str" : "19645781",
      "id" : 19645781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/n3F3qcfUCg",
      "expanded_url" : "http:\/\/www.theguardian.com\/science\/2011\/sep\/05\/publish-perish-peer-review-science?INTCMP=SRCH",
      "display_url" : "theguardian.com\/science\/2011\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562227416484315136",
  "text" : "RT @ardalby: Such a sorry state of affairs http:\/\/t.co\/n3F3qcfUCg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/n3F3qcfUCg",
        "expanded_url" : "http:\/\/www.theguardian.com\/science\/2011\/sep\/05\/publish-perish-peer-review-science?INTCMP=SRCH",
        "display_url" : "theguardian.com\/science\/2011\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "562225218065039360",
    "text" : "Such a sorry state of affairs http:\/\/t.co\/n3F3qcfUCg",
    "id" : 562225218065039360,
    "created_at" : "2015-02-02 12:25:12 +0000",
    "user" : {
      "name" : "andrew dalby",
      "screen_name" : "ardalby",
      "protected" : false,
      "id_str" : "19645781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000785900654\/db137f2573665b3091ad03b5937a7302_normal.png",
      "id" : 19645781,
      "verified" : false
    }
  },
  "id" : 562227416484315136,
  "created_at" : "2015-02-02 12:33:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/gT53wQaUEn",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/1\/30\/7952859\/despecialized-edition-download",
      "display_url" : "vox.com\/2015\/1\/30\/7952\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562163196724011008",
  "text" : "This is the best version of Star Wars \u2014 and watching it is a crime http:\/\/t.co\/gT53wQaUEn",
  "id" : 562163196724011008,
  "created_at" : "2015-02-02 08:18:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]