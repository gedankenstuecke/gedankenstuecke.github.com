Grailbird.data.tweets_2015_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/NoUuVecFcK",
      "expanded_url" : "https:\/\/twitter.com\/rocza\/status\/605128465969479681",
      "display_url" : "twitter.com\/rocza\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605130190646296576",
  "text" : "RT @JBYoder: When your defense against retraction includes grounds for retraction ... https:\/\/t.co\/NoUuVecFcK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/NoUuVecFcK",
        "expanded_url" : "https:\/\/twitter.com\/rocza\/status\/605128465969479681",
        "display_url" : "twitter.com\/rocza\/status\/6\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "605129464889114625",
    "text" : "When your defense against retraction includes grounds for retraction ... https:\/\/t.co\/NoUuVecFcK",
    "id" : 605129464889114625,
    "created_at" : "2015-05-31 21:51:21 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 605130190646296576,
  "created_at" : "2015-05-31 21:54:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/dGLbikgbnT",
      "expanded_url" : "https:\/\/courserajunkie.wordpress.com\/2015\/05\/26\/courseras-free-statements-of-accomplisments-die-a-quiet-death\/",
      "display_url" : "courserajunkie.wordpress.com\/2015\/05\/26\/cou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605114440518889472",
  "text" : "RT @madprime: Coursera quietly removes free certificates. Compare\/contrast with EdX (nonprofit &amp; open source)? https:\/\/t.co\/dGLbikgbnT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/dGLbikgbnT",
        "expanded_url" : "https:\/\/courserajunkie.wordpress.com\/2015\/05\/26\/courseras-free-statements-of-accomplisments-die-a-quiet-death\/",
        "display_url" : "courserajunkie.wordpress.com\/2015\/05\/26\/cou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "605114050649948160",
    "text" : "Coursera quietly removes free certificates. Compare\/contrast with EdX (nonprofit &amp; open source)? https:\/\/t.co\/dGLbikgbnT",
    "id" : 605114050649948160,
    "created_at" : "2015-05-31 20:50:06 +0000",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 605114440518889472,
  "created_at" : "2015-05-31 20:51:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Weigel Lab",
      "screen_name" : "PlantEvolution",
      "indices" : [ 0, 15 ],
      "id_str" : "100068931",
      "id" : 100068931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605110791398924288",
  "geo" : { },
  "id_str" : "605111011188830208",
  "in_reply_to_user_id" : 100068931,
  "text" : "@PlantEvolution yes, as for black there are plenty of people around. ;)",
  "id" : 605111011188830208,
  "in_reply_to_status_id" : 605110791398924288,
  "created_at" : "2015-05-31 20:38:02 +0000",
  "in_reply_to_screen_name" : "PlantEvolution",
  "in_reply_to_user_id_str" : "100068931",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Pisor",
      "screen_name" : "AnnePisor",
      "indices" : [ 3, 13 ],
      "id_str" : "595206056",
      "id" : 595206056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605081842744737792",
  "text" : "RT @AnnePisor: Nicole Creanza: Language (phonemes) does track geo distance from Africa, but not cleanly: not predictive far from pop bottle\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HBES2015",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "604770750055055360",
    "text" : "Nicole Creanza: Language (phonemes) does track geo distance from Africa, but not cleanly: not predictive far from pop bottlenecks. #HBES2015",
    "id" : 604770750055055360,
    "created_at" : "2015-05-30 22:05:57 +0000",
    "user" : {
      "name" : "Anne Pisor",
      "screen_name" : "AnnePisor",
      "protected" : false,
      "id_str" : "595206056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/907883130010423296\/5_Bqiq8g_normal.jpg",
      "id" : 595206056,
      "verified" : false
    }
  },
  "id" : 605081842744737792,
  "created_at" : "2015-05-31 18:42:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/FaHVCC8Zd0",
      "expanded_url" : "http:\/\/nsmn1.uh.edu\/dgraur\/texts\/cancerhaldane.htm",
      "display_url" : "nsmn1.uh.edu\/dgraur\/texts\/c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407396248063, 8.753322807364478 ]
  },
  "id_str" : "605073437439238144",
  "text" : "TIAL: Haldane wrote \u2018Cancer\u2019s a Funny Thing\u2019\n\n\u00ABMy rectum is a serious loss to me, \nBut I\u2019ve a very neat colostomy\u00BB\n\nhttp:\/\/t.co\/FaHVCC8Zd0",
  "id" : 605073437439238144,
  "created_at" : "2015-05-31 18:08:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407331929431, 8.753322627910647 ]
  },
  "id_str" : "605063812253917184",
  "text" : "Might accidentally have found the first person who thinks openSNP isn\u2019t operating in a legal gray area.",
  "id" : 605063812253917184,
  "created_at" : "2015-05-31 17:30:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/HCZQwkTTgt",
      "expanded_url" : "https:\/\/books.google.de\/books?id=GzxvfRbIMbAC&pg=PA21&lpg=PA21&dq=haldane+pepper+gas+lecture&source=bl&ots=kxDfVxQKZ9&sig=SweVLKL_-gIOgfbHBk2Rwvuk2zU&hl=en&sa=X&ei=BN5qVduLD4HlUcaFgYgE&ved=0CB0Q6AEwAA#v=onepage&q=haldane%20pepper%20gas%20lecture&f=false",
      "display_url" : "books.google.de\/books?id=Gzxvf\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407412764106, 8.753322793159453 ]
  },
  "id_str" : "604953417572851712",
  "text" : "TIL: Haldane once pepper-gassed the audience of one of his lectures for demo purposes. https:\/\/t.co\/HCZQwkTTgt",
  "id" : 604953417572851712,
  "created_at" : "2015-05-31 10:11:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604931043041374208",
  "geo" : { },
  "id_str" : "604931760250613760",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski we\u2019re still fighting over who won the past matches. Damn prior-selection.",
  "id" : 604931760250613760,
  "in_reply_to_status_id" : 604931043041374208,
  "created_at" : "2015-05-31 08:45:45 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140733063291, 8.753322188494195 ]
  },
  "id_str" : "604929989985861632",
  "text" : "Fisher vs. Bayes. The perfect way to start a breakfast (or a war).",
  "id" : 604929989985861632,
  "created_at" : "2015-05-31 08:38:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604780314066599937",
  "geo" : { },
  "id_str" : "604781279549255680",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon &lt;3",
  "id" : 604781279549255680,
  "in_reply_to_status_id" : 604780314066599937,
  "created_at" : "2015-05-30 22:47:47 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 0, 13 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604777270729945088",
  "geo" : { },
  "id_str" : "604777459058405378",
  "in_reply_to_user_id" : 1421360166,
  "text" : "@ToxXInFlames I definitely feel more like special needs.",
  "id" : 604777459058405378,
  "in_reply_to_status_id" : 604777270729945088,
  "created_at" : "2015-05-30 22:32:37 +0000",
  "in_reply_to_screen_name" : "ToxXInFlames",
  "in_reply_to_user_id_str" : "1421360166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reasons",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604414652781580288",
  "text" : "\u00ABDawkins\u2019 intellectual forefather Ronald Fisher, who was a radical adaptationist before Dawkins was even a genotype\u2026\u00BB #reasons",
  "id" : 604414652781580288,
  "created_at" : "2015-05-29 22:30:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604401694861082624",
  "text" : "\u00ABKassel is an even greater enigma. What was I doing in Kassel? How and why did I get there?\u00BB Oh Feyerabend, I feel you.",
  "id" : 604401694861082624,
  "created_at" : "2015-05-29 21:39:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Montague",
      "screen_name" : "monkeymullet",
      "indices" : [ 3, 16 ],
      "id_str" : "15989138",
      "id" : 15989138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604363749345116160",
  "text" : "RT @monkeymullet: Back From Yet Another Adventure, Indiana Jones Checks His Mail And Discovers That His Bid For Tenure Has Been Denied http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/cm36zwPNRm",
        "expanded_url" : "http:\/\/bit.ly\/1am1NYw",
        "display_url" : "bit.ly\/1am1NYw"
      } ]
    },
    "geo" : { },
    "id_str" : "604362928720990208",
    "text" : "Back From Yet Another Adventure, Indiana Jones Checks His Mail And Discovers That His Bid For Tenure Has Been Denied http:\/\/t.co\/cm36zwPNRm",
    "id" : 604362928720990208,
    "created_at" : "2015-05-29 19:05:25 +0000",
    "user" : {
      "name" : "Mike Montague",
      "screen_name" : "monkeymullet",
      "protected" : false,
      "id_str" : "15989138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67788238\/D06EA5711F752CD3113C2D694C1522_normal.jpg",
      "id" : 15989138,
      "verified" : false
    }
  },
  "id" : 604363749345116160,
  "created_at" : "2015-05-29 19:08:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pall Melsted",
      "screen_name" : "pmelsted",
      "indices" : [ 3, 12 ],
      "id_str" : "1135472480",
      "id" : 1135472480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/dEhu3ldqFG",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/biorxiv\/early\/2015\/05\/29\/020024.full.pdf",
      "display_url" : "biorxiv.org\/content\/biorxi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "604361770938015747",
  "text" : "RT @pmelsted: holy cow, there is a new BAM format http:\/\/t.co\/dEhu3ldqFG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/dEhu3ldqFG",
        "expanded_url" : "http:\/\/biorxiv.org\/content\/biorxiv\/early\/2015\/05\/29\/020024.full.pdf",
        "display_url" : "biorxiv.org\/content\/biorxi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "604347881483427842",
    "text" : "holy cow, there is a new BAM format http:\/\/t.co\/dEhu3ldqFG",
    "id" : 604347881483427842,
    "created_at" : "2015-05-29 18:05:37 +0000",
    "user" : {
      "name" : "Pall Melsted",
      "screen_name" : "pmelsted",
      "protected" : false,
      "id_str" : "1135472480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3185781099\/3f5c881ce8adc3b5aaf3568530290c31_normal.jpeg",
      "id" : 1135472480,
      "verified" : false
    }
  },
  "id" : 604361770938015747,
  "created_at" : "2015-05-29 19:00:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    }, {
      "name" : "This American Life",
      "screen_name" : "ThisAmerLife",
      "indices" : [ 110, 123 ],
      "id_str" : "149180925",
      "id" : 149180925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RainbowRetraction",
      "indices" : [ 69, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604337902290669568",
  "text" : "RT @JBYoder: Previous from GREAT piece on grad student who uncovered #RainbowRetraction, who deserves his own @ThisAmerLife bit: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "This American Life",
        "screen_name" : "ThisAmerLife",
        "indices" : [ 97, 110 ],
        "id_str" : "149180925",
        "id" : 149180925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RainbowRetraction",
        "indices" : [ 56, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/KBpe8cwR4S",
        "expanded_url" : "http:\/\/nymag.com\/scienceofus\/2015\/05\/how-a-grad-student-uncovered-a-huge-fraud.html",
        "display_url" : "nymag.com\/scienceofus\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "604335155872817152",
    "text" : "Previous from GREAT piece on grad student who uncovered #RainbowRetraction, who deserves his own @ThisAmerLife bit: http:\/\/t.co\/KBpe8cwR4S",
    "id" : 604335155872817152,
    "created_at" : "2015-05-29 17:15:03 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 604337902290669568,
  "created_at" : "2015-05-29 17:25:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I really, really like bears",
      "screen_name" : "tonitonirocca",
      "indices" : [ 3, 17 ],
      "id_str" : "45281719",
      "id" : 45281719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604326686503628801",
  "text" : "RT @tonitonirocca: Genders are like cars, everyone keeps telling me I abso need one and I keep going \"I LIVE IN SAN FRANCISCO\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "337697644468129792",
    "text" : "Genders are like cars, everyone keeps telling me I abso need one and I keep going \"I LIVE IN SAN FRANCISCO\"",
    "id" : 337697644468129792,
    "created_at" : "2013-05-23 22:32:47 +0000",
    "user" : {
      "name" : "I really, really like bears",
      "screen_name" : "tonitonirocca",
      "protected" : false,
      "id_str" : "45281719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559885770261925888\/lAyzKYqH_normal.png",
      "id" : 45281719,
      "verified" : false
    }
  },
  "id" : 604326686503628801,
  "created_at" : "2015-05-29 16:41:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/604314499760406528\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/tIfGoSmUUl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGL01ccWUAA7kn9.png",
      "id_str" : "604314499026407424",
      "id" : 604314499026407424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGL01ccWUAA7kn9.png",
      "sizes" : [ {
        "h" : 83,
        "resize" : "fit",
        "w" : 657
      }, {
        "h" : 83,
        "resize" : "fit",
        "w" : 657
      }, {
        "h" : 83,
        "resize" : "fit",
        "w" : 657
      }, {
        "h" : 83,
        "resize" : "crop",
        "w" : 83
      }, {
        "h" : 83,
        "resize" : "fit",
        "w" : 657
      } ],
      "display_url" : "pic.twitter.com\/tIfGoSmUUl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226516696498, 8.627529796654159 ]
  },
  "id_str" : "604314499760406528",
  "text" : "Uh, okay. http:\/\/t.co\/tIfGoSmUUl",
  "id" : 604314499760406528,
  "created_at" : "2015-05-29 15:52:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/1icGrmliGZ",
      "expanded_url" : "http:\/\/www.pbs.org\/wgbh\/nova\/labs\/lab\/evolution\/research#\/chooser",
      "display_url" : "pbs.org\/wgbh\/nova\/labs\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223319497936, 8.627553410016768 ]
  },
  "id_str" : "604296823344349185",
  "text" : "What a sweet Evolution game: learn to think with trees http:\/\/t.co\/1icGrmliGZ",
  "id" : 604296823344349185,
  "created_at" : "2015-05-29 14:42:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604199046031511552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722646565005, 8.627530846248634 ]
  },
  "id_str" : "604200872529252352",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski and that might work as alternative medicine as well? ;)",
  "id" : 604200872529252352,
  "in_reply_to_status_id" : 604199046031511552,
  "created_at" : "2015-05-29 08:21:28 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604198536239038464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227900994709, 8.62752190940419 ]
  },
  "id_str" : "604198894151581696",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski obviously they should send you advertising for workshops on building cardboard telescopes.",
  "id" : 604198894151581696,
  "in_reply_to_status_id" : 604198536239038464,
  "created_at" : "2015-05-29 08:13:36 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604198179857383424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225106868493, 8.627568489934935 ]
  },
  "id_str" : "604198417473105920",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski goes on: \u00ABWould you like to start learning Python or R? Is Linux command line interface a complete stranger to you?\u00BB",
  "id" : 604198417473105920,
  "in_reply_to_status_id" : 604198179857383424,
  "created_at" : "2015-05-29 08:11:42 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225106868493, 8.627568489934935 ]
  },
  "id_str" : "604198037234290688",
  "text" : "\u00ABDear Dr. Greshake, have you ever thought about doing biological data analysis by yourself?\u00BB Well targeted advertising\u2026",
  "id" : 604198037234290688,
  "created_at" : "2015-05-29 08:10:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "feyerabend",
      "indices" : [ 133, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223325736524, 8.627600446038612 ]
  },
  "id_str" : "604190275309834240",
  "text" : "\u00ABExcellence in all fields looked like an urge to conform. Fortunately I was often reprimanded &amp; once even thrown out of school.\u00BB #feyerabend",
  "id" : 604190275309834240,
  "created_at" : "2015-05-29 07:39:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/0BQbHbJRV0",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/5\/27\/8665401\/nuclear-power-gender",
      "display_url" : "vox.com\/2015\/5\/27\/8665\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218306398171, 8.627687005601102 ]
  },
  "id_str" : "604184344085860352",
  "text" : "\u00ABThe \"risk-averse female\" archetype [\u2026] reflects deep-seated social and gender assumptions more than research.\u00BB http:\/\/t.co\/0BQbHbJRV0",
  "id" : 604184344085860352,
  "created_at" : "2015-05-29 07:15:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/HdjWKkyckR",
      "expanded_url" : "http:\/\/xkcd.com\/1531\/",
      "display_url" : "xkcd.com\/1531\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222639193828, 8.62755467414979 ]
  },
  "id_str" : "604180856224256000",
  "text" : "For nerd sniping-purposes add a made-up effect\/hypothesis. http:\/\/t.co\/HdjWKkyckR",
  "id" : 604180856224256000,
  "created_at" : "2015-05-29 07:01:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 0, 14 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 24, 32 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604030605198807041",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406987864012, 8.753323102579863 ]
  },
  "id_str" : "604031436992188417",
  "in_reply_to_user_id" : 20444825,
  "text" : "@genetics_blog I\u2019m sure @glyn_dk is happy to answer your questions re:repositive. :)",
  "id" : 604031436992188417,
  "in_reply_to_status_id" : 604030605198807041,
  "created_at" : "2015-05-28 21:08:11 +0000",
  "in_reply_to_screen_name" : "strnr",
  "in_reply_to_user_id_str" : "20444825",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 4, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/I64BE0C7e8",
      "expanded_url" : "http:\/\/www.open-bio.org\/wiki\/BOSC_2015_Schedule",
      "display_url" : "open-bio.org\/wiki\/BOSC_2015\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140723236469, 8.753323056186984 ]
  },
  "id_str" : "604026412849328129",
  "text" : "The #BOSC2015 schedule is now available. I\u2019ll be there to speak on openSNP: http:\/\/t.co\/I64BE0C7e8",
  "id" : 604026412849328129,
  "created_at" : "2015-05-28 20:48:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/aL3Dhidn0K",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics\/archive.php?comicid=1531",
      "display_url" : "phdcomics.com\/comics\/archive\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "603933520105472000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228601743395, 8.627505869547567 ]
  },
  "id_str" : "603933852978061312",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer i see, will add a bit more branching &amp; merging to get around http:\/\/t.co\/aL3Dhidn0K",
  "id" : 603933852978061312,
  "in_reply_to_status_id" : 603933520105472000,
  "created_at" : "2015-05-28 14:40:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meghan Duffy",
      "screen_name" : "duffy_ma",
      "indices" : [ 3, 12 ],
      "id_str" : "453892183",
      "id" : 453892183
    }, {
      "name" : "ps",
      "screen_name" : "PatSchloss",
      "indices" : [ 97, 108 ],
      "id_str" : "185631499",
      "id" : 185631499
    }, {
      "name" : "Software Carpentry",
      "screen_name" : "swcarpentry",
      "indices" : [ 115, 127 ],
      "id_str" : "125695429",
      "id" : 125695429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603919815171022848",
  "text" : "RT @duffy_ma: Data and code for the paper I just had accepted are on GitHub, thanks to help from @PatSchloss &amp; @swcarpentry https:\/\/t.co\/9j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ps",
        "screen_name" : "PatSchloss",
        "indices" : [ 83, 94 ],
        "id_str" : "185631499",
        "id" : 185631499
      }, {
        "name" : "Software Carpentry",
        "screen_name" : "swcarpentry",
        "indices" : [ 101, 113 ],
        "id_str" : "125695429",
        "id" : 125695429
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/9jZYECggXD",
        "expanded_url" : "https:\/\/dynamicecology.wordpress.com\/2015\/05\/28\/my-first-experience-with-github-for-sharing-data-and-code\/",
        "display_url" : "dynamicecology.wordpress.com\/2015\/05\/28\/my-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "603887574306922496",
    "text" : "Data and code for the paper I just had accepted are on GitHub, thanks to help from @PatSchloss &amp; @swcarpentry https:\/\/t.co\/9jZYECggXD",
    "id" : 603887574306922496,
    "created_at" : "2015-05-28 11:36:32 +0000",
    "user" : {
      "name" : "Meghan Duffy",
      "screen_name" : "duffy_ma",
      "protected" : false,
      "id_str" : "453892183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/862413420385251331\/U0ufMi47_normal.jpg",
      "id" : 453892183,
      "verified" : true
    }
  },
  "id" : 603919815171022848,
  "created_at" : "2015-05-28 13:44:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603890276118175744",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw: did you ever give the Software Carpentry workshop on git? If yes: would you do one in Frankfurt while still around? :D",
  "id" : 603890276118175744,
  "created_at" : "2015-05-28 11:47:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/ebc7MKMp2B",
      "expanded_url" : "http:\/\/copywrongs.eu",
      "display_url" : "copywrongs.eu"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/ysSrWdVUTp",
      "expanded_url" : "https:\/\/youtube.com\/watch?v=o9FTp_htnnc",
      "display_url" : "youtube.com\/watch?v=o9FTp_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603877984093794304",
  "text" : "RT @Senficon: Save copyright reform! Contact your members of the European Parliament now: http:\/\/t.co\/ebc7MKMp2B https:\/\/t.co\/ysSrWdVUTp #F\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FixCopyright",
        "indices" : [ 123, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/ebc7MKMp2B",
        "expanded_url" : "http:\/\/copywrongs.eu",
        "display_url" : "copywrongs.eu"
      }, {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/ysSrWdVUTp",
        "expanded_url" : "https:\/\/youtube.com\/watch?v=o9FTp_htnnc",
        "display_url" : "youtube.com\/watch?v=o9FTp_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "603848201934868480",
    "text" : "Save copyright reform! Contact your members of the European Parliament now: http:\/\/t.co\/ebc7MKMp2B https:\/\/t.co\/ysSrWdVUTp #FixCopyright",
    "id" : 603848201934868480,
    "created_at" : "2015-05-28 09:00:04 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 603877984093794304,
  "created_at" : "2015-05-28 10:58:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "statsdonewrong",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603698482201911296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.08945406140023, 7.613675678155956 ]
  },
  "id_str" : "603698635818278912",
  "in_reply_to_user_id" : 14286491,
  "text" : "#statsdonewrong is a fun light read.",
  "id" : 603698635818278912,
  "in_reply_to_status_id" : 603698482201911296,
  "created_at" : "2015-05-27 23:05:45 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.08945406140023, 7.613675678155956 ]
  },
  "id_str" : "603698482201911296",
  "text" : "\u00ABMisconceptions are like cockroaches: you have no idea where they came from, but they\u2019re everywhere &amp; they\u2019re impervious to nuclear weapons\u00BB",
  "id" : 603698482201911296,
  "created_at" : "2015-05-27 23:05:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Q6Ru4ZKZbg",
      "expanded_url" : "http:\/\/www.open-bio.org\/wiki\/BOSC_2015",
      "display_url" : "open-bio.org\/wiki\/BOSC_2015"
    } ]
  },
  "geo" : { },
  "id_str" : "603690496117088256",
  "text" : "RT @OBF_BOSC: Call for Abstracts for Late-Breaking Lightning Talks and Posters (due June 5): http:\/\/t.co\/Q6Ru4ZKZbg #BOSC2015",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2015",
        "indices" : [ 102, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/Q6Ru4ZKZbg",
        "expanded_url" : "http:\/\/www.open-bio.org\/wiki\/BOSC_2015",
        "display_url" : "open-bio.org\/wiki\/BOSC_2015"
      } ]
    },
    "geo" : { },
    "id_str" : "603685021187211266",
    "text" : "Call for Abstracts for Late-Breaking Lightning Talks and Posters (due June 5): http:\/\/t.co\/Q6Ru4ZKZbg #BOSC2015",
    "id" : 603685021187211266,
    "created_at" : "2015-05-27 22:11:39 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 603690496117088256,
  "created_at" : "2015-05-27 22:33:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/AU0Y9V21G6",
      "expanded_url" : "http:\/\/moby.to\/e48c2f",
      "display_url" : "moby.to\/e48c2f"
    } ]
  },
  "in_reply_to_status_id_str" : "603615002029875200",
  "geo" : { },
  "id_str" : "603685216490790912",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks there you go! http:\/\/t.co\/AU0Y9V21G6",
  "id" : 603685216490790912,
  "in_reply_to_status_id" : 603615002029875200,
  "created_at" : "2015-05-27 22:12:26 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 3, 12 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Sage Bionetworks",
      "screen_name" : "Sagebio",
      "indices" : [ 33, 41 ],
      "id_str" : "130579391",
      "id" : 130579391
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "researchkit",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603671606410502145",
  "text" : "RT @eramirez: The great folks at @Sagebio are looking for iOS devs to work on #researchkit apps with them. Details here: http:\/\/t.co\/4mfO8R\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sage Bionetworks",
        "screen_name" : "Sagebio",
        "indices" : [ 19, 27 ],
        "id_str" : "130579391",
        "id" : 130579391
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "researchkit",
        "indices" : [ 64, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/4mfO8R4XG6",
        "expanded_url" : "http:\/\/sagebase.org\/current-positions\/software-engineer-ios-mobile-development\/",
        "display_url" : "sagebase.org\/current-positi\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 33.99887802979411, -118.4365620505016 ]
    },
    "id_str" : "603641642097119233",
    "text" : "The great folks at @Sagebio are looking for iOS devs to work on #researchkit apps with them. Details here: http:\/\/t.co\/4mfO8R4XG6",
    "id" : 603641642097119233,
    "created_at" : "2015-05-27 19:19:17 +0000",
    "user" : {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "protected" : false,
      "id_str" : "21135674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/866822214267666432\/IYzsQHYG_normal.jpg",
      "id" : 21135674,
      "verified" : false
    }
  },
  "id" : 603671606410502145,
  "created_at" : "2015-05-27 21:18:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Steven Keating",
      "screen_name" : "stevenkeating",
      "indices" : [ 10, 24 ],
      "id_str" : "19216179",
      "id" : 19216179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603652463003095040",
  "geo" : { },
  "id_str" : "603659178343800832",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @stevenkeating same here. Would love to upgrade from exome to WGS some time soon.",
  "id" : 603659178343800832,
  "in_reply_to_status_id" : 603652463003095040,
  "created_at" : "2015-05-27 20:28:58 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Assemblathon",
      "screen_name" : "assemblathon",
      "indices" : [ 56, 69 ],
      "id_str" : "216793572",
      "id" : 216793572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603578545315545088",
  "geo" : { },
  "id_str" : "603652137592233984",
  "in_reply_to_user_id" : 216793572,
  "text" : "\u2018An assembly of bioinformaticians\u2019, nice group term. RT @assemblathon: 2,500 followers! That\u2019s quite an assembly \uD83D\uDE00",
  "id" : 603652137592233984,
  "in_reply_to_status_id" : 603578545315545088,
  "created_at" : "2015-05-27 20:00:59 +0000",
  "in_reply_to_screen_name" : "assemblathon",
  "in_reply_to_user_id_str" : "216793572",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Keating",
      "screen_name" : "stevenkeating",
      "indices" : [ 0, 14 ],
      "id_str" : "19216179",
      "id" : 19216179
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 15, 24 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603633398234644480",
  "geo" : { },
  "id_str" : "603641774410698753",
  "in_reply_to_user_id" : 19216179,
  "text" : "@stevenkeating @madprime very nice. All the best for your presentation :)",
  "id" : 603641774410698753,
  "in_reply_to_status_id" : 603633398234644480,
  "created_at" : "2015-05-27 19:19:48 +0000",
  "in_reply_to_screen_name" : "stevenkeating",
  "in_reply_to_user_id_str" : "19216179",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603615002029875200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.94202158078573, 7.381709163682507 ]
  },
  "id_str" : "603621948640342016",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks will deliver later. :)",
  "id" : 603621948640342016,
  "in_reply_to_status_id" : 603615002029875200,
  "created_at" : "2015-05-27 18:01:01 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David J. Pearce",
      "screen_name" : "whileydave",
      "indices" : [ 3, 14 ],
      "id_str" : "302526206",
      "id" : 302526206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/Sn6R7oePAT",
      "expanded_url" : "http:\/\/www.benfrederickson.com\/unicode-insanity\/",
      "display_url" : "benfrederickson.com\/unicode-insani\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603561584028459009",
  "text" : "RT @whileydave: Unicode is Crazy!! \uD83D\uDCA9 http:\/\/t.co\/Sn6R7oePAT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/Sn6R7oePAT",
        "expanded_url" : "http:\/\/www.benfrederickson.com\/unicode-insanity\/",
        "display_url" : "benfrederickson.com\/unicode-insani\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "603479261039599617",
    "text" : "Unicode is Crazy!! \uD83D\uDCA9 http:\/\/t.co\/Sn6R7oePAT",
    "id" : 603479261039599617,
    "created_at" : "2015-05-27 08:34:02 +0000",
    "user" : {
      "name" : "David J. Pearce",
      "screen_name" : "whileydave",
      "protected" : false,
      "id_str" : "302526206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531540476050948096\/BupmEBal_normal.jpeg",
      "id" : 302526206,
      "verified" : false
    }
  },
  "id" : 603561584028459009,
  "created_at" : "2015-05-27 14:01:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Steven Keating",
      "screen_name" : "stevenkeating",
      "indices" : [ 10, 24 ],
      "id_str" : "19216179",
      "id" : 19216179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603557708344782849",
  "geo" : { },
  "id_str" : "603558119726256128",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @stevenkeating thanks, there must be someone with free capacities on their X Ten. :)",
  "id" : 603558119726256128,
  "in_reply_to_status_id" : 603557708344782849,
  "created_at" : "2015-05-27 13:47:23 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Steven Keating",
      "screen_name" : "stevenkeating",
      "indices" : [ 10, 24 ],
      "id_str" : "19216179",
      "id" : 19216179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603554000043118592",
  "geo" : { },
  "id_str" : "603555146849726464",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @stevenkeating that\u2019s still too expensive by a factor of 2. ;)",
  "id" : 603555146849726464,
  "in_reply_to_status_id" : 603554000043118592,
  "created_at" : "2015-05-27 13:35:35 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Steven Keating",
      "screen_name" : "stevenkeating",
      "indices" : [ 10, 24 ],
      "id_str" : "19216179",
      "id" : 19216179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603549727137931264",
  "geo" : { },
  "id_str" : "603552702870790144",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @stevenkeating more importantly: how can I get my genome done. ;)",
  "id" : 603552702870790144,
  "in_reply_to_status_id" : 603549727137931264,
  "created_at" : "2015-05-27 13:25:52 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 42, 51 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229586722734, 8.627592431486649 ]
  },
  "id_str" : "603485597467090944",
  "text" : "I\u2019m so glad I did the snoopy-dance-GIF of @wilbanks. Finally I can correctly acknowledge him in my slide decks!",
  "id" : 603485597467090944,
  "created_at" : "2015-05-27 08:59:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Keating",
      "screen_name" : "stevenkeating",
      "indices" : [ 0, 14 ],
      "id_str" : "19216179",
      "id" : 19216179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603379763646889984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218295576173, 8.627504425829665 ]
  },
  "id_str" : "603451084959522816",
  "in_reply_to_user_id" : 19216179,
  "text" : "@stevenkeating through which route did you get them to do it? :)",
  "id" : 603451084959522816,
  "in_reply_to_status_id" : 603379763646889984,
  "created_at" : "2015-05-27 06:42:04 +0000",
  "in_reply_to_screen_name" : "stevenkeating",
  "in_reply_to_user_id_str" : "19216179",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 8, 17 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603288538101059584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140730752184, 8.753322983506242 ]
  },
  "id_str" : "603294081767383042",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn @eramirez I always forget that you\u2019re supposed to be the enemy now :p",
  "id" : 603294081767383042,
  "in_reply_to_status_id" : 603288538101059584,
  "created_at" : "2015-05-26 20:18:12 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 10, 17 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603284842525036544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407289789459, 8.753322827423805 ]
  },
  "id_str" : "603287439483006978",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @mrgunn sounds a bit like handwaving at higher powers that be. ;)",
  "id" : 603287439483006978,
  "in_reply_to_status_id" : 603284842525036544,
  "created_at" : "2015-05-26 19:51:48 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 10, 17 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603282898779668481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407277566377, 8.753323072408723 ]
  },
  "id_str" : "603283291937079296",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @mrgunn but I\u2019m not buying the UX argument either. If that would be the case: Why not include in the data export?",
  "id" : 603283291937079296,
  "in_reply_to_status_id" : 603282898779668481,
  "created_at" : "2015-05-26 19:35:19 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 10, 17 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603282898779668481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407334760688, 8.75332307123747 ]
  },
  "id_str" : "603283052794617857",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @mrgunn ok, so it\u2019s not the most obvious case of \u201Cbecause we want to make money out of it\u201D ;)",
  "id" : 603283052794617857,
  "in_reply_to_status_id" : 603282898779668481,
  "created_at" : "2015-05-26 19:34:22 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 10, 17 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603282047021416448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407334760688, 8.75332307123747 ]
  },
  "id_str" : "603282669129043969",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @mrgunn is\/was the intraday-export part of the premium account? ;-)",
  "id" : 603282669129043969,
  "in_reply_to_status_id" : 603282047021416448,
  "created_at" : "2015-05-26 19:32:51 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603277061713629184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407312151442, 8.75332268123085 ]
  },
  "id_str" : "603277949287170049",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez this I really want! Where do I have to write to? ;)",
  "id" : 603277949287170049,
  "in_reply_to_status_id" : 603277061713629184,
  "created_at" : "2015-05-26 19:14:06 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mittelman",
      "screen_name" : "evolvability",
      "indices" : [ 0, 13 ],
      "id_str" : "199737585",
      "id" : 199737585
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 14, 28 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 29, 37 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 38, 47 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603272529709408256",
  "geo" : { },
  "id_str" : "603273495544467456",
  "in_reply_to_user_id" : 199737585,
  "text" : "@evolvability @BioMickWatson @mbeisen @kbradnam so we should be happy it\u2019s not the \u2018[B]ig [L]ibrary for [A]ll [S]cientific [T]exts\u2019.",
  "id" : 603273495544467456,
  "in_reply_to_status_id" : 603272529709408256,
  "created_at" : "2015-05-26 18:56:24 +0000",
  "in_reply_to_screen_name" : "evolvability",
  "in_reply_to_user_id_str" : "199737585",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mittelman",
      "screen_name" : "evolvability",
      "indices" : [ 0, 13 ],
      "id_str" : "199737585",
      "id" : 199737585
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 14, 28 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 29, 37 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 49, 58 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603265188729458688",
  "geo" : { },
  "id_str" : "603272062162096128",
  "in_reply_to_user_id" : 199737585,
  "text" : "@evolvability @BioMickWatson @mbeisen watch out, @kbradnam may hand out a JABBA award for that!",
  "id" : 603272062162096128,
  "in_reply_to_status_id" : 603265188729458688,
  "created_at" : "2015-05-26 18:50:42 +0000",
  "in_reply_to_screen_name" : "evolvability",
  "in_reply_to_user_id_str" : "199737585",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603229698659717121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234575169214, 8.627534018158626 ]
  },
  "id_str" : "603230435779420161",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I\u2019ll give it a try. Would be really nice to have the higher resolution.",
  "id" : 603230435779420161,
  "in_reply_to_status_id" : 603229698659717121,
  "created_at" : "2015-05-26 16:05:18 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603229355863474176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723458437057, 8.627533927797597 ]
  },
  "id_str" : "603229518392852480",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez was in contact asking for general intra-data access for openSNP, at some point didn\u2019t hear back :(",
  "id" : 603229518392852480,
  "in_reply_to_status_id" : 603229355863474176,
  "created_at" : "2015-05-26 16:01:39 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603227859344236544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233501540012, 8.627544561633641 ]
  },
  "id_str" : "603229249386975232",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez unfortunately I don\u2019t think it will happen too soon\/ever. :(",
  "id" : 603229249386975232,
  "in_reply_to_status_id" : 603227859344236544,
  "created_at" : "2015-05-26 16:00:35 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 0, 13 ],
      "id_str" : "189118361",
      "id" : 189118361
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 68, 77 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 98, 107 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603225147013734400",
  "geo" : { },
  "id_str" : "603225611079970817",
  "in_reply_to_user_id" : 189118361,
  "text" : "@MaliciaRogue having him around is the main reason why I\u2019m lobbying @Senficon to collaborate with @wilbanks.",
  "id" : 603225611079970817,
  "in_reply_to_status_id" : 603225147013734400,
  "created_at" : "2015-05-26 15:46:07 +0000",
  "in_reply_to_screen_name" : "MaliciaRogue",
  "in_reply_to_user_id_str" : "189118361",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603225037064122368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218668447912, 8.6276911520679 ]
  },
  "id_str" : "603225192639438848",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez when will intra-day data become standard? :D",
  "id" : 603225192639438848,
  "in_reply_to_status_id" : 603225037064122368,
  "created_at" : "2015-05-26 15:44:27 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 3, 11 ],
      "id_str" : "454724555",
      "id" : 454724555
    }, {
      "name" : "Lior Pachter",
      "screen_name" : "lpachter",
      "indices" : [ 85, 94 ],
      "id_str" : "31936449",
      "id" : 31936449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/70bXum5raJ",
      "expanded_url" : "https:\/\/liorpachter.wordpress.com\/2015\/05\/26\/pachters-p-value-prize\/#comment-4329",
      "display_url" : "liorpachter.wordpress.com\/2015\/05\/26\/pac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603224153953542145",
  "text" : "RT @marc_rr: 11 years after Kellis et al 2004 a rebuttal is published\u2026 as comment on @lpachter's blog: https:\/\/t.co\/70bXum5raJ (we need blo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lior Pachter",
        "screen_name" : "lpachter",
        "indices" : [ 72, 81 ],
        "id_str" : "31936449",
        "id" : 31936449
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/70bXum5raJ",
        "expanded_url" : "https:\/\/liorpachter.wordpress.com\/2015\/05\/26\/pachters-p-value-prize\/#comment-4329",
        "display_url" : "liorpachter.wordpress.com\/2015\/05\/26\/pac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "603218441257013248",
    "text" : "11 years after Kellis et al 2004 a rebuttal is published\u2026 as comment on @lpachter's blog: https:\/\/t.co\/70bXum5raJ (we need blogs in science)",
    "id" : 603218441257013248,
    "created_at" : "2015-05-26 15:17:38 +0000",
    "user" : {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "protected" : false,
      "id_str" : "454724555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1751744306\/mrr_caricature_normal.jpg",
      "id" : 454724555,
      "verified" : false
    }
  },
  "id" : 603224153953542145,
  "created_at" : "2015-05-26 15:40:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603223330439573504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225105705997, 8.627582038553166 ]
  },
  "id_str" : "603223954610847744",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez And I see, it\u2019s just been like this since a couple of months, this explains it. :-)",
  "id" : 603223954610847744,
  "in_reply_to_status_id" : 603223330439573504,
  "created_at" : "2015-05-26 15:39:32 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603223045482762242",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225105705997, 8.627582038553166 ]
  },
  "id_str" : "603223268187832320",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez oh, I hadn\u2019t seen that. That\u2019s sweet!",
  "id" : 603223268187832320,
  "in_reply_to_status_id" : 603223045482762242,
  "created_at" : "2015-05-26 15:36:49 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 31, 38 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603222046412144640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225105705997, 8.627582038553166 ]
  },
  "id_str" : "603222374587224064",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I actually would, if @fitbit would allow to pair more than 1 device at the same time. But as is, it\u2019s too much effort.",
  "id" : 603222374587224064,
  "in_reply_to_status_id" : 603222046412144640,
  "created_at" : "2015-05-26 15:33:16 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 10, 23 ],
      "id_str" : "189118361",
      "id" : 189118361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603213016579121155",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225105705997, 8.627582038553166 ]
  },
  "id_str" : "603222168772685824",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @MaliciaRogue that\u2019s a shame. You have to spent more time here :)",
  "id" : 603222168772685824,
  "in_reply_to_status_id" : 603213016579121155,
  "created_at" : "2015-05-26 15:32:27 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Assemblathon",
      "screen_name" : "assemblathon",
      "indices" : [ 0, 13 ],
      "id_str" : "216793572",
      "id" : 216793572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603208737440927746",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17219570005118, 8.627647730589954 ]
  },
  "id_str" : "603220058861633537",
  "in_reply_to_user_id" : 216793572,
  "text" : "@assemblathon anything one can help with?",
  "id" : 603220058861633537,
  "in_reply_to_status_id" : 603208737440927746,
  "created_at" : "2015-05-26 15:24:03 +0000",
  "in_reply_to_screen_name" : "assemblathon",
  "in_reply_to_user_id_str" : "216793572",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Sage Bionetworks",
      "screen_name" : "Sagebio",
      "indices" : [ 65, 73 ],
      "id_str" : "130579391",
      "id" : 130579391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/wv8lOxRyZL",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/05\/26\/opinion\/the-university-of-minnesotas-medical-research-mess.html?_r=0",
      "display_url" : "nytimes.com\/2015\/05\/26\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603211874407215104",
  "text" : "RT @wilbanks: So, here\u2019s ethics reason for additional app review @Sagebio http:\/\/t.co\/wv8lOxRyZL and here\u2019s the technical reason: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sage Bionetworks",
        "screen_name" : "Sagebio",
        "indices" : [ 51, 59 ],
        "id_str" : "130579391",
        "id" : 130579391
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/wv8lOxRyZL",
        "expanded_url" : "http:\/\/www.nytimes.com\/2015\/05\/26\/opinion\/the-university-of-minnesotas-medical-research-mess.html?_r=0",
        "display_url" : "nytimes.com\/2015\/05\/26\/opi\u2026"
      }, {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/4sr1XWBkNh",
        "expanded_url" : "http:\/\/www.zdnet.com\/article\/researchers-track-commuters-using-stolen-mobile-accelerometer-data\/",
        "display_url" : "zdnet.com\/article\/resear\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "603192249187467264",
    "text" : "So, here\u2019s ethics reason for additional app review @Sagebio http:\/\/t.co\/wv8lOxRyZL and here\u2019s the technical reason: http:\/\/t.co\/4sr1XWBkNh",
    "id" : 603192249187467264,
    "created_at" : "2015-05-26 13:33:33 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 603211874407215104,
  "created_at" : "2015-05-26 14:51:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603136208135421952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218003718539, 8.627692099485822 ]
  },
  "id_str" : "603167283658268672",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon one of the simplest ways to feel incompetent, just read those 26 pages.",
  "id" : 603167283658268672,
  "in_reply_to_status_id" : 603136208135421952,
  "created_at" : "2015-05-26 11:54:21 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Horak",
      "screen_name" : "fatmike182",
      "indices" : [ 0, 11 ],
      "id_str" : "15271509",
      "id" : 15271509
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 12, 27 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603164329207300096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218134771226, 8.62760737931287 ]
  },
  "id_str" : "603164682518691840",
  "in_reply_to_user_id" : 15271509,
  "text" : "@fatmike182 @gedankenabfall echt, welche z.B.? Bei 23andMe lag es am aggressive advertising iirc.",
  "id" : 603164682518691840,
  "in_reply_to_status_id" : 603164329207300096,
  "created_at" : "2015-05-26 11:44:01 +0000",
  "in_reply_to_screen_name" : "fatmike182",
  "in_reply_to_user_id_str" : "15271509",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Horak",
      "screen_name" : "fatmike182",
      "indices" : [ 0, 11 ],
      "id_str" : "15271509",
      "id" : 15271509
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 12, 27 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/MSPufOPbsM",
      "expanded_url" : "https:\/\/promethease.com\/ondemandlicense",
      "display_url" : "promethease.com\/ondemandlicense"
    } ]
  },
  "in_reply_to_status_id_str" : "603162794213699584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218293011957, 8.627507753066759 ]
  },
  "id_str" : "603163901258248192",
  "in_reply_to_user_id" : 15271509,
  "text" : "@fatmike182 @gedankenabfall ja, die FDA hats unterbunden. Gibt aber Alternativen die 23andMe-Daten untersuchen, e.g. https:\/\/t.co\/MSPufOPbsM",
  "id" : 603163901258248192,
  "in_reply_to_status_id" : 603162794213699584,
  "created_at" : "2015-05-26 11:40:54 +0000",
  "in_reply_to_screen_name" : "fatmike182",
  "in_reply_to_user_id_str" : "15271509",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603097991558406145",
  "geo" : { },
  "id_str" : "603098997524402176",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich \uD83C\uDF89",
  "id" : 603098997524402176,
  "in_reply_to_status_id" : 603097991558406145,
  "created_at" : "2015-05-26 07:23:00 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/cI3eo3Iayl",
      "expanded_url" : "https:\/\/www.beaconreader.com\/arikia-millikan\/packing-is-the-easy-part",
      "display_url" : "beaconreader.com\/arikia-millika\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220070941434, 8.62762996251487 ]
  },
  "id_str" : "603096070504198144",
  "text" : "\u00AB[\u2026] it\u2019s not like I\u2019m going to war or something. Unless someone wants to pay me to write about it. Then I would.\u00BB https:\/\/t.co\/cI3eo3Iayl",
  "id" : 603096070504198144,
  "created_at" : "2015-05-26 07:11:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603089730092212224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220202308815, 8.62762910118454 ]
  },
  "id_str" : "603091781538971648",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez in any case, I\u2019m already agitated about loosing data when charging my Charge HR every couple of days. ;-)",
  "id" : 603091781538971648,
  "in_reply_to_status_id" : 603089730092212224,
  "created_at" : "2015-05-26 06:54:20 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603089730092212224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229749163229, 8.6275757743415 ]
  },
  "id_str" : "603091633320656896",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez not sure either, but I guess the data collected during sleep might be nice to correlate with other sleep measurements.",
  "id" : 603091633320656896,
  "in_reply_to_status_id" : 603089730092212224,
  "created_at" : "2015-05-26 06:53:44 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603089150623940608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231159247394, 8.627558640478089 ]
  },
  "id_str" : "603089402286514176",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I thought so. Biggest issue w\/ Watch for me: charging over night = no HR readings for ~6h every day.",
  "id" : 603089402286514176,
  "in_reply_to_status_id" : 603089150623940608,
  "created_at" : "2015-05-26 06:44:53 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603063624748244992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226108543269, 8.62751863744467 ]
  },
  "id_str" : "603086366478606336",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez what\u2019s the x-axis showing?",
  "id" : 603086366478606336,
  "in_reply_to_status_id" : 603063624748244992,
  "created_at" : "2015-05-26 06:32:49 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/hDNx4pPAhH",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/82",
      "display_url" : "existentialcomics.com\/comic\/82"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226108543269, 8.62751863744467 ]
  },
  "id_str" : "603084968814870528",
  "text" : "Captain Metaphysics: Another problem solved by calculus http:\/\/t.co\/hDNx4pPAhH",
  "id" : 603084968814870528,
  "created_at" : "2015-05-26 06:27:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 3, 18 ],
      "id_str" : "14897792",
      "id" : 14897792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603077336351821825",
  "text" : "RT @michaelhoffman: New American Statistical Association membership plans permit members to reject null hypothesis at \u03B1 &gt; 0.05 http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/Q5GMSceaxp",
        "expanded_url" : "http:\/\/pnis.co\/scinews\/vol2_1.html",
        "display_url" : "pnis.co\/scinews\/vol2_1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "602990913175027714",
    "text" : "New American Statistical Association membership plans permit members to reject null hypothesis at \u03B1 &gt; 0.05 http:\/\/t.co\/Q5GMSceaxp",
    "id" : 602990913175027714,
    "created_at" : "2015-05-26 00:13:31 +0000",
    "user" : {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "protected" : false,
      "id_str" : "14897792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548279118576365568\/ETEKXJcp_normal.jpeg",
      "id" : 14897792,
      "verified" : false
    }
  },
  "id" : 603077336351821825,
  "created_at" : "2015-05-26 05:56:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/KonWLmfC2M",
      "expanded_url" : "https:\/\/vimeo.com\/73689431",
      "display_url" : "vimeo.com\/73689431"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407330946145, 8.753323257593706 ]
  },
  "id_str" : "602852911996149760",
  "text" : "One of the best things of the Ori Gersht exhibit: https:\/\/t.co\/KonWLmfC2M",
  "id" : 602852911996149760,
  "created_at" : "2015-05-25 15:05:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 29, 38 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/dUwpCde486",
      "expanded_url" : "https:\/\/www.songkick.com\/concerts\/23812258-mountain-goats-at-paradiso-noord-tolhuistuin",
      "display_url" : "songkick.com\/concerts\/23812\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407253303794, 8.753323064920403 ]
  },
  "id_str" : "602839365916696576",
  "text" : "Anyone interested in joining @Senficon &amp; me for The Mountain Goats in Amsterdam on 22nd of November? https:\/\/t.co\/dUwpCde486",
  "id" : 602839365916696576,
  "created_at" : "2015-05-25 14:11:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407420112027, 8.75332133136297 ]
  },
  "id_str" : "602767747307675648",
  "text" : "Large effects w\/ small N: \u00ABYour first reaction should not be \u201CWow, they\u2019ve found something big!\u201D but \u201CWow, this study is underpowered!\u201D\u00BB",
  "id" : 602767747307675648,
  "created_at" : "2015-05-25 09:26:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "statsdonewrong",
      "indices" : [ 114, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407406459104, 8.753322785138723 ]
  },
  "id_str" : "602765407284527104",
  "text" : "\u00ABOne possible explanation is that confidence intervals go unreported because they are often embarrassingly wide.\u00BB #statsdonewrong",
  "id" : 602765407284527104,
  "created_at" : "2015-05-25 09:17:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 10, 17 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602558945241092096",
  "geo" : { },
  "id_str" : "602580290238808067",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @fitbit still no heart rate? :(",
  "id" : 602580290238808067,
  "in_reply_to_status_id" : 602558945241092096,
  "created_at" : "2015-05-24 21:01:51 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602579140533956608",
  "text" : "\u00ABYou know what they say: don\u2019t drink &amp; drive down memory lane.\u00BB",
  "id" : 602579140533956608,
  "created_at" : "2015-05-24 20:57:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/8OjP5HQRmM",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2015\/05\/15\/017830",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.8793877682298, 8.645359867097072 ]
  },
  "id_str" : "602469509287534594",
  "text" : "An evaluation of the accuracy and speed of metagenome analysis tools http:\/\/t.co\/8OjP5HQRmM",
  "id" : 602469509287534594,
  "created_at" : "2015-05-24 13:41:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/602467192450473984\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/zQHkNFlw4h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFxkt6jWoAEAFCE.png",
      "id_str" : "602467190135234561",
      "id" : 602467190135234561,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFxkt6jWoAEAFCE.png",
      "sizes" : [ {
        "h" : 495,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 495,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 495,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 495,
        "resize" : "fit",
        "w" : 625
      } ],
      "display_url" : "pic.twitter.com\/zQHkNFlw4h"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/Ags5y1TTGy",
      "expanded_url" : "http:\/\/www.slideshare.net\/gedankenstuecke\/opensnp-geekend-darmstadt",
      "display_url" : "slideshare.net\/gedankenstueck\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.87934617040016, 8.645273428984048 ]
  },
  "id_str" : "602467192450473984",
  "text" : "Slides for the talk I gave at the Geekend http:\/\/t.co\/Ags5y1TTGy http:\/\/t.co\/zQHkNFlw4h",
  "id" : 602467192450473984,
  "created_at" : "2015-05-24 13:32:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Haaretz.com",
      "screen_name" : "haaretzcom",
      "indices" : [ 3, 14 ],
      "id_str" : "24506246",
      "id" : 24506246
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/haaretzcom\/status\/602392639707553793\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/GO0Cvt8x45",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFwg6gXUsAAZzJ2.jpg",
      "id_str" : "602392639653064704",
      "id" : 602392639653064704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFwg6gXUsAAZzJ2.jpg",
      "sizes" : [ {
        "h" : 274,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 274,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 274,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 274,
        "resize" : "fit",
        "w" : 474
      } ],
      "display_url" : "pic.twitter.com\/GO0Cvt8x45"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/OvZkUvrDfR",
      "expanded_url" : "http:\/\/dlvr.it\/9xlfqX",
      "display_url" : "dlvr.it\/9xlfqX"
    } ]
  },
  "geo" : { },
  "id_str" : "602393319763779584",
  "text" : "RT @haaretzcom: Venice police close Iceland's Bienalle mosque, deemed 'Not art' http:\/\/t.co\/OvZkUvrDfR http:\/\/t.co\/GO0Cvt8x45",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/haaretzcom\/status\/602392639707553793\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/GO0Cvt8x45",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFwg6gXUsAAZzJ2.jpg",
        "id_str" : "602392639653064704",
        "id" : 602392639653064704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFwg6gXUsAAZzJ2.jpg",
        "sizes" : [ {
          "h" : 274,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 274,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 274,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 274,
          "resize" : "fit",
          "w" : 474
        } ],
        "display_url" : "pic.twitter.com\/GO0Cvt8x45"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/OvZkUvrDfR",
        "expanded_url" : "http:\/\/dlvr.it\/9xlfqX",
        "display_url" : "dlvr.it\/9xlfqX"
      } ]
    },
    "geo" : { },
    "id_str" : "602392639707553793",
    "text" : "Venice police close Iceland's Bienalle mosque, deemed 'Not art' http:\/\/t.co\/OvZkUvrDfR http:\/\/t.co\/GO0Cvt8x45",
    "id" : 602392639707553793,
    "created_at" : "2015-05-24 08:36:11 +0000",
    "user" : {
      "name" : "Haaretz.com",
      "screen_name" : "haaretzcom",
      "protected" : false,
      "id_str" : "24506246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669523420774858753\/Q3O8r8FJ_normal.png",
      "id" : 24506246,
      "verified" : true
    }
  },
  "id" : 602393319763779584,
  "created_at" : "2015-05-24 08:38:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann Loraine",
      "screen_name" : "aloraine205",
      "indices" : [ 3, 15 ],
      "id_str" : "114142293",
      "id" : 114142293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/bFSPnPGUUd",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pmc\/articles\/PMC3663102\/",
      "display_url" : "ncbi.nlm.nih.gov\/pmc\/articles\/P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "602183550792802304",
  "text" : "RT @aloraine205: A 10-step guide to party conversation for bioinformaticians http:\/\/t.co\/bFSPnPGUUd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/bFSPnPGUUd",
        "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pmc\/articles\/PMC3663102\/",
        "display_url" : "ncbi.nlm.nih.gov\/pmc\/articles\/P\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "602127385216065536",
    "text" : "A 10-step guide to party conversation for bioinformaticians http:\/\/t.co\/bFSPnPGUUd",
    "id" : 602127385216065536,
    "created_at" : "2015-05-23 15:02:10 +0000",
    "user" : {
      "name" : "Ann Loraine",
      "screen_name" : "aloraine205",
      "protected" : false,
      "id_str" : "114142293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2525523774\/olxn00n8niqsbbuq2ful_normal.jpeg",
      "id" : 114142293,
      "verified" : false
    }
  },
  "id" : 602183550792802304,
  "created_at" : "2015-05-23 18:45:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Stegmann",
      "screen_name" : "wonderb0lt",
      "indices" : [ 0, 11 ],
      "id_str" : "538307847",
      "id" : 538307847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/ShecG1Z4z2",
      "expanded_url" : "https:\/\/appsto.re\/de\/OIaCI.i",
      "display_url" : "appsto.re\/de\/OIaCI.i"
    } ]
  },
  "in_reply_to_status_id_str" : "602146885823004673",
  "geo" : { },
  "id_str" : "602148855593971712",
  "in_reply_to_user_id" : 538307847,
  "text" : "@wonderb0lt \nhttps:\/\/t.co\/ShecG1Z4z2 :)",
  "id" : 602148855593971712,
  "in_reply_to_status_id" : 602146885823004673,
  "created_at" : "2015-05-23 16:27:29 +0000",
  "in_reply_to_screen_name" : "wonderb0lt",
  "in_reply_to_user_id_str" : "538307847",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602104656102334464",
  "geo" : { },
  "id_str" : "602108386117820417",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach \uD83C\uDFBA\uD83C\uDFB6",
  "id" : 602108386117820417,
  "in_reply_to_status_id" : 602104656102334464,
  "created_at" : "2015-05-23 13:46:40 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602103219100192768",
  "geo" : { },
  "id_str" : "602103974322425857",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach willst du lieber raus zu den Panfl\u00F6ten und Trommeln?",
  "id" : 602103974322425857,
  "in_reply_to_status_id" : 602103219100192768,
  "created_at" : "2015-05-23 13:29:08 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/602103497593647105\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/1AwFYgKfXp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFsZ8FYWgAAkeBN.png",
      "id_str" : "602103495211253760",
      "id" : 602103495211253760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFsZ8FYWgAAkeBN.png",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      } ],
      "display_url" : "pic.twitter.com\/1AwFYgKfXp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602103497593647105",
  "text" : "Worst role playing game I ever played. Leveling up takes ages, all grinding and no fun. http:\/\/t.co\/1AwFYgKfXp",
  "id" : 602103497593647105,
  "created_at" : "2015-05-23 13:27:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/qy0tpIjVcf",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/4IPgjZSfnPk\/info%3Adoi%2F10.1371%2Fjournal.pone.0128036",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "602035282536472576",
  "text" : "Inexpensive Multiplexed Library Preparation for Megabase-Sized Genomes http:\/\/t.co\/qy0tpIjVcf",
  "id" : 602035282536472576,
  "created_at" : "2015-05-23 08:56:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/n5rLXeOZE9",
      "expanded_url" : "http:\/\/www.hr-online.de\/website\/rubriken\/kultur\/index.jsp?rubrik=7696&key=standard_document_54804833",
      "display_url" : "hr-online.de\/website\/rubrik\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407383585799, 8.753323056530252 ]
  },
  "id_str" : "602033156867411968",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon http:\/\/t.co\/n5rLXeOZE9",
  "id" : 602033156867411968,
  "created_at" : "2015-05-23 08:47:44 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aodh\u00E1n \u00D3 R\u00EDord\u00E1in",
      "screen_name" : "AodhanORiordain",
      "indices" : [ 3, 19 ],
      "id_str" : "120117254",
      "id" : 120117254
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602029896911736832",
  "text" : "RT @AodhanORiordain: I'm calling it. Key boxes opened.\nIt's a yes. And a landslide across Dublin.\nAnd I'm so proud to be Irish today. \n#Mar\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MarRef",
        "indices" : [ 114, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602023396373876737",
    "text" : "I'm calling it. Key boxes opened.\nIt's a yes. And a landslide across Dublin.\nAnd I'm so proud to be Irish today. \n#MarRef",
    "id" : 602023396373876737,
    "created_at" : "2015-05-23 08:08:57 +0000",
    "user" : {
      "name" : "Aodh\u00E1n \u00D3 R\u00EDord\u00E1in",
      "screen_name" : "AodhanORiordain",
      "protected" : false,
      "id_str" : "120117254",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933044401705766912\/XZB4EdFj_normal.jpg",
      "id" : 120117254,
      "verified" : true
    }
  },
  "id" : 602029896911736832,
  "created_at" : "2015-05-23 08:34:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 77, 83 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/vUfJPt6uRF",
      "expanded_url" : "http:\/\/www.theatlantic.com\/entertainment\/archive\/2015\/05\/the-rise-of-the-data-artist\/392399\/",
      "display_url" : "theatlantic.com\/entertainment\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140723994373, 8.75332517314353 ]
  },
  "id_str" : "601885503550582785",
  "text" : "From Paint to Pixels: the rise of the data artist http:\/\/t.co\/vUfJPt6uRF \/cc @dvzrv",
  "id" : 601885503550582785,
  "created_at" : "2015-05-22 23:01:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Greg Cohn \uD83D\uDC94",
      "screen_name" : "gregcohn",
      "indices" : [ 10, 19 ],
      "id_str" : "12400",
      "id" : 12400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601883478016167936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140726916361, 8.753325147241613 ]
  },
  "id_str" : "601884247675281409",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @gregcohn (and you didn\u2019t tell me! you are very lucky!)",
  "id" : 601884247675281409,
  "in_reply_to_status_id" : 601883478016167936,
  "created_at" : "2015-05-22 22:56:01 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Greg Cohn \uD83D\uDC94",
      "screen_name" : "gregcohn",
      "indices" : [ 10, 19 ],
      "id_str" : "12400",
      "id" : 12400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/tVdrfBx3SI",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=SkWeMvrNiOM",
      "display_url" : "youtube.com\/watch?v=SkWeMv\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "601883559641489408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140726916361, 8.753325147241613 ]
  },
  "id_str" : "601883936168480770",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @gregcohn I always suspected that this should be \u201Clove finds a way\u201D https:\/\/t.co\/tVdrfBx3SI",
  "id" : 601883936168480770,
  "in_reply_to_status_id" : 601883559641489408,
  "created_at" : "2015-05-22 22:54:47 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Greg Cohn \uD83D\uDC94",
      "screen_name" : "gregcohn",
      "indices" : [ 73, 82 ],
      "id_str" : "12400",
      "id" : 12400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/pqLh6Qbljd",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=dFUlAQZB9Ng",
      "display_url" : "youtube.com\/watch?v=dFUlAQ\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "601882017232343041",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407292451307, 8.753325127260673 ]
  },
  "id_str" : "601882879065464832",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez we alternate between that and this one https:\/\/t.co\/pqLh6Qbljd @gregcohn",
  "id" : 601882879065464832,
  "in_reply_to_status_id" : 601882017232343041,
  "created_at" : "2015-05-22 22:50:35 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Greg Cohn \uD83D\uDC94",
      "screen_name" : "gregcohn",
      "indices" : [ 10, 19 ],
      "id_str" : "12400",
      "id" : 12400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601880362306809857",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407295729276, 8.753325119611675 ]
  },
  "id_str" : "601880625411444736",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @gregcohn it\u2019s close to 2000 by now ;-)",
  "id" : 601880625411444736,
  "in_reply_to_status_id" : 601880362306809857,
  "created_at" : "2015-05-22 22:41:38 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Rosenau",
      "screen_name" : "JoshRosenau",
      "indices" : [ 3, 15 ],
      "id_str" : "88290488",
      "id" : 88290488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/uxoP227p6Q",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/answer-sheet\/wp\/2015\/05\/20\/deepak-chopra-blasts-scientist-who-criticized-his-view-of-evolution-the-scientist-fires-back\/",
      "display_url" : "washingtonpost.com\/blogs\/answer-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601876805470056448",
  "text" : "RT @JoshRosenau: Some days, ya wake up \u2019n yer feudin\u2019 with Deepak Chopra. http:\/\/t.co\/uxoP227p6Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/uxoP227p6Q",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/answer-sheet\/wp\/2015\/05\/20\/deepak-chopra-blasts-scientist-who-criticized-his-view-of-evolution-the-scientist-fires-back\/",
        "display_url" : "washingtonpost.com\/blogs\/answer-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "601042117306101761",
    "text" : "Some days, ya wake up \u2019n yer feudin\u2019 with Deepak Chopra. http:\/\/t.co\/uxoP227p6Q",
    "id" : 601042117306101761,
    "created_at" : "2015-05-20 15:09:42 +0000",
    "user" : {
      "name" : "Josh Rosenau",
      "screen_name" : "JoshRosenau",
      "protected" : false,
      "id_str" : "88290488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623587296542109696\/k32eU-yR_normal.jpg",
      "id" : 88290488,
      "verified" : false
    }
  },
  "id" : 601876805470056448,
  "created_at" : "2015-05-22 22:26:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/qVDma9zGaQ",
      "expanded_url" : "http:\/\/www.sporkful.com\/true-story-office-fridge-food-theft-shock-you-serial\/",
      "display_url" : "sporkful.com\/true-story-off\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407317353493, 8.753325068943022 ]
  },
  "id_str" : "601812684632363008",
  "text" : "\u00ABNumber Three: Mr. McGuffin\u2019s favorite food is red herring.\u00BB Investigating An Office Fridge Food Theft http:\/\/t.co\/qVDma9zGaQ",
  "id" : 601812684632363008,
  "created_at" : "2015-05-22 18:11:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    }, {
      "name" : "Chris Cole",
      "screen_name" : "drchriscole",
      "indices" : [ 10, 22 ],
      "id_str" : "228015307",
      "id" : 228015307
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 23, 39 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601783859504545792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140726319065, 8.753325155289694 ]
  },
  "id_str" : "601784653503148033",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam @drchriscole @pathogenomenick at least it\u2019s an accepted format with A4 and not US Letter ;-)",
  "id" : 601784653503148033,
  "in_reply_to_status_id" : 601783859504545792,
  "created_at" : "2015-05-22 16:20:16 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cole",
      "screen_name" : "drchriscole",
      "indices" : [ 0, 12 ],
      "id_str" : "228015307",
      "id" : 228015307
    }, {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 13, 22 ],
      "id_str" : "17061155",
      "id" : 17061155
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 23, 39 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601782645270405120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407263182798, 8.75332515550418 ]
  },
  "id_str" : "601783101782630401",
  "in_reply_to_user_id" : 228015307,
  "text" : "@drchriscole @kbradnam @pathogenomenick preferentially after adding hand-drawn annotations with MSPaint.",
  "id" : 601783101782630401,
  "in_reply_to_status_id" : 601782645270405120,
  "created_at" : "2015-05-22 16:14:06 +0000",
  "in_reply_to_screen_name" : "drchriscole",
  "in_reply_to_user_id_str" : "228015307",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 10, 26 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601779517443547136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407289492288, 8.75332512800856 ]
  },
  "id_str" : "601781950760751104",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam @pathogenomenick don\u2019t forget to do a PDF export of the final .doc!",
  "id" : 601781950760751104,
  "in_reply_to_status_id" : 601779517443547136,
  "created_at" : "2015-05-22 16:09:32 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/y3qXx8PYEG",
      "expanded_url" : "https:\/\/instagram.com\/p\/2_Lie9hwr6\/",
      "display_url" : "instagram.com\/p\/2_Lie9hwr6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "601753201990356993",
  "text" : "semi-analog slide deck-prep https:\/\/t.co\/y3qXx8PYEG",
  "id" : 601753201990356993,
  "created_at" : "2015-05-22 14:15:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Hills",
      "screen_name" : "rocza",
      "indices" : [ 3, 9 ],
      "id_str" : "14075844",
      "id" : 14075844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601743710871760896",
  "text" : "RT @rocza: Well that's not helping Max Planck's reputation any. (It's still promoting sexism, even with a smile. :| ) https:\/\/t.co\/XV6sU3UO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/XV6sU3UO1g",
        "expanded_url" : "https:\/\/twitter.com\/mpicbg\/status\/601403150034194432",
        "display_url" : "twitter.com\/mpicbg\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "601729822356832256",
    "text" : "Well that's not helping Max Planck's reputation any. (It's still promoting sexism, even with a smile. :| ) https:\/\/t.co\/XV6sU3UO1g",
    "id" : 601729822356832256,
    "created_at" : "2015-05-22 12:42:23 +0000",
    "user" : {
      "name" : "Kelly Hills",
      "screen_name" : "rocza",
      "protected" : false,
      "id_str" : "14075844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788549856528859136\/dco0kme__normal.jpg",
      "id" : 14075844,
      "verified" : false
    }
  },
  "id" : 601743710871760896,
  "created_at" : "2015-05-22 13:37:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aoife McLysaght",
      "screen_name" : "aoifemcl",
      "indices" : [ 3, 12 ],
      "id_str" : "29462444",
      "id" : 29462444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/tZLJwGXcjz",
      "expanded_url" : "http:\/\/gu.com\/p\/494b3\/stw",
      "display_url" : "gu.com\/p\/494b3\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "601711434188365824",
  "text" : "RT @aoifemcl: The 10 best unsung female scientists http:\/\/t.co\/tZLJwGXcjz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/tZLJwGXcjz",
        "expanded_url" : "http:\/\/gu.com\/p\/494b3\/stw",
        "display_url" : "gu.com\/p\/494b3\/stw"
      } ]
    },
    "geo" : { },
    "id_str" : "601709044722728960",
    "text" : "The 10 best unsung female scientists http:\/\/t.co\/tZLJwGXcjz",
    "id" : 601709044722728960,
    "created_at" : "2015-05-22 11:19:50 +0000",
    "user" : {
      "name" : "Aoife McLysaght",
      "screen_name" : "aoifemcl",
      "protected" : false,
      "id_str" : "29462444",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761641973757382657\/wlIskpUg_normal.jpg",
      "id" : 29462444,
      "verified" : false
    }
  },
  "id" : 601711434188365824,
  "created_at" : "2015-05-22 11:29:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 0, 5 ],
      "id_str" : "773450",
      "id" : 773450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/Xb4Amm6AsL",
      "expanded_url" : "http:\/\/www.recoilwinders.com\/",
      "display_url" : "recoilwinders.com"
    } ]
  },
  "in_reply_to_status_id_str" : "601698235258920960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722090975256, 8.627534711708991 ]
  },
  "id_str" : "601703059585114113",
  "in_reply_to_user_id" : 773450,
  "text" : "@klmr these work rather well for me http:\/\/t.co\/Xb4Amm6AsL",
  "id" : 601703059585114113,
  "in_reply_to_status_id" : 601698235258920960,
  "created_at" : "2015-05-22 10:56:03 +0000",
  "in_reply_to_screen_name" : "klmr",
  "in_reply_to_user_id_str" : "773450",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601641112353267712",
  "text" : "RT @JBYoder: Best (worst) use of quiz-as-article format ever? FISA Court or the court from Kafka's \"The Trial\"? (I got 8\/11) http:\/\/t.co\/fH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/fHv35efX6y",
        "expanded_url" : "http:\/\/wapo.st\/1HxOZhc",
        "display_url" : "wapo.st\/1HxOZhc"
      } ]
    },
    "geo" : { },
    "id_str" : "601579436975218688",
    "text" : "Best (worst) use of quiz-as-article format ever? FISA Court or the court from Kafka's \"The Trial\"? (I got 8\/11) http:\/\/t.co\/fHv35efX6y",
    "id" : 601579436975218688,
    "created_at" : "2015-05-22 02:44:49 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 601641112353267712,
  "created_at" : "2015-05-22 06:49:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601413154304823296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409417941164, 8.75332351860654 ]
  },
  "id_str" : "601496515853611012",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia congratulations. :)",
  "id" : 601496515853611012,
  "in_reply_to_status_id" : 601413154304823296,
  "created_at" : "2015-05-21 21:15:19 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 3, 13 ],
      "id_str" : "347340056",
      "id" : 347340056
    }, {
      "name" : "David Wong",
      "screen_name" : "JohnDiesattheEn",
      "indices" : [ 99, 115 ],
      "id_str" : "23404794",
      "id" : 23404794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/RuIjD0sg0B",
      "expanded_url" : "http:\/\/www.cracked.com\/blog\/5-helpful-answers-to-societys-most-uncomfortable-questions\/",
      "display_url" : "cracked.com\/blog\/5-helpful\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601495709867716610",
  "text" : "RT @vortacist: Best clickbait ever: 5 Helpful Answers To Society's Most Uncomfortable Questions by @JohnDiesattheEn http:\/\/t.co\/RuIjD0sg0B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Wong",
        "screen_name" : "JohnDiesattheEn",
        "indices" : [ 84, 100 ],
        "id_str" : "23404794",
        "id" : 23404794
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/RuIjD0sg0B",
        "expanded_url" : "http:\/\/www.cracked.com\/blog\/5-helpful-answers-to-societys-most-uncomfortable-questions\/",
        "display_url" : "cracked.com\/blog\/5-helpful\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "601489795429376000",
    "text" : "Best clickbait ever: 5 Helpful Answers To Society's Most Uncomfortable Questions by @JohnDiesattheEn http:\/\/t.co\/RuIjD0sg0B",
    "id" : 601489795429376000,
    "created_at" : "2015-05-21 20:48:37 +0000",
    "user" : {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "protected" : false,
      "id_str" : "347340056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819220259148177408\/UYT71cyh_normal.jpg",
      "id" : 347340056,
      "verified" : false
    }
  },
  "id" : 601495709867716610,
  "created_at" : "2015-05-21 21:12:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Exploding Vim",
      "screen_name" : "explodingvim",
      "indices" : [ 3, 16 ],
      "id_str" : "155644031",
      "id" : 155644031
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/explodingvim\/status\/537284269564235776\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/xvr6U197Xt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3TRMNkCEAE2580.jpg",
      "id_str" : "537284263293358081",
      "id" : 537284263293358081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3TRMNkCEAE2580.jpg",
      "sizes" : [ {
        "h" : 330,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/xvr6U197Xt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601491873346232322",
  "text" : "RT @explodingvim: http:\/\/t.co\/xvr6U197Xt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/explodingvim\/status\/537284269564235776\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/xvr6U197Xt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3TRMNkCEAE2580.jpg",
        "id_str" : "537284263293358081",
        "id" : 537284263293358081,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3TRMNkCEAE2580.jpg",
        "sizes" : [ {
          "h" : 330,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/xvr6U197Xt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537284269564235776",
    "text" : "http:\/\/t.co\/xvr6U197Xt",
    "id" : 537284269564235776,
    "created_at" : "2014-11-25 16:38:46 +0000",
    "user" : {
      "name" : "Exploding Vim",
      "screen_name" : "explodingvim",
      "protected" : false,
      "id_str" : "155644031",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/989979458\/explodingvim_normal.png",
      "id" : 155644031,
      "verified" : false
    }
  },
  "id" : 601491873346232322,
  "created_at" : "2015-05-21 20:56:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601491296105144320",
  "text" : "My guesstimate: Everything I learnt about short read de novo assembly will be useless in 3 years tops; thanks to long read sequencing.",
  "id" : 601491296105144320,
  "created_at" : "2015-05-21 20:54:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Hahn",
      "screen_name" : "3rdreviewer",
      "indices" : [ 0, 12 ],
      "id_str" : "2678236062",
      "id" : 2678236062
    }, {
      "name" : "The Assemblathon",
      "screen_name" : "assemblathon",
      "indices" : [ 13, 26 ],
      "id_str" : "216793572",
      "id" : 216793572
    }, {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 27, 36 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601409906667868160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218293924827, 8.627504508573331 ]
  },
  "id_str" : "601411815197802496",
  "in_reply_to_user_id" : 2678236062,
  "text" : "@3rdreviewer @assemblathon @kbradnam I haven\u2019t looked into the more specific data sets, might be more genes there. :-)",
  "id" : 601411815197802496,
  "in_reply_to_status_id" : 601409906667868160,
  "created_at" : "2015-05-21 15:38:45 +0000",
  "in_reply_to_screen_name" : "3rdreviewer",
  "in_reply_to_user_id_str" : "2678236062",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601409317330227201",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218295880671, 8.627503244753905 ]
  },
  "id_str" : "601410535393988608",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam yes, only at saturation of # of genes found it breaks down a bit.",
  "id" : 601410535393988608,
  "in_reply_to_status_id" : 601409317330227201,
  "created_at" : "2015-05-21 15:33:39 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Hahn",
      "screen_name" : "3rdreviewer",
      "indices" : [ 0, 12 ],
      "id_str" : "2678236062",
      "id" : 2678236062
    }, {
      "name" : "The Assemblathon",
      "screen_name" : "assemblathon",
      "indices" : [ 13, 26 ],
      "id_str" : "216793572",
      "id" : 216793572
    }, {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 27, 36 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601409275752243200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17217996912304, 8.627696496019997 ]
  },
  "id_str" : "601410030823407616",
  "in_reply_to_user_id" : 2678236062,
  "text" : "@3rdreviewer @assemblathon @kbradnam minimum number of missed genes for BUSCO in the data I looked at: 16.",
  "id" : 601410030823407616,
  "in_reply_to_status_id" : 601409275752243200,
  "created_at" : "2015-05-21 15:31:39 +0000",
  "in_reply_to_screen_name" : "3rdreviewer",
  "in_reply_to_user_id_str" : "2678236062",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Hahn",
      "screen_name" : "3rdreviewer",
      "indices" : [ 0, 12 ],
      "id_str" : "2678236062",
      "id" : 2678236062
    }, {
      "name" : "The Assemblathon",
      "screen_name" : "assemblathon",
      "indices" : [ 13, 26 ],
      "id_str" : "216793572",
      "id" : 216793572
    }, {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 27, 36 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601409275752243200",
  "geo" : { },
  "id_str" : "601409760903221248",
  "in_reply_to_user_id" : 2678236062,
  "text" : "@3rdreviewer @assemblathon @kbradnam I used the Eukaryote set for BUSCO, seemed most fitting for CEGMA comp. BUSCO total: 429.",
  "id" : 601409760903221248,
  "in_reply_to_status_id" : 601409275752243200,
  "created_at" : "2015-05-21 15:30:35 +0000",
  "in_reply_to_screen_name" : "3rdreviewer",
  "in_reply_to_user_id_str" : "2678236062",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 85, 94 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/601355327922114560\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/L4vquAALiE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFhxe3JWMAAaNe2.png",
      "id_str" : "601355325267128320",
      "id" : 601355325267128320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFhxe3JWMAAaNe2.png",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2047
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2047
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1199
      } ],
      "display_url" : "pic.twitter.com\/L4vquAALiE"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/601355327922114560\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/L4vquAALiE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFhxe84WMAAmgWe.png",
      "id_str" : "601355326806437888",
      "id" : 601355326806437888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFhxe84WMAAmgWe.png",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2047
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2047
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1199
      } ],
      "display_url" : "pic.twitter.com\/L4vquAALiE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1721829355691, 8.62750440502312 ]
  },
  "id_str" : "601355327922114560",
  "text" : "Compared CEGMA to BUSCO with some simulated fungal assemblies with a fitted glm. \/cc @kbradnam http:\/\/t.co\/L4vquAALiE",
  "id" : 601355327922114560,
  "created_at" : "2015-05-21 11:54:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastien Chevreux",
      "screen_name" : "BaCh_mira",
      "indices" : [ 0, 10 ],
      "id_str" : "360258516",
      "id" : 360258516
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 11, 19 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601340238972215296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1721901047328, 8.627592997554776 ]
  },
  "id_str" : "601354171707719680",
  "in_reply_to_user_id" : 360258516,
  "text" : "@BaCh_mira @pjacock for what it\u2019s worth: I\u2019m really grateful for the complete Book of (Assembly-)Genesis :)",
  "id" : 601354171707719680,
  "in_reply_to_status_id" : 601340238972215296,
  "created_at" : "2015-05-21 11:49:41 +0000",
  "in_reply_to_screen_name" : "BaCh_mira",
  "in_reply_to_user_id_str" : "360258516",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "viola vo\u00DF",
      "screen_name" : "v_i_o_l_a",
      "indices" : [ 0, 10 ],
      "id_str" : "14937469",
      "id" : 14937469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/IpEiOVH9qX",
      "expanded_url" : "https:\/\/twitter.com\/GretchenAMcC\/status\/601077165300523008",
      "display_url" : "twitter.com\/GretchenAMcC\/s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "601332665476915200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17321777343821, 8.62876129150603 ]
  },
  "id_str" : "601333988712685568",
  "in_reply_to_user_id" : 14937469,
  "text" : "@v_i_o_l_a https:\/\/t.co\/IpEiOVH9qX ;)",
  "id" : 601333988712685568,
  "in_reply_to_status_id" : 601332665476915200,
  "created_at" : "2015-05-21 10:29:29 +0000",
  "in_reply_to_screen_name" : "v_i_o_l_a",
  "in_reply_to_user_id_str" : "14937469",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601330695517114368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17299080004443, 8.62809658415655 ]
  },
  "id_str" : "601332246591754241",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon oh, I wasn\u2019t aware that this is a claim people make.",
  "id" : 601332246591754241,
  "in_reply_to_status_id" : 601330695517114368,
  "created_at" : "2015-05-21 10:22:34 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601326911088910336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17289841589714, 8.62782648749366 ]
  },
  "id_str" : "601330242553249793",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce yes, that should work just fine (if your machine isn\u2019t too old).",
  "id" : 601330242553249793,
  "in_reply_to_status_id" : 601326911088910336,
  "created_at" : "2015-05-21 10:14:36 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601328954922905601",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17296626889359, 8.628054013432918 ]
  },
  "id_str" : "601330014362165248",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon thx, totally agree w\/ the sentiment: by going all-in on faking it, it got around all the usual concerns re:statistics.",
  "id" : 601330014362165248,
  "in_reply_to_status_id" : 601328954922905601,
  "created_at" : "2015-05-21 10:13:42 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 3, 17 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 99, 115 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/IvbeuDZSCm",
      "expanded_url" : "http:\/\/wapo.st\/1LaQhMT",
      "display_url" : "wapo.st\/1LaQhMT"
    } ]
  },
  "geo" : { },
  "id_str" : "601329709239140352",
  "text" : "RT @zoonpolitikon: More thoughts on the fake study on changing attitudes http:\/\/t.co\/IvbeuDZSCm cc @gedankenstuecke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 80, 96 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/IvbeuDZSCm",
        "expanded_url" : "http:\/\/wapo.st\/1LaQhMT",
        "display_url" : "wapo.st\/1LaQhMT"
      } ]
    },
    "geo" : { },
    "id_str" : "601328954922905601",
    "text" : "More thoughts on the fake study on changing attitudes http:\/\/t.co\/IvbeuDZSCm cc @gedankenstuecke",
    "id" : 601328954922905601,
    "created_at" : "2015-05-21 10:09:29 +0000",
    "user" : {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "protected" : false,
      "id_str" : "13040652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875702734921629697\/1TUbd7IS_normal.jpg",
      "id" : 13040652,
      "verified" : false
    }
  },
  "id" : 601329709239140352,
  "created_at" : "2015-05-21 10:12:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 86, 95 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/9hVGAoVSzc",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/YS7o5a3wD8c\/info%3Adoi%2F10.1371%2Fjournal.pone.0125208",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17332, 8.629053 ]
  },
  "id_str" : "601306074705199104",
  "text" : "Impact of Open Data Policies on Consent to Participate in Human Subjects Research \/cc @wilbanks  http:\/\/t.co\/9hVGAoVSzc",
  "id" : 601306074705199104,
  "created_at" : "2015-05-21 08:38:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 65, 80 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/BIyG3eQuan",
      "expanded_url" : "https:\/\/www.mozillascience.org\/projects\/gedankenstuecke-snpr",
      "display_url" : "mozillascience.org\/projects\/gedan\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17219494850591, 8.627587691148737 ]
  },
  "id_str" : "601279310616535040",
  "text" : "For the AM crowd in the EU: openSNP is now listed on Collaborate @MozillaScience https:\/\/t.co\/BIyG3eQuan",
  "id" : 601279310616535040,
  "created_at" : "2015-05-21 06:52:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Mills",
      "screen_name" : "billdoesphysics",
      "indices" : [ 0, 16 ],
      "id_str" : "489868737",
      "id" : 489868737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601139516028690433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11410117725732, 8.753259086703936 ]
  },
  "id_str" : "601140327534198785",
  "in_reply_to_user_id" : 489868737,
  "text" : "@billdoesphysics glad you like it, that means a lot!",
  "id" : 601140327534198785,
  "in_reply_to_status_id" : 601139516028690433,
  "created_at" : "2015-05-20 21:39:57 +0000",
  "in_reply_to_screen_name" : "billdoesphysics",
  "in_reply_to_user_id_str" : "489868737",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 3, 18 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opendata",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/OKugT9nFrJ",
      "expanded_url" : "https:\/\/www.mozillascience.org\/projects\/gedankenstuecke-snpr",
      "display_url" : "mozillascience.org\/projects\/gedan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601138850224799744",
  "text" : "RT @MozillaScience: New on Collaborate: OpenSNP, a crowdsourced #opendata collection of human gene data https:\/\/t.co\/OKugT9nFrJ cc @gedanke\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 111, 127 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opendata",
        "indices" : [ 44, 53 ]
      }, {
        "text" : "openscience",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/OKugT9nFrJ",
        "expanded_url" : "https:\/\/www.mozillascience.org\/projects\/gedankenstuecke-snpr",
        "display_url" : "mozillascience.org\/projects\/gedan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "601138655550427136",
    "text" : "New on Collaborate: OpenSNP, a crowdsourced #opendata collection of human gene data https:\/\/t.co\/OKugT9nFrJ cc @gedankenstuecke #openscience",
    "id" : 601138655550427136,
    "created_at" : "2015-05-20 21:33:18 +0000",
    "user" : {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "protected" : false,
      "id_str" : "1428575976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687287790049034240\/lwIk-ZQT_normal.png",
      "id" : 1428575976,
      "verified" : false
    }
  },
  "id" : 601138850224799744,
  "created_at" : "2015-05-20 21:34:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 0, 15 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601138655550427136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11748768647519, 8.73687614438348 ]
  },
  "id_str" : "601138826141118464",
  "in_reply_to_user_id" : 1428575976,
  "text" : "@MozillaScience wow, that was quick. Thanks!",
  "id" : 601138826141118464,
  "in_reply_to_status_id" : 601138655550427136,
  "created_at" : "2015-05-20 21:33:59 +0000",
  "in_reply_to_screen_name" : "MozillaScience",
  "in_reply_to_user_id_str" : "1428575976",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 24, 36 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 95, 110 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601134833641881600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419999998, 8.753323480000015 ]
  },
  "id_str" : "601136533895262210",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @PhilippBayer @helgerausch no worries, I\u2019m happy we could help discovering a bug! So @MozillaScience is already working ;-)",
  "id" : 601136533895262210,
  "in_reply_to_status_id" : 601134833641881600,
  "created_at" : "2015-05-20 21:24:52 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 55, 70 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 103, 112 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419999998, 8.753323480000008 ]
  },
  "id_str" : "601132652989669376",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch openSNP is now submitted to @MozillaScience, thanks to the great support of @abbycabs :)",
  "id" : 601132652989669376,
  "created_at" : "2015-05-20 21:09:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/BbrKb1C2OX",
      "expanded_url" : "http:\/\/www.snpedia.com\/index.php\/SNPedia:About",
      "display_url" : "snpedia.com\/index.php\/SNPe\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "601127078906482688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419999998, 8.753323479999752 ]
  },
  "id_str" : "601127530343563265",
  "in_reply_to_user_id" : 14286491,
  "text" : "So we\u2019re not the only ones confused. From: http:\/\/t.co\/BbrKb1C2OX",
  "id" : 601127530343563265,
  "in_reply_to_status_id" : 601127078906482688,
  "created_at" : "2015-05-20 20:49:06 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419999998, 8.753323480179187 ]
  },
  "id_str" : "601127078906482688",
  "text" : "\u00ABSNPedia has nothing to do with the Scottish National Party, even though SNPedia is a top search engine result for \"Redheads in the SNP\u201D.\u00BB",
  "id" : 601127078906482688,
  "created_at" : "2015-05-20 20:47:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601116046964224002",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419999998, 8.753323480163942 ]
  },
  "id_str" : "601116299398348800",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ernsthaft, ich h\u00E4tte meine Soja-Produkte gerne voller GMOs, aber versuch das mal zu bekommen!",
  "id" : 601116299398348800,
  "in_reply_to_status_id" : 601116046964224002,
  "created_at" : "2015-05-20 20:04:28 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601115377712660482",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419999998, 8.753323524866921 ]
  },
  "id_str" : "601115605899603971",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich i\u2019ll taking that over being binned with the anti-vaxx anti-GMO crowd every single time!",
  "id" : 601115605899603971,
  "in_reply_to_status_id" : 601115377712660482,
  "created_at" : "2015-05-20 20:01:43 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vegan GMO",
      "screen_name" : "VeganGMO",
      "indices" : [ 56, 65 ],
      "id_str" : "567565028",
      "id" : 567565028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601115100477562880",
  "text" : "Nice! I wasn\u2019t aware of this being a thing until today: @VeganGMO",
  "id" : 601115100477562880,
  "created_at" : "2015-05-20 19:59:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Bill Mills",
      "screen_name" : "billdoesphysics",
      "indices" : [ 10, 26 ],
      "id_str" : "489868737",
      "id" : 489868737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/2knE92FZmt",
      "expanded_url" : "https:\/\/github.com\/mozillascience\/site\/issues\/35",
      "display_url" : "github.com\/mozillascience\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "601076346316595200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419999997, 8.75332490000002 ]
  },
  "id_str" : "601077718160121856",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @billdoesphysics thanks, there you go :-) https:\/\/t.co\/2knE92FZmt",
  "id" : 601077718160121856,
  "in_reply_to_status_id" : 601076346316595200,
  "created_at" : "2015-05-20 17:31:10 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Bill Mills",
      "screen_name" : "billdoesphysics",
      "indices" : [ 10, 26 ],
      "id_str" : "489868737",
      "id" : 489868737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601075816525598720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409420000021, 8.753324899999503 ]
  },
  "id_str" : "601076153084997632",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @billdoesphysics sure, I can file an issue. Are you certain that it\u2019s the right repository though? :)",
  "id" : 601076153084997632,
  "in_reply_to_status_id" : 601075816525598720,
  "created_at" : "2015-05-20 17:24:57 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Bill Mills",
      "screen_name" : "billdoesphysics",
      "indices" : [ 10, 26 ],
      "id_str" : "489868737",
      "id" : 489868737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601073385247010816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419998957, 8.753324900022514 ]
  },
  "id_str" : "601073815670681600",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @billdoesphysics did try it, immediately back to blank :)",
  "id" : 601073815670681600,
  "in_reply_to_status_id" : 601073385247010816,
  "created_at" : "2015-05-20 17:15:39 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Bill Mills",
      "screen_name" : "billdoesphysics",
      "indices" : [ 10, 26 ],
      "id_str" : "489868737",
      "id" : 489868737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601073385247010816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419978189, 8.753324900471446 ]
  },
  "id_str" : "601073663123783680",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @billdoesphysics sure, let me give it a try.",
  "id" : 601073663123783680,
  "in_reply_to_status_id" : 601073385247010816,
  "created_at" : "2015-05-20 17:15:03 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Bill Mills",
      "screen_name" : "billdoesphysics",
      "indices" : [ 10, 26 ],
      "id_str" : "489868737",
      "id" : 489868737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601069959918264320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419894231, 8.75332490228633 ]
  },
  "id_str" : "601070359731904513",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @billdoesphysics would creating an additional README.md help on your end? :)",
  "id" : 601070359731904513,
  "in_reply_to_status_id" : 601069959918264320,
  "created_at" : "2015-05-20 17:01:55 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Mills",
      "screen_name" : "billdoesphysics",
      "indices" : [ 0, 16 ],
      "id_str" : "489868737",
      "id" : 489868737
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 17, 26 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601067779639418880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409425320689, 8.753324784984743 ]
  },
  "id_str" : "601068447557099520",
  "in_reply_to_user_id" : 489868737,
  "text" : "@billdoesphysics @abbycabs (haven\u2019t entered any data so far, so wouldn\u2019t be a problem, but I can\u2019t delete as page not loading) ;-)",
  "id" : 601068447557099520,
  "in_reply_to_status_id" : 601067779639418880,
  "created_at" : "2015-05-20 16:54:19 +0000",
  "in_reply_to_screen_name" : "billdoesphysics",
  "in_reply_to_user_id_str" : "489868737",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Mills",
      "screen_name" : "billdoesphysics",
      "indices" : [ 0, 16 ],
      "id_str" : "489868737",
      "id" : 489868737
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 17, 26 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601067779639418880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409398719111, 8.75332536000781 ]
  },
  "id_str" : "601068338387808257",
  "in_reply_to_user_id" : 489868737,
  "text" : "@billdoesphysics @abbycabs nope, didn\u2019t help. And now the project is listed twice on my account. Maybe deleting the projects helps?",
  "id" : 601068338387808257,
  "in_reply_to_status_id" : 601067779639418880,
  "created_at" : "2015-05-20 16:53:53 +0000",
  "in_reply_to_screen_name" : "billdoesphysics",
  "in_reply_to_user_id_str" : "489868737",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/Gnqnfx1WiP",
      "expanded_url" : "http:\/\/simplystatistics.org\/2015\/05\/20\/is-it-species-or-is-it-batch-they-are-confounded-so-we-cant-know\/",
      "display_url" : "simplystatistics.org\/2015\/05\/20\/is-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218135315434, 8.627608239488998 ]
  },
  "id_str" : "601057282537951233",
  "text" : "\u00ABConfounded designs ruin experiments. Current batch effect removal methods will not save you.\u00BB http:\/\/t.co\/Gnqnfx1WiP",
  "id" : 601057282537951233,
  "created_at" : "2015-05-20 16:09:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/SJtQQKWfMA",
      "expanded_url" : "https:\/\/medium.com\/message\/falling-in-love-with-a-hard-drive-b49ddd6ce488",
      "display_url" : "medium.com\/message\/fallin\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218135315434, 8.627608239488998 ]
  },
  "id_str" : "601056912705204225",
  "text" : "Falling In Love With A Hard Drive https:\/\/t.co\/SJtQQKWfMA",
  "id" : 601056912705204225,
  "created_at" : "2015-05-20 16:08:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/YfuiROUphP",
      "expanded_url" : "https:\/\/www.mozillascience.org\/",
      "display_url" : "mozillascience.org"
    } ]
  },
  "in_reply_to_status_id_str" : "601049408621441024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218129300401, 8.627612997970521 ]
  },
  "id_str" : "601049699508944897",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy no, it\u2019s for the general https:\/\/t.co\/YfuiROUphP But would be nice to have it up by the sprint if possible.",
  "id" : 601049699508944897,
  "in_reply_to_status_id" : 601049408621441024,
  "created_at" : "2015-05-20 15:39:49 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 0, 15 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/sDHJjOIqlA",
      "expanded_url" : "https:\/\/www.mozillascience.org\/projects\/gedankenstuecke-snpr\/edit",
      "display_url" : "mozillascience.org\/projects\/gedan\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218129300401, 8.627612997970521 ]
  },
  "id_str" : "601047982721638400",
  "in_reply_to_user_id" : 1428575976,
  "text" : "@MozillaScience we\u2019d like to submit openSNP, but the edit page just blanks for us. known bug? :-) https:\/\/t.co\/sDHJjOIqlA",
  "id" : 601047982721638400,
  "created_at" : "2015-05-20 15:33:00 +0000",
  "in_reply_to_screen_name" : "MozillaScience",
  "in_reply_to_user_id_str" : "1428575976",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601027384545026048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172200375446, 8.627632809231017 ]
  },
  "id_str" : "601029474696732672",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon same here. I was skeptical, but then they told about the replications\u2026",
  "id" : 601029474696732672,
  "in_reply_to_status_id" : 601027384545026048,
  "created_at" : "2015-05-20 14:19:28 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/myoMkMYkBh",
      "expanded_url" : "http:\/\/m.thisamericanlife.org\/radio-archives\/episode\/460\/retraction",
      "display_url" : "m.thisamericanlife.org\/radio-archives\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "601026408354324480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223789776458, 8.627565021230138 ]
  },
  "id_str" : "601026856243044353",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski would be a good opportunity, cf. http:\/\/t.co\/myoMkMYkBh",
  "id" : 601026856243044353,
  "in_reply_to_status_id" : 601026408354324480,
  "created_at" : "2015-05-20 14:09:03 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601026234999566338",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17219531179168, 8.627587901611177 ]
  },
  "id_str" : "601026621148106752",
  "in_reply_to_user_id" : 14286491,
  "text" : "The lesson stays the same: if a story is too good to be true, it\u2019s because it probably isn\u2019t.",
  "id" : 601026621148106752,
  "in_reply_to_status_id" : 601026234999566338,
  "created_at" : "2015-05-20 14:08:07 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/1PgcETDP4T",
      "expanded_url" : "https:\/\/twitter.com\/Neuro_Skeptic\/status\/600954138432819200",
      "display_url" : "twitter.com\/Neuro_Skeptic\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17219531179168, 8.627587901611177 ]
  },
  "id_str" : "601026234999566338",
  "text" : "So will we get another This American Life retraction episode now? https:\/\/t.co\/1PgcETDP4T",
  "id" : 601026234999566338,
  "created_at" : "2015-05-20 14:06:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neuroskeptic",
      "screen_name" : "Neuro_Skeptic",
      "indices" : [ 3, 17 ],
      "id_str" : "316327930",
      "id" : 316327930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601025622123642880",
  "text" : "RT @Neuro_Skeptic: Brilliant work by Broockman and Kalla, two grad students who have discovered fraud in a Science paper http:\/\/t.co\/9JwXHS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dani\u00EBl Lakens",
        "screen_name" : "lakens",
        "indices" : [ 128, 135 ],
        "id_str" : "17387342",
        "id" : 17387342
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/9JwXHSfPYY",
        "expanded_url" : "http:\/\/web.stanford.edu\/~dbroock\/broockman_kalla_aronow_lg_irregularities.pdf",
        "display_url" : "web.stanford.edu\/~dbroock\/brooc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "600954138432819200",
    "text" : "Brilliant work by Broockman and Kalla, two grad students who have discovered fraud in a Science paper http:\/\/t.co\/9JwXHSfPYY ht @lakens",
    "id" : 600954138432819200,
    "created_at" : "2015-05-20 09:20:06 +0000",
    "user" : {
      "name" : "Neuroskeptic",
      "screen_name" : "Neuro_Skeptic",
      "protected" : false,
      "id_str" : "316327930",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703637604181393409\/iCflIKVK_normal.jpg",
      "id" : 316327930,
      "verified" : false
    }
  },
  "id" : 601025622123642880,
  "created_at" : "2015-05-20 14:04:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 3, 17 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/ZQYbnjy7V6",
      "expanded_url" : "http:\/\/genomebiology.com\/2015\/16\/1\/99\/abstract",
      "display_url" : "genomebiology.com\/2015\/16\/1\/99\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601015790771576833",
  "text" : "RT @BioMickWatson: Most partial domains in proteins are alignment and annotation artifacts http:\/\/t.co\/ZQYbnjy7V6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/ZQYbnjy7V6",
        "expanded_url" : "http:\/\/genomebiology.com\/2015\/16\/1\/99\/abstract",
        "display_url" : "genomebiology.com\/2015\/16\/1\/99\/a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "600656519902994434",
    "text" : "Most partial domains in proteins are alignment and annotation artifacts http:\/\/t.co\/ZQYbnjy7V6",
    "id" : 600656519902994434,
    "created_at" : "2015-05-19 13:37:28 +0000",
    "user" : {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "protected" : false,
      "id_str" : "228586748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870214569679093760\/YIZGIDTS_normal.jpg",
      "id" : 228586748,
      "verified" : false
    }
  },
  "id" : 601015790771576833,
  "created_at" : "2015-05-20 13:25:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/ZduDZ2URDP",
      "expanded_url" : "http:\/\/aeon.co\/magazine\/psychology\/we-need-to-ditch-generational-labels\/",
      "display_url" : "aeon.co\/magazine\/psych\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218094313285, 8.62765570234953 ]
  },
  "id_str" : "601009569196863489",
  "text" : "On the horoscope-like qualities of generational thinking http:\/\/t.co\/ZduDZ2URDP",
  "id" : 601009569196863489,
  "created_at" : "2015-05-20 13:00:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601000697698590720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218089593603, 8.627689832614033 ]
  },
  "id_str" : "601001799349358592",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch great, made some last suggestions. Otherwise good2go I\u2019d say.",
  "id" : 601001799349358592,
  "in_reply_to_status_id" : 601000697698590720,
  "created_at" : "2015-05-20 12:29:29 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 80, 92 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600954855151271936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17219665119899, 8.627577574574511 ]
  },
  "id_str" : "600986973373919233",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer will you participate? also: have you had a look at the pad again? @helgerausch",
  "id" : 600986973373919233,
  "in_reply_to_status_id" : 600954855151271936,
  "created_at" : "2015-05-20 11:30:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/M0F5EsUKkA",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/IyU6jMbzVF3hK\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/IyU6jMbz\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218034730543, 8.627693444472596 ]
  },
  "id_str" : "600937056748048384",
  "text" : "day 3 w\/o espresso machine http:\/\/t.co\/M0F5EsUKkA",
  "id" : 600937056748048384,
  "created_at" : "2015-05-20 08:12:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Chisholm",
      "screen_name" : "glyphobet",
      "indices" : [ 3, 13 ],
      "id_str" : "5053801",
      "id" : 5053801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/QKiOdYlhon",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/throgers\/sets\/72157622211751522\/",
      "display_url" : "flickr.com\/photos\/throger\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600920323261911041",
  "text" : "RT @glyphobet: Awesome misspelled SF street names in concrete: https:\/\/t.co\/QKiOdYlhon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/QKiOdYlhon",
        "expanded_url" : "https:\/\/www.flickr.com\/photos\/throgers\/sets\/72157622211751522\/",
        "display_url" : "flickr.com\/photos\/throger\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "600820902356385793",
    "text" : "Awesome misspelled SF street names in concrete: https:\/\/t.co\/QKiOdYlhon",
    "id" : 600820902356385793,
    "created_at" : "2015-05-20 00:30:40 +0000",
    "user" : {
      "name" : "Matt Chisholm",
      "screen_name" : "glyphobet",
      "protected" : false,
      "id_str" : "5053801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/999179781\/blue-duck_normal.png",
      "id" : 5053801,
      "verified" : false
    }
  },
  "id" : 600920323261911041,
  "created_at" : "2015-05-20 07:05:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "somehillbilly",
      "screen_name" : "somehillbilly",
      "indices" : [ 3, 17 ],
      "id_str" : "343437200",
      "id" : 343437200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/OBy2oBDP0o",
      "expanded_url" : "http:\/\/www.adioslounge.com\/dylan-the-plugz-start-me-talkin\/",
      "display_url" : "adioslounge.com\/dylan-the-plug\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600783906946834432",
  "text" : "RT @somehillbilly: more Dylan &amp; the Plugz \nhttp:\/\/t.co\/OBy2oBDP0o\n(via @adioslounge)@sterlewine",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen T Erlewine",
        "screen_name" : "sterlewine",
        "indices" : [ 69, 80 ],
        "id_str" : "20324984",
        "id" : 20324984
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/OBy2oBDP0o",
        "expanded_url" : "http:\/\/www.adioslounge.com\/dylan-the-plugz-start-me-talkin\/",
        "display_url" : "adioslounge.com\/dylan-the-plug\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "600745708006674433",
    "geo" : { },
    "id_str" : "600756470636908545",
    "in_reply_to_user_id" : 20324984,
    "text" : "more Dylan &amp; the Plugz \nhttp:\/\/t.co\/OBy2oBDP0o\n(via @adioslounge)@sterlewine",
    "id" : 600756470636908545,
    "in_reply_to_status_id" : 600745708006674433,
    "created_at" : "2015-05-19 20:14:38 +0000",
    "in_reply_to_screen_name" : "sterlewine",
    "in_reply_to_user_id_str" : "20324984",
    "user" : {
      "name" : "somehillbilly",
      "screen_name" : "somehillbilly",
      "protected" : false,
      "id_str" : "343437200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670480879731380224\/ApMaA_z__normal.png",
      "id" : 343437200,
      "verified" : false
    }
  },
  "id" : 600783906946834432,
  "created_at" : "2015-05-19 22:03:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/uaBXLEc7TP",
      "expanded_url" : "http:\/\/www.adioslounge.com\/dylan-the-plugz-start-me-talkin\/",
      "display_url" : "adioslounge.com\/dylan-the-plug\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600783885815930880",
  "text" : "\u00ABHe\u2019s a folksinging prophet, an inscrutable rebel genius, and the spokesman for a generation. I get it, believe me\u00BB http:\/\/t.co\/uaBXLEc7TP",
  "id" : 600783885815930880,
  "created_at" : "2015-05-19 22:03:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600675084970401792",
  "geo" : { },
  "id_str" : "600686951042285568",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam so you can keep your fingers crossed that people will switch over rather quickly ;)",
  "id" : 600686951042285568,
  "in_reply_to_status_id" : 600675084970401792,
  "created_at" : "2015-05-19 15:38:24 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600675084970401792",
  "geo" : { },
  "id_str" : "600686812022099968",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam did some test driving of it today. Much easier install, works +\/- out of the box. Only small n so far, but results +\/- like CEGMA.",
  "id" : 600686812022099968,
  "in_reply_to_status_id" : 600675084970401792,
  "created_at" : "2015-05-19 15:37:50 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "indices" : [ 3, 16 ],
      "id_str" : "314758565",
      "id" : 314758565
    }, {
      "name" : "Yoav Gilad",
      "screen_name" : "Y_Gilad",
      "indices" : [ 103, 111 ],
      "id_str" : "2802558480",
      "id" : 2802558480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600671022950576128",
  "text" : "RT @joe_pickrell: Great piece of forensic bioinformatics on human-mouse gene expression comparisons by @Y_Gilad, Mizrahi-Man http:\/\/t.co\/3Q\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yoav Gilad",
        "screen_name" : "Y_Gilad",
        "indices" : [ 85, 93 ],
        "id_str" : "2802558480",
        "id" : 2802558480
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/3Q93cZjSvg",
        "expanded_url" : "http:\/\/f1000research.com\/articles\/4-121\/v1",
        "display_url" : "f1000research.com\/articles\/4-121\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "600667552713469953",
    "text" : "Great piece of forensic bioinformatics on human-mouse gene expression comparisons by @Y_Gilad, Mizrahi-Man http:\/\/t.co\/3Q93cZjSvg",
    "id" : 600667552713469953,
    "created_at" : "2015-05-19 14:21:19 +0000",
    "user" : {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "protected" : false,
      "id_str" : "314758565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923000443105611776\/g88uZpgr_normal.jpg",
      "id" : 314758565,
      "verified" : false
    }
  },
  "id" : 600671022950576128,
  "created_at" : "2015-05-19 14:35:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600646952976556032",
  "geo" : { },
  "id_str" : "600647812032942080",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 dann beim n\u00E4chsten Mal. Ich hab es als ich da war auch vergessen m(",
  "id" : 600647812032942080,
  "in_reply_to_status_id" : 600646952976556032,
  "created_at" : "2015-05-19 13:02:52 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600645284788580352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17219994671559, 8.627526155980691 ]
  },
  "id_str" : "600645946565861376",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 fragst du etwa wegen des Keyboardproblems? :D",
  "id" : 600645946565861376,
  "in_reply_to_status_id" : 600645284788580352,
  "created_at" : "2015-05-19 12:55:27 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Eveleth \u25B7\u25B7",
      "screen_name" : "roseveleth",
      "indices" : [ 3, 14 ],
      "id_str" : "44903491",
      "id" : 44903491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/RzDjsPSDDF",
      "expanded_url" : "http:\/\/mosaicscience.com\/story\/extreme-prosthetic-knee",
      "display_url" : "mosaicscience.com\/story\/extreme-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600640876768055296",
  "text" : "RT @roseveleth: Meet Brian Bartlett, an amputee who built his own knee because he hated all the options he had: http:\/\/t.co\/RzDjsPSDDF (by \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/RzDjsPSDDF",
        "expanded_url" : "http:\/\/mosaicscience.com\/story\/extreme-prosthetic-knee",
        "display_url" : "mosaicscience.com\/story\/extreme-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "600631537600753664",
    "text" : "Meet Brian Bartlett, an amputee who built his own knee because he hated all the options he had: http:\/\/t.co\/RzDjsPSDDF (by me)",
    "id" : 600631537600753664,
    "created_at" : "2015-05-19 11:58:12 +0000",
    "user" : {
      "name" : "Rose Eveleth \u25B7\u25B7",
      "screen_name" : "roseveleth",
      "protected" : false,
      "id_str" : "44903491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782201676006588416\/GAIXvMwJ_normal.jpg",
      "id" : 44903491,
      "verified" : false
    }
  },
  "id" : 600640876768055296,
  "created_at" : "2015-05-19 12:35:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 3, 11 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEM",
      "indices" : [ 51, 60 ]
    }, {
      "text" : "LGBT",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/l9kWVvKyoY",
      "expanded_url" : "https:\/\/lgbtstem.wordpress.com\/",
      "display_url" : "lgbtstem.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "600605697089339393",
  "text" : "RT @PhdGeek: This is your periodic reminder of the #LGBTSTEM blog https:\/\/t.co\/l9kWVvKyoY -we're always looking for #LGBT people to talk ab\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTSTEM",
        "indices" : [ 38, 47 ]
      }, {
        "text" : "LGBT",
        "indices" : [ 103, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/l9kWVvKyoY",
        "expanded_url" : "https:\/\/lgbtstem.wordpress.com\/",
        "display_url" : "lgbtstem.wordpress.com"
      } ]
    },
    "geo" : { },
    "id_str" : "600589850119696384",
    "text" : "This is your periodic reminder of the #LGBTSTEM blog https:\/\/t.co\/l9kWVvKyoY -we're always looking for #LGBT people to talk about their work",
    "id" : 600589850119696384,
    "created_at" : "2015-05-19 09:12:33 +0000",
    "user" : {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "protected" : false,
      "id_str" : "27841081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745191411327328256\/PI3LgJTF_normal.jpg",
      "id" : 27841081,
      "verified" : false
    }
  },
  "id" : 600605697089339393,
  "created_at" : "2015-05-19 10:15:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fernanda castano",
      "screen_name" : "ferwen",
      "indices" : [ 3, 10 ],
      "id_str" : "33123688",
      "id" : 33123688
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ferwen\/status\/600570825205522432\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/nsBcgdoiee",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFWn-40WoAA6WRH.jpg",
      "id_str" : "600570824169529344",
      "id" : 600570824169529344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFWn-40WoAA6WRH.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 475
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 671
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 671
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 671
      } ],
      "display_url" : "pic.twitter.com\/nsBcgdoiee"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600574393450901504",
  "text" : "RT @ferwen: Paleontology: Know the Warning Signs http:\/\/t.co\/nsBcgdoiee",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ferwen\/status\/600570825205522432\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/nsBcgdoiee",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFWn-40WoAA6WRH.jpg",
        "id_str" : "600570824169529344",
        "id" : 600570824169529344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFWn-40WoAA6WRH.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 475
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 671
        } ],
        "display_url" : "pic.twitter.com\/nsBcgdoiee"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600570825205522432",
    "text" : "Paleontology: Know the Warning Signs http:\/\/t.co\/nsBcgdoiee",
    "id" : 600570825205522432,
    "created_at" : "2015-05-19 07:56:57 +0000",
    "user" : {
      "name" : "fernanda castano",
      "screen_name" : "ferwen",
      "protected" : false,
      "id_str" : "33123688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908413180321452033\/JxquZ77e_normal.jpg",
      "id" : 33123688,
      "verified" : false
    }
  },
  "id" : 600574393450901504,
  "created_at" : "2015-05-19 08:11:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deborah Bowman",
      "screen_name" : "deborahbowman",
      "indices" : [ 3, 17 ],
      "id_str" : "21187559",
      "id" : 21187559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/IeybiZR3Kb",
      "expanded_url" : "http:\/\/www.independent.co.uk\/voices\/comment\/i-learnt-everything-i-need-to-know-about-the-nhs-when-i-gave-birth-to-my-son-at-16-weeks-10248172.html",
      "display_url" : "independent.co.uk\/voices\/comment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600568056235057153",
  "text" : "RT @deborahbowman: I learnt everything I need to know about the NHS when I gave birth to my son at 16 weeks http:\/\/t.co\/IeybiZR3Kb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/IeybiZR3Kb",
        "expanded_url" : "http:\/\/www.independent.co.uk\/voices\/comment\/i-learnt-everything-i-need-to-know-about-the-nhs-when-i-gave-birth-to-my-son-at-16-weeks-10248172.html",
        "display_url" : "independent.co.uk\/voices\/comment\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "599126093254254593",
    "text" : "I learnt everything I need to know about the NHS when I gave birth to my son at 16 weeks http:\/\/t.co\/IeybiZR3Kb",
    "id" : 599126093254254593,
    "created_at" : "2015-05-15 08:16:06 +0000",
    "user" : {
      "name" : "Deborah Bowman",
      "screen_name" : "deborahbowman",
      "protected" : false,
      "id_str" : "21187559",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/915584834881417216\/tHE5Xu7I_normal.jpg",
      "id" : 21187559,
      "verified" : false
    }
  },
  "id" : 600568056235057153,
  "created_at" : "2015-05-19 07:45:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pedro Mendes",
      "screen_name" : "gepasi",
      "indices" : [ 3, 10 ],
      "id_str" : "22406785",
      "id" : 22406785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/lygHccPTeu",
      "expanded_url" : "http:\/\/gael-varoquaux.info\/programming\/software-for-reproducible-science-lets-not-have-a-misunderstanding.html",
      "display_url" : "gael-varoquaux.info\/programming\/so\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600563317132939264",
  "text" : "RT @gepasi: Software for reproducible science: let\u2019s not have a misunderstanding http:\/\/t.co\/lygHccPTeu I entirely agree with this position",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/lygHccPTeu",
        "expanded_url" : "http:\/\/gael-varoquaux.info\/programming\/software-for-reproducible-science-lets-not-have-a-misunderstanding.html",
        "display_url" : "gael-varoquaux.info\/programming\/so\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "600560470995685377",
    "text" : "Software for reproducible science: let\u2019s not have a misunderstanding http:\/\/t.co\/lygHccPTeu I entirely agree with this position",
    "id" : 600560470995685377,
    "created_at" : "2015-05-19 07:15:48 +0000",
    "user" : {
      "name" : "Pedro Mendes",
      "screen_name" : "gepasi",
      "protected" : false,
      "id_str" : "22406785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509953518975729664\/OWJDX8AQ_normal.png",
      "id" : 22406785,
      "verified" : false
    }
  },
  "id" : 600563317132939264,
  "created_at" : "2015-05-19 07:27:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/YwxqhihWJy",
      "expanded_url" : "https:\/\/thenib.com\/electronic-folk-remedies-8089b0f78d6d",
      "display_url" : "thenib.com\/electronic-fol\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419999999, 8.753324899999951 ]
  },
  "id_str" : "600433338034315264",
  "text" : "Electronic Folk Remedies https:\/\/t.co\/YwxqhihWJy",
  "id" : 600433338034315264,
  "created_at" : "2015-05-18 22:50:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600406954666786816",
  "geo" : { },
  "id_str" : "600407131129516033",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU I actually read it up after you made the assumption, as I didn\u2019t know it either. :D",
  "id" : 600407131129516033,
  "in_reply_to_status_id" : 600406954666786816,
  "created_at" : "2015-05-18 21:06:29 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/VD670SUFCo",
      "expanded_url" : "http:\/\/mashable.com\/2015\/05\/17\/girls-with-toys\/?utm_cid=mash-com-Tw-main-link",
      "display_url" : "mashable.com\/2015\/05\/17\/gir\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "600402461602504704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409420000004, 8.753324899988144 ]
  },
  "id_str" : "600403608602079232",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU and for the target audience of the \u2018campaign\u2019, this is the origin: http:\/\/t.co\/VD670SUFCo :)",
  "id" : 600403608602079232,
  "in_reply_to_status_id" : 600402461602504704,
  "created_at" : "2015-05-18 20:52:29 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600402461602504704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140942000401, 8.753324891643494 ]
  },
  "id_str" : "600403077460537344",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU w\/o having numbers: I assume there\u2019s already a clear divide between Bachelor &amp; Master studies.",
  "id" : 600403077460537344,
  "in_reply_to_status_id" : 600402461602504704,
  "created_at" : "2015-05-18 20:50:23 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600397502634930176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409420002499, 8.75332489479 ]
  },
  "id_str" : "600400148980707328",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU leaky pipeline even worse for bioinformatics &amp; mol. biology et al. comp. to other bio-fields given my (limited) experience.",
  "id" : 600400148980707328,
  "in_reply_to_status_id" : 600397502634930176,
  "created_at" : "2015-05-18 20:38:45 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/TE0TDZjUyB",
      "expanded_url" : "http:\/\/www.cell.com\/crosstalk\/tackling-the-leaky-pipe?startPage=2",
      "display_url" : "cell.com\/crosstalk\/tack\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "600397502634930176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419991139, 8.753324918452982 ]
  },
  "id_str" : "600399598230835200",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU depends on where you are looking career-wise: http:\/\/t.co\/TE0TDZjUyB",
  "id" : 600399598230835200,
  "in_reply_to_status_id" : 600397502634930176,
  "created_at" : "2015-05-18 20:36:33 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TGAC",
      "screen_name" : "GenomeAnalysis",
      "indices" : [ 3, 18 ],
      "id_str" : "741221534082183168",
      "id" : 741221534082183168
    }, {
      "name" : "PacBio",
      "screen_name" : "PacBio",
      "indices" : [ 105, 112 ],
      "id_str" : "39694489",
      "id" : 39694489
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Science",
      "indices" : [ 20, 28 ]
    }, {
      "text" : "GirlsWithToys",
      "indices" : [ 113, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600395694822785024",
  "text" : "RT @GenomeAnalysis: #Science isn't just for men, especially biology! Here's Stephanie and Vicky with our @PacBio #GirlsWithToys http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PacBio",
        "screen_name" : "PacBio",
        "indices" : [ 85, 92 ],
        "id_str" : "39694489",
        "id" : 39694489
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GenomeAnalysis\/status\/600329623386386432\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/SBpXWFzY5c",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFTMnGAXIAIxlr8.png",
        "id_str" : "600329622346211330",
        "id" : 600329622346211330,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFTMnGAXIAIxlr8.png",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/SBpXWFzY5c"
      } ],
      "hashtags" : [ {
        "text" : "Science",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "GirlsWithToys",
        "indices" : [ 93, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600329623386386432",
    "text" : "#Science isn't just for men, especially biology! Here's Stephanie and Vicky with our @PacBio #GirlsWithToys http:\/\/t.co\/SBpXWFzY5c",
    "id" : 600329623386386432,
    "created_at" : "2015-05-18 15:58:30 +0000",
    "user" : {
      "name" : "Earlham Institute",
      "screen_name" : "EarlhamInst",
      "protected" : false,
      "id_str" : "93655345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747326409463341057\/jCJ7Jycw_normal.jpg",
      "id" : 93655345,
      "verified" : false
    }
  },
  "id" : 600395694822785024,
  "created_at" : "2015-05-18 20:21:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 106, 113 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/fLhl0HUBiU",
      "expanded_url" : "https:\/\/www.beaconreader.com\/projects\/arikia-millikans-remote-year",
      "display_url" : "beaconreader.com\/projects\/ariki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600393118073102336",
  "text" : "\u00ABall I've got is a mandate to write and a big case of wanderlust\u00BB which translates into a mandate to fund @arikia! https:\/\/t.co\/fLhl0HUBiU",
  "id" : 600393118073102336,
  "created_at" : "2015-05-18 20:10:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 3, 14 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/ZGXed7GWLc",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2015\/05\/what-we-talk-about-when-we-talk-about-the-raised-hands-emoji\/392774\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600391383690682368",
  "text" : "RT @LouWoodley: On the meaning(s) of emojis: http:\/\/t.co\/ZGXed7GWLc &lt;-- including the raised hands one",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/ZGXed7GWLc",
        "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2015\/05\/what-we-talk-about-when-we-talk-about-the-raised-hands-emoji\/392774\/",
        "display_url" : "theatlantic.com\/technology\/arc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "600389355455303680",
    "text" : "On the meaning(s) of emojis: http:\/\/t.co\/ZGXed7GWLc &lt;-- including the raised hands one",
    "id" : 600389355455303680,
    "created_at" : "2015-05-18 19:55:51 +0000",
    "user" : {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "protected" : false,
      "id_str" : "20342875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/415633332408688640\/IRl4qNXY_normal.jpeg",
      "id" : 20342875,
      "verified" : false
    }
  },
  "id" : 600391383690682368,
  "created_at" : "2015-05-18 20:03:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600371514874138624",
  "geo" : { },
  "id_str" : "600372397745770496",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @Lobot finally things can get competitive!",
  "id" : 600372397745770496,
  "in_reply_to_status_id" : 600371514874138624,
  "created_at" : "2015-05-18 18:48:28 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600364182450634752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140508647669, 8.753406043284203 ]
  },
  "id_str" : "600370488884514816",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @Lobot next time I\u2019m around you just have to join me for a swim :p",
  "id" : 600370488884514816,
  "in_reply_to_status_id" : 600364182450634752,
  "created_at" : "2015-05-18 18:40:53 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600360299645018112",
  "geo" : { },
  "id_str" : "600361005340827648",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @Lobot I hoped for naked tourists taking a swim and was utterly disappointed by the lack thereof!",
  "id" : 600361005340827648,
  "in_reply_to_status_id" : 600360299645018112,
  "created_at" : "2015-05-18 18:03:12 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11609582215949, 8.677089566627284 ]
  },
  "id_str" : "600343507107225600",
  "text" : "\u00ABWhat\u2019s the problem with your phone?\u00BB\u2014\u00ABThe display is broken.\u00BB\u2014\u00ABCan you reproduce the problem?\u00BB\u2014\u00ABShall I drop it again in front of you?\u00BB",
  "id" : 600343507107225600,
  "created_at" : "2015-05-18 16:53:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Holmes",
      "screen_name" : "ianholmes",
      "indices" : [ 3, 13 ],
      "id_str" : "7079752",
      "id" : 7079752
    }, {
      "name" : "Oxford Nanopore",
      "screen_name" : "nanopore",
      "indices" : [ 58, 67 ],
      "id_str" : "37732219",
      "id" : 37732219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600318315895070720",
  "text" : "RT @ianholmes: By the way, I love it when people snipe at @nanopore because they announced too early at AGBT 2012. \"My flying car is LATE, \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oxford Nanopore",
        "screen_name" : "nanopore",
        "indices" : [ 43, 52 ],
        "id_str" : "37732219",
        "id" : 37732219
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "599038855677943808",
    "text" : "By the way, I love it when people snipe at @nanopore because they announced too early at AGBT 2012. \"My flying car is LATE, you charlatan\"",
    "id" : 599038855677943808,
    "created_at" : "2015-05-15 02:29:27 +0000",
    "user" : {
      "name" : "Ian Holmes",
      "screen_name" : "ianholmes",
      "protected" : false,
      "id_str" : "7079752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816807997120782336\/DRHqbOSj_normal.jpg",
      "id" : 7079752,
      "verified" : false
    }
  },
  "id" : 600318315895070720,
  "created_at" : "2015-05-18 15:13:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/GzkVDVrCiE",
      "expanded_url" : "http:\/\/myreactiongifs.com\/gifs\/thefountain.gif",
      "display_url" : "myreactiongifs.com\/gifs\/thefounta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220389303922, 8.627543606134816 ]
  },
  "id_str" : "600295207016472576",
  "text" : "playing around with a graph database for the afternoon. +1 tech hipster cred http:\/\/t.co\/GzkVDVrCiE",
  "id" : 600295207016472576,
  "created_at" : "2015-05-18 13:41:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain \u2744\uFE0F\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDF93",
      "screen_name" : "DevilleSy",
      "indices" : [ 3, 13 ],
      "id_str" : "331228486",
      "id" : 331228486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/MtGMRiOhBa",
      "expanded_url" : "http:\/\/www.nature.com\/nature\/journal\/v520\/n7548\/full\/nature14437.html",
      "display_url" : "nature.com\/nature\/journal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600262215153889280",
  "text" : "RT @DevilleSy: Reviewer 3: \"Figure 4 is nice, but the authors should add a picture of Napoleon\" http:\/\/t.co\/MtGMRiOhBa http:\/\/t.co\/rqcC1TDZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DevilleSy\/status\/600257591353208833\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/rqcC1TDZWx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFSKwW-WgAElrUR.jpg",
        "id_str" : "600257213752573953",
        "id" : 600257213752573953,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFSKwW-WgAElrUR.jpg",
        "sizes" : [ {
          "h" : 834,
          "resize" : "fit",
          "w" : 1077
        }, {
          "h" : 527,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 834,
          "resize" : "fit",
          "w" : 1077
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 834,
          "resize" : "fit",
          "w" : 1077
        } ],
        "display_url" : "pic.twitter.com\/rqcC1TDZWx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/MtGMRiOhBa",
        "expanded_url" : "http:\/\/www.nature.com\/nature\/journal\/v520\/n7548\/full\/nature14437.html",
        "display_url" : "nature.com\/nature\/journal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "600257591353208833",
    "text" : "Reviewer 3: \"Figure 4 is nice, but the authors should add a picture of Napoleon\" http:\/\/t.co\/MtGMRiOhBa http:\/\/t.co\/rqcC1TDZWx",
    "id" : 600257591353208833,
    "created_at" : "2015-05-18 11:12:16 +0000",
    "user" : {
      "name" : "Sylvain \u2744\uFE0F\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDF93",
      "screen_name" : "DevilleSy",
      "protected" : false,
      "id_str" : "331228486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887046588954226688\/p3UlM_8C_normal.jpg",
      "id" : 331228486,
      "verified" : false
    }
  },
  "id" : 600262215153889280,
  "created_at" : "2015-05-18 11:30:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/yeB8QfnW3B",
      "expanded_url" : "http:\/\/www.biomedcentral.com\/1471-2148\/15\/76",
      "display_url" : "biomedcentral.com\/1471-2148\/15\/76"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218015161854, 8.627686105072177 ]
  },
  "id_str" : "600237156922204161",
  "text" : "Darwin and Fisher meet at biotech: on the potential of computational molecular evolution in industry http:\/\/t.co\/yeB8QfnW3B",
  "id" : 600237156922204161,
  "created_at" : "2015-05-18 09:51:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/CiBQTqJpLW",
      "expanded_url" : "http:\/\/bcgavel.com\/wp-content\/uploads\/2014\/07\/tumblr_mtr5dq4fGM1rln1hlo1_500.gif",
      "display_url" : "bcgavel.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218380146934, 8.627506656328924 ]
  },
  "id_str" : "600221778758209536",
  "text" : "caffeine status http:\/\/t.co\/CiBQTqJpLW",
  "id" : 600221778758209536,
  "created_at" : "2015-05-18 08:49:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 78, 94 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/VlFFlBJ2t9",
      "expanded_url" : "https:\/\/theconversation.com\/how-a-small-backpack-for-fast-genomic-sequencing-is-helping-combat-ebola-41863",
      "display_url" : "theconversation.com\/how-a-small-ba\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220226139909, 8.627553739440785 ]
  },
  "id_str" : "600197888292036608",
  "text" : "\u00ABHow a small backpack for fast genomic sequencing is helping combat\u00A0Ebola\u00BB by @pathogenomenick https:\/\/t.co\/VlFFlBJ2t9",
  "id" : 600197888292036608,
  "created_at" : "2015-05-18 07:15:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 88, 101 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/my1nMjKQBJ",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2015\/05\/13\/019299",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600195226565779457",
  "text" : "FIQT: a simple, powerful method to accurately estimate effect sizes in genome scans \/cc @PhilippBayer http:\/\/t.co\/my1nMjKQBJ",
  "id" : 600195226565779457,
  "created_at" : "2015-05-18 07:04:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Winters",
      "screen_name" : "replicatedtypo",
      "indices" : [ 3, 18 ],
      "id_str" : "15677536",
      "id" : 15677536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/CPfZn7MynU",
      "expanded_url" : "http:\/\/thelousylinguist.blogspot.com\/2015\/05\/the-language-myth-preliminary-thoughts.html",
      "display_url" : "thelousylinguist.blogspot.com\/2015\/05\/the-la\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600187792300384256",
  "text" : "RT @replicatedtypo: The Language Myth - Preliminary Thoughts http:\/\/t.co\/CPfZn7MynU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/CPfZn7MynU",
        "expanded_url" : "http:\/\/thelousylinguist.blogspot.com\/2015\/05\/the-language-myth-preliminary-thoughts.html",
        "display_url" : "thelousylinguist.blogspot.com\/2015\/05\/the-la\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "600177966908211200",
    "text" : "The Language Myth - Preliminary Thoughts http:\/\/t.co\/CPfZn7MynU",
    "id" : 600177966908211200,
    "created_at" : "2015-05-18 05:55:52 +0000",
    "user" : {
      "name" : "James Winters",
      "screen_name" : "replicatedtypo",
      "protected" : false,
      "id_str" : "15677536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781432695838609409\/W-qS38wx_normal.jpg",
      "id" : 15677536,
      "verified" : false
    }
  },
  "id" : 600187792300384256,
  "created_at" : "2015-05-18 06:34:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 37, 50 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600170192946204672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17217997859862, 8.627696411378913 ]
  },
  "id_str" : "600179899006111744",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch Doh, but the suggestion @PhilippBayer made requires reparsing everything anyhow, iirc?",
  "id" : 600179899006111744,
  "in_reply_to_status_id" : 600170192946204672,
  "created_at" : "2015-05-18 06:03:33 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600072882463571968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409425434485, 8.753324869939659 ]
  },
  "id_str" : "600073263486771200",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Dicke M\u00E4nner m\u00F6gen Alkohol in Bochum, oder so. :3",
  "id" : 600073263486771200,
  "in_reply_to_status_id" : 600072882463571968,
  "created_at" : "2015-05-17 22:59:49 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/1Wd3rD0ZNk",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=lIRMXGKEDbs&feature=youtu.be&t=3m14s",
      "display_url" : "youtube.com\/watch?v=lIRMXG\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "600070388287217664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409403535045, 8.753324990889675 ]
  },
  "id_str" : "600072645271560192",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj could be worse https:\/\/t.co\/1Wd3rD0ZNk",
  "id" : 600072645271560192,
  "in_reply_to_status_id" : 600070388287217664,
  "created_at" : "2015-05-17 22:57:22 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Gratwicke",
      "screen_name" : "BrianGratwicke",
      "indices" : [ 3, 18 ],
      "id_str" : "102087933",
      "id" : 102087933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/CdaNGFb4lC",
      "expanded_url" : "http:\/\/nyti.ms\/1PoQHFS",
      "display_url" : "nyti.ms\/1PoQHFS"
    } ]
  },
  "geo" : { },
  "id_str" : "599916578738720768",
  "text" : "RT @BrianGratwicke: It Is, in Fact, Rocket Science http:\/\/t.co\/CdaNGFb4lC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/CdaNGFb4lC",
        "expanded_url" : "http:\/\/nyti.ms\/1PoQHFS",
        "display_url" : "nyti.ms\/1PoQHFS"
      } ]
    },
    "geo" : { },
    "id_str" : "599893157279563776",
    "text" : "It Is, in Fact, Rocket Science http:\/\/t.co\/CdaNGFb4lC",
    "id" : 599893157279563776,
    "created_at" : "2015-05-17 11:04:08 +0000",
    "user" : {
      "name" : "Brian Gratwicke",
      "screen_name" : "BrianGratwicke",
      "protected" : false,
      "id_str" : "102087933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/878968660278333440\/b2lCC4gi_normal.jpg",
      "id" : 102087933,
      "verified" : false
    }
  },
  "id" : 599916578738720768,
  "created_at" : "2015-05-17 12:37:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/nbnlvbBN2q",
      "expanded_url" : "https:\/\/instagram.com\/p\/2x6y45BwuF\/",
      "display_url" : "instagram.com\/p\/2x6y45BwuF\/"
    } ]
  },
  "geo" : { },
  "id_str" : "599886795522834432",
  "text" : "ups and downs https:\/\/t.co\/nbnlvbBN2q",
  "id" : 599886795522834432,
  "created_at" : "2015-05-17 10:38:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/599835434429116416\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/Y4C6I4siBE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFMLJcEWoAEKxiJ.jpg",
      "id_str" : "599835432151588865",
      "id" : 599835432151588865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFMLJcEWoAEKxiJ.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Y4C6I4siBE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599835434429116416",
  "text" : "gimme some art. http:\/\/t.co\/Y4C6I4siBE",
  "id" : 599835434429116416,
  "created_at" : "2015-05-17 07:14:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/xKBv2hYn7E",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=3738",
      "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "599694272137428992",
  "text" : "numerology  http:\/\/t.co\/xKBv2hYn7E",
  "id" : 599694272137428992,
  "created_at" : "2015-05-16 21:53:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 14, 30 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599667082079379456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.08945720461391, 7.613777769736585 ]
  },
  "id_str" : "599690278295969792",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @pathogenomenick I\u2019ll claim a draw!",
  "id" : 599690278295969792,
  "in_reply_to_status_id" : 599667082079379456,
  "created_at" : "2015-05-16 21:37:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/h9rQiAX2EB",
      "expanded_url" : "https:\/\/instagram.com\/p\/2wCQY8hwvo\/",
      "display_url" : "instagram.com\/p\/2wCQY8hwvo\/"
    } ]
  },
  "geo" : { },
  "id_str" : "599621726394314752",
  "text" : "Wannabe Arcology https:\/\/t.co\/h9rQiAX2EB",
  "id" : 599621726394314752,
  "created_at" : "2015-05-16 17:05:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 3, 10 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/CqlLouWlF6",
      "expanded_url" : "https:\/\/www.beaconreader.com\/projects\/arikia-millikans-remote-year",
      "display_url" : "beaconreader.com\/projects\/ariki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "599299696763510784",
  "text" : "RT @arikia: Thanks to your generosity, I\u2019m over 2\/3 funded with 5 days left to go. Feeling loved and inspired &lt;3 https:\/\/t.co\/CqlLouWlF6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/CqlLouWlF6",
        "expanded_url" : "https:\/\/www.beaconreader.com\/projects\/arikia-millikans-remote-year",
        "display_url" : "beaconreader.com\/projects\/ariki\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "599294084205916160",
    "text" : "Thanks to your generosity, I\u2019m over 2\/3 funded with 5 days left to go. Feeling loved and inspired &lt;3 https:\/\/t.co\/CqlLouWlF6",
    "id" : 599294084205916160,
    "created_at" : "2015-05-15 19:23:38 +0000",
    "user" : {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "protected" : false,
      "id_str" : "71654283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897255084073025537\/5uB8YwJG_normal.jpg",
      "id" : 71654283,
      "verified" : false
    }
  },
  "id" : 599299696763510784,
  "created_at" : "2015-05-15 19:45:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika",
      "screen_name" : "GreenSkyOverMe",
      "indices" : [ 0, 15 ],
      "id_str" : "345356127",
      "id" : 345356127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599298386894954496",
  "geo" : { },
  "id_str" : "599298538099580928",
  "in_reply_to_user_id" : 345356127,
  "text" : "@GreenSkyOverMe oh, Ja. Ist heut Nacht irgendwann wieder reingekrochen gekommen :)",
  "id" : 599298538099580928,
  "in_reply_to_status_id" : 599298386894954496,
  "created_at" : "2015-05-15 19:41:20 +0000",
  "in_reply_to_screen_name" : "GreenSkyOverMe",
  "in_reply_to_user_id_str" : "345356127",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/hbjSw7VM4A",
      "expanded_url" : "https:\/\/instagram.com\/p\/2tqxRiBwnM\/",
      "display_url" : "instagram.com\/p\/2tqxRiBwnM\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.51504, 7.178728 ]
  },
  "id_str" : "599288604876271616",
  "text" : "Boilerplate Lyrics @ H\u00FClsmann https:\/\/t.co\/hbjSw7VM4A",
  "id" : 599288604876271616,
  "created_at" : "2015-05-15 19:01:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 3, 17 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/uwP7rFNW1m",
      "expanded_url" : "http:\/\/www.analome.com\/about-us\/",
      "display_url" : "analome.com\/about-us\/"
    } ]
  },
  "geo" : { },
  "id_str" : "599285819485085696",
  "text" : "RT @phylogenomics: and the winner, by a landslide, of the worst new omics word award - get ready - the ANALOME http:\/\/t.co\/uwP7rFNW1m h\/t @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kausik",
        "screen_name" : "kausikdatta22",
        "indices" : [ 119, 133 ],
        "id_str" : "212448611",
        "id" : 212448611
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/uwP7rFNW1m",
        "expanded_url" : "http:\/\/www.analome.com\/about-us\/",
        "display_url" : "analome.com\/about-us\/"
      } ]
    },
    "in_reply_to_status_id_str" : "599260694199017473",
    "geo" : { },
    "id_str" : "599266847444205570",
    "in_reply_to_user_id" : 212448611,
    "text" : "and the winner, by a landslide, of the worst new omics word award - get ready - the ANALOME http:\/\/t.co\/uwP7rFNW1m h\/t @kausikdatta22",
    "id" : 599266847444205570,
    "in_reply_to_status_id" : 599260694199017473,
    "created_at" : "2015-05-15 17:35:24 +0000",
    "in_reply_to_screen_name" : "kausikdatta22",
    "in_reply_to_user_id_str" : "212448611",
    "user" : {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "protected" : false,
      "id_str" : "15154811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751288576403382273\/AKfTiFxx_normal.jpg",
      "id" : 15154811,
      "verified" : true
    }
  },
  "id" : 599285819485085696,
  "created_at" : "2015-05-15 18:50:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TED Talks",
      "screen_name" : "TEDTalks",
      "indices" : [ 3, 12 ],
      "id_str" : "15492359",
      "id" : 15492359
    }, {
      "name" : "Roman Mars",
      "screen_name" : "romanmars",
      "indices" : [ 95, 105 ],
      "id_str" : "8198012",
      "id" : 8198012
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TEDTalks\/status\/598887837811998720\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/I7nk1socmy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE-tUL4WMAEqmMr.png",
      "id_str" : "598887837761679361",
      "id" : 598887837761679361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE-tUL4WMAEqmMr.png",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/I7nk1socmy"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/HM3CUyTXo4",
      "expanded_url" : "http:\/\/t.ted.com\/55PA3A8",
      "display_url" : "t.ted.com\/55PA3A8"
    } ]
  },
  "geo" : { },
  "id_str" : "599255580218400769",
  "text" : "RT @TEDTalks: Why Amsterdam has the most badass city flag in the world: http:\/\/t.co\/HM3CUyTXo4 @romanmars http:\/\/t.co\/I7nk1socmy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Roman Mars",
        "screen_name" : "romanmars",
        "indices" : [ 81, 91 ],
        "id_str" : "8198012",
        "id" : 8198012
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TEDTalks\/status\/598887837811998720\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/I7nk1socmy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE-tUL4WMAEqmMr.png",
        "id_str" : "598887837761679361",
        "id" : 598887837761679361,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE-tUL4WMAEqmMr.png",
        "sizes" : [ {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/I7nk1socmy"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/HM3CUyTXo4",
        "expanded_url" : "http:\/\/t.ted.com\/55PA3A8",
        "display_url" : "t.ted.com\/55PA3A8"
      } ]
    },
    "geo" : { },
    "id_str" : "598887837811998720",
    "text" : "Why Amsterdam has the most badass city flag in the world: http:\/\/t.co\/HM3CUyTXo4 @romanmars http:\/\/t.co\/I7nk1socmy",
    "id" : 598887837811998720,
    "created_at" : "2015-05-14 16:29:21 +0000",
    "user" : {
      "name" : "TED Talks",
      "screen_name" : "TEDTalks",
      "protected" : false,
      "id_str" : "15492359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877631054525472768\/Xp5FAPD5_normal.jpg",
      "id" : 15492359,
      "verified" : true
    }
  },
  "id" : 599255580218400769,
  "created_at" : "2015-05-15 16:50:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599250646022389761",
  "text" : "German w00t?",
  "id" : 599250646022389761,
  "created_at" : "2015-05-15 16:31:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599214499174965248",
  "geo" : { },
  "id_str" : "599216234601676800",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nice, thanks!",
  "id" : 599216234601676800,
  "in_reply_to_status_id" : 599214499174965248,
  "created_at" : "2015-05-15 14:14:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599173042854563840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409376735958, 8.753319710099838 ]
  },
  "id_str" : "599173972278796288",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr there goes my day!",
  "id" : 599173972278796288,
  "in_reply_to_status_id" : 599173042854563840,
  "created_at" : "2015-05-15 11:26:21 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599154388389724160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409416666979, 8.753324500175154 ]
  },
  "id_str" : "599154583416532992",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer ack, will do it.",
  "id" : 599154583416532992,
  "in_reply_to_status_id" : 599154388389724160,
  "created_at" : "2015-05-15 10:09:19 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599152233016664065",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409411555999, 8.753323887068188 ]
  },
  "id_str" : "599153922322882561",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch my best guess is some corruption that occurred somewhere along the way. Let's hope it\u2019s not a hardware issue.",
  "id" : 599153922322882561,
  "in_reply_to_status_id" : 599152233016664065,
  "created_at" : "2015-05-15 10:06:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599127023576031233",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10032741340584, 8.752089082331539 ]
  },
  "id_str" : "599129673226985472",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer thx!",
  "id" : 599129673226985472,
  "in_reply_to_status_id" : 599127023576031233,
  "created_at" : "2015-05-15 08:30:20 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599114959721799680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409418081019, 8.75332466377505 ]
  },
  "id_str" : "599116473139896320",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski so I\u2019m not the only one doing this!",
  "id" : 599116473139896320,
  "in_reply_to_status_id" : 599114959721799680,
  "created_at" : "2015-05-15 07:37:52 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/iOhCDLeubq",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/05\/14\/writing-music-coding.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+boingboing%2FiBag+%28Boing+Boing%29",
      "display_url" : "boingboing.net\/2015\/05\/14\/wri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "599113099099119616",
  "text" : "Wrong notes and syntax errors: The joy of improv in music and code http:\/\/t.co\/iOhCDLeubq",
  "id" : 599113099099119616,
  "created_at" : "2015-05-15 07:24:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/tfnIN7sZjZ",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/D2j31L1y0Yw\/info%3Adoi%2F10.1371%2Fjournal.pone.0126865",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "599111424351326208",
  "text" : "A Wandering Mind Does Not Stray Far from Home: The Value of Metacognition in Distant Search http:\/\/t.co\/tfnIN7sZjZ",
  "id" : 599111424351326208,
  "created_at" : "2015-05-15 07:17:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beenish Ahmed",
      "screen_name" : "beenishfahmed",
      "indices" : [ 3, 17 ],
      "id_str" : "264507577",
      "id" : 264507577
    }, {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 59, 66 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599093475594866688",
  "text" : "RT @beenishfahmed: Who doesn't wanna live vicariously thru @arikia as she travels thru 12 countries in 12 months? Help fund her: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arikia\uD83D\uDCAB",
        "screen_name" : "arikia",
        "indices" : [ 40, 47 ],
        "id_str" : "71654283",
        "id" : 71654283
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/Lt4ZzQEpbt",
        "expanded_url" : "http:\/\/www.beaconreader.com\/projects\/arikia-millikans-remote-year",
        "display_url" : "beaconreader.com\/projects\/ariki\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "598867374238932993",
    "text" : "Who doesn't wanna live vicariously thru @arikia as she travels thru 12 countries in 12 months? Help fund her: http:\/\/t.co\/Lt4ZzQEpbt",
    "id" : 598867374238932993,
    "created_at" : "2015-05-14 15:08:03 +0000",
    "user" : {
      "name" : "Beenish Ahmed",
      "screen_name" : "beenishfahmed",
      "protected" : false,
      "id_str" : "264507577",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603973815782215680\/JyR1Ebke_normal.jpg",
      "id" : 264507577,
      "verified" : true
    }
  },
  "id" : 599093475594866688,
  "created_at" : "2015-05-15 06:06:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/598951809814769664\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/XaA2dxm5IC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE_nfvwWYAMVOmU.jpg",
      "id_str" : "598951808044785667",
      "id" : 598951808044785667,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE_nfvwWYAMVOmU.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XaA2dxm5IC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598949267005374464",
  "geo" : { },
  "id_str" : "598951809814769664",
  "in_reply_to_user_id" : 14286491,
  "text" : "Instead she dragged me here, so now I can watch her play sandbox games. http:\/\/t.co\/XaA2dxm5IC",
  "id" : 598951809814769664,
  "in_reply_to_status_id" : 598949267005374464,
  "created_at" : "2015-05-14 20:43:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598949267005374464",
  "text" : "Might just have spent part of the evening following my clever cat around the neighborhood, hoping she leads me to my stupid cat that\u2019s lost.",
  "id" : 598949267005374464,
  "created_at" : "2015-05-14 20:33:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598943864854941697",
  "geo" : { },
  "id_str" : "598948433320407040",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime do you mail them out as well? ;)",
  "id" : 598948433320407040,
  "in_reply_to_status_id" : 598943864854941697,
  "created_at" : "2015-05-14 20:30:09 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/MIjFTawPXx",
      "expanded_url" : "http:\/\/www.gayiceland.is\/2015\/viking-weddings-trending\/",
      "display_url" : "gayiceland.is\/2015\/viking-we\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409392028669, 8.75332154459445 ]
  },
  "id_str" : "598939213921419265",
  "text" : "my gay viking wedding &lt;3 http:\/\/t.co\/MIjFTawPXx",
  "id" : 598939213921419265,
  "created_at" : "2015-05-14 19:53:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Eyre-Walker",
      "screen_name" : "AdamEyreWalker",
      "indices" : [ 3, 18 ],
      "id_str" : "632538212",
      "id" : 632538212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/p44GCNjJ5N",
      "expanded_url" : "http:\/\/kva.screen9.tv\/#D9TdrKkMoD-nsgNKcr49fg",
      "display_url" : "kva.screen9.tv\/#D9TdrKkMoD-ns\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598937352455749632",
  "text" : "RT @AdamEyreWalker: quantifying the nearly neutral theory at Crafoord prize symposium - talk by me available at http:\/\/t.co\/p44GCNjJ5N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/p44GCNjJ5N",
        "expanded_url" : "http:\/\/kva.screen9.tv\/#D9TdrKkMoD-nsgNKcr49fg",
        "display_url" : "kva.screen9.tv\/#D9TdrKkMoD-ns\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "598884078201503744",
    "text" : "quantifying the nearly neutral theory at Crafoord prize symposium - talk by me available at http:\/\/t.co\/p44GCNjJ5N",
    "id" : 598884078201503744,
    "created_at" : "2015-05-14 16:14:25 +0000",
    "user" : {
      "name" : "Adam Eyre-Walker",
      "screen_name" : "AdamEyreWalker",
      "protected" : false,
      "id_str" : "632538212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000378934951\/a6faf8023c1888143e3b381306189b3a_normal.jpeg",
      "id" : 632538212,
      "verified" : false
    }
  },
  "id" : 598937352455749632,
  "created_at" : "2015-05-14 19:46:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Eyre-Walker",
      "screen_name" : "AdamEyreWalker",
      "indices" : [ 0, 15 ],
      "id_str" : "632538212",
      "id" : 632538212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598884078201503744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407660097085, 8.753113784252319 ]
  },
  "id_str" : "598937344771792897",
  "in_reply_to_user_id" : 632538212,
  "text" : "@AdamEyreWalker thanks, really enjoyed the embedding into the larger historic context!",
  "id" : 598937344771792897,
  "in_reply_to_status_id" : 598884078201503744,
  "created_at" : "2015-05-14 19:46:05 +0000",
  "in_reply_to_screen_name" : "AdamEyreWalker",
  "in_reply_to_user_id_str" : "632538212",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598901547146342400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419231761, 8.7533248078432 ]
  },
  "id_str" : "598902366860095488",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer I think only one, though I\u2019m not 100% sure tbh. Gave so many interviews in the last weeks that it\u2019s a blur. :)",
  "id" : 598902366860095488,
  "in_reply_to_status_id" : 598901547146342400,
  "created_at" : "2015-05-14 17:27:05 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ethicspolice",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409417551057, 8.753324606228047 ]
  },
  "id_str" : "598901990048047104",
  "text" : "\u00ABDefinitions of science and \u201Cgood science\u201D also remain murky.\u00BB That\u2019s more or less the summary of all my experience with IRBs. #ethicspolice",
  "id" : 598901990048047104,
  "created_at" : "2015-05-14 17:25:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598895189965598720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419998595, 8.75332490003032 ]
  },
  "id_str" : "598895359398682625",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer uh, thanks. I guess you mean the Chaosradio? :)",
  "id" : 598895359398682625,
  "in_reply_to_status_id" : 598895189965598720,
  "created_at" : "2015-05-14 16:59:15 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598894370792841216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419619877, 8.7533249082141 ]
  },
  "id_str" : "598894568893984769",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer ah, may also explain why fitbit disabled us again, because sidekiq didn\u2019t reply.",
  "id" : 598894568893984769,
  "in_reply_to_status_id" : 598894370792841216,
  "created_at" : "2015-05-14 16:56:06 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598847423667134466",
  "geo" : { },
  "id_str" : "598848228096876544",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks should pass that one to the cloned IRB.",
  "id" : 598848228096876544,
  "in_reply_to_status_id" : 598847423667134466,
  "created_at" : "2015-05-14 13:51:58 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598846411652870145",
  "geo" : { },
  "id_str" : "598847301319315456",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks Herpes, the gift that keeps on giving!",
  "id" : 598847301319315456,
  "in_reply_to_status_id" : 598846411652870145,
  "created_at" : "2015-05-14 13:48:17 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Kroos",
      "screen_name" : "de_Wastl",
      "indices" : [ 0, 9 ],
      "id_str" : "17620538",
      "id" : 17620538
    }, {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 10, 21 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598846449162571776",
  "geo" : { },
  "id_str" : "598846901031718913",
  "in_reply_to_user_id" : 17620538,
  "text" : "@de_Wastl @plaetzchen @robikraus sehr sch\u00F6n. Das Ding muss jetzt  ~10 Jahre alt sein, hab es damals eigenh\u00E4ndig zusammengebaut :D",
  "id" : 598846901031718913,
  "in_reply_to_status_id" : 598846449162571776,
  "created_at" : "2015-05-14 13:46:41 +0000",
  "in_reply_to_screen_name" : "de_Wastl",
  "in_reply_to_user_id_str" : "17620538",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/598846411652870145\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/p2PrUIGdSi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE-HmUPUgAAMhMt.jpg",
      "id_str" : "598846367801311232",
      "id" : 598846367801311232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE-HmUPUgAAMhMt.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/p2PrUIGdSi"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/598846411652870145\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/p2PrUIGdSi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE-HmUmVAAAJJYq.jpg",
      "id_str" : "598846367897812992",
      "id" : 598846367897812992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE-HmUmVAAAJJYq.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/p2PrUIGdSi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598846584932212736",
  "text" : "RT @wilbanks: @gedankenstuecke some more: http:\/\/t.co\/p2PrUIGdSi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/598846411652870145\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/p2PrUIGdSi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE-HmUPUgAAMhMt.jpg",
        "id_str" : "598846367801311232",
        "id" : 598846367801311232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE-HmUPUgAAMhMt.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/p2PrUIGdSi"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/598846411652870145\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/p2PrUIGdSi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE-HmUmVAAAJJYq.jpg",
        "id_str" : "598846367897812992",
        "id" : 598846367897812992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE-HmUmVAAAJJYq.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/p2PrUIGdSi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "598846239795458048",
    "geo" : { },
    "id_str" : "598846411652870145",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke some more: http:\/\/t.co\/p2PrUIGdSi",
    "id" : 598846411652870145,
    "in_reply_to_status_id" : 598846239795458048,
    "created_at" : "2015-05-14 13:44:45 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 598846584932212736,
  "created_at" : "2015-05-14 13:45:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598845818452443136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409417961229, 8.753324934916886 ]
  },
  "id_str" : "598846239795458048",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks that\u2019s a lovely idea!",
  "id" : 598846239795458048,
  "in_reply_to_status_id" : 598845818452443136,
  "created_at" : "2015-05-14 13:44:04 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Kroos",
      "screen_name" : "de_Wastl",
      "indices" : [ 0, 9 ],
      "id_str" : "17620538",
      "id" : 17620538
    }, {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 10, 21 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598844996322746368",
  "geo" : { },
  "id_str" : "598845908189630464",
  "in_reply_to_user_id" : 17620538,
  "text" : "@de_Wastl @plaetzchen @robikraus von meiner Seite aus nicht. Hatte auch ganz vergessen das es die Kiste noch gibt :-)",
  "id" : 598845908189630464,
  "in_reply_to_status_id" : 598844996322746368,
  "created_at" : "2015-05-14 13:42:45 +0000",
  "in_reply_to_screen_name" : "de_Wastl",
  "in_reply_to_user_id_str" : "17620538",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "newseum",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598845515648864256",
  "text" : "RT @wilbanks: Well, depends on the ethics board. Cloning the wrong one could have some negative network effects. #newseum http:\/\/t.co\/D6H70\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/598841590308831233\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/D6H70W848y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE-DJZEXIAEEqIe.jpg",
        "id_str" : "598841472834805761",
        "id" : 598841472834805761,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE-DJZEXIAEEqIe.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/D6H70W848y"
      } ],
      "hashtags" : [ {
        "text" : "newseum",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598841590308831233",
    "text" : "Well, depends on the ethics board. Cloning the wrong one could have some negative network effects. #newseum http:\/\/t.co\/D6H70W848y",
    "id" : 598841590308831233,
    "created_at" : "2015-05-14 13:25:35 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 598845515648864256,
  "created_at" : "2015-05-14 13:41:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598841590308831233",
  "geo" : { },
  "id_str" : "598845510343077888",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks took me way to long to parse that in the way it (supposedly) was intended.",
  "id" : 598845510343077888,
  "in_reply_to_status_id" : 598841590308831233,
  "created_at" : "2015-05-14 13:41:10 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan White",
      "screen_name" : "ethanwhite",
      "indices" : [ 0, 11 ],
      "id_str" : "34540379",
      "id" : 34540379
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 12, 24 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/nEfyGF0KQz",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0024914",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "598534739822186497",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409339923656, 8.753326271424232 ]
  },
  "id_str" : "598844242342125569",
  "in_reply_to_user_id" : 34540379,
  "text" : "@ethanwhite @ctitusbrown http:\/\/t.co\/nEfyGF0KQz this one?",
  "id" : 598844242342125569,
  "in_reply_to_status_id" : 598534739822186497,
  "created_at" : "2015-05-14 13:36:08 +0000",
  "in_reply_to_screen_name" : "ethanwhite",
  "in_reply_to_user_id_str" : "34540379",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oleg Lavrovsky",
      "screen_name" : "loleg",
      "indices" : [ 0, 6 ],
      "id_str" : "5429882",
      "id" : 5429882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598763985853390848",
  "geo" : { },
  "id_str" : "598766511608696832",
  "in_reply_to_user_id" : 5429882,
  "text" : "@loleg with disciples standing by as the data ascends into the cloud? Sounds kinda sexy! ;)",
  "id" : 598766511608696832,
  "in_reply_to_status_id" : 598763985853390848,
  "created_at" : "2015-05-14 08:27:15 +0000",
  "in_reply_to_screen_name" : "loleg",
  "in_reply_to_user_id_str" : "5429882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 14, 24 ],
      "id_str" : "35304791",
      "id" : 35304791
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/598659278128476160\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/WHswXD19a0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE7dcN9WIAAT2ad.png",
      "id_str" : "598659277339893760",
      "id" : 598659277339893760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE7dcN9WIAAT2ad.png",
      "sizes" : [ {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/WHswXD19a0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598641388490772480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419108437, 8.75332491926492 ]
  },
  "id_str" : "598659278128476160",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @razibkhan that\u2019s fun. :-) from my data: http:\/\/t.co\/WHswXD19a0",
  "id" : 598659278128476160,
  "in_reply_to_status_id" : 598641388490772480,
  "created_at" : "2015-05-14 01:21:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 14, 22 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598632987794788352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409414250692, 8.753324193528877 ]
  },
  "id_str" : "598633291172945920",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @heyaudy the things that happen if you try to outsmart regular consumer software :D",
  "id" : 598633291172945920,
  "in_reply_to_status_id" : 598632987794788352,
  "created_at" : "2015-05-13 23:37:53 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ethicspolice",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409457318833, 8.753320429230623 ]
  },
  "id_str" : "598615120990838784",
  "text" : "\u00ABIn 2nd half of the 20th century researchers have unraveled the genetic code for all life.\u00BB Apparently my work here is done! #ethicspolice",
  "id" : 598615120990838784,
  "created_at" : "2015-05-13 22:25:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598554708740026368",
  "geo" : { },
  "id_str" : "598564787031642112",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU viel Erfolg :)",
  "id" : 598564787031642112,
  "in_reply_to_status_id" : 598554708740026368,
  "created_at" : "2015-05-13 19:05:40 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/7zPp8aqRuZ",
      "expanded_url" : "https:\/\/twitter.com\/Awl\/status\/598530543433687040",
      "display_url" : "twitter.com\/Awl\/status\/598\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598549417415806977",
  "text" : "RT @JBYoder: Okay, NOW can we hate Ira Glass? https:\/\/t.co\/7zPp8aqRuZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/7zPp8aqRuZ",
        "expanded_url" : "https:\/\/twitter.com\/Awl\/status\/598530543433687040",
        "display_url" : "twitter.com\/Awl\/status\/598\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "598546613661925378",
    "text" : "Okay, NOW can we hate Ira Glass? https:\/\/t.co\/7zPp8aqRuZ",
    "id" : 598546613661925378,
    "created_at" : "2015-05-13 17:53:27 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 598549417415806977,
  "created_at" : "2015-05-13 18:04:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/k0E6DH74PB",
      "expanded_url" : "https:\/\/twitter.com\/easternblot\/status\/598459086817067008",
      "display_url" : "twitter.com\/easternblot\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598541607420428288",
  "text" : "Makes 100% of authors being unhappy with how traditional peer review works. https:\/\/t.co\/k0E6DH74PB",
  "id" : 598541607420428288,
  "created_at" : "2015-05-13 17:33:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/v1CKgj8Weg",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/FrajBDPikVqBG\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/FrajBDPi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "598540711622012928",
  "geo" : { },
  "id_str" : "598541213399126017",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski \u201C\u2026and then I made all those people believe they were donating their data for open citizen science\u2026\u201D http:\/\/t.co\/v1CKgj8Weg",
  "id" : 598541213399126017,
  "in_reply_to_status_id" : 598540711622012928,
  "created_at" : "2015-05-13 17:32:00 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598540015862489088",
  "geo" : { },
  "id_str" : "598540542448967680",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski give it some time, it\u2019s all evolution: small, incremental changes will get me there eventually.",
  "id" : 598540542448967680,
  "in_reply_to_status_id" : 598540015862489088,
  "created_at" : "2015-05-13 17:29:20 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/rThwi8WsWG",
      "expanded_url" : "https:\/\/twitter.com\/tante\/status\/598532739160211457",
      "display_url" : "twitter.com\/tante\/status\/5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598539869854531585",
  "text" : "Worse: giving same origin story time &amp; again is boring. Tempted to give a new one each time when asked for openSNP. https:\/\/t.co\/rThwi8WsWG",
  "id" : 598539869854531585,
  "created_at" : "2015-05-13 17:26:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 3, 17 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Matthew Bietz",
      "screen_name" : "mbietz",
      "indices" : [ 32, 39 ],
      "id_str" : "5783382",
      "id" : 5783382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HDExplore2015",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598531186995163137",
  "text" : "RT @beaugunderson: happy to see @mbietz bring up social justice aspect of representativeness of personal health data at #HDExplore2015 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthew Bietz",
        "screen_name" : "mbietz",
        "indices" : [ 13, 20 ],
        "id_str" : "5783382",
        "id" : 5783382
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/beaugunderson\/status\/598527782319034369\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/PP6IdVUVwT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE5l2ENUsAAwmyM.jpg",
        "id_str" : "598527780003819520",
        "id" : 598527780003819520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE5l2ENUsAAwmyM.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/PP6IdVUVwT"
      } ],
      "hashtags" : [ {
        "text" : "HDExplore2015",
        "indices" : [ 101, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598527782319034369",
    "text" : "happy to see @mbietz bring up social justice aspect of representativeness of personal health data at #HDExplore2015 http:\/\/t.co\/PP6IdVUVwT",
    "id" : 598527782319034369,
    "created_at" : "2015-05-13 16:38:38 +0000",
    "user" : {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "protected" : false,
      "id_str" : "5746882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/913840034016399360\/pU3IIxqf_normal.jpg",
      "id" : 5746882,
      "verified" : false
    }
  },
  "id" : 598531186995163137,
  "created_at" : "2015-05-13 16:52:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "advertiselikeapro",
      "indices" : [ 93, 111 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598500931873955840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222637999998, 8.627554699999996 ]
  },
  "id_str" : "598522480802816000",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABTestimonial: I now know what a Single-nucleotide polymorphism is!\u00BB Might have to reconsider #advertiselikeapro",
  "id" : 598522480802816000,
  "in_reply_to_status_id" : 598500931873955840,
  "created_at" : "2015-05-13 16:17:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/mPV02qjvsp",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/05\/13\/how-to-buy-secret-cookies-bake.html",
      "display_url" : "boingboing.net\/2015\/05\/13\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598520143946379264",
  "text" : "Damn. Now I\u2019m hungry and do want to drive down to Spain. http:\/\/t.co\/mPV02qjvsp",
  "id" : 598520143946379264,
  "created_at" : "2015-05-13 16:08:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598513296891850752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222637999989, 8.627554700000168 ]
  },
  "id_str" : "598513577973121025",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye the tl;dr (or part of it) is: you keep the \u2018wrong\u2019 people (i.e. not the intended ones) from using data.",
  "id" : 598513577973121025,
  "in_reply_to_status_id" : 598513296891850752,
  "created_at" : "2015-05-13 15:42:11 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/5bU2ZIfS9p",
      "expanded_url" : "https:\/\/fortune.com\/2015\/05\/12\/Facebook-fcc-kevin-martin\/",
      "display_url" : "fortune.com\/2015\/05\/12\/Fac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598511481026695168",
  "text" : "RT @wilbanks: FB hires former FCC chief to move fast and break things (e.g. the open internet) https:\/\/t.co\/5bU2ZIfS9p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/5bU2ZIfS9p",
        "expanded_url" : "https:\/\/fortune.com\/2015\/05\/12\/Facebook-fcc-kevin-martin\/",
        "display_url" : "fortune.com\/2015\/05\/12\/Fac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "598503872374644736",
    "text" : "FB hires former FCC chief to move fast and break things (e.g. the open internet) https:\/\/t.co\/5bU2ZIfS9p",
    "id" : 598503872374644736,
    "created_at" : "2015-05-13 15:03:37 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 598511481026695168,
  "created_at" : "2015-05-13 15:33:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/FPn3kLevpf",
      "expanded_url" : "http:\/\/zookeys.pensoft.net\/articles.php?id=3036",
      "display_url" : "zookeys.pensoft.net\/articles.php?i\u2026"
    }, {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/kyydBVYFgS",
      "expanded_url" : "http:\/\/www.kuro5hin.org\/story\/2005\/9\/11\/16331\/0655",
      "display_url" : "kuro5hin.org\/story\/2005\/9\/1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "598504731624022016",
  "geo" : { },
  "id_str" : "598506003139792896",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye nope, largely because non-commercial clauses always mean trouble, cf. http:\/\/t.co\/FPn3kLevpf &amp; http:\/\/t.co\/kyydBVYFgS",
  "id" : 598506003139792896,
  "in_reply_to_status_id" : 598504731624022016,
  "created_at" : "2015-05-13 15:12:05 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598503673216532480",
  "geo" : { },
  "id_str" : "598503977190305792",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye by uploading the people dedicate their data into the public domain. So yes, everyone can use the data, w\/o limitations.",
  "id" : 598503977190305792,
  "in_reply_to_status_id" : 598503673216532480,
  "created_at" : "2015-05-13 15:04:02 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598501666720190466",
  "geo" : { },
  "id_str" : "598502162772144130",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye it\u2019s like Uber for genetic data. No wait, it\u2019s actually sharing and not \u201Csharing\u201D economy.",
  "id" : 598502162772144130,
  "in_reply_to_status_id" : 598501666720190466,
  "created_at" : "2015-05-13 14:56:49 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "advertiselikeapro",
      "indices" : [ 119, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598500931873955840",
  "text" : "Q: What learning opportunities does openSNP present for newcomers to the field? \nA: How to work in a legal gray area.\n\n#advertiselikeapro",
  "id" : 598500931873955840,
  "created_at" : "2015-05-13 14:51:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/09aw8wFzIf",
      "expanded_url" : "https:\/\/gedankenstuecke.piratenpad.de\/mozillascience",
      "display_url" : "gedankenstuecke.piratenpad.de\/mozillascience"
    } ]
  },
  "in_reply_to_status_id_str" : "598488920414932993",
  "geo" : { },
  "id_str" : "598490295827898368",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch here you go: https:\/\/t.co\/09aw8wFzIf :-)",
  "id" : 598490295827898368,
  "in_reply_to_status_id" : 598488920414932993,
  "created_at" : "2015-05-13 14:09:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598488920414932993",
  "geo" : { },
  "id_str" : "598488973619679232",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch currently setting it up :)",
  "id" : 598488973619679232,
  "in_reply_to_status_id" : 598488920414932993,
  "created_at" : "2015-05-13 14:04:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598487587486040064",
  "geo" : { },
  "id_str" : "598488642013810689",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch yeah, but submitting is a bit more than just having the repo on there, e.g. writing who we are &amp; what we need. ;)",
  "id" : 598488642013810689,
  "in_reply_to_status_id" : 598487587486040064,
  "created_at" : "2015-05-13 14:03:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598458910345994240",
  "geo" : { },
  "id_str" : "598461793833455617",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer okay, it\u2019s on my todo. :-)",
  "id" : 598461793833455617,
  "in_reply_to_status_id" : 598458910345994240,
  "created_at" : "2015-05-13 12:16:25 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598442147260534785",
  "geo" : { },
  "id_str" : "598442645669699584",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer sweet, do you think we should try to get openSNP up there?",
  "id" : 598442645669699584,
  "in_reply_to_status_id" : 598442147260534785,
  "created_at" : "2015-05-13 11:00:19 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/LhSyRJ7IOE",
      "expanded_url" : "https:\/\/thescienceweb.wordpress.com\/2015\/05\/13\/sequencing-company-about-to-sht-all-over-your-plans-once-again\/",
      "display_url" : "thescienceweb.wordpress.com\/2015\/05\/13\/seq\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222637999986, 8.627554700000259 ]
  },
  "id_str" : "598441977965871104",
  "text" : "\u00ABupgrades to the machine happen every 30 seconds and file formats change in real time.\u00BB https:\/\/t.co\/LhSyRJ7IOE",
  "id" : 598441977965871104,
  "created_at" : "2015-05-13 10:57:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598422461395431424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222638037521, 8.627554699187202 ]
  },
  "id_str" : "598440536819773441",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer Ah, okay. :-)",
  "id" : 598440536819773441,
  "in_reply_to_status_id" : 598422461395431424,
  "created_at" : "2015-05-13 10:51:57 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/rlHjGVGb1C",
      "expanded_url" : "http:\/\/labmath.org\/?p=467",
      "display_url" : "labmath.org\/?p=467"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222639978083, 8.627554657151897 ]
  },
  "id_str" : "598408178301345792",
  "text" : "\u00ABChange the culture. Use equations until it hurts.\u00BB On simple lab math http:\/\/t.co\/rlHjGVGb1C",
  "id" : 598408178301345792,
  "created_at" : "2015-05-13 08:43:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/uNfij3pcjZ",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/05\/12\/r2-vw-a-microbus-transformed.html",
      "display_url" : "boingboing.net\/2015\/05\/12\/r2-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598407332175941632",
  "text" : "So cute: R2-VW! http:\/\/t.co\/uNfij3pcjZ",
  "id" : 598407332175941632,
  "created_at" : "2015-05-13 08:40:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598403398233366528",
  "geo" : { },
  "id_str" : "598405322437435394",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer getting the SNPs we already have is still is rather large, or what\u2019s taking the mem?",
  "id" : 598405322437435394,
  "in_reply_to_status_id" : 598403398233366528,
  "created_at" : "2015-05-13 08:32:01 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598385236637024256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222636853164, 8.627554724811981 ]
  },
  "id_str" : "598385419798056960",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yay, gratz!",
  "id" : 598385419798056960,
  "in_reply_to_status_id" : 598385236637024256,
  "created_at" : "2015-05-13 07:12:56 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598381850193690624",
  "geo" : { },
  "id_str" : "598383780433403904",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer The VX6 could be problematic for Sidekiq, the parsing jobs take quite some RAM iirc?",
  "id" : 598383780433403904,
  "in_reply_to_status_id" : 598381850193690624,
  "created_at" : "2015-05-13 07:06:25 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598380470850686977",
  "geo" : { },
  "id_str" : "598380893783330816",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer ack, we should do a finance plan to calc how much we could expect per month. (dear, did i say that? getting old\u2026)",
  "id" : 598380893783330816,
  "in_reply_to_status_id" : 598380470850686977,
  "created_at" : "2015-05-13 06:54:57 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598379788731027456",
  "geo" : { },
  "id_str" : "598380145771151360",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer yeah, so we still would be stuck with the problem of getting vservs for sidekiq, rails and what else do we have.",
  "id" : 598380145771151360,
  "in_reply_to_status_id" : 598379788731027456,
  "created_at" : "2015-05-13 06:51:58 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598379015125278720",
  "geo" : { },
  "id_str" : "598379317014503426",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer yeah, largest SSD setup comparable to current one would be ~120\u20AC\/month.",
  "id" : 598379317014503426,
  "in_reply_to_status_id" : 598379015125278720,
  "created_at" : "2015-05-13 06:48:41 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598378574303916032",
  "geo" : { },
  "id_str" : "598379041951997952",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer they do have 480 &amp; 960 GB versions you can pay extra for ((39\/49)+15\u20AC\/month).",
  "id" : 598379041951997952,
  "in_reply_to_status_id" : 598378574303916032,
  "created_at" : "2015-05-13 06:47:35 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/82rJTi0gws",
      "expanded_url" : "https:\/\/www.hetzner.de\/hosting\/produkte_rootserver\/ex40ssd",
      "display_url" : "hetzner.de\/hosting\/produk\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "598377302221791233",
  "geo" : { },
  "id_str" : "598377990838427648",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer well now there are ones with SSDs instead of HDDs https:\/\/t.co\/82rJTi0gws",
  "id" : 598377990838427648,
  "in_reply_to_status_id" : 598377302221791233,
  "created_at" : "2015-05-13 06:43:24 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hummusday",
      "indices" : [ 69, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/bGKKsonUff",
      "expanded_url" : "http:\/\/food.walla.co.il\/item\/2852103",
      "display_url" : "food.walla.co.il\/item\/2852103"
    } ]
  },
  "in_reply_to_status_id_str" : "598373714430930945",
  "geo" : { },
  "id_str" : "598375793102848000",
  "in_reply_to_user_id" : 14286491,
  "text" : "Though I\u2019m kind of sad that there doesn\u2019t seem to be free hummus for #hummusday around here, cf. http:\/\/t.co\/bGKKsonUff",
  "id" : 598375793102848000,
  "in_reply_to_status_id" : 598373714430930945,
  "created_at" : "2015-05-13 06:34:41 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598373171981643776",
  "geo" : { },
  "id_str" : "598375305884078080",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer Uh, so either fundraising works out really great or we should think about getting more machines at hetzner?",
  "id" : 598375305884078080,
  "in_reply_to_status_id" : 598373171981643776,
  "created_at" : "2015-05-13 06:32:44 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hummusday",
      "indices" : [ 8, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598373714430930945",
  "text" : "So it\u2019s #hummusday. \\o\/ (Which is as good an excuse to overeat on it as any.)",
  "id" : 598373714430930945,
  "created_at" : "2015-05-13 06:26:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 14, 22 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598359238092664832",
  "geo" : { },
  "id_str" : "598359933948661760",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @heyaudy yeah, but csvkit should do the trick. :-)",
  "id" : 598359933948661760,
  "in_reply_to_status_id" : 598359238092664832,
  "created_at" : "2015-05-13 05:31:39 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Tsurkov",
      "screen_name" : "Elizrael",
      "indices" : [ 3, 12 ],
      "id_str" : "18014005",
      "id" : 18014005
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/qrx0Z97Gpn",
      "expanded_url" : "http:\/\/www.maysaloon.org\/2015\/05\/what-is-happiness-essay-by-syrian-girl.html",
      "display_url" : "maysaloon.org\/2015\/05\/what-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598355355178049536",
  "text" : "RT @Elizrael: \"What is Happiness?\" An Essay by a Syrian Girl called Sana http:\/\/t.co\/qrx0Z97Gpn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/qrx0Z97Gpn",
        "expanded_url" : "http:\/\/www.maysaloon.org\/2015\/05\/what-is-happiness-essay-by-syrian-girl.html",
        "display_url" : "maysaloon.org\/2015\/05\/what-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "598295434495455232",
    "text" : "\"What is Happiness?\" An Essay by a Syrian Girl called Sana http:\/\/t.co\/qrx0Z97Gpn",
    "id" : 598295434495455232,
    "created_at" : "2015-05-13 01:15:22 +0000",
    "user" : {
      "name" : "Elizabeth Tsurkov",
      "screen_name" : "Elizrael",
      "protected" : false,
      "id_str" : "18014005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/917584197551669248\/TT1Xoj96_normal.jpg",
      "id" : 18014005,
      "verified" : true
    }
  },
  "id" : 598355355178049536,
  "created_at" : "2015-05-13 05:13:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598255815464620032",
  "geo" : { },
  "id_str" : "598256478261276672",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez have fun and greetings to everyone. :-)",
  "id" : 598256478261276672,
  "in_reply_to_status_id" : 598255815464620032,
  "created_at" : "2015-05-12 22:40:34 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 14, 22 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/jQEARJFheu",
      "expanded_url" : "https:\/\/csvkit.readthedocs.org",
      "display_url" : "csvkit.readthedocs.org"
    } ]
  },
  "in_reply_to_status_id_str" : "598242832592314370",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409420000012, 8.753324899999694 ]
  },
  "id_str" : "598244635861983233",
  "in_reply_to_user_id" : 14286491,
  "text" : "@PhilippBayer @heyaudy I\u2019ll call myself out on that one: \n\ncsvcut -d \",\" -q \"\\\"\" your.csv \n\nseems to work ok. \n\nhttps:\/\/t.co\/jQEARJFheu",
  "id" : 598244635861983233,
  "in_reply_to_status_id" : 598242832592314370,
  "created_at" : "2015-05-12 21:53:30 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 14, 22 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598139891973812224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409420014468, 8.753324899687312 ]
  },
  "id_str" : "598242832592314370",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @heyaudy after playing around with your CSV for \u201Ca while\u201D I\u2019m rather sure that parsing the CSV is worse than API access.",
  "id" : 598242832592314370,
  "in_reply_to_status_id" : 598139891973812224,
  "created_at" : "2015-05-12 21:46:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen James",
      "screen_name" : "kejames",
      "indices" : [ 0, 8 ],
      "id_str" : "17385903",
      "id" : 17385903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598226627080884224",
  "geo" : { },
  "id_str" : "598227350669623296",
  "in_reply_to_user_id" : 17385903,
  "text" : "@kejames good idea,\u2B50\uFE0Fwould also work for Geastrum\/Astraeus :-)",
  "id" : 598227350669623296,
  "in_reply_to_status_id" : 598226627080884224,
  "created_at" : "2015-05-12 20:44:49 +0000",
  "in_reply_to_screen_name" : "kejames",
  "in_reply_to_user_id_str" : "17385903",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Elliott",
      "screen_name" : "FearLoathingBTX",
      "indices" : [ 3, 19 ],
      "id_str" : "268815203",
      "id" : 268815203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/8yCZ9HJzU3",
      "expanded_url" : "http:\/\/bloom.bg\/1F3vObl",
      "display_url" : "bloom.bg\/1F3vObl"
    } ]
  },
  "geo" : { },
  "id_str" : "598226478271242240",
  "text" : "RT @FearLoathingBTX: The Ugly Human Experiments Behind the Medical Ethics Police. An interview with Robert Klitzman. http:\/\/t.co\/8yCZ9HJzU3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/8yCZ9HJzU3",
        "expanded_url" : "http:\/\/bloom.bg\/1F3vObl",
        "display_url" : "bloom.bg\/1F3vObl"
      } ]
    },
    "geo" : { },
    "id_str" : "598100143838261248",
    "text" : "The Ugly Human Experiments Behind the Medical Ethics Police. An interview with Robert Klitzman. http:\/\/t.co\/8yCZ9HJzU3",
    "id" : 598100143838261248,
    "created_at" : "2015-05-12 12:19:21 +0000",
    "user" : {
      "name" : "Carl Elliott",
      "screen_name" : "FearLoathingBTX",
      "protected" : false,
      "id_str" : "268815203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613842886770061312\/lqHxQlQe_normal.jpg",
      "id" : 268815203,
      "verified" : false
    }
  },
  "id" : 598226478271242240,
  "created_at" : "2015-05-12 20:41:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Phylomoji",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598224687974490112",
  "text" : "Those of us working with fungi are pretty limited in their taxon sampling for #Phylomoji: \uD83C\uDF44. But at least there is one, poor algae people.",
  "id" : 598224687974490112,
  "created_at" : "2015-05-12 20:34:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madhvi Venkatraman",
      "screen_name" : "EvoBabble",
      "indices" : [ 3, 13 ],
      "id_str" : "1138274203",
      "id" : 1138274203
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EvoBabble\/status\/598220008146210816\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/ffQ8VgTqPj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE1N7WrW0AA4GMW.jpg",
      "id_str" : "598220007605194752",
      "id" : 598220007605194752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE1N7WrW0AA4GMW.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ffQ8VgTqPj"
    } ],
    "hashtags" : [ {
      "text" : "Phylomoji",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598222592802164737",
  "text" : "RT @EvoBabble: In the same vein as #Phylomoji I give you Manhattan plot emoji :P http:\/\/t.co\/ffQ8VgTqPj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EvoBabble\/status\/598220008146210816\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/ffQ8VgTqPj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE1N7WrW0AA4GMW.jpg",
        "id_str" : "598220007605194752",
        "id" : 598220007605194752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE1N7WrW0AA4GMW.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ffQ8VgTqPj"
      } ],
      "hashtags" : [ {
        "text" : "Phylomoji",
        "indices" : [ 20, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598220008146210816",
    "text" : "In the same vein as #Phylomoji I give you Manhattan plot emoji :P http:\/\/t.co\/ffQ8VgTqPj",
    "id" : 598220008146210816,
    "created_at" : "2015-05-12 20:15:38 +0000",
    "user" : {
      "name" : "Madhvi Venkatraman",
      "screen_name" : "EvoBabble",
      "protected" : false,
      "id_str" : "1138274203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/912380485812310017\/s86sjlWg_normal.jpg",
      "id" : 1138274203,
      "verified" : false
    }
  },
  "id" : 598222592802164737,
  "created_at" : "2015-05-12 20:25:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 3, 11 ],
      "id_str" : "27841081",
      "id" : 27841081
    }, {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "indices" : [ 23, 32 ],
      "id_str" : "2442015493",
      "id" : 2442015493
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 17, 22 ]
    }, {
      "text" : "SMBE15",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/x5fzoULveT",
      "expanded_url" : "https:\/\/twitter.com\/DIVAmagazine\/status\/597749671113728000",
      "display_url" : "twitter.com\/DIVAmagazine\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598211678761787392",
  "text" : "RT @PhdGeek: Any #LGBT @LGBTSTEM folks going to #SMBE15 might be interested... https:\/\/t.co\/x5fzoULveT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LGBTQ+ STEM",
        "screen_name" : "LGBTSTEM",
        "indices" : [ 10, 19 ],
        "id_str" : "2442015493",
        "id" : 2442015493
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBT",
        "indices" : [ 4, 9 ]
      }, {
        "text" : "SMBE15",
        "indices" : [ 35, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/x5fzoULveT",
        "expanded_url" : "https:\/\/twitter.com\/DIVAmagazine\/status\/597749671113728000",
        "display_url" : "twitter.com\/DIVAmagazine\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "597752828220874752",
    "text" : "Any #LGBT @LGBTSTEM folks going to #SMBE15 might be interested... https:\/\/t.co\/x5fzoULveT",
    "id" : 597752828220874752,
    "created_at" : "2015-05-11 13:19:14 +0000",
    "user" : {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "protected" : false,
      "id_str" : "27841081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745191411327328256\/PI3LgJTF_normal.jpg",
      "id" : 27841081,
      "verified" : false
    }
  },
  "id" : 598211678761787392,
  "created_at" : "2015-05-12 19:42:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((A.V. Flox)))",
      "screen_name" : "avflox",
      "indices" : [ 3, 10 ],
      "id_str" : "5845242",
      "id" : 5845242
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/avflox\/status\/598192006175666177\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/G0wTDlskuV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE00dbQVIAEtVQF.png",
      "id_str" : "598192005647245313",
      "id" : 598192005647245313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE00dbQVIAEtVQF.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 493
      } ],
      "display_url" : "pic.twitter.com\/G0wTDlskuV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598210383632048129",
  "text" : "RT @avflox: On FetLife, you can express your love for science in interesting ways. http:\/\/t.co\/G0wTDlskuV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/avflox\/status\/598192006175666177\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/G0wTDlskuV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE00dbQVIAEtVQF.png",
        "id_str" : "598192005647245313",
        "id" : 598192005647245313,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE00dbQVIAEtVQF.png",
        "sizes" : [ {
          "h" : 212,
          "resize" : "fit",
          "w" : 493
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 212,
          "resize" : "fit",
          "w" : 493
        }, {
          "h" : 212,
          "resize" : "fit",
          "w" : 493
        }, {
          "h" : 212,
          "resize" : "fit",
          "w" : 493
        } ],
        "display_url" : "pic.twitter.com\/G0wTDlskuV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598192006175666177",
    "text" : "On FetLife, you can express your love for science in interesting ways. http:\/\/t.co\/G0wTDlskuV",
    "id" : 598192006175666177,
    "created_at" : "2015-05-12 18:24:22 +0000",
    "user" : {
      "name" : "(((A.V. Flox)))",
      "screen_name" : "avflox",
      "protected" : false,
      "id_str" : "5845242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648980089443454976\/XGeNXI27_normal.jpg",
      "id" : 5845242,
      "verified" : false
    }
  },
  "id" : 598210383632048129,
  "created_at" : "2015-05-12 19:37:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 14, 22 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598174403805982720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409415474131, 8.753324997800393 ]
  },
  "id_str" : "598187191181901824",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @heyaudy but that\u2019s less of a pain than doing the csv-parsing, isn\u2019t it? :D",
  "id" : 598187191181901824,
  "in_reply_to_status_id" : 598174403805982720,
  "created_at" : "2015-05-12 18:05:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409418509743, 8.753324932201394 ]
  },
  "id_str" : "598186159374770176",
  "text" : "I\u2019m great w\/ cars. Called a student for support on my constantly flashing turn signal. She rightfully told me turn off the hazard flashers\u2026",
  "id" : 598186159374770176,
  "created_at" : "2015-05-12 18:01:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 9, 22 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598131647645646848",
  "geo" : { },
  "id_str" : "598132050441445376",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy @PhilippBayer oh, wow!",
  "id" : 598132050441445376,
  "in_reply_to_status_id" : 598131647645646848,
  "created_at" : "2015-05-12 14:26:08 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 9, 22 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598130663582216192",
  "geo" : { },
  "id_str" : "598131579026812928",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy @PhilippBayer wait, what? That\u2019s possible?!",
  "id" : 598131579026812928,
  "in_reply_to_status_id" : 598130663582216192,
  "created_at" : "2015-05-12 14:24:15 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598119560190001152",
  "text" : "RT @wilbanks: Anyone out there have a greatest-hits list of open knowledge scholarly articles (not blog posts or ranty-rants like mine)?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598119386155773952",
    "text" : "Anyone out there have a greatest-hits list of open knowledge scholarly articles (not blog posts or ranty-rants like mine)?",
    "id" : 598119386155773952,
    "created_at" : "2015-05-12 13:35:48 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 598119560190001152,
  "created_at" : "2015-05-12 13:36:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/fGpnpNTF9v",
      "expanded_url" : "http:\/\/www.nature.com\/scitable\/knowledge\/library\/the-breeder-s-equation-24204828",
      "display_url" : "nature.com\/scitable\/knowl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "598097199008985088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222637999998, 8.627554699999994 ]
  },
  "id_str" : "598097863705505792",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson damn hipsters being into the Breeder\u2019s equation before it was cool! http:\/\/t.co\/fGpnpNTF9v",
  "id" : 598097863705505792,
  "in_reply_to_status_id" : 598097199008985088,
  "created_at" : "2015-05-12 12:10:17 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/XuZm5q9jeQ",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/snpr\/issues\/170#issuecomment-101210409",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222638000001, 8.627554699999976 ]
  },
  "id_str" : "598093366618906624",
  "text" : "\u00ABIt's not a straight path when ls can't tell you the way\u00BB Bible quotes in GitHub issues \u2713 https:\/\/t.co\/XuZm5q9jeQ",
  "id" : 598093366618906624,
  "created_at" : "2015-05-12 11:52:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598081191129014272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222637999998, 8.627554699999994 ]
  },
  "id_str" : "598081467432992768",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ups, nein. Meine Lesestand ist noch bei ~10:00. ;-)",
  "id" : 598081467432992768,
  "in_reply_to_status_id" : 598081191129014272,
  "created_at" : "2015-05-12 11:05:08 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hague Declaration",
      "screen_name" : "haguedec",
      "indices" : [ 19, 28 ],
      "id_str" : "2915324884",
      "id" : 2915324884
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 34, 45 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/yE3BG9jc96",
      "expanded_url" : "http:\/\/thehaguedeclaration.com\/",
      "display_url" : "thehaguedeclaration.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222638000521, 8.6275546999972 ]
  },
  "id_str" : "598080741302472704",
  "text" : "We just signed the @haguedec with @openSNPorg and you should think about doing the same: http:\/\/t.co\/yE3BG9jc96",
  "id" : 598080741302472704,
  "created_at" : "2015-05-12 11:02:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598060966148988928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228341615208, 8.62854720170963 ]
  },
  "id_str" : "598062334414876672",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer thanks :)",
  "id" : 598062334414876672,
  "in_reply_to_status_id" : 598060966148988928,
  "created_at" : "2015-05-12 09:49:06 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 16, 30 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/6oAnqnylWw",
      "expanded_url" : "https:\/\/github.com\/beaugunderson\/intervention",
      "display_url" : "github.com\/beaugunderson\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222638030454, 8.62755469983735 ]
  },
  "id_str" : "598037531742117889",
  "text" : "Intervention by @beaugunderson has secondary uses, e.g. as a high-resolution lab notebook. https:\/\/t.co\/6oAnqnylWw",
  "id" : 598037531742117889,
  "created_at" : "2015-05-12 08:10:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 9, 21 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/Mz6CBlfOu6",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/snpr\/issues\/170#issuecomment-101173642",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222638774218, 8.627554695865326 ]
  },
  "id_str" : "598032318889070592",
  "text" : "In which @helgerausch figures out what kind of UX that bioinformaticians have to endure with dbSNP. https:\/\/t.co\/Mz6CBlfOu6",
  "id" : 598032318889070592,
  "created_at" : "2015-05-12 07:49:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John McCormack",
      "screen_name" : "LAevolving",
      "indices" : [ 3, 14 ],
      "id_str" : "382945026",
      "id" : 382945026
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Phylomoji",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598021285776613376",
  "text" : "RT @LAevolving: #Phylomoji 2\n\n\uD83D\uDC2C \uD83D\uDC0B \uD83D\uDC16 \uD83D\uDC20\n |     |     |    |\n  ==      |    |\n    |       |    |\n     ===     |\n        |       |\n        ====\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Phylomoji",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597962594394120194",
    "text" : "#Phylomoji 2\n\n\uD83D\uDC2C \uD83D\uDC0B \uD83D\uDC16 \uD83D\uDC20\n |     |     |    |\n  ==      |    |\n    |       |    |\n     ===     |\n        |       |\n        ====\n            |",
    "id" : 597962594394120194,
    "created_at" : "2015-05-12 03:12:46 +0000",
    "user" : {
      "name" : "John McCormack",
      "screen_name" : "LAevolving",
      "protected" : false,
      "id_str" : "382945026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497018903848304640\/1hy5QbrN_normal.jpeg",
      "id" : 382945026,
      "verified" : false
    }
  },
  "id" : 598021285776613376,
  "created_at" : "2015-05-12 07:05:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598019239195373569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222638170194, 8.627554699091062 ]
  },
  "id_str" : "598019767216275456",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski well, I suspect they are right in the sense that no employment office would try too hard getting me a job.",
  "id" : 598019767216275456,
  "in_reply_to_status_id" : 598019239195373569,
  "created_at" : "2015-05-12 06:59:57 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222214429009, 8.627557739701032 ]
  },
  "id_str" : "598018319011192832",
  "text" : "\u00ABWith your looks you better never get unemployed!\u00BB Useful advice I get at work.",
  "id" : 598018319011192832,
  "created_at" : "2015-05-12 06:54:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/7pMURWSC6h",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Acheron#\/media\/File:Gustave_Dore,_The_Divine_comedy,_Inferno,_plate_9,_Charon,_The_Ferryman_of_Hell.jpg",
      "display_url" : "en.m.wikipedia.org\/wiki\/Acheron#\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "597857638144200705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11476135253898, 8.750137329101582 ]
  },
  "id_str" : "597860013080711168",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy http:\/\/t.co\/7pMURWSC6h",
  "id" : 597860013080711168,
  "in_reply_to_status_id" : 597857638144200705,
  "created_at" : "2015-05-11 20:25:09 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/Zwfbo7EIbw",
      "expanded_url" : "https:\/\/instagram.com\/p\/2jeIz2Bwqg\/",
      "display_url" : "instagram.com\/p\/2jeIz2Bwqg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "597853451880632320",
  "text" : "Wake up, sheeple! https:\/\/t.co\/Zwfbo7EIbw",
  "id" : 597853451880632320,
  "created_at" : "2015-05-11 19:59:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597847808490758144",
  "geo" : { },
  "id_str" : "597849998894755840",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia thanks for all your work. Keeping my fingers crossed that funding works out!",
  "id" : 597849998894755840,
  "in_reply_to_status_id" : 597847808490758144,
  "created_at" : "2015-05-11 19:45:21 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597842480231542784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419999998, 8.753324899999997 ]
  },
  "id_str" : "597843362360795137",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia I\u2019ll be doing some travel inside Europe during the time as well, but I should work out somehow. Let me know if you need a couch :)",
  "id" : 597843362360795137,
  "in_reply_to_status_id" : 597842480231542784,
  "created_at" : "2015-05-11 19:18:59 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 10, 17 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/fLhl0HUBiU",
      "expanded_url" : "https:\/\/www.beaconreader.com\/projects\/arikia-millikans-remote-year",
      "display_url" : "beaconreader.com\/projects\/ariki\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419999998, 8.753324899999997 ]
  },
  "id_str" : "597841877086380032",
  "text" : "I so envy @arikia for the remote year opportunity, but it\u2019s so deserved. Go and take my money. https:\/\/t.co\/fLhl0HUBiU",
  "id" : 597841877086380032,
  "created_at" : "2015-05-11 19:13:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597814812622659585",
  "geo" : { },
  "id_str" : "597815706034511872",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy oh, so the N was for Nail-tional all the time?",
  "id" : 597815706034511872,
  "in_reply_to_status_id" : 597814812622659585,
  "created_at" : "2015-05-11 17:29:05 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597811282989953024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419999998, 8.753324899999997 ]
  },
  "id_str" : "597814415677902848",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy so the TSA will not only have your nail clippers but also your data? Great!",
  "id" : 597814415677902848,
  "in_reply_to_status_id" : 597811282989953024,
  "created_at" : "2015-05-11 17:23:58 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597334836001517568",
  "geo" : { },
  "id_str" : "597338477139775488",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski you will need a sabbatical to go through all of them. ;)",
  "id" : 597338477139775488,
  "in_reply_to_status_id" : 597334836001517568,
  "created_at" : "2015-05-10 09:52:45 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597110449063251969",
  "text" : "Finally managed to see season 2 of In The Flesh, thanks to having a sick day in bed. Still the best TV-take on Zombies.",
  "id" : 597110449063251969,
  "created_at" : "2015-05-09 18:46:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillaume Dumas \uD83D\uDD04",
      "screen_name" : "introspection",
      "indices" : [ 3, 17 ],
      "id_str" : "14403154",
      "id" : 14403154
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Statistics",
      "indices" : [ 47, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/QHQHJ7yFoh",
      "expanded_url" : "http:\/\/ow.ly\/MJBhQ",
      "display_url" : "ow.ly\/MJBhQ"
    } ]
  },
  "geo" : { },
  "id_str" : "597033733737336832",
  "text" : "RT @introspection: Blade Runner meets Bayesian #Statistics :D!\u2014Building a Voight-Kampff Test with Bayes Factor http:\/\/t.co\/QHQHJ7yFoh http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/introspection\/status\/597016569563185152\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/8XaEyett5R",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEkHZy_XIAEM9Oc.png",
        "id_str" : "597016565368954881",
        "id" : 597016565368954881,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEkHZy_XIAEM9Oc.png",
        "sizes" : [ {
          "h" : 295,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 953
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 953
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 953
        } ],
        "display_url" : "pic.twitter.com\/8XaEyett5R"
      } ],
      "hashtags" : [ {
        "text" : "Statistics",
        "indices" : [ 28, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/QHQHJ7yFoh",
        "expanded_url" : "http:\/\/ow.ly\/MJBhQ",
        "display_url" : "ow.ly\/MJBhQ"
      } ]
    },
    "geo" : { },
    "id_str" : "597016569563185152",
    "text" : "Blade Runner meets Bayesian #Statistics :D!\u2014Building a Voight-Kampff Test with Bayes Factor http:\/\/t.co\/QHQHJ7yFoh http:\/\/t.co\/8XaEyett5R",
    "id" : 597016569563185152,
    "created_at" : "2015-05-09 12:33:36 +0000",
    "user" : {
      "name" : "Guillaume Dumas \uD83D\uDD04",
      "screen_name" : "introspection",
      "protected" : false,
      "id_str" : "14403154",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681158719871258624\/s-nWU7Mb_normal.jpg",
      "id" : 14403154,
      "verified" : false
    }
  },
  "id" : 597033733737336832,
  "created_at" : "2015-05-09 13:41:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596744801841713154",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11186326450485, 8.741348119039491 ]
  },
  "id_str" : "596746198238765056",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime it\u2019s really too bad that no bioinformatician ever had to parse &amp; reformat data!",
  "id" : 596746198238765056,
  "in_reply_to_status_id" : 596744801841713154,
  "created_at" : "2015-05-08 18:39:15 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 14, 22 ],
      "id_str" : "114220397",
      "id" : 114220397
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 23, 30 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 31, 40 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409420071718, 8.753324898450245 ]
  },
  "id_str" : "596728925310611457",
  "text" : "Habemus WiFi! @branleb @TnaKng @Senficon",
  "id" : 596728925310611457,
  "created_at" : "2015-05-08 17:30:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596235456494239744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222637999998, 8.627554699999996 ]
  },
  "id_str" : "596643010668044288",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson at least i got it up and running by now. ;-)",
  "id" : 596643010668044288,
  "in_reply_to_status_id" : 596235456494239744,
  "created_at" : "2015-05-08 11:49:13 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222637999998, 8.627554699999996 ]
  },
  "id_str" : "596587938051391488",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr \u00ABTop image: Bjork making out with a robot\u00BB well chosen!",
  "id" : 596587938051391488,
  "created_at" : "2015-05-08 08:10:23 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @sckottie",
      "screen_name" : "recology_",
      "indices" : [ 3, 13 ],
      "id_str" : "4465848374",
      "id" : 4465848374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/30lpjTme46",
      "expanded_url" : "https:\/\/medium.com\/@b_k\/https-the-end-of-an-era-c106acded474",
      "display_url" : "medium.com\/@b_k\/https-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596566036146688000",
  "text" : "RT @recology_: HTTPS: the end of an era https:\/\/t.co\/30lpjTme46",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/30lpjTme46",
        "expanded_url" : "https:\/\/medium.com\/@b_k\/https-the-end-of-an-era-c106acded474",
        "display_url" : "medium.com\/@b_k\/https-the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "596564395901198336",
    "text" : "HTTPS: the end of an era https:\/\/t.co\/30lpjTme46",
    "id" : 596564395901198336,
    "created_at" : "2015-05-08 06:36:50 +0000",
    "user" : {
      "name" : "scott",
      "screen_name" : "sckottie",
      "protected" : false,
      "id_str" : "103004948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/806575041135726593\/tnm7p6Zp_normal.jpg",
      "id" : 103004948,
      "verified" : false
    }
  },
  "id" : 596566036146688000,
  "created_at" : "2015-05-08 06:43:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 8, 17 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 18, 25 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596434747380764672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11467010783536, 8.750167934688454 ]
  },
  "id_str" : "596435079557160960",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn @eramirez @fitbit same here, at least on first level.",
  "id" : 596435079557160960,
  "in_reply_to_status_id" : 596434747380764672,
  "created_at" : "2015-05-07 22:02:58 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaveTheLink",
      "indices" : [ 71, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/tiF0J7mdoi",
      "expanded_url" : "https:\/\/savethelink.org\/",
      "display_url" : "savethelink.org"
    } ]
  },
  "geo" : { },
  "id_str" : "596389007795294208",
  "text" : "Hey, Open-folks and all the others who like the internet, it\u2019s time to #SaveTheLink, ok? https:\/\/t.co\/tiF0J7mdoi",
  "id" : 596389007795294208,
  "created_at" : "2015-05-07 18:59:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/htTKeg3L9m",
      "expanded_url" : "https:\/\/mobile.twitter.com\/Senficon\/status\/595926195126042624",
      "display_url" : "mobile.twitter.com\/Senficon\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "596277197788323840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17822002153736, 8.625193578307771 ]
  },
  "id_str" : "596277935256031233",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch also: https:\/\/t.co\/htTKeg3L9m ;)",
  "id" : 596277935256031233,
  "in_reply_to_status_id" : 596277197788323840,
  "created_at" : "2015-05-07 11:38:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596277197788323840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17262821191569, 8.628796377266346 ]
  },
  "id_str" : "596277431490719744",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch ok, give it a minute, it's worth it, especially as we're largely based on text\/data mining :D",
  "id" : 596277431490719744,
  "in_reply_to_status_id" : 596277197788323840,
  "created_at" : "2015-05-07 11:36:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596275474826919936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218291686287, 8.627594682249484 ]
  },
  "id_str" : "596275616074362880",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch thx! btw: did you see the email re: the hague declaration?",
  "id" : 596275616074362880,
  "in_reply_to_status_id" : 596275474826919936,
  "created_at" : "2015-05-07 11:29:19 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596275351879311360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17611461252407, 8.626551915097908 ]
  },
  "id_str" : "596275429494943744",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch didn\u2019t do it so far.",
  "id" : 596275429494943744,
  "in_reply_to_status_id" : 596275351879311360,
  "created_at" : "2015-05-07 11:28:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Howard",
      "screen_name" : "samtayhow",
      "indices" : [ 3, 13 ],
      "id_str" : "2912016357",
      "id" : 2912016357
    }, {
      "name" : "O'Reilly Media",
      "screen_name" : "OReillyMedia",
      "indices" : [ 33, 46 ],
      "id_str" : "11069462",
      "id" : 11069462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "funny",
      "indices" : [ 79, 85 ]
    }, {
      "text" : "tech",
      "indices" : [ 86, 91 ]
    }, {
      "text" : "javascript",
      "indices" : [ 92, 103 ]
    }, {
      "text" : "webdev",
      "indices" : [ 104, 111 ]
    }, {
      "text" : "webdesign",
      "indices" : [ 112, 122 ]
    }, {
      "text" : "webdevelopment",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/4rBRIlv8yK",
      "expanded_url" : "https:\/\/medium.com\/@samtayhow\/the-complete-history-of-safari-books-34ff0210b9de",
      "display_url" : "medium.com\/@samtayhow\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596267484786884608",
  "text" : "RT @samtayhow: That time I wrote @OReillyMedia fanfic: https:\/\/t.co\/4rBRIlv8yK #funny #tech #javascript #webdev #webdesign #webdevelopment",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "O'Reilly Media",
        "screen_name" : "OReillyMedia",
        "indices" : [ 18, 31 ],
        "id_str" : "11069462",
        "id" : 11069462
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "funny",
        "indices" : [ 64, 70 ]
      }, {
        "text" : "tech",
        "indices" : [ 71, 76 ]
      }, {
        "text" : "javascript",
        "indices" : [ 77, 88 ]
      }, {
        "text" : "webdev",
        "indices" : [ 89, 96 ]
      }, {
        "text" : "webdesign",
        "indices" : [ 97, 107 ]
      }, {
        "text" : "webdevelopment",
        "indices" : [ 108, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/4rBRIlv8yK",
        "expanded_url" : "https:\/\/medium.com\/@samtayhow\/the-complete-history-of-safari-books-34ff0210b9de",
        "display_url" : "medium.com\/@samtayhow\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "596033787940741121",
    "text" : "That time I wrote @OReillyMedia fanfic: https:\/\/t.co\/4rBRIlv8yK #funny #tech #javascript #webdev #webdesign #webdevelopment",
    "id" : 596033787940741121,
    "created_at" : "2015-05-06 19:28:23 +0000",
    "user" : {
      "name" : "Taylor Howard",
      "screen_name" : "samtayhow",
      "protected" : false,
      "id_str" : "2912016357",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759091983310811137\/DU2yyfOY_normal.jpg",
      "id" : 2912016357,
      "verified" : false
    }
  },
  "id" : 596267484786884608,
  "created_at" : "2015-05-07 10:57:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1793323327328, 8.612600984300178 ]
  },
  "id_str" : "596251711079063552",
  "text" : "\u00ABWie jetzt, Schnaps-Tag? Seit ihr besoffen oder was?\u00BB \u2014 \u00ABWie der Name schon sagt.\u00BB",
  "id" : 596251711079063552,
  "created_at" : "2015-05-07 09:54:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596235456494239744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17301940917968, 8.628555297851562 ]
  },
  "id_str" : "596236710666698752",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson ah, too bad. would have loved to read more about it in a single place :)",
  "id" : 596236710666698752,
  "in_reply_to_status_id" : 596235456494239744,
  "created_at" : "2015-05-07 08:54:44 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596233182581686274",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17301976680321, 8.628555402158106 ]
  },
  "id_str" : "596234340339683328",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson sweet, where did you talk about it previously? :)",
  "id" : 596234340339683328,
  "in_reply_to_status_id" : 596233182581686274,
  "created_at" : "2015-05-07 08:45:18 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harm Otten",
      "screen_name" : "harm82",
      "indices" : [ 0, 7 ],
      "id_str" : "1678261",
      "id" : 1678261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596227176669827072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17375183106871, 8.628768910443643 ]
  },
  "id_str" : "596231075686383616",
  "in_reply_to_user_id" : 1678261,
  "text" : "@harm82 danke, aber ich bin entweder nicht der einzige Profi oder auch ein Amateur ;-)",
  "id" : 596231075686383616,
  "in_reply_to_status_id" : 596227176669827072,
  "created_at" : "2015-05-07 08:32:20 +0000",
  "in_reply_to_screen_name" : "harm82",
  "in_reply_to_user_id_str" : "1678261",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 3, 10 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596082033807458304",
  "text" : "RT @mrgunn: It\u2019s the conflation of ideological diets with diets that are supposed to help cure cancer... that\u2019s really dangerous. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ZCGaKk5Eun",
        "expanded_url" : "http:\/\/www.salon.com\/2015\/05\/03\/diet_fads_are_destroying_us_paleo_gluten_free_and_the_lies_we_tell_ourselves_partner\/",
        "display_url" : "salon.com\/2015\/05\/03\/die\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "596079631922401280",
    "text" : "It\u2019s the conflation of ideological diets with diets that are supposed to help cure cancer... that\u2019s really dangerous. http:\/\/t.co\/ZCGaKk5Eun",
    "id" : 596079631922401280,
    "created_at" : "2015-05-06 22:30:33 +0000",
    "user" : {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "protected" : false,
      "id_str" : "15237935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/679914371770798080\/FBcokUq2_normal.jpg",
      "id" : 15237935,
      "verified" : false
    }
  },
  "id" : 596082033807458304,
  "created_at" : "2015-05-06 22:40:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Pearson",
      "screen_name" : "shinchpearson",
      "indices" : [ 3, 17 ],
      "id_str" : "17138416",
      "id" : 17138416
    }, {
      "name" : "danah boyd",
      "screen_name" : "zephoria",
      "indices" : [ 75, 84 ],
      "id_str" : "633",
      "id" : 633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/UnaPH2C9ki",
      "expanded_url" : "https:\/\/medium.com\/p\/977b008ce689",
      "display_url" : "medium.com\/p\/977b008ce689"
    } ]
  },
  "geo" : { },
  "id_str" : "596067439034683392",
  "text" : "RT @shinchpearson: This is an amazing piece. \"I miss not being scared.\u201D by @zephoria https:\/\/t.co\/UnaPH2C9ki",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "danah boyd",
        "screen_name" : "zephoria",
        "indices" : [ 56, 65 ],
        "id_str" : "633",
        "id" : 633
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/UnaPH2C9ki",
        "expanded_url" : "https:\/\/medium.com\/p\/977b008ce689",
        "display_url" : "medium.com\/p\/977b008ce689"
      } ]
    },
    "geo" : { },
    "id_str" : "596012244644704258",
    "text" : "This is an amazing piece. \"I miss not being scared.\u201D by @zephoria https:\/\/t.co\/UnaPH2C9ki",
    "id" : 596012244644704258,
    "created_at" : "2015-05-06 18:02:47 +0000",
    "user" : {
      "name" : "Sarah Pearson",
      "screen_name" : "shinchpearson",
      "protected" : false,
      "id_str" : "17138416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582609754846928896\/ARogVYzR_normal.jpg",
      "id" : 17138416,
      "verified" : false
    }
  },
  "id" : 596067439034683392,
  "created_at" : "2015-05-06 21:42:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/wcuwUTQT52",
      "expanded_url" : "http:\/\/www.whatisitliketobeaphilosopher.com\/",
      "display_url" : "whatisitliketobeaphilosopher.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114827, 8.750213 ]
  },
  "id_str" : "596066469030559745",
  "text" : "\u00ABWhat's your favorite curse word?\u00BB \u2013 \u00ABFuck me, I don\u2019t know!\u00BB Great interview w\/ Michael Ruse (sry, lost the via) http:\/\/t.co\/wcuwUTQT52",
  "id" : 596066469030559745,
  "created_at" : "2015-05-06 21:38:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Eyre-Walker",
      "screen_name" : "AdamEyreWalker",
      "indices" : [ 3, 18 ],
      "id_str" : "632538212",
      "id" : 632538212
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AdamEyreWalker\/status\/595966282928906241\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/OB4M3P3w3r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEVMK61WAAAbQqT.jpg",
      "id_str" : "595966276171857920",
      "id" : 595966276171857920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEVMK61WAAAbQqT.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/OB4M3P3w3r"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596050633637142528",
  "text" : "RT @AdamEyreWalker: Tomoko Ohta receiving the Crafoord prize - very well deserved http:\/\/t.co\/OB4M3P3w3r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AdamEyreWalker\/status\/595966282928906241\/photo\/1",
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/OB4M3P3w3r",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEVMK61WAAAbQqT.jpg",
        "id_str" : "595966276171857920",
        "id" : 595966276171857920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEVMK61WAAAbQqT.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/OB4M3P3w3r"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "595966282928906241",
    "text" : "Tomoko Ohta receiving the Crafoord prize - very well deserved http:\/\/t.co\/OB4M3P3w3r",
    "id" : 595966282928906241,
    "created_at" : "2015-05-06 15:00:09 +0000",
    "user" : {
      "name" : "Adam Eyre-Walker",
      "screen_name" : "AdamEyreWalker",
      "protected" : false,
      "id_str" : "632538212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000378934951\/a6faf8023c1888143e3b381306189b3a_normal.jpeg",
      "id" : 632538212,
      "verified" : false
    }
  },
  "id" : 596050633637142528,
  "created_at" : "2015-05-06 20:35:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596021783817367552",
  "geo" : { },
  "id_str" : "596024231969828864",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks now I really wish I was done with my degree already. ;)",
  "id" : 596024231969828864,
  "in_reply_to_status_id" : 596021783817367552,
  "created_at" : "2015-05-06 18:50:25 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11530817526269, 8.750350239667688 ]
  },
  "id_str" : "596014659792146433",
  "text" : "Just started the 3rd year of my PhD. By accidentally having to teach first-year students I also finally learn the basics of bioinformatics.",
  "id" : 596014659792146433,
  "created_at" : "2015-05-06 18:12:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/596006012689186816\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/60NUTpKeMh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEVwTylWYAAoHF3.png",
      "id_str" : "596006010994712576",
      "id" : 596006010994712576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEVwTylWYAAoHF3.png",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      } ],
      "display_url" : "pic.twitter.com\/60NUTpKeMh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595730465706909696",
  "geo" : { },
  "id_str" : "596006012689186816",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU :p http:\/\/t.co\/60NUTpKeMh",
  "id" : 596006012689186816,
  "in_reply_to_status_id" : 595730465706909696,
  "created_at" : "2015-05-06 17:38:01 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595955807080034304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222637999998, 8.627554699999996 ]
  },
  "id_str" : "595962968904458241",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer the comments! \u00BBeverybody should absolutely paraphrase Dobzhansky to make the point that their research is highly relevant.\u00BB :D",
  "id" : 595962968904458241,
  "in_reply_to_status_id" : 595955807080034304,
  "created_at" : "2015-05-06 14:46:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/SvVIrD7omz",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/05\/05\/crowdfunding-medical-mdma-and.html",
      "display_url" : "boingboing.net\/2015\/05\/05\/cro\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222637999998, 8.627554699999996 ]
  },
  "id_str" : "595907524693458944",
  "text" : "Crowdfunding medical MDMA and magic\u00A0mushrooms http:\/\/t.co\/SvVIrD7omz",
  "id" : 595907524693458944,
  "created_at" : "2015-05-06 11:06:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 0, 8 ],
      "id_str" : "114220397",
      "id" : 114220397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595881510915411968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18234376147019, 8.622526541945211 ]
  },
  "id_str" : "595883106550358016",
  "in_reply_to_user_id" : 114220397,
  "text" : "@branleb da will man ihm ja gleich helfen\u2026",
  "id" : 595883106550358016,
  "in_reply_to_status_id" : 595881510915411968,
  "created_at" : "2015-05-06 09:29:38 +0000",
  "in_reply_to_screen_name" : "branleb",
  "in_reply_to_user_id_str" : "114220397",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 0, 8 ],
      "id_str" : "114220397",
      "id" : 114220397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595880411395465216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16423891344966, 8.63154974687168 ]
  },
  "id_str" : "595880634301685760",
  "in_reply_to_user_id" : 114220397,
  "text" : "@branleb yep",
  "id" : 595880634301685760,
  "in_reply_to_status_id" : 595880411395465216,
  "created_at" : "2015-05-06 09:19:48 +0000",
  "in_reply_to_screen_name" : "branleb",
  "in_reply_to_user_id_str" : "114220397",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595878199151702016",
  "text" : "\u00ABIt is not a coincidence that Linus is a nice guy who makes people like him and want to help him.\u00BB lol, from \u2018The Cathedral &amp; the Bazaar\u2019.",
  "id" : 595878199151702016,
  "created_at" : "2015-05-06 09:10:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Goethe-Universit\u00E4t",
      "screen_name" : "goetheuni",
      "indices" : [ 17, 27 ],
      "id_str" : "38180826",
      "id" : 38180826
    }, {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 28, 36 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595864264721735680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222637999998, 8.627554699999996 ]
  },
  "id_str" : "595864837172940801",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @goetheuni @punkish Aye, they give this limitation for Flash, HTML5 &amp; Silverlight formats. QT &amp; MP3 may be saved o_O",
  "id" : 595864837172940801,
  "in_reply_to_status_id" : 595864264721735680,
  "created_at" : "2015-05-06 08:17:02 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Goethe-Universit\u00E4t",
      "screen_name" : "goetheuni",
      "indices" : [ 11, 21 ],
      "id_str" : "38180826",
      "id" : 38180826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595863717654454273",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222637999998, 8.627554699999996 ]
  },
  "id_str" : "595863960789843968",
  "in_reply_to_user_id" : 14286491,
  "text" : "Ernsthaft, @goetheuni? Ich bin mir ziemlich sicher, dass CC auch f\u00FCr die E-Lectures so nicht funktioniert\u2026",
  "id" : 595863960789843968,
  "in_reply_to_status_id" : 595863717654454273,
  "created_at" : "2015-05-06 08:13:33 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222637999998, 8.627554699999996 ]
  },
  "id_str" : "595863717654454273",
  "text" : "\u2018Jede Art von Benutzer-aktivierter Speicherung dieser Inhalte auf ihrem Computer ist ausdr\u00FCcklich untersagt.\u2019 Aber CC BY-NC-ND lizensiert\u2026",
  "id" : 595863717654454273,
  "created_at" : "2015-05-06 08:12:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595840011964145664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222637999998, 8.627554699999996 ]
  },
  "id_str" : "595842579280883712",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson agree, also the ones were oneself profits from doing maintenance.",
  "id" : 595842579280883712,
  "in_reply_to_status_id" : 595840011964145664,
  "created_at" : "2015-05-06 06:48:35 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/d1P0tHPxwv",
      "expanded_url" : "https:\/\/twitter.com\/genetics_blog\/status\/593432807705292800",
      "display_url" : "twitter.com\/genetics_blog\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "595839184423759872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222637999998, 8.627554699999996 ]
  },
  "id_str" : "595839591246143489",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson https:\/\/t.co\/d1P0tHPxwv ;-)",
  "id" : 595839591246143489,
  "in_reply_to_status_id" : 595839184423759872,
  "created_at" : "2015-05-06 06:36:43 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595837858222583811",
  "geo" : { },
  "id_str" : "595838068118134784",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU nah, bin ja selbst ein bisschen guilty as charged. ;-)",
  "id" : 595838068118134784,
  "in_reply_to_status_id" : 595837858222583811,
  "created_at" : "2015-05-06 06:30:40 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595740430970552322",
  "geo" : { },
  "id_str" : "595837621701599232",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson it\u2019s so nice when people finally start using your stuff ;-)",
  "id" : 595837621701599232,
  "in_reply_to_status_id" : 595740430970552322,
  "created_at" : "2015-05-06 06:28:53 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595730465706909696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11092324999998, 8.759631709999997 ]
  },
  "id_str" : "595812088762789890",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU du meinst den RT? ;)",
  "id" : 595812088762789890,
  "in_reply_to_status_id" : 595730465706909696,
  "created_at" : "2015-05-06 04:47:26 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Molly Meade Hall",
      "screen_name" : "StaffingSAS_etc",
      "indices" : [ 3, 19 ],
      "id_str" : "26668905",
      "id" : 26668905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/piF1uWE5Ag",
      "expanded_url" : "http:\/\/www.csnphilly.com\/blog\/700-level\/message-runners-everywhere-shutttttt-uppppppp",
      "display_url" : "csnphilly.com\/blog\/700-level\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595721923079884800",
  "text" : "RT @StaffingSAS_etc: A message to runners everywhere: shutttttt uppppppp http:\/\/t.co\/piF1uWE5Ag",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/piF1uWE5Ag",
        "expanded_url" : "http:\/\/www.csnphilly.com\/blog\/700-level\/message-runners-everywhere-shutttttt-uppppppp",
        "display_url" : "csnphilly.com\/blog\/700-level\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595718081902727168",
    "text" : "A message to runners everywhere: shutttttt uppppppp http:\/\/t.co\/piF1uWE5Ag",
    "id" : 595718081902727168,
    "created_at" : "2015-05-05 22:33:53 +0000",
    "user" : {
      "name" : "Molly Meade Hall",
      "screen_name" : "StaffingSAS_etc",
      "protected" : false,
      "id_str" : "26668905",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2292657238\/togwdys6qxfqa7sc2e32_normal.jpeg",
      "id" : 26668905,
      "verified" : false
    }
  },
  "id" : 595721923079884800,
  "created_at" : "2015-05-05 22:49:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/FzroyPdSQO",
      "expanded_url" : "https:\/\/instagram.com\/p\/2UEDYbBwiU\/",
      "display_url" : "instagram.com\/p\/2UEDYbBwiU\/"
    } ]
  },
  "geo" : { },
  "id_str" : "595685028052480001",
  "text" : "5 minutes to midnight https:\/\/t.co\/FzroyPdSQO",
  "id" : 595685028052480001,
  "created_at" : "2015-05-05 20:22:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595672202676154368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11040088999999, 8.739991819999997 ]
  },
  "id_str" : "595672402949963776",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch no wonder it needs to run idle, to generate the heat for baking!",
  "id" : 595672402949963776,
  "in_reply_to_status_id" : 595672202676154368,
  "created_at" : "2015-05-05 19:32:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595668598980481024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11040088999999, 8.739991819999997 ]
  },
  "id_str" : "595669094411665408",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch btw: still no news re:funds. Keep you posted.",
  "id" : 595669094411665408,
  "in_reply_to_status_id" : 595668598980481024,
  "created_at" : "2015-05-05 19:19:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595665903171276800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11040088999999, 8.739991819999997 ]
  },
  "id_str" : "595666157329321985",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch thx! And the mem usage seems too high to me. What are the processes doing?",
  "id" : 595666157329321985,
  "in_reply_to_status_id" : 595665903171276800,
  "created_at" : "2015-05-05 19:07:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595664119153487874",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11040088999999, 8.739991819999997 ]
  },
  "id_str" : "595664275294822400",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch btw did you see the mail at info@?",
  "id" : 595664275294822400,
  "in_reply_to_status_id" : 595664119153487874,
  "created_at" : "2015-05-05 19:00:04 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/eN8ApFo6VM",
      "expanded_url" : "https:\/\/instagram.com\/p\/2TrJENBwke\/",
      "display_url" : "instagram.com\/p\/2TrJENBwke\/"
    } ]
  },
  "geo" : { },
  "id_str" : "595630248001175553",
  "text" : "alles was ist https:\/\/t.co\/eN8ApFo6VM",
  "id" : 595630248001175553,
  "created_at" : "2015-05-05 16:44:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595628445230616577",
  "geo" : { },
  "id_str" : "595628914254413825",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara guess everyone who ever published with BMC did.",
  "id" : 595628914254413825,
  "in_reply_to_status_id" : 595628445230616577,
  "created_at" : "2015-05-05 16:39:34 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409383164067, 8.75332559362283 ]
  },
  "id_str" : "595622360046264321",
  "text" : "\u00ABWe are delighted to bring you a selection of the latest highly accessed articles from Journal of Foot and Ankle Research.\u00BB Why?!",
  "id" : 595622360046264321,
  "created_at" : "2015-05-05 16:13:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Simpson",
      "screen_name" : "ggsimpsonrna",
      "indices" : [ 3, 16 ],
      "id_str" : "269426340",
      "id" : 269426340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595597906570309632",
  "text" : "RT @ggsimpsonrna: Known locally as \"The Great RNA-Seq Experiment\" - statistical analysis with 48 reps - first paper posted on arXiv http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/tBCmAJH9SQ",
        "expanded_url" : "http:\/\/arxiv.org\/abs\/1505.00588",
        "display_url" : "arxiv.org\/abs\/1505.00588"
      } ]
    },
    "geo" : { },
    "id_str" : "595589044802887680",
    "text" : "Known locally as \"The Great RNA-Seq Experiment\" - statistical analysis with 48 reps - first paper posted on arXiv http:\/\/t.co\/tBCmAJH9SQ",
    "id" : 595589044802887680,
    "created_at" : "2015-05-05 14:01:08 +0000",
    "user" : {
      "name" : "Gordon Simpson",
      "screen_name" : "ggsimpsonrna",
      "protected" : false,
      "id_str" : "269426340",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897016127473291264\/KuZFl6D-_normal.jpg",
      "id" : 269426340,
      "verified" : false
    }
  },
  "id" : 595597906570309632,
  "created_at" : "2015-05-05 14:36:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hakantee",
      "screen_name" : "hakantee",
      "indices" : [ 3, 12 ],
      "id_str" : "4902835689",
      "id" : 4902835689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/UxxZwxOXZU",
      "expanded_url" : "http:\/\/www.theawl.com\/2015\/05\/leaving-new-york-and-also-technology",
      "display_url" : "theawl.com\/2015\/05\/leavin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595591340483813376",
  "text" : "RT @hakantee: \", I realized I had to leave New York and stop using the Internet for a while\" http:\/\/t.co\/UxxZwxOXZU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/UxxZwxOXZU",
        "expanded_url" : "http:\/\/www.theawl.com\/2015\/05\/leaving-new-york-and-also-technology",
        "display_url" : "theawl.com\/2015\/05\/leavin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595580656895270912",
    "text" : "\", I realized I had to leave New York and stop using the Internet for a while\" http:\/\/t.co\/UxxZwxOXZU",
    "id" : 595580656895270912,
    "created_at" : "2015-05-05 13:27:48 +0000",
    "user" : {
      "name" : "hakan",
      "screen_name" : "hatr",
      "protected" : false,
      "id_str" : "48272332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721712668244099073\/k8ZI3LQq_normal.jpg",
      "id" : 48272332,
      "verified" : true
    }
  },
  "id" : 595591340483813376,
  "created_at" : "2015-05-05 14:10:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "indices" : [ 3, 17 ],
      "id_str" : "2315551122",
      "id" : 2315551122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/7AqDcUS1fp",
      "expanded_url" : "http:\/\/wp.me\/p4ik2k-4M",
      "display_url" : "wp.me\/p4ik2k-4M"
    } ]
  },
  "geo" : { },
  "id_str" : "595540713846222848",
  "text" : "RT @TheScienceWeb: Funders to insist that all scientific groups contain at least two men http:\/\/t.co\/7AqDcUS1fp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/7AqDcUS1fp",
        "expanded_url" : "http:\/\/wp.me\/p4ik2k-4M",
        "display_url" : "wp.me\/p4ik2k-4M"
      } ]
    },
    "geo" : { },
    "id_str" : "595509905672544256",
    "text" : "Funders to insist that all scientific groups contain at least two men http:\/\/t.co\/7AqDcUS1fp",
    "id" : 595509905672544256,
    "created_at" : "2015-05-05 08:46:40 +0000",
    "user" : {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "protected" : false,
      "id_str" : "2315551122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428172546672824320\/1lZmC7lz_normal.jpeg",
      "id" : 2315551122,
      "verified" : false
    }
  },
  "id" : 595540713846222848,
  "created_at" : "2015-05-05 10:49:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 3, 17 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/poOiHn7c0Q",
      "expanded_url" : "http:\/\/kuow.org\/post\/why-nasa-called-northwest-indian-college-space-center",
      "display_url" : "kuow.org\/post\/why-nasa-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595490877906223104",
  "text" : "RT @beaugunderson: this is one of the most feel-goodest stories i've read in a while ( \u00B0\u0325\u0325\u0325\u0325\u0325\u0325\u0325\u0325\u25E1\u0350\u00B0\u0325\u0325\u0325\u0325\u0325\u0325\u0325\u0325) http:\/\/t.co\/poOiHn7c0Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/poOiHn7c0Q",
        "expanded_url" : "http:\/\/kuow.org\/post\/why-nasa-called-northwest-indian-college-space-center",
        "display_url" : "kuow.org\/post\/why-nasa-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595448808147853312",
    "text" : "this is one of the most feel-goodest stories i've read in a while ( \u00B0\u0325\u0325\u0325\u0325\u0325\u0325\u0325\u0325\u25E1\u0350\u00B0\u0325\u0325\u0325\u0325\u0325\u0325\u0325\u0325) http:\/\/t.co\/poOiHn7c0Q",
    "id" : 595448808147853312,
    "created_at" : "2015-05-05 04:43:53 +0000",
    "user" : {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "protected" : false,
      "id_str" : "5746882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/913840034016399360\/pU3IIxqf_normal.jpg",
      "id" : 5746882,
      "verified" : false
    }
  },
  "id" : 595490877906223104,
  "created_at" : "2015-05-05 07:31:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/O1KLQq7l30",
      "expanded_url" : "https:\/\/media2.giphy.com\/media\/mfyvkCz5y8G1q\/200.gif",
      "display_url" : "media2.giphy.com\/media\/mfyvkCz5\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "595466622716026880",
  "geo" : { },
  "id_str" : "595489837848895488",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo https:\/\/t.co\/O1KLQq7l30",
  "id" : 595489837848895488,
  "in_reply_to_status_id" : 595466622716026880,
  "created_at" : "2015-05-05 07:26:55 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/QwDXDTtdyG",
      "expanded_url" : "http:\/\/www.radiolab.org\/story\/dont-touch-me-said-canada-i-wont-said-usa-so-they-moved-20-feet-apart\/?utm_source=sharedUrl&utm_media=metatag&utm_campaign=sharedUrl&fb_action_ids=10152317794305660&fb_action_types=og.likes&fb_source=other_multiline&action_object_map=%5B653375744717329%5D&action_type_map=%5B%22og.likes%22%5D&action_ref_map=%5B%5D",
      "display_url" : "radiolab.org\/story\/dont-tou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595489414194843649",
  "text" : "RT @bella_velo: Canada; Don't touch me! America: I won't!! The longest straight(ish) border in the world  http:\/\/t.co\/QwDXDTtdyG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/QwDXDTtdyG",
        "expanded_url" : "http:\/\/www.radiolab.org\/story\/dont-touch-me-said-canada-i-wont-said-usa-so-they-moved-20-feet-apart\/?utm_source=sharedUrl&utm_media=metatag&utm_campaign=sharedUrl&fb_action_ids=10152317794305660&fb_action_types=og.likes&fb_source=other_multiline&action_object_map=%5B653375744717329%5D&action_type_map=%5B%22og.likes%22%5D&action_ref_map=%5B%5D",
        "display_url" : "radiolab.org\/story\/dont-tou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595466622716026880",
    "text" : "Canada; Don't touch me! America: I won't!! The longest straight(ish) border in the world  http:\/\/t.co\/QwDXDTtdyG",
    "id" : 595466622716026880,
    "created_at" : "2015-05-05 05:54:40 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 595489414194843649,
  "created_at" : "2015-05-05 07:25:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Olson",
      "screen_name" : "randal_olson",
      "indices" : [ 3, 16 ],
      "id_str" : "49413866",
      "id" : 49413866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/cUrpnUdjLo",
      "expanded_url" : "http:\/\/touchpianist.com\/",
      "display_url" : "touchpianist.com"
    } ]
  },
  "geo" : { },
  "id_str" : "595477956341956608",
  "text" : "RT @randal_olson: I love how this game makes me feel like an accomplished pianist without all the practicing: http:\/\/t.co\/cUrpnUdjLo http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/randal_olson\/status\/595408130512711680\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/d1GLrhZ5wi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CENQidoUUAMfi6t.png",
        "id_str" : "595408128742543363",
        "id" : 595408128742543363,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CENQidoUUAMfi6t.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 593,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 712,
          "resize" : "fit",
          "w" : 1440
        }, {
          "h" : 712,
          "resize" : "fit",
          "w" : 1440
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/d1GLrhZ5wi"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/cUrpnUdjLo",
        "expanded_url" : "http:\/\/touchpianist.com\/",
        "display_url" : "touchpianist.com"
      } ]
    },
    "geo" : { },
    "id_str" : "595408130512711680",
    "text" : "I love how this game makes me feel like an accomplished pianist without all the practicing: http:\/\/t.co\/cUrpnUdjLo http:\/\/t.co\/d1GLrhZ5wi",
    "id" : 595408130512711680,
    "created_at" : "2015-05-05 02:02:15 +0000",
    "user" : {
      "name" : "Randy Olson",
      "screen_name" : "randal_olson",
      "protected" : false,
      "id_str" : "49413866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770816518988959744\/Ma530Li__normal.jpg",
      "id" : 49413866,
      "verified" : false
    }
  },
  "id" : 595477956341956608,
  "created_at" : "2015-05-05 06:39:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/NsPiRQWe96",
      "expanded_url" : "http:\/\/www.michaeleisen.org\/blog\/?p=1700",
      "display_url" : "michaeleisen.org\/blog\/?p=1700"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409419999916, 8.753324899995132 ]
  },
  "id_str" : "595329350020538368",
  "text" : "\u00ABEnding gender-based harassment in peer review\u00BB http:\/\/t.co\/NsPiRQWe96",
  "id" : 595329350020538368,
  "created_at" : "2015-05-04 20:49:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/N8zoiXx0XZ",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/79",
      "display_url" : "existentialcomics.com\/comic\/79"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.112027, 8.741053 ]
  },
  "id_str" : "595296512411901953",
  "text" : "Learn how to have a god damn authentic experience!  http:\/\/t.co\/N8zoiXx0XZ",
  "id" : 595296512411901953,
  "created_at" : "2015-05-04 18:38:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LZ",
      "screen_name" : "lydia_zv",
      "indices" : [ 3, 12 ],
      "id_str" : "585394581",
      "id" : 585394581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595282662564179968",
  "text" : "RT @lydia_zv: Everyone likes open data, as long as it's someone else's, especially the work.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "595266481987792896",
    "text" : "Everyone likes open data, as long as it's someone else's, especially the work.",
    "id" : 595266481987792896,
    "created_at" : "2015-05-04 16:39:23 +0000",
    "user" : {
      "name" : "LZ",
      "screen_name" : "lydia_zv",
      "protected" : false,
      "id_str" : "585394581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911737293379035137\/VK49eCQm_normal.jpg",
      "id" : 585394581,
      "verified" : false
    }
  },
  "id" : 595282662564179968,
  "created_at" : "2015-05-04 17:43:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Read PhD",
      "screen_name" : "tdread_emory",
      "indices" : [ 3, 16 ],
      "id_str" : "415762872",
      "id" : 415762872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/n4P05IJmmg",
      "expanded_url" : "http:\/\/read-lab-confederation.github.io\/nyc-subway-anthrax-study\/",
      "display_url" : "read-lab-confederation.github.io\/nyc-subway-ant\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595232952101003264",
  "text" : "RT @tdread_emory: Our analysis of B. anthracis in the NYC subway metagenome dats is posted on github. http:\/\/t.co\/n4P05IJmmg http:\/\/t.co\/4l\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tdread_emory\/status\/595232061868396544\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/4lgZT9V8aD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEKwZ_xWgAADRYl.png",
        "id_str" : "595232061427974144",
        "id" : 595232061427974144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEKwZ_xWgAADRYl.png",
        "sizes" : [ {
          "h" : 890,
          "resize" : "fit",
          "w" : 1337
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 890,
          "resize" : "fit",
          "w" : 1337
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/4lgZT9V8aD"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/n4P05IJmmg",
        "expanded_url" : "http:\/\/read-lab-confederation.github.io\/nyc-subway-anthrax-study\/",
        "display_url" : "read-lab-confederation.github.io\/nyc-subway-ant\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595232061868396544",
    "text" : "Our analysis of B. anthracis in the NYC subway metagenome dats is posted on github. http:\/\/t.co\/n4P05IJmmg http:\/\/t.co\/4lgZT9V8aD",
    "id" : 595232061868396544,
    "created_at" : "2015-05-04 14:22:37 +0000",
    "user" : {
      "name" : "Timothy Read PhD",
      "screen_name" : "tdread_emory",
      "protected" : false,
      "id_str" : "415762872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768828282338967552\/pPPssx8v_normal.jpg",
      "id" : 415762872,
      "verified" : false
    }
  },
  "id" : 595232952101003264,
  "created_at" : "2015-05-04 14:26:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595231389089423360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222637999989, 8.627554700000173 ]
  },
  "id_str" : "595232158542880768",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks maybe in 1517 you could get away with 95 theses, today it\u2019s mostly tl;dr.",
  "id" : 595232158542880768,
  "in_reply_to_status_id" : 595231389089423360,
  "created_at" : "2015-05-04 14:23:00 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 3, 15 ],
      "id_str" : "9207632",
      "id" : 9207632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/IujS6v1xYj",
      "expanded_url" : "http:\/\/buff.ly\/1ERqTeZ",
      "display_url" : "buff.ly\/1ERqTeZ"
    } ]
  },
  "geo" : { },
  "id_str" : "595229090250104832",
  "text" : "RT @brainpicker: How to criticize with kindness \u2013 Daniel Dennett on the 4 steps to arguing intelligently http:\/\/t.co\/IujS6v1xYj http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/brainpicker\/status\/595226880925634560\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/4ogLwQE5CY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEKrscpWEAAcvjM.png",
        "id_str" : "595226880858525696",
        "id" : 595226880858525696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEKrscpWEAAcvjM.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 242,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 242,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 242,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 242,
          "resize" : "fit",
          "w" : 468
        } ],
        "display_url" : "pic.twitter.com\/4ogLwQE5CY"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/IujS6v1xYj",
        "expanded_url" : "http:\/\/buff.ly\/1ERqTeZ",
        "display_url" : "buff.ly\/1ERqTeZ"
      } ]
    },
    "geo" : { },
    "id_str" : "595226880925634560",
    "text" : "How to criticize with kindness \u2013 Daniel Dennett on the 4 steps to arguing intelligently http:\/\/t.co\/IujS6v1xYj http:\/\/t.co\/4ogLwQE5CY",
    "id" : 595226880925634560,
    "created_at" : "2015-05-04 14:02:01 +0000",
    "user" : {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "protected" : false,
      "id_str" : "9207632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577255253852065794\/qGnSwsBR_normal.jpg",
      "id" : 9207632,
      "verified" : true
    }
  },
  "id" : 595229090250104832,
  "created_at" : "2015-05-04 14:10:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Worth",
      "screen_name" : "jonworth",
      "indices" : [ 3, 12 ],
      "id_str" : "17442320",
      "id" : 17442320
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 26, 35 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595215485735677952",
  "text" : "RT @jonworth: Go work for @senficon in the EP! Not only are her comms great, but she needs super help taking on copyright lobbies! http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julia Reda",
        "screen_name" : "Senficon",
        "indices" : [ 12, 21 ],
        "id_str" : "14861745",
        "id" : 14861745
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/49Da3FsFgE",
        "expanded_url" : "http:\/\/j.mp\/1DZV13J",
        "display_url" : "j.mp\/1DZV13J"
      } ]
    },
    "geo" : { },
    "id_str" : "595214187510538240",
    "text" : "Go work for @senficon in the EP! Not only are her comms great, but she needs super help taking on copyright lobbies! http:\/\/t.co\/49Da3FsFgE",
    "id" : 595214187510538240,
    "created_at" : "2015-05-04 13:11:35 +0000",
    "user" : {
      "name" : "Jon Worth",
      "screen_name" : "jonworth",
      "protected" : false,
      "id_str" : "17442320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779030529698127872\/S6nkO99n_normal.jpg",
      "id" : 17442320,
      "verified" : true
    }
  },
  "id" : 595215485735677952,
  "created_at" : "2015-05-04 13:16:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/oSBudn5tpO",
      "expanded_url" : "http:\/\/h3kker.github.io\/assemblyTalk\/slides.html#\/71",
      "display_url" : "h3kker.github.io\/assemblyTalk\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222638002929, 8.627554699936496 ]
  },
  "id_str" : "595201154662965248",
  "text" : "\u2018Crashed? \u2713\u2019 This must be one of my favorite slides about de novo assembly. Maybe because it looks my notebook http:\/\/t.co\/oSBudn5tpO",
  "id" : 595201154662965248,
  "created_at" : "2015-05-04 12:19:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595182530665574400",
  "geo" : { },
  "id_str" : "595187708697382912",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I meant the other one. ;)",
  "id" : 595187708697382912,
  "in_reply_to_status_id" : 595182530665574400,
  "created_at" : "2015-05-04 11:26:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595177745245667329",
  "geo" : { },
  "id_str" : "595182119229489152",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw. did you see my email?",
  "id" : 595182119229489152,
  "in_reply_to_status_id" : 595177745245667329,
  "created_at" : "2015-05-04 11:04:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595177745245667329",
  "geo" : { },
  "id_str" : "595177962833629184",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, but it\u2019s still impressive. As the same problem is faced with Illumina only.",
  "id" : 595177962833629184,
  "in_reply_to_status_id" : 595177745245667329,
  "created_at" : "2015-05-04 10:47:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595177339241234432",
  "geo" : { },
  "id_str" : "595177573379878913",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, but it\u2019s the organism most present in the data set, so it\u2019s due to that I\u2019d wager.",
  "id" : 595177573379878913,
  "in_reply_to_status_id" : 595177339241234432,
  "created_at" : "2015-05-04 10:46:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595162309951127553",
  "geo" : { },
  "id_str" : "595164766089388032",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor ein Nebeneffekt des vielen Reisens ;)",
  "id" : 595164766089388032,
  "in_reply_to_status_id" : 595162309951127553,
  "created_at" : "2015-05-04 09:55:12 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222638121064, 8.627554697378171 ]
  },
  "id_str" : "595157311653576704",
  "text" : "My next travel plans are taking shape. In Zurich from 4.\u20137.6., in Leiden from 9.\u201311.6.",
  "id" : 595157311653576704,
  "created_at" : "2015-05-04 09:25:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 3, 15 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hack4Nepal",
      "indices" : [ 17, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/hQuOE9ZxmE",
      "expanded_url" : "https:\/\/geekli.st\/hackathon\/Nepal\/?tab=ideas",
      "display_url" : "geekli.st\/hackathon\/Nepa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595136375571259392",
  "text" : "RT @helgerausch: #Hack4Nepal is collecting ideas on how to help: https:\/\/t.co\/hQuOE9ZxmE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hack4Nepal",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/hQuOE9ZxmE",
        "expanded_url" : "https:\/\/geekli.st\/hackathon\/Nepal\/?tab=ideas",
        "display_url" : "geekli.st\/hackathon\/Nepa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595135390132080640",
    "text" : "#Hack4Nepal is collecting ideas on how to help: https:\/\/t.co\/hQuOE9ZxmE",
    "id" : 595135390132080640,
    "created_at" : "2015-05-04 07:58:28 +0000",
    "user" : {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "protected" : false,
      "id_str" : "52747896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841604882352201729\/O7uP_eHQ_normal.jpg",
      "id" : 52747896,
      "verified" : false
    }
  },
  "id" : 595136375571259392,
  "created_at" : "2015-05-04 08:02:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/pYP7IYSdIE",
      "expanded_url" : "http:\/\/xkcd.com\/1520\/",
      "display_url" : "xkcd.com\/1520\/"
    } ]
  },
  "geo" : { },
  "id_str" : "595122661979791360",
  "text" : "Best use of the Rutherford quote I\u2019ve seen in quite some while! http:\/\/t.co\/pYP7IYSdIE",
  "id" : 595122661979791360,
  "created_at" : "2015-05-04 07:07:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "metro fnord",
      "screen_name" : "linse",
      "indices" : [ 0, 6 ],
      "id_str" : "2206871",
      "id" : 2206871
    }, {
      "name" : "Chaosradio",
      "screen_name" : "chaosradio",
      "indices" : [ 7, 18 ],
      "id_str" : "14257211",
      "id" : 14257211
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 19, 24 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "C. Haupt",
      "screen_name" : "caha42",
      "indices" : [ 25, 32 ],
      "id_str" : "397120166",
      "id" : 397120166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594979111132635138",
  "geo" : { },
  "id_str" : "594979968259641344",
  "in_reply_to_user_id" : 2206871,
  "text" : "@linse @chaosradio @li5a @caha42 Sehr cool. Ich hatte vorher ein bisschen Angst wie zug\u00E4nglich wir es hinbekommen k\u00F6nnen :)",
  "id" : 594979968259641344,
  "in_reply_to_status_id" : 594979111132635138,
  "created_at" : "2015-05-03 21:40:53 +0000",
  "in_reply_to_screen_name" : "linse",
  "in_reply_to_user_id_str" : "2206871",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chaosradio",
      "screen_name" : "chaosradio",
      "indices" : [ 0, 11 ],
      "id_str" : "14257211",
      "id" : 14257211
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 12, 17 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "metro fnord",
      "screen_name" : "linse",
      "indices" : [ 18, 24 ],
      "id_str" : "2206871",
      "id" : 2206871
    }, {
      "name" : "C. Haupt",
      "screen_name" : "caha42",
      "indices" : [ 25, 32 ],
      "id_str" : "397120166",
      "id" : 397120166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594228074209746944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409350864307, 8.75329009941891 ]
  },
  "id_str" : "594974662284697600",
  "in_reply_to_user_id" : 14257211,
  "text" : "@chaosradio @li5a @linse @caha42 Meine Eltern haben mir gemailt das sie nach dem anh\u00F6ren der Sendung endlich \u00B1 verstehen was ich tue. ;-)",
  "id" : 594974662284697600,
  "in_reply_to_status_id" : 594228074209746944,
  "created_at" : "2015-05-03 21:19:48 +0000",
  "in_reply_to_screen_name" : "chaosradio",
  "in_reply_to_user_id_str" : "14257211",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594819631388479488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409350657159, 8.753289995115939 ]
  },
  "id_str" : "594973972950818817",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you got mail, the awesome results are based largely on the fungus :p",
  "id" : 594973972950818817,
  "in_reply_to_status_id" : 594819631388479488,
  "created_at" : "2015-05-03 21:17:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aatish Bhatia",
      "screen_name" : "aatishb",
      "indices" : [ 3, 11 ],
      "id_str" : "300735398",
      "id" : 300735398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/V3JxLLZA1z",
      "expanded_url" : "http:\/\/www.terryburnham.com\/2015\/04\/a-trick-for-higher-sat-scores.html?m=1",
      "display_url" : "terryburnham.com\/2015\/04\/a-tric\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594947508700315648",
  "text" : "RT @aatishb: \"Beware simple stories.\" Brilliant article debunking a claim popularized by Kahneman &amp; Gladwell http:\/\/t.co\/V3JxLLZA1z Via @se\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sean Carroll",
        "screen_name" : "seanmcarroll",
        "indices" : [ 127, 140 ],
        "id_str" : "21611239",
        "id" : 21611239
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/V3JxLLZA1z",
        "expanded_url" : "http:\/\/www.terryburnham.com\/2015\/04\/a-trick-for-higher-sat-scores.html?m=1",
        "display_url" : "terryburnham.com\/2015\/04\/a-tric\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "594921478270889986",
    "text" : "\"Beware simple stories.\" Brilliant article debunking a claim popularized by Kahneman &amp; Gladwell http:\/\/t.co\/V3JxLLZA1z Via @seanmcarroll",
    "id" : 594921478270889986,
    "created_at" : "2015-05-03 17:48:28 +0000",
    "user" : {
      "name" : "Aatish Bhatia",
      "screen_name" : "aatishb",
      "protected" : false,
      "id_str" : "300735398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000817613002\/3814bf3474aff91370d827c2f4cbdb9b_normal.jpeg",
      "id" : 300735398,
      "verified" : true
    }
  },
  "id" : 594947508700315648,
  "created_at" : "2015-05-03 19:31:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 10, 24 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594943569032417280",
  "geo" : { },
  "id_str" : "594944491863310337",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @beaugunderson in that case you should get it printed on a shirt :p",
  "id" : 594944491863310337,
  "in_reply_to_status_id" : 594943569032417280,
  "created_at" : "2015-05-03 19:19:55 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/brbZLmgiC7",
      "expanded_url" : "https:\/\/instagram.com\/p\/2Ov_y9Bwo6\/",
      "display_url" : "instagram.com\/p\/2Ov_y9Bwo6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "594937236841484289",
  "text" : "Arcology-spotting https:\/\/t.co\/brbZLmgiC7",
  "id" : 594937236841484289,
  "created_at" : "2015-05-03 18:51:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 0, 5 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/fXdos4P9qF",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=JE1fzk-4TJk",
      "display_url" : "youtube.com\/watch?v=JE1fzk\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "594916181720567808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409352219524, 8.753290781477155 ]
  },
  "id_str" : "594917972130562048",
  "in_reply_to_user_id" : 1147751,
  "text" : "@johl i\u2019ve heard it both ways! https:\/\/t.co\/fXdos4P9qF",
  "id" : 594917972130562048,
  "in_reply_to_status_id" : 594916181720567808,
  "created_at" : "2015-05-03 17:34:32 +0000",
  "in_reply_to_screen_name" : "johl",
  "in_reply_to_user_id_str" : "1147751",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Spear",
      "screen_name" : "mikesgene",
      "indices" : [ 3, 13 ],
      "id_str" : "13395272",
      "id" : 13395272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/MmA3N6ixG1",
      "expanded_url" : "http:\/\/bits.blogs.nytimes.com\/2015\/05\/01\/the-rise-of-emoji-on-instagram-is-causing-language-repercussions\/?partner=msft_msn?a=1&m=en-us",
      "display_url" : "bits.blogs.nytimes.com\/2015\/05\/01\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594900845885595648",
  "text" : "RT @mikesgene: Emoji killing internet slang. Real language dying compleltely,I guess. http:\/\/t.co\/MmA3N6ixG1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/windows.microsoft.com\/\" rel=\"nofollow\"\u003EWindows 8\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/MmA3N6ixG1",
        "expanded_url" : "http:\/\/bits.blogs.nytimes.com\/2015\/05\/01\/the-rise-of-emoji-on-instagram-is-causing-language-repercussions\/?partner=msft_msn?a=1&m=en-us",
        "display_url" : "bits.blogs.nytimes.com\/2015\/05\/01\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "594896102718971904",
    "text" : "Emoji killing internet slang. Real language dying compleltely,I guess. http:\/\/t.co\/MmA3N6ixG1",
    "id" : 594896102718971904,
    "created_at" : "2015-05-03 16:07:38 +0000",
    "user" : {
      "name" : "Mike Spear",
      "screen_name" : "mikesgene",
      "protected" : false,
      "id_str" : "13395272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543069730249011200\/xHhZnJGZ_normal.jpeg",
      "id" : 13395272,
      "verified" : false
    }
  },
  "id" : 594900845885595648,
  "created_at" : "2015-05-03 16:26:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chaosradio",
      "screen_name" : "chaosradio",
      "indices" : [ 0, 11 ],
      "id_str" : "14257211",
      "id" : 14257211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594898725765545987",
  "geo" : { },
  "id_str" : "594898891612491776",
  "in_reply_to_user_id" : 14257211,
  "text" : "@chaosradio danke!",
  "id" : 594898891612491776,
  "in_reply_to_status_id" : 594898725765545987,
  "created_at" : "2015-05-03 16:18:43 +0000",
  "in_reply_to_screen_name" : "chaosradio",
  "in_reply_to_user_id_str" : "14257211",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/594890161105829889\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/h45AkLPc8v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEF5crtWEAApfaV.jpg",
      "id_str" : "594890159465828352",
      "id" : 594890159465828352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEF5crtWEAApfaV.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/h45AkLPc8v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594890161105829889",
  "text" : "Advice, Offenbach-style: love each other. http:\/\/t.co\/h45AkLPc8v",
  "id" : 594890161105829889,
  "created_at" : "2015-05-03 15:44:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alejandro Montenegro",
      "screen_name" : "aemonten",
      "indices" : [ 3, 12 ],
      "id_str" : "38892114",
      "id" : 38892114
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "plosbuzzfeed",
      "indices" : [ 59, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594889083488497665",
  "text" : "RT @aemonten: Ten simple rules for having a male co-author #plosbuzzfeed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "plosbuzzfeed",
        "indices" : [ 45, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594886785106337792",
    "text" : "Ten simple rules for having a male co-author #plosbuzzfeed",
    "id" : 594886785106337792,
    "created_at" : "2015-05-03 15:30:36 +0000",
    "user" : {
      "name" : "Alejandro Montenegro",
      "screen_name" : "aemonten",
      "protected" : false,
      "id_str" : "38892114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569914366330298368\/1jntJYRU_normal.jpeg",
      "id" : 38892114,
      "verified" : false
    }
  },
  "id" : 594889083488497665,
  "created_at" : "2015-05-03 15:39:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594821066058551296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409359574836, 8.75329448339318 ]
  },
  "id_str" : "594822023886544897",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that\u2019s the most fun part: 10x increase is with error correction in FALCON, using only PB reads.",
  "id" : 594822023886544897,
  "in_reply_to_status_id" : 594821066058551296,
  "created_at" : "2015-05-03 11:13:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594819631388479488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409339179855, 8.753290616822675 ]
  },
  "id_str" : "594820327714254849",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer but definitely still room for improvement. So far I worked on 50% of the total PacBio data we plan to generate.",
  "id" : 594820327714254849,
  "in_reply_to_status_id" : 594819631388479488,
  "created_at" : "2015-05-03 11:06:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594819631388479488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409339179855, 8.753290616822675 ]
  },
  "id_str" : "594820101834158080",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nah, higher, how high exactly I don\u2019t now atm as it\u2019s a meta genome, so total len is unknown.",
  "id" : 594820101834158080,
  "in_reply_to_status_id" : 594819631388479488,
  "created_at" : "2015-05-03 11:05:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594819056630407168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409339179855, 8.753290616822675 ]
  },
  "id_str" : "594819290924187648",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, and that\u2019s comparing PacBio contig N50 to Illumina scaffold N50 :D",
  "id" : 594819290924187648,
  "in_reply_to_status_id" : 594819056630407168,
  "created_at" : "2015-05-03 11:02:24 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594816175986585600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409408792498, 8.753290416197663 ]
  },
  "id_str" : "594818642950381568",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer to high coverage Illumina data with 1 MP + 1 regular MiSeq lib.",
  "id" : 594818642950381568,
  "in_reply_to_status_id" : 594816175986585600,
  "created_at" : "2015-05-03 10:59:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594816175986585600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409408792498, 8.753290416197663 ]
  },
  "id_str" : "594818465824911360",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer wow, I hadn\u2019t. That\u2019s awesome. Already ran FALCON on my own (low coverage) data. Still improved N50 by factor of 10, compared\u2026",
  "id" : 594818465824911360,
  "in_reply_to_status_id" : 594816175986585600,
  "created_at" : "2015-05-03 10:59:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594800305650405376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409368883876, 8.753299168572319 ]
  },
  "id_str" : "594800782697963520",
  "in_reply_to_user_id" : 14286491,
  "text" : "no surprise there: \u00AB[\u2026] a disconnect between the views of those handling the findings of research and those participating in research.\u00BB",
  "id" : 594800782697963520,
  "in_reply_to_status_id" : 594800305650405376,
  "created_at" : "2015-05-03 09:48:52 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/SseUNYovbl",
      "expanded_url" : "http:\/\/www.nature.com\/ejhg\/journal\/vaop\/ncurrent\/full\/ejhg201558a.html",
      "display_url" : "nature.com\/ejhg\/journal\/v\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409368883876, 8.753299168572319 ]
  },
  "id_str" : "594800305650405376",
  "text" : "Attitudes of health professionals, genomic researchers &amp; publics toward the return of incidental findings http:\/\/t.co\/SseUNYovbl",
  "id" : 594800305650405376,
  "created_at" : "2015-05-03 09:46:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/fi0YxmyHBi",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/technology\/future_tense\/2015\/04\/the_dangers_of_letting_algorithms_enforce_policy.html?wpsrc=sh_all_tab_tw_top",
      "display_url" : "slate.com\/articles\/techn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594797026929418240",
  "text" : "RT @EffyVayena: The dangers of letting algorithms make decisions about law enforcement, welfare, and other policies: http:\/\/t.co\/fi0YxmyHBi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Slate",
        "screen_name" : "Slate",
        "indices" : [ 128, 134 ],
        "id_str" : "15164565",
        "id" : 15164565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/fi0YxmyHBi",
        "expanded_url" : "http:\/\/www.slate.com\/articles\/technology\/future_tense\/2015\/04\/the_dangers_of_letting_algorithms_enforce_policy.html?wpsrc=sh_all_tab_tw_top",
        "display_url" : "slate.com\/articles\/techn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "594795534344421376",
    "text" : "The dangers of letting algorithms make decisions about law enforcement, welfare, and other policies: http:\/\/t.co\/fi0YxmyHBi via @slate",
    "id" : 594795534344421376,
    "created_at" : "2015-05-03 09:28:00 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 594797026929418240,
  "created_at" : "2015-05-03 09:33:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "michael_nielsen",
      "screen_name" : "michael_nielsen",
      "indices" : [ 17, 33 ],
      "id_str" : "15626406",
      "id" : 15626406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594795828780367872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409344377412, 8.753286834121377 ]
  },
  "id_str" : "594796766714798080",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @michael_nielsen I already switched to e-\u2018only\u2019 (&gt;95% ebooks I guess). And goodreads works really well for me.",
  "id" : 594796766714798080,
  "in_reply_to_status_id" : 594795828780367872,
  "created_at" : "2015-05-03 09:32:54 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "witch@serenity",
      "screen_name" : "_MinaHarker_",
      "indices" : [ 0, 13 ],
      "id_str" : "1068997124",
      "id" : 1068997124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594794720762683392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409344377412, 8.753286834121377 ]
  },
  "id_str" : "594796131151966208",
  "in_reply_to_user_id" : 1068997124,
  "text" : "@_MinaHarker_ sounds exciting but also like it\u2019s at a very early stage ;)",
  "id" : 594796131151966208,
  "in_reply_to_status_id" : 594794720762683392,
  "created_at" : "2015-05-03 09:30:23 +0000",
  "in_reply_to_screen_name" : "_MinaHarker_",
  "in_reply_to_user_id_str" : "1068997124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "michael_nielsen",
      "screen_name" : "michael_nielsen",
      "indices" : [ 17, 33 ],
      "id_str" : "15626406",
      "id" : 15626406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/7Dn1QrMJjC",
      "expanded_url" : "https:\/\/www.goodreads.com\/api",
      "display_url" : "goodreads.com\/api"
    } ]
  },
  "in_reply_to_status_id_str" : "594794631319166976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409351599399, 8.753290489228908 ]
  },
  "id_str" : "594795589411405824",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @michael_nielsen +1 for that, goodreads even has an API for such things. https:\/\/t.co\/7Dn1QrMJjC",
  "id" : 594795589411405824,
  "in_reply_to_status_id" : 594794631319166976,
  "created_at" : "2015-05-03 09:28:13 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Hughes",
      "screen_name" : "virginiahughes",
      "indices" : [ 3, 18 ],
      "id_str" : "17042078",
      "id" : 17042078
    }, {
      "name" : "cat ferguson",
      "screen_name" : "biocuriosity",
      "indices" : [ 81, 94 ],
      "id_str" : "238033596",
      "id" : 238033596
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AddMaleAuthorGate",
      "indices" : [ 95, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/0j7789coQh",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/catferguson\/women-scientists-share-their-stories-of-sexism-in-publishing",
      "display_url" : "buzzfeed.com\/catferguson\/wo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594793966693941249",
  "text" : "RT @virginiahughes: Women Scientists Share Their Stories Of Sexism In Publishing @biocuriosity #AddMaleAuthorGate http:\/\/t.co\/0j7789coQh ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "cat ferguson",
        "screen_name" : "biocuriosity",
        "indices" : [ 61, 74 ],
        "id_str" : "238033596",
        "id" : 238033596
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/virginiahughes\/status\/594343002153193472\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/ZdqiCCTx0q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD-HxkFUMAAaaAb.jpg",
        "id_str" : "594342961405505536",
        "id" : 594342961405505536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD-HxkFUMAAaaAb.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/ZdqiCCTx0q"
      } ],
      "hashtags" : [ {
        "text" : "AddMaleAuthorGate",
        "indices" : [ 75, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/0j7789coQh",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/catferguson\/women-scientists-share-their-stories-of-sexism-in-publishing",
        "display_url" : "buzzfeed.com\/catferguson\/wo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "594488538818867200",
    "text" : "Women Scientists Share Their Stories Of Sexism In Publishing @biocuriosity #AddMaleAuthorGate http:\/\/t.co\/0j7789coQh http:\/\/t.co\/ZdqiCCTx0q",
    "id" : 594488538818867200,
    "created_at" : "2015-05-02 13:08:07 +0000",
    "user" : {
      "name" : "Virginia Hughes",
      "screen_name" : "virginiahughes",
      "protected" : false,
      "id_str" : "17042078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554066251845083137\/ERzrr-4S_normal.jpeg",
      "id" : 17042078,
      "verified" : true
    }
  },
  "id" : 594793966693941249,
  "created_at" : "2015-05-03 09:21:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 95, 108 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/wKK1DfytY8",
      "expanded_url" : "http:\/\/www.biomedcentral.com\/1471-2105\/16\/S7\/S5",
      "display_url" : "biomedcentral.com\/1471-2105\/16\/S\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409349360246, 8.753289373588455 ]
  },
  "id_str" : "594793069276442624",
  "text" : "Interesting: Heterozygous genome assembly via binary classification of homologous sequence \/cc @PhilippBayer http:\/\/t.co\/wKK1DfytY8",
  "id" : 594793069276442624,
  "created_at" : "2015-05-03 09:18:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Keating",
      "screen_name" : "stevenkeating",
      "indices" : [ 67, 81 ],
      "id_str" : "19216179",
      "id" : 19216179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/gbhfxGa3gB",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/5\/2\/8532381\/steven-keating",
      "display_url" : "vox.com\/2015\/5\/2\/85323\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594779597167820800",
  "text" : "\u00ABMeet the MIT student who filmed his own brain surgery\u00BB well done, @stevenkeating! http:\/\/t.co\/gbhfxGa3gB",
  "id" : 594779597167820800,
  "created_at" : "2015-05-03 08:24:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WWRD",
      "screen_name" : "5lawslib",
      "indices" : [ 3, 12 ],
      "id_str" : "1163679896",
      "id" : 1163679896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/B4OPJxCSU5",
      "expanded_url" : "http:\/\/bitly.com\/1OrYxJl",
      "display_url" : "bitly.com\/1OrYxJl"
    } ]
  },
  "geo" : { },
  "id_str" : "594759739969527808",
  "text" : "RT @5lawslib: The Open Publishing Revolution, Now Behind A Billion-Dollar Paywall [Mendeley's travails] http:\/\/t.co\/B4OPJxCSU5 http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/5lawslib\/status\/594642281182961664\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/0UaZOAakOe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CECYAQgXIAAQ_0X.png",
        "id_str" : "594642281011027968",
        "id" : 594642281011027968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CECYAQgXIAAQ_0X.png",
        "sizes" : [ {
          "h" : 408,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/0UaZOAakOe"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/B4OPJxCSU5",
        "expanded_url" : "http:\/\/bitly.com\/1OrYxJl",
        "display_url" : "bitly.com\/1OrYxJl"
      } ]
    },
    "geo" : { },
    "id_str" : "594642281182961664",
    "text" : "The Open Publishing Revolution, Now Behind A Billion-Dollar Paywall [Mendeley's travails] http:\/\/t.co\/B4OPJxCSU5 http:\/\/t.co\/0UaZOAakOe",
    "id" : 594642281182961664,
    "created_at" : "2015-05-02 23:19:02 +0000",
    "user" : {
      "name" : "WWRD",
      "screen_name" : "5lawslib",
      "protected" : false,
      "id_str" : "1163679896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3230393922\/fe95678c234d841f7d547e9ea29877d4_normal.jpeg",
      "id" : 1163679896,
      "verified" : false
    }
  },
  "id" : 594759739969527808,
  "created_at" : "2015-05-03 07:05:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/0opKkPj6P5",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=itAOGRiYRLI",
      "display_url" : "m.youtube.com\/watch?v=itAOGR\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "594600760937164801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11536409781645, 8.75038010885269 ]
  },
  "id_str" : "594601078232117252",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ausnahmsweise nicht, sondern dies war tats\u00E4chlich gemeint. https:\/\/t.co\/0opKkPj6P5",
  "id" : 594601078232117252,
  "in_reply_to_status_id" : 594600760937164801,
  "created_at" : "2015-05-02 20:35:18 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594599594572566528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11416500166036, 8.753145760639976 ]
  },
  "id_str" : "594600054733840385",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich \uD83C\uDFAF",
  "id" : 594600054733840385,
  "in_reply_to_status_id" : 594599594572566528,
  "created_at" : "2015-05-02 20:31:14 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594597070419419138",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409602812968, 8.75330376388653 ]
  },
  "id_str" : "594598065081864192",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich leider gibt es kein Drumroll-Emoji. ;)",
  "id" : 594598065081864192,
  "in_reply_to_status_id" : 594597070419419138,
  "created_at" : "2015-05-02 20:23:20 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack A Gilbert",
      "screen_name" : "gilbertjacka",
      "indices" : [ 3, 16 ],
      "id_str" : "223529798",
      "id" : 223529798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/apHYFmvCdq",
      "expanded_url" : "http:\/\/wpo.st\/TgSF0",
      "display_url" : "wpo.st\/TgSF0"
    } ]
  },
  "geo" : { },
  "id_str" : "594590467326607360",
  "text" : "RT @gilbertjacka: How Western media would cover Baltimore if it happened elsewhere http:\/\/t.co\/apHYFmvCdq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/apHYFmvCdq",
        "expanded_url" : "http:\/\/wpo.st\/TgSF0",
        "display_url" : "wpo.st\/TgSF0"
      } ]
    },
    "geo" : { },
    "id_str" : "594588050086232064",
    "text" : "How Western media would cover Baltimore if it happened elsewhere http:\/\/t.co\/apHYFmvCdq",
    "id" : 594588050086232064,
    "created_at" : "2015-05-02 19:43:32 +0000",
    "user" : {
      "name" : "Jack A Gilbert",
      "screen_name" : "gilbertjacka",
      "protected" : false,
      "id_str" : "223529798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2330006367\/image_normal.jpg",
      "id" : 223529798,
      "verified" : false
    }
  },
  "id" : 594590467326607360,
  "created_at" : "2015-05-02 19:53:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily [redacted] Willingham\uD83C\uDFC1",
      "screen_name" : "ejwillingham",
      "indices" : [ 0, 13 ],
      "id_str" : "77907514",
      "id" : 77907514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594587408827428865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404844829756, 8.753355465537044 ]
  },
  "id_str" : "594588335995232258",
  "in_reply_to_user_id" : 77907514,
  "text" : "@ejwillingham yes, feels like a good equivalent. :)",
  "id" : 594588335995232258,
  "in_reply_to_status_id" : 594587408827428865,
  "created_at" : "2015-05-02 19:44:40 +0000",
  "in_reply_to_screen_name" : "ejwillingham",
  "in_reply_to_user_id_str" : "77907514",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594580326858563585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409343667444, 8.753290690270411 ]
  },
  "id_str" : "594583879824060416",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich \uD83D\uDC68\u200D\u2764\uFE0F\u200D\uD83D\uDC8B\u200D\uD83D\uDC68",
  "id" : 594583879824060416,
  "in_reply_to_status_id" : 594580326858563585,
  "created_at" : "2015-05-02 19:26:58 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594563155994488832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400506819294, 8.753495927373645 ]
  },
  "id_str" : "594574265091039232",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich machen wir es uns gegenseitig? :p",
  "id" : 594574265091039232,
  "in_reply_to_status_id" : 594563155994488832,
  "created_at" : "2015-05-02 18:48:46 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594561540843536385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409309501573, 8.753292945581093 ]
  },
  "id_str" : "594561757483524096",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen sounds great as well!",
  "id" : 594561757483524096,
  "in_reply_to_status_id" : 594561540843536385,
  "created_at" : "2015-05-02 17:59:04 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594560856526041088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409309501573, 8.753292945581093 ]
  },
  "id_str" : "594561522535378944",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ich lieb\u00E4ugle gerade mehr mit 1x komplett entfernen. :3",
  "id" : 594561522535378944,
  "in_reply_to_status_id" : 594560856526041088,
  "created_at" : "2015-05-02 17:58:08 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/594560349178826752\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/Nv41btESr3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEBNfGdWoAIb9dW.jpg",
      "id_str" : "594560347517919234",
      "id" : 594560347517919234,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEBNfGdWoAIb9dW.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/Nv41btESr3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594558100025253888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409420002508, 8.753292495319847 ]
  },
  "id_str" : "594560349178826752",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich auf bestem Weg dahin zumindest. http:\/\/t.co\/Nv41btESr3",
  "id" : 594560349178826752,
  "in_reply_to_status_id" : 594558100025253888,
  "created_at" : "2015-05-02 17:53:28 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409420002508, 8.753292495319847 ]
  },
  "id_str" : "594559958059986945",
  "text" : "poor man\u2019s fusion kitchen: tortilla chips with hummus.",
  "id" : 594559958059986945,
  "created_at" : "2015-05-02 17:51:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594556952052633600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409287705303, 8.753293184683926 ]
  },
  "id_str" : "594557858353643521",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich jetzt bin ich fast versucht doch wieder zu f\u00E4rben ;)",
  "id" : 594557858353643521,
  "in_reply_to_status_id" : 594556952052633600,
  "created_at" : "2015-05-02 17:43:34 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594556474996690946",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409231173155, 8.753294747074312 ]
  },
  "id_str" : "594556779842908160",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich du bekommst gern mal eine Privatvorlesung. Daf\u00FCr Wisch ich sogar das Whiteboard ;)",
  "id" : 594556779842908160,
  "in_reply_to_status_id" : 594556474996690946,
  "created_at" : "2015-05-02 17:39:17 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409390717319, 8.753292649977546 ]
  },
  "id_str" : "594556328493903872",
  "text" : "Motto of the Day: \u00AB50 Shades of Crazy, Offenbach-Edition.\u00BB",
  "id" : 594556328493903872,
  "created_at" : "2015-05-02 17:37:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594552597983469568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409390717319, 8.753292649977546 ]
  },
  "id_str" : "594555913954004992",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ich bin auf dein Feedback gespannt. :)",
  "id" : 594555913954004992,
  "in_reply_to_status_id" : 594552597983469568,
  "created_at" : "2015-05-02 17:35:50 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/594542858906030080\/photo\/1",
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/iAIwxN5VIA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEA9lH_XIAA8idL.jpg",
      "id_str" : "594542858822164480",
      "id" : 594542858822164480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEA9lH_XIAA8idL.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/iAIwxN5VIA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594542858906030080",
  "text" : "T\u00FC\u00FC\u00FCt! http:\/\/t.co\/iAIwxN5VIA",
  "id" : 594542858906030080,
  "created_at" : "2015-05-02 16:43:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594534274465947649",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10594654311419, 8.752096501851508 ]
  },
  "id_str" : "594535614042767360",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng @Senficon &lt;3",
  "id" : 594535614042767360,
  "in_reply_to_status_id" : 594534274465947649,
  "created_at" : "2015-05-02 16:15:10 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/eJJbuWp9nJ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=dgit_DQHbJ8",
      "display_url" : "youtube.com\/watch?v=dgit_D\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409348326769, 8.753289596779178 ]
  },
  "id_str" : "594280162155438081",
  "text" : "How did I miss out on these guys until now?! https:\/\/t.co\/eJJbuWp9nJ",
  "id" : 594280162155438081,
  "created_at" : "2015-05-01 23:20:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chaosradio",
      "screen_name" : "chaosradio",
      "indices" : [ 0, 11 ],
      "id_str" : "14257211",
      "id" : 14257211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594228074209746944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409347684098, 8.753289735444092 ]
  },
  "id_str" : "594276131991355392",
  "in_reply_to_user_id" : 14257211,
  "text" : "@chaosradio d\u00FCrft mich \u00FCbrigens auch gern in den shownotes hierher verlinken :-)",
  "id" : 594276131991355392,
  "in_reply_to_status_id" : 594228074209746944,
  "created_at" : "2015-05-01 23:04:05 +0000",
  "in_reply_to_screen_name" : "chaosradio",
  "in_reply_to_user_id_str" : "14257211",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Ancestry",
      "screen_name" : "Ancestry",
      "indices" : [ 51, 60 ],
      "id_str" : "16754078",
      "id" : 16754078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/nE4U4GmU19",
      "expanded_url" : "https:\/\/www.eff.org\/deeplinks\/2015\/05\/how-private-dna-data-led-idaho-cops-wild-goose-chase-and-linked-innocent-man-20",
      "display_url" : "eff.org\/deeplinks\/2015\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594275531010535425",
  "text" : "RT @wilbanks: At this point why would anyone trust @ancestry with their genetic information\u2026or anything else?  https:\/\/t.co\/nE4U4GmU19",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ancestry",
        "screen_name" : "Ancestry",
        "indices" : [ 37, 46 ],
        "id_str" : "16754078",
        "id" : 16754078
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/nE4U4GmU19",
        "expanded_url" : "https:\/\/www.eff.org\/deeplinks\/2015\/05\/how-private-dna-data-led-idaho-cops-wild-goose-chase-and-linked-innocent-man-20",
        "display_url" : "eff.org\/deeplinks\/2015\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "594219868712341505",
    "text" : "At this point why would anyone trust @ancestry with their genetic information\u2026or anything else?  https:\/\/t.co\/nE4U4GmU19",
    "id" : 594219868712341505,
    "created_at" : "2015-05-01 19:20:31 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 594275531010535425,
  "created_at" : "2015-05-01 23:01:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/USi5VjOuAq",
      "expanded_url" : "https:\/\/medium.com\/sf-popos\/the-21-secret-parks-of-san-francisco-192e6d88ea0a",
      "display_url" : "medium.com\/sf-popos\/the-2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409346441287, 8.753289824329244 ]
  },
  "id_str" : "594273018605613056",
  "text" : "The 21 Secret Parks of San Francisco https:\/\/t.co\/USi5VjOuAq",
  "id" : 594273018605613056,
  "created_at" : "2015-05-01 22:51:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chaosradio",
      "screen_name" : "chaosradio",
      "indices" : [ 3, 14 ],
      "id_str" : "14257211",
      "id" : 14257211
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 70, 75 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "metro fnord",
      "screen_name" : "linse",
      "indices" : [ 77, 83 ],
      "id_str" : "2206871",
      "id" : 2206871
    }, {
      "name" : "C. Haupt",
      "screen_name" : "caha42",
      "indices" : [ 85, 92 ],
      "id_str" : "397120166",
      "id" : 397120166
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 97, 113 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CR211",
      "indices" : [ 117, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594228657222221825",
  "text" : "RT @chaosradio: Was hat Bioinformatik mit Viagra zu tun? Das erz\u00E4hlen @li5a, @linse, @caha42 und @gedankenstuecke im #CR211. http:\/\/t.co\/MH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "li5a",
        "screen_name" : "li5a",
        "indices" : [ 54, 59 ],
        "id_str" : "11712822",
        "id" : 11712822
      }, {
        "name" : "metro fnord",
        "screen_name" : "linse",
        "indices" : [ 61, 67 ],
        "id_str" : "2206871",
        "id" : 2206871
      }, {
        "name" : "C. Haupt",
        "screen_name" : "caha42",
        "indices" : [ 69, 76 ],
        "id_str" : "397120166",
        "id" : 397120166
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 81, 97 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CR211",
        "indices" : [ 101, 107 ]
      }, {
        "text" : "podcast",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/MHY7VpCXN0",
        "expanded_url" : "http:\/\/chaosradio.ccc.de\/cr211.html",
        "display_url" : "chaosradio.ccc.de\/cr211.html"
      } ]
    },
    "geo" : { },
    "id_str" : "594228074209746944",
    "text" : "Was hat Bioinformatik mit Viagra zu tun? Das erz\u00E4hlen @li5a, @linse, @caha42 und @gedankenstuecke im #CR211. http:\/\/t.co\/MHY7VpCXN0 #podcast",
    "id" : 594228074209746944,
    "created_at" : "2015-05-01 19:53:07 +0000",
    "user" : {
      "name" : "Chaosradio",
      "screen_name" : "chaosradio",
      "protected" : false,
      "id_str" : "14257211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/52233040\/chaosradio-icon-300_normal.jpg",
      "id" : 14257211,
      "verified" : false
    }
  },
  "id" : 594228657222221825,
  "created_at" : "2015-05-01 19:55:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17710288379624, 8.40448061632803 ]
  },
  "id_str" : "594170339237744641",
  "text" : "\u00ABApropos! Wo ist mein Weltraumaufzug?! Ich muss immer noch mit dem Auto zur Arbeit fahren wie so ein Tier!\u00BB",
  "id" : 594170339237744641,
  "created_at" : "2015-05-01 16:03:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 3, 17 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/NMSe1qar0M",
      "expanded_url" : "https:\/\/twitter.com\/Kurt_Vonnegut\/status\/593324617252483072",
      "display_url" : "twitter.com\/Kurt_Vonnegut\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594114621591650304",
  "text" : "RT @genetics_blog: In which Vonnegut comments on bioinformatics software  https:\/\/t.co\/NMSe1qar0M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/NMSe1qar0M",
        "expanded_url" : "https:\/\/twitter.com\/Kurt_Vonnegut\/status\/593324617252483072",
        "display_url" : "twitter.com\/Kurt_Vonnegut\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "593432807705292800",
    "text" : "In which Vonnegut comments on bioinformatics software  https:\/\/t.co\/NMSe1qar0M",
    "id" : 593432807705292800,
    "created_at" : "2015-04-29 15:13:01 +0000",
    "user" : {
      "name" : "Stephen Turner",
      "screen_name" : "strnr",
      "protected" : false,
      "id_str" : "20444825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660439762856230913\/ARYE5YB6_normal.jpg",
      "id" : 20444825,
      "verified" : false
    }
  },
  "id" : 594114621591650304,
  "created_at" : "2015-05-01 12:22:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/TanUqhKhJd",
      "expanded_url" : "https:\/\/instagram.com\/p\/2IykH6hwqk\/",
      "display_url" : "instagram.com\/p\/2IykH6hwqk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "594098459705217024",
  "text" : "Microbe-powered https:\/\/t.co\/TanUqhKhJd",
  "id" : 594098459705217024,
  "created_at" : "2015-05-01 11:18:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Cockell",
      "screen_name" : "sjcockell",
      "indices" : [ 3, 13 ],
      "id_str" : "15084702",
      "id" : 15084702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/z8gUDGBdsQ",
      "expanded_url" : "http:\/\/wp.me\/p1a4Ef-4L0",
      "display_url" : "wp.me\/p1a4Ef-4L0"
    } ]
  },
  "geo" : { },
  "id_str" : "594075336498933760",
  "text" : "RT @sjcockell: My response (and addition) to navel-gazing over what a bioinformatician is http:\/\/t.co\/z8gUDGBdsQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/z8gUDGBdsQ",
        "expanded_url" : "http:\/\/wp.me\/p1a4Ef-4L0",
        "display_url" : "wp.me\/p1a4Ef-4L0"
      } ]
    },
    "geo" : { },
    "id_str" : "594068170186498048",
    "text" : "My response (and addition) to navel-gazing over what a bioinformatician is http:\/\/t.co\/z8gUDGBdsQ",
    "id" : 594068170186498048,
    "created_at" : "2015-05-01 09:17:43 +0000",
    "user" : {
      "name" : "Simon Cockell",
      "screen_name" : "sjcockell",
      "protected" : false,
      "id_str" : "15084702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671629143310749696\/6M9y-H4J_normal.png",
      "id" : 15084702,
      "verified" : false
    }
  },
  "id" : 594075336498933760,
  "created_at" : "2015-05-01 09:46:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat McKitten",
      "screen_name" : "yuiofthesun",
      "indices" : [ 3, 15 ],
      "id_str" : "513049579",
      "id" : 513049579
    }, {
      "name" : "Media Diversified",
      "screen_name" : "WritersofColour",
      "indices" : [ 109, 125 ],
      "id_str" : "1561448815",
      "id" : 1561448815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/6ErtkFoydU",
      "expanded_url" : "http:\/\/wp.me\/p3HucV-IYE",
      "display_url" : "wp.me\/p3HucV-IYE"
    } ]
  },
  "geo" : { },
  "id_str" : "594074669109669888",
  "text" : "RT @yuiofthesun: My Middle East: \u2018We should go out there and represent ourselves\u2019 http:\/\/t.co\/6ErtkFoydU via @WritersofColour",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Diversified",
        "screen_name" : "WritersofColour",
        "indices" : [ 92, 108 ],
        "id_str" : "1561448815",
        "id" : 1561448815
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/6ErtkFoydU",
        "expanded_url" : "http:\/\/wp.me\/p3HucV-IYE",
        "display_url" : "wp.me\/p3HucV-IYE"
      } ]
    },
    "geo" : { },
    "id_str" : "594065225420283904",
    "text" : "My Middle East: \u2018We should go out there and represent ourselves\u2019 http:\/\/t.co\/6ErtkFoydU via @WritersofColour",
    "id" : 594065225420283904,
    "created_at" : "2015-05-01 09:06:01 +0000",
    "user" : {
      "name" : "Kat McKitten",
      "screen_name" : "yuiofthesun",
      "protected" : false,
      "id_str" : "513049579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2214229059\/kat_normal.png",
      "id" : 513049579,
      "verified" : false
    }
  },
  "id" : 594074669109669888,
  "created_at" : "2015-05-01 09:43:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 90, 103 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/DpS7TKh2Od",
      "expanded_url" : "https:\/\/www.youtube.com\/playlist?list=PL1B24EADC01219B23",
      "display_url" : "youtube.com\/playlist?list=\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409301757811, 8.753289820422196 ]
  },
  "id_str" : "594025115219795968",
  "text" : "A collection of talks on \u201CHow Language Evolves\u201D from the UCSD Center for Anthropogeny \/cc @PhilippBayer https:\/\/t.co\/DpS7TKh2Od",
  "id" : 594025115219795968,
  "created_at" : "2015-05-01 06:26:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "*shrug*",
      "screen_name" : "jesseract",
      "indices" : [ 3, 13 ],
      "id_str" : "77269856",
      "id" : 77269856
    }, {
      "name" : "Alicia Liu",
      "screen_name" : "aliciatweet",
      "indices" : [ 53, 65 ],
      "id_str" : "38939335",
      "id" : 38939335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/GYgs6Egk5y",
      "expanded_url" : "https:\/\/medium.com\/@aliciatweet\/you-don-t-have-impostor-syndrome-126e4c4bdcc?source=tw-lo_dnt_6590316c15b9-1430445848467",
      "display_url" : "medium.com\/@aliciatweet\/y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594018463628316672",
  "text" : "RT @jesseract: \u201CYou don\u2019t have Impostor Syndrome\u201D by @aliciatweet https:\/\/t.co\/GYgs6Egk5y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alicia Liu",
        "screen_name" : "aliciatweet",
        "indices" : [ 38, 50 ],
        "id_str" : "38939335",
        "id" : 38939335
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/GYgs6Egk5y",
        "expanded_url" : "https:\/\/medium.com\/@aliciatweet\/you-don-t-have-impostor-syndrome-126e4c4bdcc?source=tw-lo_dnt_6590316c15b9-1430445848467",
        "display_url" : "medium.com\/@aliciatweet\/y\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "593959068483616769",
    "text" : "\u201CYou don\u2019t have Impostor Syndrome\u201D by @aliciatweet https:\/\/t.co\/GYgs6Egk5y",
    "id" : 593959068483616769,
    "created_at" : "2015-05-01 02:04:11 +0000",
    "user" : {
      "name" : "*shrug*",
      "screen_name" : "jesseract",
      "protected" : false,
      "id_str" : "77269856",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724792346932563968\/AVYcW3ix_normal.jpg",
      "id" : 77269856,
      "verified" : false
    }
  },
  "id" : 594018463628316672,
  "created_at" : "2015-05-01 06:00:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Haupt",
      "screen_name" : "caha42",
      "indices" : [ 0, 7 ],
      "id_str" : "397120166",
      "id" : 397120166
    }, {
      "name" : "metro fnord",
      "screen_name" : "linse",
      "indices" : [ 8, 14 ],
      "id_str" : "2206871",
      "id" : 2206871
    }, {
      "name" : "Chaosradio",
      "screen_name" : "chaosradio",
      "indices" : [ 15, 26 ],
      "id_str" : "14257211",
      "id" : 14257211
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 27, 32 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593908784210247680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409301757811, 8.75329022362311 ]
  },
  "id_str" : "593908962124259329",
  "in_reply_to_user_id" : 397120166,
  "text" : "@caha42 @linse @chaosradio @li5a ich meinte schon: Zum Gl\u00FCck ist die Bioinformatik ein so weites Feld, da kann man mehr Episoden machen ;)",
  "id" : 593908962124259329,
  "in_reply_to_status_id" : 593908784210247680,
  "created_at" : "2015-04-30 22:45:05 +0000",
  "in_reply_to_screen_name" : "caha42",
  "in_reply_to_user_id_str" : "397120166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593907770988048385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1130549749788, 8.75448409761942 ]
  },
  "id_str" : "593908582946611200",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju \uD83C\uDF89",
  "id" : 593908582946611200,
  "in_reply_to_status_id" : 593907770988048385,
  "created_at" : "2015-04-30 22:43:35 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chaosradio",
      "screen_name" : "chaosradio",
      "indices" : [ 0, 11 ],
      "id_str" : "14257211",
      "id" : 14257211
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 12, 17 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "metro fnord",
      "screen_name" : "linse",
      "indices" : [ 18, 24 ],
      "id_str" : "2206871",
      "id" : 2206871
    }, {
      "name" : "C. Haupt",
      "screen_name" : "caha42",
      "indices" : [ 25, 32 ],
      "id_str" : "397120166",
      "id" : 397120166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593865521554190337",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409301757811, 8.753290562655735 ]
  },
  "id_str" : "593898930473201664",
  "in_reply_to_user_id" : 14257211,
  "text" : "@chaosradio @li5a @linse @caha42 Vielen Dank f\u00FCr die nette Sendung!",
  "id" : 593898930473201664,
  "in_reply_to_status_id" : 593865521554190337,
  "created_at" : "2015-04-30 22:05:13 +0000",
  "in_reply_to_screen_name" : "chaosradio",
  "in_reply_to_user_id_str" : "14257211",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]