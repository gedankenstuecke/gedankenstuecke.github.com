Grailbird.data.tweets_2013_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0070346312, 8.2832121668 ]
  },
  "id_str" : "406825035014627328",
  "text" : "\u00ABI was once a dinosaur. A Stegosaurus, to be exact.\u00BB Awww, I was one as well, back in the days! &lt;3",
  "id" : 406825035014627328,
  "created_at" : "2013-11-30 16:40:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096849467, 8.28300662 ]
  },
  "id_str" : "406809355120807936",
  "text" : "\u00ABMir sagen ich soll nach meinen Orgien bitte aufr\u00E4umen, aber selbst dann \u00FCberall die Nerf Gun Darts liegen lassen\u2026\u00BB",
  "id" : 406809355120807936,
  "created_at" : "2013-11-30 15:38:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 56, 64 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/LrUagXMSPA",
      "expanded_url" : "http:\/\/del-fi.org\/post\/68560843111\/fdas-culture-is-mendelian-dominant-over-23andmes",
      "display_url" : "del-fi.org\/post\/685608431\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "406800579449847809",
  "text" : "RT @wilbanks: FDA data culture: Mendelian dominant over @23andme\u2019s business model. New post at http:\/\/t.co\/LrUagXMSPA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "23andMe",
        "screen_name" : "23andMe",
        "indices" : [ 42, 50 ],
        "id_str" : "14738561",
        "id" : 14738561
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/LrUagXMSPA",
        "expanded_url" : "http:\/\/del-fi.org\/post\/68560843111\/fdas-culture-is-mendelian-dominant-over-23andmes",
        "display_url" : "del-fi.org\/post\/685608431\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "406784706378625024",
    "text" : "FDA data culture: Mendelian dominant over @23andme\u2019s business model. New post at http:\/\/t.co\/LrUagXMSPA",
    "id" : 406784706378625024,
    "created_at" : "2013-11-30 14:00:06 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 406800579449847809,
  "created_at" : "2013-11-30 15:03:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0510137608, 8.5713868517 ]
  },
  "id_str" : "406752403678302208",
  "text" : "\u00ABWarten sie mal gerade hier, wir haben wieder ein herrenloses Gep\u00E4ckst\u00FCck. Der Sprengdienst kommt gleich, schon zum dritten mal heute\u2026\u00BB",
  "id" : 406752403678302208,
  "created_at" : "2013-11-30 11:51:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/gu4qJFR79s",
      "expanded_url" : "http:\/\/instagram.com\/p\/hVmNyMBwq7\/",
      "display_url" : "instagram.com\/p\/hVmNyMBwq7\/"
    } ]
  },
  "geo" : { },
  "id_str" : "406749973142061057",
  "text" : "\u00ABLook, there's a plane!\u00BB \u2014 \u00ABGod, we're at a damn airport, what did you expect?\u00BB http:\/\/t.co\/gu4qJFR79s",
  "id" : 406749973142061057,
  "created_at" : "2013-11-30 11:42:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 110, 119 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/ww6Y6na9aJ",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0081536",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096963514, 8.28322106 ]
  },
  "id_str" : "406581407210045440",
  "text" : "Affective Instability in Daily Life Is Predicted by Resting Heart Rate Variability http:\/\/t.co\/ww6Y6na9aJ \/cc @eramirez",
  "id" : 406581407210045440,
  "created_at" : "2013-11-30 00:32:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096963514, 8.28322106 ]
  },
  "id_str" : "406578085799395328",
  "text" : "Nearly fell for the phishing email. Then I remembered: Neither do I have a MasterCard nor do I speak Danish.",
  "id" : 406578085799395328,
  "created_at" : "2013-11-30 00:19:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406568873388175360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096506975, 8.2830096 ]
  },
  "id_str" : "406570075148546048",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock you\u2019re the first person to come to mind when talking about BioPython :)",
  "id" : 406570075148546048,
  "in_reply_to_status_id" : 406568873388175360,
  "created_at" : "2013-11-29 23:47:14 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096506975, 8.2830096 ]
  },
  "id_str" : "406562751772131328",
  "text" : "Love reading drafts that start with: \u00ABThe author can not be held responsible for any damage caused by reading this pre-release version\u00BB",
  "id" : 406562751772131328,
  "created_at" : "2013-11-29 23:18:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406559161313665024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096286633, 8.2829808267 ]
  },
  "id_str" : "406559369523109888",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock how stupid of me. Sorry to bother you on your own account. (You\u2019re just too famous!) ;)",
  "id" : 406559369523109888,
  "in_reply_to_status_id" : 406559161313665024,
  "created_at" : "2013-11-29 23:04:41 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406558382905364481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096286633, 8.2829808267 ]
  },
  "id_str" : "406558936960335872",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock awesome, thanks a lot for the support! Have a nice weekend! :)",
  "id" : 406558936960335872,
  "in_reply_to_status_id" : 406558382905364481,
  "created_at" : "2013-11-29 23:02:58 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406556349544562688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096286633, 8.2829808267 ]
  },
  "id_str" : "406557343703650304",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock Thanks! So if I want to make sure translation works Seq.translate(table=$id) is the preferred way to go if I need * as well?",
  "id" : 406557343703650304,
  "in_reply_to_status_id" : 406556349544562688,
  "created_at" : "2013-11-29 22:56:38 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 135, 143 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096286633, 8.2829808267 ]
  },
  "id_str" : "406551588892049408",
  "text" : "Why do the BioPython\u2019s \u2018CodonTable\u2019 exclude stop codons? e.g. CodonTable.unambiguous_dna_by_id[1].forward_table[\"TGA\"] -&gt; KeyError \/@pjacock",
  "id" : 406551588892049408,
  "created_at" : "2013-11-29 22:33:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1017361586, 8.5699199818 ]
  },
  "id_str" : "406541952835149824",
  "text" : "\u00ABWenn ich es entscheiden kann werde ich deinen Leichnam nicht wie gew\u00FCnscht in einer M\u00FClltonne entsorgen, sondern einen Quadrocopter bauen.\u00BB",
  "id" : 406541952835149824,
  "created_at" : "2013-11-29 21:55:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406432360612122624",
  "text" : "\u00ABIch durfte dich 6 Wochen lang volljammern &amp; Fragen stellen, deshalb habe ich dir Zigaretten mitgebracht. Ich h\u00E4tte da noch mal eine Frage\u2026\u00BB",
  "id" : 406432360612122624,
  "created_at" : "2013-11-29 14:40:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/cc8DvZkGMZ",
      "expanded_url" : "http:\/\/i.imgur.com\/IySZCch.gif",
      "display_url" : "i.imgur.com\/IySZCch.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "406428374760824832",
  "text" : "Progress today: http:\/\/t.co\/cc8DvZkGMZ",
  "id" : 406428374760824832,
  "created_at" : "2013-11-29 14:24:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406425350588358656",
  "geo" : { },
  "id_str" : "406425611373015042",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Ja, solange sind wir noch dabei ein paar Features (e.g. mehr\/besser standardisierte Phenotype-Descriptions) einzubauen.",
  "id" : 406425611373015042,
  "in_reply_to_status_id" : 406425350588358656,
  "created_at" : "2013-11-29 14:13:11 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406424149478100992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723292878, 8.6276419592 ]
  },
  "id_str" : "406424629285486592",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog 624 genotype data sets and counting. ;)",
  "id" : 406424629285486592,
  "in_reply_to_status_id" : 406424149478100992,
  "created_at" : "2013-11-29 14:09:17 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/5SW24yLKLV",
      "expanded_url" : "http:\/\/blogs.plos.org\/everyone\/2013\/11\/27\/ill-have-what-hes-having-dogs-eavesdrop-on-human-interactions\/",
      "display_url" : "blogs.plos.org\/everyone\/2013\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "406365993632419840",
  "text" : "I\u2019ll Have What He\u2019s Having: Dogs Eavesdrop on Human Interactions http:\/\/t.co\/5SW24yLKLV",
  "id" : 406365993632419840,
  "created_at" : "2013-11-29 10:16:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/CJTsoCeOph",
      "expanded_url" : "http:\/\/www.darkroastedblend.com\/2006\/11\/most-dangerous-roads-in-world.html",
      "display_url" : "darkroastedblend.com\/2006\/11\/most-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "406365400381669376",
  "text" : "\u00AByour shrieks (as you fall down the abyss) will disturb the peace and quiet of the villagers nearby.\u00BB http:\/\/t.co\/CJTsoCeOph",
  "id" : 406365400381669376,
  "created_at" : "2013-11-29 10:13:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/aiu9O2YAK7",
      "expanded_url" : "http:\/\/i.imgur.com\/D9VURG1.gif",
      "display_url" : "i.imgur.com\/D9VURG1.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096286633, 8.2829808267 ]
  },
  "id_str" : "406227511543336961",
  "text" : "What I will look like in about 4 hours http:\/\/t.co\/aiu9O2YAK7",
  "id" : 406227511543336961,
  "created_at" : "2013-11-29 01:06:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406210553057513473",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096286633, 8.2829808267 ]
  },
  "id_str" : "406212920440545280",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u2018How continental drift influences BTC mining efficiency\u2019",
  "id" : 406212920440545280,
  "in_reply_to_status_id" : 406210553057513473,
  "created_at" : "2013-11-29 00:08:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406209871965454336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966902, 8.28296197 ]
  },
  "id_str" : "406210075339268097",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Now we just have to wait! Getting rich quick (compared to evolutionary time scales)",
  "id" : 406210075339268097,
  "in_reply_to_status_id" : 406209871965454336,
  "created_at" : "2013-11-28 23:56:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/o5nm9Nh5xQ",
      "expanded_url" : "http:\/\/youtu.be\/UqIRa15wMjw?t=13m23s",
      "display_url" : "youtu.be\/UqIRa15wMjw?t=\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966902, 8.28296197 ]
  },
  "id_str" : "406208903546802176",
  "text" : "she's accustomed to hearing that she could never run far, a slipped disc in the spine of community http:\/\/t.co\/o5nm9Nh5xQ",
  "id" : 406208903546802176,
  "created_at" : "2013-11-28 23:52:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/fzDj9zWLKD",
      "expanded_url" : "http:\/\/www.nature.com\/news\/policy-twenty-tips-for-interpreting-scientific-claims-1.14183",
      "display_url" : "nature.com\/news\/policy-tw\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095908567, 8.28294269 ]
  },
  "id_str" : "406169774193135616",
  "text" : "Twenty tips for interpreting scientific claims (e.g. avoid the base-rate fallacy\u2026) http:\/\/t.co\/fzDj9zWLKD",
  "id" : 406169774193135616,
  "created_at" : "2013-11-28 21:16:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 65, 78 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/kfoxyvGcfo",
      "expanded_url" : "https:\/\/medium.com\/the-physics-arxiv-blog\/cf3e13e4f103",
      "display_url" : "medium.com\/the-physics-ar\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095908567, 8.28294269 ]
  },
  "id_str" : "406167249146621952",
  "text" : "Amazonian Beer Drinking Networks Revealed by Anthropologists \/cc @PhilippBayer  https:\/\/t.co\/kfoxyvGcfo",
  "id" : 406167249146621952,
  "created_at" : "2013-11-28 21:06:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/xSu4zGr4vG",
      "expanded_url" : "http:\/\/www.nature.com\/srep\/2013\/131125\/srep03325\/full\/srep03325.html",
      "display_url" : "nature.com\/srep\/2013\/1311\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095908567, 8.28294269 ]
  },
  "id_str" : "406164908683059201",
  "text" : "Wow: \u00ABA novel platform to enable inhaled naked RNAi medicine for lung cancer\u00BB http:\/\/t.co\/xSu4zGr4vG",
  "id" : 406164908683059201,
  "created_at" : "2013-11-28 20:57:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Bork",
      "screen_name" : "sebidotorg",
      "indices" : [ 0, 11 ],
      "id_str" : "751063429",
      "id" : 751063429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/smCE2zl9Ak",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Polytomy",
      "display_url" : "en.wikipedia.org\/wiki\/Polytomy"
    } ]
  },
  "in_reply_to_status_id_str" : "406076930707185664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722872682, 8.6274862055 ]
  },
  "id_str" : "406077409432440832",
  "in_reply_to_user_id" : 751063429,
  "text" : "@sebidotorg der Slang ist auch zu Nische: http:\/\/t.co\/smCE2zl9Ak :)",
  "id" : 406077409432440832,
  "in_reply_to_status_id" : 406076930707185664,
  "created_at" : "2013-11-28 15:09:33 +0000",
  "in_reply_to_screen_name" : "sebidotorg",
  "in_reply_to_user_id_str" : "751063429",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1727581123, 8.6275327104 ]
  },
  "id_str" : "406030453196324865",
  "text" : "Overly attached Mensapersonal: \u00ABDein Freund? Das ist meiner, er isst meine Nudeln!\u00BB\u2014\u00ABNicht streiten\u2026\u00BB\u2014\u00ABGenau, weil du sowieso mir geh\u00F6rst!\u00BB",
  "id" : 406030453196324865,
  "created_at" : "2013-11-28 12:02:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406025658041917440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1727586259, 8.6275464067 ]
  },
  "id_str" : "406029851695808512",
  "in_reply_to_user_id" : 464898426,
  "text" : "@thewholebakery w\u00FCrde mich zumindest nicht \u00FCberraschen wenn es die Lingo da auch gibt ;)",
  "id" : 406029851695808512,
  "in_reply_to_status_id" : 406025658041917440,
  "created_at" : "2013-11-28 12:00:34 +0000",
  "in_reply_to_screen_name" : "_schnurri",
  "in_reply_to_user_id_str" : "464898426",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/smCE2zl9Ak",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Polytomy",
      "display_url" : "en.wikipedia.org\/wiki\/Polytomy"
    } ]
  },
  "in_reply_to_status_id_str" : "406024221962567680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723852883, 8.6275930329 ]
  },
  "id_str" : "406024865322663936",
  "in_reply_to_user_id" : 464898426,
  "text" : "@thewholebakery http:\/\/t.co\/smCE2zl9Ak ;)",
  "id" : 406024865322663936,
  "in_reply_to_status_id" : 406024221962567680,
  "created_at" : "2013-11-28 11:40:46 +0000",
  "in_reply_to_screen_name" : "_schnurri",
  "in_reply_to_user_id_str" : "464898426",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724204525, 8.6275562021 ]
  },
  "id_str" : "406023012644032512",
  "text" : "\u00ABGleich wird es um Hard Poly vs Soft Poly gehen.\u00BB \u2014 \u00ABImmer dieses polyer-than-thou\u2026\u00BB",
  "id" : 406023012644032512,
  "created_at" : "2013-11-28 11:33:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1726959565, 8.627587461 ]
  },
  "id_str" : "405973896576655360",
  "text" : "\u00ABIch bin in die Stadt gefahren weil ich mir dachte das du heute um diese Zeit zur Arbeit f\u00E4hrst und ich dich dann in der U-Bahn treffe.\u00BB &lt;3",
  "id" : 405973896576655360,
  "created_at" : "2013-11-28 08:18:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 45, 58 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/RW4JlnS8zS",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/5SypkweH2Go\/info%3Adoi%2F10.1371%2Fjournal.pone.0081823",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.99849, 8.354356 ]
  },
  "id_str" : "405951785246154752",
  "text" : "Publication Bias in Recent Meta-Analyses \/cc @philippbayer  http:\/\/t.co\/RW4JlnS8zS",
  "id" : 405951785246154752,
  "created_at" : "2013-11-28 06:50:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "David Dobbs",
      "screen_name" : "David_Dobbs",
      "indices" : [ 58, 70 ],
      "id_str" : "14043142",
      "id" : 14043142
    }, {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 84, 97 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/BDR2CdXUgo",
      "expanded_url" : "http:\/\/www.newyorker.com\/online\/blogs\/elements\/2013\/11\/the-fda-vs-personal-genetic-testing.html",
      "display_url" : "newyorker.com\/online\/blogs\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "405868034319204352",
  "text" : "RT @edyong209: V.lucid take on the FDA\/23andme ruckus, by @david_dobbs, with killer @MishaAngrist quote http:\/\/t.co\/BDR2CdXUgo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Dobbs",
        "screen_name" : "David_Dobbs",
        "indices" : [ 43, 55 ],
        "id_str" : "14043142",
        "id" : 14043142
      }, {
        "name" : "Misha Angrist",
        "screen_name" : "MishaAngrist",
        "indices" : [ 69, 82 ],
        "id_str" : "116877838",
        "id" : 116877838
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/BDR2CdXUgo",
        "expanded_url" : "http:\/\/www.newyorker.com\/online\/blogs\/elements\/2013\/11\/the-fda-vs-personal-genetic-testing.html",
        "display_url" : "newyorker.com\/online\/blogs\/e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "405866824736055296",
    "text" : "V.lucid take on the FDA\/23andme ruckus, by @david_dobbs, with killer @MishaAngrist quote http:\/\/t.co\/BDR2CdXUgo",
    "id" : 405866824736055296,
    "created_at" : "2013-11-28 01:12:46 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 405868034319204352,
  "created_at" : "2013-11-28 01:17:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 3, 10 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405866938691502080",
  "text" : "RT @arikia: \"If you\u2019re going to hate us, hate us for the traditional reason to hate us. Call us witches, not hipsters.\u201D http:\/\/t.co\/PlmV7tI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/PlmV7tIn9C",
        "expanded_url" : "http:\/\/www.nytimes.com\/2013\/11\/17\/nyregion\/witches-dance-at-catland-occult-bookstore-in-bushwick.html?_r=0",
        "display_url" : "nytimes.com\/2013\/11\/17\/nyr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "405866397341061120",
    "text" : "\"If you\u2019re going to hate us, hate us for the traditional reason to hate us. Call us witches, not hipsters.\u201D http:\/\/t.co\/PlmV7tIn9C",
    "id" : 405866397341061120,
    "created_at" : "2013-11-28 01:11:04 +0000",
    "user" : {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "protected" : false,
      "id_str" : "71654283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897255084073025537\/5uB8YwJG_normal.jpg",
      "id" : 71654283,
      "verified" : false
    }
  },
  "id" : 405866938691502080,
  "created_at" : "2013-11-28 01:13:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Khomenko",
      "screen_name" : "akhomenko",
      "indices" : [ 0, 10 ],
      "id_str" : "46498656",
      "id" : 46498656
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405830899670851586",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096558, 8.28308351 ]
  },
  "id_str" : "405831219335938048",
  "in_reply_to_user_id" : 46498656,
  "text" : "@akhomenko @PhilippBayer you\u2019re right, accurately that should be \u2018tried to\u2019.",
  "id" : 405831219335938048,
  "in_reply_to_status_id" : 405830899670851586,
  "created_at" : "2013-11-27 22:51:17 +0000",
  "in_reply_to_screen_name" : "akhomenko",
  "in_reply_to_user_id_str" : "46498656",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 122, 135 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096558, 8.28308351 ]
  },
  "id_str" : "405830501040410624",
  "text" : "Fun: Next larger jump in \u2018genotypes over time\u2019-graph for openSNP may be labeled \u2018The week the FDA shut down 23andMe\u2019. \/cc @PhilippBayer",
  "id" : 405830501040410624,
  "created_at" : "2013-11-27 22:48:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009607245, 8.2829381775 ]
  },
  "id_str" : "405829412924690432",
  "text" : "\u00ABLet\u2019s call it a day. We tried hard, but I think we overshot the Ballmer peak for now.\u00BB",
  "id" : 405829412924690432,
  "created_at" : "2013-11-27 22:44:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405827530948497408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009607245, 8.2829381775 ]
  },
  "id_str" : "405828574823075840",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn even better: Gorilla gorilla (aka \u2018gorilla\u2019 for the layperson) ;)",
  "id" : 405828574823075840,
  "in_reply_to_status_id" : 405827530948497408,
  "created_at" : "2013-11-27 22:40:46 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405818466068099072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958781, 8.282954845 ]
  },
  "id_str" : "405818643956912128",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara If you can find and spare the time that would be awesome. We\u2019ll give it another try tomorrow as well (and I\u2019m googling right now).",
  "id" : 405818643956912128,
  "in_reply_to_status_id" : 405818466068099072,
  "created_at" : "2013-11-27 22:01:19 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405816435249012736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958781, 8.282954845 ]
  },
  "id_str" : "405817812129972224",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara looked into it, but my student and I felt to brain dead to make it work, do you maybe have a how-to-link?",
  "id" : 405817812129972224,
  "in_reply_to_status_id" : 405816435249012736,
  "created_at" : "2013-11-27 21:58:00 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Nikbakht",
      "screen_name" : "nikleotide",
      "indices" : [ 0, 11 ],
      "id_str" : "92132955",
      "id" : 92132955
    }, {
      "name" : "Neil Saunders",
      "screen_name" : "neilfws",
      "indices" : [ 12, 20 ],
      "id_str" : "14162706",
      "id" : 14162706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405814306165751808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958781, 8.282954845 ]
  },
  "id_str" : "405814635921952768",
  "in_reply_to_user_id" : 92132955,
  "text" : "@nikleotide @neilfws no problem, we\u2019re happy for everyone who can put our little hobby project to use. :)",
  "id" : 405814635921952768,
  "in_reply_to_status_id" : 405814306165751808,
  "created_at" : "2013-11-27 21:45:23 +0000",
  "in_reply_to_screen_name" : "nikleotide",
  "in_reply_to_user_id_str" : "92132955",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958781, 8.282954845 ]
  },
  "id_str" : "405814186556801024",
  "text" : "Hey, R experts: Any tips on how to best fit a truncated beta distribution to my data?",
  "id" : 405814186556801024,
  "created_at" : "2013-11-27 21:43:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H. Nikbakht",
      "screen_name" : "nikleotide",
      "indices" : [ 0, 11 ],
      "id_str" : "92132955",
      "id" : 92132955
    }, {
      "name" : "Neil Saunders",
      "screen_name" : "neilfws",
      "indices" : [ 12, 20 ],
      "id_str" : "14162706",
      "id" : 14162706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405813309347491840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958781, 8.282954845 ]
  },
  "id_str" : "405813838857375744",
  "in_reply_to_user_id" : 92132955,
  "text" : "@nikleotide @neilfws let us know if we can be of any help feature- or otherwise etc. :)",
  "id" : 405813838857375744,
  "in_reply_to_status_id" : 405813309347491840,
  "created_at" : "2013-11-27 21:42:13 +0000",
  "in_reply_to_screen_name" : "nikleotide",
  "in_reply_to_user_id_str" : "92132955",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405622755258679296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958781, 8.282954845 ]
  },
  "id_str" : "405806488960401408",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer more of an industrial-scale floor polisher actually!",
  "id" : 405806488960401408,
  "in_reply_to_status_id" : 405622755258679296,
  "created_at" : "2013-11-27 21:13:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0420\u043E\u043C\u0430 \u0428\u0443\u043F\u0438\u0446\u0430",
      "screen_name" : "Bobolze",
      "indices" : [ 0, 8 ],
      "id_str" : "275951822",
      "id" : 275951822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405532646370836481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958781, 8.282954845 ]
  },
  "id_str" : "405805645280321536",
  "in_reply_to_user_id" : 453559748,
  "text" : "@Bobolze Great, thanks a lot! :)",
  "id" : 405805645280321536,
  "in_reply_to_status_id" : 405532646370836481,
  "created_at" : "2013-11-27 21:09:40 +0000",
  "in_reply_to_screen_name" : "alexbolze",
  "in_reply_to_user_id_str" : "453559748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0075144135, 8.279166352 ]
  },
  "id_str" : "405803464716206081",
  "text" : "Universit\u00E4re Forschung: Niemand kann \u2018seit meiner Zeit beim Bund\/dem Zivildienst habe ich nicht mehr so gut verdient\u2019 widersprechen.",
  "id" : 405803464716206081,
  "created_at" : "2013-11-27 21:01:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722886499, 8.6275926652 ]
  },
  "id_str" : "405621788505538560",
  "text" : "Vor dem ersten Kaffee schon 2x von Reinigungsger\u00E4ten \u00FCberfahren werden. Bring it on\u2026",
  "id" : 405621788505538560,
  "created_at" : "2013-11-27 08:59:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/XHQE1so1Ia",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=qFMwqGucfvw",
      "display_url" : "youtube.com\/watch?v=qFMwqG\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958781, 8.282954845 ]
  },
  "id_str" : "405505153043660800",
  "text" : "Pool of oobleck to create a non-newtonian version of the Red Queen: \u00ABtakes all the running you can do, to not drown\u00BB  http:\/\/t.co\/XHQE1so1Ia",
  "id" : 405505153043660800,
  "created_at" : "2013-11-27 01:15:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Khomenko",
      "screen_name" : "akhomenko",
      "indices" : [ 0, 10 ],
      "id_str" : "46498656",
      "id" : 46498656
    }, {
      "name" : "Gholson Lyon",
      "screen_name" : "GholsonLyon",
      "indices" : [ 11, 23 ],
      "id_str" : "384182912",
      "id" : 384182912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405498071267540992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096507675, 8.283009525 ]
  },
  "id_str" : "405498707853840384",
  "in_reply_to_user_id" : 46498656,
  "text" : "@akhomenko @GholsonLyon full ack. Making the data of all customers available isn\u2019t feasible. Guess the API is a 1st step in right direction.",
  "id" : 405498707853840384,
  "in_reply_to_status_id" : 405498071267540992,
  "created_at" : "2013-11-27 00:50:00 +0000",
  "in_reply_to_screen_name" : "akhomenko",
  "in_reply_to_user_id_str" : "46498656",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Khomenko",
      "screen_name" : "akhomenko",
      "indices" : [ 0, 10 ],
      "id_str" : "46498656",
      "id" : 46498656
    }, {
      "name" : "Gholson Lyon",
      "screen_name" : "GholsonLyon",
      "indices" : [ 11, 23 ],
      "id_str" : "384182912",
      "id" : 384182912
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 24, 35 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405496550475845632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958781, 8.282954845 ]
  },
  "id_str" : "405497951327252480",
  "in_reply_to_user_id" : 46498656,
  "text" : "@akhomenko @GholsonLyon @openSNPorg but yes, single data sets can only be made avail by individuals themselves.",
  "id" : 405497951327252480,
  "in_reply_to_status_id" : 405496550475845632,
  "created_at" : "2013-11-27 00:47:00 +0000",
  "in_reply_to_screen_name" : "akhomenko",
  "in_reply_to_user_id_str" : "46498656",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Khomenko",
      "screen_name" : "akhomenko",
      "indices" : [ 0, 10 ],
      "id_str" : "46498656",
      "id" : 46498656
    }, {
      "name" : "Gholson Lyon",
      "screen_name" : "GholsonLyon",
      "indices" : [ 11, 23 ],
      "id_str" : "384182912",
      "id" : 384182912
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 24, 35 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405496550475845632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958781, 8.282954845 ]
  },
  "id_str" : "405497637735915520",
  "in_reply_to_user_id" : 46498656,
  "text" : "@akhomenko @GholsonLyon @openSNPorg well: publishing results isn\u2019t even close to data publishing in terms of re-use possibilities.",
  "id" : 405497637735915520,
  "in_reply_to_status_id" : 405496550475845632,
  "created_at" : "2013-11-27 00:45:45 +0000",
  "in_reply_to_screen_name" : "akhomenko",
  "in_reply_to_user_id_str" : "46498656",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/T4BK3iTCEy",
      "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2532",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958781, 8.282954845 ]
  },
  "id_str" : "405496929326350336",
  "text" : "\u00ABEnglish is like software that keeps pushing out cool new updates, but then also drops old features!\u00BB http:\/\/t.co\/T4BK3iTCEy",
  "id" : 405496929326350336,
  "created_at" : "2013-11-27 00:42:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/d8xLKJqa8r",
      "expanded_url" : "http:\/\/alexandreafonso.wordpress.com\/2013\/11\/21\/how-academia-resembles-a-drug-gang\/",
      "display_url" : "alexandreafonso.wordpress.com\/2013\/11\/21\/how\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965128, 8.2830097375 ]
  },
  "id_str" : "405488006166900737",
  "text" : "\u00ABThe academic job market is structured in many respects like a drug gang\u00BB http:\/\/t.co\/d8xLKJqa8r",
  "id" : 405488006166900737,
  "created_at" : "2013-11-27 00:07:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096979463, 8.2831276304 ]
  },
  "id_str" : "405481778242011137",
  "text" : "\u00ABIch stricke gerne, musst du wissen.\u00BB \u2014 \u00ABTrifft sich gut, ich trage gerne Handschuhe!\u00BB",
  "id" : 405481778242011137,
  "created_at" : "2013-11-26 23:42:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Stajich",
      "screen_name" : "hyphaltip",
      "indices" : [ 3, 13 ],
      "id_str" : "14324284",
      "id" : 14324284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405412162413559809",
  "text" : "RT @hyphaltip: Glomus genome published!: Genome of an arbuscular mycorrhizal fungus provides insight into the oldest plant symbiosis http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/hb8hgGTXHg",
        "expanded_url" : "http:\/\/s.fungidb.org\/18lUKhJ",
        "display_url" : "s.fungidb.org\/18lUKhJ"
      } ]
    },
    "geo" : { },
    "id_str" : "405386238058049536",
    "text" : "Glomus genome published!: Genome of an arbuscular mycorrhizal fungus provides insight into the oldest plant symbiosis http:\/\/t.co\/hb8hgGTXHg",
    "id" : 405386238058049536,
    "created_at" : "2013-11-26 17:23:05 +0000",
    "user" : {
      "name" : "Jason Stajich",
      "screen_name" : "hyphaltip",
      "protected" : false,
      "id_str" : "14324284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/52523742\/Coprinus_normal.jpg",
      "id" : 14324284,
      "verified" : false
    }
  },
  "id" : 405412162413559809,
  "created_at" : "2013-11-26 19:06:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Voytek",
      "screen_name" : "bradleyvoytek",
      "indices" : [ 3, 17 ],
      "id_str" : "162535413",
      "id" : 162535413
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "overlyhonestreviews",
      "indices" : [ 108, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405411547524370432",
  "text" : "RT @bradleyvoytek: My favorite Acknowledgements (and a wonderful closing paragraph for a theory paper too!) #overlyhonestreviews http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bradleyvoytek\/status\/405404136843132928\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/AjAxg01hA3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaBI6h-CQAAfZLY.jpg",
        "id_str" : "405404136851521536",
        "id" : 405404136851521536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaBI6h-CQAAfZLY.jpg",
        "sizes" : [ {
          "h" : 1224,
          "resize" : "fit",
          "w" : 1632
        }, {
          "h" : 1224,
          "resize" : "fit",
          "w" : 1632
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/AjAxg01hA3"
      } ],
      "hashtags" : [ {
        "text" : "overlyhonestreviews",
        "indices" : [ 89, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405404136843132928",
    "text" : "My favorite Acknowledgements (and a wonderful closing paragraph for a theory paper too!) #overlyhonestreviews http:\/\/t.co\/AjAxg01hA3",
    "id" : 405404136843132928,
    "created_at" : "2013-11-26 18:34:13 +0000",
    "user" : {
      "name" : "Brad Voytek",
      "screen_name" : "bradleyvoytek",
      "protected" : false,
      "id_str" : "162535413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688408740651909124\/mz2GSnS0_normal.jpg",
      "id" : 162535413,
      "verified" : true
    }
  },
  "id" : 405411547524370432,
  "created_at" : "2013-11-26 19:03:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gonewiththeBLASTwave",
      "indices" : [ 63, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/yz1kniilj5",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/04f15b84af84e78098f823bc4390d635\/tumblr_mtsx4r0suv1st4d1oo1_500.gif",
      "display_url" : "25.media.tumblr.com\/04f15b84af84e7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "405392568684265472",
  "text" : "Submitting 60,000+ jobs to the cluster\u2026 http:\/\/t.co\/yz1kniilj5 #gonewiththeBLASTwave",
  "id" : 405392568684265472,
  "created_at" : "2013-11-26 17:48:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/XWNjRtTTqj",
      "expanded_url" : "http:\/\/i.imgur.com\/erQUN3h.jpg",
      "display_url" : "i.imgur.com\/erQUN3h.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "405391341418340352",
  "text" : "It's true! (p &lt; 0.05) http:\/\/t.co\/XWNjRtTTqj",
  "id" : 405391341418340352,
  "created_at" : "2013-11-26 17:43:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aprica",
      "screen_name" : "aprica",
      "indices" : [ 3, 10 ],
      "id_str" : "13196692",
      "id" : 13196692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ftZE1hyVzc",
      "expanded_url" : "http:\/\/www.newrepublic.com\/article\/115726\/period-our-simplest-punctuation-mark-has-become-sign-anger",
      "display_url" : "newrepublic.com\/article\/115726\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "405305331028594688",
  "text" : "RT @aprica: Total. \"The period has a new meaning in punctuation. It\u2019s become a symbol of passive aggression.\" http:\/\/t.co\/ftZE1hyVzc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/ftZE1hyVzc",
        "expanded_url" : "http:\/\/www.newrepublic.com\/article\/115726\/period-our-simplest-punctuation-mark-has-become-sign-anger",
        "display_url" : "newrepublic.com\/article\/115726\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "405299767158525952",
    "text" : "Total. \"The period has a new meaning in punctuation. It\u2019s become a symbol of passive aggression.\" http:\/\/t.co\/ftZE1hyVzc",
    "id" : 405299767158525952,
    "created_at" : "2013-11-26 11:39:29 +0000",
    "user" : {
      "name" : "aprica",
      "screen_name" : "aprica",
      "protected" : false,
      "id_str" : "13196692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2176100652\/IMG_0385-Bearbeitet3_rp122_normal.jpg",
      "id" : 13196692,
      "verified" : false
    }
  },
  "id" : 405305331028594688,
  "created_at" : "2013-11-26 12:01:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hurtz",
      "screen_name" : "SimonHurtz",
      "indices" : [ 0, 11 ],
      "id_str" : "263096190",
      "id" : 263096190
    }, {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 12, 18 ],
      "id_str" : "14179278",
      "id" : 14179278
    }, {
      "name" : "Udo Stiehl",
      "screen_name" : "udostiehl",
      "indices" : [ 19, 29 ],
      "id_str" : "19725119",
      "id" : 19725119
    }, {
      "name" : "Richard Gutjahr",
      "screen_name" : "gutjahr",
      "indices" : [ 30, 38 ],
      "id_str" : "14824990",
      "id" : 14824990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405304266900127744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1727502025, 8.6275406708 ]
  },
  "id_str" : "405304658115457024",
  "in_reply_to_user_id" : 263096190,
  "text" : "@SimonHurtz @tante @udostiehl @gutjahr @DRadioWissen und das wurde auch g\u00FCtig beigelegt. Mal abwarten was passiert.",
  "id" : 405304658115457024,
  "in_reply_to_status_id" : 405304266900127744,
  "created_at" : "2013-11-26 11:58:55 +0000",
  "in_reply_to_screen_name" : "SimonHurtz",
  "in_reply_to_user_id_str" : "263096190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Hurtz",
      "screen_name" : "SimonHurtz",
      "indices" : [ 0, 11 ],
      "id_str" : "263096190",
      "id" : 263096190
    }, {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 12, 18 ],
      "id_str" : "14179278",
      "id" : 14179278
    }, {
      "name" : "Udo Stiehl",
      "screen_name" : "udostiehl",
      "indices" : [ 19, 29 ],
      "id_str" : "19725119",
      "id" : 19725119
    }, {
      "name" : "Richard Gutjahr",
      "screen_name" : "gutjahr",
      "indices" : [ 30, 38 ],
      "id_str" : "14824990",
      "id" : 14824990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405304266900127744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1727502025, 8.6275406708 ]
  },
  "id_str" : "405304562820841472",
  "in_reply_to_user_id" : 263096190,
  "text" : "@SimonHurtz @tante @udostiehl @gutjahr @DRadioWissen iirc gab es vor Jahren schon mal einen cease &amp; desist von kalifornischen Beh\u00F6rden.",
  "id" : 405304562820841472,
  "in_reply_to_status_id" : 405304266900127744,
  "created_at" : "2013-11-26 11:58:32 +0000",
  "in_reply_to_screen_name" : "SimonHurtz",
  "in_reply_to_user_id_str" : "263096190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 7, 20 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405288449436946432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1727444491, 8.6275331984 ]
  },
  "id_str" : "405303824656904192",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv @PhilippBayer well, if they really have half a Million customers there\u2019s still space for us to grow. ;)",
  "id" : 405303824656904192,
  "in_reply_to_status_id" : 405288449436946432,
  "created_at" : "2013-11-26 11:55:36 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405276753868120064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723770929, 8.6275950579 ]
  },
  "id_str" : "405277614090502144",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante ich schau es mir heut Abend mal an. :)",
  "id" : 405277614090502144,
  "in_reply_to_status_id" : 405276753868120064,
  "created_at" : "2013-11-26 10:11:27 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723770929, 8.6275950579 ]
  },
  "id_str" : "405277523485147136",
  "text" : "\u00ABWieso sind da Gitter an den Dachfenstern?\u00BB \u2014 \u00ABVielleicht sind das Spielzimmer. Also f\u00FCr Kinder.\u00BB",
  "id" : 405277523485147136,
  "created_at" : "2013-11-26 10:11:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405252157315624961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172346611, 8.6276127625 ]
  },
  "id_str" : "405277063575515136",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 nein, hatte ich dank zu viel Arbeit noch nicht gesehen. Danke :)",
  "id" : 405277063575515136,
  "in_reply_to_status_id" : 405252157315624961,
  "created_at" : "2013-11-26 10:09:16 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405275534483271680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723387994, 8.6276031703 ]
  },
  "id_str" : "405276627078479872",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante cool, danke :)",
  "id" : 405276627078479872,
  "in_reply_to_status_id" : 405275534483271680,
  "created_at" : "2013-11-26 10:07:32 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1673056765, 8.6860256242 ]
  },
  "id_str" : "405138614872735745",
  "text" : "\u00ABAber au\u00DFer dir bringe ich doch niemanden zum weinen.\u00BB \u2014 \u00ABNicht? Das wundert mich!\u00BB",
  "id" : 405138614872735745,
  "created_at" : "2013-11-26 00:59:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    }, {
      "name" : "Udo Stiehl",
      "screen_name" : "udostiehl",
      "indices" : [ 7, 17 ],
      "id_str" : "19725119",
      "id" : 19725119
    }, {
      "name" : "Simon Hurtz",
      "screen_name" : "SimonHurtz",
      "indices" : [ 18, 29 ],
      "id_str" : "263096190",
      "id" : 263096190
    }, {
      "name" : "Richard Gutjahr",
      "screen_name" : "gutjahr",
      "indices" : [ 44, 52 ],
      "id_str" : "14824990",
      "id" : 14824990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405054456615948290",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.167405461, 8.686055867 ]
  },
  "id_str" : "405055195794931712",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante @udostiehl @SimonHurtz @DRadioWissen @gutjahr dito",
  "id" : 405055195794931712,
  "in_reply_to_status_id" : 405054456615948290,
  "created_at" : "2013-11-25 19:27:38 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/MZindRglx9",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=527",
      "display_url" : "smbc-comics.com\/index.php?id=5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "404979664747106304",
  "text" : "say what you will\u2026 http:\/\/t.co\/MZindRglx9",
  "id" : 404979664747106304,
  "created_at" : "2013-11-25 14:27:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/Dgj8qxfpVU",
      "expanded_url" : "https:\/\/github.com\/jtleek\/datasharing",
      "display_url" : "github.com\/jtleek\/datasha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "404973397236396032",
  "text" : "How to share data with a statistician https:\/\/t.co\/Dgj8qxfpVU",
  "id" : 404973397236396032,
  "created_at" : "2013-11-25 14:02:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723755922, 8.6275331605 ]
  },
  "id_str" : "404941742891626496",
  "text" : "\u00ABWir haben ihr nur Retro-Geschenke geschenkt. Und eine Zwiebel.\u00BB",
  "id" : 404941742891626496,
  "created_at" : "2013-11-25 11:56:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722839137, 8.6276527728 ]
  },
  "id_str" : "404935005933408256",
  "text" : "\u00ABMein 3-Punkte Plan f\u00FCr Pickup Artists: 1: Hallo sagen 2: Hand halten 3: Hand einf\u00FChren.\u00BB",
  "id" : 404935005933408256,
  "created_at" : "2013-11-25 11:30:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0994094316, 8.5189328502 ]
  },
  "id_str" : "404727840333398016",
  "text" : "\u00ABMan sieht bei dem Konzert hier gleich wer Sigur R\u00F3s gern zum einschlafen h\u00F6rt und darauf konditioniert ist.\u00BB \u2014 \u00ABDu meinst so wie ich?\u00BB",
  "id" : 404727840333398016,
  "created_at" : "2013-11-24 21:46:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0994059762, 8.5190189156 ]
  },
  "id_str" : "404698402589777921",
  "text" : "Wochenends S-Bahn fahren in Frankfurt: \u00ABSo einen schlechten Trip hatte ich ja noch nie! Noch nie! Oh, doch! Auf Pep! Auf Pep!\u00BB",
  "id" : 404698402589777921,
  "created_at" : "2013-11-24 19:49:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404636743460085761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095902343, 8.2829510465 ]
  },
  "id_str" : "404637034075389952",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez they are great live. Had you had a chance to see them? :)",
  "id" : 404637034075389952,
  "in_reply_to_status_id" : 404636743460085761,
  "created_at" : "2013-11-24 15:46:01 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia McLainn",
      "screen_name" : "girlinterruptin",
      "indices" : [ 3, 19 ],
      "id_str" : "851410550357721088",
      "id" : 851410550357721088
    }, {
      "name" : "Uta Frith",
      "screen_name" : "utafrith",
      "indices" : [ 62, 71 ],
      "id_str" : "185280748",
      "id" : 185280748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404587931924709376",
  "text" : "RT @girlinterruptin: Wow, funding applications of the past MT @utafrith Otto Warburg's grant application 1921 \"I need 10.000 marks\" http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Uta Frith",
        "screen_name" : "utafrith",
        "indices" : [ 41, 50 ],
        "id_str" : "185280748",
        "id" : 185280748
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dbasanta\/status\/360865277241614336\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/Dmi7F4jHW2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQINDsYCYAARVd4.png",
        "id_str" : "360865277245808640",
        "id" : 360865277245808640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQINDsYCYAARVd4.png",
        "sizes" : [ {
          "h" : 862,
          "resize" : "fit",
          "w" : 851
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 862,
          "resize" : "fit",
          "w" : 851
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 862,
          "resize" : "fit",
          "w" : 851
        } ],
        "display_url" : "pic.twitter.com\/Dmi7F4jHW2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "371960008814395392",
    "geo" : { },
    "id_str" : "404555713831514112",
    "in_reply_to_user_id" : 185280748,
    "text" : "Wow, funding applications of the past MT @utafrith Otto Warburg's grant application 1921 \"I need 10.000 marks\" http:\/\/t.co\/Dmi7F4jHW2",
    "id" : 404555713831514112,
    "in_reply_to_status_id" : 371960008814395392,
    "created_at" : "2013-11-24 10:22:53 +0000",
    "in_reply_to_screen_name" : "utafrith",
    "in_reply_to_user_id_str" : "185280748",
    "user" : {
      "name" : "Sylvia McLain",
      "screen_name" : "DrSylviaMcLain",
      "protected" : false,
      "id_str" : "127360026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762217881123848192\/tCvadUwn_normal.jpg",
      "id" : 127360026,
      "verified" : true
    }
  },
  "id" : 404587931924709376,
  "created_at" : "2013-11-24 12:30:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096682567, 8.2831319 ]
  },
  "id_str" : "404586829732921345",
  "text" : "\u00ABIch werde mich z\u00FCngeln.\u00BB close, autocorrect, close\u2026",
  "id" : 404586829732921345,
  "created_at" : "2013-11-24 12:26:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/4c4WvxbMCr",
      "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2530",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "404564476206518272",
  "text" : "how can i ever go back, trading the beauty of the universe for one lonely sun? http:\/\/t.co\/4c4WvxbMCr",
  "id" : 404564476206518272,
  "created_at" : "2013-11-24 10:57:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/mFYA4rMAws",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=2pJ7V2-AUY4",
      "display_url" : "youtube.com\/watch?v=2pJ7V2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "404456409364185088",
  "text" : "for feeling anything at all, the flight that comes before the fall http:\/\/t.co\/mFYA4rMAws",
  "id" : 404456409364185088,
  "created_at" : "2013-11-24 03:48:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/mVHaXvjGo0",
      "expanded_url" : "https:\/\/medium.com\/learning-to-code\/565fc9dcb329",
      "display_url" : "medium.com\/learning-to-co\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "404444982368825344",
  "text" : "Learning to Code: \u00ABIt never works the first time. And probably won\u2019t the second or third time\u00BB https:\/\/t.co\/mVHaXvjGo0",
  "id" : 404444982368825344,
  "created_at" : "2013-11-24 03:02:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/zZymUXz4BG",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/eba75a4b1b81f8e82adb3d6b665cf6fb\/tumblr_mvtif2eent1qdlh1io1_r1_400.gif",
      "display_url" : "25.media.tumblr.com\/eba75a4b1b81f8\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "404443119615496193",
  "text" : "Fuck you, I won't do what you tell me http:\/\/t.co\/zZymUXz4BG",
  "id" : 404443119615496193,
  "created_at" : "2013-11-24 02:55:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404438771245912064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "404438902687404033",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \\o\/ Awesome! I got the text for the newsletter. Will sent to the mailing list later.",
  "id" : 404438902687404033,
  "in_reply_to_status_id" : 404438771245912064,
  "created_at" : "2013-11-24 02:38:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 32, 45 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/Kf1NOLgNIR",
      "expanded_url" : "http:\/\/blogs.smithsonianmag.com\/science\/2013\/11\/the-neuroscientist-who-discovered-he-was-a-psychopath\/",
      "display_url" : "blogs.smithsonianmag.com\/science\/2013\/1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "404437859224289280",
  "text" : "Love the last two paragraphs RT @PhilippBayer: \"The Neuroscientist Who Discovered He Was a Psychopath\" http:\/\/t.co\/Kf1NOLgNIR",
  "id" : 404437859224289280,
  "created_at" : "2013-11-24 02:34:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404434620231344128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "404436770286481408",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer cool, TIL: pro-social psychopathy is a thing!",
  "id" : 404436770286481408,
  "in_reply_to_status_id" : 404434620231344128,
  "created_at" : "2013-11-24 02:30:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/z8er15qOJ9",
      "expanded_url" : "http:\/\/i.imgur.com\/kKWHSnG.gif",
      "display_url" : "i.imgur.com\/kKWHSnG.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "404430310118797312",
  "text" : "Cute? More like training to bite the carotids! http:\/\/t.co\/z8er15qOJ9",
  "id" : 404430310118797312,
  "created_at" : "2013-11-24 02:04:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "Jan F. Wienken",
      "screen_name" : "jan_wienken",
      "indices" : [ 8, 20 ],
      "id_str" : "16699185",
      "id" : 16699185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/lT4OJfeEPh",
      "expanded_url" : "http:\/\/i.imgur.com\/s7BgcoO.jpg",
      "display_url" : "i.imgur.com\/s7BgcoO.jpg"
    } ]
  },
  "in_reply_to_status_id_str" : "404319251885879296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "404423496732004352",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng @jan_wienken Related: http:\/\/t.co\/lT4OJfeEPh ;)",
  "id" : 404423496732004352,
  "in_reply_to_status_id" : 404319251885879296,
  "created_at" : "2013-11-24 01:37:30 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "404420598920921088",
  "text" : "\u00ABYou really shouldn\u2019t buy my latest album. You know: You can get it online and have a beer instead.\u00BB \u2013 \u00ABCheers!\u00BB",
  "id" : 404420598920921088,
  "created_at" : "2013-11-24 01:25:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "404407984954302464",
  "text" : "\u00ABChanging medicine from a \u201Ctelling what to do\u201D to a \u201Ctelling the patient the information\u201D profession will lead us to a better system\u00BB",
  "id" : 404407984954302464,
  "created_at" : "2013-11-24 00:35:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/82z08vpIMh",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/guest-blog\/2013\/11\/22\/how-clinical-guidelines-can-fail-both-doctors-and-patients\/",
      "display_url" : "blogs.scientificamerican.com\/guest-blog\/201\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "404407789701066752",
  "text" : "\u00ABHow Clinical Guidelines Can Fail Both Doctors and Patients\u00BB http:\/\/t.co\/82z08vpIMh",
  "id" : 404407789701066752,
  "created_at" : "2013-11-24 00:35:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 67, 76 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/pApW5hA97y",
      "expanded_url" : "http:\/\/instagram.com\/p\/hElee2hwg4\/",
      "display_url" : "instagram.com\/p\/hElee2hwg4\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1121725609, 8.740817852 ]
  },
  "id_str" : "404356198369333248",
  "text" : "\u00ABI get a very murdery feeling from the crowd.\u00BB \u2014 Radical Face. \/HT @eramirez for the recommendation! http:\/\/t.co\/pApW5hA97y",
  "id" : 404356198369333248,
  "created_at" : "2013-11-23 21:10:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11217786, 8.74081854 ]
  },
  "id_str" : "404345546162597889",
  "text" : "\u00ABYou\u2019re all so quiet! It\u2019s almost as if you were listening to the stuff I\u2019m doing. I know, you\u2019re texting\u2026 But I\u2019ll keep that dream.\u00AB",
  "id" : 404345546162597889,
  "created_at" : "2013-11-23 20:27:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404338927345340416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11217786, 8.74081854 ]
  },
  "id_str" : "404339180505141248",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC it\u2019s always good to have a plan B. Enjoy that in the worst case :)",
  "id" : 404339180505141248,
  "in_reply_to_status_id" : 404338927345340416,
  "created_at" : "2013-11-23 20:02:27 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404336288259928065",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.112180201, 8.7408374245 ]
  },
  "id_str" : "404337709097189377",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC thinking about my organic chemistry courses \u2018good luck\u2019 feels more appropriate than \u2018enjoy\u2019.",
  "id" : 404337709097189377,
  "in_reply_to_status_id" : 404336288259928065,
  "created_at" : "2013-11-23 19:56:36 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/O0QEwrXbqG",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=zksJoIv5vak",
      "display_url" : "youtube.com\/watch?v=zksJoI\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.103828934, 8.6504158288 ]
  },
  "id_str" : "404321224102543360",
  "text" : "\u00ABBut all folks are damaged goods. It ain\u2019t a talk of \u201Cif,\u201D just one of \u201Cwhen\u201D and \u201Chow\u201D\u00BB http:\/\/t.co\/O0QEwrXbqG",
  "id" : 404321224102543360,
  "created_at" : "2013-11-23 18:51:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404317734533468160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1026076962, 8.544244602 ]
  },
  "id_str" : "404319199340036096",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng vergiss nicht schlechte Gewinner &amp; Verlierer unter \u2018bieten\u2019 zu erw\u00E4hnen ;)",
  "id" : 404319199340036096,
  "in_reply_to_status_id" : 404317734533468160,
  "created_at" : "2013-11-23 18:43:03 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1004357461, 8.5710425267 ]
  },
  "id_str" : "404050611081314304",
  "text" : "\u00ABMit der roten Armee die Weltherrschaft erringen &amp; dazu die Internationale spielen\u2026 Kein Wunder das der Verfassungsschutz dich beobachtet\u2026\u00BB",
  "id" : 404050611081314304,
  "created_at" : "2013-11-23 00:55:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1005589939, 8.5709521693 ]
  },
  "id_str" : "403975188519600128",
  "text" : "\u00ABSie hat mich gerade ganz b\u00F6se angeschaut und gezwungen die Flasche zu nehmen!\u00BB \u2014 \u00ABThat came out wrong\u2026\u00BB",
  "id" : 403975188519600128,
  "created_at" : "2013-11-22 19:56:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403883439171977217",
  "text" : "\u00ABSeltsam, eure Heizung ist ja auch gedrosselt. Nur unsere kann man ganz aufdrehen!\u00BB\u2013\u00ABSchon verstanden, ihr seid einfach das hei\u00DFeste B\u00FCro\u2026\u00BB",
  "id" : 403883439171977217,
  "created_at" : "2013-11-22 13:51:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/93PGSI0vKn",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/AskReddit\/comments\/1r57m0\/what_university_degree_do_you_have_and_what_job\/",
      "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403838229079543809",
  "text" : "\u00ABI have a B.S. in Journalism. I now build swingsets for a living. It's oddly satisfying.\u00BB http:\/\/t.co\/93PGSI0vKn",
  "id" : 403838229079543809,
  "created_at" : "2013-11-22 10:51:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/xqpWdwxnG0",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1655",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403819687261118464",
  "text" : "Step 4: take fetal position. Step 5: start to sob http:\/\/t.co\/xqpWdwxnG0",
  "id" : 403819687261118464,
  "created_at" : "2013-11-22 09:38:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403674858837782528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096734148, 8.2831335986 ]
  },
  "id_str" : "403675545231433730",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog afaik haben multi-drug resistant Acinetobacter schon bis zu 40% mortality.",
  "id" : 403675545231433730,
  "in_reply_to_status_id" : 403674858837782528,
  "created_at" : "2013-11-22 00:05:24 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/XY6LK7dviu",
      "expanded_url" : "http:\/\/i.imgur.com\/d5oC96kh.jpg",
      "display_url" : "i.imgur.com\/d5oC96kh.jpg"
    } ]
  },
  "in_reply_to_status_id_str" : "403659882772967424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "403659990814425088",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon not slacking off, looking for office decoration! http:\/\/t.co\/XY6LK7dviu",
  "id" : 403659990814425088,
  "in_reply_to_status_id" : 403659882772967424,
  "created_at" : "2013-11-21 23:03:36 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 3, 14 ],
      "id_str" : "20342875",
      "id" : 20342875
    }, {
      "name" : "Nik Papageorgiou",
      "screen_name" : "upmicblog",
      "indices" : [ 114, 124 ],
      "id_str" : "19063117",
      "id" : 19063117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webcomic",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/AlS5vhZ9Su",
      "expanded_url" : "http:\/\/wp.me\/pP1Q8-O3",
      "display_url" : "wp.me\/pP1Q8-O3"
    } ]
  },
  "geo" : { },
  "id_str" : "403635965753053184",
  "text" : "RT @LouWoodley: Wondering what happens if you break the lab safety rules...? http:\/\/t.co\/AlS5vhZ9Su #webcomic via @upmicblog",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nik Papageorgiou",
        "screen_name" : "upmicblog",
        "indices" : [ 98, 108 ],
        "id_str" : "19063117",
        "id" : 19063117
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "webcomic",
        "indices" : [ 84, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/AlS5vhZ9Su",
        "expanded_url" : "http:\/\/wp.me\/pP1Q8-O3",
        "display_url" : "wp.me\/pP1Q8-O3"
      } ]
    },
    "geo" : { },
    "id_str" : "403635394186850305",
    "text" : "Wondering what happens if you break the lab safety rules...? http:\/\/t.co\/AlS5vhZ9Su #webcomic via @upmicblog",
    "id" : 403635394186850305,
    "created_at" : "2013-11-21 21:25:51 +0000",
    "user" : {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "protected" : false,
      "id_str" : "20342875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/415633332408688640\/IRl4qNXY_normal.jpeg",
      "id" : 20342875,
      "verified" : false
    }
  },
  "id" : 403635965753053184,
  "created_at" : "2013-11-21 21:28:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/fxdvlpaV4I",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0079714",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "403627305777774593",
  "text" : "The Dual Effects of Critical Thinking Disposition on Worry http:\/\/t.co\/fxdvlpaV4I",
  "id" : 403627305777774593,
  "created_at" : "2013-11-21 20:53:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/8FqTgwSiOt",
      "expanded_url" : "http:\/\/i1159.photobucket.com\/albums\/p634\/electricpickles12\/tumblr_m6tfczWU8P1qe8r5ro3_250-1.gif",
      "display_url" : "i1159.photobucket.com\/albums\/p634\/el\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "403619004553904128",
  "text" : "\u00ABDeine Frontpage besteht ja nur aus B\u00E4rten\u2026\u00BB \u2013 \u00ABDas stimmt doch gar nicht, da sind auch Hunde und andere Tiere!\u00BB http:\/\/t.co\/8FqTgwSiOt",
  "id" : 403619004553904128,
  "created_at" : "2013-11-21 20:20:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "403608214836871168",
  "text" : "cryptographically secure pseudo-random acts of kindness",
  "id" : 403608214836871168,
  "created_at" : "2013-11-21 19:37:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly A. Hogan Ph.D.",
      "screen_name" : "Loose_Lab_Rat",
      "indices" : [ 3, 17 ],
      "id_str" : "316832974",
      "id" : 316832974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403606582661230592",
  "text" : "RT @Loose_Lab_Rat: \"Don't be arrogant because arrogance kills curiosity.\" -Mina Bissell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403534583859527680",
    "text" : "\"Don't be arrogant because arrogance kills curiosity.\" -Mina Bissell",
    "id" : 403534583859527680,
    "created_at" : "2013-11-21 14:45:16 +0000",
    "user" : {
      "name" : "Kelly A. Hogan Ph.D.",
      "screen_name" : "Loose_Lab_Rat",
      "protected" : false,
      "id_str" : "316832974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2157270091\/Kelly_Woods_Hole_3_color_normal.jpg",
      "id" : 316832974,
      "verified" : false
    }
  },
  "id" : 403606582661230592,
  "created_at" : "2013-11-21 19:31:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BioinfoTV",
      "indices" : [ 25, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0623712454, 8.529647527 ]
  },
  "id_str" : "403586542083796992",
  "text" : "Two and a half man pages #BioinfoTV",
  "id" : 403586542083796992,
  "created_at" : "2013-11-21 18:11:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bioinfoTV",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1020887784, 8.652093605 ]
  },
  "id_str" : "403583138380906496",
  "text" : "The SOAPranos #bioinfoTV",
  "id" : 403583138380906496,
  "created_at" : "2013-11-21 17:58:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172374771, 8.6276313665 ]
  },
  "id_str" : "403549580908044288",
  "text" : "\u00ABABSOLUTELY NOT RECOMMENDED AT ALL\u00BB just the option I was looking for!",
  "id" : 403549580908044288,
  "created_at" : "2013-11-21 15:44:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722718553, 8.6276412066 ]
  },
  "id_str" : "403542109036490752",
  "text" : "\u00ABWoher sollen wir denn wissen wie die Aufgaben \u2014 die wir euch gestellt haben \u2014 zu l\u00F6sen sind?\u00BB",
  "id" : 403542109036490752,
  "created_at" : "2013-11-21 15:15:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403491801895432192",
  "text" : "\u00ABAber das heisst doch das wir alle verwandt sind, wenn man das zu Ende denkt! Das ist ja widerlich!\u00BB Willkommen in der Evolutionsbiologie\u2026",
  "id" : 403491801895432192,
  "created_at" : "2013-11-21 11:55:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403436144802529281",
  "text" : "\u00ABDu hast heute morgen ausnahmsweise gar nicht gelacht, alles okay bei dir?\u00BB B\u00E4rtige U-Bahn-Mitfahrer beobachten mich.",
  "id" : 403436144802529281,
  "created_at" : "2013-11-21 08:14:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 22, 35 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096209534, 8.2829806209 ]
  },
  "id_str" : "403315743065784321",
  "text" : "\u00ABI can\u2019t come to bed! @PhilippBayer is wrong about date formatting! On the Internet!\u00BB",
  "id" : 403315743065784321,
  "created_at" : "2013-11-21 00:15:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403315042021421058",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096209534, 8.2829806209 ]
  },
  "id_str" : "403315261798760450",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer so that\u2019s why that folder is growing for me! :p",
  "id" : 403315261798760450,
  "in_reply_to_status_id" : 403315042021421058,
  "created_at" : "2013-11-21 00:13:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403314231790931969",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096671209, 8.283024324 ]
  },
  "id_str" : "403314712302989312",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you don\u2019t have a \u2018projects that I will maybe finish one day\u2019*-folder around that you can only ls with grep-magic? *never",
  "id" : 403314712302989312,
  "in_reply_to_status_id" : 403314231790931969,
  "created_at" : "2013-11-21 00:11:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403312339404853248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096776725, 8.2830693236 ]
  },
  "id_str" : "403313556080189440",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I don\u2019t care for ISO, I care for pain-free alphanum. sorting. You don\u2019t have enough projects if can get away with your format!",
  "id" : 403313556080189440,
  "in_reply_to_status_id" : 403312339404853248,
  "created_at" : "2013-11-21 00:06:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403311388111552513",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "403312146085183488",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer most shocking revelation: you use dd-m-yyyy over yyyy-mm-dd!",
  "id" : 403312146085183488,
  "in_reply_to_status_id" : 403311388111552513,
  "created_at" : "2013-11-21 00:01:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joonas M\u00E4kinen",
      "screen_name" : "JoonasD6",
      "indices" : [ 3, 12 ],
      "id_str" : "43360175",
      "id" : 43360175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/M7tMATyJwf",
      "expanded_url" : "http:\/\/j.mp\/1aH3H2D",
      "display_url" : "j.mp\/1aH3H2D"
    } ]
  },
  "geo" : { },
  "id_str" : "403310287161290753",
  "text" : "RT @JoonasD6: &lt;3 How to Find and Care for a Pet Tardigrade http:\/\/t.co\/M7tMATyJwf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/M7tMATyJwf",
        "expanded_url" : "http:\/\/j.mp\/1aH3H2D",
        "display_url" : "j.mp\/1aH3H2D"
      } ]
    },
    "geo" : { },
    "id_str" : "403308319177068544",
    "text" : "&lt;3 How to Find and Care for a Pet Tardigrade http:\/\/t.co\/M7tMATyJwf",
    "id" : 403308319177068544,
    "created_at" : "2013-11-20 23:46:11 +0000",
    "user" : {
      "name" : "Joonas M\u00E4kinen",
      "screen_name" : "JoonasD6",
      "protected" : false,
      "id_str" : "43360175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/238120339\/Pi3_150x150_normal.jpg",
      "id" : 43360175,
      "verified" : false
    }
  },
  "id" : 403310287161290753,
  "created_at" : "2013-11-20 23:54:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/Hz4c4Lsbeu",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/11\/20\/blade-runner-animated-as-1200.html",
      "display_url" : "boingboing.net\/2013\/11\/20\/bla\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "403281725364924416",
  "text" : "Blade Runner animated as 12,000 hand-painted watercolor\u00A0paintings (now w\/ 30 mins runtime) http:\/\/t.co\/Hz4c4Lsbeu",
  "id" : 403281725364924416,
  "created_at" : "2013-11-20 22:00:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/YKlHX9k8rD",
      "expanded_url" : "http:\/\/assets0.ordienetworks.com\/misc\/dog%20wtf.gif",
      "display_url" : "assets0.ordienetworks.com\/misc\/dog%20wtf\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "403273986634960896",
  "text" : "trying complex regular expressions http:\/\/t.co\/YKlHX9k8rD",
  "id" : 403273986634960896,
  "created_at" : "2013-11-20 21:29:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009619112, 8.282943352 ]
  },
  "id_str" : "403226622830313472",
  "text" : "\u00ABMach dir keine Hoffnungen, ich glaube nicht das wir irgendwann auch nur einen Nobel bekommen werden.\u00BB \u2013 \u00ABAber?! Nichtmal Frieden?!\u00BB",
  "id" : 403226622830313472,
  "created_at" : "2013-11-20 18:21:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172370963, 8.6275890654 ]
  },
  "id_str" : "403112010101313536",
  "text" : "\u00ABDu autonomes Teilst\u00FCckchen.\u00BB \u2014 \u00ABHast du mich gerade mit einer Schwarzw\u00E4lder Kirschtorte verglichen?!\u00BB",
  "id" : 403112010101313536,
  "created_at" : "2013-11-20 10:46:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 17, 27 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172300732, 8.627680432 ]
  },
  "id_str" : "403095855898832896",
  "text" : "GATGCTATGAAC! RT @edyong209: CGCATTCCGTTTCGCGAAGATAGCGCGAACGGCGAACGC :-(",
  "id" : 403095855898832896,
  "created_at" : "2013-11-20 09:41:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/TaT3FiDH9f",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/nature\/14048754",
      "display_url" : "bbc.co.uk\/nature\/14048754"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096249225, 8.2829494125 ]
  },
  "id_str" : "402947298608832513",
  "text" : "Tiny snails survive digestion by birds http:\/\/t.co\/TaT3FiDH9f",
  "id" : 402947298608832513,
  "created_at" : "2013-11-19 23:51:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/crW98A6Kiq",
      "expanded_url" : "http:\/\/vimeo.com\/47867150",
      "display_url" : "vimeo.com\/47867150"
    } ]
  },
  "geo" : { },
  "id_str" : "402946608821993472",
  "text" : "RT @PhilippBayer: \"This machine kills integrity\" http:\/\/t.co\/crW98A6Kiq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/crW98A6Kiq",
        "expanded_url" : "http:\/\/vimeo.com\/47867150",
        "display_url" : "vimeo.com\/47867150"
      } ]
    },
    "geo" : { },
    "id_str" : "402945919093469184",
    "text" : "\"This machine kills integrity\" http:\/\/t.co\/crW98A6Kiq",
    "id" : 402945919093469184,
    "created_at" : "2013-11-19 23:46:08 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 402946608821993472,
  "created_at" : "2013-11-19 23:48:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/SjD9qaM5yF",
      "expanded_url" : "http:\/\/what-if.xkcd.com\/72\/",
      "display_url" : "what-if.xkcd.com\/72\/"
    } ]
  },
  "geo" : { },
  "id_str" : "402944090641563648",
  "text" : "\u00ABIntroverts understand; the loneliest human in history was just happy to have a few minutes of peace and quiet.\u00BB http:\/\/t.co\/SjD9qaM5yF",
  "id" : 402944090641563648,
  "created_at" : "2013-11-19 23:38:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/ydxWorhCDd",
      "expanded_url" : "http:\/\/instagram.com\/p\/g6RqE-hwvn\/",
      "display_url" : "instagram.com\/p\/g6RqE-hwvn\/"
    } ]
  },
  "geo" : { },
  "id_str" : "402904721574596608",
  "text" : "Nazis riechen nicht so gut http:\/\/t.co\/ydxWorhCDd",
  "id" : 402904721574596608,
  "created_at" : "2013-11-19 21:02:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1040119848, 8.6973119318 ]
  },
  "id_str" : "402902626318446592",
  "text" : "\u00ABHast du gerade gelacht w\u00E4hrend ich an deiner Schulter geweint habe?!\u00BB \u2014 \u00ABJa, weil du dich so niedlich am meinem Bart festgekrallt hast.\u00BB",
  "id" : 402902626318446592,
  "created_at" : "2013-11-19 20:54:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402895054018076672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1016753705, 8.700055782 ]
  },
  "id_str" : "402902353680277504",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente Wikipedia sagt Glucose geht auch. Was man alles auf sich nimmt um Leute aus dem S\u00FCndenpfuhl PR in ehrliche Sexarbeit zu bringen\u2026",
  "id" : 402902353680277504,
  "in_reply_to_status_id" : 402895054018076672,
  "created_at" : "2013-11-19 20:53:01 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1163518458, 8.6848093879 ]
  },
  "id_str" : "402871450820157440",
  "text" : "\u00ABW\u00FCrdest du dir von mir den Hodensack aufpumpen lassen, damit ich \u00FCben kann?\u00BB \u2014 \u00ABWenn du dann endlich von der PR loskommst\u2026\u00BB",
  "id" : 402871450820157440,
  "created_at" : "2013-11-19 18:50:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1134576398, 8.6787519696 ]
  },
  "id_str" : "402848417162207232",
  "text" : "Nach Hungrig kommt Bl\u00F6d: Dem Sitznachbarn in der U-Bahn erst das Knie ins Gesicht hauen &amp; w\u00E4hrend der Entschuldigung auf den Fu\u00DF treten\u2026 m(",
  "id" : 402848417162207232,
  "created_at" : "2013-11-19 17:18:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3bXC3WZws2",
      "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2528",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722825215, 8.6276587438 ]
  },
  "id_str" : "402837671204388864",
  "text" : "Dinosaur Comics on polyamorous weaponizing of love: \u00ABWhat if a world leader is poly too?\u00BB\u2013\u00ABTHEN MAY GOD HELP US ALL\u00BB http:\/\/t.co\/3bXC3WZws2",
  "id" : 402837671204388864,
  "created_at" : "2013-11-19 16:35:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722825215, 8.6276587438 ]
  },
  "id_str" : "402835314466889728",
  "text" : "\u00ABHilfe, der Computer hat alle meine Daten gefressen!\u00BB \u2013 \u00ABNa, wer hat da nicht zugeh\u00F6rt als ich erkl\u00E4rt habe wie \u2018rm\u2019 funktioniert?\u00BB",
  "id" : 402835314466889728,
  "created_at" : "2013-11-19 16:26:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 109, 116 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/FVeBFvtwKQ",
      "expanded_url" : "http:\/\/www.robot-hugs.com\/comments\/",
      "display_url" : "robot-hugs.com\/comments\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722825215, 8.6276587438 ]
  },
  "id_str" : "402733170036334592",
  "text" : "Blog Comments: \u2018maybe people will be really thoughtful and supportive this time!\u2019 http:\/\/t.co\/FVeBFvtwKQ \/HT @acid23",
  "id" : 402733170036334592,
  "created_at" : "2013-11-19 09:40:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/bvCLAjZq8M",
      "expanded_url" : "http:\/\/www.edwardtufte.com\/tufte\/gould",
      "display_url" : "edwardtufte.com\/tufte\/gould"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722825215, 8.6276587438 ]
  },
  "id_str" : "402708915093520384",
  "text" : "The Median Isn't the Message: \u00ABall evol. biologists know that variation itself is nature's only irreducible essence\u00BB http:\/\/t.co\/bvCLAjZq8M",
  "id" : 402708915093520384,
  "created_at" : "2013-11-19 08:04:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 72, 85 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/cbgCgR7sn6",
      "expanded_url" : "http:\/\/www.tor.com\/blogs\/2013\/11\/surprise-fear-and-an-almost-fanatical-dedication-to-the-womack",
      "display_url" : "tor.com\/blogs\/2013\/11\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172321785, 8.62763263 ]
  },
  "id_str" : "402705782099443712",
  "text" : "Praise for Random Acts of Senseless Violence http:\/\/t.co\/cbgCgR7sn6 \/cc @PhilippBayer",
  "id" : 402705782099443712,
  "created_at" : "2013-11-19 07:51:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/yRXExAKNT0",
      "expanded_url" : "http:\/\/m.imgur.com\/a\/d7d6t",
      "display_url" : "m.imgur.com\/a\/d7d6t"
    } ]
  },
  "geo" : { },
  "id_str" : "402695444406734850",
  "text" : "How-To: Break Bad News http:\/\/t.co\/yRXExAKNT0",
  "id" : 402695444406734850,
  "created_at" : "2013-11-19 07:10:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402596152106692608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096249225, 8.2829494125 ]
  },
  "id_str" : "402596349369389056",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch there was some issue because I printed it in B\/W and they needed color or something like that. :D",
  "id" : 402596349369389056,
  "in_reply_to_status_id" : 402596152106692608,
  "created_at" : "2013-11-19 00:37:04 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402595207922724864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096249225, 8.2829494125 ]
  },
  "id_str" : "402596066673307648",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch will investigate that tomorrow. :)",
  "id" : 402596066673307648,
  "in_reply_to_status_id" : 402595207922724864,
  "created_at" : "2013-11-19 00:35:56 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402595207922724864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096249225, 8.2829494125 ]
  },
  "id_str" : "402596028475400192",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch yes, though I guess our time is still not running as I haven\u2019t heard  the final word on the contract.",
  "id" : 402596028475400192,
  "in_reply_to_status_id" : 402595207922724864,
  "created_at" : "2013-11-19 00:35:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/VFOfkSzfAZ",
      "expanded_url" : "http:\/\/imgur.com\/ejW2XeU",
      "display_url" : "imgur.com\/ejW2XeU"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096249225, 8.2829494125 ]
  },
  "id_str" : "402595247760609280",
  "text" : "\u00ABThe Banana \u2013 A New, More Forgiving Unit of Measure.\u00BB Don\u2019t use for: Banana Costumes, it will create a paradox. http:\/\/t.co\/VFOfkSzfAZ",
  "id" : 402595247760609280,
  "created_at" : "2013-11-19 00:32:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 94, 106 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402594461043007488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096249225, 8.2829494125 ]
  },
  "id_str" : "402594923008233472",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer meh, too bad. Maybe we should use the Bayer grant either to fly you over or for @helgerausch and I to visit you :D",
  "id" : 402594923008233472,
  "in_reply_to_status_id" : 402594461043007488,
  "created_at" : "2013-11-19 00:31:24 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402592605482938368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096249225, 8.2829494125 ]
  },
  "id_str" : "402593871856947200",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer should change that, will you come over for the holidays?",
  "id" : 402593871856947200,
  "in_reply_to_status_id" : 402592605482938368,
  "created_at" : "2013-11-19 00:27:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402592148664500224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096249225, 8.2829494125 ]
  },
  "id_str" : "402592441968390144",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I\u2019m sorry for your loss! (but same here, that weird pseudo-grown-up-stuff that keeps happening all the time!)",
  "id" : 402592441968390144,
  "in_reply_to_status_id" : 402592148664500224,
  "created_at" : "2013-11-19 00:21:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402591715858456576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096249225, 8.2829494125 ]
  },
  "id_str" : "402591898059436032",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer no hurries, just wondered. Preparing course work efficiently kept me from doing it (well, that and getting drunk on the WE).",
  "id" : 402591898059436032,
  "in_reply_to_status_id" : 402591715858456576,
  "created_at" : "2013-11-19 00:19:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402591083822977024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096249225, 8.2829494125 ]
  },
  "id_str" : "402591274362212352",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer speaking of server side stuff: any news on the EC2 BTC stuff?",
  "id" : 402591274362212352,
  "in_reply_to_status_id" : 402591083822977024,
  "created_at" : "2013-11-19 00:16:54 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402588389213351936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096249225, 8.2829494125 ]
  },
  "id_str" : "402590225668767744",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer wow, bokeh looks awesome. :D",
  "id" : 402590225668767744,
  "in_reply_to_status_id" : 402588389213351936,
  "created_at" : "2013-11-19 00:12:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00961938, 8.282873035 ]
  },
  "id_str" : "402585158928588800",
  "text" : "\u00ABthe \u201C2-body problem\u201D is the problem of maintaining a commit. relationship between 2 individuals who are trying to have careers in academia\u00BB",
  "id" : 402585158928588800,
  "created_at" : "2013-11-18 23:52:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Siobhan O'Dwyer",
      "screen_name" : "Siobhan_ODwyer",
      "indices" : [ 3, 18 ],
      "id_str" : "558161717",
      "id" : 558161717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402584934629801984",
  "text" : "RT @Siobhan_ODwyer: \"Academia is best suited to those with no relationships, who travel light &amp; have their passport at the ready\" http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/h1JIdMwSzP",
        "expanded_url" : "http:\/\/bit.ly\/1hSTPcv",
        "display_url" : "bit.ly\/1hSTPcv"
      } ]
    },
    "geo" : { },
    "id_str" : "402571383596539906",
    "text" : "\"Academia is best suited to those with no relationships, who travel light &amp; have their passport at the ready\" http:\/\/t.co\/h1JIdMwSzP",
    "id" : 402571383596539906,
    "created_at" : "2013-11-18 22:57:51 +0000",
    "user" : {
      "name" : "Dr Siobhan O'Dwyer",
      "screen_name" : "Siobhan_ODwyer",
      "protected" : false,
      "id_str" : "558161717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/900552266595303426\/7FfklVEL_normal.jpg",
      "id" : 558161717,
      "verified" : false
    }
  },
  "id" : 402584934629801984,
  "created_at" : "2013-11-18 23:51:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402582605679185921",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00961938, 8.282873035 ]
  },
  "id_str" : "402583010413125634",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer haha, thanks. Read it a couple of days ago. Thought I had tweeted that as well and cc\u2019d you :)",
  "id" : 402583010413125634,
  "in_reply_to_status_id" : 402582605679185921,
  "created_at" : "2013-11-18 23:44:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00961938, 8.282873035 ]
  },
  "id_str" : "402582739075223552",
  "text" : "\u00ABOrrr, Kater! Du stinkst!\u00BB \u2013 \u00ABNope, das bin ich!\u00BB",
  "id" : 402582739075223552,
  "created_at" : "2013-11-18 23:42:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 96, 109 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/1Tyo1uZuoK",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0079345",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00961938, 8.282873035 ]
  },
  "id_str" : "402582439081824257",
  "text" : "StochPy: A Comprehensive, User-Friendly Tool for Simulating Stochastic Biological Processes \/cc @PhilippBayer http:\/\/t.co\/1Tyo1uZuoK",
  "id" : 402582439081824257,
  "created_at" : "2013-11-18 23:41:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/PWqTvlYoLM",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=aiBt44rrslw",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00961938, 8.282873035 ]
  },
  "id_str" : "402582097589985280",
  "text" : "Alfonso Cuar\u00F3n's \"IKEA\" - Official Trailer http:\/\/t.co\/PWqTvlYoLM",
  "id" : 402582097589985280,
  "created_at" : "2013-11-18 23:40:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/37Qk2nqXlq",
      "expanded_url" : "http:\/\/www.crackajack.de\/2013\/11\/18\/20-years-of-nirvana-unplugged\/",
      "display_url" : "crackajack.de\/2013\/11\/18\/20-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00961938, 8.282873035 ]
  },
  "id_str" : "402578329926397953",
  "text" : "20 Years of Nirvana Unplugged http:\/\/t.co\/37Qk2nqXlq",
  "id" : 402578329926397953,
  "created_at" : "2013-11-18 23:25:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/cGrtd67ycy",
      "expanded_url" : "http:\/\/i.imgur.com\/DJsl8yF.gif",
      "display_url" : "i.imgur.com\/DJsl8yF.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009647398, 8.283037836 ]
  },
  "id_str" : "402561338347900929",
  "text" : "i need to go http:\/\/t.co\/cGrtd67ycy",
  "id" : 402561338347900929,
  "created_at" : "2013-11-18 22:17:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/dopKCDRB4A",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/christopher-emdin\/children-science_b_1081642.html",
      "display_url" : "huffingtonpost.com\/christopher-em\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009647398, 8.283037836 ]
  },
  "id_str" : "402558843361984512",
  "text" : "\u00ABGood grades in science will not make you a scientist.\u00BB At least not given the current curricula http:\/\/t.co\/dopKCDRB4A",
  "id" : 402558843361984512,
  "created_at" : "2013-11-18 22:08:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/xbPdhDscVJ",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/AskReddit\/comments\/1qoyn2\/assume_all_of_world_history_is_a_movie_what_are\/",
      "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009647398, 8.283037836 ]
  },
  "id_str" : "402553656987648000",
  "text" : "\u00ABAssume all of world history is a movie. What are the biggest plotholes?\u00BB http:\/\/t.co\/xbPdhDscVJ",
  "id" : 402553656987648000,
  "created_at" : "2013-11-18 21:47:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009647398, 8.283037836 ]
  },
  "id_str" : "402552283835420672",
  "text" : "\u00ABMach den Reiskocher an: Wenn wir mit kuscheln fertig sind ist der Reis fertig.\u00BB \u2013 \u00ABDu meinst: Genug gekuschelt wenn der Reis fertig ist.\u00BB",
  "id" : 402552283835420672,
  "created_at" : "2013-11-18 21:41:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/yGatXkniNF",
      "expanded_url" : "http:\/\/newswatch.nationalgeographic.com\/2013\/11\/05\/repurposed-private-parts-5-animals-use-genitals-creative-purposes\/",
      "display_url" : "newswatch.nationalgeographic.com\/2013\/11\/05\/rep\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096119533, 8.2828875567 ]
  },
  "id_str" : "402539851868016640",
  "text" : "5 Unexpected Ways Animals Use Their Genitals (How did I not know about Micronecta!) http:\/\/t.co\/yGatXkniNF",
  "id" : 402539851868016640,
  "created_at" : "2013-11-18 20:52:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "History In Pictures",
      "screen_name" : "HistoryInPics",
      "indices" : [ 3, 17 ],
      "id_str" : "1582853809",
      "id" : 1582853809
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HistoryInPics\/status\/401321460331184129\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/Naoc6DS64x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZHHvdzIQAAXmrF.jpg",
      "id_str" : "401321460079542272",
      "id" : 401321460079542272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZHHvdzIQAAXmrF.jpg",
      "sizes" : [ {
        "h" : 747,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 747,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 747,
        "resize" : "fit",
        "w" : 749
      } ],
      "display_url" : "pic.twitter.com\/Naoc6DS64x"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402538497984446464",
  "text" : "RT @HistoryInPics: Yearbook pictures of rock and metal icons. http:\/\/t.co\/Naoc6DS64x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HistoryInPics\/status\/401321460331184129\/photo\/1",
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/Naoc6DS64x",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZHHvdzIQAAXmrF.jpg",
        "id_str" : "401321460079542272",
        "id" : 401321460079542272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZHHvdzIQAAXmrF.jpg",
        "sizes" : [ {
          "h" : 747,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 747,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 747,
          "resize" : "fit",
          "w" : 749
        } ],
        "display_url" : "pic.twitter.com\/Naoc6DS64x"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401321460331184129",
    "text" : "Yearbook pictures of rock and metal icons. http:\/\/t.co\/Naoc6DS64x",
    "id" : 401321460331184129,
    "created_at" : "2013-11-15 12:11:06 +0000",
    "user" : {
      "name" : "History In Pictures",
      "screen_name" : "HistoryInPics",
      "protected" : false,
      "id_str" : "1582853809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723564356693192705\/IV1fgh7G_normal.jpg",
      "id" : 1582853809,
      "verified" : false
    }
  },
  "id" : 402538497984446464,
  "created_at" : "2013-11-18 20:47:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/CuHY41LQts",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3179",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096119533, 8.2828875567 ]
  },
  "id_str" : "402536741631844352",
  "text" : "Neuromancer http:\/\/t.co\/CuHY41LQts",
  "id" : 402536741631844352,
  "created_at" : "2013-11-18 20:40:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0948411756, 8.673158344 ]
  },
  "id_str" : "402521782298873857",
  "text" : "\u00ABWas l\u00E4uft in deinem Kopfkino so?\u00BB \u2014 \u00ABMeistens Gangbang. Manchmal auch das ich von einem Pferd gefickt werde. Ganz unterschiedlich.\u00BB",
  "id" : 402521782298873857,
  "created_at" : "2013-11-18 19:40:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.099508022, 8.6867596116 ]
  },
  "id_str" : "402517409732788224",
  "text" : "Dass ich mal einen TV-Gig nicht bekommen w\u00FCrde weil ich auf der falschen Rheinseite wohne\u2026 o_O",
  "id" : 402517409732788224,
  "created_at" : "2013-11-18 19:23:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1567028987, 8.6563831112 ]
  },
  "id_str" : "402482244969070592",
  "text" : "\u00ABWir k\u00F6nnen noch Platten f\u00FCrs Cluster kaufen. Noch nagen wir nicht am Hungertuch.\u00BB \u2014 \u00ABF\u00FCr dich ist das einfach zu sagen, du isst ein Brot!\u00BB",
  "id" : 402482244969070592,
  "created_at" : "2013-11-18 17:03:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096123619, 8.2829247136 ]
  },
  "id_str" : "402451566969757696",
  "text" : "\u00ABWolltest du deinen Bart nicht wachsen lassen bis du deinen Doktor hast?\u00BB \u2014 \u00ABLeg den Finger in die Wunde\u2026\u00BB",
  "id" : 402451566969757696,
  "created_at" : "2013-11-18 15:01:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/CmUYH21ePh",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/67281114972\/story-of-my-life",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/672811149\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722822969, 8.6276589585 ]
  },
  "id_str" : "402447606322069505",
  "text" : "story of my life http:\/\/t.co\/CmUYH21ePh",
  "id" : 402447606322069505,
  "created_at" : "2013-11-18 14:46:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722822969, 8.6276589585 ]
  },
  "id_str" : "402444596472721409",
  "text" : "\u00ABNat\u00FCrlich verlasse ich dich nicht. Bis ich jemanden besseren gefunden habe.\u00BB",
  "id" : 402444596472721409,
  "created_at" : "2013-11-18 14:34:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402394474082357248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722822969, 8.6276589585 ]
  },
  "id_str" : "402438305239007233",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, the writing is great. Makes speed reading really easy.",
  "id" : 402438305239007233,
  "in_reply_to_status_id" : 402394474082357248,
  "created_at" : "2013-11-18 14:09:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.thunderclap.it\" rel=\"nofollow\"\u003EThunderclap\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oabuttonlaunch",
      "indices" : [ 100, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/wcHK7VG0ZX",
      "expanded_url" : "http:\/\/thndr.it\/1atMFSK",
      "display_url" : "thndr.it\/1atMFSK"
    } ]
  },
  "geo" : { },
  "id_str" : "402437549823897600",
  "text" : "Paywalls hide knowledge and stifle innovation, help map their impact and get the research you need. #oabuttonlaunch http:\/\/t.co\/wcHK7VG0ZX",
  "id" : 402437549823897600,
  "created_at" : "2013-11-18 14:06:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402207961868541952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.14115389, 8.57980127 ]
  },
  "id_str" : "402345819405582337",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer guess I did catch up with Complexity by now. (Reading about PopGen History once again ;)) Fun so far!",
  "id" : 402345819405582337,
  "in_reply_to_status_id" : 402207961868541952,
  "created_at" : "2013-11-18 08:01:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/XSeG7hFxH4",
      "expanded_url" : "http:\/\/www.nature.com\/nature\/journal\/v456\/n7220\/full\/nature07309.html",
      "display_url" : "nature.com\/nature\/journal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402238051969413120",
  "text" : "RT @PhilippBayer: \"Acoel development indicates the independent evolution of the bilaterian mouth and anus\" http:\/\/t.co\/XSeG7hFxH4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/XSeG7hFxH4",
        "expanded_url" : "http:\/\/www.nature.com\/nature\/journal\/v456\/n7220\/full\/nature07309.html",
        "display_url" : "nature.com\/nature\/journal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "402236747494346753",
    "text" : "\"Acoel development indicates the independent evolution of the bilaterian mouth and anus\" http:\/\/t.co\/XSeG7hFxH4",
    "id" : 402236747494346753,
    "created_at" : "2013-11-18 00:48:08 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 402238051969413120,
  "created_at" : "2013-11-18 00:53:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 126, 139 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/mP1oSAmgdb",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/bering-in-mind\/2010\/10\/20\/being-suicidal-what-it-feels-like-to-want-to-kill-yourself\/",
      "display_url" : "blogs.scientificamerican.com\/bering-in-mind\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00959582, 8.28292084 ]
  },
  "id_str" : "402202341061197824",
  "text" : "On Life &amp; Suicide: \u00ABBear in mind that there\u2019s no such thing as a failed experiment\u2014only data.\u00BB http:\/\/t.co\/mP1oSAmgdb \/HT @PhilippBayer",
  "id" : 402202341061197824,
  "created_at" : "2013-11-17 22:31:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402193808890146816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00959582, 8.28292084 ]
  },
  "id_str" : "402199472484392960",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer did you give it a try or is it based on the shiny docs? :D",
  "id" : 402199472484392960,
  "in_reply_to_status_id" : 402193808890146816,
  "created_at" : "2013-11-17 22:20:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 45, 58 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/2xxRPFjaQF",
      "expanded_url" : "http:\/\/docopt.org\/",
      "display_url" : "docopt.org"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00959582, 8.28292084 ]
  },
  "id_str" : "402199389294575616",
  "text" : "This looks like pure &lt;3 on first sight RT @PhilippBayer: I might replace argparse with this: http:\/\/t.co\/2xxRPFjaQF",
  "id" : 402199389294575616,
  "created_at" : "2013-11-17 22:19:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/nOxEuLUjQa",
      "expanded_url" : "http:\/\/i.imgur.com\/bD3OfGW.jpg?1",
      "display_url" : "i.imgur.com\/bD3OfGW.jpg?1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096721475, 8.2830422925 ]
  },
  "id_str" : "402183470543548417",
  "text" : "Not again! http:\/\/t.co\/nOxEuLUjQa",
  "id" : 402183470543548417,
  "created_at" : "2013-11-17 21:16:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helmut Wicht",
      "screen_name" : "h_wicht",
      "indices" : [ 0, 8 ],
      "id_str" : "322062420",
      "id" : 322062420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402148627646140417",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095961025, 8.282920225 ]
  },
  "id_str" : "402148780914790400",
  "in_reply_to_user_id" : 322062420,
  "text" : "@h_wicht Keine Sorge, in dem Blog gibt es auch ganz viel was tot und ganz nett geschrieben ist.",
  "id" : 402148780914790400,
  "in_reply_to_status_id" : 402148627646140417,
  "created_at" : "2013-11-17 18:58:35 +0000",
  "in_reply_to_screen_name" : "h_wicht",
  "in_reply_to_user_id_str" : "322062420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402146113907851264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095961025, 8.282920225 ]
  },
  "id_str" : "402146387972096000",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy Hast du und ich war beim lesen kurz verwirrt ob es das Wappentier der Republik 2.0 werden soll. :)",
  "id" : 402146387972096000,
  "in_reply_to_status_id" : 402146113907851264,
  "created_at" : "2013-11-17 18:49:05 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 10, 14 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402144335854309376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095961025, 8.282920225 ]
  },
  "id_str" : "402145303849365506",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @scy psst, versau mir doch nicht die Anmache ;)",
  "id" : 402145303849365506,
  "in_reply_to_status_id" : 402144335854309376,
  "created_at" : "2013-11-17 18:44:46 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402141679211540481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095961025, 8.282920225 ]
  },
  "id_str" : "402142093378060288",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy und f\u00FCr dich ist es eine neue Herausforderung: Den Bart farbfrei zu lassen :P",
  "id" : 402142093378060288,
  "in_reply_to_status_id" : 402141679211540481,
  "created_at" : "2013-11-17 18:32:01 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402140812051746816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095961025, 8.282920225 ]
  },
  "id_str" : "402141011109240832",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy die Chance mich \u00B1 nackt auf dem Sofa sitzen zu haben und mit mir Cocktails zu trinken? ;)",
  "id" : 402141011109240832,
  "in_reply_to_status_id" : 402140812051746816,
  "created_at" : "2013-11-17 18:27:43 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 69, 78 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402139994477039616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095961025, 8.282920225 ]
  },
  "id_str" : "402140427480203264",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy dann kann ich dich also darum bitten das bei mir zu machen wenn @Senficon mal wieder l\u00E4nger unterwegs ist? ;)",
  "id" : 402140427480203264,
  "in_reply_to_status_id" : 402139994477039616,
  "created_at" : "2013-11-17 18:25:23 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/4otfvKGUZS",
      "expanded_url" : "http:\/\/arsanatomica.tumblr.com\/post\/55946121477",
      "display_url" : "arsanatomica.tumblr.com\/post\/559461214\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095961025, 8.282920225 ]
  },
  "id_str" : "402137111463493633",
  "text" : "Student Errors: \u00ABThe\u00A0platypus\u00A0lives in [\u2026]\u00A0Australia not in your chest cavity. Although that might be pretty awesome\u00BB http:\/\/t.co\/4otfvKGUZS",
  "id" : 402137111463493633,
  "created_at" : "2013-11-17 18:12:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/bfAOxs5nyQ",
      "expanded_url" : "http:\/\/arsanatomica.tumblr.com\/post\/66955678329",
      "display_url" : "arsanatomica.tumblr.com\/post\/669556783\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095961025, 8.282920225 ]
  },
  "id_str" : "402135424434724864",
  "text" : "Inflating a set of cat lungs http:\/\/t.co\/bfAOxs5nyQ",
  "id" : 402135424434724864,
  "created_at" : "2013-11-17 18:05:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helmut Wicht",
      "screen_name" : "h_wicht",
      "indices" : [ 0, 8 ],
      "id_str" : "322062420",
      "id" : 322062420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/Fpym9wbGka",
      "expanded_url" : "http:\/\/arsanatomica.tumblr.com\/",
      "display_url" : "arsanatomica.tumblr.com"
    } ]
  },
  "in_reply_to_status_id_str" : "402135017515528192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095961025, 8.282920225 ]
  },
  "id_str" : "402135336249483266",
  "in_reply_to_user_id" : 322062420,
  "text" : "@h_wicht Ist das was f\u00FCr dich? http:\/\/t.co\/Fpym9wbGka",
  "id" : 402135336249483266,
  "in_reply_to_status_id" : 402135017515528192,
  "created_at" : "2013-11-17 18:05:10 +0000",
  "in_reply_to_screen_name" : "h_wicht",
  "in_reply_to_user_id_str" : "322062420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/XIai3L33HT",
      "expanded_url" : "http:\/\/dasnuf.de\/kinder-kinder\/sockenkaspar\/",
      "display_url" : "dasnuf.de\/kinder-kinder\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095961025, 8.282920225 ]
  },
  "id_str" : "402133487408668672",
  "text" : "\u00ABAn Erziehung glaube ich nicht. Die Kinder werden so geboren wie sie sind und dann wachsen sie einfach.\u00BB http:\/\/t.co\/XIai3L33HT",
  "id" : 402133487408668672,
  "created_at" : "2013-11-17 17:57:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torben Lasch",
      "screen_name" : "hmpf22",
      "indices" : [ 0, 7 ],
      "id_str" : "73732784",
      "id" : 73732784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402133145346408448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095961025, 8.282920225 ]
  },
  "id_str" : "402133355061587969",
  "in_reply_to_user_id" : 73732784,
  "text" : "@hmpf22 Verwendungszweck f\u00FCr die Tiersammelbildchen vom Supermarkt: Gefunden! ;)",
  "id" : 402133355061587969,
  "in_reply_to_status_id" : 402133145346408448,
  "created_at" : "2013-11-17 17:57:17 +0000",
  "in_reply_to_screen_name" : "hmpf22",
  "in_reply_to_user_id_str" : "73732784",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Schwanbeck",
      "screen_name" : "GregSchwanbeck",
      "indices" : [ 3, 18 ],
      "id_str" : "76152210",
      "id" : 76152210
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "physicsed",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402131785716629505",
  "text" : "RT @GregSchwanbeck: Beautiful picture of a fighter jet firing flares while rolling is a great visual of Newton's 1st Law. #physicsed http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GregSchwanbeck\/status\/402122621229080576\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/uYZCguDDKs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZSgZLsCIAAXzUs.jpg",
        "id_str" : "402122621237469184",
        "id" : 402122621237469184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZSgZLsCIAAXzUs.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/uYZCguDDKs"
      } ],
      "hashtags" : [ {
        "text" : "physicsed",
        "indices" : [ 102, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "402122621229080576",
    "text" : "Beautiful picture of a fighter jet firing flares while rolling is a great visual of Newton's 1st Law. #physicsed http:\/\/t.co\/uYZCguDDKs",
    "id" : 402122621229080576,
    "created_at" : "2013-11-17 17:14:38 +0000",
    "user" : {
      "name" : "Greg Schwanbeck",
      "screen_name" : "GregSchwanbeck",
      "protected" : false,
      "id_str" : "76152210",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/830072370111082497\/9XdDg1LO_normal.jpg",
      "id" : 76152210,
      "verified" : false
    }
  },
  "id" : 402131785716629505,
  "created_at" : "2013-11-17 17:51:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Kuszewski \uD83E\uDDE0",
      "screen_name" : "AndreaKuszewski",
      "indices" : [ 3, 19 ],
      "id_str" : "15150453",
      "id" : 15150453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/bwHrZJYMRk",
      "expanded_url" : "http:\/\/sfist.com\/2013\/11\/15\/photos_batkid_saves_gotham_wins_san.php",
      "display_url" : "sfist.com\/2013\/11\/15\/pho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402130173052862464",
  "text" : "RT @AndreaKuszewski: These make me all weepy. &lt;3 Photos: Batkid Saves Gotham City, Wins San Francisco's Heart http:\/\/t.co\/bwHrZJYMRk via @",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/bwHrZJYMRk",
        "expanded_url" : "http:\/\/sfist.com\/2013\/11\/15\/photos_batkid_saves_gotham_wins_san.php",
        "display_url" : "sfist.com\/2013\/11\/15\/pho\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "402128569796534272",
    "text" : "These make me all weepy. &lt;3 Photos: Batkid Saves Gotham City, Wins San Francisco's Heart http:\/\/t.co\/bwHrZJYMRk via @",
    "id" : 402128569796534272,
    "created_at" : "2013-11-17 17:38:16 +0000",
    "user" : {
      "name" : "Andrea Kuszewski \uD83E\uDDE0",
      "screen_name" : "AndreaKuszewski",
      "protected" : false,
      "id_str" : "15150453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879595697800060928\/-tdsZ4nM_normal.jpg",
      "id" : 15150453,
      "verified" : true
    }
  },
  "id" : 402130173052862464,
  "created_at" : "2013-11-17 17:44:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 0, 9 ],
      "id_str" : "81582697",
      "id" : 81582697
    }, {
      "name" : "Julian Finn",
      "screen_name" : "hdsjulian",
      "indices" : [ 10, 20 ],
      "id_str" : "12192142",
      "id" : 12192142
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 21, 30 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/bkuK8nCcRn",
      "expanded_url" : "http:\/\/i.imgur.com\/e4et3.gif",
      "display_url" : "i.imgur.com\/e4et3.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "402126133275402242",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095961025, 8.282920225 ]
  },
  "id_str" : "402127268660908032",
  "in_reply_to_user_id" : 81582697,
  "text" : "@viirus42 @hdsjulian @Senficon entweder sie wird in ihrem Alter senil, oder es ist: http:\/\/t.co\/bkuK8nCcRn (symbolbild)",
  "id" : 402127268660908032,
  "in_reply_to_status_id" : 402126133275402242,
  "created_at" : "2013-11-17 17:33:06 +0000",
  "in_reply_to_screen_name" : "viirus42",
  "in_reply_to_user_id_str" : "81582697",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095961025, 8.282920225 ]
  },
  "id_str" : "402125988202807296",
  "text" : "Die Katze macht deutlich was sie von meiner Autorit\u00E4t &amp; der \u201CNicht auf den Esstisch klettern\u201D-Regel h\u00E4lt: Sie scheisst drauf.",
  "id" : 402125988202807296,
  "created_at" : "2013-11-17 17:28:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009647498, 8.283037198 ]
  },
  "id_str" : "402124891706916864",
  "text" : "\u00ABBut no one wants to be boring.\u00BB \u2013 \u00ABNobody knows they're boring.\u00BB \u2013 \u00ABBut they can learn. And I feel like you're here to teach us.\u00BB &lt;3",
  "id" : 402124891706916864,
  "created_at" : "2013-11-17 17:23:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/Fjh4f8zqIy",
      "expanded_url" : "http:\/\/www.thisamericanlife.org\/radio-archives\/episode\/511\/the-seven-things-youre-not-supposed-to-talk-about",
      "display_url" : "thisamericanlife.org\/radio-archives\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0045620642, 8.2635159699 ]
  },
  "id_str" : "402111870532063233",
  "text" : "The Seven Things You\u2019re Not Supposed to Talk About http:\/\/t.co\/Fjh4f8zqIy",
  "id" : 402111870532063233,
  "created_at" : "2013-11-17 16:31:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/NOjXy4j8bE",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=eGIrppp9zLg",
      "display_url" : "youtube.com\/watch?v=eGIrpp\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009647498, 8.283037198 ]
  },
  "id_str" : "402066966514761728",
  "text" : "\u00ABWell, if she thinks Pope Francis is liberal, wait until she sees what Jesus has been saying\u00BB http:\/\/t.co\/NOjXy4j8bE",
  "id" : 402066966514761728,
  "created_at" : "2013-11-17 13:33:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trish Groves",
      "screen_name" : "trished",
      "indices" : [ 3, 11 ],
      "id_str" : "16947313",
      "id" : 16947313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheBMJ",
      "indices" : [ 35, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/o5Dt6ipYEF",
      "expanded_url" : "http:\/\/www.bmj.com\/content\/347\/bmj.f6631",
      "display_url" : "bmj.com\/content\/347\/bm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401891037599510528",
  "text" : "RT @trished: Christmas competition #TheBMJ http:\/\/t.co\/o5Dt6ipYEF \n\nChristmas BMJ\n\nwill examine haiku as\n\nresearch medium",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TheBMJ",
        "indices" : [ 22, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/o5Dt6ipYEF",
        "expanded_url" : "http:\/\/www.bmj.com\/content\/347\/bmj.f6631",
        "display_url" : "bmj.com\/content\/347\/bm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "401879159330177024",
    "text" : "Christmas competition #TheBMJ http:\/\/t.co\/o5Dt6ipYEF \n\nChristmas BMJ\n\nwill examine haiku as\n\nresearch medium",
    "id" : 401879159330177024,
    "created_at" : "2013-11-17 01:07:12 +0000",
    "user" : {
      "name" : "Trish Groves",
      "screen_name" : "trished",
      "protected" : false,
      "id_str" : "16947313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737630194257661952\/648PVMij_normal.jpg",
      "id" : 16947313,
      "verified" : false
    }
  },
  "id" : 401891037599510528,
  "created_at" : "2013-11-17 01:54:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/nzgT8dzJWS",
      "expanded_url" : "http:\/\/i.imgur.com\/12W8bQ6.gif",
      "display_url" : "i.imgur.com\/12W8bQ6.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095959367, 8.28292037 ]
  },
  "id_str" : "401885624921518080",
  "text" : "Happiness: It goes up to eleven! http:\/\/t.co\/nzgT8dzJWS",
  "id" : 401885624921518080,
  "created_at" : "2013-11-17 01:32:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401855898391302144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096018409, 8.2829194055 ]
  },
  "id_str" : "401856575633358848",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon thanks for pointing it out, hadn\u2019t noticed that!",
  "id" : 401856575633358848,
  "in_reply_to_status_id" : 401855898391302144,
  "created_at" : "2013-11-16 23:37:28 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/xZjhEFNSku",
      "expanded_url" : "http:\/\/www.terminalcornucopia.com\/",
      "display_url" : "terminalcornucopia.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095959367, 8.28292037 ]
  },
  "id_str" : "401852484135964672",
  "text" : "Can common items sold in airports after the security screening be used to build lethal weapons? http:\/\/t.co\/xZjhEFNSku",
  "id" : 401852484135964672,
  "created_at" : "2013-11-16 23:21:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/cjzxNExfzj",
      "expanded_url" : "http:\/\/i.imgur.com\/0Cbc6tc.gif",
      "display_url" : "i.imgur.com\/0Cbc6tc.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095959367, 8.28292037 ]
  },
  "id_str" : "401831554559004672",
  "text" : "airwolf http:\/\/t.co\/cjzxNExfzj",
  "id" : 401831554559004672,
  "created_at" : "2013-11-16 21:58:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/GxLsvvrLLK",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/11\/15\/sleeping-on-strangers-on-the-s.html",
      "display_url" : "boingboing.net\/2013\/11\/15\/sle\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00959338, 8.28285132 ]
  },
  "id_str" : "401786550276853761",
  "text" : "'Sleeping On Strangers On The Subway,' a video\u00A0experiment http:\/\/t.co\/GxLsvvrLLK",
  "id" : 401786550276853761,
  "created_at" : "2013-11-16 18:59:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/Feki0CA9F8",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3177",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00959338, 8.28285132 ]
  },
  "id_str" : "401785500132212737",
  "text" : "Never have I ever\u2026 http:\/\/t.co\/Feki0CA9F8",
  "id" : 401785500132212737,
  "created_at" : "2013-11-16 18:55:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 7, 14 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401779589317271552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0327164913, 8.2949713525 ]
  },
  "id_str" : "401779804233826304",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @TnaKng du hast uns durchschaut! (Heute waren wir sogar extra mit Lupen bewaffnet)",
  "id" : 401779804233826304,
  "in_reply_to_status_id" : 401779589317271552,
  "created_at" : "2013-11-16 18:32:24 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 8, 15 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/RPUefo7yQl",
      "expanded_url" : "http:\/\/www.metmuseum.org\/toah\/works-of-art\/29.107.31",
      "display_url" : "metmuseum.org\/toah\/works-of-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.104203, 8.651542 ]
  },
  "id_str" : "401779128585949184",
  "text" : "Weshalb @TnaKng und ich einen Heist auf das St\u00E4del planen.  http:\/\/t.co\/RPUefo7yQl",
  "id" : 401779128585949184,
  "created_at" : "2013-11-16 18:29:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/ROUs2dq0OF",
      "expanded_url" : "http:\/\/i.imgur.com\/7gjAYXD.gif",
      "display_url" : "i.imgur.com\/7gjAYXD.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "401778146166714368",
  "text" : "The Shadow! http:\/\/t.co\/ROUs2dq0OF",
  "id" : 401778146166714368,
  "created_at" : "2013-11-16 18:25:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00959338, 8.28285132 ]
  },
  "id_str" : "401674116996288512",
  "text" : "\u00ABDu machst Fotos. Ich mach Kunst.\u00BB \u2013 \u00ABDu fotografierst Toiletten!\u00BB",
  "id" : 401674116996288512,
  "created_at" : "2013-11-16 11:32:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1003638124, 8.2649009721 ]
  },
  "id_str" : "401476577546215424",
  "text" : "\u00ABIch habe eine Marktl\u00FCcke entdeckt: Energie-Urin, zur passenden Mondphase abgef\u00FCllt, an Esoteriker verticken.\u00BB \u2014 \u00ABVollmond-Mittelstrahl!\u00BB",
  "id" : 401476577546215424,
  "created_at" : "2013-11-15 22:27:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1003708026, 8.2648051896 ]
  },
  "id_str" : "401470877663264768",
  "text" : "\u00ABDu hast deinen Echsen ja nicht mal Namen gegeben.\u00BB \u2014 \u00ABIch bin verwirrt, geht es um die Tiere oder Ex-Freundinnen?\u00BB",
  "id" : 401470877663264768,
  "created_at" : "2013-11-15 22:04:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1003409471, 8.2649620643 ]
  },
  "id_str" : "401449395151187968",
  "text" : "\u00ABL\u00E4sst du dir in die Nase pusten?\u00BB \u2014 \u00ABPusten oder pupsen? Ich sag mal so: Ich lasse mir von Menschen die ich mag die Nase sogar auslecken!\u00BB",
  "id" : 401449395151187968,
  "created_at" : "2013-11-15 20:39:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/l98w8U5Yiu",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/N_z1R19O4u8\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401422357283483648",
  "text" : "That would make an awesome first date! http:\/\/t.co\/l98w8U5Yiu",
  "id" : 401422357283483648,
  "created_at" : "2013-11-15 18:52:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 47, 56 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/FJlifBEqul",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/c74agBe9KkA\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401420692241264640",
  "text" : "Scenes from a vegan hot dog eating\u00A0contest \/cc @senficon http:\/\/t.co\/FJlifBEqul",
  "id" : 401420692241264640,
  "created_at" : "2013-11-15 18:45:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1184072245, 8.6807765927 ]
  },
  "id_str" : "401402040993464320",
  "text" : "\u00ABSorry, ich w\u00FCrde ja gern noch weiter mit euch trinken. Aber ich habe schon einer anderen Orgie zugesagt.\u00BB",
  "id" : 401402040993464320,
  "created_at" : "2013-11-15 17:31:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401377695873130496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172304797, 8.62764639 ]
  },
  "id_str" : "401377901368864769",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Ist das der Ruderclub in dem du bist?",
  "id" : 401377901368864769,
  "in_reply_to_status_id" : 401377695873130496,
  "created_at" : "2013-11-15 15:55:23 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401373078493863936",
  "text" : "\u00ABWusstest du das J\u00FCrgen Klopp der prominenteste Absolvent der Uni Frankfurt ist?\u00BB \u2013 \u00ABIch kenne diesen Klopp ja nicht, aber: Adorno?!\u00BB",
  "id" : 401373078493863936,
  "created_at" : "2013-11-15 15:36:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 77, 90 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/0LmhI94QxA",
      "expanded_url" : "http:\/\/www.plospathogens.org\/article\/info:doi\/10.1371\/journal.ppat.1003766",
      "display_url" : "plospathogens.org\/article\/info:d\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172304797, 8.62764639 ]
  },
  "id_str" : "401367814143221760",
  "text" : "Natural Selection Promotes Antigenic Evolvability http:\/\/t.co\/0LmhI94QxA \/cc @PhilippBayer",
  "id" : 401367814143221760,
  "created_at" : "2013-11-15 15:15:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172304797, 8.62764639 ]
  },
  "id_str" : "401366647598252032",
  "text" : "\u00ABLass es mich dir mit einer Analogie \u00FCber H\u00FChner, einen Hahn, Eier und einen Fuchs erkl\u00E4ren.\u00BB \u2013 \u00ABSchon gut, ich google ja schon!\u00BB",
  "id" : 401366647598252032,
  "created_at" : "2013-11-15 15:10:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Houslay",
      "screen_name" : "tomhouslay",
      "indices" : [ 3, 14 ],
      "id_str" : "91206387",
      "id" : 91206387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401357002053795841",
  "text" : "RT @tomhouslay: If you like pictures of deadly fungus and terrible attempts to start a new meme, check out my new blog post http:\/\/t.co\/WxG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/WxGQ9XEIPP",
        "expanded_url" : "http:\/\/tomhouslay.com\/2013\/11\/15\/fungal-excitement\/",
        "display_url" : "tomhouslay.com\/2013\/11\/15\/fun\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "401349175452786688",
    "text" : "If you like pictures of deadly fungus and terrible attempts to start a new meme, check out my new blog post http:\/\/t.co\/WxGQ9XEIPP",
    "id" : 401349175452786688,
    "created_at" : "2013-11-15 14:01:14 +0000",
    "user" : {
      "name" : "Tom Houslay",
      "screen_name" : "tomhouslay",
      "protected" : false,
      "id_str" : "91206387",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875038475577196544\/_KDDmB_l_normal.jpg",
      "id" : 91206387,
      "verified" : false
    }
  },
  "id" : 401357002053795841,
  "created_at" : "2013-11-15 14:32:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sci Curious",
      "screen_name" : "scicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "31443503",
      "id" : 31443503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/Gkmuf1ESNc",
      "expanded_url" : "https:\/\/www.sciencenews.org\/blog\/scicurious\/do-you-want-good-news-or-bad-news-first?mode=blog&context=131",
      "display_url" : "sciencenews.org\/blog\/scicuriou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401352347651420160",
  "text" : "RT @scicurious: I've got good news and bad news. Which do you want first? https:\/\/t.co\/Gkmuf1ESNc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/Gkmuf1ESNc",
        "expanded_url" : "https:\/\/www.sciencenews.org\/blog\/scicurious\/do-you-want-good-news-or-bad-news-first?mode=blog&context=131",
        "display_url" : "sciencenews.org\/blog\/scicuriou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "401351937712742400",
    "text" : "I've got good news and bad news. Which do you want first? https:\/\/t.co\/Gkmuf1ESNc",
    "id" : 401351937712742400,
    "created_at" : "2013-11-15 14:12:13 +0000",
    "user" : {
      "name" : "Sci Curious",
      "screen_name" : "scicurious",
      "protected" : false,
      "id_str" : "31443503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905120517052620800\/uq2q-fjc_normal.jpg",
      "id" : 31443503,
      "verified" : true
    }
  },
  "id" : 401352347651420160,
  "created_at" : "2013-11-15 14:13:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 138, 144 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/cyY6GBblrH",
      "expanded_url" : "http:\/\/www.salon.com\/2013\/11\/12\/the_craziest_okcupid_date_ever\/?new",
      "display_url" : "salon.com\/2013\/11\/12\/the\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172304797, 8.62764639 ]
  },
  "id_str" : "401336913325723648",
  "text" : "\u00ABJeff &amp; I traveled to eight countries in 21 days without changing clothes. It sure beat meeting for coffee\u00BB http:\/\/t.co\/cyY6GBblrH HT @tante",
  "id" : 401336913325723648,
  "created_at" : "2013-11-15 13:12:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/P2LV3PgUgx",
      "expanded_url" : "http:\/\/www.wired.com\/threatlevel\/2013\/11\/google-books\/",
      "display_url" : "wired.com\/threatlevel\/20\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172304797, 8.62764639 ]
  },
  "id_str" : "401304964045479936",
  "text" : "Google\u2019s Book-Scanning Is Fair Use, Judge Rules in Landmark Copyright Case http:\/\/t.co\/P2LV3PgUgx",
  "id" : 401304964045479936,
  "created_at" : "2013-11-15 11:05:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/dSAB5pEWYs",
      "expanded_url" : "http:\/\/www.zmescience.com\/science\/anthropology\/monkey-human-music-13112013\/",
      "display_url" : "zmescience.com\/science\/anthro\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172304797, 8.62764639 ]
  },
  "id_str" : "401301807227744256",
  "text" : "Monkey-Human ancestor developed music skills 30 million years ago http:\/\/t.co\/dSAB5pEWYs",
  "id" : 401301807227744256,
  "created_at" : "2013-11-15 10:53:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/gKCF7i46ny",
      "expanded_url" : "http:\/\/i.imgur.com\/wqEnkHj.gif",
      "display_url" : "i.imgur.com\/wqEnkHj.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172304797, 8.62764639 ]
  },
  "id_str" : "401282264723886080",
  "text" : "half-ass all the methods\u2026 http:\/\/t.co\/gKCF7i46ny",
  "id" : 401282264723886080,
  "created_at" : "2013-11-15 09:35:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/VStHyDzq2w",
      "expanded_url" : "http:\/\/www.ploscompbiol.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pcbi.1003343",
      "display_url" : "ploscompbiol.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172304797, 8.62764639 ]
  },
  "id_str" : "401277522819969024",
  "text" : "Ten Quick Tips for Using the Gene Ontology http:\/\/t.co\/VStHyDzq2w",
  "id" : 401277522819969024,
  "created_at" : "2013-11-15 09:16:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/NxPzosSjag",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/11\/14\/black-metal-meets-benny-hill.html",
      "display_url" : "boingboing.net\/2013\/11\/14\/bla\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172304797, 8.62764639 ]
  },
  "id_str" : "401276713436733440",
  "text" : "Immortal meets Benny Hill http:\/\/t.co\/NxPzosSjag",
  "id" : 401276713436733440,
  "created_at" : "2013-11-15 09:13:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0090753627, 8.317361564 ]
  },
  "id_str" : "401256572804145152",
  "text" : "\u00ABIhn fragst du ob du sein Knie anfassen darfst, aber mir greifst du einfach in die Hose?!\u00BB \u2014 \u00ABIch finde ersteres halt sehr intim!\u00BB",
  "id" : 401256572804145152,
  "created_at" : "2013-11-15 07:53:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ebbert",
      "screen_name" : "nalfion",
      "indices" : [ 0, 8 ],
      "id_str" : "799167086182408192",
      "id" : 799167086182408192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.008151372, 8.2822274121 ]
  },
  "id_str" : "401254134583951360",
  "text" : "@nalfion schau ich sobald ich im B\u00FCro bin. :)",
  "id" : 401254134583951360,
  "created_at" : "2013-11-15 07:43:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/IC9h1V8yCN",
      "expanded_url" : "http:\/\/i.imgur.com\/2VKvNR0.gif",
      "display_url" : "i.imgur.com\/2VKvNR0.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009629922, 8.282966976 ]
  },
  "id_str" : "401126794189103104",
  "text" : "they see me rollin\u2019\u2026 http:\/\/t.co\/IC9h1V8yCN",
  "id" : 401126794189103104,
  "created_at" : "2013-11-14 23:17:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/EMVp8l3Tt5",
      "expanded_url" : "http:\/\/bioinformatics.oxfordjournals.org\/content\/early\/2013\/11\/13\/bioinformatics.btt658.short?rss=1",
      "display_url" : "bioinformatics.oxfordjournals.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401126494522445824",
  "text" : "RT @PhilippBayer: Cool idea: \"SeqDepot: streamlined database of biological sequences and precomputed features\" http:\/\/t.co\/EMVp8l3Tt5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/EMVp8l3Tt5",
        "expanded_url" : "http:\/\/bioinformatics.oxfordjournals.org\/content\/early\/2013\/11\/13\/bioinformatics.btt658.short?rss=1",
        "display_url" : "bioinformatics.oxfordjournals.org\/content\/early\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "401115438022549504",
    "text" : "Cool idea: \"SeqDepot: streamlined database of biological sequences and precomputed features\" http:\/\/t.co\/EMVp8l3Tt5",
    "id" : 401115438022549504,
    "created_at" : "2013-11-14 22:32:27 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 401126494522445824,
  "created_at" : "2013-11-14 23:16:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "indices" : [ 3, 15 ],
      "id_str" : "6705042",
      "id" : 6705042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/T8uM0xXqYD",
      "expanded_url" : "http:\/\/feedly.com\/k\/17V788e",
      "display_url" : "feedly.com\/k\/17V788e"
    } ]
  },
  "geo" : { },
  "id_str" : "401125440716558336",
  "text" : "RT @bengoldacre: here's some very detailed research on where to put swear words for maximum impact and flow. http:\/\/t.co\/T8uM0xXqYD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.feedly.com\" rel=\"nofollow\"\u003Efeedly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/T8uM0xXqYD",
        "expanded_url" : "http:\/\/feedly.com\/k\/17V788e",
        "display_url" : "feedly.com\/k\/17V788e"
      } ]
    },
    "geo" : { },
    "id_str" : "401124812011347968",
    "text" : "here's some very detailed research on where to put swear words for maximum impact and flow. http:\/\/t.co\/T8uM0xXqYD",
    "id" : 401124812011347968,
    "created_at" : "2013-11-14 23:09:42 +0000",
    "user" : {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "protected" : false,
      "id_str" : "6705042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523118410419286016\/qXTUFTZR_normal.png",
      "id" : 6705042,
      "verified" : true
    }
  },
  "id" : 401125440716558336,
  "created_at" : "2013-11-14 23:12:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Stajich",
      "screen_name" : "hyphaltip",
      "indices" : [ 3, 13 ],
      "id_str" : "14324284",
      "id" : 14324284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/iw7XUu2tra",
      "expanded_url" : "http:\/\/wp.me\/p5w5B-17X",
      "display_url" : "wp.me\/p5w5B-17X"
    } ]
  },
  "geo" : { },
  "id_str" : "401123877453320192",
  "text" : "RT @hyphaltip: Job: Evolutionary Genomics at McMaster University http:\/\/t.co\/iw7XUu2tra",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sopresto.mailchimp.com\" rel=\"nofollow\"\u003ESocial Proxy by Mailchimp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/iw7XUu2tra",
        "expanded_url" : "http:\/\/wp.me\/p5w5B-17X",
        "display_url" : "wp.me\/p5w5B-17X"
      } ]
    },
    "geo" : { },
    "id_str" : "401122386843406336",
    "text" : "Job: Evolutionary Genomics at McMaster University http:\/\/t.co\/iw7XUu2tra",
    "id" : 401122386843406336,
    "created_at" : "2013-11-14 23:00:04 +0000",
    "user" : {
      "name" : "Jason Stajich",
      "screen_name" : "hyphaltip",
      "protected" : false,
      "id_str" : "14324284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/52523742\/Coprinus_normal.jpg",
      "id" : 14324284,
      "verified" : false
    }
  },
  "id" : 401123877453320192,
  "created_at" : "2013-11-14 23:05:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401093790703689728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097104302, 8.2829584926 ]
  },
  "id_str" : "401093928625373184",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez that\u2019s already enqueued :)",
  "id" : 401093928625373184,
  "in_reply_to_status_id" : 401093790703689728,
  "created_at" : "2013-11-14 21:06:59 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "401092773022945280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095931854, 8.2832240041 ]
  },
  "id_str" : "401093696151904257",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez always glad to scroll through your last played songs :)",
  "id" : 401093696151904257,
  "in_reply_to_status_id" : 401092773022945280,
  "created_at" : "2013-11-14 21:06:03 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 51, 60 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/CbK3pQdp6C",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=UqIRa15wMjw",
      "display_url" : "youtube.com\/watch?v=UqIRa1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009629922, 8.282966976 ]
  },
  "id_str" : "401092279341187072",
  "text" : "Yet another thanks for the indirect recommendation @eramirez! http:\/\/t.co\/CbK3pQdp6C",
  "id" : 401092279341187072,
  "created_at" : "2013-11-14 21:00:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009629922, 8.282966976 ]
  },
  "id_str" : "401085851423490048",
  "text" : "\u00ABL\u00E4sst du dir die Insekten unter deiner Haut bitte nicht gleich rausschneiden wenn du zum Arzt gehst, damit ich mitkommen &amp; zuschauen darf?\u00BB",
  "id" : 401085851423490048,
  "created_at" : "2013-11-14 20:34:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Beiko",
      "screen_name" : "rob_beiko",
      "indices" : [ 3, 13 ],
      "id_str" : "134993381",
      "id" : 134993381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401022836103725056",
  "text" : "RT @rob_beiko: Five stages of rejection: shock, anger, bargaining, depression and reformatting references.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400070645796466688",
    "text" : "Five stages of rejection: shock, anger, bargaining, depression and reformatting references.",
    "id" : 400070645796466688,
    "created_at" : "2013-11-12 01:20:49 +0000",
    "user" : {
      "name" : "Robert Beiko",
      "screen_name" : "rob_beiko",
      "protected" : false,
      "id_str" : "134993381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2309168464\/m0ioo8vttlp50qrxj7tc_normal.png",
      "id" : 134993381,
      "verified" : false
    }
  },
  "id" : 401022836103725056,
  "created_at" : "2013-11-14 16:24:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/a3GriC9Ph8",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info:doi%2F10.1371%2Fjournal.pone.0078871",
      "display_url" : "plosone.org\/article\/info:d\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722716622, 8.6276719656 ]
  },
  "id_str" : "401015362864824320",
  "text" : "The kind of cultural evolution studies I love: The Phylogeny of Little Red Riding Hood http:\/\/t.co\/a3GriC9Ph8",
  "id" : 401015362864824320,
  "created_at" : "2013-11-14 15:54:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/PGBUTcfTDU",
      "expanded_url" : "http:\/\/www.niemanlab.org\/2013\/11\/matt-waite-how-i-faced-my-fears-and-learned-to-be-good-at-math\/",
      "display_url" : "niemanlab.org\/2013\/11\/matt-w\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722716622, 8.6276719656 ]
  },
  "id_str" : "400919455343341568",
  "text" : "\u00ABHow I faced my fears and learned to be good at math\u00BB http:\/\/t.co\/PGBUTcfTDU",
  "id" : 400919455343341568,
  "created_at" : "2013-11-14 09:33:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722716622, 8.6276719656 ]
  },
  "id_str" : "400916947942264832",
  "text" : "\u00ABUnd wor\u00FCber wirst du heute im Journal Club sprechen?\u00BB \u2013 \u00ABMelktechnologie!\u00BB",
  "id" : 400916947942264832,
  "created_at" : "2013-11-14 09:23:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/MjSEGCRujM",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0077967",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722716622, 8.6276719656 ]
  },
  "id_str" : "400916306922196993",
  "text" : "To Dope or Not to Dope: Neuroenhancement with Prescription Drugs and Drugs of Abuse among Swiss University Students http:\/\/t.co\/MjSEGCRujM",
  "id" : 400916306922196993,
  "created_at" : "2013-11-14 09:21:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/bztjdwT0cn",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/1bd1393e0cbe039c78122ee097aeaec0\/tumblr_mw7e57HCB41sevvjfo1_500.gif",
      "display_url" : "25.media.tumblr.com\/1bd1393e0cbe03\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722716622, 8.6276719656 ]
  },
  "id_str" : "400914319229349888",
  "text" : "\u00ABcould not write anymore to hash file. disk full?\u00BB http:\/\/t.co\/bztjdwT0cn",
  "id" : 400914319229349888,
  "created_at" : "2013-11-14 09:13:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400881222890446848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.006618294, 8.2836402558 ]
  },
  "id_str" : "400883557700481024",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer we\u2019ll see. Nothing to\nworry about right now. :)",
  "id" : 400883557700481024,
  "in_reply_to_status_id" : 400881222890446848,
  "created_at" : "2013-11-14 07:11:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400879894495645696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096418502, 8.2829821431 ]
  },
  "id_str" : "400880950407876608",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer but I didn\u2019t get an email about having reached the credit limit. Which I should have if it was running?",
  "id" : 400880950407876608,
  "in_reply_to_status_id" : 400879894495645696,
  "created_at" : "2013-11-14 07:00:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400879259113103360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096466866, 8.2829858983 ]
  },
  "id_str" : "400879727080394752",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nope, didn\u2019t find the time yesterday. 12h in the office, 4h commuting\u2026",
  "id" : 400879727080394752,
  "in_reply_to_status_id" : 400879259113103360,
  "created_at" : "2013-11-14 06:55:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400878364967182336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096411862, 8.2829794615 ]
  },
  "id_str" : "400878671143391232",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer great,  but let\u2019s first see whether the subscription works because that was just the reminder that I subscribed, right?",
  "id" : 400878671143391232,
  "in_reply_to_status_id" : 400878364967182336,
  "created_at" : "2013-11-14 06:51:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400780034853437440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096457661, 8.2829806084 ]
  },
  "id_str" : "400878226161295360",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, I did :)",
  "id" : 400878226161295360,
  "in_reply_to_status_id" : 400780034853437440,
  "created_at" : "2013-11-14 06:49:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0035109651, 8.292163834 ]
  },
  "id_str" : "400752785731629056",
  "text" : "\u00ABDu hast auch keine Hemmungen vor niemand, oder?\u00BB \u2014 \u00ABYup, und das w\u00E4re auch ein super Scherben-Song!\u00BB",
  "id" : 400752785731629056,
  "created_at" : "2013-11-13 22:31:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400746805476220928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.098538613, 8.5284062661 ]
  },
  "id_str" : "400747999011561472",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon da es sowieso zu sp\u00E4t ist um den Tag noch vor dem Abend zu loben lehne ich mich mal aus dem Fenster: ETA 2345",
  "id" : 400747999011561472,
  "in_reply_to_status_id" : 400746805476220928,
  "created_at" : "2013-11-13 22:12:23 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400744912725217280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1021368892, 8.5703261604 ]
  },
  "id_str" : "400746448851320832",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon moving (so far even in the right direction)",
  "id" : 400746448851320832,
  "in_reply_to_status_id" : 400744912725217280,
  "created_at" : "2013-11-13 22:06:13 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400740452095500289",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1104032437, 8.6607969436 ]
  },
  "id_str" : "400743817303044096",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon (andererseits steht hier auch seit 30 Minuten eine S3 die immer gleich losfahren soll ;))",
  "id" : 400743817303044096,
  "in_reply_to_status_id" : 400740452095500289,
  "created_at" : "2013-11-13 21:55:46 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400740452095500289",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1100274427, 8.6598848908 ]
  },
  "id_str" : "400743570409537538",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon jetzt ist hier eine S1 die angeblich irgendwann nach Wiesbaden zur\u00FCckf\u00E4hrt.",
  "id" : 400743570409537538,
  "in_reply_to_status_id" : 400740452095500289,
  "created_at" : "2013-11-13 21:54:47 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400734426155716608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.104039683, 8.644101353 ]
  },
  "id_str" : "400740302795079680",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon noch am Hbf aber irgendwann(tm) soll eine Bahn fahren.",
  "id" : 400740302795079680,
  "in_reply_to_status_id" : 400734426155716608,
  "created_at" : "2013-11-13 21:41:48 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ice Cream Assasin",
      "screen_name" : "_Firebug_",
      "indices" : [ 0, 10 ],
      "id_str" : "15837895",
      "id" : 15837895
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 11, 18 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 19, 28 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400734252238508032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1038052428, 8.6449336854 ]
  },
  "id_str" : "400734592262750208",
  "in_reply_to_user_id" : 15837895,
  "text" : "@_Firebug_ @TnaKng @Senficon danke, am Hbf ist der Status jetzt \u2018sie fahren ab hier, irgendwann.\u2019 Ich warte mal ab.",
  "id" : 400734592262750208,
  "in_reply_to_status_id" : 400734252238508032,
  "created_at" : "2013-11-13 21:19:06 +0000",
  "in_reply_to_screen_name" : "_Firebug_",
  "in_reply_to_user_id_str" : "15837895",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400733168141361152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1088008127, 8.6782233134 ]
  },
  "id_str" : "400733412832849920",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Hey, immerhin gebe ich look-wise notfalls schon einen super Hobo ab ;)",
  "id" : 400733412832849920,
  "in_reply_to_status_id" : 400733168141361152,
  "created_at" : "2013-11-13 21:14:25 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400731979446239232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1088000675, 8.678219634 ]
  },
  "id_str" : "400732540480552960",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon schlage mich erstmal zum Hbf durch und dann mal schauen.",
  "id" : 400732540480552960,
  "in_reply_to_status_id" : 400731979446239232,
  "created_at" : "2013-11-13 21:10:57 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400730965880111106",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1108608102, 8.6885380934 ]
  },
  "id_str" : "400731297280458752",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon well, mal schauen. Running out of options right now.",
  "id" : 400731297280458752,
  "in_reply_to_status_id" : 400730965880111106,
  "created_at" : "2013-11-13 21:06:01 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400730621456441345",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1112286881, 8.6872043728 ]
  },
  "id_str" : "400730910917931009",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon im worst case fahre ich wieder zur Uni und geh in die H\u00E4ngematte.",
  "id" : 400730910917931009,
  "in_reply_to_status_id" : 400730621456441345,
  "created_at" : "2013-11-13 21:04:29 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400730621456441345",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1120182161, 8.6846400474 ]
  },
  "id_str" : "400730789962584064",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon keine Chance f\u00FCr mich. Ab der Hauptwache f\u00E4hrt bis 0800 nichts mehr. Jetzt erstmal zum Hbf und dann schauen.",
  "id" : 400730789962584064,
  "in_reply_to_status_id" : 400730621456441345,
  "created_at" : "2013-11-13 21:04:00 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 18, 27 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400728646169927680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1362284561, 8.6712393524 ]
  },
  "id_str" : "400729372212363264",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng klar, und @Senficon sitzt jetzt sowieso auch an FFM Airport fest.",
  "id" : 400729372212363264,
  "in_reply_to_status_id" : 400728646169927680,
  "created_at" : "2013-11-13 20:58:22 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 37, 46 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400727693638893568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1371172024, 8.6709113605 ]
  },
  "id_str" : "400727947478597632",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng okay, ich wei\u00DF nicht wann\/ob @Senficon nach Hause kommt. Sonst w\u00FCrde ich dir Asyl bei uns anbieten.",
  "id" : 400727947478597632,
  "in_reply_to_status_id" : 400727693638893568,
  "created_at" : "2013-11-13 20:52:42 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400727068281155585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1437534905, 8.6684659403 ]
  },
  "id_str" : "400727446418649088",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng die VIA bekomme ich nicht mehr und das ist die letzte die gleich f\u00E4hrt. Sehen uns dann gleich eventuell am Hbf.",
  "id" : 400727446418649088,
  "in_reply_to_status_id" : 400727068281155585,
  "created_at" : "2013-11-13 20:50:43 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400726187846410240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1561364763, 8.6574044583 ]
  },
  "id_str" : "400726551421263873",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng wei\u00DFt du wann es weitergehen soll? Bin gerade auf dem Weg von der Uni zur Hauptwache.",
  "id" : 400726551421263873,
  "in_reply_to_status_id" : 400726187846410240,
  "created_at" : "2013-11-13 20:47:09 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722685872, 8.6277023779 ]
  },
  "id_str" : "400696310502027264",
  "text" : "\u00ABOh, du bist ja auch noch da. Ich bring dir mal Schnaps vorbei.\u00BB \u2014 \u00ABNext: Drunken Peer Review Ramblings of a Mad Man!\u00BB",
  "id" : 400696310502027264,
  "created_at" : "2013-11-13 18:46:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/leaYa839zP",
      "expanded_url" : "http:\/\/www.news.cornell.edu\/stories\/1997\/07\/worlds-smallest-silicon-mechanical-devices-are-made-cornell",
      "display_url" : "news.cornell.edu\/stories\/1997\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400688941747433472",
  "text" : "Finally: A guitar where I can wrap my small hands around the neck! http:\/\/t.co\/leaYa839zP",
  "id" : 400688941747433472,
  "created_at" : "2013-11-13 18:17:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/CPec94sRuz",
      "expanded_url" : "http:\/\/i.imgur.com\/Mxd1QDs.gif",
      "display_url" : "i.imgur.com\/Mxd1QDs.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400684072634425345",
  "text" : "he discovered that in his bed he had been changed into a monstrous verminous bug\u2026 http:\/\/t.co\/CPec94sRuz",
  "id" : 400684072634425345,
  "created_at" : "2013-11-13 17:58:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/AfkVGoMBic",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/11\/13\/the-best-way-to-pee-into-a-uri.html",
      "display_url" : "boingboing.net\/2013\/11\/13\/the\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400671676406710272",
  "text" : "The best way to pee into a urinal \u2014 as explained by\u00A0physics http:\/\/t.co\/AfkVGoMBic",
  "id" : 400671676406710272,
  "created_at" : "2013-11-13 17:09:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/jhloLTrb1A",
      "expanded_url" : "http:\/\/media.tumblr.com\/488de2d49f08f0b0f30abfce913986f1\/tumblr_inline_mw72m7JN8Z1rhty6n.gif",
      "display_url" : "media.tumblr.com\/488de2d49f08f0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400667112286732288",
  "text" : "how excited I get when the methods you\u2019re using are subpar http:\/\/t.co\/jhloLTrb1A",
  "id" : 400667112286732288,
  "created_at" : "2013-11-13 16:50:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/i8sW1Ddjo8",
      "expanded_url" : "http:\/\/vimeo.com\/74068427",
      "display_url" : "vimeo.com\/74068427"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400640480280862720",
  "text" : "Ballpoint Barber http:\/\/t.co\/i8sW1Ddjo8",
  "id" : 400640480280862720,
  "created_at" : "2013-11-13 15:05:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/bDzvimlzLS",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Witzelsucht",
      "display_url" : "en.wikipedia.org\/wiki\/Witzelsuc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400636482081529856",
  "text" : "Thanks to reddit I now know that there\u2019s a set of neurological symptoms that predicts Twitter usage http:\/\/t.co\/bDzvimlzLS",
  "id" : 400636482081529856,
  "created_at" : "2013-11-13 14:49:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/rdf5kr5LfX",
      "expanded_url" : "http:\/\/i.imgur.com\/i8SBdhW.jpg",
      "display_url" : "i.imgur.com\/i8SBdhW.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400635040734130176",
  "text" : "Mittagstief http:\/\/t.co\/rdf5kr5LfX",
  "id" : 400635040734130176,
  "created_at" : "2013-11-13 14:43:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400594688287047680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723173649, 8.6276157087 ]
  },
  "id_str" : "400594821813121024",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay, thanks :)",
  "id" : 400594821813121024,
  "in_reply_to_status_id" : 400594688287047680,
  "created_at" : "2013-11-13 12:03:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/9nSuiySrsc",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/running-ponies\/2013\/11\/13\/australian-sea-slugs-have-sex-by-stabbing-each-other-in-the-head\/",
      "display_url" : "blogs.scientificamerican.com\/running-ponies\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400579038789771264",
  "text" : "Australian Sea Slug Sex in all its Head-Stabbing Glory: \u00ABinject prostate gland fluid into your forehead\u00BB &lt;3 http:\/\/t.co\/9nSuiySrsc",
  "id" : 400579038789771264,
  "created_at" : "2013-11-13 11:00:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/Bs6BXIDOKr",
      "expanded_url" : "http:\/\/imgur.com\/BxU62Zy",
      "display_url" : "imgur.com\/BxU62Zy"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400572652076957696",
  "text" : "doing peer review, aka: i\u2019ve no idea what i\u2019m doing! http:\/\/t.co\/Bs6BXIDOKr",
  "id" : 400572652076957696,
  "created_at" : "2013-11-13 10:35:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "viola vo\u00DF",
      "screen_name" : "v_i_o_l_a",
      "indices" : [ 3, 13 ],
      "id_str" : "14937469",
      "id" : 14937469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400571002692042752",
  "text" : "RT @v_i_o_l_a: \"Nicht mehr Hasso oder Rex, sondern Benny oder Gina: Mainzer Linguisten erforschen, wie sich Tiernamen wandeln\" http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "swr2",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/7rONTEc14K",
        "expanded_url" : "http:\/\/0cn.de\/ju61",
        "display_url" : "0cn.de\/ju61"
      } ]
    },
    "geo" : { },
    "id_str" : "400569992116064257",
    "text" : "\"Nicht mehr Hasso oder Rex, sondern Benny oder Gina: Mainzer Linguisten erforschen, wie sich Tiernamen wandeln\" http:\/\/t.co\/7rONTEc14K #swr2",
    "id" : 400569992116064257,
    "created_at" : "2013-11-13 10:25:03 +0000",
    "user" : {
      "name" : "viola vo\u00DF",
      "screen_name" : "v_i_o_l_a",
      "protected" : false,
      "id_str" : "14937469",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908747934547742720\/JdLgkzf8_normal.jpg",
      "id" : 14937469,
      "verified" : false
    }
  },
  "id" : 400571002692042752,
  "created_at" : "2013-11-13 10:29:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/Dm2h1LATm1",
      "expanded_url" : "http:\/\/instagram.com\/p\/gpofc-BwuE\/",
      "display_url" : "instagram.com\/p\/gpofc-BwuE\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1718408315, 8.6255121231 ]
  },
  "id_str" : "400562421137670144",
  "text" : "Kreuzerhohl @ Niederursel \u2194 Riedberg http:\/\/t.co\/Dm2h1LATm1",
  "id" : 400562421137670144,
  "created_at" : "2013-11-13 09:54:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400551007689527296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322824, 8.6276250372 ]
  },
  "id_str" : "400552032442257408",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Twitter-Flirt-Versuch horribly gone wrong? ;)",
  "id" : 400552032442257408,
  "in_reply_to_status_id" : 400551007689527296,
  "created_at" : "2013-11-13 09:13:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400544114015367168",
  "text" : "\u00ABWorst case runtime: O(n^m^r), for our data ~ twice the time until the heat death of the universe occurs.\u00BB",
  "id" : 400544114015367168,
  "created_at" : "2013-11-13 08:42:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 75, 81 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/DSJXnuXnFf",
      "expanded_url" : "http:\/\/tvtropes.org\/pmwiki\/pmwiki.php\/EnforcedMethodActing\/Film",
      "display_url" : "tvtropes.org\/pmwiki\/pmwiki.\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.022419, 8.437503 ]
  },
  "id_str" : "400527955811921920",
  "text" : "Enforced Method Acting (what you won't learn in the Method One Clinic) \/cc @Lobot  http:\/\/t.co\/DSJXnuXnFf",
  "id" : 400527955811921920,
  "created_at" : "2013-11-13 07:38:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/9CQ5XpJTjY",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/NerdcoreRSS2\/~3\/--eSu1I1Aes\/",
      "display_url" : "feedproxy.google.com\/~r\/NerdcoreRSS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "400526733470093312",
  "text" : "Hopes for slapping over TCP\/IP are rising: \u00ABSex-Simulator on Occulus Rift: Virtual Reality Wanking-Machine\u00BB http:\/\/t.co\/9CQ5XpJTjY",
  "id" : 400526733470093312,
  "created_at" : "2013-11-13 07:33:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/sgnfjAfynY",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/lauqz4n32iE\/info%3Adoi%2F10.1371%2Fjournal.pone.0078363",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.019211, 8.4336 ]
  },
  "id_str" : "400524547155578880",
  "text" : "Conversational Flow Promotes Solidarity http:\/\/t.co\/sgnfjAfynY",
  "id" : 400524547155578880,
  "created_at" : "2013-11-13 07:24:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/y5qDLpjpzO",
      "expanded_url" : "http:\/\/xkcd.com\/1290\/",
      "display_url" : "xkcd.com\/1290\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.015194, 8.428466 ]
  },
  "id_str" : "400524144145866752",
  "text" : "Syllable Planning http:\/\/t.co\/y5qDLpjpzO",
  "id" : 400524144145866752,
  "created_at" : "2013-11-13 07:22:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L3viathan",
      "screen_name" : "L3viathan2142",
      "indices" : [ 0, 14 ],
      "id_str" : "23305817",
      "id" : 23305817
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sociallyawkwardpenguin101",
      "indices" : [ 90, 116 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400245000346537984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1732858141, 8.6277318781 ]
  },
  "id_str" : "400245754939592704",
  "in_reply_to_user_id" : 23305817,
  "text" : "@L3viathan2142 Kopfh\u00F6rer aufsetzen und mit Blick nach vorne ohne umdrehen schnell vorbei. #sociallyawkwardpenguin101",
  "id" : 400245754939592704,
  "in_reply_to_status_id" : 400245000346537984,
  "created_at" : "2013-11-12 12:56:38 +0000",
  "in_reply_to_screen_name" : "L3viathan2142",
  "in_reply_to_user_id_str" : "23305817",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 3, 16 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/nCSAyrmsFo",
      "expanded_url" : "http:\/\/jimromenesko.com\/2013\/11\/11\/art-garfunkel-doesnt-allow-photos-so-newspaper-shows-readers-where-he-sat\/",
      "display_url" : "jimromenesko.com\/2013\/11\/11\/art\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "400245133285023744",
  "text" : "RT @MishaAngrist: Band name of the day: Garfunkel's Stool  http:\/\/t.co\/nCSAyrmsFo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/nCSAyrmsFo",
        "expanded_url" : "http:\/\/jimromenesko.com\/2013\/11\/11\/art-garfunkel-doesnt-allow-photos-so-newspaper-shows-readers-where-he-sat\/",
        "display_url" : "jimromenesko.com\/2013\/11\/11\/art\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "400244673362407424",
    "text" : "Band name of the day: Garfunkel's Stool  http:\/\/t.co\/nCSAyrmsFo",
    "id" : 400244673362407424,
    "created_at" : "2013-11-12 12:52:20 +0000",
    "user" : {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "protected" : false,
      "id_str" : "116877838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747461459974717441\/GIrZkLT-_normal.jpg",
      "id" : 116877838,
      "verified" : false
    }
  },
  "id" : 400245133285023744,
  "created_at" : "2013-11-12 12:54:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 3, 17 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/xS3Zr2RGhu",
      "expanded_url" : "http:\/\/wp.me\/p1PnkE-7l",
      "display_url" : "wp.me\/p1PnkE-7l"
    } ]
  },
  "geo" : { },
  "id_str" : "400238965397422080",
  "text" : "RT @BioMickWatson: Nanopore wars http:\/\/t.co\/xS3Zr2RGhu I try and untangle the relationship between Illumina and Oxford Nanopore",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/xS3Zr2RGhu",
        "expanded_url" : "http:\/\/wp.me\/p1PnkE-7l",
        "display_url" : "wp.me\/p1PnkE-7l"
      } ]
    },
    "geo" : { },
    "id_str" : "400234656819183616",
    "text" : "Nanopore wars http:\/\/t.co\/xS3Zr2RGhu I try and untangle the relationship between Illumina and Oxford Nanopore",
    "id" : 400234656819183616,
    "created_at" : "2013-11-12 12:12:32 +0000",
    "user" : {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "protected" : false,
      "id_str" : "228586748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870214569679093760\/YIZGIDTS_normal.jpg",
      "id" : 228586748,
      "verified" : false
    }
  },
  "id" : 400238965397422080,
  "created_at" : "2013-11-12 12:29:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 126, 139 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/FMoxBgn3Dd",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/gnxp\/2013\/11\/isnt-special\/?utm_source=twitterfeed&utm_medium=twitter&utm_campaign=Feed%3A+GeneExpressionBlog+%28Gene+Expression%29#.UoIXopRO-Xp",
      "display_url" : "blogs.discovermagazine.com\/gnxp\/2013\/11\/i\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400233299161120768",
  "text" : "\u00ABnegative freq. depend. selection is a major factor in maintaining genetic diversity in populations.\u00BB http:\/\/t.co\/FMoxBgn3Dd \/@PhilippBayer",
  "id" : 400233299161120768,
  "created_at" : "2013-11-12 12:07:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucie \uD83C\uDF42",
      "screen_name" : "Autofocus",
      "indices" : [ 0, 10 ],
      "id_str" : "18939309",
      "id" : 18939309
    }, {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 11, 22 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400215347040882688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400215830342152192",
  "in_reply_to_user_id" : 18939309,
  "text" : "@Autofocus @plaetzchen dann liegt die Wahrheit wohl irgendwo zwischen criminal und \u201Creines nerd-problem\u201D ;)",
  "id" : 400215830342152192,
  "in_reply_to_status_id" : 400215347040882688,
  "created_at" : "2013-11-12 10:57:44 +0000",
  "in_reply_to_screen_name" : "Autofocus",
  "in_reply_to_user_id_str" : "18939309",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    }, {
      "name" : "Lucie \uD83C\uDF42",
      "screen_name" : "Autofocus",
      "indices" : [ 12, 22 ],
      "id_str" : "18939309",
      "id" : 18939309
    }, {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 23, 29 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400214868571471872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400215050939813888",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen @Autofocus @tante das ist aber was anderes als zu sagen das es reine Nerd-W\u00FCnsche sind. :)",
  "id" : 400215050939813888,
  "in_reply_to_status_id" : 400214868571471872,
  "created_at" : "2013-11-12 10:54:38 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    }, {
      "name" : "Lucie \uD83C\uDF42",
      "screen_name" : "Autofocus",
      "indices" : [ 12, 22 ],
      "id_str" : "18939309",
      "id" : 18939309
    }, {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 23, 29 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/400214548797743104\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/JXBMQS9o9I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY3ZAvZIcAA9z7v.png",
      "id_str" : "400214548650946560",
      "id" : 400214548650946560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY3ZAvZIcAA9z7v.png",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/JXBMQS9o9I"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400213075502325760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722967975, 8.6276476501 ]
  },
  "id_str" : "400214548797743104",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen @Autofocus @tante wie sehr muss man Nerd sein um sich einen brauchbaren Kalender als default zu w\u00FCnschen? http:\/\/t.co\/JXBMQS9o9I",
  "id" : 400214548797743104,
  "in_reply_to_status_id" : 400213075502325760,
  "created_at" : "2013-11-12 10:52:38 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/OpIeOgcl6o",
      "expanded_url" : "http:\/\/blog.chembark.com\/2013\/11\/11\/how-jacs-treated-the-anonymous-tip-of-the-rodriguez-marks-paper\/",
      "display_url" : "blog.chembark.com\/2013\/11\/11\/how\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400200377637023744",
  "text" : "Anon. Whistleblowing: \u00ABPeople publishing NMRs that were never real. And no one dared disturb the sound of silence\u00BB http:\/\/t.co\/OpIeOgcl6o",
  "id" : 400200377637023744,
  "created_at" : "2013-11-12 09:56:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400188445718761472",
  "text" : "\u00ABAccording to the publication\u2019s password expiration policy, you must change your PW after 365 days.\u00BB How long the openSNP paper is in sub\u2026",
  "id" : 400188445718761472,
  "created_at" : "2013-11-12 09:08:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sir Beef-A-Lot \uD83C\uDDE9\uD83C\uDDEA\uD83D\uDD1C\uD83C\uDDEF\uD83C\uDDF5",
      "screen_name" : "FreXxX",
      "indices" : [ 0, 7 ],
      "id_str" : "22941893",
      "id" : 22941893
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 8, 21 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400182746670465024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400182987712917506",
  "in_reply_to_user_id" : 22941893,
  "text" : "@FreXxX @PhilippBayer yeah, we don\u2019t care too much about how effective it is, it\u2019s just a way to cut losses.",
  "id" : 400182987712917506,
  "in_reply_to_status_id" : 400182746670465024,
  "created_at" : "2013-11-12 08:47:13 +0000",
  "in_reply_to_screen_name" : "FreXxX",
  "in_reply_to_user_id_str" : "22941893",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sir Beef-A-Lot \uD83C\uDDE9\uD83C\uDDEA\uD83D\uDD1C\uD83C\uDDEF\uD83C\uDDF5",
      "screen_name" : "FreXxX",
      "indices" : [ 0, 7 ],
      "id_str" : "22941893",
      "id" : 22941893
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 8, 21 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400179895273553920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400180054678065152",
  "in_reply_to_user_id" : 22941893,
  "text" : "@FreXxX @PhilippBayer we have USD 1000 worth of AWS credits that are only good until 12\/31 and no other need for them.",
  "id" : 400180054678065152,
  "in_reply_to_status_id" : 400179895273553920,
  "created_at" : "2013-11-12 08:35:34 +0000",
  "in_reply_to_screen_name" : "FreXxX",
  "in_reply_to_user_id_str" : "22941893",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/x41E7KJR8K",
      "expanded_url" : "http:\/\/furniturehelios.com\/catalog\/view\/bitcoin\/BitcoinWalletLocation\/amazon-ec2-gpu-cluster-bitcoin.php",
      "display_url" : "furniturehelios.com\/catalog\/view\/b\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "400178933275967488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400179162453147649",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer http:\/\/t.co\/x41E7KJR8K",
  "id" : 400179162453147649,
  "in_reply_to_status_id" : 400178933275967488,
  "created_at" : "2013-11-12 08:32:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400178933275967488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400179130962300928",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u201Cdecided to go for the meanest and most expensive EC2 instance type (the cg1.4xlarge Cluster GPU instance that costs $2.10\/h\u201D",
  "id" : 400179130962300928,
  "in_reply_to_status_id" : 400178933275967488,
  "created_at" : "2013-11-12 08:31:54 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400177066827456512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722819369, 8.6276597885 ]
  },
  "id_str" : "400178804674818048",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, okay. Any reason why you didn\u2019t want to use the one given in the blogpost?",
  "id" : 400178804674818048,
  "in_reply_to_status_id" : 400177066827456512,
  "created_at" : "2013-11-12 08:30:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400166314343292928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722607682, 8.627707922 ]
  },
  "id_str" : "400175565384466432",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw had you had a look at the BTC miner?",
  "id" : 400175565384466432,
  "in_reply_to_status_id" : 400166314343292928,
  "created_at" : "2013-11-12 08:17:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400166314343292928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722910481, 8.6276663144 ]
  },
  "id_str" : "400174118290866176",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay, i might give another book a try in that case. ;)",
  "id" : 400174118290866176,
  "in_reply_to_status_id" : 400166314343292928,
  "created_at" : "2013-11-12 08:11:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400161222877671424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0942287222, 8.6067956686 ]
  },
  "id_str" : "400161459315175424",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer in that case I\u2019ll go with MoD first and hope you have finished Complexity by the time I\u2019m done with former. ;)",
  "id" : 400161459315175424,
  "in_reply_to_status_id" : 400161222877671424,
  "created_at" : "2013-11-12 07:21:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400151028600807426",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0942287222, 8.6067956686 ]
  },
  "id_str" : "400160689014464512",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw: how is Complexity? Worth reading as well?",
  "id" : 400160689014464512,
  "in_reply_to_status_id" : 400151028600807426,
  "created_at" : "2013-11-12 07:18:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0069778064, 8.2831692474 ]
  },
  "id_str" : "400151558752833536",
  "text" : "Dreamt of getting some work done. Thoroughly disappointed when I was awake and couldn\u2019t find the results in my ~.",
  "id" : 400151558752833536,
  "created_at" : "2013-11-12 06:42:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400151028600807426",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0070352363, 8.2823739241 ]
  },
  "id_str" : "400151211342856192",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I know, that\u2019s what gave me the idea in the first place. ;)",
  "id" : 400151211342856192,
  "in_reply_to_status_id" : 400151028600807426,
  "created_at" : "2013-11-12 06:40:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400145768675164160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0071543358, 8.2827975284 ]
  },
  "id_str" : "400150893381054464",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer hah, already wondered whether that should be my next read. So it\u2019s settled now. :)",
  "id" : 400150893381054464,
  "in_reply_to_status_id" : 400145768675164160,
  "created_at" : "2013-11-12 06:39:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009593344, 8.2832001939 ]
  },
  "id_str" : "400052975777099776",
  "text" : "Don\u2019t even remember how I ended up on the Wiki pages, but I spent an hour reading on graph databases. Now I know I don\u2019t need but want one\u2026",
  "id" : 400052975777099776,
  "created_at" : "2013-11-12 00:10:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400033237625344001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096674167, 8.2829662133 ]
  },
  "id_str" : "400033444110929920",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that still would be cost-effective according to your USD&lt;-&gt;BTC converter. Guess by now mining will be less effective though.",
  "id" : 400033444110929920,
  "in_reply_to_status_id" : 400033237625344001,
  "created_at" : "2013-11-11 22:53:00 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400028851914276866",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096674167, 8.2829662133 ]
  },
  "id_str" : "400032897991970816",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw your calculation is off: USD60 ~ 0.2 BTC &lt;-&gt; USD1000 ~ 3.3 BTC if I didn\u2019t make a calc error.",
  "id" : 400032897991970816,
  "in_reply_to_status_id" : 400028851914276866,
  "created_at" : "2013-11-11 22:50:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400031108135256064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096674167, 8.2829662133 ]
  },
  "id_str" : "400031891597688833",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer great, but as stated in the email: please make sure not to exceed the credit limit :D",
  "id" : 400031891597688833,
  "in_reply_to_status_id" : 400031108135256064,
  "created_at" : "2013-11-11 22:46:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400030401214685184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096674167, 8.2829662133 ]
  },
  "id_str" : "400030926916186114",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you should have mail with the account data. Won\u2019t have time to set it up today though. Do you?",
  "id" : 400030926916186114,
  "in_reply_to_status_id" : 400030401214685184,
  "created_at" : "2013-11-11 22:42:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400028851914276866",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096674167, 8.2829662133 ]
  },
  "id_str" : "400030026122678272",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ok, setting up the account right now",
  "id" : 400030026122678272,
  "in_reply_to_status_id" : 400028851914276866,
  "created_at" : "2013-11-11 22:39:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/EVycabAbvu",
      "expanded_url" : "http:\/\/furniturehelios.com\/catalog\/view\/bitcoin\/BitcoinWalletLocation\/amazon-ec2-gpu-cluster-bitcoin.php",
      "display_url" : "furniturehelios.com\/catalog\/view\/b\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "400026874786484224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967021, 8.2831480033 ]
  },
  "id_str" : "400027933206519809",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw http:\/\/t.co\/EVycabAbvu",
  "id" : 400027933206519809,
  "in_reply_to_status_id" : 400026874786484224,
  "created_at" : "2013-11-11 22:31:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400026874786484224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096217637, 8.282959731 ]
  },
  "id_str" : "400027248415084546",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer in that case I\u2019d prefer bit coins or boinc ;) (so much fun, like unexpectedly finding usd1000 under your sofa!)",
  "id" : 400027248415084546,
  "in_reply_to_status_id" : 400026874786484224,
  "created_at" : "2013-11-11 22:28:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400026034357010433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096133433, 8.2829618433 ]
  },
  "id_str" : "400026475316781056",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thought so, would be an easy way to cut losses I guess. If you want to be more altruistic we could run some BOINC projects ;)",
  "id" : 400026475316781056,
  "in_reply_to_status_id" : 400026034357010433,
  "created_at" : "2013-11-11 22:25:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400025089174806529",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096133433, 8.2829618433 ]
  },
  "id_str" : "400025405546967041",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer just skimmed. so it\u2019s not cost effective, but does it work non-cost effective? we don\u2019t care too much about that, right?",
  "id" : 400025405546967041,
  "in_reply_to_status_id" : 400025089174806529,
  "created_at" : "2013-11-11 22:21:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400023869647364097",
  "geo" : { },
  "id_str" : "400024385886507008",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer if we don't have productive use for it: are EC2's any good for bitcoin mining? :D",
  "id" : 400024385886507008,
  "in_reply_to_status_id" : 400023869647364097,
  "created_at" : "2013-11-11 22:17:00 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400023798516178944",
  "geo" : { },
  "id_str" : "400024264650137600",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer meh, too bad. Anything else coming up at your end? Also have no professional use right now (our cluster is virtually idle atm)",
  "id" : 400024264650137600,
  "in_reply_to_status_id" : 400023798516178944,
  "created_at" : "2013-11-11 22:16:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400021578764652544",
  "geo" : { },
  "id_str" : "400023539467558912",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Just checked: We still have the 1000 USD in AWS credits, and they are only good until 31st of Dec 13. So go for it if you can.",
  "id" : 400023539467558912,
  "in_reply_to_status_id" : 400021578764652544,
  "created_at" : "2013-11-11 22:13:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400021578764652544",
  "geo" : { },
  "id_str" : "400022807569899520",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer can you use EC2? if yes: do we still have the binary battle credits? :P",
  "id" : 400022807569899520,
  "in_reply_to_status_id" : 400021578764652544,
  "created_at" : "2013-11-11 22:10:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/S0p862QjiO",
      "expanded_url" : "http:\/\/corgis.blizzpro.com\/wp-content\/uploads\/sites\/5\/2013\/08\/corgi-fighting2.jpg",
      "display_url" : "corgis.blizzpro.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966899, 8.28298161 ]
  },
  "id_str" : "400019860450988033",
  "text" : "Battle-Cat? Please! http:\/\/t.co\/S0p862QjiO",
  "id" : 400019860450988033,
  "created_at" : "2013-11-11 21:59:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/NLG1NyA8Ig",
      "expanded_url" : "http:\/\/i2.kym-cdn.com\/photos\/images\/newsfeed\/000\/478\/261\/226.gif",
      "display_url" : "i2.kym-cdn.com\/photos\/images\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966899, 8.28298161 ]
  },
  "id_str" : "400014570619944964",
  "text" : "re p-values: what running &amp; interpreting statistical tests is like for many people http:\/\/t.co\/NLG1NyA8Ig",
  "id" : 400014570619944964,
  "created_at" : "2013-11-11 21:38:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/9FPHLwYv3Y",
      "expanded_url" : "http:\/\/www.nature.com\/news\/weak-statistical-standards-implicated-in-scientific-irreproducibility-1.14131",
      "display_url" : "nature.com\/news\/weak-stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095966525, 8.2829233775 ]
  },
  "id_str" : "400013243244355586",
  "text" : "I doubt that the p-value cutoff is the real problem. It\u2019s that virtually no one understands what p-values say\u2026 http:\/\/t.co\/9FPHLwYv3Y",
  "id" : 400013243244355586,
  "created_at" : "2013-11-11 21:32:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/UmQHpDmVDM",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/neuroskeptic\/2013\/11\/11\/lost-art-twitter-conversation\/#.UoFLnpRO-Xo",
      "display_url" : "blogs.discovermagazine.com\/neuroskeptic\/2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095966525, 8.2829233775 ]
  },
  "id_str" : "400012116692049920",
  "text" : "Why Are (Some) Tweets Getting Shorter? http:\/\/t.co\/UmQHpDmVDM",
  "id" : 400012116692049920,
  "created_at" : "2013-11-11 21:28:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffa",
      "screen_name" : "rei_in_der_tube",
      "indices" : [ 0, 16 ],
      "id_str" : "19707954",
      "id" : 19707954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400010263975702531",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009644955, 8.282933255 ]
  },
  "id_str" : "400010415809511424",
  "in_reply_to_user_id" : 19707954,
  "text" : "@rei_in_der_tube Keine Ahnung, ich hab sie nur abbauen sehen als ich aus der Uni heim kam. Und gleichzeitig war alles voller Betrunkener ;)",
  "id" : 400010415809511424,
  "in_reply_to_status_id" : 400010263975702531,
  "created_at" : "2013-11-11 21:21:29 +0000",
  "in_reply_to_screen_name" : "rei_in_der_tube",
  "in_reply_to_user_id_str" : "19707954",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0093230031, 8.2834724724 ]
  },
  "id_str" : "399989779754147840",
  "text" : "Am 11.11. in Mainz den Blutspendedienst durchzuf\u00FChren ist auch schon sehr sportlich*. \n\n*nutzlos",
  "id" : 399989779754147840,
  "created_at" : "2013-11-11 19:59:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1138530921, 8.6788122055 ]
  },
  "id_str" : "399967983977906176",
  "text" : "\u00ABIt gets better starting a PhD, right? The feeling of not knowing anything, being incompetent\u2026\u00BB\u2014\u00ABOh, you\u2019ve discovered the human condition!\u00BB",
  "id" : 399967983977906176,
  "created_at" : "2013-11-11 18:32:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399948934941913088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1500859734, 8.6639537621 ]
  },
  "id_str" : "399962447723118592",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente danke! :)",
  "id" : 399962447723118592,
  "in_reply_to_status_id" : 399948934941913088,
  "created_at" : "2013-11-11 18:10:53 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/riXuQfjGUr",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Andrei_Sakharov#Development_of_thermonuclear_devices",
      "display_url" : "en.wikipedia.org\/wiki\/Andrei_Sa\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722804282, 8.6276605218 ]
  },
  "id_str" : "399918189586702337",
  "text" : "I knew that Edward Teller got the Ig Nobel Peace Prize. Wasn\u2019t aware that his russian counterpart got an actual Nobel http:\/\/t.co\/riXuQfjGUr",
  "id" : 399918189586702337,
  "created_at" : "2013-11-11 15:15:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/T1OPqFiPMQ",
      "expanded_url" : "http:\/\/forlackofabettercomic.com\/?id=272",
      "display_url" : "forlackofabettercomic.com\/?id=272"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722804282, 8.6276605218 ]
  },
  "id_str" : "399916351885967360",
  "text" : "year of the beard http:\/\/t.co\/T1OPqFiPMQ",
  "id" : 399916351885967360,
  "created_at" : "2013-11-11 15:07:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722804282, 8.6276605218 ]
  },
  "id_str" : "399908016029728768",
  "text" : "\u00ABIch sehe, du hast im Sozialkompetenz-Workshop auch aufgepasst.\u00BB \u2013 \u00ABWas willst du denn? Ich bin doch noch bekleidet!\u00BB",
  "id" : 399908016029728768,
  "created_at" : "2013-11-11 14:34:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722804282, 8.6276605218 ]
  },
  "id_str" : "399893756251750400",
  "text" : "\u00ABApropos Movember: Mit was f\u00FCr einem Tool trimmst du eigentlich deinen Bart?\u00BB \u2013 \u00ABNennt sich \u2018Freundin\u2019, kann ich sehr empfehlen.\u00BB",
  "id" : 399893756251750400,
  "created_at" : "2013-11-11 13:37:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399889610970370048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722804282, 8.6276605218 ]
  },
  "id_str" : "399889915233988608",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab cool, who did the workshop? Worked there for my Master\u2019s and still collaborate for my PhD :)",
  "id" : 399889915233988608,
  "in_reply_to_status_id" : 399889610970370048,
  "created_at" : "2013-11-11 13:22:40 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399888219476480000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722804282, 8.6276605218 ]
  },
  "id_str" : "399888488864436224",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab ah, was there a workshop of the BIK-F or something else? Feel free to drop a note next time you\u2019re around!",
  "id" : 399888488864436224,
  "in_reply_to_status_id" : 399888219476480000,
  "created_at" : "2013-11-11 13:16:59 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399886859125276672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722804282, 8.6276605218 ]
  },
  "id_str" : "399886995411181568",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab sry for the disappointment! btw: which Senckenberg did you visit? :)",
  "id" : 399886995411181568,
  "in_reply_to_status_id" : 399886859125276672,
  "created_at" : "2013-11-11 13:11:03 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/8kd9qiq3bw",
      "expanded_url" : "http:\/\/noisey.vice.com\/blog\/unlocking-the-truth-is-the-most-brutal-sixth-grade-metal-band-ever-ever-ever-ever",
      "display_url" : "noisey.vice.com\/blog\/unlocking\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "399874131107135488",
  "text" : "Unlocking the Truth is the Most Brutal Sixth Grade Metal Band Ever, Ever, Ever, Ever http:\/\/t.co\/8kd9qiq3bw",
  "id" : 399874131107135488,
  "created_at" : "2013-11-11 12:19:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/9esVP7LRH3",
      "expanded_url" : "http:\/\/i.imgur.com\/zdKaUCe.gif",
      "display_url" : "i.imgur.com\/zdKaUCe.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722804282, 8.6276605218 ]
  },
  "id_str" : "399868441559322624",
  "text" : "waiting for yet another round of pairwise alignments http:\/\/t.co\/9esVP7LRH3",
  "id" : 399868441559322624,
  "created_at" : "2013-11-11 11:57:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/7LiP2Eo4K9",
      "expanded_url" : "http:\/\/i.imgur.com\/ISLBQtL.gif",
      "display_url" : "i.imgur.com\/ISLBQtL.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722804282, 8.6276605218 ]
  },
  "id_str" : "399828520542961664",
  "text" : "This looks familiar (and is the reason why cats have favorite songs as well) http:\/\/t.co\/7LiP2Eo4K9",
  "id" : 399828520542961664,
  "created_at" : "2013-11-11 09:18:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399816688767471616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1721673551, 8.6277669919 ]
  },
  "id_str" : "399820818374742016",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, though i have to agree: the writing is awkward at times. ;)",
  "id" : 399820818374742016,
  "in_reply_to_status_id" : 399816688767471616,
  "created_at" : "2013-11-11 08:48:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/dHRYV4mM02",
      "expanded_url" : "http:\/\/www.languageonthemove.com\/language-learning-gender-identity\/bilingualism-delays-onset-of-dementia?utm_source=rss&utm_medium=rss&utm_campaign=bilingualism-delays-onset-of-dementia",
      "display_url" : "languageonthemove.com\/language-learn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "399810971612770304",
  "text" : "Bilingualism delays onset of dementia http:\/\/t.co\/dHRYV4mM02",
  "id" : 399810971612770304,
  "created_at" : "2013-11-11 08:08:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/fC0PjLbyga",
      "expanded_url" : "http:\/\/www.thisamericanlife.org\/radio-archives\/episode\/510\/fiasco?act=3#play",
      "display_url" : "thisamericanlife.org\/radio-archives\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1335645535, 8.6687250677 ]
  },
  "id_str" : "399809970273017856",
  "text" : "\u00ABit ran into the fire, caught on fire and ran directly back out, directly under the couch\u00BB http:\/\/t.co\/fC0PjLbyga",
  "id" : 399809970273017856,
  "created_at" : "2013-11-11 08:04:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399803278906507265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0905941535, 8.6208844547 ]
  },
  "id_str" : "399805571354083328",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw: Thanks for recommending the Borlaug-Bio. Just finished it. :)",
  "id" : 399805571354083328,
  "in_reply_to_status_id" : 399803278906507265,
  "created_at" : "2013-11-11 07:47:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/ms4mfwAS2s",
      "expanded_url" : "http:\/\/xkcd.com\/1289\/",
      "display_url" : "xkcd.com\/1289\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0129739657, 8.4255799291 ]
  },
  "id_str" : "399799549176590336",
  "text" : "So this is where Morozov is getting his essay ideas from! http:\/\/t.co\/ms4mfwAS2s",
  "id" : 399799549176590336,
  "created_at" : "2013-11-11 07:23:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399763571581530112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0049169898, 8.3032201507 ]
  },
  "id_str" : "399797188035092480",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer what was that about unions and 8h work\/day? ;)",
  "id" : 399797188035092480,
  "in_reply_to_status_id" : 399763571581530112,
  "created_at" : "2013-11-11 07:14:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Nijhuis",
      "screen_name" : "nijhuism",
      "indices" : [ 3, 12 ],
      "id_str" : "83237493",
      "id" : 83237493
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scio14",
      "indices" : [ 73, 80 ]
    }, {
      "text" : "LWON",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/OTfz2gvxGM",
      "expanded_url" : "http:\/\/bit.ly\/HLlLix",
      "display_url" : "bit.ly\/HLlLix"
    } ]
  },
  "geo" : { },
  "id_str" : "399796675323383808",
  "text" : "RT @nijhuism: What happens when an entomologist develops a fear of bugs? #scio14 #LWON http:\/\/t.co\/OTfz2gvxGM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scio14",
        "indices" : [ 59, 66 ]
      }, {
        "text" : "LWON",
        "indices" : [ 67, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/OTfz2gvxGM",
        "expanded_url" : "http:\/\/bit.ly\/HLlLix",
        "display_url" : "bit.ly\/HLlLix"
      } ]
    },
    "geo" : { },
    "id_str" : "398852507419435008",
    "text" : "What happens when an entomologist develops a fear of bugs? #scio14 #LWON http:\/\/t.co\/OTfz2gvxGM",
    "id" : 398852507419435008,
    "created_at" : "2013-11-08 16:40:22 +0000",
    "user" : {
      "name" : "Michelle Nijhuis",
      "screen_name" : "nijhuism",
      "protected" : false,
      "id_str" : "83237493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721922762722283520\/84GPEOYa_normal.jpg",
      "id" : 83237493,
      "verified" : true
    }
  },
  "id" : 399796675323383808,
  "created_at" : "2013-11-11 07:12:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/yR3jpDpT3g",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Frequency_illusion",
      "display_url" : "en.wikipedia.org\/wiki\/Frequency\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963864, 8.28297472 ]
  },
  "id_str" : "399674675460325376",
  "text" : "Wasn\u2019t aware that frequency illusions also go under the name \u00ABBaader-Meinhof Phenomenon\u00BB (and today I read it twice!) http:\/\/t.co\/yR3jpDpT3g",
  "id" : 399674675460325376,
  "created_at" : "2013-11-10 23:07:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Amsen",
      "screen_name" : "easternblot",
      "indices" : [ 3, 15 ],
      "id_str" : "14506075",
      "id" : 14506075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "solo13blogs",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/vpgIohHy2y",
      "expanded_url" : "http:\/\/easternblot.net\/2013\/09\/06\/please-do-not-publish-my-thesis\/",
      "display_url" : "easternblot.net\/2013\/09\/06\/ple\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "399669802245308416",
  "text" : "RT @easternblot: Sometimes blog comments make a post better. I'm still getting \"me too\"'s on this one: http:\/\/t.co\/vpgIohHy2y #solo13blogs \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "solo13blogs",
        "indices" : [ 109, 121 ]
      }, {
        "text" : "solo13",
        "indices" : [ 122, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/vpgIohHy2y",
        "expanded_url" : "http:\/\/easternblot.net\/2013\/09\/06\/please-do-not-publish-my-thesis\/",
        "display_url" : "easternblot.net\/2013\/09\/06\/ple\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "399660237335969792",
    "text" : "Sometimes blog comments make a post better. I'm still getting \"me too\"'s on this one: http:\/\/t.co\/vpgIohHy2y #solo13blogs #solo13",
    "id" : 399660237335969792,
    "created_at" : "2013-11-10 22:10:00 +0000",
    "user" : {
      "name" : "Eva Amsen",
      "screen_name" : "easternblot",
      "protected" : false,
      "id_str" : "14506075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821131597848121345\/Zedt0G5I_normal.jpg",
      "id" : 14506075,
      "verified" : false
    }
  },
  "id" : 399669802245308416,
  "created_at" : "2013-11-10 22:48:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/qNSZUYNfPc",
      "expanded_url" : "http:\/\/i.imgur.com\/JMSfkKk.gif",
      "display_url" : "i.imgur.com\/JMSfkKk.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963864, 8.28297472 ]
  },
  "id_str" : "399645873329946624",
  "text" : "How I prefer to sleep http:\/\/t.co\/qNSZUYNfPc",
  "id" : 399645873329946624,
  "created_at" : "2013-11-10 21:12:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/5bOHAEy6PS",
      "expanded_url" : "http:\/\/i.imgur.com\/W9HVIIA.gif",
      "display_url" : "i.imgur.com\/W9HVIIA.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963864, 8.28297472 ]
  },
  "id_str" : "399634432887619584",
  "text" : "Shotgun! http:\/\/t.co\/5bOHAEy6PS",
  "id" : 399634432887619584,
  "created_at" : "2013-11-10 20:27:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097161027, 8.2832583258 ]
  },
  "id_str" : "399619707839713280",
  "text" : "\u00ABHaben wir noch Taschent\u00FCcher?\u00BB\u2014\u00ABNein, das wir welche kaufen m\u00FCssten steht auf dem Whiteboard.\u00BB\u2014\u00ABSchon gut, hab Pfeifenreiniger gefunden.\u00BB",
  "id" : 399619707839713280,
  "created_at" : "2013-11-10 19:28:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/vCB7pl38F3",
      "expanded_url" : "http:\/\/neurocritic.blogspot.de\/2013\/11\/now-is-that-gratitude.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed:+TheNeurocritic+(The+Neurocritic",
      "display_url" : "neurocritic.blogspot.de\/2013\/11\/now-is\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963864, 8.28297472 ]
  },
  "id_str" : "399605731340865536",
  "text" : "Now Is That Gratitude? http:\/\/t.co\/vCB7pl38F3)",
  "id" : 399605731340865536,
  "created_at" : "2013-11-10 18:33:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096592688, 8.2830565312 ]
  },
  "id_str" : "399598173595107328",
  "text" : "\u00ABWas macht die Polizei vor der T\u00FCr?\u00BB \u2014 \u00ABUnsere Nachbar machen einen Fackelzug\u2026\u00BB \u2014 \u00ABSind die nicht entweder einen Tag zu fr\u00FCh oder zu sp\u00E4t?\u00BB",
  "id" : 399598173595107328,
  "created_at" : "2013-11-10 18:03:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399587220262096896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095993281, 8.2829921879 ]
  },
  "id_str" : "399589852230201344",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante that I misread your closing sentence as \u2018be a part in shipping the future\u2019 is probably a telling comment on the status quo.",
  "id" : 399589852230201344,
  "in_reply_to_status_id" : 399587220262096896,
  "created_at" : "2013-11-10 17:30:19 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399510848227385344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009712265, 8.2831829869 ]
  },
  "id_str" : "399511871298236416",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that\u2019s the worst nightmare I have every time I fire up a rails c in production.",
  "id" : 399511871298236416,
  "in_reply_to_status_id" : 399510848227385344,
  "created_at" : "2013-11-10 12:20:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399492240252231681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096987979, 8.2830623397 ]
  },
  "id_str" : "399508491150589952",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer well, it was noticed with 2 files getting purged in the process. Could have been much worse and it\u2019s fixed now :)",
  "id" : 399508491150589952,
  "in_reply_to_status_id" : 399492240252231681,
  "created_at" : "2013-11-10 12:07:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399348469585809410",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096499548, 8.2829294074 ]
  },
  "id_str" : "399461958938034176",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks, I already read (and tweeted) it myself. :)",
  "id" : 399461958938034176,
  "in_reply_to_status_id" : 399348469585809410,
  "created_at" : "2013-11-10 09:02:07 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin F. Robbins",
      "screen_name" : "mjrobbins",
      "indices" : [ 3, 13 ],
      "id_str" : "14315063",
      "id" : 14315063
    }, {
      "name" : "Deborah Blum",
      "screen_name" : "deborahblum",
      "indices" : [ 58, 70 ],
      "id_str" : "72842277",
      "id" : 72842277
    }, {
      "name" : "Emily [redacted] Willingham\uD83C\uDFC1",
      "screen_name" : "ejwillingham",
      "indices" : [ 79, 92 ],
      "id_str" : "77907514",
      "id" : 77907514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399312190567886849",
  "text" : "RT @mjrobbins: Absolutely jaw-dropping behaviour -&gt; RT @deborahblum: Thanks @ejwillingham for standing up for our XX panel! http:\/\/t.co\/m5Z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Deborah Blum",
        "screen_name" : "deborahblum",
        "indices" : [ 43, 55 ],
        "id_str" : "72842277",
        "id" : 72842277
      }, {
        "name" : "Emily [redacted] Willingham\uD83C\uDFC1",
        "screen_name" : "ejwillingham",
        "indices" : [ 64, 77 ],
        "id_str" : "77907514",
        "id" : 77907514
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/m5ZLX5yDC5",
        "expanded_url" : "http:\/\/www.emilywillinghamphd.com\/2013\/11\/no-not-back-to-our-regularly-scheduled.html",
        "display_url" : "emilywillinghamphd.com\/2013\/11\/no-not\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "399305650791927809",
    "text" : "Absolutely jaw-dropping behaviour -&gt; RT @deborahblum: Thanks @ejwillingham for standing up for our XX panel! http:\/\/t.co\/m5ZLX5yDC5",
    "id" : 399305650791927809,
    "created_at" : "2013-11-09 22:41:00 +0000",
    "user" : {
      "name" : "Martin F. Robbins",
      "screen_name" : "mjrobbins",
      "protected" : false,
      "id_str" : "14315063",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/889888866257297408\/smSw_n3y_normal.jpg",
      "id" : 14315063,
      "verified" : true
    }
  },
  "id" : 399312190567886849,
  "created_at" : "2013-11-09 23:06:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/CepSN6Sduc",
      "expanded_url" : "http:\/\/freethoughtblogs.com\/pharyngula\/2013\/11\/09\/balance\/",
      "display_url" : "freethoughtblogs.com\/pharyngula\/201\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096746598, 8.2829556277 ]
  },
  "id_str" : "399311280429080577",
  "text" : "\u00ABThe world thinks we\u2019re about making material improvements [\u2026] Wrong. We do what we do to increase our understanding\u00BB http:\/\/t.co\/CepSN6Sduc",
  "id" : 399311280429080577,
  "created_at" : "2013-11-09 23:03:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/uXF86OUCSN",
      "expanded_url" : "http:\/\/www.elephantjournal.com\/2013\/11\/what-a-funeral-taught-me-about-polyamory-kristin-s-luce\/",
      "display_url" : "elephantjournal.com\/2013\/11\/what-a\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095943007, 8.2829424251 ]
  },
  "id_str" : "399301435214823425",
  "text" : "What a Funeral Taught Me About Polyamory: \u00ABHumans can\u2019t help but to love\u2014at best we can only pretend not to.\u00BB  http:\/\/t.co\/uXF86OUCSN",
  "id" : 399301435214823425,
  "created_at" : "2013-11-09 22:24:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096721668, 8.2829393819 ]
  },
  "id_str" : "399299551246704640",
  "text" : "Zwei Katzen klettern \u00FCber ihren Kopf. Aus dem Schlaf heraus wird \u2018thank you for assisting\u2019 gemurmelt.",
  "id" : 399299551246704640,
  "created_at" : "2013-11-09 22:16:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "indices" : [ 3, 10 ],
      "id_str" : "47876842",
      "id" : 47876842
    }, {
      "name" : "PLOS Biology",
      "screen_name" : "PLOSBiology",
      "indices" : [ 15, 27 ],
      "id_str" : "96102210",
      "id" : 96102210
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "plos",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/30vL4cgqti",
      "expanded_url" : "http:\/\/www.psblab.org\/?p=130",
      "display_url" : "psblab.org\/?p=130"
    } ]
  },
  "geo" : { },
  "id_str" : "399282619927756800",
  "text" : "RT @brembs: Is @PLOSBiology ignoring potential fraud in one of their papers? What does it take? http:\/\/t.co\/30vL4cgqti #plos",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PLOS Biology",
        "screen_name" : "PLOSBiology",
        "indices" : [ 3, 15 ],
        "id_str" : "96102210",
        "id" : 96102210
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "plos",
        "indices" : [ 107, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/30vL4cgqti",
        "expanded_url" : "http:\/\/www.psblab.org\/?p=130",
        "display_url" : "psblab.org\/?p=130"
      } ]
    },
    "geo" : { },
    "id_str" : "399202187210809345",
    "text" : "Is @PLOSBiology ignoring potential fraud in one of their papers? What does it take? http:\/\/t.co\/30vL4cgqti #plos",
    "id" : 399202187210809345,
    "created_at" : "2013-11-09 15:49:52 +0000",
    "user" : {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "protected" : false,
      "id_str" : "47876842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524937570984013824\/uPSUsTcU_normal.png",
      "id" : 47876842,
      "verified" : false
    }
  },
  "id" : 399282619927756800,
  "created_at" : "2013-11-09 21:09:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/Z1boceF0eV",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0078273?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosone%2FPLoSONE+(PLOS+ONE+Alerts%3A+New+Articles",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "399277316872101888",
  "text" : "Is \u201CHuh?\u201D a Universal Word? Conversational Infrastructure and the Convergent Evolution of Linguistic Items http:\/\/t.co\/Z1boceF0eV)",
  "id" : 399277316872101888,
  "created_at" : "2013-11-09 20:48:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/NLhq6m03OR",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/rafa\/the-electric-loog-guitar",
      "display_url" : "kickstarter.com\/projects\/rafa\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963864, 8.28297472 ]
  },
  "id_str" : "399265517191827456",
  "text" : "The Electric Loog Guitar http:\/\/t.co\/NLhq6m03OR",
  "id" : 399265517191827456,
  "created_at" : "2013-11-09 20:01:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/mTceXtNOou",
      "expanded_url" : "http:\/\/instagram.com\/p\/gf8CjPhwo5\/",
      "display_url" : "instagram.com\/p\/gf8CjPhwo5\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0140282104, 8.2576776303 ]
  },
  "id_str" : "399198350089912320",
  "text" : "stuck @ Zollhafen S\u00FCdmole http:\/\/t.co\/mTceXtNOou",
  "id" : 399198350089912320,
  "created_at" : "2013-11-09 15:34:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/YT1lHbsmhp",
      "expanded_url" : "http:\/\/instagram.com\/p\/gf7RlGhwnt\/",
      "display_url" : "instagram.com\/p\/gf7RlGhwnt\/"
    } ]
  },
  "geo" : { },
  "id_str" : "399196413491683328",
  "text" : "Planke Nord http:\/\/t.co\/YT1lHbsmhp",
  "id" : 399196413491683328,
  "created_at" : "2013-11-09 15:26:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0086577552, 8.28319688 ]
  },
  "id_str" : "399185570767056896",
  "text" : "\u00ABEntschuldige das ich \u2018Savages\u2019 ausgesucht hab. Ich wusste nicht wie schlecht er ist.\u00BB\u2014\u00ABDu hast \u2018Polys die druff sind? Gekauft!\u2019 gedacht?\u00BB",
  "id" : 399185570767056896,
  "created_at" : "2013-11-09 14:43:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095312236, 8.2825731972 ]
  },
  "id_str" : "399160779863511040",
  "text" : "\u00ABK\u00F6nnen Menschen und Vulkanier einfach nur Freunde sein?\u00BB \u2014 \u00ABDas frage ich mich bei unserer Beziehung auch immer.\u00BB",
  "id" : 399160779863511040,
  "created_at" : "2013-11-09 13:05:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0079427813, 8.2824388745 ]
  },
  "id_str" : "399133309865062401",
  "text" : "\u00ABDu bist doch die Fisting-Fachfrau?\u00BB \u2014 \u00ABSorry, aber ich hab da auch keine Faustregel\u2026\u00BB",
  "id" : 399133309865062401,
  "created_at" : "2013-11-09 11:16:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/hWjsnM1CMh",
      "expanded_url" : "http:\/\/hyakumonogatari.com\/2013\/10\/31\/katabira-no-tsuji-the-crossroad-of-corpses\/",
      "display_url" : "hyakumonogatari.com\/2013\/10\/31\/kat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "399073197234335744",
  "text" : "RT @PhilippBayer: Such a great story: \"The Crossroad of Corpses\" (relatively NSFL drawings at the end) http:\/\/t.co\/hWjsnM1CMh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/hWjsnM1CMh",
        "expanded_url" : "http:\/\/hyakumonogatari.com\/2013\/10\/31\/katabira-no-tsuji-the-crossroad-of-corpses\/",
        "display_url" : "hyakumonogatari.com\/2013\/10\/31\/kat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "399037476179693569",
    "text" : "Such a great story: \"The Crossroad of Corpses\" (relatively NSFL drawings at the end) http:\/\/t.co\/hWjsnM1CMh",
    "id" : 399037476179693569,
    "created_at" : "2013-11-09 04:55:22 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 399073197234335744,
  "created_at" : "2013-11-09 07:17:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/4SriaRYyir",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/?id=3169",
      "display_url" : "smbc-comics.com\/?id=3169"
    } ]
  },
  "geo" : { },
  "id_str" : "398934709717438464",
  "text" : "In Defense of the Anus: \u00ABNatural selection is a tinkerer, not an idiot.\u00BB http:\/\/t.co\/4SriaRYyir",
  "id" : 398934709717438464,
  "created_at" : "2013-11-08 22:07:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096482831, 8.2829254212 ]
  },
  "id_str" : "398933770147217409",
  "text" : "\u00ABDu riechst so gut.\u00BB \u2014 \u00ABDabei hab ich gar nicht gefurzt, das ist nur mein Mund.\u00BB",
  "id" : 398933770147217409,
  "created_at" : "2013-11-08 22:03:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/M8pxSS81Wh",
      "expanded_url" : "http:\/\/instagram.com\/p\/gdXb3vBwk0\/",
      "display_url" : "instagram.com\/p\/gdXb3vBwk0\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723745458, 8.6276945674 ]
  },
  "id_str" : "398835970906542080",
  "text" : "Lo-Fi indeed @ Biologicum http:\/\/t.co\/M8pxSS81Wh",
  "id" : 398835970906542080,
  "created_at" : "2013-11-08 15:34:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/vcxl2axBPr",
      "expanded_url" : "http:\/\/i.imgur.com\/h5WuF5W.gif",
      "display_url" : "i.imgur.com\/h5WuF5W.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722841875, 8.6276596975 ]
  },
  "id_str" : "398831683568664576",
  "text" : "\u00ABit feels like petting a very odd feeling cat\u00BB http:\/\/t.co\/vcxl2axBPr",
  "id" : 398831683568664576,
  "created_at" : "2013-11-08 15:17:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/3KfNJdDqpI",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/adamellis\/your-favorite-disney-princesses-with-beards?bffb",
      "display_url" : "buzzfeed.com\/adamellis\/your\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722841875, 8.6276596975 ]
  },
  "id_str" : "398815406284374016",
  "text" : "Your Favorite Disney Princesses With\u00A0Beards http:\/\/t.co\/3KfNJdDqpI",
  "id" : 398815406284374016,
  "created_at" : "2013-11-08 14:12:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722841875, 8.6276596975 ]
  },
  "id_str" : "398808684811530240",
  "text" : "Mensapersonal: \u00ABMeine Schwiegertochter kommt heute vorbei um sich von mir bemuttern zu lassen. Du weisst ja wie gut das von mir ist.\u00BB",
  "id" : 398808684811530240,
  "created_at" : "2013-11-08 13:46:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/XAFKiXR06I",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0076942",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722841875, 8.6276596975 ]
  },
  "id_str" : "398797146050560000",
  "text" : "Effect of Initial Fraction of Cooperators on Cooperative Behavior in Evolutionary Prisoner's Dilemma Game http:\/\/t.co\/XAFKiXR06I",
  "id" : 398797146050560000,
  "created_at" : "2013-11-08 13:00:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398787515299414016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722841875, 8.6276596975 ]
  },
  "id_str" : "398796337749450753",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog pro: soziale Kontrolle zu sauberer Review. Contra: junior scientists die \u2018Ber\u00FChmtheiten\u2019 reviewen sollen -&gt; bias zu pos. Reviews.",
  "id" : 398796337749450753,
  "in_reply_to_status_id" : 398787515299414016,
  "created_at" : "2013-11-08 12:57:10 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/A3SO9nYV9s",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0080234",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722841875, 8.6276596975 ]
  },
  "id_str" : "398765865640144896",
  "text" : "Olfactory Performance Is Predicted by Individual Sex-Atypicality, but Not Sexual Orientation http:\/\/t.co\/A3SO9nYV9s",
  "id" : 398765865640144896,
  "created_at" : "2013-11-08 10:56:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722841875, 8.6276596975 ]
  },
  "id_str" : "398764658141954048",
  "text" : "\u00ABHier dein Schl\u00FCssel, es ist noch alles da.\u00BB \u2013 \u00ABDu hast also nicht das Cluster geklaut?\u00BB \u2013 \u00ABIch hab kurz dran gedacht, aber: Zu anstrengend\u00BB",
  "id" : 398764658141954048,
  "created_at" : "2013-11-08 10:51:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 124, 130 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/OQg85LkkoE",
      "expanded_url" : "http:\/\/ssc.sagepub.com\/content\/early\/2013\/10\/31\/0894439313497468",
      "display_url" : "ssc.sagepub.com\/content\/early\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722841875, 8.6276596975 ]
  },
  "id_str" : "398760294451011584",
  "text" : "Where Am I? A Meta-Analysis of Experiments on the Effects of Progress Indicators for Web Surveys http:\/\/t.co\/OQg85LkkoE \/cc @Lobot",
  "id" : 398760294451011584,
  "created_at" : "2013-11-08 10:33:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/ycCrDbz1EV",
      "expanded_url" : "http:\/\/i.imgur.com\/ENEe9rN.gif",
      "display_url" : "i.imgur.com\/ENEe9rN.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722841875, 8.6276596975 ]
  },
  "id_str" : "398758612002422784",
  "text" : "Banthastic! http:\/\/t.co\/ycCrDbz1EV",
  "id" : 398758612002422784,
  "created_at" : "2013-11-08 10:27:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/Ep1E0F7PR7",
      "expanded_url" : "http:\/\/imgur.com\/CY1HB7D",
      "display_url" : "imgur.com\/CY1HB7D"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722841875, 8.6276596975 ]
  },
  "id_str" : "398758065685934080",
  "text" : "Push Button Officer X-127 http:\/\/t.co\/Ep1E0F7PR7",
  "id" : 398758065685934080,
  "created_at" : "2013-11-08 10:25:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 36, 40 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722032381, 8.6277396934 ]
  },
  "id_str" : "398750697526951936",
  "text" : "\u00ABGibt es was neues bei Twitter?\u00BB \u2014 \u00AB@scy hat sich den Nagellack entfernt.\u00BB \u2014 \u00ABNa dann kann Twitter ja an die B\u00F6rse.\u00BB",
  "id" : 398750697526951936,
  "created_at" : "2013-11-08 09:55:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096474096, 8.2830713399 ]
  },
  "id_str" : "398593281069568001",
  "text" : "\u00ABMetallica, die haben mir immer Angst gemacht. Genauso wie Axl Rose mit seinem engen H\u00F6schen.\u00BB",
  "id" : 398593281069568001,
  "created_at" : "2013-11-07 23:30:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0094868421, 8.2826973038 ]
  },
  "id_str" : "398554515399770112",
  "text" : "\u00ABAlso, wir waren im Serverraum, mit dem Hund\u2026\u00BB \u2014 \u00ABWie alle guten Sex-Geschichten beginnen.\u00BB",
  "id" : 398554515399770112,
  "created_at" : "2013-11-07 20:56:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/05OujXr1Vi",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=tcY5czIND-A",
      "display_url" : "youtube.com\/watch?v=tcY5cz\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095910167, 8.2829394567 ]
  },
  "id_str" : "398511407005962240",
  "text" : "I\u2019m disappointed, Twitter: The RadioLab episode on Dawn of MIDI is over 2 mo old &amp; no one told me how great they are! http:\/\/t.co\/05OujXr1Vi",
  "id" : 398511407005962240,
  "created_at" : "2013-11-07 18:04:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/xDYf7sY4YT",
      "expanded_url" : "http:\/\/instagram.com\/p\/gazWcQBwpZ\/",
      "display_url" : "instagram.com\/p\/gazWcQBwpZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "398475137697476608",
  "text" : "Feierabendzeit http:\/\/t.co\/xDYf7sY4YT",
  "id" : 398475137697476608,
  "created_at" : "2013-11-07 15:40:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 0, 13 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398465552425185280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398465994752282624",
  "in_reply_to_user_id" : 53639020,
  "text" : "@Unsichtbarer nein, das Original ist extrem buggy. :)",
  "id" : 398465994752282624,
  "in_reply_to_status_id" : 398465552425185280,
  "created_at" : "2013-11-07 15:04:30 +0000",
  "in_reply_to_screen_name" : "Unsichtbarer",
  "in_reply_to_user_id_str" : "53639020",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 0, 13 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398463830260727809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398464019771961344",
  "in_reply_to_user_id" : 53639020,
  "text" : "@Unsichtbarer ein nicht st\u00E4ndig abst\u00FCrzendes hires-remake w\u00FCrde mich schon so gl\u00FCcklich machen :)",
  "id" : 398464019771961344,
  "in_reply_to_status_id" : 398463830260727809,
  "created_at" : "2013-11-07 14:56:40 +0000",
  "in_reply_to_screen_name" : "Unsichtbarer",
  "in_reply_to_user_id_str" : "53639020",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 0, 13 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398462718975676417",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398463004897214464",
  "in_reply_to_user_id" : 53639020,
  "text" : "@Unsichtbarer wie k\u00F6nnte das keine gute Sache sein?! :D",
  "id" : 398463004897214464,
  "in_reply_to_status_id" : 398462718975676417,
  "created_at" : "2013-11-07 14:52:38 +0000",
  "in_reply_to_screen_name" : "Unsichtbarer",
  "in_reply_to_user_id_str" : "53639020",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398459166026919936",
  "text" : "\u00ABImmer dieses laute herumgehacke auf dem Keyboard\u2026\u00BB \u2013 \u00ABBabak O'Riley!\u00BB",
  "id" : 398459166026919936,
  "created_at" : "2013-11-07 14:37:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722779643, 8.6276638349 ]
  },
  "id_str" : "398413897658806272",
  "text" : "\u00ABFr\u00FCher haben wir einfach immer in den Respawn-Zeiten geschlafen. 44 Sekunden Power-Nap!\u00BB",
  "id" : 398413897658806272,
  "created_at" : "2013-11-07 11:37:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "indices" : [ 0, 6 ],
      "id_str" : "5751892",
      "id" : 5751892
    }, {
      "name" : "Julian Finn",
      "screen_name" : "hdsjulian",
      "indices" : [ 7, 17 ],
      "id_str" : "12192142",
      "id" : 12192142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398403240431460352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398403643797299200",
  "in_reply_to_user_id" : 5751892,
  "text" : "@mspro @hdsjulian Tut es nicht. Daten m\u00FCssen CC-0 sein, alles andere (selbst CC-BY) funktioniert nicht.",
  "id" : 398403643797299200,
  "in_reply_to_status_id" : 398403240431460352,
  "created_at" : "2013-11-07 10:56:45 +0000",
  "in_reply_to_screen_name" : "mspro",
  "in_reply_to_user_id_str" : "5751892",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Reuben",
      "screen_name" : "SusanReuben",
      "indices" : [ 3, 15 ],
      "id_str" : "317034895",
      "id" : 317034895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398387691542548480",
  "text" : "RT @SusanReuben: I love this, not because it's esp. hilarious, but because it's so English - official &amp; deadpan, but actually a joke.\nhttp:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SoumyaShetty25\/status\/398210948663894018\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/ASerY0B4ex",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYa6v3VIcAEHlOS.jpg",
        "id_str" : "398210948538068993",
        "id" : 398210948538068993,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYa6v3VIcAEHlOS.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 522
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 617
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 617
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 617
        } ],
        "display_url" : "pic.twitter.com\/ASerY0B4ex"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398375046873247745",
    "text" : "I love this, not because it's esp. hilarious, but because it's so English - official &amp; deadpan, but actually a joke.\nhttp:\/\/t.co\/ASerY0B4ex",
    "id" : 398375046873247745,
    "created_at" : "2013-11-07 09:03:07 +0000",
    "user" : {
      "name" : "Susan Reuben",
      "screen_name" : "SusanReuben",
      "protected" : false,
      "id_str" : "317034895",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734106180650426368\/CvGsWohd_normal.jpg",
      "id" : 317034895,
      "verified" : false
    }
  },
  "id" : 398387691542548480,
  "created_at" : "2013-11-07 09:53:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/ZZUWGiw8Nv",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/funny\/comments\/1q2855\/limerick_larry_the_greatest_commenter_in_pornhub\/",
      "display_url" : "reddit.com\/r\/funny\/commen\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398384646943424513",
  "text" : "Limerick Larry, the greatest commenter in Pornhub history http:\/\/t.co\/ZZUWGiw8Nv",
  "id" : 398384646943424513,
  "created_at" : "2013-11-07 09:41:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 99, 112 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/aNVlbZnCG1",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0078410",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398378249606422528",
  "text" : "HLA Typing from 1000 Genomes Whole Genome and Whole Exome Illumina Data http:\/\/t.co\/aNVlbZnCG1 \/cc @PhilippBayer",
  "id" : 398378249606422528,
  "created_at" : "2013-11-07 09:15:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/ty9wWowPay",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0073440",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398377461291159552",
  "text" : "Social Judgement in Borderline Personality Disorder http:\/\/t.co\/ty9wWowPay",
  "id" : 398377461291159552,
  "created_at" : "2013-11-07 09:12:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/EMcPTxa0zw",
      "expanded_url" : "http:\/\/www.reactiongifs.com\/wp-content\/uploads\/2013\/05\/bear-wave.gif",
      "display_url" : "reactiongifs.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398377075205480448",
  "text" : "Meeting people I apparently should know during the commute http:\/\/t.co\/EMcPTxa0zw",
  "id" : 398377075205480448,
  "created_at" : "2013-11-07 09:11:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/StYro07QRZ",
      "expanded_url" : "http:\/\/Archive.org",
      "display_url" : "Archive.org"
    }, {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/zXt3owpuFJ",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/11\/06\/archive-orgs-scanning-center.html",
      "display_url" : "boingboing.net\/2013\/11\/06\/arc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398375914415071232",
  "text" : "http:\/\/t.co\/StYro07QRZ's scanning center destroyed by\u00A0fire http:\/\/t.co\/zXt3owpuFJ",
  "id" : 398375914415071232,
  "created_at" : "2013-11-07 09:06:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Daou",
      "screen_name" : "peterdaou",
      "indices" : [ 3, 13 ],
      "id_str" : "18464266",
      "id" : 18464266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/dx24WoGwQN",
      "expanded_url" : "http:\/\/bit.ly\/1dOA80o",
      "display_url" : "bit.ly\/1dOA80o"
    } ]
  },
  "geo" : { },
  "id_str" : "398253912593281024",
  "text" : "RT @peterdaou: In America, if you're in a car accident and you're black, you can get shot and killed seeking help: http:\/\/t.co\/dx24WoGwQN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/dx24WoGwQN",
        "expanded_url" : "http:\/\/bit.ly\/1dOA80o",
        "display_url" : "bit.ly\/1dOA80o"
      } ]
    },
    "geo" : { },
    "id_str" : "398250702897553409",
    "text" : "In America, if you're in a car accident and you're black, you can get shot and killed seeking help: http:\/\/t.co\/dx24WoGwQN",
    "id" : 398250702897553409,
    "created_at" : "2013-11-07 00:49:01 +0000",
    "user" : {
      "name" : "Peter Daou",
      "screen_name" : "peterdaou",
      "protected" : false,
      "id_str" : "18464266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/855902920222625796\/E2_h_-xf_normal.jpg",
      "id" : 18464266,
      "verified" : true
    }
  },
  "id" : 398253912593281024,
  "created_at" : "2013-11-07 01:01:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398243647344214016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966665, 8.28295624 ]
  },
  "id_str" : "398243798649962496",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX dito ;)",
  "id" : 398243798649962496,
  "in_reply_to_status_id" : 398243647344214016,
  "created_at" : "2013-11-07 00:21:35 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/R2pVReVT4E",
      "expanded_url" : "http:\/\/i.imgur.com\/ZyJQgmx.jpg",
      "display_url" : "i.imgur.com\/ZyJQgmx.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966665, 8.28295624 ]
  },
  "id_str" : "398228835063582720",
  "text" : "Mugged http:\/\/t.co\/R2pVReVT4E",
  "id" : 398228835063582720,
  "created_at" : "2013-11-06 23:22:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/C3dSnpPpQ0",
      "expanded_url" : "http:\/\/euri.ca\/2012\/youre-probably-polluting-your-statistics-more-than-you-think\/index.html",
      "display_url" : "euri.ca\/2012\/youre-pro\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00966665, 8.28295624 ]
  },
  "id_str" : "398224939586961408",
  "text" : "You\u2019re probably polluting your statistics more than you think http:\/\/t.co\/C3dSnpPpQ0",
  "id" : 398224939586961408,
  "created_at" : "2013-11-06 23:06:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 26, 35 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/398208107366862848\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/ngQwnXDiV3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYa4KeiIYAARYkJ.png",
      "id_str" : "398208107203289088",
      "id" : 398208107203289088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYa4KeiIYAARYkJ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1039,
        "resize" : "fit",
        "w" : 1017
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 666
      }, {
        "h" : 1039,
        "resize" : "fit",
        "w" : 1017
      }, {
        "h" : 1039,
        "resize" : "fit",
        "w" : 1017
      } ],
      "display_url" : "pic.twitter.com\/ngQwnXDiV3"
    } ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 105, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958497, 8.282848395 ]
  },
  "id_str" : "398208107366862848",
  "text" : "Guess I need to apologize @Senficon. Mann\u2013Whitney U gives p &gt; .05 for all three possible comparisons. #quantifiedself http:\/\/t.co\/ngQwnXDiV3",
  "id" : 398208107366862848,
  "created_at" : "2013-11-06 21:59:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009609555, 8.2829011 ]
  },
  "id_str" : "398190531697995776",
  "text" : "\u00ABCaution: Cute Dog Video\u00BB Damn, WNYC really knows how to grab my attention\u2026",
  "id" : 398190531697995776,
  "created_at" : "2013-11-06 20:49:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 107, 120 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 121, 133 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095539425, 8.2829244775 ]
  },
  "id_str" : "398165353500798976",
  "text" : "Meh, looks like Solr is still making problems for openSNP. Manually restarting seems to be a temp. fix \/cc @PhilippBayer @helgerausch",
  "id" : 398165353500798976,
  "created_at" : "2013-11-06 19:09:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heiko S.",
      "screen_name" : "hkos",
      "indices" : [ 0, 5 ],
      "id_str" : "27012673",
      "id" : 27012673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398158267727503360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0094848732, 8.2829230372 ]
  },
  "id_str" : "398159358099746816",
  "in_reply_to_user_id" : 27012673,
  "text" : "@hkos so gerade, der Triumph von Try&amp;Error \u00FCber eine Sprache die man nicht spricht und nicht sprechen will.",
  "id" : 398159358099746816,
  "in_reply_to_status_id" : 398158267727503360,
  "created_at" : "2013-11-06 18:46:03 +0000",
  "in_reply_to_screen_name" : "hkos",
  "in_reply_to_user_id_str" : "27012673",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0094848732, 8.2829230372 ]
  },
  "id_str" : "398158469741961216",
  "text" : "Kann mir jetzt in den CV schreiben mit meiner Gitarre schon in S\u00FCdkorea aufgetreten zu sein. Oder so \u00E4hnlich.",
  "id" : 398158469741961216,
  "created_at" : "2013-11-06 18:42:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heiko S.",
      "screen_name" : "hkos",
      "indices" : [ 0, 5 ],
      "id_str" : "27012673",
      "id" : 27012673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398154297860694016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095926145, 8.2828298378 ]
  },
  "id_str" : "398158152170242049",
  "in_reply_to_user_id" : 27012673,
  "text" : "@hkos ich musste es auch nicht lesen. Nur die Dependencies installieren damit ich die Ziel-Software installiert bekomme. ;)",
  "id" : 398158152170242049,
  "in_reply_to_status_id" : 398154297860694016,
  "created_at" : "2013-11-06 18:41:15 +0000",
  "in_reply_to_screen_name" : "hkos",
  "in_reply_to_user_id_str" : "27012673",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heiko S.",
      "screen_name" : "hkos",
      "indices" : [ 0, 5 ],
      "id_str" : "27012673",
      "id" : 27012673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398093684807585792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0091738254, 8.2834514394 ]
  },
  "id_str" : "398153244146675713",
  "in_reply_to_user_id" : 27012673,
  "text" : "@hkos am Ende gewonnen. Hat nur 2 ganze Arbeitstage gedauert!",
  "id" : 398153244146675713,
  "in_reply_to_status_id" : 398093684807585792,
  "created_at" : "2013-11-06 18:21:45 +0000",
  "in_reply_to_screen_name" : "hkos",
  "in_reply_to_user_id_str" : "27012673",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398152189459169280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0085579377, 8.2831414067 ]
  },
  "id_str" : "398153072570302464",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon gib mir 5 damit ich nicht den Gitarrensimulator in der Bahn nutzen muss. ;)",
  "id" : 398153072570302464,
  "in_reply_to_status_id" : 398152189459169280,
  "created_at" : "2013-11-06 18:21:04 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398151866166411264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0043204997, 8.288815719 ]
  },
  "id_str" : "398152136221278208",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon willst du gleich ein Remote-Schlaflied gespielt bekommen?",
  "id" : 398152136221278208,
  "in_reply_to_status_id" : 398151866166411264,
  "created_at" : "2013-11-06 18:17:21 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398150028612485120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0045449272, 8.3004899179 ]
  },
  "id_str" : "398151588839440384",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon bist du noch oder schon wieder wach? :p",
  "id" : 398151588839440384,
  "in_reply_to_status_id" : 398150028612485120,
  "created_at" : "2013-11-06 18:15:10 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398145196229394432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1021383699, 8.5715128878 ]
  },
  "id_str" : "398146221715771392",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 wir k\u00F6nnen uns aber demn\u00E4chst auch gern mal wieder so auf ein Bier treffen. :)",
  "id" : 398146221715771392,
  "in_reply_to_status_id" : 398145196229394432,
  "created_at" : "2013-11-06 17:53:51 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398144391975813122",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0961775147, 8.6341596488 ]
  },
  "id_str" : "398144841806544897",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 muss mich erstmal um den Haushalt (aka die Katzen) k\u00FCmmern.",
  "id" : 398144841806544897,
  "in_reply_to_status_id" : 398144391975813122,
  "created_at" : "2013-11-06 17:48:22 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398143409644634112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1103271853, 8.6701495643 ]
  },
  "id_str" : "398143600988798976",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 h\u00E4ttest du noch 3 Minuten gewartet h\u00E4tten wir zusammen S1 fahren k\u00F6nnen. ;)",
  "id" : 398143600988798976,
  "in_reply_to_status_id" : 398143409644634112,
  "created_at" : "2013-11-06 17:43:26 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398129424144805888",
  "text" : "\u00ABIch versuche mich in den Nutzer hineinzuversetzen: Was w\u00FCrde er in einer solchen Situation tun wollen?\u00BB \u2013 \u00ABDen TFT aus dem Fenster werfen\u2026\u00BB",
  "id" : 398129424144805888,
  "created_at" : "2013-11-06 16:47:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/nrBpic9vFN",
      "expanded_url" : "http:\/\/imgur.com\/gallery\/lrLPrWQ",
      "display_url" : "imgur.com\/gallery\/lrLPrWQ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398106096810082304",
  "text" : "I made you a nest http:\/\/t.co\/nrBpic9vFN",
  "id" : 398106096810082304,
  "created_at" : "2013-11-06 15:14:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/NhCbcI7lck",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3167",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398094586540597248",
  "text" : "Infographics http:\/\/t.co\/NhCbcI7lck",
  "id" : 398094586540597248,
  "created_at" : "2013-11-06 14:28:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398084856611368960",
  "text" : "\u00ABIst perl module installieren so schlimm?\u00BB \u2013 \u00ABMir f\u00E4llt gar kein passender Vergleich ein um den Schmerz zu beschreiben.\u00BB",
  "id" : 398084856611368960,
  "created_at" : "2013-11-06 13:50:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398070449655263232",
  "text" : "cat stevens.txt",
  "id" : 398070449655263232,
  "created_at" : "2013-11-06 12:52:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/rD8a6QRRbl",
      "expanded_url" : "http:\/\/upmic.wordpress.com\/2013\/06\/10\/negative-data\/",
      "display_url" : "upmic.wordpress.com\/2013\/06\/10\/neg\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398062656390983680",
  "text" : "Negative Data http:\/\/t.co\/rD8a6QRRbl",
  "id" : 398062656390983680,
  "created_at" : "2013-11-06 12:21:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722854769, 8.6276621394 ]
  },
  "id_str" : "398049822672183296",
  "text" : "\u00ABSchau mal, ist das Rosmarin oder Thymian?\u00BB \u2014 \u00ABHangelst du dich mangels Botanikwissen durch Scarborough Fair?\u00BB",
  "id" : 398049822672183296,
  "created_at" : "2013-11-06 11:30:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398042092095549441",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398042281326161920",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX Ich habe immer schon lange Feierabend gemacht wenn die Leute anfangen zu trinken!",
  "id" : 398042281326161920,
  "in_reply_to_status_id" : 398042092095549441,
  "created_at" : "2013-11-06 11:00:49 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398041654130905088",
  "text" : "\u00ABIch w\u00FCrde ja gerne arbeiten. Aber immer werden hier Parties gefeiert und vor lauter Rum trinken kommt man zu nichts!\u00BB",
  "id" : 398041654130905088,
  "created_at" : "2013-11-06 10:58:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398039984768573440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398040306069045248",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s h\u00F6r lieber auf Twitter zu lesen damit deine Diss heut Abend fertig ist ;)",
  "id" : 398040306069045248,
  "in_reply_to_status_id" : 398039984768573440,
  "created_at" : "2013-11-06 10:52:58 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/yIidlJMDYW",
      "expanded_url" : "http:\/\/www.kritikdervernetztenvernunft.de\/2013\/11\/05\/schnelles-internet-ist-kein-selbstzweck\/",
      "display_url" : "kritikdervernetztenvernunft.de\/2013\/11\/05\/sch\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398039813703884800",
  "text" : "\u00ABSchnelles Internet ist kein Selbstzweck.\u00BB Ich denk schon, als Enabling f\u00FCr neue Technologien die darauf aufbauen. http:\/\/t.co\/yIidlJMDYW",
  "id" : 398039813703884800,
  "created_at" : "2013-11-06 10:51:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fukami",
      "screen_name" : "fukami",
      "indices" : [ 3, 10 ],
      "id_str" : "1209301",
      "id" : 1209301
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Rails",
      "indices" : [ 60, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/VuxK1CRril",
      "expanded_url" : "http:\/\/homakov.blogspot.de\/2013\/11\/stealing-user-session-with-open.html",
      "display_url" : "homakov.blogspot.de\/2013\/11\/steali\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398033869653696512",
  "text" : "RT @fukami: Stealing user session with open-redirect bug in #Rails http:\/\/t.co\/VuxK1CRril",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Rails",
        "indices" : [ 48, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/VuxK1CRril",
        "expanded_url" : "http:\/\/homakov.blogspot.de\/2013\/11\/stealing-user-session-with-open.html",
        "display_url" : "homakov.blogspot.de\/2013\/11\/steali\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "398025962354663424",
    "text" : "Stealing user session with open-redirect bug in #Rails http:\/\/t.co\/VuxK1CRril",
    "id" : 398025962354663424,
    "created_at" : "2013-11-06 09:55:59 +0000",
    "user" : {
      "name" : "fukami",
      "screen_name" : "fukami",
      "protected" : false,
      "id_str" : "1209301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772745887\/fukami-twitter_normal.jpg",
      "id" : 1209301,
      "verified" : false
    }
  },
  "id" : 398033869653696512,
  "created_at" : "2013-11-06 10:27:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/aRbg4weiNb",
      "expanded_url" : "http:\/\/beardvertising.com\/",
      "display_url" : "beardvertising.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398029256552644608",
  "text" : "Beardvertising: \u00ABImagine if this cat was your ad\u00BB http:\/\/t.co\/aRbg4weiNb",
  "id" : 398029256552644608,
  "created_at" : "2013-11-06 10:09:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/VcTXdROlaX",
      "expanded_url" : "http:\/\/vimeo.com\/77846004",
      "display_url" : "vimeo.com\/77846004"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398027017201123328",
  "text" : "lmgtfy 2.0 http:\/\/t.co\/VcTXdROlaX",
  "id" : 398027017201123328,
  "created_at" : "2013-11-06 10:00:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/PA8tzxcaC9",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0078663",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722810323, 8.6276602815 ]
  },
  "id_str" : "398024945491775488",
  "text" : "Sex Differences in How Social Networks and Relationship Quality Influence Experimental Pain Sensitivity http:\/\/t.co\/PA8tzxcaC9",
  "id" : 398024945491775488,
  "created_at" : "2013-11-06 09:51:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1001030792, 8.5697841496 ]
  },
  "id_str" : "398007900012294144",
  "text" : "\u00ABThe NT is a brutal destroyer of human illusions. If you follow Jesus &amp; don\u2019t end up dead, it appears you have some explaining to do.\u00BB",
  "id" : 398007900012294144,
  "created_at" : "2013-11-06 08:44:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/JdRfipyqoa",
      "expanded_url" : "http:\/\/i.imgur.com\/dBSM6s2.gif",
      "display_url" : "i.imgur.com\/dBSM6s2.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009587905, 8.28294847 ]
  },
  "id_str" : "397884420784652288",
  "text" : "w00t? http:\/\/t.co\/JdRfipyqoa",
  "id" : 397884420784652288,
  "created_at" : "2013-11-06 00:33:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "howtobealone",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Wosv0jkzQm",
      "expanded_url" : "http:\/\/amzn.com\/k\/pnbJuHMXRmKs5yxSyPgsCQ",
      "display_url" : "amzn.com\/k\/pnbJuHMXRmKs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397872016399015937",
  "text" : "I have to repeat it: This essay on privacy &amp; panic was published in 1998, not 201X. #howtobealone http:\/\/t.co\/Wosv0jkzQm Just as most...",
  "id" : 397872016399015937,
  "created_at" : "2013-11-05 23:44:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 3, 11 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397869904034291712",
  "text" : "RT @rmounce: PDF supp data must die. KILL IT WITH FIRE! RT Why bioinformaticians hate the \"traditional journal article\" http:\/\/t.co\/v5WCpql\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neil Saunders",
        "screen_name" : "neilfws",
        "indices" : [ 130, 138 ],
        "id_str" : "14162706",
        "id" : 14162706
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/v5WCpql9A0",
        "expanded_url" : "http:\/\/wp.me\/p1oWi-W0",
        "display_url" : "wp.me\/p1oWi-W0"
      } ]
    },
    "geo" : { },
    "id_str" : "397867938063343616",
    "text" : "PDF supp data must die. KILL IT WITH FIRE! RT Why bioinformaticians hate the \"traditional journal article\" http:\/\/t.co\/v5WCpql9A0 @neilfws",
    "id" : 397867938063343616,
    "created_at" : "2013-11-05 23:28:03 +0000",
    "user" : {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "protected" : false,
      "id_str" : "222765418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668402841262927872\/2vZUj52I_normal.jpg",
      "id" : 222765418,
      "verified" : false
    }
  },
  "id" : 397869904034291712,
  "created_at" : "2013-11-05 23:35:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 62, 68 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/Lfbb7Prza6",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Gunner_%28dog%29",
      "display_url" : "en.m.wikipedia.org\/wiki\/Gunner_%2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.104487, 8.701031 ]
  },
  "id_str" : "397799222512480256",
  "text" : "Gunner, Australia's air-raid early warning dog during WW2 \/cc @Lobot  http:\/\/t.co\/Lfbb7Prza6",
  "id" : 397799222512480256,
  "created_at" : "2013-11-05 18:55:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1024968327, 8.7844572194 ]
  },
  "id_str" : "397796158921539584",
  "text" : "\u00BBSprache ver\u00E4ndert das Denken hab ich geh\u00F6rt.\u00BB \u2014 \u00ABKeine Sorge, da gibt es nicht viel zu \u00E4ndern bei dir.\u00BB",
  "id" : 397796158921539584,
  "created_at" : "2013-11-05 18:42:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397745108453306368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1025131334, 8.7842898078 ]
  },
  "id_str" : "397795326922592256",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog dann trink einen f\u00FCr mich mit. :)",
  "id" : 397795326922592256,
  "in_reply_to_status_id" : 397745108453306368,
  "created_at" : "2013-11-05 18:39:31 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397744283299491841",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1133692341, 8.6785719943 ]
  },
  "id_str" : "397744793247555585",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog leider nein. Aber viel Spass und Gr\u00FC\u00DFe an den Rest. Trink nicht so viel. ;)",
  "id" : 397744793247555585,
  "in_reply_to_status_id" : 397744283299491841,
  "created_at" : "2013-11-05 15:18:43 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1133387329, 8.6786860177 ]
  },
  "id_str" : "397741733884493824",
  "text" : "\u00ABSag mal deine Flugnummern. Damit ich wei\u00DF welche Abst\u00FCrze ich im Auge behalten sollte.\u00BB",
  "id" : 397741733884493824,
  "created_at" : "2013-11-05 15:06:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/2KEobIpQ8f",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/AskReddit\/comments\/1pxrf5\/how_did_you_introduce_farting_into_your\/",
      "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397715405952659456",
  "text" : "\/r\/RelationshipAdvice \u00ABNow we basically shit our pants in front of each other &amp; neither of us bat an eye.\u00BB http:\/\/t.co\/2KEobIpQ8f",
  "id" : 397715405952659456,
  "created_at" : "2013-11-05 13:21:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/R2UDmPNgcn",
      "expanded_url" : "http:\/\/i.imgur.com\/GCWUgxc.gif",
      "display_url" : "i.imgur.com\/GCWUgxc.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "397708810732597248",
  "text" : "Yes, this is dog! http:\/\/t.co\/R2UDmPNgcn",
  "id" : 397708810732597248,
  "created_at" : "2013-11-05 12:55:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/UJT9WzaEV7",
      "expanded_url" : "http:\/\/i.imgur.com\/KhlV8VW.gif",
      "display_url" : "i.imgur.com\/KhlV8VW.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "397683509860372480",
  "geo" : { },
  "id_str" : "397685109496639489",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot yup, by chemical warfare http:\/\/t.co\/UJT9WzaEV7",
  "id" : 397685109496639489,
  "in_reply_to_status_id" : 397683509860372480,
  "created_at" : "2013-11-05 11:21:33 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/tNhsjjGcBb",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/11\/04\/kickstarting-a-documentary-abo.html",
      "display_url" : "boingboing.net\/2013\/11\/04\/kic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397649758493241344",
  "text" : "Kickstarting a documentary about cops shooting dogs http:\/\/t.co\/tNhsjjGcBb",
  "id" : 397649758493241344,
  "created_at" : "2013-11-05 09:01:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/g5n9zcRBxt",
      "expanded_url" : "http:\/\/replygif.net\/i\/1069.gif",
      "display_url" : "replygif.net\/i\/1069.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009587905, 8.28294847 ]
  },
  "id_str" : "397516096653492224",
  "text" : "http:\/\/t.co\/g5n9zcRBxt",
  "id" : 397516096653492224,
  "created_at" : "2013-11-05 00:09:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096760982, 8.2829963141 ]
  },
  "id_str" : "397473640973107200",
  "text" : "\u00ABDer Kater jammert weil er nass ist und trocken gekuschelt werden will.\u00BB \u2014 \u00ABIch bin auch ganz nass geworden!\u00BB",
  "id" : 397473640973107200,
  "created_at" : "2013-11-04 21:21:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily [redacted] Willingham\uD83C\uDFC1",
      "screen_name" : "ejwillingham",
      "indices" : [ 0, 13 ],
      "id_str" : "77907514",
      "id" : 77907514
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 51, 60 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397469737745010689",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096244222, 8.2830258173 ]
  },
  "id_str" : "397471656492675072",
  "in_reply_to_user_id" : 77907514,
  "text" : "@ejwillingham yes, the girl in the green shirt got @Senficon and me as well! Thanks for sharing :)",
  "id" : 397471656492675072,
  "in_reply_to_status_id" : 397469737745010689,
  "created_at" : "2013-11-04 21:13:22 +0000",
  "in_reply_to_screen_name" : "ejwillingham",
  "in_reply_to_user_id_str" : "77907514",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily [redacted] Willingham\uD83C\uDFC1",
      "screen_name" : "ejwillingham",
      "indices" : [ 56, 69 ],
      "id_str" : "77907514",
      "id" : 77907514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/dm4T8RTwXs",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/2013\/11\/04\/kids-react-gay-marriage_n_4212543.html?utm_hp_ref=gay-voices",
      "display_url" : "huffingtonpost.com\/2013\/11\/04\/kid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397469325390778368",
  "text" : "So cute (I\u2019d marry microscopes in an instant!) &lt;3 RT @ejwillingham: \u201CIf I got a box of microscopes, would I be gay?\u201D http:\/\/t.co\/dm4T8RTwXs",
  "id" : 397469325390778368,
  "created_at" : "2013-11-04 21:04:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397378780769296384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1167581752, 8.6804578965 ]
  },
  "id_str" : "397380381445718016",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich it also may be \u2018heard through\u2019, my feminist, baby killing high tyrant!",
  "id" : 397380381445718016,
  "in_reply_to_status_id" : 397378780769296384,
  "created_at" : "2013-11-04 15:10:40 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397377078175490048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1392339037, 8.6702622924 ]
  },
  "id_str" : "397377859557539840",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich close, but usually it\u2019s just \u2018hat tip\u2019",
  "id" : 397377859557539840,
  "in_reply_to_status_id" : 397377078175490048,
  "created_at" : "2013-11-04 15:00:39 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 0, 15 ],
      "id_str" : "73134122",
      "id" : 73134122
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 16, 25 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397375100431114240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1440614344, 8.6684625779 ]
  },
  "id_str" : "397377357889417216",
  "in_reply_to_user_id" : 73134122,
  "text" : "@astefanowitsch @JP_Stich never was that big a fan of their music tbh.",
  "id" : 397377357889417216,
  "in_reply_to_status_id" : 397375100431114240,
  "created_at" : "2013-11-04 14:58:39 +0000",
  "in_reply_to_screen_name" : "astefanowitsch",
  "in_reply_to_user_id_str" : "73134122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 79, 88 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/maximalgedanke\/status\/397362325130199040\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/xRWo7qNhe1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYO27ezCQAAkuyk.jpg",
      "id_str" : "397362325134393344",
      "id" : 397362325134393344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYO27ezCQAAkuyk.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/xRWo7qNhe1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1694251515, 8.6222278854 ]
  },
  "id_str" : "397374957589913600",
  "text" : "That sounds like a fun agenda, except for witchcraft http:\/\/t.co\/xRWo7qNhe1 HT @JP_Stich",
  "id" : 397374957589913600,
  "created_at" : "2013-11-04 14:49:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397359147114434560",
  "text" : "\u00ABFr\u00FCher mochte sie uns noch alle. Und ist uns immer unter den Rock gegangen. Das war total sch\u00F6n!\u00BB",
  "id" : 397359147114434560,
  "created_at" : "2013-11-04 13:46:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattias Bj\u00E4rnemalm",
      "screen_name" : "_Mab_",
      "indices" : [ 3, 9 ],
      "id_str" : "20418318",
      "id" : 20418318
    }, {
      "name" : "Amelia Andersdotter",
      "screen_name" : "teirdes",
      "indices" : [ 110, 118 ],
      "id_str" : "43017642",
      "id" : 43017642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397353834378694656",
  "text" : "RT @_Mab_: just nu \u00E4r omr\u00F6stningen ig\u00E5ng p\u00E5 Piratpartiets medlemsm\u00F6te om toppnamnet p\u00E5 EU-listan. Vill man se @teirdes \u00F6verst \u00E4r det nu man\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amelia Andersdotter",
        "screen_name" : "teirdes",
        "indices" : [ 99, 107 ],
        "id_str" : "43017642",
        "id" : 43017642
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "397127378691825665",
    "text" : "just nu \u00E4r omr\u00F6stningen ig\u00E5ng p\u00E5 Piratpartiets medlemsm\u00F6te om toppnamnet p\u00E5 EU-listan. Vill man se @teirdes \u00F6verst \u00E4r det nu man m\u00E5ste r\u00F6sta",
    "id" : 397127378691825665,
    "created_at" : "2013-11-03 22:25:20 +0000",
    "user" : {
      "name" : "Mattias Bj\u00E4rnemalm",
      "screen_name" : "_Mab_",
      "protected" : false,
      "id_str" : "20418318",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795619391140495364\/7zLQ4RZr_normal.jpg",
      "id" : 20418318,
      "verified" : false
    }
  },
  "id" : 397353834378694656,
  "created_at" : "2013-11-04 13:25:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/eWZVVpCTNT",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/AskReddit\/comments\/1pudb0\/lefties_of_reddit_what_are_little_inconveniences\/cd665ec",
      "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397336047350054912",
  "text" : "ITT: fellow southpaws on what annoys them. One I really like, as I only figured that out this year: http:\/\/t.co\/eWZVVpCTNT",
  "id" : 397336047350054912,
  "created_at" : "2013-11-04 12:14:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397327441724579842",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722895381, 8.6276606219 ]
  },
  "id_str" : "397327853605646336",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab I never learnt perl but went with Python because it felt much less confusing as first language. But I\u2019m sure you will handle it :)",
  "id" : 397327853605646336,
  "in_reply_to_status_id" : 397327441724579842,
  "created_at" : "2013-11-04 11:41:56 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397326412425609216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722876127, 8.627660655 ]
  },
  "id_str" : "397327025218002944",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab good luck!",
  "id" : 397327025218002944,
  "in_reply_to_status_id" : 397326412425609216,
  "created_at" : "2013-11-04 11:38:39 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723141024, 8.6276652887 ]
  },
  "id_str" : "397319712696459264",
  "text" : "\u00ABDer Aufzug hat ein Software-Update bekommen. Jetzt funktioniert er nicht mehr.\u00BB \u2014 \u00ABDeshalb spielt ihr zu f\u00FCnft an der offenen Elektronik?\u00BB",
  "id" : 397319712696459264,
  "created_at" : "2013-11-04 11:09:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/ZWWs2AAWkQ",
      "expanded_url" : "http:\/\/i.imgur.com\/GKd1n3m.jpg",
      "display_url" : "i.imgur.com\/GKd1n3m.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "397297646974414848",
  "text" : "Something I need to put up in our groups kitchen http:\/\/t.co\/ZWWs2AAWkQ",
  "id" : 397297646974414848,
  "created_at" : "2013-11-04 09:41:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/gQD6cNW9Q4",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0078866",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397295787110965248",
  "text" : "The Diversity and Distribution of Fungi on Residential Surfaces http:\/\/t.co\/gQD6cNW9Q4",
  "id" : 397295787110965248,
  "created_at" : "2013-11-04 09:34:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/Hsrso7PoWM",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3164",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397287575976550400",
  "text" : "The drawbacks of immortality http:\/\/t.co\/Hsrso7PoWM",
  "id" : 397287575976550400,
  "created_at" : "2013-11-04 09:01:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/1YDQoi6JcY",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2013\/11\/scientists-nuclear-power-can-prevent-use-of-the-atmosphere-as-a-waste-dump\/",
      "display_url" : "arstechnica.com\/science\/2013\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397286457590571008",
  "text" : "Four climate researchers publicly ask policymakers to reconsider nuclear opposition. http:\/\/t.co\/1YDQoi6JcY",
  "id" : 397286457590571008,
  "created_at" : "2013-11-04 08:57:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397284183011098624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1728705876, 8.6275917571 ]
  },
  "id_str" : "397285199790497792",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer but that was before I figured out that ironically his defense of the public is more privacy ;)",
  "id" : 397285199790497792,
  "in_reply_to_status_id" : 397284183011098624,
  "created_at" : "2013-11-04 08:52:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397284183011098624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1725717308, 8.6276220158 ]
  },
  "id_str" : "397285100402270208",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer and I would even have agreed on the need for defending the public sphere at first glance.",
  "id" : 397285100402270208,
  "in_reply_to_status_id" : 397284183011098624,
  "created_at" : "2013-11-04 08:52:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397282803252867072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1668710309, 8.6297381111 ]
  },
  "id_str" : "397283272524595201",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, the conclusions of what to do are weird. But the problem description could have been published today (it\u2019s from 98!)",
  "id" : 397283272524595201,
  "in_reply_to_status_id" : 397282803252867072,
  "created_at" : "2013-11-04 08:44:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397281950756372480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1566765411, 8.6564222351 ]
  },
  "id_str" : "397282355452592128",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah! Eery how up to date the essay on privacy is (though I don\u2019t agree with the \u2018doing a front for the public\u2019-conclusion)",
  "id" : 397282355452592128,
  "in_reply_to_status_id" : 397281950756372480,
  "created_at" : "2013-11-04 08:41:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397281350153023488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1566812679, 8.6561471557 ]
  },
  "id_str" : "397281668492701696",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer good luck with that! (btw: just came across the literary inspiration of your \u2018books I an expect to read\u2019-calculation! :))",
  "id" : 397281668492701696,
  "in_reply_to_status_id" : 397281350153023488,
  "created_at" : "2013-11-04 08:38:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "howtobealone",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0964875658, 8.6027165624 ]
  },
  "id_str" : "397275801156337664",
  "text" : "\u00ABOn closer examination, though, privacy proves to be the Cheshire Cat of values: not much substance, but a very winning smile\u00BB #howtobealone",
  "id" : 397275801156337664,
  "created_at" : "2013-11-04 08:15:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 34, 47 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/8Qe6VLe6MF",
      "expanded_url" : "https:\/\/www.goodreads.com\/review\/show\/474783310",
      "display_url" : "goodreads.com\/review\/show\/47\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0852255255, 8.5095835547 ]
  },
  "id_str" : "397273785591943168",
  "text" : "Fun: Talking group selection with @PhilippBayer Miss doing that afk while slowly getting drunk https:\/\/t.co\/8Qe6VLe6MF",
  "id" : 397273785591943168,
  "created_at" : "2013-11-04 08:07:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Jones",
      "screen_name" : "moleitau",
      "indices" : [ 3, 12 ],
      "id_str" : "821",
      "id" : 821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/YAJgaQb5IP",
      "expanded_url" : "http:\/\/wp.me\/pjrnv-GK",
      "display_url" : "wp.me\/pjrnv-GK"
    } ]
  },
  "geo" : { },
  "id_str" : "397268458846822400",
  "text" : "RT @moleitau: Bye Dopplr http:\/\/t.co\/YAJgaQb5IP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 33 ],
        "url" : "http:\/\/t.co\/YAJgaQb5IP",
        "expanded_url" : "http:\/\/wp.me\/pjrnv-GK",
        "display_url" : "wp.me\/pjrnv-GK"
      } ]
    },
    "geo" : { },
    "id_str" : "397179962609766401",
    "text" : "Bye Dopplr http:\/\/t.co\/YAJgaQb5IP",
    "id" : 397179962609766401,
    "created_at" : "2013-11-04 01:54:16 +0000",
    "user" : {
      "name" : "Matt Jones",
      "screen_name" : "moleitau",
      "protected" : false,
      "id_str" : "821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2269300250\/x0hlgg1ix3uygnm0eiyu_normal.jpeg",
      "id" : 821,
      "verified" : false
    }
  },
  "id" : 397268458846822400,
  "created_at" : "2013-11-04 07:45:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397236233241255936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0072648559, 8.2830603085 ]
  },
  "id_str" : "397267405866811392",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer sequenceLDhot? ;)",
  "id" : 397267405866811392,
  "in_reply_to_status_id" : 397236233241255936,
  "created_at" : "2013-11-04 07:41:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 61, 66 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0071003926, 8.2832246016 ]
  },
  "id_str" : "397266454707716096",
  "text" : "Dreamt of unique kmers and seed extension strategies. Thanks @li5a",
  "id" : 397266454707716096,
  "created_at" : "2013-11-04 07:37:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397163874962505728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0072161147, 8.2831143148 ]
  },
  "id_str" : "397264871429251072",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that sounds like your job may be secure but only 10 ppl worldwide got those jobs ;)",
  "id" : 397264871429251072,
  "in_reply_to_status_id" : 397163874962505728,
  "created_at" : "2013-11-04 07:31:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 57, 70 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/31dWd89Z4p",
      "expanded_url" : "http:\/\/zachbruggeman.me\/dogescript\/",
      "display_url" : "zachbruggeman.me\/dogescript\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096729528, 8.2831035229 ]
  },
  "id_str" : "397159589336346624",
  "text" : "I know what my students will have to learn next &lt;3 RT @PhilippBayer: such geniouse wow http:\/\/t.co\/31dWd89Z4p",
  "id" : 397159589336346624,
  "created_at" : "2013-11-04 00:33:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397137653927129088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096560425, 8.2830793325 ]
  },
  "id_str" : "397141310140080130",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a nevermind, I\u2019m stupid. Did non-overlapping windows instead of increment by 1.",
  "id" : 397141310140080130,
  "in_reply_to_status_id" : 397137653927129088,
  "created_at" : "2013-11-03 23:20:41 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397137653927129088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096560425, 8.2830793325 ]
  },
  "id_str" : "397140448877498368",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a my quick sliding window run over chrY of GRCh37 only gave 1.4 mio unique kmers? o_O",
  "id" : 397140448877498368,
  "in_reply_to_status_id" : 397137653927129088,
  "created_at" : "2013-11-03 23:17:16 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397137653927129088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009587905, 8.28294847 ]
  },
  "id_str" : "397138364635566080",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a my feeling is that it might very well be possible. But let me have a quick test on that :)",
  "id" : 397138364635566080,
  "in_reply_to_status_id" : 397137653927129088,
  "created_at" : "2013-11-03 23:08:59 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397137653927129088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009587905, 8.28294847 ]
  },
  "id_str" : "397137952708755456",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a yeah, so you have like 30 Mb left for lots of variation to happen. And there you\u2019ll have constraints as well.",
  "id" : 397137952708755456,
  "in_reply_to_status_id" : 397137653927129088,
  "created_at" : "2013-11-03 23:07:21 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397134376309239808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009587905, 8.28294847 ]
  },
  "id_str" : "397136642303336449",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a had a brief look into the repeats via UCSC. Looks like ~ 50% of chrY are STRs &amp; other repeats.",
  "id" : 397136642303336449,
  "in_reply_to_status_id" : 397134376309239808,
  "created_at" : "2013-11-03 23:02:08 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397134376309239808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009587905, 8.28294847 ]
  },
  "id_str" : "397135157502939136",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a doing a sliding window for getting\/counting all kmers?",
  "id" : 397135157502939136,
  "in_reply_to_status_id" : 397134376309239808,
  "created_at" : "2013-11-03 22:56:14 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397132157098803201",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009587905, 8.28294847 ]
  },
  "id_str" : "397133768966045696",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a well, it\u2019s only like what, 60 Mb, in size?",
  "id" : 397133768966045696,
  "in_reply_to_status_id" : 397132157098803201,
  "created_at" : "2013-11-03 22:50:43 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009680708, 8.283071336 ]
  },
  "id_str" : "397100870048813056",
  "text" : "\u00ABIch k\u00F6nnte zwar besser auf dich als auf Essen verzichten. Aber es ist gar keine so emotionale Beziehung, es ist mehr Friends With Benefits\u00BB",
  "id" : 397100870048813056,
  "created_at" : "2013-11-03 20:39:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009679593, 8.2830497012 ]
  },
  "id_str" : "397094101012996096",
  "text" : "\u00ABIch geh noch kurz die Katzen f\u00FCttern und aufs Klo.\u00BB \u2014 \u00ABSchei\u00DF nicht in die N\u00E4pfe!\u00BB",
  "id" : 397094101012996096,
  "created_at" : "2013-11-03 20:13:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Bellersen",
      "screen_name" : "nichimtakt",
      "indices" : [ 0, 11 ],
      "id_str" : "48065959",
      "id" : 48065959
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 96, 105 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397077582661038080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1856638026, 7.5906821899 ]
  },
  "id_str" : "397078180496166912",
  "in_reply_to_user_id" : 48065959,
  "text" : "@nichimtakt das w\u00E4re n\u00FCtzlich wenn ich dort diskutieren wollen w\u00FCrde. Ich will ja nur ein X f\u00FCr @Senficon machen und sonst meine Ruhe. ;)",
  "id" : 397078180496166912,
  "in_reply_to_status_id" : 397077582661038080,
  "created_at" : "2013-11-03 19:09:50 +0000",
  "in_reply_to_screen_name" : "nichimtakt",
  "in_reply_to_user_id_str" : "48065959",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396989922508541952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.2713713609, 7.5072607957 ]
  },
  "id_str" : "397077193970692096",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Ich sollte schon mal nach einem Buch f\u00FCr den Bundesparteitag suchen. Vielleicht mal The Divine Comedy wieder lesen?",
  "id" : 397077193970692096,
  "in_reply_to_status_id" : 396989922508541952,
  "created_at" : "2013-11-03 19:05:55 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.3785945522, 7.3883537762 ]
  },
  "id_str" : "397074297627623424",
  "text" : "\u00ABDas erste Podium war ja zum weglaufen.\u00BB \u2014 \u00ABHab ich auch gemacht. 10 km, 14000 Schritte.\u00BB",
  "id" : 397074297627623424,
  "created_at" : "2013-11-03 18:54:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/o9lN4q6Bhn",
      "expanded_url" : "http:\/\/amzn.com\/k\/O22IVjDrRnaz0CkIqNwKHg",
      "display_url" : "amzn.com\/k\/O22IVjDrRnaz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397034363269185536",
  "text" : "I find this comforting given that my personal p(some form of heritable dementia) slowly approaches 1 http:\/\/t.co\/o9lN4q6Bhn strangely...",
  "id" : 397034363269185536,
  "created_at" : "2013-11-03 16:15:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/o6VeneIL2U",
      "expanded_url" : "http:\/\/instagram.com\/p\/gQXSNMBwpo\/",
      "display_url" : "instagram.com\/p\/gQXSNMBwpo\/"
    } ]
  },
  "geo" : { },
  "id_str" : "397006145296293888",
  "text" : "MFC http:\/\/t.co\/o6VeneIL2U",
  "id" : 397006145296293888,
  "created_at" : "2013-11-03 14:23:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/D6WYBipzcG",
      "expanded_url" : "http:\/\/instagram.com\/p\/gQWM8WBwn-\/",
      "display_url" : "instagram.com\/p\/gQWM8WBwn-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "397003625106796545",
  "text" : "Broken Windows http:\/\/t.co\/D6WYBipzcG",
  "id" : 397003625106796545,
  "created_at" : "2013-11-03 14:13:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.90229603, 6.6964084748 ]
  },
  "id_str" : "396997705219993601",
  "text" : "\u00ABIch bewundere ja wie du es hier aush\u00E4ltst.\u00BB \u2014 \u00ABNext: Zen and the Art of Not Going on Suicidal Killing Sprees.\u00BB",
  "id" : 396997705219993601,
  "created_at" : "2013-11-03 13:50:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.9110838688, 6.6906460002 ]
  },
  "id_str" : "396983884006842369",
  "text" : "\u00ABDass es den Leuten so schwer f\u00E4llt sich mit den Piraten zu \u00FCberidentifizieren ist wirklich ein ernstes Problem was diskutiert geh\u00F6rt\u2026\u00BB",
  "id" : 396983884006842369,
  "created_at" : "2013-11-03 12:55:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.9111009259, 6.6905206908 ]
  },
  "id_str" : "396974986583638016",
  "text" : "\u00ABIst der Reis nicht vegan?\u00BB \u2014 \u00ABNein, da ist Mais drin.\u00BB",
  "id" : 396974986583638016,
  "created_at" : "2013-11-03 12:19:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/fkTPyr97Sh",
      "expanded_url" : "http:\/\/instagram.com\/p\/gQAQnrBwqX\/",
      "display_url" : "instagram.com\/p\/gQAQnrBwqX\/"
    } ]
  },
  "geo" : { },
  "id_str" : "396955367177199616",
  "text" : "Heavy Metal http:\/\/t.co\/fkTPyr97Sh",
  "id" : 396955367177199616,
  "created_at" : "2013-11-03 11:01:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.9116536492, 6.6901454675 ]
  },
  "id_str" : "396934354976669696",
  "text" : "\u00ABWenn du deine Beziehungen anhand von Chatlogs auswertest: Denk daran das diskrete != kont. Fourier-Transformation.\u00BB\u2014\u00ABIch h\u00F6r nur Furie?\u00BB",
  "id" : 396934354976669696,
  "created_at" : "2013-11-03 09:38:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.9107314935, 6.6911552846 ]
  },
  "id_str" : "396928357193228288",
  "text" : "\u00ABDas ist ja wie fr\u00FCher bei den Piraten.\u00BB \u2014 \u00ABWie in alten Zeiten. Naja, bis auf die Folter und so.\u00BB",
  "id" : 396928357193228288,
  "created_at" : "2013-11-03 09:14:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "caa",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1025800939, 8.5425964967 ]
  },
  "id_str" : "396889425768378368",
  "text" : "\u00ABData released with use and redistribution restrictions are balkanized data or, to put it more simply, they are not actually released.\u00AB #caa",
  "id" : 396889425768378368,
  "created_at" : "2013-11-03 06:39:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096586174, 8.2829707335 ]
  },
  "id_str" : "396877236043018240",
  "text" : "The horror: Dreamt of too small sample sizes and low read counts in RNA-Seq experiments.",
  "id" : 396877236043018240,
  "created_at" : "2013-11-03 05:51:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AdrienMth\/status\/395959570201600001\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/9NNQ3aMefu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX67IYvIcAAKwV3.jpg",
      "id_str" : "395959570008666112",
      "id" : 395959570008666112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX67IYvIcAAKwV3.jpg",
      "sizes" : [ {
        "h" : 460,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 460,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 460,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 460,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/9NNQ3aMefu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009586378, 8.2830086164 ]
  },
  "id_str" : "396795028909334528",
  "text" : "I always end up on the wrong parties http:\/\/t.co\/9NNQ3aMefu",
  "id" : 396795028909334528,
  "created_at" : "2013-11-03 00:24:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396773412011405312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009680708, 8.283071336 ]
  },
  "id_str" : "396773626818883584",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn Exactly what I expected of you! ;)",
  "id" : 396773626818883584,
  "in_reply_to_status_id" : 396773412011405312,
  "created_at" : "2013-11-02 22:59:38 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 131, 143 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/JF8PNAcurl",
      "expanded_url" : "http:\/\/m.smh.com.au\/comment\/science-inspires-so-dont-let-your-art-rule-your-head-20131101-2wrjb.html",
      "display_url" : "m.smh.com.au\/comment\/scienc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095195082, 8.2827407106 ]
  },
  "id_str" : "396727122762686464",
  "text" : "\u00ABThere is no conflict between art &amp; science: only the wide-eyed pursuit of cool ideas\u00BB this, so much http:\/\/t.co\/JF8PNAcurl ht @AkshatRathi",
  "id" : 396727122762686464,
  "created_at" : "2013-11-02 19:54:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095891665, 8.2829450386 ]
  },
  "id_str" : "396711215789248512",
  "text" : "\u00ABWie war es?\u00BB \u2014 \u00ABGut, und n\u00E4chstes mal kommst du auch mit. Dann gehen wir ins Bibelmuseum!\u00BB",
  "id" : 396711215789248512,
  "created_at" : "2013-11-02 18:51:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/ZWsONvLv8a",
      "expanded_url" : "http:\/\/ramblingmuse.com\/wp-content\/uploads\/2011\/08\/laundromat3.jpg",
      "display_url" : "ramblingmuse.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396697668766146560",
  "text" : "Go ahead! http:\/\/t.co\/ZWsONvLv8a",
  "id" : 396697668766146560,
  "created_at" : "2013-11-02 17:57:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0012467765, 8.2598906911 ]
  },
  "id_str" : "396694017532256256",
  "text" : "\u00ABK\u00F6nnte der Besucher der seinen rosa Rollkoffer an den Fahrradst\u00E4nder angeschlossen hat bitte zum Haupteingang kommen?\u00BB",
  "id" : 396694017532256256,
  "created_at" : "2013-11-02 17:43:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1033343729, 8.6739089414 ]
  },
  "id_str" : "396647233946669056",
  "text" : "\u00ABSorry, Rembrandt, aber der Horizont ist nicht gerade.\u00BB",
  "id" : 396647233946669056,
  "created_at" : "2013-11-02 14:37:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096384551, 8.2829546991 ]
  },
  "id_str" : "396606854039883776",
  "text" : "\u00ABDie GLS-Boten stellen sich manchmal so dumm an die sollten unseren Kater als Wappentier verwenden\u00BB\u2014\u00ABAber Miller ist schon mein Wappentier!\u00BB",
  "id" : 396606854039883776,
  "created_at" : "2013-11-02 11:56:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0048901499, 8.2896530251 ]
  },
  "id_str" : "396581918420238336",
  "text" : "\u00AB\u00DCber manche Dinge macht man keine Witze!\u00BB \u2014 \u00ABDu hast mir gestern das Prisoner\u2019s Dilemma daran erkl\u00E4rt wie wir unsere Hosts umbringen!\u00BB",
  "id" : 396581918420238336,
  "created_at" : "2013-11-02 10:17:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396573794094940160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096550306, 8.2830486627 ]
  },
  "id_str" : "396574270757015552",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer only deploy when the CI says build failed. :p",
  "id" : 396574270757015552,
  "in_reply_to_status_id" : 396573794094940160,
  "created_at" : "2013-11-02 09:47:28 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 3, 12 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396573626243502080",
  "text" : "RT @eramirez: Say what you will about the evils of Wal-Mart, but they let me hangout in their parking lots a few years back. re: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/bqhI4Ej9lm",
        "expanded_url" : "http:\/\/www.wired.com\/rawfile\/2013\/11\/walmart-parking-lots\/",
        "display_url" : "wired.com\/rawfile\/2013\/1\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 33.9988422548, -118.4366410155 ]
    },
    "id_str" : "396501889841627136",
    "text" : "Say what you will about the evils of Wal-Mart, but they let me hangout in their parking lots a few years back. re: http:\/\/t.co\/bqhI4Ej9lm",
    "id" : 396501889841627136,
    "created_at" : "2013-11-02 04:59:51 +0000",
    "user" : {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "protected" : false,
      "id_str" : "21135674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/866822214267666432\/IYzsQHYG_normal.jpg",
      "id" : 21135674,
      "verified" : false
    }
  },
  "id" : 396573626243502080,
  "created_at" : "2013-11-02 09:44:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396501466380120064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096550306, 8.2830486627 ]
  },
  "id_str" : "396573186189701121",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer half-working is best working \\o\/",
  "id" : 396573186189701121,
  "in_reply_to_status_id" : 396501466380120064,
  "created_at" : "2013-11-02 09:43:10 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396322870944858112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1044074355, 8.6971356775 ]
  },
  "id_str" : "396374268629757952",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj me too &lt;3",
  "id" : 396374268629757952,
  "in_reply_to_status_id" : 396322870944858112,
  "created_at" : "2013-11-01 20:32:44 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/lhLJOdGZRw",
      "expanded_url" : "http:\/\/i.imgur.com\/r1idpjz.gif",
      "display_url" : "i.imgur.com\/r1idpjz.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "396304570214670336",
  "text" : "Working hard http:\/\/t.co\/lhLJOdGZRw",
  "id" : 396304570214670336,
  "created_at" : "2013-11-01 15:55:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/qjSRjwTM7g",
      "expanded_url" : "http:\/\/mudfooted.com\/new-snail-species-discovered-semi-transparent-shell\/",
      "display_url" : "mudfooted.com\/new-snail-spec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396264947614613505",
  "text" : "New snail species discovered with semi-transparent shell &lt;3 http:\/\/t.co\/qjSRjwTM7g",
  "id" : 396264947614613505,
  "created_at" : "2013-11-01 13:18:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723039808, 8.6276479559 ]
  },
  "id_str" : "396259807243825153",
  "text" : "\u00ABDas Freitag-Nachmittag-Seminar aka YouTube-Party mit Kuchen essen.\u00BB",
  "id" : 396259807243825153,
  "created_at" : "2013-11-01 12:57:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396250773517905920",
  "geo" : { },
  "id_str" : "396251959553830913",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer no problem, I'm just a fan of discussing that topic :D",
  "id" : 396251959553830913,
  "in_reply_to_status_id" : 396250773517905920,
  "created_at" : "2013-11-01 12:26:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396248700877414400",
  "geo" : { },
  "id_str" : "396250649836273664",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ~ to the optimal virulence (group ;)) selection discussed in your review of the Price biography.",
  "id" : 396250649836273664,
  "in_reply_to_status_id" : 396248700877414400,
  "created_at" : "2013-11-01 12:21:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396248700877414400",
  "geo" : { },
  "id_str" : "396250450753630209",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer looking at the life cycle: seems not too counter-intuitive. Larger snail -&gt; more tissue to breed your parasitic army!",
  "id" : 396250450753630209,
  "in_reply_to_status_id" : 396248700877414400,
  "created_at" : "2013-11-01 12:20:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396240169893769216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722917932, 8.6276869264 ]
  },
  "id_str" : "396240813086507008",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer not too sure about that. I\u2019d rather edit PAML files I think. :p",
  "id" : 396240813086507008,
  "in_reply_to_status_id" : 396240169893769216,
  "created_at" : "2013-11-01 11:42:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396228467945000961",
  "geo" : { },
  "id_str" : "396230477717049344",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer for the weird standards: I guess at least in DE you will have to work with some weird DIN\/ISO stuff (prob. worse than phylip!)",
  "id" : 396230477717049344,
  "in_reply_to_status_id" : 396228467945000961,
  "created_at" : "2013-11-01 11:01:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396228467945000961",
  "geo" : { },
  "id_str" : "396230202121916416",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I'd say it's a job where you're in pretty much full control of dirty data &amp; false positives.",
  "id" : 396230202121916416,
  "in_reply_to_status_id" : 396228467945000961,
  "created_at" : "2013-11-01 11:00:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396227483873599488",
  "geo" : { },
  "id_str" : "396229540218814464",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Sehr nett wie man Broad, Sanger &amp; BGI auch auf der kleinsten Zoomstufe direkt erkennen kann. :)",
  "id" : 396229540218814464,
  "in_reply_to_status_id" : 396227483873599488,
  "created_at" : "2013-11-01 10:57:38 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396227134504439808",
  "geo" : { },
  "id_str" : "396228337971916800",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer which might be a fun job if you're the kind of person who always carries sample tubes and ethanol for impromptu sampling :p",
  "id" : 396228337971916800,
  "in_reply_to_status_id" : 396227134504439808,
  "created_at" : "2013-11-01 10:52:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396227134504439808",
  "geo" : { },
  "id_str" : "396228043028443136",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yup, basically. afair it's running around, collecting samples, ID species, assess the risk.",
  "id" : 396228043028443136,
  "in_reply_to_status_id" : 396227134504439808,
  "created_at" : "2013-11-01 10:51:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396226131776389120",
  "geo" : { },
  "id_str" : "396226489277898752",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer assessing growth in buildings\/homes seems to be the major focus. But I guess starting a brewery would also be an option.",
  "id" : 396226489277898752,
  "in_reply_to_status_id" : 396226131776389120,
  "created_at" : "2013-11-01 10:45:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396225255619821568",
  "geo" : { },
  "id_str" : "396225930764378113",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer should have gone into mycology. A friend told me about his stellar career options in commer. mold classification yesterday. ;)",
  "id" : 396225930764378113,
  "in_reply_to_status_id" : 396225255619821568,
  "created_at" : "2013-11-01 10:43:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396224255643242497",
  "geo" : { },
  "id_str" : "396224911867273216",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer we will never be out of work, just out of funding!",
  "id" : 396224911867273216,
  "in_reply_to_status_id" : 396224255643242497,
  "created_at" : "2013-11-01 10:39:15 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/eOqBX5nG1C",
      "expanded_url" : "http:\/\/www.biomedcentral.com\/1741-7007\/11\/109",
      "display_url" : "biomedcentral.com\/1741-7007\/11\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396224858985861121",
  "text" : "RT @PhilippBayer: Open questions: genomics and how far we haven\u2019t come http:\/\/t.co\/eOqBX5nG1C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/eOqBX5nG1C",
        "expanded_url" : "http:\/\/www.biomedcentral.com\/1741-7007\/11\/109",
        "display_url" : "biomedcentral.com\/1741-7007\/11\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "396224255643242497",
    "text" : "Open questions: genomics and how far we haven\u2019t come http:\/\/t.co\/eOqBX5nG1C",
    "id" : 396224255643242497,
    "created_at" : "2013-11-01 10:36:38 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 396224858985861121,
  "created_at" : "2013-11-01 10:39:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/tplYNM5kgc",
      "expanded_url" : "http:\/\/www.cell.com\/current-biology\/retrieve\/pii\/S0960982213011433",
      "display_url" : "cell.com\/current-biolog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396221051157229568",
  "text" : "Seeing Left- or Right-Asymmetric Tail Wagging Produces Different Emotional Responses in Dogs http:\/\/t.co\/tplYNM5kgc",
  "id" : 396221051157229568,
  "created_at" : "2013-11-01 10:23:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/VSS57mirFE",
      "expanded_url" : "http:\/\/xkcd.com\/1285\/",
      "display_url" : "xkcd.com\/1285\/"
    } ]
  },
  "geo" : { },
  "id_str" : "396211963987898368",
  "text" : "We can all hear your stupid whitespace!  http:\/\/t.co\/VSS57mirFE",
  "id" : 396211963987898368,
  "created_at" : "2013-11-01 09:47:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Mohr",
      "screen_name" : "fabianmohr",
      "indices" : [ 3, 14 ],
      "id_str" : "13183522",
      "id" : 13183522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/XhjLux0wYZ",
      "expanded_url" : "http:\/\/kzhu.net\/does-life-end-at-35.html",
      "display_url" : "kzhu.net\/does-life-end-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396198713053675520",
  "text" : "RT @fabianmohr: A great read for insecure overachievers (you, possibly): \"Does life end with 35?\" http:\/\/t.co\/XhjLux0wYZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/XhjLux0wYZ",
        "expanded_url" : "http:\/\/kzhu.net\/does-life-end-at-35.html",
        "display_url" : "kzhu.net\/does-life-end-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "396197783029305345",
    "text" : "A great read for insecure overachievers (you, possibly): \"Does life end with 35?\" http:\/\/t.co\/XhjLux0wYZ",
    "id" : 396197783029305345,
    "created_at" : "2013-11-01 08:51:27 +0000",
    "user" : {
      "name" : "Fabian Mohr",
      "screen_name" : "fabianmohr",
      "protected" : false,
      "id_str" : "13183522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932352046967246849\/UXOqOF2N_normal.jpg",
      "id" : 13183522,
      "verified" : true
    }
  },
  "id" : 396198713053675520,
  "created_at" : "2013-11-01 08:55:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 3, 17 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    }, {
      "name" : "Lior Pachter",
      "screen_name" : "lpachter",
      "indices" : [ 68, 77 ],
      "id_str" : "31936449",
      "id" : 31936449
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GTEX",
      "indices" : [ 52, 57 ]
    }, {
      "text" : "gi2013",
      "indices" : [ 108, 115 ]
    }, {
      "text" : "methodsmatter",
      "indices" : [ 116, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/cqBxip3mFA",
      "expanded_url" : "http:\/\/liorpachter.wordpress.com\/2013\/10\/31\/response-to-gtex-is-throwing-away-90-of-their-data\/#comment-104",
      "display_url" : "liorpachter.wordpress.com\/2013\/10\/31\/res\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396080791429853184",
  "text" : "RT @genetics_blog: Steven Salzberg weighs in on the #GTEX debate on @lpachter's blog http:\/\/t.co\/cqBxip3mFA #gi2013 #methodsmatter #bioinfo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lior Pachter",
        "screen_name" : "lpachter",
        "indices" : [ 49, 58 ],
        "id_str" : "31936449",
        "id" : 31936449
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GTEX",
        "indices" : [ 33, 38 ]
      }, {
        "text" : "gi2013",
        "indices" : [ 89, 96 ]
      }, {
        "text" : "methodsmatter",
        "indices" : [ 97, 111 ]
      }, {
        "text" : "bioinformatics",
        "indices" : [ 112, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/cqBxip3mFA",
        "expanded_url" : "http:\/\/liorpachter.wordpress.com\/2013\/10\/31\/response-to-gtex-is-throwing-away-90-of-their-data\/#comment-104",
        "display_url" : "liorpachter.wordpress.com\/2013\/10\/31\/res\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "396076993445650432",
    "text" : "Steven Salzberg weighs in on the #GTEX debate on @lpachter's blog http:\/\/t.co\/cqBxip3mFA #gi2013 #methodsmatter #bioinformatics",
    "id" : 396076993445650432,
    "created_at" : "2013-11-01 00:51:28 +0000",
    "user" : {
      "name" : "Stephen Turner",
      "screen_name" : "strnr",
      "protected" : false,
      "id_str" : "20444825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660439762856230913\/ARYE5YB6_normal.jpg",
      "id" : 20444825,
      "verified" : false
    }
  },
  "id" : 396080791429853184,
  "created_at" : "2013-11-01 01:06:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/Zooj4CpcVi",
      "expanded_url" : "http:\/\/imgur.com\/a\/T68eB",
      "display_url" : "imgur.com\/a\/T68eB"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009680708, 8.283071336 ]
  },
  "id_str" : "396079091834978304",
  "text" : "\u00ABHe doesn't even know he's a squirrel.\u00BB http:\/\/t.co\/Zooj4CpcVi",
  "id" : 396079091834978304,
  "created_at" : "2013-11-01 00:59:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/396064463360888832\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/j95AaGhKQQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX8ah-SIUAArQXj.jpg",
      "id_str" : "396064463188938752",
      "id" : 396064463188938752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX8ah-SIUAArQXj.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/j95AaGhKQQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009680708, 8.283071336 ]
  },
  "id_str" : "396064463360888832",
  "text" : "Most automatically taken pictures show me playing with my beard but once in a while: Not sure if facepalm or crying. http:\/\/t.co\/j95AaGhKQQ",
  "id" : 396064463360888832,
  "created_at" : "2013-11-01 00:01:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095931806, 8.2829379012 ]
  },
  "id_str" : "396061384108441601",
  "text" : "\u00ABIch bin auch ein Maker: Ich habe Nudeln essen gemacht!\u00BB",
  "id" : 396061384108441601,
  "created_at" : "2013-10-31 23:49:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]