Grailbird.data.tweets_2015_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/682624128566824963\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/BYsIJIxwg9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXkrBt-W8AA0uVO.png",
      "id_str" : "682624127044349952",
      "id" : 682624127044349952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXkrBt-W8AA0uVO.png",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/BYsIJIxwg9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403101878919, 8.753373605649497 ]
  },
  "id_str" : "682624128566824963",
  "text" : "I guess all the news coming out of the US are working in shaping stereotypes. https:\/\/t.co\/BYsIJIxwg9",
  "id" : 682624128566824963,
  "created_at" : "2015-12-31 18:07:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    }, {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 60, 71 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682589085131735041",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11380907028708, 8.753795189877012 ]
  },
  "id_str" : "682589340124483585",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil ich glaube mit der Einsch\u00E4tzung kannst du dich mit @kathakatze zusammentun ;)",
  "id" : 682589340124483585,
  "in_reply_to_status_id" : 682589085131735041,
  "created_at" : "2015-12-31 15:49:15 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/7gpzRXFMaK",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/_9irFkhwvT\/",
      "display_url" : "instagram.com\/p\/_9irFkhwvT\/"
    } ]
  },
  "geo" : { },
  "id_str" : "682587395741626369",
  "text" : "\u05DE\u05DC\u05D1\u05D9 https:\/\/t.co\/7gpzRXFMaK",
  "id" : 682587395741626369,
  "created_at" : "2015-12-31 15:41:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682579715958398976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11389280971542, 8.75362912101896 ]
  },
  "id_str" : "682580998475898880",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot bleeding from all orifices thanks to the Benzene is not what I\u2019d call \u2018pooping like a queen\u2019, but YMMV!",
  "id" : 682580998475898880,
  "in_reply_to_status_id" : 682579715958398976,
  "created_at" : "2015-12-31 15:16:06 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/RdeZ9Ycjfx",
      "expanded_url" : "https:\/\/medium.com\/desk-of-van-schneider\/no-alcohol-no-coffee-for-15-months-this-is-what-happened-1a2d052be9e7#.irizkw36a",
      "display_url" : "medium.com\/desk-of-van-sc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682577956313665536",
  "text" : "\u00ABRemoving coffee\/caffeine from my diet not only made me more relaxed, I also poop like a king.\u00BB https:\/\/t.co\/RdeZ9Ycjfx",
  "id" : 682577956313665536,
  "created_at" : "2015-12-31 15:04:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/6sX7PSOmyO",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/_7g66Vhwt1\/",
      "display_url" : "instagram.com\/p\/_7g66Vhwt1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "682302070611918848",
  "text" : "Pizza https:\/\/t.co\/6sX7PSOmyO",
  "id" : 682302070611918848,
  "created_at" : "2015-12-30 20:47:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Raschka",
      "screen_name" : "rasbt",
      "indices" : [ 3, 9 ],
      "id_str" : "865622395",
      "id" : 865622395
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rasbt\/status\/682247099715563521\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/SuVqMzyKtO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXfUHQjWwAEh0Sf.png",
      "id_str" : "682247089737351169",
      "id" : 682247089737351169,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXfUHQjWwAEh0Sf.png",
      "sizes" : [ {
        "h" : 517,
        "resize" : "fit",
        "w" : 795
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 442,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 795
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 795
      } ],
      "display_url" : "pic.twitter.com\/SuVqMzyKtO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/yT1ic2zHFW",
      "expanded_url" : "https:\/\/medium.com\/rants-on-machine-learning\/what-to-do-with-small-data-d253254d1a89#.rujkijnp4",
      "display_url" : "medium.com\/rants-on-machi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682296387682320384",
  "text" : "RT @rasbt: \"What to do with \u201Csmall\u201D data?\" -- how far we've come ;) https:\/\/t.co\/yT1ic2zHFW https:\/\/t.co\/SuVqMzyKtO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rasbt\/status\/682247099715563521\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/SuVqMzyKtO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXfUHQjWwAEh0Sf.png",
        "id_str" : "682247089737351169",
        "id" : 682247089737351169,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXfUHQjWwAEh0Sf.png",
        "sizes" : [ {
          "h" : 517,
          "resize" : "fit",
          "w" : 795
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 442,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 517,
          "resize" : "fit",
          "w" : 795
        }, {
          "h" : 517,
          "resize" : "fit",
          "w" : 795
        } ],
        "display_url" : "pic.twitter.com\/SuVqMzyKtO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/yT1ic2zHFW",
        "expanded_url" : "https:\/\/medium.com\/rants-on-machine-learning\/what-to-do-with-small-data-d253254d1a89#.rujkijnp4",
        "display_url" : "medium.com\/rants-on-machi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "682247099715563521",
    "text" : "\"What to do with \u201Csmall\u201D data?\" -- how far we've come ;) https:\/\/t.co\/yT1ic2zHFW https:\/\/t.co\/SuVqMzyKtO",
    "id" : 682247099715563521,
    "created_at" : "2015-12-30 17:09:18 +0000",
    "user" : {
      "name" : "Sebastian Raschka",
      "screen_name" : "rasbt",
      "protected" : false,
      "id_str" : "865622395",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/894027600435318784\/rKM8RRUg_normal.jpg",
      "id" : 865622395,
      "verified" : false
    }
  },
  "id" : 682296387682320384,
  "created_at" : "2015-12-30 20:25:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blindspot",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11391661146617, 8.753632303801828 ]
  },
  "id_str" : "682199792387272705",
  "text" : "\u00ABWhich of us can easily come up with nine good qualities of a partner? Even canonization requires only two miracles!\u00BB #blindspot",
  "id" : 682199792387272705,
  "created_at" : "2015-12-30 14:01:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682186411324358657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412050161935, 8.753440510449302 ]
  },
  "id_str" : "682186745107054592",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks that\u2019s too bad, I virtually never check FB :)",
  "id" : 682186745107054592,
  "in_reply_to_status_id" : 682186411324358657,
  "created_at" : "2015-12-30 13:09:29 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682184355880513536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412050161935, 8.753440510449302 ]
  },
  "id_str" : "682186238481281024",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks does this mean we will get to read even more of the fun unprofessional ones?! ;)",
  "id" : 682186238481281024,
  "in_reply_to_status_id" : 682184355880513536,
  "created_at" : "2015-12-30 13:07:28 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 57, 65 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/Gunij4yod3",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/gbGNsNDch1U\/info%3Adoi%2F10.1371%2Fjournal.pone.0145557",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682185910595747840",
  "text" : "Inferring Mathematical Equations Using Crowdsourcing \/cc @Seplute  https:\/\/t.co\/Gunij4yod3",
  "id" : 682185910595747840,
  "created_at" : "2015-12-30 13:06:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hagen",
      "screen_name" : "drhagen",
      "indices" : [ 3, 11 ],
      "id_str" : "53490935",
      "id" : 53490935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682014872280940544",
  "text" : "RT @drhagen: An xkcd once wondered why the 11th of most months is mentioned less than the other days. I think I figured it out. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/gsB9Hn6dQK",
        "expanded_url" : "http:\/\/drhagen.com\/blog\/the-missing-11th-of-the-month\/",
        "display_url" : "drhagen.com\/blog\/the-missi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "681928755594526720",
    "text" : "An xkcd once wondered why the 11th of most months is mentioned less than the other days. I think I figured it out. https:\/\/t.co\/gsB9Hn6dQK",
    "id" : 681928755594526720,
    "created_at" : "2015-12-29 20:04:19 +0000",
    "user" : {
      "name" : "David Hagen",
      "screen_name" : "drhagen",
      "protected" : false,
      "id_str" : "53490935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514210015813459968\/G74zpCcy_normal.jpeg",
      "id" : 53490935,
      "verified" : false
    }
  },
  "id" : 682014872280940544,
  "created_at" : "2015-12-30 01:46:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682013303153930241",
  "geo" : { },
  "id_str" : "682013415301353472",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen Danke, dir auch :)",
  "id" : 682013415301353472,
  "in_reply_to_status_id" : 682013303153930241,
  "created_at" : "2015-12-30 01:40:44 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682012499298783234",
  "geo" : { },
  "id_str" : "682012942078996480",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen I will, looking forward to it. But first: some sleep \uD83D\uDCA4\uD83D\uDE09",
  "id" : 682012942078996480,
  "in_reply_to_status_id" : 682012499298783234,
  "created_at" : "2015-12-30 01:38:51 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682010421138554880",
  "geo" : { },
  "id_str" : "682011139421650944",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen and with amazon the DRM can be easily broken to make them shareable again ;)",
  "id" : 682011139421650944,
  "in_reply_to_status_id" : 682010421138554880,
  "created_at" : "2015-12-30 01:31:41 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682010421138554880",
  "geo" : { },
  "id_str" : "682011046039687168",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen for me schlepping around print books is too much of a hassle, which is why i try to avoid them as much as possible.",
  "id" : 682011046039687168,
  "in_reply_to_status_id" : 682010421138554880,
  "created_at" : "2015-12-30 01:31:19 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682008291514257410",
  "geo" : { },
  "id_str" : "682008537128566785",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen nice, but they are even available as ebooks on amazon :D",
  "id" : 682008537128566785,
  "in_reply_to_status_id" : 682008291514257410,
  "created_at" : "2015-12-30 01:21:21 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682006997009444870",
  "geo" : { },
  "id_str" : "682007770233622533",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen I haven\u2019t, but I just added them to my to-read-list :)",
  "id" : 682007770233622533,
  "in_reply_to_status_id" : 682006997009444870,
  "created_at" : "2015-12-30 01:18:18 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682005529565081600",
  "geo" : { },
  "id_str" : "682006060257771521",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen sure, whenever you\u2019re up for it. :-) As an additional motivation: all in all it\u2019s only 140 pages I think.",
  "id" : 682006060257771521,
  "in_reply_to_status_id" : 682005529565081600,
  "created_at" : "2015-12-30 01:11:30 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682004152189239298",
  "geo" : { },
  "id_str" : "682004723990306816",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen (as it\u2019s out of print it\u2019s not super easy to get a copy, would be happy to mail mine over if you\u2019re interested)",
  "id" : 682004723990306816,
  "in_reply_to_status_id" : 682004152189239298,
  "created_at" : "2015-12-30 01:06:11 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/8r4NEIQbTQ",
      "expanded_url" : "https:\/\/www.goodreads.com\/review\/show\/937426834?book_show_action=false",
      "display_url" : "goodreads.com\/review\/show\/93\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "682004152189239298",
  "geo" : { },
  "id_str" : "682004568117411840",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen here you go: https:\/\/t.co\/8r4NEIQbTQ",
  "id" : 682004568117411840,
  "in_reply_to_status_id" : 682004152189239298,
  "created_at" : "2015-12-30 01:05:34 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681992848552685568",
  "geo" : { },
  "id_str" : "682003600847970305",
  "in_reply_to_user_id" : 14286491,
  "text" : "From SJ Gould\u2019s afterword, about GG Simpson: \u00ABone of the world\u2019s most honored scientists wallowed in a miasma of doubt and anger\u00BB",
  "id" : 682003600847970305,
  "in_reply_to_status_id" : 681992848552685568,
  "created_at" : "2015-12-30 01:01:44 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681459837285351424",
  "geo" : { },
  "id_str" : "681992848552685568",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABI suddenly realized that my father was not here, and had not been. In the Cretaceous, he would not be born for eighty million years.\u00BB \uD83C\uDFCE\u23F2",
  "id" : 681992848552685568,
  "in_reply_to_status_id" : 681459837285351424,
  "created_at" : "2015-12-30 00:19:00 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/XjBtfKt4rh",
      "expanded_url" : "http:\/\/www.pattismith.net\/banga.html",
      "display_url" : "pattismith.net\/banga.html"
    } ]
  },
  "geo" : { },
  "id_str" : "681951851516944384",
  "text" : "Packing like Patti Smith https:\/\/t.co\/XjBtfKt4rh",
  "id" : 681951851516944384,
  "created_at" : "2015-12-29 21:36:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/iozcZJ6sBR",
      "expanded_url" : "https:\/\/twitter.com\/jacyreese\/status\/681872685333266432",
      "display_url" : "twitter.com\/jacyreese\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681948957942136835",
  "text" : "marketing rules: \"Number one, never use the word 'vegan'\" sad but true. https:\/\/t.co\/iozcZJ6sBR",
  "id" : 681948957942136835,
  "created_at" : "2015-12-29 21:24:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/koaWJc044A",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=F5QCs3PnQBc",
      "display_url" : "youtube.com\/watch?v=F5QCs3\u2026"
    }, {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/GkOOCYB2Bb",
      "expanded_url" : "https:\/\/twitter.com\/sokareemie\/status\/681881774826385408",
      "display_url" : "twitter.com\/sokareemie\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681942771654070272",
  "text" : "That guy watched too much of this: https:\/\/t.co\/koaWJc044A https:\/\/t.co\/GkOOCYB2Bb",
  "id" : 681942771654070272,
  "created_at" : "2015-12-29 21:00:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/3OWMrLrdc4",
      "expanded_url" : "https:\/\/twitter.com\/arjunrajlab\/status\/681834325642506240",
      "display_url" : "twitter.com\/arjunrajlab\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681935628003590144",
  "text" : "\uD83D\uDC4Dto the comment: \u00ABa career in science should not require a vow of monasticism or acting fiscally irresponsible.\u00BB https:\/\/t.co\/3OWMrLrdc4",
  "id" : 681935628003590144,
  "created_at" : "2015-12-29 20:31:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mem_somerville",
      "screen_name" : "mem_somerville",
      "indices" : [ 3, 18 ],
      "id_str" : "15201021",
      "id" : 15201021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681920990998212608",
  "text" : "RT @mem_somerville: I split a house with a friend. But it's legally challenging + confuses everyone (besides us, we're good with this). htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/FrITXTnVyd",
        "expanded_url" : "https:\/\/twitter.com\/drvox\/status\/681916297777680384",
        "display_url" : "twitter.com\/drvox\/status\/6\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "681918877668896768",
    "text" : "I split a house with a friend. But it's legally challenging + confuses everyone (besides us, we're good with this). https:\/\/t.co\/FrITXTnVyd",
    "id" : 681918877668896768,
    "created_at" : "2015-12-29 19:25:04 +0000",
    "user" : {
      "name" : "mem_somerville",
      "screen_name" : "mem_somerville",
      "protected" : false,
      "id_str" : "15201021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929049262591115264\/ZIPrsQlr_normal.jpg",
      "id" : 15201021,
      "verified" : false
    }
  },
  "id" : 681920990998212608,
  "created_at" : "2015-12-29 19:33:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681915095115522050",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406707784634, 8.753404002122844 ]
  },
  "id_str" : "681915329753280512",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Yeah, that or using a VPN, but both are really a last resort. In doubt: \u201Cno access, didn\u2019t read\u201D",
  "id" : 681915329753280512,
  "in_reply_to_status_id" : 681915095115522050,
  "created_at" : "2015-12-29 19:10:58 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/umG73Cfrvh",
      "expanded_url" : "https:\/\/twitter.com\/bik_f_\/status\/681910025099546624",
      "display_url" : "twitter.com\/bik_f_\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406703421333, 8.753384307792418 ]
  },
  "id_str" : "681914432193212416",
  "text" : "Unfortunately it\u2019s closed access and as virtually nobody is in the office, no one can read it. https:\/\/t.co\/umG73Cfrvh",
  "id" : 681914432193212416,
  "created_at" : "2015-12-29 19:07:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/D5TcL2vwVT",
      "expanded_url" : "https:\/\/twitter.com\/VergeScience\/status\/681863658989727744",
      "display_url" : "twitter.com\/VergeScience\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406659593744, 8.753395331928616 ]
  },
  "id_str" : "681867495452610560",
  "text" : "Not surprised at all: Somehow knowing a thing or two about tech doesn\u2019t make you a science-know-it-all. https:\/\/t.co\/D5TcL2vwVT",
  "id" : 681867495452610560,
  "created_at" : "2015-12-29 16:00:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fleece",
      "screen_name" : "fleecemusics",
      "indices" : [ 0, 13 ],
      "id_str" : "3293259316",
      "id" : 3293259316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681654598038204416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406500057554, 8.753374488207012 ]
  },
  "id_str" : "681859576644370432",
  "in_reply_to_user_id" : 3293259316,
  "text" : "@fleecemusics yes, but then you don\u2019t profit from me listening to it! :)",
  "id" : 681859576644370432,
  "in_reply_to_status_id" : 681654598038204416,
  "created_at" : "2015-12-29 15:29:26 +0000",
  "in_reply_to_screen_name" : "fleecemusics",
  "in_reply_to_user_id_str" : "3293259316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/RNHcE9TXfA",
      "expanded_url" : "https:\/\/twitter.com\/Daeinar\/status\/681770191831863296",
      "display_url" : "twitter.com\/Daeinar\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406632814471, 8.753391682731397 ]
  },
  "id_str" : "681798892497813504",
  "text" : "Because someone has to do the tech support. https:\/\/t.co\/RNHcE9TXfA",
  "id" : 681798892497813504,
  "created_at" : "2015-12-29 11:28:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fleece",
      "screen_name" : "fleecemusics",
      "indices" : [ 0, 13 ],
      "id_str" : "3293259316",
      "id" : 3293259316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/edxptYItUo",
      "expanded_url" : "http:\/\/youtuberepeat.com",
      "display_url" : "youtuberepeat.com"
    } ]
  },
  "in_reply_to_status_id_str" : "681646773715091456",
  "geo" : { },
  "id_str" : "681647527800782848",
  "in_reply_to_user_id" : 3293259316,
  "text" : "@fleecemusics I would be over the \uD83C\uDF1B! So far I\u2019m helping myself by using https:\/\/t.co\/edxptYItUo to listen to it all the time!",
  "id" : 681647527800782848,
  "in_reply_to_status_id" : 681646773715091456,
  "created_at" : "2015-12-29 01:26:49 +0000",
  "in_reply_to_screen_name" : "fleecemusics",
  "in_reply_to_user_id_str" : "3293259316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fleece",
      "screen_name" : "fleecemusics",
      "indices" : [ 0, 13 ],
      "id_str" : "3293259316",
      "id" : 3293259316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/J2PbVMEOVf",
      "expanded_url" : "https:\/\/www.youtube.com\/watch\/?v=rlBskd3IaNw#how_to_write_an_Alt-J_song",
      "display_url" : "youtube.com\/watch\/?v=rlBsk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681646126039199747",
  "in_reply_to_user_id" : 3293259316,
  "text" : "@fleecemusics could you release https:\/\/t.co\/J2PbVMEOVf on spotify, please? \uD83D\uDE4F\uD83D\uDE07",
  "id" : 681646126039199747,
  "created_at" : "2015-12-29 01:21:15 +0000",
  "in_reply_to_screen_name" : "fleecemusics",
  "in_reply_to_user_id_str" : "3293259316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/S2Bhdwm97T",
      "expanded_url" : "https:\/\/twitter.com\/TheMetalCore\/status\/681635311307350017",
      "display_url" : "twitter.com\/TheMetalCore\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139303881759, 8.753586663600348 ]
  },
  "id_str" : "681637523047714819",
  "text" : "Uh oh, you better watch out now, Keith Richards! https:\/\/t.co\/S2Bhdwm97T",
  "id" : 681637523047714819,
  "created_at" : "2015-12-29 00:47:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 0, 13 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    }, {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 14, 23 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681594563379736576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406533719158, 8.753382559676515 ]
  },
  "id_str" : "681594852396658691",
  "in_reply_to_user_id" : 1421360166,
  "text" : "@ToxXInFlames @SuicideC that\u2019s one useful skill to have :)",
  "id" : 681594852396658691,
  "in_reply_to_status_id" : 681594563379736576,
  "created_at" : "2015-12-28 21:57:30 +0000",
  "in_reply_to_screen_name" : "ToxXInFlames",
  "in_reply_to_user_id_str" : "1421360166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681592419259936769",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402852365443, 8.753475847145008 ]
  },
  "id_str" : "681592741642551296",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC and fwiw, it works quite well ;)",
  "id" : 681592741642551296,
  "in_reply_to_status_id" : 681592419259936769,
  "created_at" : "2015-12-28 21:49:07 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681587882818142208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140059107783, 8.753523730440959 ]
  },
  "id_str" : "681588908241608704",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC as far as I\u2019m concerned it\u2019s the same thing :3",
  "id" : 681588908241608704,
  "in_reply_to_status_id" : 681587882818142208,
  "created_at" : "2015-12-28 21:33:53 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 0, 13 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    }, {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 14, 23 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681587831215665153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406701845304, 8.753379433066785 ]
  },
  "id_str" : "681588823407640576",
  "in_reply_to_user_id" : 1421360166,
  "text" : "@ToxXInFlames @SuicideC sometimes those pokes are well deserved, sometimes they aren\u2019t ;)",
  "id" : 681588823407640576,
  "in_reply_to_status_id" : 681587831215665153,
  "created_at" : "2015-12-28 21:33:33 +0000",
  "in_reply_to_screen_name" : "ToxXInFlames",
  "in_reply_to_user_id_str" : "1421360166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681584421800132608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140670768283, 8.753390314849192 ]
  },
  "id_str" : "681586441546264576",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC are you trying to seduce me, Mrs. Robinson?",
  "id" : 681586441546264576,
  "in_reply_to_status_id" : 681584421800132608,
  "created_at" : "2015-12-28 21:24:05 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681530956893663232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400438189392, 8.753549671752578 ]
  },
  "id_str" : "681551853964931073",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson sweet :)",
  "id" : 681551853964931073,
  "in_reply_to_status_id" : 681530956893663232,
  "created_at" : "2015-12-28 19:06:39 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 108, 114 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Gt11wvGjYg",
      "expanded_url" : "http:\/\/www.bbc.com\/news\/world-europe-35189938",
      "display_url" : "bbc.com\/news\/world-eur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681519287371231232",
  "text" : "The region where I grew up: \u00ABGerman man dies after blowing up condom machine\u00BB Guess that explains a lot \/HT @Lobot  https:\/\/t.co\/Gt11wvGjYg",
  "id" : 681519287371231232,
  "created_at" : "2015-12-28 16:57:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/Cj6MdPxyxM",
      "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/681487739578138624",
      "display_url" : "twitter.com\/wilbanks\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405345032046, 8.753327420661149 ]
  },
  "id_str" : "681489918116392960",
  "text" : "My own favorite trope: Steven Pinker wants to hurt people. https:\/\/t.co\/Cj6MdPxyxM",
  "id" : 681489918116392960,
  "created_at" : "2015-12-28 15:00:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "molly clare wilson",
      "screen_name" : "mollyclare",
      "indices" : [ 0, 11 ],
      "id_str" : "12138192",
      "id" : 12138192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681486874347573248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406704954459, 8.753388700704091 ]
  },
  "id_str" : "681488165132189696",
  "in_reply_to_user_id" : 12138192,
  "text" : "@mollyclare which is really good :)",
  "id" : 681488165132189696,
  "in_reply_to_status_id" : 681486874347573248,
  "created_at" : "2015-12-28 14:53:34 +0000",
  "in_reply_to_screen_name" : "mollyclare",
  "in_reply_to_user_id_str" : "12138192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "molly clare wilson",
      "screen_name" : "mollyclare",
      "indices" : [ 0, 11 ],
      "id_str" : "12138192",
      "id" : 12138192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681486874347573248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406619637779, 8.753414426268833 ]
  },
  "id_str" : "681488130558550017",
  "in_reply_to_user_id" : 12138192,
  "text" : "@mollyclare don\u2019t know yet. It just arrived this morning. Currently reading \u2018The Only Women in the Room: Why Science is Still a Boy\u2019s Club\u2019.",
  "id" : 681488130558550017,
  "in_reply_to_status_id" : 681486874347573248,
  "created_at" : "2015-12-28 14:53:26 +0000",
  "in_reply_to_screen_name" : "mollyclare",
  "in_reply_to_user_id_str" : "12138192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/681459837285351424\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/QK777AzQZb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXUIHH1WYAAe1QW.jpg",
      "id_str" : "681459837071417344",
      "id" : 681459837071417344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXUIHH1WYAAe1QW.jpg",
      "sizes" : [ {
        "h" : 1168,
        "resize" : "fit",
        "w" : 876
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1168,
        "resize" : "fit",
        "w" : 876
      }, {
        "h" : 1168,
        "resize" : "fit",
        "w" : 876
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/QK777AzQZb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.113679, 8.75503 ]
  },
  "id_str" : "681459837285351424",
  "text" : "Wow, having those two write the introduction and the afterword is quite an achievement. https:\/\/t.co\/QK777AzQZb",
  "id" : 681459837285351424,
  "created_at" : "2015-12-28 13:01:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/AIqXIoEAya",
      "expanded_url" : "http:\/\/i.imgur.com\/MxP62L4.gif",
      "display_url" : "i.imgur.com\/MxP62L4.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "681274043119616000",
  "geo" : { },
  "id_str" : "681274504526610433",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye maybe you could splice in https:\/\/t.co\/AIqXIoEAya",
  "id" : 681274504526610433,
  "in_reply_to_status_id" : 681274043119616000,
  "created_at" : "2015-12-28 00:44:34 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ydV00bnB11",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/601026621148106752",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "681270503521255428",
  "geo" : { },
  "id_str" : "681271632674054145",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABIt sounded like something that was too good to be true.\u00BB Most likely people wiser than me repeated this since ages: https:\/\/t.co\/ydV00bnB11",
  "id" : 681271632674054145,
  "in_reply_to_status_id" : 681270503521255428,
  "created_at" : "2015-12-28 00:33:09 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681270503521255428",
  "geo" : { },
  "id_str" : "681271013099868160",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABThe company has said it performed millions of tests, with highly [false] positive feedback.\u00BB fixed that for you.",
  "id" : 681271013099868160,
  "in_reply_to_status_id" : 681270503521255428,
  "created_at" : "2015-12-28 00:30:41 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/681270503521255428\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/ipQJHfJstW",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CXRbvm_U0AA-SRG.png",
      "id_str" : "681270317117919232",
      "id" : 681270317117919232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CXRbvm_U0AA-SRG.png",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/ipQJHfJstW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/dqM8gjsMDP",
      "expanded_url" : "http:\/\/www.wsj.com\/articles\/at-theranos-many-strategies-and-snags-1451259629?mod=djemalertNEWS",
      "display_url" : "wsj.com\/articles\/at-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681270503521255428",
  "text" : "On Theranos, again\u2026 https:\/\/t.co\/dqM8gjsMDP https:\/\/t.co\/ipQJHfJstW",
  "id" : 681270503521255428,
  "created_at" : "2015-12-28 00:28:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Der @KleineMaulwurf",
      "screen_name" : "KleineMaulwurf",
      "indices" : [ 73, 88 ],
      "id_str" : "49373312",
      "id" : 49373312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/LQxeFUIM8C",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=bLE7zsJk4AI",
      "display_url" : "youtube.com\/watch?v=bLE7zs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681262790607155202",
  "text" : "My roommates will love the new Wifi password https:\/\/t.co\/LQxeFUIM8C \/HT @KleineMaulwurf",
  "id" : 681262790607155202,
  "created_at" : "2015-12-27 23:58:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681244092391624705",
  "geo" : { },
  "id_str" : "681244589466976258",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU oh, thanks! While watching it I actually thought that this scene reminded me of something it but couldn\u2019t place it!",
  "id" : 681244589466976258,
  "in_reply_to_status_id" : 681244092391624705,
  "created_at" : "2015-12-27 22:45:41 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681243185444728832",
  "geo" : { },
  "id_str" : "681243622814171136",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU oh, I seem to have missed the Apocalypse Now reference!",
  "id" : 681243622814171136,
  "in_reply_to_status_id" : 681243185444728832,
  "created_at" : "2015-12-27 22:41:51 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681225263317954560",
  "geo" : { },
  "id_str" : "681225627282849793",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s bwhahaha m)",
  "id" : 681225627282849793,
  "in_reply_to_status_id" : 681225263317954560,
  "created_at" : "2015-12-27 21:30:20 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681213685721772034",
  "geo" : { },
  "id_str" : "681214460850225152",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson only a bit weird when I wanted to send a message to the class room and was asked about my US state. ;)",
  "id" : 681214460850225152,
  "in_reply_to_status_id" : 681213685721772034,
  "created_at" : "2015-12-27 20:45:58 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681213685721772034",
  "geo" : { },
  "id_str" : "681214004283441152",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson nah, it\u2019s fine. And I really like the project I gave to. Hope they make the cut before it runs out. :)",
  "id" : 681214004283441152,
  "in_reply_to_status_id" : 681213685721772034,
  "created_at" : "2015-12-27 20:44:09 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681212688530149376",
  "geo" : { },
  "id_str" : "681212846181593088",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson sure, more than happy to! Though it feels a bit weird to support US class rooms ;)",
  "id" : 681212846181593088,
  "in_reply_to_status_id" : 681212688530149376,
  "created_at" : "2015-12-27 20:39:33 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/GPWe4WrapJ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/zXMxHtBwow\/",
      "display_url" : "instagram.com\/p\/zXMxHtBwow\/"
    } ]
  },
  "in_reply_to_status_id_str" : "681039429943734272",
  "geo" : { },
  "id_str" : "681203886003220480",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson and here you go. Happy Birthday! https:\/\/t.co\/GPWe4WrapJ",
  "id" : 681203886003220480,
  "in_reply_to_status_id" : 681039429943734272,
  "created_at" : "2015-12-27 20:03:57 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/BA8tO0B4JW",
      "expanded_url" : "https:\/\/aeon.co\/essays\/what-have-we-lost-now-we-can-no-longer-read-the-sky",
      "display_url" : "aeon.co\/essays\/what-ha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681201176931622912",
  "text" : "What have we lost, now that we can no longer read the sky? https:\/\/t.co\/BA8tO0B4JW",
  "id" : 681201176931622912,
  "created_at" : "2015-12-27 19:53:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/M5xld8zWN8",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/LegalAdviceUK\/comments\/3xyjhz\/unable_to_contact_staff_member_on_annual_holiday\/",
      "display_url" : "reddit.com\/r\/LegalAdviceU\u2026"
    }, {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/wPgBUVZzIi",
      "expanded_url" : "https:\/\/twitter.com\/chaeronaea\/status\/681173760255197184",
      "display_url" : "twitter.com\/chaeronaea\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681181898102669312",
  "text" : "Link to the thread https:\/\/t.co\/M5xld8zWN8 https:\/\/t.co\/wPgBUVZzIi",
  "id" : 681181898102669312,
  "created_at" : "2015-12-27 18:36:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681176470560071680",
  "geo" : { },
  "id_str" : "681177612018933760",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess keine schlechte Wahl wenn ich mir das neue Twitter-Handle anschaue :p",
  "id" : 681177612018933760,
  "in_reply_to_status_id" : 681176470560071680,
  "created_at" : "2015-12-27 18:19:33 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681162127340617729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406622746146, 8.753382742169533 ]
  },
  "id_str" : "681175872045453312",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess kommt mir bekannt vor ;)",
  "id" : 681175872045453312,
  "in_reply_to_status_id" : 681162127340617729,
  "created_at" : "2015-12-27 18:12:38 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406704356789, 8.753391324513313 ]
  },
  "id_str" : "681175429085048832",
  "text" : "@malech Agentin Lammfellimitat hat gr\u00FCnes Licht gegeben. \uD83D\uDEA6\uD83C\uDF79\uD83C\uDF59",
  "id" : 681175429085048832,
  "created_at" : "2015-12-27 18:10:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WomanthologyUK",
      "screen_name" : "WomanthologyUK",
      "indices" : [ 3, 18 ],
      "id_str" : "1575952254",
      "id" : 1575952254
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crowdfunding",
      "indices" : [ 22, 35 ]
    }, {
      "text" : "WomenInSTEM",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/Za1OTojgGs",
      "expanded_url" : "http:\/\/j.mp\/1K6x2XV",
      "display_url" : "j.mp\/1K6x2XV"
    } ]
  },
  "geo" : { },
  "id_str" : "681126543159128064",
  "text" : "RT @WomanthologyUK: A #crowdfunding platform set up by female researchers for female researchers https:\/\/t.co\/Za1OTojgGs #WomenInSTEM https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WomanthologyUK\/status\/681096945436389376\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/bBNapIfpTo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXO-Dx5WQAA2U8K.jpg",
        "id_str" : "681096940805832704",
        "id" : 681096940805832704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXO-Dx5WQAA2U8K.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/bBNapIfpTo"
      } ],
      "hashtags" : [ {
        "text" : "crowdfunding",
        "indices" : [ 2, 15 ]
      }, {
        "text" : "WomenInSTEM",
        "indices" : [ 101, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/Za1OTojgGs",
        "expanded_url" : "http:\/\/j.mp\/1K6x2XV",
        "display_url" : "j.mp\/1K6x2XV"
      } ]
    },
    "geo" : { },
    "id_str" : "681096945436389376",
    "text" : "A #crowdfunding platform set up by female researchers for female researchers https:\/\/t.co\/Za1OTojgGs #WomenInSTEM https:\/\/t.co\/bBNapIfpTo",
    "id" : 681096945436389376,
    "created_at" : "2015-12-27 12:59:00 +0000",
    "user" : {
      "name" : "WomanthologyUK",
      "screen_name" : "WomanthologyUK",
      "protected" : false,
      "id_str" : "1575952254",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433555618574516224\/JRI2-hKk_normal.jpeg",
      "id" : 1575952254,
      "verified" : false
    }
  },
  "id" : 681126543159128064,
  "created_at" : "2015-12-27 14:56:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681121576822124544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09947468659447, 8.692741213276834 ]
  },
  "id_str" : "681124715507879936",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna \uD83D\uDC4D\uD83D\uDC96",
  "id" : 681124715507879936,
  "in_reply_to_status_id" : 681121576822124544,
  "created_at" : "2015-12-27 14:49:21 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 93, 106 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/FnpCT02MzP",
      "expanded_url" : "http:\/\/www.theawl.com\/2015\/12\/doomed",
      "display_url" : "theawl.com\/2015\/12\/doomed"
    } ]
  },
  "geo" : { },
  "id_str" : "681109382004903936",
  "text" : "\u00ABIf you\u2019re frostbitten and you know it, amputate (thunk thunk).\u00BB https:\/\/t.co\/FnpCT02MzP \/HT @MishaAngrist",
  "id" : 681109382004903936,
  "created_at" : "2015-12-27 13:48:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681094613076209664",
  "geo" : { },
  "id_str" : "681107643763654656",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe unfortunately when you look at \u2018success stories\u2019 the first quite often comes hand in hand with the second\u2026",
  "id" : 681107643763654656,
  "in_reply_to_status_id" : 681094613076209664,
  "created_at" : "2015-12-27 13:41:31 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/MnojvL3e5b",
      "expanded_url" : "https:\/\/twitter.com\/SuicideC\/status\/681057099120558080",
      "display_url" : "twitter.com\/SuicideC\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681105433285758976",
  "text" : "Doesn\u2019t stop some of them to publish their work on what they assume is biology. https:\/\/t.co\/MnojvL3e5b",
  "id" : 681105433285758976,
  "created_at" : "2015-12-27 13:32:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/OprjH129UP",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP",
      "display_url" : "patreon.com\/openSNP"
    } ]
  },
  "geo" : { },
  "id_str" : "681101842873475073",
  "text" : "Either our newsletter had some impact or Christmas really is the season of love &amp; giving: Having 10 new Patrons! https:\/\/t.co\/OprjH129UP",
  "id" : 681101842873475073,
  "created_at" : "2015-12-27 13:18:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 45, 54 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 59, 68 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681098029466783744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404869960572, 8.753383881750018 ]
  },
  "id_str" : "681098339832741888",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia great, the last person I endorsed to @Senficon was @wilbanks, to go full circle. ;)",
  "id" : 681098339832741888,
  "in_reply_to_status_id" : 681098029466783744,
  "created_at" : "2015-12-27 13:04:33 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 10, 17 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "32C3",
      "indices" : [ 59, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11410497746335, 8.753097910620044 ]
  },
  "id_str" : "681096919939158016",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @arikia I think the two of you should meet up at #32C3 if you get the chance. :)",
  "id" : 681096919939158016,
  "created_at" : "2015-12-27 12:58:54 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 17, 27 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "680781311397728256",
  "geo" : { },
  "id_str" : "680781491006234625",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @Helena_LB yes, that would be the only phrasebook I ever need.",
  "id" : 680781491006234625,
  "in_reply_to_status_id" : 680781311397728256,
  "created_at" : "2015-12-26 16:05:30 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/zXagGxlkB5",
      "expanded_url" : "https:\/\/twitter.com\/Helena_LB\/status\/680778926059339776",
      "display_url" : "twitter.com\/Helena_LB\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "680780739751841793",
  "text" : "I need this book! https:\/\/t.co\/zXagGxlkB5",
  "id" : 680780739751841793,
  "created_at" : "2015-12-26 16:02:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Lumley",
      "screen_name" : "tslumley",
      "indices" : [ 3, 12 ],
      "id_str" : "1168003974",
      "id" : 1168003974
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tslumley\/status\/680653091268603904\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/H2BsCy9yvi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXIqYQnUsAAht_0.png",
      "id_str" : "680653089951494144",
      "id" : 680653089951494144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXIqYQnUsAAht_0.png",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/H2BsCy9yvi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/U27vlvwvSH",
      "expanded_url" : "http:\/\/languagelog.ldc.upenn.edu\/nll\/?p=22859",
      "display_url" : "languagelog.ldc.upenn.edu\/nll\/?p=22859"
    } ]
  },
  "geo" : { },
  "id_str" : "680778140189364224",
  "text" : "RT @tslumley: When the which-hunters crippled a perfectly good syntactic construction\nhttps:\/\/t.co\/U27vlvwvSH https:\/\/t.co\/H2BsCy9yvi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tslumley\/status\/680653091268603904\/photo\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/H2BsCy9yvi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXIqYQnUsAAht_0.png",
        "id_str" : "680653089951494144",
        "id" : 680653089951494144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXIqYQnUsAAht_0.png",
        "sizes" : [ {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/H2BsCy9yvi"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/U27vlvwvSH",
        "expanded_url" : "http:\/\/languagelog.ldc.upenn.edu\/nll\/?p=22859",
        "display_url" : "languagelog.ldc.upenn.edu\/nll\/?p=22859"
      } ]
    },
    "geo" : { },
    "id_str" : "680653091268603904",
    "text" : "When the which-hunters crippled a perfectly good syntactic construction\nhttps:\/\/t.co\/U27vlvwvSH https:\/\/t.co\/H2BsCy9yvi",
    "id" : 680653091268603904,
    "created_at" : "2015-12-26 07:35:17 +0000",
    "user" : {
      "name" : "Thomas Lumley",
      "screen_name" : "tslumley",
      "protected" : false,
      "id_str" : "1168003974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3237872431\/07ecae166f2898fc9da007a5de720cb3_normal.jpeg",
      "id" : 1168003974,
      "verified" : false
    }
  },
  "id" : 680778140189364224,
  "created_at" : "2015-12-26 15:52:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/A3JFlUOcLg",
      "expanded_url" : "http:\/\/now-here-this.timeout.com\/wp-content\/uploads\/2013\/04\/tumblr_lkoxcq7mri1qakh43o1_500.gif",
      "display_url" : "now-here-this.timeout.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "680517236549902336",
  "geo" : { },
  "id_str" : "680518157631655936",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 responder https:\/\/t.co\/A3JFlUOcLg",
  "id" : 680518157631655936,
  "in_reply_to_status_id" : 680517236549902336,
  "created_at" : "2015-12-25 22:39:06 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680517045344145408",
  "text" : "\u00ABHow was your Christmas?\u00BB \u2013 \u00ABBasically a bisexual remake of \u2018The Graduate\u2019.\u00BB",
  "id" : 680517045344145408,
  "created_at" : "2015-12-25 22:34:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "680515235845820417",
  "geo" : { },
  "id_str" : "680515509973073921",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson what exactly would you like to analyse? Not familiar with it.",
  "id" : 680515509973073921,
  "in_reply_to_status_id" : 680515235845820417,
  "created_at" : "2015-12-25 22:28:35 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "680513588658737152",
  "geo" : { },
  "id_str" : "680513868230189057",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson happens to be that I did the concordance analysis ;) 100x sounds really good though, I fear there goes my money :P",
  "id" : 680513868230189057,
  "in_reply_to_status_id" : 680513588658737152,
  "created_at" : "2015-12-25 22:22:04 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/g26nVWf9N3",
      "expanded_url" : "http:\/\/bmcgenomics.biomedcentral.com\/articles\/10.1186\/s12864-015-1973-7",
      "display_url" : "bmcgenomics.biomedcentral.com\/articles\/10.11\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "680512214147547137",
  "geo" : { },
  "id_str" : "680512568948068352",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson don\u2019t do 2x! See concordance analysis here https:\/\/t.co\/g26nVWf9N3",
  "id" : 680512568948068352,
  "in_reply_to_status_id" : 680512214147547137,
  "created_at" : "2015-12-25 22:16:54 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/6mgEDW8SXn",
      "expanded_url" : "http:\/\/mediadiversified.org\/2015\/12\/20\/12-writers-of-colour-im-excited-about-reading-in-2016\/",
      "display_url" : "mediadiversified.org\/2015\/12\/20\/12-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "680495684223676420",
  "text" : "More for your reading list: 12 Writers Of Colour I\u2019m Excited About Reading In 2016 https:\/\/t.co\/6mgEDW8SXn",
  "id" : 680495684223676420,
  "created_at" : "2015-12-25 21:09:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/y5M0yLPmTK",
      "expanded_url" : "http:\/\/journals.plos.org\/plosgenetics\/article?id=10.1371\/journal.pgen.1005736",
      "display_url" : "journals.plos.org\/plosgenetics\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "680488549393760256",
  "text" : "\u00ABWomen Who Don't Give a Crap\u00BB My reading list did just grow a bit. https:\/\/t.co\/y5M0yLPmTK",
  "id" : 680488549393760256,
  "created_at" : "2015-12-25 20:41:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "680482473378197504",
  "geo" : { },
  "id_str" : "680482940707581952",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe thanks a lot!",
  "id" : 680482940707581952,
  "in_reply_to_status_id" : 680482473378197504,
  "created_at" : "2015-12-25 20:19:10 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 75, 85 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/pMtW7ZbP9Z",
      "expanded_url" : "https:\/\/opensnp.wordpress.com\/2015\/12\/25\/our-2015-end-of-the-year-newsletter\/",
      "display_url" : "opensnp.wordpress.com\/2015\/12\/25\/our\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "680475621659668484",
  "text" : "The openSNP newsletter is now also on the blog https:\/\/t.co\/pMtW7ZbP9Z \/cc @biocrusoe",
  "id" : 680475621659668484,
  "created_at" : "2015-12-25 19:50:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 11, 23 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "680403711668137984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.08937302057645, 7.613480263065401 ]
  },
  "id_str" : "680410651437756418",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe @helgerausch sorry, none yet. Will put it into a blogpost later on. :)",
  "id" : 680410651437756418,
  "in_reply_to_status_id" : 680403711668137984,
  "created_at" : "2015-12-25 15:31:55 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/Dxl3C2IGY6",
      "expanded_url" : "https:\/\/twitter.com\/tolland\/status\/680382627333992448",
      "display_url" : "twitter.com\/tolland\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.08320321920723, 7.631073541579457 ]
  },
  "id_str" : "680385738635132928",
  "text" : "Thanks so much! https:\/\/t.co\/Dxl3C2IGY6",
  "id" : 680385738635132928,
  "created_at" : "2015-12-25 13:52:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 10, 22 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.08939732876109, 7.613436756977998 ]
  },
  "id_str" : "680369192084844546",
  "text" : "Thanks to @helgerausch for sending out the openSNP newsletter! Includes some details on our new infrastructure.",
  "id" : 680369192084844546,
  "created_at" : "2015-12-25 12:47:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.61262089638687, 7.195076630856915 ]
  },
  "id_str" : "680200810203078656",
  "text" : "\u00ABIt\u2019s Christmas Eve, not Christmas and Steve!\u00BB oh, well\u2026",
  "id" : 680200810203078656,
  "created_at" : "2015-12-25 01:38:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.61260726100775, 7.195146611527877 ]
  },
  "id_str" : "680168517124112384",
  "text" : "\u00ABIch habe so ein Magazin abonniert: DDS, das steht f\u00FCr \u2018Der Deutsche Tischler\u2019!\u00BB",
  "id" : 680168517124112384,
  "created_at" : "2015-12-24 23:29:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.61290549852477, 7.193688030116753 ]
  },
  "id_str" : "680157808910807040",
  "text" : "Probably a tad late, but is there any literature on how to deal with the divide that comes with being the only academic in the family?",
  "id" : 680157808910807040,
  "created_at" : "2015-12-24 22:47:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "witch@serenity",
      "screen_name" : "_MinaHarker_",
      "indices" : [ 0, 13 ],
      "id_str" : "1068997124",
      "id" : 1068997124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "680121331409641473",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.08944033102528, 7.613379792299318 ]
  },
  "id_str" : "680131418631069701",
  "in_reply_to_user_id" : 1068997124,
  "text" : "@_MinaHarker_ awww \u2764\uFE0F",
  "id" : 680131418631069701,
  "in_reply_to_status_id" : 680121331409641473,
  "created_at" : "2015-12-24 21:02:21 +0000",
  "in_reply_to_screen_name" : "_MinaHarker_",
  "in_reply_to_user_id_str" : "1068997124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 13, 25 ],
      "id_str" : "48357885",
      "id" : 48357885
    }, {
      "name" : "dridde",
      "screen_name" : "dridde",
      "indices" : [ 26, 33 ],
      "id_str" : "52021289",
      "id" : 52021289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "680047566420074496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.08938465779398, 7.613464210138262 ]
  },
  "id_str" : "680048200598876160",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @Whitey_chan @dridde okay, cool :)",
  "id" : 680048200598876160,
  "in_reply_to_status_id" : 680047566420074496,
  "created_at" : "2015-12-24 15:31:40 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 13, 25 ],
      "id_str" : "48357885",
      "id" : 48357885
    }, {
      "name" : "dridde",
      "screen_name" : "dridde",
      "indices" : [ 26, 33 ],
      "id_str" : "52021289",
      "id" : 52021289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "680046610798231552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.08937119154402, 7.613481142174318 ]
  },
  "id_str" : "680047160864407555",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @Whitey_chan @dridde gerade erst hier angekommen und noch keinen \u00DCberblick \u00FCber die Pl\u00E4ne hier.",
  "id" : 680047160864407555,
  "in_reply_to_status_id" : 680046610798231552,
  "created_at" : "2015-12-24 15:27:32 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "dridde",
      "screen_name" : "dridde",
      "indices" : [ 13, 20 ],
      "id_str" : "52021289",
      "id" : 52021289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679662875435208706",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10952041489082, 8.762151394047553 ]
  },
  "id_str" : "679663165454594048",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat @dridde das Twittertreffen des Westf\u00E4lischen Friedens. :p",
  "id" : 679663165454594048,
  "in_reply_to_status_id" : 679662875435208706,
  "created_at" : "2015-12-23 14:01:40 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679661873797660673",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10812118188488, 8.765931380920826 ]
  },
  "id_str" : "679662493644513280",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat cool, genaueres morgen. Wei\u00DF noch nicht ob ich die Kids am 24. abends in RE besuche. If so w\u00E4re ich aber auch fast in Nottuln.",
  "id" : 679662493644513280,
  "in_reply_to_status_id" : 679661873797660673,
  "created_at" : "2015-12-23 13:59:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679661571405164545",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10753843006687, 8.768855743118346 ]
  },
  "id_str" : "679661726812471296",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat fahre voraussichtlich morgen hoch.",
  "id" : 679661726812471296,
  "in_reply_to_status_id" : 679661571405164545,
  "created_at" : "2015-12-23 13:55:57 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679661100531617796",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10747053665119, 8.770440844827117 ]
  },
  "id_str" : "679661419470663680",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat und wenn du sowieso \u00FCber die A1 f\u00E4hrst\u2026 ;)",
  "id" : 679661419470663680,
  "in_reply_to_status_id" : 679661100531617796,
  "created_at" : "2015-12-23 13:54:44 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679658723531423744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11191093367535, 8.781870240353776 ]
  },
  "id_str" : "679658879391776768",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s sportlich, viel Gl\u00FCck!",
  "id" : 679658879391776768,
  "in_reply_to_status_id" : 679658723531423744,
  "created_at" : "2015-12-23 13:44:38 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679657894749585408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11242667217749, 8.781973673038912 ]
  },
  "id_str" : "679658593625477121",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s Abgabe 31.12.16 :p",
  "id" : 679658593625477121,
  "in_reply_to_status_id" : 679657894749585408,
  "created_at" : "2015-12-23 13:43:30 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679656813638356992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11022990108478, 8.77989303321464 ]
  },
  "id_str" : "679657779834056705",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s Team Diss 2016? \uD83D\uDE09",
  "id" : 679657779834056705,
  "in_reply_to_status_id" : 679656813638356992,
  "created_at" : "2015-12-23 13:40:16 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 0, 13 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 14, 22 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679646473907220481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140952791099, 8.753871293355596 ]
  },
  "id_str" : "679652497955405824",
  "in_reply_to_user_id" : 3059929578,
  "text" : "@repositiveio @glyn_dk thanks, to all of you as well! Looking forward to an equally great 2016 :)",
  "id" : 679652497955405824,
  "in_reply_to_status_id" : 679646473907220481,
  "created_at" : "2015-12-23 13:19:17 +0000",
  "in_reply_to_screen_name" : "repositiveio",
  "in_reply_to_user_id_str" : "3059929578",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 37, 50 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 55, 63 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/679645452803936257\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/XtDdynjEHo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW6V70jWkAAMn96.jpg",
      "id_str" : "679645448731267072",
      "id" : 679645448731267072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW6V70jWkAAMn96.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/XtDdynjEHo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407406484955, 8.753380043633674 ]
  },
  "id_str" : "679645452803936257",
  "text" : "What I just found in my mail. Thanks @repositiveio and @glyn_dk! https:\/\/t.co\/XtDdynjEHo",
  "id" : 679645452803936257,
  "created_at" : "2015-12-23 12:51:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679612229457580033",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407278661179, 8.753386842746444 ]
  },
  "id_str" : "679612459469148160",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z much more appropriate for the vegetarian. ;)",
  "id" : 679612459469148160,
  "in_reply_to_status_id" : 679612229457580033,
  "created_at" : "2015-12-23 10:40:11 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679602373367431168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408032449521, 8.75326893960486 ]
  },
  "id_str" : "679611812199968768",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z I guess we won\u2019t do any BBQ. But thanks for the suggestion ;)",
  "id" : 679611812199968768,
  "in_reply_to_status_id" : 679602373367431168,
  "created_at" : "2015-12-23 10:37:37 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ludmila Carone",
      "screen_name" : "Exotides",
      "indices" : [ 0, 9 ],
      "id_str" : "78689305",
      "id" : 78689305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679609020995514368",
  "geo" : { },
  "id_str" : "679609820454989825",
  "in_reply_to_user_id" : 78689305,
  "text" : "@Exotides fully agree, reproducibility in other sciences is also abysmal in some fields.",
  "id" : 679609820454989825,
  "in_reply_to_status_id" : 679609020995514368,
  "created_at" : "2015-12-23 10:29:42 +0000",
  "in_reply_to_screen_name" : "Exotides",
  "in_reply_to_user_id_str" : "78689305",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/iENXnyyDHN",
      "expanded_url" : "https:\/\/medium.com\/@ValidScience\/bunking-debunking-and-discovery-b1d6ece5e0cb#.34klocvyw",
      "display_url" : "medium.com\/@ValidScience\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679608102996602880",
  "text" : "the fucked up state of social psychology. one of the reasons I stopped blogging about those \u2018results\u2019\u2026 https:\/\/t.co\/iENXnyyDHN",
  "id" : 679608102996602880,
  "created_at" : "2015-12-23 10:22:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Oyen",
      "screen_name" : "michelleoyen",
      "indices" : [ 3, 16 ],
      "id_str" : "83589523",
      "id" : 83589523
    }, {
      "name" : "Kate Clancy",
      "screen_name" : "KateClancy",
      "indices" : [ 129, 140 ],
      "id_str" : "14729597",
      "id" : 14729597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/G3p4yp3dfV",
      "expanded_url" : "http:\/\/wapo.st\/1Zn6czG?tid=ss_tw-bottom",
      "display_url" : "wapo.st\/1Zn6czG?tid=ss\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679599229237628928",
  "text" : "RT @michelleoyen: Not pink = cheaper! Why you should always buy the men\u2019s version of almost anything https:\/\/t.co\/G3p4yp3dfV h\/t @kateclancy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kate Clancy",
        "screen_name" : "KateClancy",
        "indices" : [ 111, 122 ],
        "id_str" : "14729597",
        "id" : 14729597
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/G3p4yp3dfV",
        "expanded_url" : "http:\/\/wapo.st\/1Zn6czG?tid=ss_tw-bottom",
        "display_url" : "wapo.st\/1Zn6czG?tid=ss\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "679598260089049088",
    "text" : "Not pink = cheaper! Why you should always buy the men\u2019s version of almost anything https:\/\/t.co\/G3p4yp3dfV h\/t @kateclancy",
    "id" : 679598260089049088,
    "created_at" : "2015-12-23 09:43:46 +0000",
    "user" : {
      "name" : "Michelle Oyen",
      "screen_name" : "michelleoyen",
      "protected" : false,
      "id_str" : "83589523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479579308\/MyPicture_normal.jpg",
      "id" : 83589523,
      "verified" : false
    }
  },
  "id" : 679599229237628928,
  "created_at" : "2015-12-23 09:47:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Open Science",
      "screen_name" : "openscience",
      "indices" : [ 11, 23 ],
      "id_str" : "53560219",
      "id" : 53560219
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 45, 58 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679399782125842433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407360316041, 8.753379313821966 ]
  },
  "id_str" : "679597932321058816",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @openscience did you manage? iirc @PhilippBayer and I wrote a crawler for them like 5 years ago :3",
  "id" : 679597932321058816,
  "in_reply_to_status_id" : 679399782125842433,
  "created_at" : "2015-12-23 09:42:28 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/lrlRbWnuMv",
      "expanded_url" : "https:\/\/twitter.com\/danwwang\/status\/679348946263609345",
      "display_url" : "twitter.com\/danwwang\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407452561293, 8.753377678949262 ]
  },
  "id_str" : "679589486217555968",
  "text" : "The fungal highlights of 2015 https:\/\/t.co\/lrlRbWnuMv",
  "id" : 679589486217555968,
  "created_at" : "2015-12-23 09:08:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11118320790593, 8.75155932549919 ]
  },
  "id_str" : "679462492926525445",
  "text" : "Travel plans! \uD83D\uDC96\u2708\uFE0F\uD83D\uDE97\uD83D\uDE9E\uD83D\uDC96",
  "id" : 679462492926525445,
  "created_at" : "2015-12-23 00:44:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/L1z1HTQxx1",
      "expanded_url" : "https:\/\/twitter.com\/familyunequal\/status\/679409731191087107",
      "display_url" : "twitter.com\/familyunequal\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679425133916897281",
  "text" : "\u00ABWe gave old people money. And now elderly poverty \u201Chas declined pretty much all the time\u201C [\u2026] Imagine that.\u00BB\n https:\/\/t.co\/L1z1HTQxx1",
  "id" : 679425133916897281,
  "created_at" : "2015-12-22 22:15:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drug Monkey",
      "screen_name" : "drugmonkeyblog",
      "indices" : [ 3, 18 ],
      "id_str" : "26589498",
      "id" : 26589498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679382018103332864",
  "text" : "RT @drugmonkeyblog: \"one must realize that the Black and Latino students who do make it into higher education are national treasures\" https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/n9NFTCEgA2",
        "expanded_url" : "http:\/\/www.achievementseminars.com\/seminar_series_2005_2006\/readings\/Treisman_Studying_Students_Studying_Calculus_1992.pdf",
        "display_url" : "achievementseminars.com\/seminar_series\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "679369506557325313",
    "text" : "\"one must realize that the Black and Latino students who do make it into higher education are national treasures\" https:\/\/t.co\/n9NFTCEgA2",
    "id" : 679369506557325313,
    "created_at" : "2015-12-22 18:34:47 +0000",
    "user" : {
      "name" : "Drug Monkey",
      "screen_name" : "drugmonkeyblog",
      "protected" : false,
      "id_str" : "26589498",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911960280610910208\/F0ay9ioS_normal.jpg",
      "id" : 26589498,
      "verified" : false
    }
  },
  "id" : 679382018103332864,
  "created_at" : "2015-12-22 19:24:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drug Monkey",
      "screen_name" : "drugmonkeyblog",
      "indices" : [ 3, 18 ],
      "id_str" : "26589498",
      "id" : 26589498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679382009135964160",
  "text" : "RT @drugmonkeyblog: A commenter on the blog dropped that link to a piece by a Berkeley calculus professor. You will want to read it. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/n9NFTCEgA2",
        "expanded_url" : "http:\/\/www.achievementseminars.com\/seminar_series_2005_2006\/readings\/Treisman_Studying_Students_Studying_Calculus_1992.pdf",
        "display_url" : "achievementseminars.com\/seminar_series\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "679369660236599300",
    "text" : "A commenter on the blog dropped that link to a piece by a Berkeley calculus professor. You will want to read it. https:\/\/t.co\/n9NFTCEgA2",
    "id" : 679369660236599300,
    "created_at" : "2015-12-22 18:35:23 +0000",
    "user" : {
      "name" : "Drug Monkey",
      "screen_name" : "drugmonkeyblog",
      "protected" : false,
      "id_str" : "26589498",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911960280610910208\/F0ay9ioS_normal.jpg",
      "id" : 26589498,
      "verified" : false
    }
  },
  "id" : 679382009135964160,
  "created_at" : "2015-12-22 19:24:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/lE0hb2DKGI",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/135650749993\/when-the-fire-alarm-keeps-going-off-for-no-reason",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/135650749\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679374311241707520",
  "text" : "As the buggy fire alarm in our building goes falsely off every other day or so, I can only agree. https:\/\/t.co\/lE0hb2DKGI",
  "id" : 679374311241707520,
  "created_at" : "2015-12-22 18:53:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/679366778296909824\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/QRtb2MJREb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW2Ye49WEAA81aU.jpg",
      "id_str" : "679366775255994368",
      "id" : 679366775255994368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW2Ye49WEAA81aU.jpg",
      "sizes" : [ {
        "h" : 964,
        "resize" : "fit",
        "w" : 994
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 964,
        "resize" : "fit",
        "w" : 994
      }, {
        "h" : 659,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 964,
        "resize" : "fit",
        "w" : 994
      } ],
      "display_url" : "pic.twitter.com\/QRtb2MJREb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Z2b0fRq8xo",
      "expanded_url" : "http:\/\/phylo.wikidot.com\/matzke-2015-science-paper-on-the-evolution-of-antievolution#toc1",
      "display_url" : "phylo.wikidot.com\/matzke-2015-sc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679366778296909824",
  "text" : "The evolution of antievolution policies after Kitzmiller v. Dover preprint at https:\/\/t.co\/Z2b0fRq8xo https:\/\/t.co\/QRtb2MJREb",
  "id" : 679366778296909824,
  "created_at" : "2015-12-22 18:23:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/qezDLpvYEy",
      "expanded_url" : "https:\/\/twitter.com\/haaretzcom\/status\/679304159124787200",
      "display_url" : "twitter.com\/haaretzcom\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679310477369982976",
  "text" : "Oh, a new addition for the \u2018dog toy or sex toy\u2019 quiz? https:\/\/t.co\/qezDLpvYEy",
  "id" : 679310477369982976,
  "created_at" : "2015-12-22 14:40:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konrad F\u00F6rstner",
      "screen_name" : "konradfoerstner",
      "indices" : [ 3, 19 ],
      "id_str" : "15150655",
      "id" : 15150655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/USnhuayyUB",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/bioinformatics\/comments\/3xozur\/how_many_bioinformaticians_does_it_take_to_change\/",
      "display_url" : "reddit.com\/r\/bioinformati\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679237023652290560",
  "text" : "RT @konradfoerstner: How many bioinformaticians does it take to change a light bulb? https:\/\/t.co\/USnhuayyUB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/USnhuayyUB",
        "expanded_url" : "https:\/\/www.reddit.com\/r\/bioinformatics\/comments\/3xozur\/how_many_bioinformaticians_does_it_take_to_change\/",
        "display_url" : "reddit.com\/r\/bioinformati\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "679233377459970049",
    "text" : "How many bioinformaticians does it take to change a light bulb? https:\/\/t.co\/USnhuayyUB",
    "id" : 679233377459970049,
    "created_at" : "2015-12-22 09:33:51 +0000",
    "user" : {
      "name" : "Konrad F\u00F6rstner",
      "screen_name" : "konradfoerstner",
      "protected" : false,
      "id_str" : "15150655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895375230281158656\/gXjAenaZ_normal.jpg",
      "id" : 15150655,
      "verified" : false
    }
  },
  "id" : 679237023652290560,
  "created_at" : "2015-12-22 09:48:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lufthansa",
      "screen_name" : "lufthansa",
      "indices" : [ 31, 41 ],
      "id_str" : "124476322",
      "id" : 124476322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17210864619148, 8.627763326629168 ]
  },
  "id_str" : "679227205818441728",
  "text" : "Took them nearly 2 months, but @lufthansa finally got in touch and agreed to pay my strike-induced train tickets\u2026",
  "id" : 679227205818441728,
  "created_at" : "2015-12-22 09:09:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 13, 23 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679085501530378242",
  "geo" : { },
  "id_str" : "679085715137896448",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @biocrusoe oh no, not this again. Don\u2019t forget your slippers!",
  "id" : 679085715137896448,
  "in_reply_to_status_id" : 679085501530378242,
  "created_at" : "2015-12-21 23:47:05 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 13, 23 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679081412348264448",
  "geo" : { },
  "id_str" : "679081574663643136",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @biocrusoe \u2018the dog ate my pants\u2019, oldest excuse in the book!",
  "id" : 679081574663643136,
  "in_reply_to_status_id" : 679081412348264448,
  "created_at" : "2015-12-21 23:30:38 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 13, 23 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679080428909830144",
  "geo" : { },
  "id_str" : "679081256957706240",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @biocrusoe did he learn that trick from observing you? ;)",
  "id" : 679081256957706240,
  "in_reply_to_status_id" : 679080428909830144,
  "created_at" : "2015-12-21 23:29:23 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 13, 23 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679078091097022465",
  "geo" : { },
  "id_str" : "679079696919826432",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @biocrusoe Does Baxter have one of those as well? :D",
  "id" : 679079696919826432,
  "in_reply_to_status_id" : 679078091097022465,
  "created_at" : "2015-12-21 23:23:11 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 11, 23 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679076978675359744",
  "geo" : { },
  "id_str" : "679077225224871941",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe @froggleston matching doggie sweaters! \uD83D\uDC95\uD83D\uDE0D",
  "id" : 679077225224871941,
  "in_reply_to_status_id" : 679076978675359744,
  "created_at" : "2015-12-21 23:13:21 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679074485509726208",
  "text" : "Somehow the annual meeting of the \u2018Society for Social Studies of Science\u2019 ended up in my calendar. m)",
  "id" : 679074485509726208,
  "created_at" : "2015-12-21 23:02:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Oyen",
      "screen_name" : "michelleoyen",
      "indices" : [ 3, 16 ],
      "id_str" : "83589523",
      "id" : 83589523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/j9bZKzefMN",
      "expanded_url" : "http:\/\/wpo.st\/_Tky0",
      "display_url" : "wpo.st\/_Tky0"
    } ]
  },
  "geo" : { },
  "id_str" : "679025129528172545",
  "text" : "RT @michelleoyen: This is lovely. My husband read to me while I was sick. It changed our marriage. https:\/\/t.co\/j9bZKzefMN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/j9bZKzefMN",
        "expanded_url" : "http:\/\/wpo.st\/_Tky0",
        "display_url" : "wpo.st\/_Tky0"
      } ]
    },
    "geo" : { },
    "id_str" : "679023247304884225",
    "text" : "This is lovely. My husband read to me while I was sick. It changed our marriage. https:\/\/t.co\/j9bZKzefMN",
    "id" : 679023247304884225,
    "created_at" : "2015-12-21 19:38:52 +0000",
    "user" : {
      "name" : "Michelle Oyen",
      "screen_name" : "michelleoyen",
      "protected" : false,
      "id_str" : "83589523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479579308\/MyPicture_normal.jpg",
      "id" : 83589523,
      "verified" : false
    }
  },
  "id" : 679025129528172545,
  "created_at" : "2015-12-21 19:46:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17218694811098, 8.630151949583292 ]
  },
  "id_str" : "678959083395883010",
  "text" : "Now matter how much you test in development. The missing html tag you only ever find in production m)",
  "id" : 678959083395883010,
  "created_at" : "2015-12-21 15:23:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678953613457100800",
  "geo" : { },
  "id_str" : "678954251914248192",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson thought it might be interesting to you :)",
  "id" : 678954251914248192,
  "in_reply_to_status_id" : 678953613457100800,
  "created_at" : "2015-12-21 15:04:42 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17219183358958, 8.630208688326459 ]
  },
  "id_str" : "678946072060895232",
  "text" : "Academia, where you are considered an \u2018early career researcher\u2019 right up to the point where you feel you\u2019re too old for doing it\u2026",
  "id" : 678946072060895232,
  "created_at" : "2015-12-21 14:32:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain \u2744\uFE0F\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDF93",
      "screen_name" : "DevilleSy",
      "indices" : [ 3, 13 ],
      "id_str" : "331228486",
      "id" : 331228486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DevilleSy\/status\/678887853200269312\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/TldcrmCIZM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWvkzziWwAARFQ-.png",
      "id_str" : "678887747508158464",
      "id" : 678887747508158464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWvkzziWwAARFQ-.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 635
      } ],
      "display_url" : "pic.twitter.com\/TldcrmCIZM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678902307405340672",
  "text" : "RT @DevilleSy: The academic Xmas bingo. Just on time. https:\/\/t.co\/TldcrmCIZM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DevilleSy\/status\/678887853200269312\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/TldcrmCIZM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWvkzziWwAARFQ-.png",
        "id_str" : "678887747508158464",
        "id" : 678887747508158464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWvkzziWwAARFQ-.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 671,
          "resize" : "fit",
          "w" : 635
        }, {
          "h" : 671,
          "resize" : "fit",
          "w" : 635
        }, {
          "h" : 671,
          "resize" : "fit",
          "w" : 635
        }, {
          "h" : 671,
          "resize" : "fit",
          "w" : 635
        } ],
        "display_url" : "pic.twitter.com\/TldcrmCIZM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "678887853200269312",
    "text" : "The academic Xmas bingo. Just on time. https:\/\/t.co\/TldcrmCIZM",
    "id" : 678887853200269312,
    "created_at" : "2015-12-21 10:40:51 +0000",
    "user" : {
      "name" : "Sylvain \u2744\uFE0F\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDF93",
      "screen_name" : "DevilleSy",
      "protected" : false,
      "id_str" : "331228486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887046588954226688\/p3UlM_8C_normal.jpg",
      "id" : 331228486,
      "verified" : false
    }
  },
  "id" : 678902307405340672,
  "created_at" : "2015-12-21 11:38:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678901075663917056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17182276159673, 8.631373389169518 ]
  },
  "id_str" : "678901180311969792",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer see my comments in the pull request. :)",
  "id" : 678901180311969792,
  "in_reply_to_status_id" : 678901075663917056,
  "created_at" : "2015-12-21 11:33:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678899423565361152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17179675776304, 8.631238440533034 ]
  },
  "id_str" : "678899860981026816",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer awesome, thanks. The image in the footer won\u2019t work because of hardcoded base links. See cfg diff :)",
  "id" : 678899860981026816,
  "in_reply_to_status_id" : 678899423565361152,
  "created_at" : "2015-12-21 11:28:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 69, 83 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/8qZRo2mFBc",
      "expanded_url" : "http:\/\/thelongandshort.org\/society\/is-mind-wandering-an-anti-mindfulness-movement",
      "display_url" : "thelongandshort.org\/society\/is-min\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "678887467945213952",
  "text" : "the rise of an anti-mindfulness movement https:\/\/t.co\/8qZRo2mFBc \/cc @beaugunderson",
  "id" : 678887467945213952,
  "created_at" : "2015-12-21 10:39:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/26n3qPTHST",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=3962",
      "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "678877774254313472",
  "text" : "It\u2019s that card writing season again https:\/\/t.co\/26n3qPTHST",
  "id" : 678877774254313472,
  "created_at" : "2015-12-21 10:00:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678860508892540929",
  "geo" : { },
  "id_str" : "678861722476789760",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u2615\uFE0F",
  "id" : 678861722476789760,
  "in_reply_to_status_id" : 678860508892540929,
  "created_at" : "2015-12-21 08:57:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678830992522502144",
  "geo" : { },
  "id_str" : "678859453828042752",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer *cough* newsletter *cough* :D",
  "id" : 678859453828042752,
  "in_reply_to_status_id" : 678830992522502144,
  "created_at" : "2015-12-21 08:48:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 3, 10 ],
      "id_str" : "71654283",
      "id" : 71654283
    }, {
      "name" : "berlin-artparasites",
      "screen_name" : "artparasites",
      "indices" : [ 16, 29 ],
      "id_str" : "43330668",
      "id" : 43330668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678854977788502017",
  "text" : "RT @arikia: The @artparasites do it again. On being a single, sexual woman and the ways men misunderstand the concept of consent https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "berlin-artparasites",
        "screen_name" : "artparasites",
        "indices" : [ 4, 17 ],
        "id_str" : "43330668",
        "id" : 43330668
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/1SAEnJ8uZx",
        "expanded_url" : "http:\/\/www.artparasites.com\/the-ugly-side-of-being-a-single-attractive-and-available-heterosexual-woman-2\/",
        "display_url" : "artparasites.com\/the-ugly-side-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "678763384020463616",
    "text" : "The @artparasites do it again. On being a single, sexual woman and the ways men misunderstand the concept of consent https:\/\/t.co\/1SAEnJ8uZx",
    "id" : 678763384020463616,
    "created_at" : "2015-12-21 02:26:16 +0000",
    "user" : {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "protected" : false,
      "id_str" : "71654283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897255084073025537\/5uB8YwJG_normal.jpg",
      "id" : 71654283,
      "verified" : false
    }
  },
  "id" : 678854977788502017,
  "created_at" : "2015-12-21 08:30:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678853454815719428",
  "text" : "First travel plans for 2016 emerge: Madrid. \u2708\uFE0F Time so finally see Guernica I guess.",
  "id" : 678853454815719428,
  "created_at" : "2015-12-21 08:24:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/kT2SBZt5UP",
      "expanded_url" : "http:\/\/www.monbiot.com\/2012\/12\/10\/the-gift-of-death\/",
      "display_url" : "monbiot.com\/2012\/12\/10\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "678587215438553092",
  "text" : "RT @pathogenomenick: The Gift of Death https:\/\/t.co\/kT2SBZt5UP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/kT2SBZt5UP",
        "expanded_url" : "http:\/\/www.monbiot.com\/2012\/12\/10\/the-gift-of-death\/",
        "display_url" : "monbiot.com\/2012\/12\/10\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "678585463167459328",
    "text" : "The Gift of Death https:\/\/t.co\/kT2SBZt5UP",
    "id" : 678585463167459328,
    "created_at" : "2015-12-20 14:39:16 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 678587215438553092,
  "created_at" : "2015-12-20 14:46:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678581731021099008",
  "geo" : { },
  "id_str" : "678581809949614080",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi thanks! :)",
  "id" : 678581809949614080,
  "in_reply_to_status_id" : 678581731021099008,
  "created_at" : "2015-12-20 14:24:45 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678577056616202240",
  "geo" : { },
  "id_str" : "678581525722628096",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi last paragraph: maybe change to \u201Edifferent parts of the tree of life\u201C? platypus and human are on the same tree after all. :)",
  "id" : 678581525722628096,
  "in_reply_to_status_id" : 678577056616202240,
  "created_at" : "2015-12-20 14:23:37 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11414215439009, 8.753206059344814 ]
  },
  "id_str" : "678569333262565376",
  "text" : "@malech h\u00E4tte ich das gewusst h\u00E4tte ich mich eingeladen ;)",
  "id" : 678569333262565376,
  "created_at" : "2015-12-20 13:35:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/678532833938415617\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/50kOo6v9ns",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWqiA71UYAAmeet.jpg",
      "id_str" : "678532830817705984",
      "id" : 678532830817705984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWqiA71UYAAmeet.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/50kOo6v9ns"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10297440442866, 8.691381470742147 ]
  },
  "id_str" : "678532833938415617",
  "text" : "Rules you do not find in the gym next to the university. https:\/\/t.co\/50kOo6v9ns",
  "id" : 678532833938415617,
  "created_at" : "2015-12-20 11:10:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678527071417729024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09927398848352, 8.69122237475034 ]
  },
  "id_str" : "678529774432710656",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo the length people go just so they can say their AirBnB has a view of the  Eiffel Tower!",
  "id" : 678529774432710656,
  "in_reply_to_status_id" : 678527071417729024,
  "created_at" : "2015-12-20 10:57:59 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josefine",
      "screen_name" : "josefine",
      "indices" : [ 0, 9 ],
      "id_str" : "14054240",
      "id" : 14054240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678277714671988736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406674130724, 8.753378993391356 ]
  },
  "id_str" : "678293042550480900",
  "in_reply_to_user_id" : 14054240,
  "text" : "@josefine \uD83D\uDE4F",
  "id" : 678293042550480900,
  "in_reply_to_status_id" : 678277714671988736,
  "created_at" : "2015-12-19 19:17:18 +0000",
  "in_reply_to_screen_name" : "josefine",
  "in_reply_to_user_id_str" : "14054240",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 10, 21 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678249402981593089",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10690099476755, 8.76497469878451 ]
  },
  "id_str" : "678250296846491649",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @bella_velo all gel pans are filled using mouth-blown pipettes",
  "id" : 678250296846491649,
  "in_reply_to_status_id" : 678249402981593089,
  "created_at" : "2015-12-19 16:27:26 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 10, 21 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/BupaRrjKHU",
      "expanded_url" : "https:\/\/instagram.com\/p\/mP1UHJPBLB\/",
      "display_url" : "instagram.com\/p\/mP1UHJPBLB\/"
    } ]
  },
  "in_reply_to_status_id_str" : "678248660895997952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10800996888651, 8.765423447244185 ]
  },
  "id_str" : "678249431385415680",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @bella_velo the press kit is coming together nicely! https:\/\/t.co\/BupaRrjKHU",
  "id" : 678249431385415680,
  "in_reply_to_status_id" : 678248660895997952,
  "created_at" : "2015-12-19 16:24:00 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 10, 21 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678244140891643904",
  "geo" : { },
  "id_str" : "678244782662098945",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @bella_velo count me in, Portland Biosciences.",
  "id" : 678244782662098945,
  "in_reply_to_status_id" : 678244140891643904,
  "created_at" : "2015-12-19 16:05:32 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 10, 21 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/bgSUi4eE1j",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/URuEc5hnbNIGs\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/URuEc5hn\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "678243114516127745",
  "geo" : { },
  "id_str" : "678243928068505600",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @bella_velo ka-ching! https:\/\/t.co\/bgSUi4eE1j",
  "id" : 678243928068505600,
  "in_reply_to_status_id" : 678243114516127745,
  "created_at" : "2015-12-19 16:02:08 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 10, 21 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678240962116755456",
  "geo" : { },
  "id_str" : "678242655072030721",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @bella_velo run your fingers over the clay tablet and feel your genome, letter for letter.",
  "id" : 678242655072030721,
  "in_reply_to_status_id" : 678240962116755456,
  "created_at" : "2015-12-19 15:57:04 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 10, 21 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/8DMG3WGZNc",
      "expanded_url" : "http:\/\/dumbcuneiform.com\/",
      "display_url" : "dumbcuneiform.com"
    } ]
  },
  "in_reply_to_status_id_str" : "678240962116755456",
  "geo" : { },
  "id_str" : "678241620307877889",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @bella_velo I could see us collaborate with https:\/\/t.co\/8DMG3WGZNc",
  "id" : 678241620307877889,
  "in_reply_to_status_id" : 678240962116755456,
  "created_at" : "2015-12-19 15:52:58 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 10, 21 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678236482616827904",
  "geo" : { },
  "id_str" : "678236853548486661",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @bella_velo base calls hand-written on papyrus.",
  "id" : 678236853548486661,
  "in_reply_to_status_id" : 678236482616827904,
  "created_at" : "2015-12-19 15:34:01 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 12, 21 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "george church",
      "screen_name" : "geochurch",
      "indices" : [ 46, 56 ],
      "id_str" : "137836269",
      "id" : 137836269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678232570539196416",
  "geo" : { },
  "id_str" : "678236085886058496",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo @wilbanks but how else would e.g. @geochurch and I get people to publish their DNA? :D",
  "id" : 678236085886058496,
  "in_reply_to_status_id" : 678232570539196416,
  "created_at" : "2015-12-19 15:30:58 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678229530276995072",
  "geo" : { },
  "id_str" : "678229792790040577",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski you know the preprint is the one largely refuting the horizontal gene transfer claims? :D",
  "id" : 678229792790040577,
  "in_reply_to_status_id" : 678229530276995072,
  "created_at" : "2015-12-19 15:05:58 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/3o9jL6DJp4",
      "expanded_url" : "http:\/\/www.biorxiv.org\/content\/biorxiv\/early\/2015\/12\/13\/033464",
      "display_url" : "biorxiv.org\/content\/biorxi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "678229286034259968",
  "text" : "Having my own work cited in the tardigrade genome preprint means it was worth all the time and energy. \\o\/ https:\/\/t.co\/3o9jL6DJp4",
  "id" : 678229286034259968,
  "created_at" : "2015-12-19 15:03:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 13, 23 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678140651091963904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406653696855, 8.753406644935541 ]
  },
  "id_str" : "678162099584016384",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @biocrusoe the saddest thing ever in my OkC profile: \u2018loves dogs, has cats\u2019.",
  "id" : 678162099584016384,
  "in_reply_to_status_id" : 678140651091963904,
  "created_at" : "2015-12-19 10:36:58 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678093346074730497",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406594813741, 8.753399537384276 ]
  },
  "id_str" : "678133757497499648",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe best thing to wake up to \uD83D\uDC96",
  "id" : 678133757497499648,
  "in_reply_to_status_id" : 678093346074730497,
  "created_at" : "2015-12-19 08:44:21 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 59, 69 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401363159774, 8.753609122993783 ]
  },
  "id_str" : "678015092626210816",
  "text" : "Late night puppy pictures in my email inbox. \uD83D\uDC96 (hear that, @biocrusoe?\uD83D\uDE09)",
  "id" : 678015092626210816,
  "created_at" : "2015-12-19 00:52:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678009656493613056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406653789206, 8.753388476126808 ]
  },
  "id_str" : "678012712622940161",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC \uD83D\uDCCA\uD83D\uDC96\uD83D\uDE0D",
  "id" : 678012712622940161,
  "in_reply_to_status_id" : 678009656493613056,
  "created_at" : "2015-12-19 00:43:22 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677983672423813121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406613045335, 8.753391917599327 ]
  },
  "id_str" : "677986598500360193",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime let\u2019s say I\u2019d rather support a project that\u2019s a bit less commercial ;)",
  "id" : 677986598500360193,
  "in_reply_to_status_id" : 677983672423813121,
  "created_at" : "2015-12-18 22:59:36 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677982114176978946",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398622206066, 8.753484678557845 ]
  },
  "id_str" : "677982633108852736",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime awesome, so no more of my money will go to uBiome I guess :3",
  "id" : 677982633108852736,
  "in_reply_to_status_id" : 677982114176978946,
  "created_at" : "2015-12-18 22:43:50 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677939077317046272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406644874903, 8.753387098182396 ]
  },
  "id_str" : "677977346218074112",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime still no love for us Europeans, right? :(",
  "id" : 677977346218074112,
  "in_reply_to_status_id" : 677939077317046272,
  "created_at" : "2015-12-18 22:22:50 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 3, 13 ],
      "id_str" : "176024190",
      "id" : 176024190
    }, {
      "name" : "BauhiniaGenome",
      "screen_name" : "BauhiniaGenome",
      "indices" : [ 89, 104 ],
      "id_str" : "3589537993",
      "id" : 3589537993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/See7gUAmEl",
      "expanded_url" : "http:\/\/igg.me\/at\/bauhinia",
      "display_url" : "igg.me\/at\/bauhinia"
    } ]
  },
  "geo" : { },
  "id_str" : "677944330531786753",
  "text" : "RT @SCEdmunds: Last Xmas, I gave you my heart\nThis year, to save me from tears\nCrowdfund @BauhiniaGenome\nhttps:\/\/t.co\/See7gUAmEl https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BauhiniaGenome",
        "screen_name" : "BauhiniaGenome",
        "indices" : [ 74, 89 ],
        "id_str" : "3589537993",
        "id" : 3589537993
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SCEdmunds\/status\/677907318844088320\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/eotYs049al",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWhpHQrU4AAinFt.jpg",
        "id_str" : "677907317375950848",
        "id" : 677907317375950848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWhpHQrU4AAinFt.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/eotYs049al"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/See7gUAmEl",
        "expanded_url" : "http:\/\/igg.me\/at\/bauhinia",
        "display_url" : "igg.me\/at\/bauhinia"
      } ]
    },
    "geo" : { },
    "id_str" : "677907318844088320",
    "text" : "Last Xmas, I gave you my heart\nThis year, to save me from tears\nCrowdfund @BauhiniaGenome\nhttps:\/\/t.co\/See7gUAmEl https:\/\/t.co\/eotYs049al",
    "id" : 677907318844088320,
    "created_at" : "2015-12-18 17:44:34 +0000",
    "user" : {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "protected" : false,
      "id_str" : "176024190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1098248807\/chess_normal.JPG",
      "id" : 176024190,
      "verified" : false
    }
  },
  "id" : 677944330531786753,
  "created_at" : "2015-12-18 20:11:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 3, 14 ],
      "id_str" : "201632630",
      "id" : 201632630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/woumdZVjhM",
      "expanded_url" : "http:\/\/buff.ly\/1m9tXN9",
      "display_url" : "buff.ly\/1m9tXN9"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/1ZqXhZKg4c",
      "expanded_url" : "http:\/\/buff.ly\/1m9u0sf",
      "display_url" : "buff.ly\/1m9u0sf"
    } ]
  },
  "geo" : { },
  "id_str" : "677890072029564928",
  "text" : "RT @BPrainsack: Why the term 'sharing economy' needs to die https:\/\/t.co\/woumdZVjhM - via Tamar Sharon a propos of https:\/\/t.co\/1ZqXhZKg4c",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/woumdZVjhM",
        "expanded_url" : "http:\/\/buff.ly\/1m9tXN9",
        "display_url" : "buff.ly\/1m9tXN9"
      }, {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/1ZqXhZKg4c",
        "expanded_url" : "http:\/\/buff.ly\/1m9u0sf",
        "display_url" : "buff.ly\/1m9u0sf"
      } ]
    },
    "geo" : { },
    "id_str" : "677888773007482880",
    "text" : "Why the term 'sharing economy' needs to die https:\/\/t.co\/woumdZVjhM - via Tamar Sharon a propos of https:\/\/t.co\/1ZqXhZKg4c",
    "id" : 677888773007482880,
    "created_at" : "2015-12-18 16:30:52 +0000",
    "user" : {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "protected" : false,
      "id_str" : "201632630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927171665917890561\/w5htgqHc_normal.jpg",
      "id" : 201632630,
      "verified" : false
    }
  },
  "id" : 677890072029564928,
  "created_at" : "2015-12-18 16:36:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/rRPgZCXmgk",
      "expanded_url" : "https:\/\/twitter.com\/shun_geki_satsu\/status\/677867716439490561",
      "display_url" : "twitter.com\/shun_geki_sats\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677874247436472320",
  "text" : "qdnf\u2026 and it\u2019s not just video games that are so ignorant\u2026 https:\/\/t.co\/rRPgZCXmgk",
  "id" : 677874247436472320,
  "created_at" : "2015-12-18 15:33:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/JJEHkeU5r2",
      "expanded_url" : "http:\/\/lithub.com\/men-explain-lolita-to-me\/",
      "display_url" : "lithub.com\/men-explain-lo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677867885704798209",
  "text" : "Men explain Lolita to Rebecca Solnit: \u00ABI just goggle in amazement at the batshit that comes out of them\u00BB https:\/\/t.co\/JJEHkeU5r2",
  "id" : 677867885704798209,
  "created_at" : "2015-12-18 15:07:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/W1lMdSajKY",
      "expanded_url" : "http:\/\/ignitelighters.com\/",
      "display_url" : "ignitelighters.com"
    } ]
  },
  "in_reply_to_status_id_str" : "677865615344799744",
  "geo" : { },
  "id_str" : "677865814284886016",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot https:\/\/t.co\/W1lMdSajKY",
  "id" : 677865814284886016,
  "in_reply_to_status_id" : 677865615344799744,
  "created_at" : "2015-12-18 14:59:38 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/LASAF9GvQn",
      "expanded_url" : "https:\/\/twitter.com\/tomstafford\/status\/677842156074176512",
      "display_url" : "twitter.com\/tomstafford\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677846910808498176",
  "text" : "Have to adopt this! https:\/\/t.co\/LASAF9GvQn",
  "id" : 677846910808498176,
  "created_at" : "2015-12-18 13:44:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adolfo Neto",
      "screen_name" : "adolfont",
      "indices" : [ 3, 12 ],
      "id_str" : "14341495",
      "id" : 14341495
    }, {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "indices" : [ 15, 22 ],
      "id_str" : "47876842",
      "id" : 47876842
    }, {
      "name" : "NassimNicholasTaleb",
      "screen_name" : "nntaleb",
      "indices" : [ 39, 47 ],
      "id_str" : "381289719",
      "id" : 381289719
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/adolfont\/status\/677786691189547008\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/EvHttBQCUm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWf668RWsAAR4Dz.png",
      "id_str" : "677786159460823040",
      "id" : 677786159460823040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWf668RWsAAR4Dz.png",
      "sizes" : [ {
        "h" : 49,
        "resize" : "fit",
        "w" : 421
      }, {
        "h" : 49,
        "resize" : "crop",
        "w" : 49
      }, {
        "h" : 49,
        "resize" : "fit",
        "w" : 421
      }, {
        "h" : 49,
        "resize" : "fit",
        "w" : 421
      }, {
        "h" : 49,
        "resize" : "fit",
        "w" : 421
      } ],
      "display_url" : "pic.twitter.com\/EvHttBQCUm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/N0JLUgewyo",
      "expanded_url" : "http:\/\/bit.ly\/1RsT9ve",
      "display_url" : "bit.ly\/1RsT9ve"
    } ]
  },
  "geo" : { },
  "id_str" : "677839350189711360",
  "text" : "RT @adolfont: '@brembs confirming what @nntaleb says about academic freedom https:\/\/t.co\/N0JLUgewyo https:\/\/t.co\/EvHttBQCUm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bj\u00F6rn Brembs",
        "screen_name" : "brembs",
        "indices" : [ 1, 8 ],
        "id_str" : "47876842",
        "id" : 47876842
      }, {
        "name" : "NassimNicholasTaleb",
        "screen_name" : "nntaleb",
        "indices" : [ 25, 33 ],
        "id_str" : "381289719",
        "id" : 381289719
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/adolfont\/status\/677786691189547008\/photo\/1",
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/EvHttBQCUm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWf668RWsAAR4Dz.png",
        "id_str" : "677786159460823040",
        "id" : 677786159460823040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWf668RWsAAR4Dz.png",
        "sizes" : [ {
          "h" : 49,
          "resize" : "fit",
          "w" : 421
        }, {
          "h" : 49,
          "resize" : "crop",
          "w" : 49
        }, {
          "h" : 49,
          "resize" : "fit",
          "w" : 421
        }, {
          "h" : 49,
          "resize" : "fit",
          "w" : 421
        }, {
          "h" : 49,
          "resize" : "fit",
          "w" : 421
        } ],
        "display_url" : "pic.twitter.com\/EvHttBQCUm"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/N0JLUgewyo",
        "expanded_url" : "http:\/\/bit.ly\/1RsT9ve",
        "display_url" : "bit.ly\/1RsT9ve"
      } ]
    },
    "geo" : { },
    "id_str" : "677786691189547008",
    "text" : "'@brembs confirming what @nntaleb says about academic freedom https:\/\/t.co\/N0JLUgewyo https:\/\/t.co\/EvHttBQCUm",
    "id" : 677786691189547008,
    "created_at" : "2015-12-18 09:45:14 +0000",
    "user" : {
      "name" : "Adolfo Neto",
      "screen_name" : "adolfont",
      "protected" : false,
      "id_str" : "14341495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579451309444698112\/L4l_ZUxZ_normal.jpg",
      "id" : 14341495,
      "verified" : false
    }
  },
  "id" : 677839350189711360,
  "created_at" : "2015-12-18 13:14:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/jxuRX4VzIK",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/B2S7bIBG3lixO\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/B2S7bIBG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677836722969952257",
  "text" : "me, hunting bugs https:\/\/t.co\/jxuRX4VzIK",
  "id" : 677836722969952257,
  "created_at" : "2015-12-18 13:04:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "ISCB News",
      "screen_name" : "iscb",
      "indices" : [ 54, 59 ],
      "id_str" : "96111619",
      "id" : 96111619
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 23, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/BJ1MvZgvAB",
      "expanded_url" : "http:\/\/www.iscb.org\/images\/stories\/newsletter\/newsletter18-3\/ISCB-newsletter-18-3-Fall2015.pdf",
      "display_url" : "iscb.org\/images\/stories\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677831908856864768",
  "text" : "RT @OBF_BOSC: Two page #BOSC2015 report is out in the @ISCB Newsletter, Fall 2015, v18(3), p9-10\nhttps:\/\/t.co\/BJ1MvZgvAB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ISCB News",
        "screen_name" : "iscb",
        "indices" : [ 40, 45 ],
        "id_str" : "96111619",
        "id" : 96111619
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2015",
        "indices" : [ 9, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/BJ1MvZgvAB",
        "expanded_url" : "http:\/\/www.iscb.org\/images\/stories\/newsletter\/newsletter18-3\/ISCB-newsletter-18-3-Fall2015.pdf",
        "display_url" : "iscb.org\/images\/stories\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "677814116472504320",
    "text" : "Two page #BOSC2015 report is out in the @ISCB Newsletter, Fall 2015, v18(3), p9-10\nhttps:\/\/t.co\/BJ1MvZgvAB",
    "id" : 677814116472504320,
    "created_at" : "2015-12-18 11:34:13 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 677831908856864768,
  "created_at" : "2015-12-18 12:44:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/FB6W5XZ0Ir",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/677707661455003648",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677766792194994176",
  "text" : "\u00ABif statisticians know about philosophy of science at all, it is [Popper\/Kuhn].\u00BB Ouch! https:\/\/t.co\/FB6W5XZ0Ir",
  "id" : 677766792194994176,
  "created_at" : "2015-12-18 08:26:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677707661455003648",
  "geo" : { },
  "id_str" : "677762800450707456",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks!",
  "id" : 677762800450707456,
  "in_reply_to_status_id" : 677707661455003648,
  "created_at" : "2015-12-18 08:10:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677638919496798208",
  "text" : "Not 100% sure what did the trick, but 3 evenings in I now have a working openSNP development environment again. m)",
  "id" : 677638919496798208,
  "created_at" : "2015-12-17 23:58:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406705159878, 8.753392738885397 ]
  },
  "id_str" : "677568942878142465",
  "text" : "\u00ABAre you eating lots of protein, now that you started working out?\u00BB \u2014 \u00ABDoes ice cream count?\u00BB",
  "id" : 677568942878142465,
  "created_at" : "2015-12-17 19:19:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/jhIagXZxxP",
      "expanded_url" : "https:\/\/twitter.com\/j_zimms\/status\/677525290306899971",
      "display_url" : "twitter.com\/j_zimms\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677560295041183744",
  "text" : "There is Dungeons &amp; Dragons yoga?! Why did no one tell me?! https:\/\/t.co\/jhIagXZxxP",
  "id" : 677560295041183744,
  "created_at" : "2015-12-17 18:45:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CompaniesArePeopleMyFriend",
      "indices" : [ 86, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/LMW3HGgg3S",
      "expanded_url" : "https:\/\/twitter.com\/MishaAngrist\/status\/677485385509953536",
      "display_url" : "twitter.com\/MishaAngrist\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677489249780965377",
  "text" : "RT @wilbanks: Screwing over sick people - legal. Screwing over a company - not legal. #CompaniesArePeopleMyFriend  https:\/\/t.co\/LMW3HGgg3S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CompaniesArePeopleMyFriend",
        "indices" : [ 72, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/LMW3HGgg3S",
        "expanded_url" : "https:\/\/twitter.com\/MishaAngrist\/status\/677485385509953536",
        "display_url" : "twitter.com\/MishaAngrist\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "677485988957069313",
    "text" : "Screwing over sick people - legal. Screwing over a company - not legal. #CompaniesArePeopleMyFriend  https:\/\/t.co\/LMW3HGgg3S",
    "id" : 677485988957069313,
    "created_at" : "2015-12-17 13:50:21 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 677489249780965377,
  "created_at" : "2015-12-17 14:03:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/V2qrVGas82",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Airport_racial_profiling_in_the_United_States",
      "display_url" : "en.wikipedia.org\/wiki\/Airport_r\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "677486546220679168",
  "geo" : { },
  "id_str" : "677488717477605376",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot well\u2026 https:\/\/t.co\/V2qrVGas82",
  "id" : 677488717477605376,
  "in_reply_to_status_id" : 677486546220679168,
  "created_at" : "2015-12-17 14:01:12 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677484647522152448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233904204556, 8.627520384339114 ]
  },
  "id_str" : "677485388429176832",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot for those who are flying while being white\u2026",
  "id" : 677485388429176832,
  "in_reply_to_status_id" : 677484647522152448,
  "created_at" : "2015-12-17 13:47:58 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Goethe-Universit\u00E4t",
      "screen_name" : "goetheuni",
      "indices" : [ 0, 10 ],
      "id_str" : "38180826",
      "id" : 38180826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/MnFfUhAqa8",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/661451984030064640",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "677447458801197056",
  "geo" : { },
  "id_str" : "677464375683375104",
  "in_reply_to_user_id" : 38180826,
  "text" : "@goetheuni auch hinter den Kulissen\u2026 https:\/\/t.co\/MnFfUhAqa8",
  "id" : 677464375683375104,
  "in_reply_to_status_id" : 677447458801197056,
  "created_at" : "2015-12-17 12:24:28 +0000",
  "in_reply_to_screen_name" : "goetheuni",
  "in_reply_to_user_id_str" : "38180826",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/9J0Z0RiBTV",
      "expanded_url" : "http:\/\/i.imgur.com\/w1X4f3j.gif",
      "display_url" : "i.imgur.com\/w1X4f3j.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "677436105713655808",
  "geo" : { },
  "id_str" : "677436308105666560",
  "in_reply_to_user_id" : 14286491,
  "text" : "What web scraping actually feels like https:\/\/t.co\/9J0Z0RiBTV",
  "id" : 677436308105666560,
  "in_reply_to_status_id" : 677436105713655808,
  "created_at" : "2015-12-17 10:32:56 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/UEDMfyWBbB",
      "expanded_url" : "https:\/\/s-media-cache-ec0.pinimg.com\/originals\/38\/62\/51\/386251783c575e4984afe3cd29f9f00e.jpg",
      "display_url" : "s-media-cache-ec0.pinimg.com\/originals\/38\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677436105713655808",
  "text" : "What I expected my web scraping to be like. https:\/\/t.co\/UEDMfyWBbB",
  "id" : 677436105713655808,
  "created_at" : "2015-12-17 10:32:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Daniel Huson",
      "screen_name" : "HusonDaniel",
      "indices" : [ 17, 29 ],
      "id_str" : "3676425321",
      "id" : 3676425321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677412419979841536",
  "geo" : { },
  "id_str" : "677413584083812352",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick @HusonDaniel yes, please!",
  "id" : 677413584083812352,
  "in_reply_to_status_id" : 677412419979841536,
  "created_at" : "2015-12-17 09:02:38 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677282222748147712",
  "geo" : { },
  "id_str" : "677399512906915840",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima happy to do so. :)",
  "id" : 677399512906915840,
  "in_reply_to_status_id" : 677282222748147712,
  "created_at" : "2015-12-17 08:06:44 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/AYAuAwuhuc",
      "expanded_url" : "https:\/\/twitter.com\/matthiasshap\/status\/677275433335980032",
      "display_url" : "twitter.com\/matthiasshap\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406624740689, 8.753380288758692 ]
  },
  "id_str" : "677275779009552384",
  "text" : "Thought it was while trying to figure out how many \u2018last experiments\u2019 he needed to do before publishing the results. https:\/\/t.co\/AYAuAwuhuc",
  "id" : 677275779009552384,
  "created_at" : "2015-12-16 23:55:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677275096134885376",
  "text" : "RT @edyong209: A little victory for psychology: journal editor rejects paper for having data that were clearly too good to be true https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/ASyb1xqzRv",
        "expanded_url" : "http:\/\/blogs.discovermagazine.com\/neuroskeptic\/2015\/11\/27\/real-data-are-messy\/#.VnHycEorLDc",
        "display_url" : "blogs.discovermagazine.com\/neuroskeptic\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "677269270150139904",
    "text" : "A little victory for psychology: journal editor rejects paper for having data that were clearly too good to be true https:\/\/t.co\/ASyb1xqzRv",
    "id" : 677269270150139904,
    "created_at" : "2015-12-16 23:29:11 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 677275096134885376,
  "created_at" : "2015-12-16 23:52:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677242093866262528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114066551984, 8.753414512289927 ]
  },
  "id_str" : "677253453673025538",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC but yes, so far R did work out \uD83D\uDCCA\uD83D\uDCC8\uD83D\uDCC9",
  "id" : 677253453673025538,
  "in_reply_to_status_id" : 677242093866262528,
  "created_at" : "2015-12-16 22:26:20 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677242093866262528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402837357469, 8.753342431111934 ]
  },
  "id_str" : "677253173967519746",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC as I actually have no idea on how to analyze survey data best I might even be tempted to use your weapon of choice. ;)",
  "id" : 677253173967519746,
  "in_reply_to_status_id" : 677242093866262528,
  "created_at" : "2015-12-16 22:25:14 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677222119546167296",
  "geo" : { },
  "id_str" : "677230948136652809",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC actually, I would have some questions regarding this as well :D",
  "id" : 677230948136652809,
  "in_reply_to_status_id" : 677222119546167296,
  "created_at" : "2015-12-16 20:56:55 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashish",
      "screen_name" : "a5hi5h",
      "indices" : [ 0, 7 ],
      "id_str" : "19154546",
      "id" : 19154546
    }, {
      "name" : "matthew scholz",
      "screen_name" : "GenIgnored",
      "indices" : [ 8, 19 ],
      "id_str" : "14777313",
      "id" : 14777313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677175575534952449",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17633750993718, 8.629906999891464 ]
  },
  "id_str" : "677175801331228676",
  "in_reply_to_user_id" : 19154546,
  "text" : "@a5hi5h @GenIgnored thanks. So what I want is the proteins with their associated KOs. Will have a look :)",
  "id" : 677175801331228676,
  "in_reply_to_status_id" : 677175575534952449,
  "created_at" : "2015-12-16 17:17:47 +0000",
  "in_reply_to_screen_name" : "a5hi5h",
  "in_reply_to_user_id_str" : "19154546",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matthew scholz",
      "screen_name" : "GenIgnored",
      "indices" : [ 0, 11 ],
      "id_str" : "14777313",
      "id" : 14777313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677164590980071424",
  "geo" : { },
  "id_str" : "677165341907226624",
  "in_reply_to_user_id" : 14777313,
  "text" : "@GenIgnored yep, and it\u2019s even $5000. Which is ridiculous\u2026",
  "id" : 677165341907226624,
  "in_reply_to_status_id" : 677164590980071424,
  "created_at" : "2015-12-16 16:36:13 +0000",
  "in_reply_to_screen_name" : "GenIgnored",
  "in_reply_to_user_id_str" : "14777313",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matthew scholz",
      "screen_name" : "GenIgnored",
      "indices" : [ 0, 11 ],
      "id_str" : "14777313",
      "id" : 14777313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/4x2ngBlRQU",
      "expanded_url" : "http:\/\/www.genome.jp\/kegg\/catalog\/org_list.html",
      "display_url" : "genome.jp\/kegg\/catalog\/o\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "677164206156812288",
  "geo" : { },
  "id_str" : "677164549213171712",
  "in_reply_to_user_id" : 14777313,
  "text" : "@GenIgnored because I\u2019m not too keen on collecting this list https:\/\/t.co\/4x2ngBlRQU semi-manually.",
  "id" : 677164549213171712,
  "in_reply_to_status_id" : 677164206156812288,
  "created_at" : "2015-12-16 16:33:04 +0000",
  "in_reply_to_screen_name" : "GenIgnored",
  "in_reply_to_user_id_str" : "14777313",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matthew scholz",
      "screen_name" : "GenIgnored",
      "indices" : [ 0, 11 ],
      "id_str" : "14777313",
      "id" : 14777313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677164206156812288",
  "geo" : { },
  "id_str" : "677164381197737984",
  "in_reply_to_user_id" : 14777313,
  "text" : "@GenIgnored FASTA of the proteomes with the KEGG annotations attached to the sequences is what I\u2019m looking for.",
  "id" : 677164381197737984,
  "in_reply_to_status_id" : 677164206156812288,
  "created_at" : "2015-12-16 16:32:24 +0000",
  "in_reply_to_screen_name" : "GenIgnored",
  "in_reply_to_user_id_str" : "14777313",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bioinformatics",
      "indices" : [ 105, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677163987142901760",
  "text" : "Let\u2019s say I\u2019d need a current copy of all KEGG genomes but lack a subscription. Where would I find those? #bioinformatics",
  "id" : 677163987142901760,
  "created_at" : "2015-12-16 16:30:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17247103450472, 8.627512197508413 ]
  },
  "id_str" : "677144071874453504",
  "text" : "When phylogenomics is explained by way of how German right wing parties\/organizations works: mob rule.",
  "id" : 677144071874453504,
  "created_at" : "2015-12-16 15:11:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17244643894135, 8.627509655884273 ]
  },
  "id_str" : "677129777837383680",
  "text" : "@malech jetzt will ich eine Ziege zu Weihnachten!",
  "id" : 677129777837383680,
  "created_at" : "2015-12-16 14:14:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677054815466299394",
  "geo" : { },
  "id_str" : "677055057414725632",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot mundgeblasen, iswydt",
  "id" : 677055057414725632,
  "in_reply_to_status_id" : 677054815466299394,
  "created_at" : "2015-12-16 09:17:59 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Schaefer",
      "screen_name" : "saraschaefer1",
      "indices" : [ 3, 17 ],
      "id_str" : "3359481",
      "id" : 3359481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/c0gE6UQ6N6",
      "expanded_url" : "https:\/\/medium.com\/@saraschaefer1\/oops-i-made-a-feminist-joke-on-the-internet-3ef6cfd1b3b3#.qp2rifbjc",
      "display_url" : "medium.com\/@saraschaefer1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677051393396617216",
  "text" : "RT @saraschaefer1: I know I didn't need to do this but I wanted to, so I did. https:\/\/t.co\/c0gE6UQ6N6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/c0gE6UQ6N6",
        "expanded_url" : "https:\/\/medium.com\/@saraschaefer1\/oops-i-made-a-feminist-joke-on-the-internet-3ef6cfd1b3b3#.qp2rifbjc",
        "display_url" : "medium.com\/@saraschaefer1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "676931948258922509",
    "text" : "I know I didn't need to do this but I wanted to, so I did. https:\/\/t.co\/c0gE6UQ6N6",
    "id" : 676931948258922509,
    "created_at" : "2015-12-16 01:08:47 +0000",
    "user" : {
      "name" : "Sara Schaefer",
      "screen_name" : "saraschaefer1",
      "protected" : false,
      "id_str" : "3359481",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/856646924367048704\/2BzgAMM2_normal.jpg",
      "id" : 3359481,
      "verified" : true
    }
  },
  "id" : 677051393396617216,
  "created_at" : "2015-12-16 09:03:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677050040888750081",
  "text" : "\u00ABDid you make it home safely yesterday?\u00BB \u2013 \u00ABYep, my OkCupid profile should include \u201EI\u2019m good at: Avoiding the police\u201C!\u00BB",
  "id" : 677050040888750081,
  "created_at" : "2015-12-16 08:58:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/WfWICl7VJk",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/guest-blog\/making-furniture-from-fungi\/",
      "display_url" : "blogs.scientificamerican.com\/guest-blog\/mak\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677043027282681856",
  "text" : "Making Furniture from Fungi https:\/\/t.co\/WfWICl7VJk",
  "id" : 677043027282681856,
  "created_at" : "2015-12-16 08:30:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai von Fintel",
      "screen_name" : "fintelkai",
      "indices" : [ 3, 13 ],
      "id_str" : "45580829",
      "id" : 45580829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/jJ7bFyTK8s",
      "expanded_url" : "http:\/\/languagelog.ldc.upenn.edu\/nll\/?p=22842",
      "display_url" : "languagelog.ldc.upenn.edu\/nll\/?p=22842"
    } ]
  },
  "geo" : { },
  "id_str" : "677042317098917888",
  "text" : "RT @fintelkai: Elsevier is trying to recruit people to edit Zombie Lingua. Please, don't agree to work with them! https:\/\/t.co\/jJ7bFyTK8s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/jJ7bFyTK8s",
        "expanded_url" : "http:\/\/languagelog.ldc.upenn.edu\/nll\/?p=22842",
        "display_url" : "languagelog.ldc.upenn.edu\/nll\/?p=22842"
      } ]
    },
    "geo" : { },
    "id_str" : "676884499192553473",
    "text" : "Elsevier is trying to recruit people to edit Zombie Lingua. Please, don't agree to work with them! https:\/\/t.co\/jJ7bFyTK8s",
    "id" : 676884499192553473,
    "created_at" : "2015-12-15 22:00:15 +0000",
    "user" : {
      "name" : "Kai von Fintel",
      "screen_name" : "fintelkai",
      "protected" : false,
      "id_str" : "45580829",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/297543898\/kai_normal.jpg",
      "id" : 45580829,
      "verified" : false
    }
  },
  "id" : 677042317098917888,
  "created_at" : "2015-12-16 08:27:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677040680451964929",
  "geo" : { },
  "id_str" : "677041775488442368",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer What's the bravest thing you ever did?\nHe spat in the road a bloody phlegm. Getting up this morning, he said.",
  "id" : 677041775488442368,
  "in_reply_to_status_id" : 677040680451964929,
  "created_at" : "2015-12-16 08:25:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677035341732184064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17150758385114, 8.628485198956866 ]
  },
  "id_str" : "677039782686539777",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer can\u2019t wait for his take on Die Hard :p",
  "id" : 677039782686539777,
  "in_reply_to_status_id" : 677035341732184064,
  "created_at" : "2015-12-16 08:17:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677007018062950400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.12320072860468, 8.72796102427759 ]
  },
  "id_str" : "677033380198895616",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer maybe the man himself was feeling a bit bored.",
  "id" : 677033380198895616,
  "in_reply_to_status_id" : 677007018062950400,
  "created_at" : "2015-12-16 07:51:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676910388030644225",
  "text" : "Getting some routine in writing those \u201Ewill attend, if you make sure there aren\u2019t only cis men on the panel\u201C emails.",
  "id" : 676910388030644225,
  "created_at" : "2015-12-15 23:43:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Shultz",
      "screen_name" : "dshultz14",
      "indices" : [ 0, 10 ],
      "id_str" : "1730159762",
      "id" : 1730159762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676550985087500288",
  "geo" : { },
  "id_str" : "676909100064751616",
  "in_reply_to_user_id" : 1730159762,
  "text" : "@dshultz14 cool, what\u2019s the paper? :)",
  "id" : 676909100064751616,
  "in_reply_to_status_id" : 676550985087500288,
  "created_at" : "2015-12-15 23:38:00 +0000",
  "in_reply_to_screen_name" : "dshultz14",
  "in_reply_to_user_id_str" : "1730159762",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 74, 87 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/6ckZr36gtL",
      "expanded_url" : "https:\/\/twitter.com\/AdrienneLaF\/status\/676742517233201152",
      "display_url" : "twitter.com\/AdrienneLaF\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676792396068356096",
  "text" : "\u00ABHe goes to church, believes in nothing, only meets a man with a shovel.\u00BB @PhilippBayer, you have to read this! https:\/\/t.co\/6ckZr36gtL",
  "id" : 676792396068356096,
  "created_at" : "2015-12-15 15:54:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 9, 23 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Israel Barrantes",
      "screen_name" : "Limenian",
      "indices" : [ 24, 33 ],
      "id_str" : "1226440681",
      "id" : 1226440681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676766289663270912",
  "geo" : { },
  "id_str" : "676771497189498881",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @BioMickWatson @Limenian when I started using entrez I thought I was going crazy because of this m(",
  "id" : 676771497189498881,
  "in_reply_to_status_id" : 676766289663270912,
  "created_at" : "2015-12-15 14:31:13 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scimpact",
      "screen_name" : "scimpact_org",
      "indices" : [ 0, 13 ],
      "id_str" : "3313174584",
      "id" : 3313174584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676761131411730432",
  "geo" : { },
  "id_str" : "676763101040132096",
  "in_reply_to_user_id" : 3313174584,
  "text" : "@scimpact_org looking forward to that! :)",
  "id" : 676763101040132096,
  "in_reply_to_status_id" : 676761131411730432,
  "created_at" : "2015-12-15 13:57:51 +0000",
  "in_reply_to_screen_name" : "scimpact_org",
  "in_reply_to_user_id_str" : "3313174584",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FORCE2016",
      "indices" : [ 23, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/qSJmCyqT6c",
      "expanded_url" : "http:\/\/www.force2016.org\/",
      "display_url" : "force2016.org"
    } ]
  },
  "geo" : { },
  "id_str" : "676755475212447744",
  "text" : "Abstract submitted for #FORCE2016 \u2714\uFE0E https:\/\/t.co\/qSJmCyqT6c",
  "id" : 676755475212447744,
  "created_at" : "2015-12-15 13:27:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daan Speth",
      "screen_name" : "daanspeth",
      "indices" : [ 0, 10 ],
      "id_str" : "1536778088",
      "id" : 1536778088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676750546024407040",
  "geo" : { },
  "id_str" : "676751036380536833",
  "in_reply_to_user_id" : 1536778088,
  "text" : "@daanspeth yep, that one is even featured in the BMJ\u2019s christmas paper. :)",
  "id" : 676751036380536833,
  "in_reply_to_status_id" : 676750546024407040,
  "created_at" : "2015-12-15 13:09:55 +0000",
  "in_reply_to_screen_name" : "daanspeth",
  "in_reply_to_user_id_str" : "1536778088",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daan Speth",
      "screen_name" : "daanspeth",
      "indices" : [ 0, 10 ],
      "id_str" : "1536778088",
      "id" : 1536778088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676749674355793920",
  "geo" : { },
  "id_str" : "676750696105050113",
  "in_reply_to_user_id" : 1536778088,
  "text" : "@daanspeth that\u2019s also really cool! I wish crypto-people would kick out Alice &amp; Bob in favor of Lily, Rosemary and the Jack of Hearts.",
  "id" : 676750696105050113,
  "in_reply_to_status_id" : 676749674355793920,
  "created_at" : "2015-12-15 13:08:34 +0000",
  "in_reply_to_screen_name" : "daanspeth",
  "in_reply_to_user_id_str" : "1536778088",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676746586072961024",
  "geo" : { },
  "id_str" : "676747400204173312",
  "in_reply_to_user_id" : 14286491,
  "text" : "From the classic heartbreak album \u2018Blood On The Custom Annotation Tracks\u2019.",
  "id" : 676747400204173312,
  "in_reply_to_status_id" : 676746586072961024,
  "created_at" : "2015-12-15 12:55:28 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/B8eMRzbyVF",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/676746129917259777",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "676746129917259777",
  "geo" : { },
  "id_str" : "676746586072961024",
  "in_reply_to_user_id" : 14286491,
  "text" : "Now I really have the urge to write a paper on the bioethics of genetic testing: \u00ABIf You Sequence Her, Say Hello\u00BB https:\/\/t.co\/B8eMRzbyVF",
  "id" : 676746586072961024,
  "in_reply_to_status_id" : 676746129917259777,
  "created_at" : "2015-12-15 12:52:14 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 126, 136 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/CYgJnvKouT",
      "expanded_url" : "http:\/\/www.bmj.com\/content\/351\/bmj.h6505",
      "display_url" : "bmj.com\/content\/351\/bm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676746129917259777",
  "text" : "\u00ABLike a rolling histone\u00BB Freewheelin\u2019 scientists: citing Bob Dylan in the biomedical literature \uD83D\uDC95 https:\/\/t.co\/CYgJnvKouT \/HT @HLWiencko",
  "id" : 676746129917259777,
  "created_at" : "2015-12-15 12:50:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227387167051, 8.62754907854574 ]
  },
  "id_str" : "676743777713827840",
  "text" : "\u00ABIs he doing the final blah blah?\u00BB \u2014 \u00ABIndeed. Doing so much of it, Europe wants to record a song about it.\u00BB",
  "id" : 676743777713827840,
  "created_at" : "2015-12-15 12:41:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/676717284795277313\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/pkvGXUSNBE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWQuyPgWwAALpQR.png",
      "id_str" : "676717284702994432",
      "id" : 676717284702994432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWQuyPgWwAALpQR.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      } ],
      "display_url" : "pic.twitter.com\/pkvGXUSNBE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172313, 8.627522 ]
  },
  "id_str" : "676717284795277313",
  "text" : "Python isn't too smartwatch-friendly! https:\/\/t.co\/pkvGXUSNBE",
  "id" : 676717284795277313,
  "created_at" : "2015-12-15 10:55:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/IxqJjAiXZT",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/_TzsJJBwlJ\/",
      "display_url" : "instagram.com\/p\/_TzsJJBwlJ\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.366851214, 4.912454588 ]
  },
  "id_str" : "676713840290213888",
  "text" : "Phage overload #latergram @ Micropia https:\/\/t.co\/IxqJjAiXZT",
  "id" : 676713840290213888,
  "created_at" : "2015-12-15 10:42:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/Hjowt0gMMH",
      "expanded_url" : "http:\/\/www.newyorker.com\/news\/sporting-scene\/spiritual-life-long-distance-runner?mbid=rss",
      "display_url" : "newyorker.com\/news\/sporting-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676711660892119040",
  "text" : "The Spiritual Life of the Long-Distance Runner https:\/\/t.co\/Hjowt0gMMH",
  "id" : 676711660892119040,
  "created_at" : "2015-12-15 10:33:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly Ganz",
      "screen_name" : "hollyhganz",
      "indices" : [ 128, 139 ],
      "id_str" : "23547345",
      "id" : 23547345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/JXGDIuFnsR",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0144881",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676710342009991168",
  "text" : "Feline Faecal Microbiome Identifies Changes into Early Adulthood Irrespective of Sexual Development https:\/\/t.co\/JXGDIuFnsR \/cc @hollyhganz",
  "id" : 676710342009991168,
  "created_at" : "2015-12-15 10:28:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spektrum",
      "screen_name" : "spektrum",
      "indices" : [ 0, 9 ],
      "id_str" : "14953378",
      "id" : 14953378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676703547287863296",
  "geo" : { },
  "id_str" : "676703741979058176",
  "in_reply_to_user_id" : 14953378,
  "text" : "@spektrum cool, danke :)",
  "id" : 676703741979058176,
  "in_reply_to_status_id" : 676703547287863296,
  "created_at" : "2015-12-15 10:01:59 +0000",
  "in_reply_to_screen_name" : "spektrum",
  "in_reply_to_user_id_str" : "14953378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spektrum",
      "screen_name" : "spektrum",
      "indices" : [ 0, 9 ],
      "id_str" : "14953378",
      "id" : 14953378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676684591265136641",
  "geo" : { },
  "id_str" : "676702276006895616",
  "in_reply_to_user_id" : 14953378,
  "text" : "@spektrum \uD83D\uDE4B",
  "id" : 676702276006895616,
  "in_reply_to_status_id" : 676684591265136641,
  "created_at" : "2015-12-15 09:56:09 +0000",
  "in_reply_to_screen_name" : "spektrum",
  "in_reply_to_user_id_str" : "14953378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676688052530618368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222610843177, 8.627630119074015 ]
  },
  "id_str" : "676690797568348161",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna ja, lief am Ende alles gut bei mir. Ich dr\u00FCck die Daumen weiterhin.",
  "id" : 676690797568348161,
  "in_reply_to_status_id" : 676688052530618368,
  "created_at" : "2015-12-15 09:10:33 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676449171294060544",
  "geo" : { },
  "id_str" : "676684622311399424",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia too bad that didn\u2019t fly! (I\u2019ll show myself out)",
  "id" : 676684622311399424,
  "in_reply_to_status_id" : 676449171294060544,
  "created_at" : "2015-12-15 08:46:00 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/KnElgARanM",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=lG2J9ny9r2A",
      "display_url" : "youtube.com\/watch?v=lG2J9n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676684409253330944",
  "text" : "I have a book for writing down who I meet and where I'm going to. But my home is nowhere without you. https:\/\/t.co\/KnElgARanM",
  "id" : 676684409253330944,
  "created_at" : "2015-12-15 08:45:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676557280473718784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11315192892557, 8.752874998492526 ]
  },
  "id_str" : "676557575865913344",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna ich wei\u00DF wie scary das sein kann. **hugsifwanted**",
  "id" : 676557575865913344,
  "in_reply_to_status_id" : 676557280473718784,
  "created_at" : "2015-12-15 00:21:10 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676545722813177856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11386013383191, 8.753644534004415 ]
  },
  "id_str" : "676554232242245636",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna all the best!",
  "id" : 676554232242245636,
  "in_reply_to_status_id" : 676545722813177856,
  "created_at" : "2015-12-15 00:07:53 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676497205088374784",
  "geo" : { },
  "id_str" : "676522206269186048",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC \uD83D\uDE0D",
  "id" : 676522206269186048,
  "in_reply_to_status_id" : 676497205088374784,
  "created_at" : "2015-12-14 22:00:37 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/B3m5AgwB2l",
      "expanded_url" : "https:\/\/twitter.com\/anitaleirfall\/status\/676397597377077249",
      "display_url" : "twitter.com\/anitaleirfall\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406660571829, 8.753411906536334 ]
  },
  "id_str" : "676513908740460545",
  "text" : "Makes you wonder how Darwin, Gould, Feynman et al pulled it off to have brilliant _and_ accessible ideas\u2026 https:\/\/t.co\/B3m5AgwB2l",
  "id" : 676513908740460545,
  "created_at" : "2015-12-14 21:27:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/aYRDwhfbu2",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/12\/13\/opinion\/exploring-the-world-on-foot.html",
      "display_url" : "nytimes.com\/2015\/12\/13\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676421760951132160",
  "text" : "Unfortunately I guess it\u2019s hard to get sabbaticals that long: Exploring the World on Foot https:\/\/t.co\/aYRDwhfbu2",
  "id" : 676421760951132160,
  "created_at" : "2015-12-14 15:21:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676368445420752896",
  "geo" : { },
  "id_str" : "676368655173726209",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima you know you\u2019ve fucked up if that happens to you :3",
  "id" : 676368655173726209,
  "in_reply_to_status_id" : 676368445420752896,
  "created_at" : "2015-12-14 11:50:28 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676346420094480384",
  "text" : "Bioinformagicians: What\u2019s your go-to solution for assembly gap close if you have Illumina &amp; PacBio data?",
  "id" : 676346420094480384,
  "created_at" : "2015-12-14 10:22:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 50, 56 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/pzLlVp3Sqm",
      "expanded_url" : "http:\/\/www.newyorker.com\/books\/page-turner\/a-history-of-punctuation-for-the-internet-age?mbid=social_facebook&utm_content=buffer7eeee&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "newyorker.com\/books\/page-tur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676342387770265600",
  "text" : "A History of Punctuation for the Internet Age \/cc @Lobot https:\/\/t.co\/pzLlVp3Sqm",
  "id" : 676342387770265600,
  "created_at" : "2015-12-14 10:06:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676337013914644480",
  "geo" : { },
  "id_str" : "676338473897484289",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z I see, I meant that there is no \u201Estandard\u201C for how to interpret the emoji, so each user translates in his\/her own mind differently",
  "id" : 676338473897484289,
  "in_reply_to_status_id" : 676337013914644480,
  "created_at" : "2015-12-14 09:50:32 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Goldman Group",
      "screen_name" : "EBIgoldman",
      "indices" : [ 3, 14 ],
      "id_str" : "897921452",
      "id" : 897921452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676330899932381185",
  "text" : "RT @EBIgoldman: Is ML phylogeny inference consistent when there are gaps in your alignment? That'll be a 'YES'. From our group: https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/cZSS9elwj8",
        "expanded_url" : "http:\/\/sysbio.oxfordjournals.org\/content\/early\/2015\/11\/28\/sysbio.syv089.abstract",
        "display_url" : "sysbio.oxfordjournals.org\/content\/early\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "676322116598394880",
    "text" : "Is ML phylogeny inference consistent when there are gaps in your alignment? That'll be a 'YES'. From our group: https:\/\/t.co\/cZSS9elwj8",
    "id" : 676322116598394880,
    "created_at" : "2015-12-14 08:45:32 +0000",
    "user" : {
      "name" : "Goldman Group",
      "screen_name" : "EBIgoldman",
      "protected" : false,
      "id_str" : "897921452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2751048547\/0383e4f95dd1f0579f78512d4d35fc7e_normal.jpeg",
      "id" : 897921452,
      "verified" : false
    }
  },
  "id" : 676330899932381185,
  "created_at" : "2015-12-14 09:20:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676326701186453504",
  "geo" : { },
  "id_str" : "676328295181459456",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z I guess you\u2019d need a separate dictionary for each \u201Espeaker\u201C, but I\u2019m sure Wittgenstein would have something to say about this ;)",
  "id" : 676328295181459456,
  "in_reply_to_status_id" : 676326701186453504,
  "created_at" : "2015-12-14 09:10:05 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676327792582225920",
  "geo" : { },
  "id_str" : "676327868050317312",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek \uD83D\uDC4D",
  "id" : 676327868050317312,
  "in_reply_to_status_id" : 676327792582225920,
  "created_at" : "2015-12-14 09:08:23 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/h1khPxP1l5",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/l41lIioP4RFRmIVB6\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/l41lIioP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676325346887802880",
  "text" : "yet another allegory for doing a PhD https:\/\/t.co\/h1khPxP1l5",
  "id" : 676325346887802880,
  "created_at" : "2015-12-14 08:58:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676319717917777920",
  "geo" : { },
  "id_str" : "676324663052603392",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z I think it\u2019s even a problem when people share the same larger cultural background. But definitely it\u2019s mostly crypt analysis. :)",
  "id" : 676324663052603392,
  "in_reply_to_status_id" : 676319717917777920,
  "created_at" : "2015-12-14 08:55:39 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 3, 10 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "John Logsdon",
      "screen_name" : "johnlogsdon",
      "indices" : [ 33, 45 ],
      "id_str" : "18414364",
      "id" : 18414364
    }, {
      "name" : "Julie Dunning Hotopp",
      "screen_name" : "DunningHotopp",
      "indices" : [ 46, 60 ],
      "id_str" : "2373958050",
      "id" : 2373958050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/SSx6kbsdXP",
      "expanded_url" : "http:\/\/dx.doi.org\/10.1101\/033464",
      "display_url" : "dx.doi.org\/10.1101\/033464"
    } ]
  },
  "geo" : { },
  "id_str" : "676314759747272704",
  "text" : "RT @sujaik: Hope we've addressed @johnlogsdon @DunningHotopp concerns about too much cleaning in revised https:\/\/t.co\/SSx6kbsdXP Critiques \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Logsdon",
        "screen_name" : "johnlogsdon",
        "indices" : [ 21, 33 ],
        "id_str" : "18414364",
        "id" : 18414364
      }, {
        "name" : "Julie Dunning Hotopp",
        "screen_name" : "DunningHotopp",
        "indices" : [ 34, 48 ],
        "id_str" : "2373958050",
        "id" : 2373958050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/SSx6kbsdXP",
        "expanded_url" : "http:\/\/dx.doi.org\/10.1101\/033464",
        "display_url" : "dx.doi.org\/10.1101\/033464"
      } ]
    },
    "in_reply_to_status_id_str" : "676205826642718720",
    "geo" : { },
    "id_str" : "676207292690391040",
    "in_reply_to_user_id" : 33651124,
    "text" : "Hope we've addressed @johnlogsdon @DunningHotopp concerns about too much cleaning in revised https:\/\/t.co\/SSx6kbsdXP Critiques welcome",
    "id" : 676207292690391040,
    "in_reply_to_status_id" : 676205826642718720,
    "created_at" : "2015-12-14 01:09:16 +0000",
    "in_reply_to_screen_name" : "sujaik",
    "in_reply_to_user_id_str" : "33651124",
    "user" : {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "protected" : false,
      "id_str" : "33651124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499041232765460480\/J2nyoivC_normal.jpeg",
      "id" : 33651124,
      "verified" : false
    }
  },
  "id" : 676314759747272704,
  "created_at" : "2015-12-14 08:16:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676289965450330112",
  "geo" : { },
  "id_str" : "676313713889136641",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z I think the biggest issue is the \u2018dialects\u2019 of emoji. The same meaning for characters is only inferred inside small peer groups.",
  "id" : 676313713889136641,
  "in_reply_to_status_id" : 676289965450330112,
  "created_at" : "2015-12-14 08:12:09 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676166806176931840",
  "geo" : { },
  "id_str" : "676166852754735104",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen vielen dank &lt;3",
  "id" : 676166852754735104,
  "in_reply_to_status_id" : 676166806176931840,
  "created_at" : "2015-12-13 22:28:34 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676161030351945729",
  "geo" : { },
  "id_str" : "676161313811341312",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen Ist das \u00E4hnlich zu second-hand smoking?",
  "id" : 676161313811341312,
  "in_reply_to_status_id" : 676161030351945729,
  "created_at" : "2015-12-13 22:06:34 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676160319375413253",
  "text" : "\u00ABLet me quickly set up docker on this machine\u00BB I thought, not thinking about the download speed in my apartment. Read 2 books already\u2026",
  "id" : 676160319375413253,
  "created_at" : "2015-12-13 22:02:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/5KYyqWOwel",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/robandstephanielevy\/4668030838\/",
      "display_url" : "flickr.com\/photos\/robands\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676133991678889989",
  "text" : "what you find when you search the wikipedia for time management https:\/\/t.co\/5KYyqWOwel",
  "id" : 676133991678889989,
  "created_at" : "2015-12-13 20:18:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Surya Saha",
      "screen_name" : "SahaSurya",
      "indices" : [ 3, 13 ],
      "id_str" : "621835593",
      "id" : 621835593
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fungal15",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/NFdIbmRpKi",
      "expanded_url" : "http:\/\/bit.ly\/1O2NBap",
      "display_url" : "bit.ly\/1O2NBap"
    } ]
  },
  "geo" : { },
  "id_str" : "676132765541277696",
  "text" : "RT @SahaSurya: Fungal Genomics Meets Social Media: Highlights of the 28th Fungal Genetics Conference https:\/\/t.co\/NFdIbmRpKi #Fungal15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Fungal15",
        "indices" : [ 110, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/NFdIbmRpKi",
        "expanded_url" : "http:\/\/bit.ly\/1O2NBap",
        "display_url" : "bit.ly\/1O2NBap"
      } ]
    },
    "geo" : { },
    "id_str" : "676069097193512961",
    "text" : "Fungal Genomics Meets Social Media: Highlights of the 28th Fungal Genetics Conference https:\/\/t.co\/NFdIbmRpKi #Fungal15",
    "id" : 676069097193512961,
    "created_at" : "2015-12-13 16:00:08 +0000",
    "user" : {
      "name" : "Surya Saha",
      "screen_name" : "SahaSurya",
      "protected" : false,
      "id_str" : "621835593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2373458683\/geyyrbspp0bgqxx2tc56_normal.jpeg",
      "id" : 621835593,
      "verified" : false
    }
  },
  "id" : 676132765541277696,
  "created_at" : "2015-12-13 20:13:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/62RYGscn4e",
      "expanded_url" : "http:\/\/mradilbert.tumblr.com\/",
      "display_url" : "mradilbert.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "676128040452300802",
  "text" : "Men\u2019s Rights Activist Dilbert https:\/\/t.co\/62RYGscn4e",
  "id" : 676128040452300802,
  "created_at" : "2015-12-13 19:54:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/cu3lWZu36p",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/sf\/national\/2015\/12\/05\/after-a-mass-shooting-a-survivors-life\/",
      "display_url" : "washingtonpost.com\/sf\/national\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676124453248630785",
  "text" : "after a mass shooting: a survivor\u2019s life https:\/\/t.co\/cu3lWZu36p",
  "id" : 676124453248630785,
  "created_at" : "2015-12-13 19:40:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/0jEPWDzQd7",
      "expanded_url" : "http:\/\/www.theguardian.com\/environment\/georgemonbiot\/2015\/dec\/12\/paris-climate-deal-governments-fossil-fuels?CMP=share_btn_fb",
      "display_url" : "theguardian.com\/environment\/ge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676099404697350144",
  "text" : "The climate talks: \u00ABThe talks in Paris are the best there have ever been. And that is a terrible indictment.\u00BB https:\/\/t.co\/0jEPWDzQd7",
  "id" : 676099404697350144,
  "created_at" : "2015-12-13 18:00:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 31, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/wTHx3ou3IW",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/_PbqQ8hwkI\/",
      "display_url" : "instagram.com\/p\/_PbqQ8hwkI\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.366851214, 4.912454588 ]
  },
  "id_str" : "676098049756803073",
  "text" : "bacterial and fungal diversity #latergram @ Micropia https:\/\/t.co\/wTHx3ou3IW",
  "id" : 676098049756803073,
  "created_at" : "2015-12-13 17:55:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10310504697374, 8.691779615706057 ]
  },
  "id_str" : "676092732021018625",
  "text" : "Somehow my iPhone managed to take in yesterday\u2019s Latke smell. Now I can\u2019t tweet without getting hungry.",
  "id" : 676092732021018625,
  "created_at" : "2015-12-13 17:34:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/r8odDRnSk6",
      "expanded_url" : "https:\/\/twitter.com\/StevenSalzberg1\/status\/676080837746696192",
      "display_url" : "twitter.com\/StevenSalzberg\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10302503446752, 8.690823543760562 ]
  },
  "id_str" : "676083174661844992",
  "text" : "\u00ABReading this manuscript makes me question Oswald\u2019s intellect\u00BB Peer review, it just works\u2026 https:\/\/t.co\/r8odDRnSk6",
  "id" : 676083174661844992,
  "created_at" : "2015-12-13 16:56:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675997807728312320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11394558438056, 8.753453069835768 ]
  },
  "id_str" : "675997942327693312",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe yes, it\u2019s all neutral technology that can be used for good and for evil!",
  "id" : 675997942327693312,
  "in_reply_to_status_id" : 675997807728312320,
  "created_at" : "2015-12-13 11:17:23 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/l0mf5PfhQv",
      "expanded_url" : "https:\/\/twitter.com\/somebadideas\/status\/675818295019372545",
      "display_url" : "twitter.com\/somebadideas\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11133021034168, 8.751652393846099 ]
  },
  "id_str" : "675997343603380224",
  "text" : "Sometimes all that stops a bad guy with a gun is a good guy with a dildo and a fart. https:\/\/t.co\/l0mf5PfhQv",
  "id" : 675997343603380224,
  "created_at" : "2015-12-13 11:15:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/aF8IqxEuBM",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/_NB0iwBwjs\/",
      "display_url" : "instagram.com\/p\/_NB0iwBwjs\/"
    } ]
  },
  "geo" : { },
  "id_str" : "675759753436491776",
  "text" : "Latke Layer 8 https:\/\/t.co\/aF8IqxEuBM",
  "id" : 675759753436491776,
  "created_at" : "2015-12-12 19:30:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/gtFpGFN04I",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/_M-nYkBwsQ\/",
      "display_url" : "instagram.com\/p\/_M-nYkBwsQ\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.366851214, 4.912454588 ]
  },
  "id_str" : "675752704749215744",
  "text" : "Leafcutter ants #latergram @ Micropia https:\/\/t.co\/gtFpGFN04I",
  "id" : 675752704749215744,
  "created_at" : "2015-12-12 19:02:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/Wbd14HQKsT",
      "expanded_url" : "https:\/\/twitter.com\/DanGraur\/status\/674728111859101697",
      "display_url" : "twitter.com\/DanGraur\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "675742492092944385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09920800806602, 8.691975742301052 ]
  },
  "id_str" : "675745151608864769",
  "in_reply_to_user_id" : 14286491,
  "text" : "And remember to know the difference between \u05D7 and \u05EA if you want to wish Happy Hanukkah. https:\/\/t.co\/Wbd14HQKsT",
  "id" : 675745151608864769,
  "in_reply_to_status_id" : 675742492092944385,
  "created_at" : "2015-12-12 18:32:53 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/oI9Vcs9kxi",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/_M5-LchwiE\/",
      "display_url" : "instagram.com\/p\/_M5-LchwiE\/"
    } ]
  },
  "geo" : { },
  "id_str" : "675742492092944385",
  "text" : "Last week I joked about doing Chai Latkes, today I say \u05D7\u05D2 \u05D7\u05E0\u05D5\u05DB\u05D4 \u05E9\u05DE\u05D7! https:\/\/t.co\/oI9Vcs9kxi",
  "id" : 675742492092944385,
  "created_at" : "2015-12-12 18:22:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens-Wolfhard",
      "screen_name" : "Drahflow",
      "indices" : [ 0, 9 ],
      "id_str" : "92904426",
      "id" : 92904426
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 20, 29 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675669598004486144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10750368707823, 8.771663093947593 ]
  },
  "id_str" : "675670361384570880",
  "in_reply_to_user_id" : 92904426,
  "text" : "@Drahflow @Senficon @thorgnyr actually CAT0 was ran over by a car, so that\u2019s somewhat fitting :\/",
  "id" : 675670361384570880,
  "in_reply_to_status_id" : 675669598004486144,
  "created_at" : "2015-12-12 13:35:42 +0000",
  "in_reply_to_screen_name" : "Drahflow",
  "in_reply_to_user_id_str" : "92904426",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675667613121454080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10991347486422, 8.759564572374222 ]
  },
  "id_str" : "675668255156117505",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @Senficon couldn\u2019t bring myself to not call the first cat CAT0. :p",
  "id" : 675668255156117505,
  "in_reply_to_status_id" : 675667613121454080,
  "created_at" : "2015-12-12 13:27:19 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 53, 62 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675666825963831297",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11138480470279, 8.756397674271637 ]
  },
  "id_str" : "675667393520226304",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr some wanted to call our cats CAT5 and CAT6 @Senficon :D",
  "id" : 675667393520226304,
  "in_reply_to_status_id" : 675666825963831297,
  "created_at" : "2015-12-12 13:23:54 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675665764746182656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11396031546605, 8.753456595714729 ]
  },
  "id_str" : "675666595935571968",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr unless she then drags away the cables to your neighbors.",
  "id" : 675666595935571968,
  "in_reply_to_status_id" : 675665764746182656,
  "created_at" : "2015-12-12 13:20:44 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675664003302072320",
  "geo" : { },
  "id_str" : "675665437955334144",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr now teach her to do the same using cables!",
  "id" : 675665437955334144,
  "in_reply_to_status_id" : 675664003302072320,
  "created_at" : "2015-12-12 13:16:08 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/ORKwgM370e",
      "expanded_url" : "http:\/\/strifeblog.org\/2015\/12\/11\/the-strategy-of-star-wars-the-rebel-alliance-as-a-maoist-insurgency\/",
      "display_url" : "strifeblog.org\/2015\/12\/11\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675473342233763840",
  "text" : "The Strategy of Star Wars: The Rebel Alliance as a Maoist\u00A0Insurgency https:\/\/t.co\/ORKwgM370e",
  "id" : 675473342233763840,
  "created_at" : "2015-12-12 00:32:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/O82D4SD3tL",
      "expanded_url" : "http:\/\/wmbriggs.com\/post\/11862\/",
      "display_url" : "wmbriggs.com\/post\/11862\/"
    }, {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/yE1qf3h7hM",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/675467745715187712",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "675467745715187712",
  "geo" : { },
  "id_str" : "675469811506393088",
  "in_reply_to_user_id" : 14286491,
  "text" : "Though for the confidence intervals you might wanna read this if you are a frequentist. https:\/\/t.co\/O82D4SD3tL https:\/\/t.co\/yE1qf3h7hM",
  "id" : 675469811506393088,
  "in_reply_to_status_id" : 675467745715187712,
  "created_at" : "2015-12-12 00:18:47 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/LeTIKjpHcQ",
      "expanded_url" : "http:\/\/www.bio.bris.ac.uk\/research\/behavior\/R_scripts\/Nakagawa%20Cuthill%20BR%202007.pdf",
      "display_url" : "bio.bris.ac.uk\/research\/behav\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675467745715187712",
  "text" : "good read: \u00ABEffect size, confidence interval &amp; statistical significance: a practical guide.\u00BB [sry, lost the via] https:\/\/t.co\/LeTIKjpHcQ",
  "id" : 675467745715187712,
  "created_at" : "2015-12-12 00:10:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/l3ByGU8vBu",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/12\/10\/world\/africa\/they-helped-erase-ebola-in-liberia-now-liberia-is-erasing-them.html",
      "display_url" : "nytimes.com\/2015\/12\/10\/wor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675460198794964992",
  "text" : "They Helped Erase Ebola in Liberia. Now Liberia Is Erasing Them. https:\/\/t.co\/l3ByGU8vBu",
  "id" : 675460198794964992,
  "created_at" : "2015-12-11 23:40:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann Loraine",
      "screen_name" : "aloraine205",
      "indices" : [ 3, 15 ],
      "id_str" : "114142293",
      "id" : 114142293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/8fusgekJub",
      "expanded_url" : "http:\/\/fw.to\/UYr40IO",
      "display_url" : "fw.to\/UYr40IO"
    } ]
  },
  "geo" : { },
  "id_str" : "675456721075204096",
  "text" : "RT @aloraine205: An Iowa farmer depends on pesticides. His son asks: Is there a better way? https:\/\/t.co\/8fusgekJub",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/8fusgekJub",
        "expanded_url" : "http:\/\/fw.to\/UYr40IO",
        "display_url" : "fw.to\/UYr40IO"
      } ]
    },
    "geo" : { },
    "id_str" : "675118641159999489",
    "text" : "An Iowa farmer depends on pesticides. His son asks: Is there a better way? https:\/\/t.co\/8fusgekJub",
    "id" : 675118641159999489,
    "created_at" : "2015-12-11 01:03:21 +0000",
    "user" : {
      "name" : "Ann Loraine",
      "screen_name" : "aloraine205",
      "protected" : false,
      "id_str" : "114142293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2525523774\/olxn00n8niqsbbuq2ful_normal.jpeg",
      "id" : 114142293,
      "verified" : false
    }
  },
  "id" : 675456721075204096,
  "created_at" : "2015-12-11 23:26:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Hills",
      "screen_name" : "rocza",
      "indices" : [ 3, 9 ],
      "id_str" : "14075844",
      "id" : 14075844
    }, {
      "name" : "AAAS",
      "screen_name" : "aaas",
      "indices" : [ 98, 103 ],
      "id_str" : "17292623",
      "id" : 17292623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675452392641593344",
  "text" : "RT @rocza: I'm not sure if there can be a clearer \"fuck you &amp; your modern safety ideals\" than @AAAS electing Harran as a fellow https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AAAS",
        "screen_name" : "aaas",
        "indices" : [ 87, 92 ],
        "id_str" : "17292623",
        "id" : 17292623
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/WHsHqJkgn5",
        "expanded_url" : "http:\/\/cenblog.org\/the-safety-zone\/2015\/12\/patrick-harran-elected-as-a-aaas-fellow\/",
        "display_url" : "cenblog.org\/the-safety-zon\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "675318384918183936",
    "text" : "I'm not sure if there can be a clearer \"fuck you &amp; your modern safety ideals\" than @AAAS electing Harran as a fellow https:\/\/t.co\/WHsHqJkgn5",
    "id" : 675318384918183936,
    "created_at" : "2015-12-11 14:17:04 +0000",
    "user" : {
      "name" : "Kelly Hills",
      "screen_name" : "rocza",
      "protected" : false,
      "id_str" : "14075844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788549856528859136\/dco0kme__normal.jpg",
      "id" : 14075844,
      "verified" : false
    }
  },
  "id" : 675452392641593344,
  "created_at" : "2015-12-11 23:09:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/9vFdgttwKd",
      "expanded_url" : "https:\/\/twitter.com\/alicetruong\/status\/675362168104095744",
      "display_url" : "twitter.com\/alicetruong\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11379176481645, 8.753737613541931 ]
  },
  "id_str" : "675425866294382592",
  "text" : "And trust me: it\u2019s so much more comfortable than using your phone with your nose. https:\/\/t.co\/9vFdgttwKd",
  "id" : 675425866294382592,
  "created_at" : "2015-12-11 21:24:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mental Floss",
      "screen_name" : "mental_floss",
      "indices" : [ 3, 16 ],
      "id_str" : "20065936",
      "id" : 20065936
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mental_floss\/status\/674965309002932224\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/zeCJu5tTWo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV31X0bU4AAjgex.png",
      "id_str" : "674965308734496768",
      "id" : 674965308734496768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV31X0bU4AAjgex.png",
      "sizes" : [ {
        "h" : 430,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/zeCJu5tTWo"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/71EkbbIsU9",
      "expanded_url" : "http:\/\/bit.ly\/1QgDtLd",
      "display_url" : "bit.ly\/1QgDtLd"
    } ]
  },
  "geo" : { },
  "id_str" : "675425099068145665",
  "text" : "RT @mental_floss: The Washington Post Style Guide Now Accepts Singular \u2018They\u2019 \u2014 https:\/\/t.co\/71EkbbIsU9 https:\/\/t.co\/zeCJu5tTWo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mental_floss\/status\/674965309002932224\/photo\/1",
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/zeCJu5tTWo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CV31X0bU4AAjgex.png",
        "id_str" : "674965308734496768",
        "id" : 674965308734496768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV31X0bU4AAjgex.png",
        "sizes" : [ {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/zeCJu5tTWo"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/71EkbbIsU9",
        "expanded_url" : "http:\/\/bit.ly\/1QgDtLd",
        "display_url" : "bit.ly\/1QgDtLd"
      } ]
    },
    "geo" : { },
    "id_str" : "674965309002932224",
    "text" : "The Washington Post Style Guide Now Accepts Singular \u2018They\u2019 \u2014 https:\/\/t.co\/71EkbbIsU9 https:\/\/t.co\/zeCJu5tTWo",
    "id" : 674965309002932224,
    "created_at" : "2015-12-10 14:54:04 +0000",
    "user" : {
      "name" : "Mental Floss",
      "screen_name" : "mental_floss",
      "protected" : false,
      "id_str" : "20065936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/857998780410548224\/zfrtpr2E_normal.jpg",
      "id" : 20065936,
      "verified" : true
    }
  },
  "id" : 675425099068145665,
  "created_at" : "2015-12-11 21:21:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/3XcCcJHpkp",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/_KnT4sBwnH\/",
      "display_url" : "instagram.com\/p\/_KnT4sBwnH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "675419981341958147",
  "text" : "Look, it's 23andMe https:\/\/t.co\/3XcCcJHpkp",
  "id" : 675419981341958147,
  "created_at" : "2015-12-11 21:00:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Urban",
      "screen_name" : "waitbutwhy",
      "indices" : [ 3, 14 ],
      "id_str" : "1282121312",
      "id" : 1282121312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/GQeN53ukth",
      "expanded_url" : "http:\/\/waitbutwhy.com\/2015\/12\/the-tail-end.html",
      "display_url" : "waitbutwhy.com\/2015\/12\/the-ta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675404039388069888",
  "text" : "RT @waitbutwhy: You may be 30% of the way thru life but 90% of the way thru many of your best relationships. https:\/\/t.co\/GQeN53ukth https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/waitbutwhy\/status\/675348625116037121\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/3IYKWQL407",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CV9R_uNU8AEyW37.png",
        "id_str" : "675348624306401281",
        "id" : 675348624306401281,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV9R_uNU8AEyW37.png",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 676,
          "resize" : "fit",
          "w" : 1353
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 676,
          "resize" : "fit",
          "w" : 1353
        } ],
        "display_url" : "pic.twitter.com\/3IYKWQL407"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/GQeN53ukth",
        "expanded_url" : "http:\/\/waitbutwhy.com\/2015\/12\/the-tail-end.html",
        "display_url" : "waitbutwhy.com\/2015\/12\/the-ta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "675348625116037121",
    "text" : "You may be 30% of the way thru life but 90% of the way thru many of your best relationships. https:\/\/t.co\/GQeN53ukth https:\/\/t.co\/3IYKWQL407",
    "id" : 675348625116037121,
    "created_at" : "2015-12-11 16:17:14 +0000",
    "user" : {
      "name" : "Tim Urban",
      "screen_name" : "waitbutwhy",
      "protected" : false,
      "id_str" : "1282121312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000096549990\/2b5b8a614e16b1527ebb75e1a7266d85_normal.jpeg",
      "id" : 1282121312,
      "verified" : true
    }
  },
  "id" : 675404039388069888,
  "created_at" : "2015-12-11 19:57:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675338646820691969",
  "geo" : { },
  "id_str" : "675339937378643972",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer at first you try to turn it into the \u201Ehypothesis of gaps\u201C ;)",
  "id" : 675339937378643972,
  "in_reply_to_status_id" : 675338646820691969,
  "created_at" : "2015-12-11 15:42:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "indices" : [ 0, 15 ],
      "id_str" : "1040758742",
      "id" : 1040758742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675338044489207808",
  "geo" : { },
  "id_str" : "675338167210364928",
  "in_reply_to_user_id" : 1040758742,
  "text" : "@BioDataGanache but doing one-liners in it just sucks ;)",
  "id" : 675338167210364928,
  "in_reply_to_status_id" : 675338044489207808,
  "created_at" : "2015-12-11 15:35:40 +0000",
  "in_reply_to_screen_name" : "BioDataGanache",
  "in_reply_to_user_id_str" : "1040758742",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "indices" : [ 0, 15 ],
      "id_str" : "1040758742",
      "id" : 1040758742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675323607854157824",
  "geo" : { },
  "id_str" : "675337678246703105",
  "in_reply_to_user_id" : 1040758742,
  "text" : "@BioDataGanache have fun with Python!",
  "id" : 675337678246703105,
  "in_reply_to_status_id" : 675323607854157824,
  "created_at" : "2015-12-11 15:33:44 +0000",
  "in_reply_to_screen_name" : "BioDataGanache",
  "in_reply_to_user_id_str" : "1040758742",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/VPyTwjYsaA",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/675295102911258624",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229092010921, 8.627512625725197 ]
  },
  "id_str" : "675334522200842240",
  "text" : "And I thought it was only me who sent some nice theories out to die today \uD83D\uDE14\uD83D\uDE22 https:\/\/t.co\/VPyTwjYsaA",
  "id" : 675334522200842240,
  "created_at" : "2015-12-11 15:21:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675278156052361218",
  "geo" : { },
  "id_str" : "675316288349163521",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z stay strong!",
  "id" : 675316288349163521,
  "in_reply_to_status_id" : 675278156052361218,
  "created_at" : "2015-12-11 14:08:44 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ocean Conservancy",
      "screen_name" : "OurOcean",
      "indices" : [ 3, 12 ],
      "id_str" : "71019945",
      "id" : 71019945
    }, {
      "name" : "Lost At E Minor",
      "screen_name" : "lostateminor",
      "indices" : [ 116, 129 ],
      "id_str" : "21684189",
      "id" : 21684189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/obLDAMMyhS",
      "expanded_url" : "http:\/\/ocean.ly\/1LxZQDV",
      "display_url" : "ocean.ly\/1LxZQDV"
    } ]
  },
  "geo" : { },
  "id_str" : "675297650732892160",
  "text" : "RT @OurOcean: See the rare and mysterious blue dragon found off the coast of Australia. https:\/\/t.co\/obLDAMMyhS via @lostateminor https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lost At E Minor",
        "screen_name" : "lostateminor",
        "indices" : [ 102, 115 ],
        "id_str" : "21684189",
        "id" : 21684189
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OurOcean\/status\/674385823379386368\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/SJWB5h7grk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVvmVUBU8AEWT1h.jpg",
        "id_str" : "674385823047938049",
        "id" : 674385823047938049,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVvmVUBU8AEWT1h.jpg",
        "sizes" : [ {
          "h" : 288,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 504
        } ],
        "display_url" : "pic.twitter.com\/SJWB5h7grk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/obLDAMMyhS",
        "expanded_url" : "http:\/\/ocean.ly\/1LxZQDV",
        "display_url" : "ocean.ly\/1LxZQDV"
      } ]
    },
    "geo" : { },
    "id_str" : "674385823379386368",
    "text" : "See the rare and mysterious blue dragon found off the coast of Australia. https:\/\/t.co\/obLDAMMyhS via @lostateminor https:\/\/t.co\/SJWB5h7grk",
    "id" : 674385823379386368,
    "created_at" : "2015-12-09 00:31:24 +0000",
    "user" : {
      "name" : "Ocean Conservancy",
      "screen_name" : "OurOcean",
      "protected" : false,
      "id_str" : "71019945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768901284124585984\/TJ_qyHRm_normal.jpg",
      "id" : 71019945,
      "verified" : false
    }
  },
  "id" : 675297650732892160,
  "created_at" : "2015-12-11 12:54:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/VVVaoONlKU",
      "expanded_url" : "http:\/\/www.wired.com\/2015\/06\/emojitrendy-slang-whole-new-language\/",
      "display_url" : "wired.com\/2015\/06\/emojit\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "675283167545188354",
  "geo" : { },
  "id_str" : "675285263124447232",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z also see https:\/\/t.co\/VVVaoONlKU",
  "id" : 675285263124447232,
  "in_reply_to_status_id" : 675283167545188354,
  "created_at" : "2015-12-11 12:05:27 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 10, 21 ],
      "id_str" : "201632630",
      "id" : 201632630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675274080233365504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233995459908, 8.627526682836086 ]
  },
  "id_str" : "675274308680359936",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @BPrainsack I think that\u2019s what I use somewhat as a synonym.",
  "id" : 675274308680359936,
  "in_reply_to_status_id" : 675274080233365504,
  "created_at" : "2015-12-11 11:21:55 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/4YiZhOJF8G",
      "expanded_url" : "http:\/\/www.demilked.com\/dynamic-action-photography-dogs-can-fly-claudio-piccoli\/",
      "display_url" : "demilked.com\/dynamic-action\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675265790535405570",
  "text" : "flying dogs https:\/\/t.co\/4YiZhOJF8G",
  "id" : 675265790535405570,
  "created_at" : "2015-12-11 10:48:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/tkyAt3zGed",
      "expanded_url" : "https:\/\/thescienceweb.wordpress.com\/2015\/12\/11\/consortium-partner-is-going-to-do-everything-you-do-only-worse\/",
      "display_url" : "thescienceweb.wordpress.com\/2015\/12\/11\/con\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675264409036570624",
  "text" : "\u00ABHonestly, why do funders force me to work with these people?\u00BB parts of academia in a nutshell https:\/\/t.co\/tkyAt3zGed",
  "id" : 675264409036570624,
  "created_at" : "2015-12-11 10:42:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675215906209988608",
  "geo" : { },
  "id_str" : "675237343226408960",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen den Spa\u00DF hatte ich mit der DB in M\u00FCnster regelm\u00E4ssig. Bevorzugt in den aus allen N\u00E4hten platzenden Rushhour Z\u00FCgen :D",
  "id" : 675237343226408960,
  "in_reply_to_status_id" : 675215906209988608,
  "created_at" : "2015-12-11 08:55:02 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/FvXOmOXW9f",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/5xaYLxI6riEuY\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/5xaYLxI6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675233995488174080",
  "text" : "today\u2019s first coffee https:\/\/t.co\/FvXOmOXW9f",
  "id" : 675233995488174080,
  "created_at" : "2015-12-11 08:41:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 20, 32 ],
      "id_str" : "208988759",
      "id" : 208988759
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 105, 121 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 123, 131 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675231475952918530",
  "text" : "RT @PhilippBayer: . @GigaScience posted the BGI Conf. Community Genomes talks on one helpful page; feat. @gedankenstuecke, @glyn_dk https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GigaScience",
        "screen_name" : "GigaScience",
        "indices" : [ 2, 14 ],
        "id_str" : "208988759",
        "id" : 208988759
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 87, 103 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Fiona Nielsen",
        "screen_name" : "glyn_dk",
        "indices" : [ 105, 113 ],
        "id_str" : "32340834",
        "id" : 32340834
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/1LIJ5A8FuK",
        "expanded_url" : "http:\/\/blogs.biomedcentral.com\/gigablog\/2015\/12\/10\/community-genomes-gigatv\/",
        "display_url" : "blogs.biomedcentral.com\/gigablog\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "675135974414897154",
    "text" : ". @GigaScience posted the BGI Conf. Community Genomes talks on one helpful page; feat. @gedankenstuecke, @glyn_dk https:\/\/t.co\/1LIJ5A8FuK",
    "id" : 675135974414897154,
    "created_at" : "2015-12-11 02:12:14 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 675231475952918530,
  "created_at" : "2015-12-11 08:31:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/JrbBDToSkL",
      "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/675059687734255616",
      "display_url" : "twitter.com\/Senficon\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140737229621, 8.753398469707465 ]
  },
  "id_str" : "675074474300035073",
  "text" : "Going deep into the content mines\u2026\uD83D\uDDE1\uD83D\uDEE1 https:\/\/t.co\/JrbBDToSkL",
  "id" : 675074474300035073,
  "created_at" : "2015-12-10 22:07:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675060291286253570",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.14087170832804, 8.706661770128372 ]
  },
  "id_str" : "675062501629960193",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon you know I\u2019m already rather old, don\u2019t you? \uD83D\uDE02",
  "id" : 675062501629960193,
  "in_reply_to_status_id" : 675060291286253570,
  "created_at" : "2015-12-10 21:20:17 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675059687734255616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.13096688159121, 8.688589745483837 ]
  },
  "id_str" : "675060146532442112",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon i\u2019d rather take your funding \uD83D\uDE09",
  "id" : 675060146532442112,
  "in_reply_to_status_id" : 675059687734255616,
  "created_at" : "2015-12-10 21:10:55 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scibucketlist",
      "indices" : [ 51, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675055838164295680",
  "text" : "Making sure \u2018closed science\u2019 finally goes extinct. #scibucketlist",
  "id" : 675055838164295680,
  "created_at" : "2015-12-10 20:53:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/dlOcDJnHN7",
      "expanded_url" : "https:\/\/twitter.com\/beaugunderson\/status\/675002574316040192",
      "display_url" : "twitter.com\/beaugunderson\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.13143039626967, 8.626088673883446 ]
  },
  "id_str" : "675049033140969473",
  "text" : "Oh, cmon! \uD83D\uDE22 https:\/\/t.co\/dlOcDJnHN7",
  "id" : 675049033140969473,
  "created_at" : "2015-12-10 20:26:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 15, 20 ],
      "id_str" : "773450",
      "id" : 773450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674953578084179968",
  "geo" : { },
  "id_str" : "674953725534994432",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima @klmr That wasn\u2019t even the best! :D",
  "id" : 674953725534994432,
  "in_reply_to_status_id" : 674953578084179968,
  "created_at" : "2015-12-10 14:08:02 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 54, 59 ],
      "id_str" : "773450",
      "id" : 773450
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/674950190323900417\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/bQ7czJnTzB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV3nnqsU8AAtbcj.png",
      "id_str" : "674950187836567552",
      "id" : 674950187836567552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV3nnqsU8AAtbcj.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 981
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 981
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 981
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/bQ7czJnTzB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/pkvMT66tWo",
      "expanded_url" : "http:\/\/guessthecorrelation.com\/",
      "display_url" : "guessthecorrelation.com"
    } ]
  },
  "geo" : { },
  "id_str" : "674950190323900417",
  "text" : "Guess the Correlation. A fun game for stats nerds. HT @klmr https:\/\/t.co\/pkvMT66tWo https:\/\/t.co\/bQ7czJnTzB",
  "id" : 674950190323900417,
  "created_at" : "2015-12-10 13:53:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 0, 11 ],
      "id_str" : "201632630",
      "id" : 201632630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GET2015",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/2tezj2SDtz",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/snpr\/pull\/222",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "674947344585121792",
  "geo" : { },
  "id_str" : "674949747334111232",
  "in_reply_to_user_id" : 201632630,
  "text" : "@BPrainsack also reminded me to take care of your comment during #GET2015 https:\/\/t.co\/2tezj2SDtz",
  "id" : 674949747334111232,
  "in_reply_to_status_id" : 674947344585121792,
  "created_at" : "2015-12-10 13:52:14 +0000",
  "in_reply_to_screen_name" : "BPrainsack",
  "in_reply_to_user_id_str" : "201632630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 0, 11 ],
      "id_str" : "201632630",
      "id" : 201632630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674947344585121792",
  "geo" : { },
  "id_str" : "674949390369431552",
  "in_reply_to_user_id" : 201632630,
  "text" : "@BPrainsack that\u2019s a good stance as far as I\u2019m concerned \uD83D\uDC4D\uD83D\uDE09",
  "id" : 674949390369431552,
  "in_reply_to_status_id" : 674947344585121792,
  "created_at" : "2015-12-10 13:50:49 +0000",
  "in_reply_to_screen_name" : "BPrainsack",
  "in_reply_to_user_id_str" : "201632630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 0, 11 ],
      "id_str" : "201632630",
      "id" : 201632630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674945098627575808",
  "geo" : { },
  "id_str" : "674946931077042176",
  "in_reply_to_user_id" : 201632630,
  "text" : "@BPrainsack I fully agree, for commercial stakeholders I also wouldn\u2019t use \u201Esharing\u201C, but then I\u2019m not too much into commerce in general ;)",
  "id" : 674946931077042176,
  "in_reply_to_status_id" : 674945098627575808,
  "created_at" : "2015-12-10 13:41:02 +0000",
  "in_reply_to_screen_name" : "BPrainsack",
  "in_reply_to_user_id_str" : "201632630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 0, 11 ],
      "id_str" : "201632630",
      "id" : 201632630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674933942135496704",
  "geo" : { },
  "id_str" : "674934114047418368",
  "in_reply_to_user_id" : 201632630,
  "text" : "@BPrainsack i thought about \u201Erelease\u201C but I\u2019m still not 100% convinced that \u201Esharing\u201C isn\u2019t the right wording in our context. :)",
  "id" : 674934114047418368,
  "in_reply_to_status_id" : 674933942135496704,
  "created_at" : "2015-12-10 12:50:07 +0000",
  "in_reply_to_screen_name" : "BPrainsack",
  "in_reply_to_user_id_str" : "201632630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674930560582746112",
  "text" : "\u00ABWhy doesn\u2019t he like the snowman figurine?!\u00BB \u2013 \u00ABEver since a snowman broke his heart a couple of years ago\u2026\u00BB",
  "id" : 674930560582746112,
  "created_at" : "2015-12-10 12:35:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674915989851516928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232947477254, 8.62752944766215 ]
  },
  "id_str" : "674917122758287360",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z thanks \uD83D\uDC96",
  "id" : 674917122758287360,
  "in_reply_to_status_id" : 674915989851516928,
  "created_at" : "2015-12-10 11:42:36 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/I4N1cUzckU",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/134858017287\/when-i-only-have-bad-data-for-the-lab-meeting",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/134858017\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674889562510991360",
  "text" : "looking forward to today\u2019s meeting\u2026 https:\/\/t.co\/I4N1cUzckU",
  "id" : 674889562510991360,
  "created_at" : "2015-12-10 09:53:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 3, 14 ],
      "id_str" : "201632630",
      "id" : 201632630
    }, {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 82, 92 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/1cZ2hMzsbq",
      "expanded_url" : "http:\/\/buff.ly\/1TBQFsf",
      "display_url" : "buff.ly\/1TBQFsf"
    } ]
  },
  "geo" : { },
  "id_str" : "674887002127515648",
  "text" : "RT @BPrainsack: Why we should stop talking about data \u201Csharing\u201D: My guest post on @DNADigest https:\/\/t.co\/1cZ2hMzsbq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DNAdigest.org",
        "screen_name" : "DNADigest",
        "indices" : [ 66, 76 ],
        "id_str" : "334912047",
        "id" : 334912047
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/1cZ2hMzsbq",
        "expanded_url" : "http:\/\/buff.ly\/1TBQFsf",
        "display_url" : "buff.ly\/1TBQFsf"
      } ]
    },
    "geo" : { },
    "id_str" : "674876745628180480",
    "text" : "Why we should stop talking about data \u201Csharing\u201D: My guest post on @DNADigest https:\/\/t.co\/1cZ2hMzsbq",
    "id" : 674876745628180480,
    "created_at" : "2015-12-10 09:02:09 +0000",
    "user" : {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "protected" : false,
      "id_str" : "201632630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927171665917890561\/w5htgqHc_normal.jpg",
      "id" : 201632630,
      "verified" : false
    }
  },
  "id" : 674887002127515648,
  "created_at" : "2015-12-10 09:42:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 0, 11 ],
      "id_str" : "201632630",
      "id" : 201632630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674876745628180480",
  "geo" : { },
  "id_str" : "674886978404540416",
  "in_reply_to_user_id" : 201632630,
  "text" : "@BPrainsack so how should we call it for openSNP? :)",
  "id" : 674886978404540416,
  "in_reply_to_status_id" : 674876745628180480,
  "created_at" : "2015-12-10 09:42:49 +0000",
  "in_reply_to_screen_name" : "BPrainsack",
  "in_reply_to_user_id_str" : "201632630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BauhiniaGenome",
      "screen_name" : "BauhiniaGenome",
      "indices" : [ 3, 18 ],
      "id_str" : "3589537993",
      "id" : 3589537993
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICG10",
      "indices" : [ 115, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674886239644946432",
  "text" : "RT @BauhiniaGenome: Our GigaScience colleagues cover our project in their blog on the Community Genomes session at #ICG10 https:\/\/t.co\/dCIJ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ICG10",
        "indices" : [ 95, 101 ]
      }, {
        "text" : "openscience",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/dCIJg7KeI4",
        "expanded_url" : "http:\/\/blogs.biomedcentral.com\/gigablog\/2015\/12\/10\/community-genomes-gigatv\/",
        "display_url" : "blogs.biomedcentral.com\/gigablog\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "674873707177844736",
    "text" : "Our GigaScience colleagues cover our project in their blog on the Community Genomes session at #ICG10 https:\/\/t.co\/dCIJg7KeI4 #openscience",
    "id" : 674873707177844736,
    "created_at" : "2015-12-10 08:50:04 +0000",
    "user" : {
      "name" : "BauhiniaGenome",
      "screen_name" : "BauhiniaGenome",
      "protected" : false,
      "id_str" : "3589537993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657829089554911232\/JdV4jgzR_normal.png",
      "id" : 3589537993,
      "verified" : false
    }
  },
  "id" : 674886239644946432,
  "created_at" : "2015-12-10 09:39:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "OBF News",
      "screen_name" : "obf_news",
      "indices" : [ 11, 20 ],
      "id_str" : "20624794",
      "id" : 20624794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674857772106797056",
  "geo" : { },
  "id_str" : "674867547469193216",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe @obf_news wow, I should have waited, I did the paper version right after #bosc2015 :D",
  "id" : 674867547469193216,
  "in_reply_to_status_id" : 674857772106797056,
  "created_at" : "2015-12-10 08:25:36 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674719512361623552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140733651097, 8.753395858089892 ]
  },
  "id_str" : "674727095780704258",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC you might also just stay with ramen. So at least there is some nostalgia to fill you. \uD83D\uDE09",
  "id" : 674727095780704258,
  "in_reply_to_status_id" : 674719512361623552,
  "created_at" : "2015-12-09 23:07:30 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674687895861637120",
  "geo" : { },
  "id_str" : "674718335486042112",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC still waiting for the avocado\u2026 \uD83D\uDE22",
  "id" : 674718335486042112,
  "in_reply_to_status_id" : 674687895861637120,
  "created_at" : "2015-12-09 22:32:41 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674683160207208452",
  "geo" : { },
  "id_str" : "674687340707717120",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC sorry for being so unspecific before :)",
  "id" : 674687340707717120,
  "in_reply_to_status_id" : 674683160207208452,
  "created_at" : "2015-12-09 20:29:31 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674672863287316480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407313717462, 8.753391211899356 ]
  },
  "id_str" : "674677528330637312",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC that\u2019s what I meant. For me those new ones came with the last update for iOS.",
  "id" : 674677528330637312,
  "in_reply_to_status_id" : 674672863287316480,
  "created_at" : "2015-12-09 19:50:32 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674619872849063937",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17366121606651, 8.62499754501314 ]
  },
  "id_str" : "674635312170213376",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC probably because it\u2019s one of the newer emoji.",
  "id" : 674635312170213376,
  "in_reply_to_status_id" : 674619872849063937,
  "created_at" : "2015-12-09 17:02:47 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674616397201342464",
  "geo" : { },
  "id_str" : "674618151691280386",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC oh, you missed out on the best part, or at least the part you need to make use of it :D",
  "id" : 674618151691280386,
  "in_reply_to_status_id" : 674616397201342464,
  "created_at" : "2015-12-09 15:54:35 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674588667915214849",
  "text" : "the latest update is in: since starting in this lab I consumed ~600 \u20AC worth of coffee while in the office.",
  "id" : 674588667915214849,
  "created_at" : "2015-12-09 13:57:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674583680170504192",
  "text" : "The moment where your meeting turns into a discussion about the roots of Uri Geller as a bacterium has a slightly similar sounding name.",
  "id" : 674583680170504192,
  "created_at" : "2015-12-09 13:37:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674566047190519808",
  "geo" : { },
  "id_str" : "674582642000547840",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z ah, glad you found this. Fits our amateur linguistics class!",
  "id" : 674582642000547840,
  "in_reply_to_status_id" : 674566047190519808,
  "created_at" : "2015-12-09 13:33:29 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/PjmE1RfUoF",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/_EXMf3Bwi9\/",
      "display_url" : "instagram.com\/p\/_EXMf3Bwi9\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.366851214, 4.912454588 ]
  },
  "id_str" : "674540118078791680",
  "text" : "Playing mad scientist #latergram @ Micropia https:\/\/t.co\/PjmE1RfUoF",
  "id" : 674540118078791680,
  "created_at" : "2015-12-09 10:44:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/5VReaRtRg8",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/_EW4qrBwim\/",
      "display_url" : "instagram.com\/p\/_EW4qrBwim\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3732605, 4.9003201 ]
  },
  "id_str" : "674539437372678144",
  "text" : "Enlightening @ Latei https:\/\/t.co\/5VReaRtRg8",
  "id" : 674539437372678144,
  "created_at" : "2015-12-09 10:41:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/Zwos78KwBq",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/134806014027\/trying-to-fix-my-thesis",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/134806014\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674529011796676608",
  "text" : "even worse if you try to fix two theses at once https:\/\/t.co\/Zwos78KwBq",
  "id" : 674529011796676608,
  "created_at" : "2015-12-09 10:00:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/StVbwuEPah",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=OqAcnDSjy4E",
      "display_url" : "youtube.com\/watch?v=OqAcnD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674524857653178368",
  "text" : "i know i\u2019m young, i know i\u2019m dying. but i\u2019m still dumb so i\u2019ll keep trying. \uD83C\uDFC3 https:\/\/t.co\/StVbwuEPah",
  "id" : 674524857653178368,
  "created_at" : "2015-12-09 09:43:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674521659861303300",
  "text" : "\u201EWorkshops where you actually do bioinformatics\u201C Oh, thanks spam mail. I have this every day actually. I just call it \u201Ework\u201C.",
  "id" : 674521659861303300,
  "created_at" : "2015-12-09 09:31:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674510570234646528",
  "geo" : { },
  "id_str" : "674519989261639680",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson only after getting a really good nights worth of sleep after being deprived for a couple of days. :D",
  "id" : 674519989261639680,
  "in_reply_to_status_id" : 674510570234646528,
  "created_at" : "2015-12-09 09:24:32 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/ON96JlIp6u",
      "expanded_url" : "http:\/\/www.wired.com\/2015\/12\/what-really-happens-when-you-get-shot\/",
      "display_url" : "wired.com\/2015\/12\/what-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674518130320896000",
  "text" : "This should be in the Lonely Planet for the USA: What Really Happens When You Get Shot https:\/\/t.co\/ON96JlIp6u",
  "id" : 674518130320896000,
  "created_at" : "2015-12-09 09:17:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/hfK722MoYZ",
      "expanded_url" : "https:\/\/twitter.com\/GigaScience\/status\/674515073147228160",
      "display_url" : "twitter.com\/GigaScience\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674515965758033921",
  "text" : "Watch me being totally jet lagged and trying not to fall asleep on stage! https:\/\/t.co\/hfK722MoYZ",
  "id" : 674515965758033921,
  "created_at" : "2015-12-09 09:08:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EvolDir",
      "screen_name" : "evoldir",
      "indices" : [ 3, 11 ],
      "id_str" : "19108922",
      "id" : 19108922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/Q93KWh3r9h",
      "expanded_url" : "http:\/\/ift.tt\/1HPGMGI",
      "display_url" : "ift.tt\/1HPGMGI"
    } ]
  },
  "geo" : { },
  "id_str" : "674512491687317504",
  "text" : "RT @evoldir: Postdoc: ULB.Belgium.Fellowships_for_Refugees https:\/\/t.co\/Q93KWh3r9h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/Q93KWh3r9h",
        "expanded_url" : "http:\/\/ift.tt\/1HPGMGI",
        "display_url" : "ift.tt\/1HPGMGI"
      } ]
    },
    "geo" : { },
    "id_str" : "673754639502848000",
    "text" : "Postdoc: ULB.Belgium.Fellowships_for_Refugees https:\/\/t.co\/Q93KWh3r9h",
    "id" : 673754639502848000,
    "created_at" : "2015-12-07 06:43:18 +0000",
    "user" : {
      "name" : "EvolDir",
      "screen_name" : "evoldir",
      "protected" : false,
      "id_str" : "19108922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/71594963\/d_normal.png",
      "id" : 19108922,
      "verified" : false
    }
  },
  "id" : 674512491687317504,
  "created_at" : "2015-12-09 08:54:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/cmLBOqKmZW",
      "expanded_url" : "https:\/\/twitter.com\/heyaudy\/status\/674482878542045184",
      "display_url" : "twitter.com\/heyaudy\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674509571117948928",
  "text" : "Me, trying to figure out how I broke the openSNP build this time. https:\/\/t.co\/cmLBOqKmZW",
  "id" : 674509571117948928,
  "created_at" : "2015-12-09 08:43:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/TD9LN1UCsb",
      "expanded_url" : "http:\/\/time.com\/4138647\/laurie-penny-stoya-james-deen\/",
      "display_url" : "time.com\/4138647\/laurie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674400143706365952",
  "text" : "The New Shift in Rape Culture https:\/\/t.co\/TD9LN1UCsb",
  "id" : 674400143706365952,
  "created_at" : "2015-12-09 01:28:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 14, 28 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674394981549797378",
  "geo" : { },
  "id_str" : "674395159522578432",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @NazeefaFatima how do you know?! (just having this as a post-commit-dinner!)",
  "id" : 674395159522578432,
  "in_reply_to_status_id" : 674394981549797378,
  "created_at" : "2015-12-09 01:08:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 63, 76 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674393850069147648",
  "geo" : { },
  "id_str" : "674394584122834944",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima sometimes you can opt into not acting like one, @PhilippBayer has perfected this :D",
  "id" : 674394584122834944,
  "in_reply_to_status_id" : 674393850069147648,
  "created_at" : "2015-12-09 01:06:13 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 14, 28 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674392204714967040",
  "geo" : { },
  "id_str" : "674392708681752576",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @NazeefaFatima lucky you! took me a bit longer to figure that one out. and I still fail to recognize this quite often m)",
  "id" : 674392708681752576,
  "in_reply_to_status_id" : 674392204714967040,
  "created_at" : "2015-12-09 00:58:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 97, 107 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674391257972633605",
  "geo" : { },
  "id_str" : "674391971671244801",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima they are just good in pretending **maybehugs** (to steal this lovely concept from @biocrusoe)",
  "id" : 674391971671244801,
  "in_reply_to_status_id" : 674391257972633605,
  "created_at" : "2015-12-09 00:55:50 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 14, 28 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674391515225960448",
  "geo" : { },
  "id_str" : "674391699024662528",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @NazeefaFatima the worst-kept secret of adulthood, regardless of inside\/outside academia.",
  "id" : 674391699024662528,
  "in_reply_to_status_id" : 674391515225960448,
  "created_at" : "2015-12-09 00:54:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674389862242381824",
  "geo" : { },
  "id_str" : "674390414909177856",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen in academia the diet is always unhealthy.",
  "id" : 674390414909177856,
  "in_reply_to_status_id" : 674389862242381824,
  "created_at" : "2015-12-09 00:49:39 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/ZgRsmTZvpH",
      "expanded_url" : "http:\/\/ak-hdl.buzzfed.com\/static\/enhanced\/webdr01\/2013\/1\/23\/17\/anigif_enhanced-buzz-6597-1358978730-4.gif",
      "display_url" : "ak-hdl.buzzfed.com\/static\/enhance\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "674388270256545792",
  "geo" : { },
  "id_str" : "674390292179623936",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima https:\/\/t.co\/ZgRsmTZvpH",
  "id" : 674390292179623936,
  "in_reply_to_status_id" : 674388270256545792,
  "created_at" : "2015-12-09 00:49:09 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674387849186181122",
  "text" : "\u00AB\u2019The Academic Jet Set\u2019 might be a good title for an autobiography. Not so much \u2018rich and beautiful\u2019 as \u2018poor, underfed &amp; sexy\u2019.\u00BB",
  "id" : 674387849186181122,
  "created_at" : "2015-12-09 00:39:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674348931036274688",
  "geo" : { },
  "id_str" : "674351146866188288",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson thanks, will give it a look!",
  "id" : 674351146866188288,
  "in_reply_to_status_id" : 674348931036274688,
  "created_at" : "2015-12-08 22:13:36 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674340348219498496",
  "geo" : { },
  "id_str" : "674341187965296642",
  "in_reply_to_user_id" : 14286491,
  "text" : "Make sure to read the abstract &amp; acknowledgements!",
  "id" : 674341187965296642,
  "in_reply_to_status_id" : 674340348219498496,
  "created_at" : "2015-12-08 21:34:02 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/mOK06ug26b",
      "expanded_url" : "https:\/\/twitter.com\/FedericoArdila\/status\/674290080895205376",
      "display_url" : "twitter.com\/FedericoArdila\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674340348219498496",
  "text" : "\u00ABIt is not my place to make the system comfortable with itself.\u00BB &lt;3 https:\/\/t.co\/mOK06ug26b",
  "id" : 674340348219498496,
  "created_at" : "2015-12-08 21:30:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 39, 45 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/j3dapd70Un",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2015\/12\/the-linguistics-of-youtube-voice\/418962\/?single_page=true",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674338084004216833",
  "text" : "The Linguistics of 'YouTube Voice' \/cc @Lobot https:\/\/t.co\/j3dapd70Un",
  "id" : 674338084004216833,
  "created_at" : "2015-12-08 21:21:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Palmer",
      "screen_name" : "jonpalmer2013",
      "indices" : [ 0, 14 ],
      "id_str" : "1167178885",
      "id" : 1167178885
    }, {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 15, 30 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480414007086436352",
  "geo" : { },
  "id_str" : "674337472353075201",
  "in_reply_to_user_id" : 1167178885,
  "text" : "@jonpalmer2013 @torstenseemann probably came with the Atlas of Protein Sequence and Structure!",
  "id" : 674337472353075201,
  "in_reply_to_status_id" : 480414007086436352,
  "created_at" : "2015-12-08 21:19:16 +0000",
  "in_reply_to_screen_name" : "jonpalmer2013",
  "in_reply_to_user_id_str" : "1167178885",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Reineke",
      "screen_name" : "larsreineke",
      "indices" : [ 0, 12 ],
      "id_str" : "6338182",
      "id" : 6338182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674323735948746752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11098180209039, 8.752907545019198 ]
  },
  "id_str" : "674332393008943104",
  "in_reply_to_user_id" : 6338182,
  "text" : "@larsreineke muss man ja nicht auf dem ersten Screen tragen. Irgendwo tief versteckt in einem Ordner ;)",
  "id" : 674332393008943104,
  "in_reply_to_status_id" : 674323735948746752,
  "created_at" : "2015-12-08 20:59:05 +0000",
  "in_reply_to_screen_name" : "larsreineke",
  "in_reply_to_user_id_str" : "6338182",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Reineke",
      "screen_name" : "larsreineke",
      "indices" : [ 0, 12 ],
      "id_str" : "6338182",
      "id" : 6338182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674323320142241792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10888577909219, 8.753875689589188 ]
  },
  "id_str" : "674323463692267524",
  "in_reply_to_user_id" : 6338182,
  "text" : "@larsreineke yep, danke. Schau ich mir mal an :)",
  "id" : 674323463692267524,
  "in_reply_to_status_id" : 674323320142241792,
  "created_at" : "2015-12-08 20:23:36 +0000",
  "in_reply_to_screen_name" : "larsreineke",
  "in_reply_to_user_id_str" : "6338182",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/FXsTxYGpZy",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/674316949497753600",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "674316949497753600",
  "geo" : { },
  "id_str" : "674317271905509376",
  "in_reply_to_user_id" : 14286491,
  "text" : "chain-smoking &amp; drinking past-me is disapprovingly shaking his head in disbelief about those changes. https:\/\/t.co\/FXsTxYGpZy",
  "id" : 674317271905509376,
  "in_reply_to_status_id" : 674316949497753600,
  "created_at" : "2015-12-08 19:59:00 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 100, 109 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 4, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674316949497753600",
  "text" : "Hey #quantifiedself people: which iOS app can you recommend to keep track of your gym workouts? \/cc @eramirez",
  "id" : 674316949497753600,
  "created_at" : "2015-12-08 19:57:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Sobel",
      "screen_name" : "JonathanSobel1",
      "indices" : [ 0, 15 ],
      "id_str" : "841497890",
      "id" : 841497890
    }, {
      "name" : "Beer DeCoded",
      "screen_name" : "beerdecoded",
      "indices" : [ 16, 28 ],
      "id_str" : "3295237359",
      "id" : 3295237359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674312582262620160",
  "geo" : { },
  "id_str" : "674316803225616384",
  "in_reply_to_user_id" : 841497890,
  "text" : "@JonathanSobel1 @beerdecoded sweet, that would be a great gift :)",
  "id" : 674316803225616384,
  "in_reply_to_status_id" : 674312582262620160,
  "created_at" : "2015-12-08 19:57:08 +0000",
  "in_reply_to_screen_name" : "JonathanSobel1",
  "in_reply_to_user_id_str" : "841497890",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beer DeCoded",
      "screen_name" : "beerdecoded",
      "indices" : [ 0, 12 ],
      "id_str" : "3295237359",
      "id" : 3295237359
    }, {
      "name" : "Current Biology",
      "screen_name" : "CurrentBiology",
      "indices" : [ 13, 28 ],
      "id_str" : "837693559",
      "id" : 837693559
    }, {
      "name" : "Jonathan Sobel",
      "screen_name" : "JonathanSobel1",
      "indices" : [ 29, 44 ],
      "id_str" : "841497890",
      "id" : 841497890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674278128647294977",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17366043065722, 8.624992771286117 ]
  },
  "id_str" : "674279029994823680",
  "in_reply_to_user_id" : 3295237359,
  "text" : "@beerdecoded @CurrentBiology @JonathanSobel1 very cool. Thanks for sharing. Any news from your data? :)",
  "id" : 674279029994823680,
  "in_reply_to_status_id" : 674278128647294977,
  "created_at" : "2015-12-08 17:27:02 +0000",
  "in_reply_to_screen_name" : "beerdecoded",
  "in_reply_to_user_id_str" : "3295237359",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/aCWztZ72AK",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0144296",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674210157426012160",
  "text" : "Sentiment of Emoji https:\/\/t.co\/aCWztZ72AK",
  "id" : 674210157426012160,
  "created_at" : "2015-12-08 12:53:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674178703627284482",
  "geo" : { },
  "id_str" : "674179075997573120",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe (which can be fun if you\u2019re on the sidelines ;))",
  "id" : 674179075997573120,
  "in_reply_to_status_id" : 674178703627284482,
  "created_at" : "2015-12-08 10:49:52 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674178703627284482",
  "geo" : { },
  "id_str" : "674179036483047424",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe i don\u2019t think it\u2019s necessarily trolling, I have seen ppl having problems in understanding similar things.",
  "id" : 674179036483047424,
  "in_reply_to_status_id" : 674178703627284482,
  "created_at" : "2015-12-08 10:49:42 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674178459841769472",
  "geo" : { },
  "id_str" : "674178614271844352",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe \u201Ebut it\u2019s not changing data, it\u2019s just reordering it!\u201C",
  "id" : 674178614271844352,
  "in_reply_to_status_id" : 674178459841769472,
  "created_at" : "2015-12-08 10:48:01 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674177804049739777",
  "geo" : { },
  "id_str" : "674178208812634112",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe have you ever discussed the Monty Hall problem with people? Statistical misunderstandings are hard to overthrow. ;-)",
  "id" : 674178208812634112,
  "in_reply_to_status_id" : 674177804049739777,
  "created_at" : "2015-12-08 10:46:25 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/aDdR1NHe6i",
      "expanded_url" : "http:\/\/www.nursebuff.com\/wp-content\/uploads\/2014\/09\/GIFs-for-nurses.gif",
      "display_url" : "nursebuff.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674172284488282112",
  "text" : "when you are too busy to finalize the last steps you\u2019d need to get some funding m( https:\/\/t.co\/aDdR1NHe6i",
  "id" : 674172284488282112,
  "created_at" : "2015-12-08 10:22:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674168634009395200",
  "geo" : { },
  "id_str" : "674170136149012480",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe even if this one is just a troll, i\u2019m sure there are people out there do this\/want to do this. Statistical literacy is rare.",
  "id" : 674170136149012480,
  "in_reply_to_status_id" : 674168634009395200,
  "created_at" : "2015-12-08 10:14:20 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heng Li",
      "screen_name" : "lh3lh3",
      "indices" : [ 3, 10 ],
      "id_str" : "2165843324",
      "id" : 2165843324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674156833146322944",
  "text" : "RT @lh3lh3: Introducing bioconda, a good bio-software package manager (no root required; no compiling; just portable binaries): https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/FzQVssIi8q",
        "expanded_url" : "http:\/\/lh3.github.io\/2015\/12\/07\/bioconda-the-best-package-manager-so-far",
        "display_url" : "lh3.github.io\/2015\/12\/07\/bio\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "674095217809727488",
    "text" : "Introducing bioconda, a good bio-software package manager (no root required; no compiling; just portable binaries): https:\/\/t.co\/FzQVssIi8q",
    "id" : 674095217809727488,
    "created_at" : "2015-12-08 05:16:38 +0000",
    "user" : {
      "name" : "Heng Li",
      "screen_name" : "lh3lh3",
      "protected" : false,
      "id_str" : "2165843324",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_normal.png",
      "id" : 2165843324,
      "verified" : false
    }
  },
  "id" : 674156833146322944,
  "created_at" : "2015-12-08 09:21:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674150595826049024",
  "geo" : { },
  "id_str" : "674150950030999552",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer always have the feeling that this branch of evolutionary biology would go extinct if Ziheng Yang was ran over by a bus.",
  "id" : 674150950030999552,
  "in_reply_to_status_id" : 674150595826049024,
  "created_at" : "2015-12-08 08:58:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674149744239767552",
  "geo" : { },
  "id_str" : "674149982132436992",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer add PAML ctl files to the list and you\u2019re good to go.",
  "id" : 674149982132436992,
  "in_reply_to_status_id" : 674149744239767552,
  "created_at" : "2015-12-08 08:54:15 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674144911654957060",
  "geo" : { },
  "id_str" : "674149420330573824",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer isn\u2019t that a PhD on its own?",
  "id" : 674149420330573824,
  "in_reply_to_status_id" : 674144911654957060,
  "created_at" : "2015-12-08 08:52:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon J Greenhill",
      "screen_name" : "SimonJGreenhill",
      "indices" : [ 3, 19 ],
      "id_str" : "415162347",
      "id" : 415162347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/XhmZ8xZbUA",
      "expanded_url" : "https:\/\/stats.stackexchange.com\/questions\/185507\/what-happens-if-the-explanatory-and-response-variables-are-sorted-independently",
      "display_url" : "stats.stackexchange.com\/questions\/1855\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674146627544817664",
  "text" : "RT @SimonJGreenhill: Wow. Just wow: https:\/\/t.co\/XhmZ8xZbUA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/XhmZ8xZbUA",
        "expanded_url" : "https:\/\/stats.stackexchange.com\/questions\/185507\/what-happens-if-the-explanatory-and-response-variables-are-sorted-independently",
        "display_url" : "stats.stackexchange.com\/questions\/1855\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "674093326954459136",
    "text" : "Wow. Just wow: https:\/\/t.co\/XhmZ8xZbUA",
    "id" : 674093326954459136,
    "created_at" : "2015-12-08 05:09:07 +0000",
    "user" : {
      "name" : "Simon J Greenhill",
      "screen_name" : "SimonJGreenhill",
      "protected" : false,
      "id_str" : "415162347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456597813829173248\/4On-MNNo_normal.jpeg",
      "id" : 415162347,
      "verified" : false
    }
  },
  "id" : 674146627544817664,
  "created_at" : "2015-12-08 08:40:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel \u201CThe Yellow Dart\u201D Feltman",
      "screen_name" : "RachelFeltman",
      "indices" : [ 3, 17 ],
      "id_str" : "22270118",
      "id" : 22270118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/Wg3VxE2R3o",
      "expanded_url" : "http:\/\/wpo.st\/D4Lv0",
      "display_url" : "wpo.st\/D4Lv0"
    } ]
  },
  "geo" : { },
  "id_str" : "674142512873873408",
  "text" : "RT @RachelFeltman: When labs clash over tardigrade DNA, that's just science working as it should https:\/\/t.co\/Wg3VxE2R3o aka: The Water Bea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/Wg3VxE2R3o",
        "expanded_url" : "http:\/\/wpo.st\/D4Lv0",
        "display_url" : "wpo.st\/D4Lv0"
      } ]
    },
    "geo" : { },
    "id_str" : "673934783165177856",
    "text" : "When labs clash over tardigrade DNA, that's just science working as it should https:\/\/t.co\/Wg3VxE2R3o aka: The Water Bear Don\u2019t Care",
    "id" : 673934783165177856,
    "created_at" : "2015-12-07 18:39:08 +0000",
    "user" : {
      "name" : "Rachel \u201CThe Yellow Dart\u201D Feltman",
      "screen_name" : "RachelFeltman",
      "protected" : false,
      "id_str" : "22270118",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/818514182219976704\/exX-XFDp_normal.jpg",
      "id" : 22270118,
      "verified" : true
    }
  },
  "id" : 674142512873873408,
  "created_at" : "2015-12-08 08:24:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Mims\uD83E\uDD33",
      "screen_name" : "mims",
      "indices" : [ 3, 8 ],
      "id_str" : "1769191",
      "id" : 1769191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/gRzQwwzegP",
      "expanded_url" : "http:\/\/qz.com\/312537\/the-secret-to-the-uber-economy-is-wealth-inequality\/",
      "display_url" : "qz.com\/312537\/the-sec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674026281005162497",
  "text" : "RT @mims: India has had \"Uber for X\" startups for centuries. They're called poor people. http:\/\/t.co\/gRzQwwzegP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/gRzQwwzegP",
        "expanded_url" : "http:\/\/qz.com\/312537\/the-secret-to-the-uber-economy-is-wealth-inequality\/",
        "display_url" : "qz.com\/312537\/the-sec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "544808183844581376",
    "text" : "India has had \"Uber for X\" startups for centuries. They're called poor people. http:\/\/t.co\/gRzQwwzegP",
    "id" : 544808183844581376,
    "created_at" : "2014-12-16 10:56:07 +0000",
    "user" : {
      "name" : "Christopher Mims\uD83E\uDD33",
      "screen_name" : "mims",
      "protected" : false,
      "id_str" : "1769191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/805781204381351936\/_P3k7Gmn_normal.jpg",
      "id" : 1769191,
      "verified" : true
    }
  },
  "id" : 674026281005162497,
  "created_at" : "2015-12-08 00:42:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Bee",
      "screen_name" : "SaraBee",
      "indices" : [ 3, 11 ],
      "id_str" : "9275462",
      "id" : 9275462
    }, {
      "name" : "Etsy",
      "screen_name" : "Etsy",
      "indices" : [ 28, 33 ],
      "id_str" : "11522502",
      "id" : 11522502
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SaraBee\/status\/674008637669556224\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/YTrwvWUfau",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVqPRQGUwAEtH6f.jpg",
      "id_str" : "674008620787351553",
      "id" : 674008620787351553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVqPRQGUwAEtH6f.jpg",
      "sizes" : [ {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/YTrwvWUfau"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674022583453523970",
  "text" : "RT @SaraBee: Super proud of @Etsy today for making our bathrooms as gender-neutral as state law allows https:\/\/t.co\/YTrwvWUfau",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Etsy",
        "screen_name" : "Etsy",
        "indices" : [ 15, 20 ],
        "id_str" : "11522502",
        "id" : 11522502
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SaraBee\/status\/674008637669556224\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/YTrwvWUfau",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVqPRQGUwAEtH6f.jpg",
        "id_str" : "674008620787351553",
        "id" : 674008620787351553,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVqPRQGUwAEtH6f.jpg",
        "sizes" : [ {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/YTrwvWUfau"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "674008637669556224",
    "text" : "Super proud of @Etsy today for making our bathrooms as gender-neutral as state law allows https:\/\/t.co\/YTrwvWUfau",
    "id" : 674008637669556224,
    "created_at" : "2015-12-07 23:32:36 +0000",
    "user" : {
      "name" : "Sara Bee",
      "screen_name" : "SaraBee",
      "protected" : false,
      "id_str" : "9275462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/679822128011542528\/llEgTH1K_normal.jpg",
      "id" : 9275462,
      "verified" : false
    }
  },
  "id" : 674022583453523970,
  "created_at" : "2015-12-08 00:28:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 72, 85 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/tcbD2FI5UI",
      "expanded_url" : "http:\/\/freethoughtblogs.com\/carrier\/archives\/9141",
      "display_url" : "freethoughtblogs.com\/carrier\/archiv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674008379887648768",
  "text" : "Is 90% of All EvoPsych False? (I think John Ioannidis would agree)  \/cc @PhilippBayer https:\/\/t.co\/tcbD2FI5UI",
  "id" : 674008379887648768,
  "created_at" : "2015-12-07 23:31:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674003632061292544",
  "text" : "@malech Die \uD83D\uDC0C ist im \uD83C\uDFE0.",
  "id" : 674003632061292544,
  "created_at" : "2015-12-07 23:12:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673944692384382976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17181785749543, 8.627124006085705 ]
  },
  "id_str" : "673951780070424580",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston congrats!",
  "id" : 673951780070424580,
  "in_reply_to_status_id" : 673944692384382976,
  "created_at" : "2015-12-07 19:46:40 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 3, 10 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "32c3",
      "indices" : [ 79, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673950328769880066",
  "text" : "RT @arikia: My Schengen visa is officially reset! Alas, just tried to book for #32c3 but tickets are sold out. Does anyone have two for me \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jack Donovan",
        "screen_name" : "Jyakku",
        "indices" : [ 131, 138 ],
        "id_str" : "14929577",
        "id" : 14929577
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "32c3",
        "indices" : [ 67, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "673935799176577024",
    "text" : "My Schengen visa is officially reset! Alas, just tried to book for #32c3 but tickets are sold out. Does anyone have two for me and @Jyakku?",
    "id" : 673935799176577024,
    "created_at" : "2015-12-07 18:43:10 +0000",
    "user" : {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "protected" : false,
      "id_str" : "71654283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897255084073025537\/5uB8YwJG_normal.jpg",
      "id" : 71654283,
      "verified" : false
    }
  },
  "id" : 673950328769880066,
  "created_at" : "2015-12-07 19:40:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673888247051853825",
  "geo" : { },
  "id_str" : "673889458891194372",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston who knows, maybe \u201Ethe genetical theory of natural selection\u201C is a weirdly written Kama Sutra clone and ppl just don\u2019t get it?",
  "id" : 673889458891194372,
  "in_reply_to_status_id" : 673888247051853825,
  "created_at" : "2015-12-07 15:39:01 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673887476302376960",
  "text" : "One day I will grow up &amp; my brain will stop splitting \u201Efishersexact\u201C as \u201Efisher sex act\u201C. But apparently not today.",
  "id" : 673887476302376960,
  "created_at" : "2015-12-07 15:31:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673829835790278656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233931514484, 8.627514153927008 ]
  },
  "id_str" : "673834090592890880",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe yes, both failing hard. ;)",
  "id" : 673834090592890880,
  "in_reply_to_status_id" : 673829835790278656,
  "created_at" : "2015-12-07 11:59:01 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/ino8l05VVH",
      "expanded_url" : "https:\/\/media1.giphy.com\/media\/DdotCCeucTHmU\/200.gif",
      "display_url" : "media1.giphy.com\/media\/DdotCCeu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "673819635125526529",
  "geo" : { },
  "id_str" : "673819781104054273",
  "in_reply_to_user_id" : 14286491,
  "text" : "and when you then try to solve issues with some pair-programming https:\/\/t.co\/ino8l05VVH",
  "id" : 673819781104054273,
  "in_reply_to_status_id" : 673819635125526529,
  "created_at" : "2015-12-07 11:02:09 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/brsgbKsw2D",
      "expanded_url" : "https:\/\/media0.giphy.com\/media\/13J4mAfd4iHC5G\/200.gif",
      "display_url" : "media0.giphy.com\/media\/13J4mAfd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673819635125526529",
  "text" : "when you find your own buggy and undocumented code https:\/\/t.co\/brsgbKsw2D",
  "id" : 673819635125526529,
  "created_at" : "2015-12-07 11:01:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/XttOlAc5os",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/134556727943\/reflecting-on-my-failed-experiments",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/134556727\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673812267000033280",
  "text" : "the wonders of science https:\/\/t.co\/XttOlAc5os",
  "id" : 673812267000033280,
  "created_at" : "2015-12-07 10:32:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard",
      "screen_name" : "zinken",
      "indices" : [ 0, 7 ],
      "id_str" : "15353398",
      "id" : 15353398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673808258038161408",
  "geo" : { },
  "id_str" : "673809379305594880",
  "in_reply_to_user_id" : 15353398,
  "text" : "@zinken Sehr sch\u00F6ne Idee \uD83D\uDC4D",
  "id" : 673809379305594880,
  "in_reply_to_status_id" : 673808258038161408,
  "created_at" : "2015-12-07 10:20:49 +0000",
  "in_reply_to_screen_name" : "zinken",
  "in_reply_to_user_id_str" : "15353398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 0, 13 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/zEKJr7qV1D",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/I%27m_Your_Man_(Leonard_Cohen_album)",
      "display_url" : "en.m.wikipedia.org\/wiki\/I%27m_You\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "673598515378053120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407361475822, 8.753394812324942 ]
  },
  "id_str" : "673640668313571328",
  "in_reply_to_user_id" : 53639020,
  "text" : "@Unsichtbarer https:\/\/t.co\/zEKJr7qV1D ? :D",
  "id" : 673640668313571328,
  "in_reply_to_status_id" : 673598515378053120,
  "created_at" : "2015-12-06 23:10:25 +0000",
  "in_reply_to_screen_name" : "Unsichtbarer",
  "in_reply_to_user_id_str" : "53639020",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tardigrade supreme",
      "screen_name" : "mrwaterbear",
      "indices" : [ 92, 104 ],
      "id_str" : "4382131093",
      "id" : 4382131093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/HzQWYSeDTx",
      "expanded_url" : "https:\/\/instagram.com\/p\/-9Ht9phwvv\/",
      "display_url" : "instagram.com\/p\/-9Ht9phwvv\/"
    } ]
  },
  "in_reply_to_status_id_str" : "673499995492982784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36569971316714, 4.961329204966278 ]
  },
  "id_str" : "673522077895364608",
  "in_reply_to_user_id" : 14286491,
  "text" : "And once the Horizontal Gene Transfer debate is settled, I will ride into the sunlight with @mrwaterbear. https:\/\/t.co\/HzQWYSeDTx",
  "id" : 673522077895364608,
  "in_reply_to_status_id" : 673499995492982784,
  "created_at" : "2015-12-06 15:19:11 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gernot J. Abel",
      "screen_name" : "gernotJabel",
      "indices" : [ 0, 12 ],
      "id_str" : "1912181796",
      "id" : 1912181796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673502466118414336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.37121470849507, 4.898117536615684 ]
  },
  "id_str" : "673505833641209856",
  "in_reply_to_user_id" : 1912181796,
  "text" : "@gernotJabel thing is, I don\u2019t really believe in the PNAS paper, the methods of the pre print address many issues :)",
  "id" : 673505833641209856,
  "in_reply_to_status_id" : 673502466118414336,
  "created_at" : "2015-12-06 14:14:38 +0000",
  "in_reply_to_screen_name" : "gernotJabel",
  "in_reply_to_user_id_str" : "1912181796",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/2V00sgxZg5",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/-8-M8ihwqS\/",
      "display_url" : "instagram.com\/p\/-8-M8ihwqS\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.366851214, 4.912454588 ]
  },
  "id_str" : "673499995492982784",
  "text" : "Horizontal Gene Transfer in Tardigrades you say? We need to have a serious talk\u2026 @ Micropia https:\/\/t.co\/2V00sgxZg5",
  "id" : 673499995492982784,
  "created_at" : "2015-12-06 13:51:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/cUuiRXqkT1",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/ResearchBloggingBiologyEnglish\/~3\/Hz7zUbkgbTw\/",
      "display_url" : "feedproxy.google.com\/~r\/ResearchBlo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673457468136136704",
  "text" : "On the Cognitive Advantage of Bilinguals https:\/\/t.co\/cUuiRXqkT1",
  "id" : 673457468136136704,
  "created_at" : "2015-12-06 11:02:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/rbvlvr5Ym7",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1841",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673456314782191616",
  "text" : "What about being mistaken for a Post-Doc while doing your PhD? https:\/\/t.co\/rbvlvr5Ym7",
  "id" : 673456314782191616,
  "created_at" : "2015-12-06 10:57:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36589392829671, 4.912872110068569 ]
  },
  "id_str" : "673451515177209856",
  "text" : "\u00ABHow shall I introduce you in the email? Does \u2018travel companion\u2019 work?\u00BB \u2014 \u00ABMake that \u2018Companion Cube\u2019!\u00BB",
  "id" : 673451515177209856,
  "created_at" : "2015-12-06 10:38:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/I6jBW5gufd",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/-8nmu_hwgC\/",
      "display_url" : "instagram.com\/p\/-8nmu_hwgC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "673450304113934336",
  "text" : "kitchen surveillance https:\/\/t.co\/I6jBW5gufd",
  "id" : 673450304113934336,
  "created_at" : "2015-12-06 10:33:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/TwS78JFunF",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/-8iGHPhwnX\/",
      "display_url" : "instagram.com\/p\/-8iGHPhwnX\/"
    } ]
  },
  "geo" : { },
  "id_str" : "673438187776290816",
  "text" : "So sleepy https:\/\/t.co\/TwS78JFunF",
  "id" : 673438187776290816,
  "created_at" : "2015-12-06 09:45:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/us5muV9z4W",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/673278965696581632",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "673278965696581632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36604184756321, 4.912746120041366 ]
  },
  "id_str" : "673436486205898754",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABDo you have a good caption for the picture?\u00BB \u2014 \u00ABAngel of Small Death\u2026?\u00BB https:\/\/t.co\/us5muV9z4W",
  "id" : 673436486205898754,
  "in_reply_to_status_id" : 673278965696581632,
  "created_at" : "2015-12-06 09:39:04 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit Support",
      "screen_name" : "FitbitSupport",
      "indices" : [ 0, 14 ],
      "id_str" : "476258341",
      "id" : 476258341
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 59, 65 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673405411047772160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36608670563657, 4.912626659502194 ]
  },
  "id_str" : "673436227627012096",
  "in_reply_to_user_id" : 476258341,
  "text" : "@FitbitSupport but why the huge difference to the One that @Lobot carries when we marched in-step all day?",
  "id" : 673436227627012096,
  "in_reply_to_status_id" : 673405411047772160,
  "created_at" : "2015-12-06 09:38:03 +0000",
  "in_reply_to_screen_name" : "FitbitSupport",
  "in_reply_to_user_id_str" : "476258341",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673284863613620225",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36526901930891, 4.959383300177835 ]
  },
  "id_str" : "673419187503656964",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 thanks :)",
  "id" : 673419187503656964,
  "in_reply_to_status_id" : 673284863613620225,
  "created_at" : "2015-12-06 08:30:20 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crispr",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/QEk9B0K91E",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/-7ZsFsBwsr\/",
      "display_url" : "instagram.com\/p\/-7ZsFsBwsr\/"
    } ]
  },
  "geo" : { },
  "id_str" : "673278965696581632",
  "text" : "Has science gone to far? Riffing on the genetic engineering &amp; playing god trope. #crispr https:\/\/t.co\/QEk9B0K91E",
  "id" : 673278965696581632,
  "created_at" : "2015-12-05 23:13:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 3, 10 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/673271619087941634\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/uabxtdIXJ0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVfw9-UWoAE47UO.png",
      "id_str" : "673271616806232065",
      "id" : 673271616806232065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVfw9-UWoAE47UO.png",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/uabxtdIXJ0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36558245034177, 4.960582880307883 ]
  },
  "id_str" : "673271619087941634",
  "text" : "My @fitbit Charge HR is acting up lately. Pretty sure the floor count is off, given that I walked around Amsterdam. https:\/\/t.co\/uabxtdIXJ0",
  "id" : 673271619087941634,
  "created_at" : "2015-12-05 22:43:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36533486974735, 4.959578224057711 ]
  },
  "id_str" : "673267421432664065",
  "text" : "@malech o\/ :)",
  "id" : 673267421432664065,
  "created_at" : "2015-12-05 22:27:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/AtzEkGRQp4",
      "expanded_url" : "http:\/\/45.media.tumblr.com\/435892f940e92c1753e6911a867e4a2e\/tumblr_n7jc3shtNs1tbh1dho1_400.gif",
      "display_url" : "45.media.tumblr.com\/435892f940e92c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "673235405429411841",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.35516908853693, 4.891020026338811 ]
  },
  "id_str" : "673235821105913856",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot https:\/\/t.co\/AtzEkGRQp4",
  "id" : 673235821105913856,
  "in_reply_to_status_id" : 673235405429411841,
  "created_at" : "2015-12-05 20:21:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/c6g7yGnGiq",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/-66m1wBwow\/",
      "display_url" : "instagram.com\/p\/-66m1wBwow\/"
    } ]
  },
  "geo" : { },
  "id_str" : "673210614010003456",
  "text" : "Tea, when the barista only scolds you for ordering decaf https:\/\/t.co\/c6g7yGnGiq",
  "id" : 673210614010003456,
  "created_at" : "2015-12-05 18:41:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/N7gbdXKnoZ",
      "expanded_url" : "https:\/\/de.m.wikipedia.org\/wiki\/Harnr%C3%B6hrenplug",
      "display_url" : "de.m.wikipedia.org\/wiki\/Harnr%C3%\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "673188719025774592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36289451743682, 4.945135200121436 ]
  },
  "id_str" : "673189565339947009",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s genau, siehe https:\/\/t.co\/N7gbdXKnoZ",
  "id" : 673189565339947009,
  "in_reply_to_status_id" : 673188719025774592,
  "created_at" : "2015-12-05 17:17:54 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673145379731456000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36531459235361, 4.95959605568852 ]
  },
  "id_str" : "673181973855264768",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC \uD83C\uDF36\u2764\uFE0F",
  "id" : 673181973855264768,
  "in_reply_to_status_id" : 673145379731456000,
  "created_at" : "2015-12-05 16:47:44 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673157774067527681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36538513493461, 4.959187986495767 ]
  },
  "id_str" : "673181843076882433",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s und Dilatoren die nicht durchrutschen und fixiert sind, sind Plugs, right?",
  "id" : 673181843076882433,
  "in_reply_to_status_id" : 673157774067527681,
  "created_at" : "2015-12-05 16:47:13 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673144130730655744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36767095449002, 4.95926212308061 ]
  },
  "id_str" : "673144581224071168",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @Lobot I will ask them next time. Claiming my Feng shui expert said I\u2019m only allowed left-spin energy.",
  "id" : 673144581224071168,
  "in_reply_to_status_id" : 673144130730655744,
  "created_at" : "2015-12-05 14:19:09 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673143137372643330",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36646947985204, 4.959986868516871 ]
  },
  "id_str" : "673143685886906369",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @Lobot they also sold \u2018energized water\u2019, they didn\u2019t say which spin it has though.",
  "id" : 673143685886906369,
  "in_reply_to_status_id" : 673143137372643330,
  "created_at" : "2015-12-05 14:15:35 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/q4OFhG9Gpt",
      "expanded_url" : "http:\/\/3.bp.blogspot.com\/-M3pzDqDBhUU\/Ur2iEJiACsI\/AAAAAAABu_U\/AufBannY9ME\/s1600\/Screen+shot+2013-12-26+at+8.00.05+PM.png",
      "display_url" : "3.bp.blogspot.com\/-M3pzDqDBhUU\/U\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "673129158025871360",
  "geo" : { },
  "id_str" : "673143402993729537",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s ich hab nach \u2018penis plug\u2019 gesucht aber das gefunden: https:\/\/t.co\/q4OFhG9Gpt",
  "id" : 673143402993729537,
  "in_reply_to_status_id" : 673129158025871360,
  "created_at" : "2015-12-05 14:14:28 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673142368871297024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36626524678478, 4.958386224484302 ]
  },
  "id_str" : "673142663055597569",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @Lobot you are right. This is why the hipster vegan fad will sort itself out sooner or later.",
  "id" : 673142663055597569,
  "in_reply_to_status_id" : 673142368871297024,
  "created_at" : "2015-12-05 14:11:31 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673114881672011777",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.37077309945726, 4.90061516412715 ]
  },
  "id_str" : "673119193710088192",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s Klamotten kauft man doch auch nicht ohne seine Gr\u00F6\u00DFe zu kennen ;)",
  "id" : 673119193710088192,
  "in_reply_to_status_id" : 673114881672011777,
  "created_at" : "2015-12-05 12:38:16 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673107381593743360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.37080561880266, 4.900617385094702 ]
  },
  "id_str" : "673108079676948480",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze the first association that came to my mind.",
  "id" : 673108079676948480,
  "in_reply_to_status_id" : 673107381593743360,
  "created_at" : "2015-12-05 11:54:06 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/RiT8funePs",
      "expanded_url" : "http:\/\/g01.a.alicdn.com\/kf\/HTB1_RgXKpXXXXXMXFXXq6xXFXXXl\/Big-vibrating-special-inflatable-penis-and-Anal-plugs-pump-max-10cm-large-air-filled-Butt-Plug.jpg_220x220.jpg",
      "display_url" : "g01.a.alicdn.com\/kf\/HTB1_RgXKpX\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "673103380890427392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.37064506348091, 4.90064022661104 ]
  },
  "id_str" : "673107285317693440",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s ich mag das gut sortierte Sex-Shops immer Schieblehren haben. https:\/\/t.co\/RiT8funePs",
  "id" : 673107285317693440,
  "in_reply_to_status_id" : 673103380890427392,
  "created_at" : "2015-12-05 11:50:57 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673103329711529984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.37081366420558, 4.900632177158321 ]
  },
  "id_str" : "673106968521895936",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze Tanz den Mussolini?",
  "id" : 673106968521895936,
  "in_reply_to_status_id" : 673103329711529984,
  "created_at" : "2015-12-05 11:49:41 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673099704763326464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.37510463058178, 4.897670320061122 ]
  },
  "id_str" : "673103270542462977",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze Ausdruckstanz!",
  "id" : 673103270542462977,
  "in_reply_to_status_id" : 673099704763326464,
  "created_at" : "2015-12-05 11:35:00 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/VdM1LeUnJv",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/3oMagoKZOY4",
      "display_url" : "swarmapp.com\/c\/3oMagoKZOY4"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3750214, 4.8976999 ]
  },
  "id_str" : "673103093085691905",
  "text" : "\uD83C\uDF46\uD83D\uDCA8 (@ RoB in Amsterdam, North Holland) https:\/\/t.co\/VdM1LeUnJv",
  "id" : 673103093085691905,
  "created_at" : "2015-12-05 11:34:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/IPG9iLmd0O",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/dWkRn15f1D1",
      "display_url" : "swarmapp.com\/c\/dWkRn15f1D1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3721479584068, 4.896220387378107 ]
  },
  "id_str" : "673094284392931328",
  "text" : "Back at one of the best reasons to visit Amsterdam (@ Smart Fetish and Fantasy in Amsterdam) https:\/\/t.co\/IPG9iLmd0O",
  "id" : 673094284392931328,
  "created_at" : "2015-12-05 10:59:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/673082840159010816\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/45EURezFEO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVdFRt1WIAAeLLE.png",
      "id_str" : "673082839978614784",
      "id" : 673082839978614784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVdFRt1WIAAeLLE.png",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      } ],
      "display_url" : "pic.twitter.com\/45EURezFEO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.363016, 4.885935 ]
  },
  "id_str" : "673082840159010816",
  "text" : "Go home, Apple Maps, you're drunk. https:\/\/t.co\/45EURezFEO",
  "id" : 673082840159010816,
  "created_at" : "2015-12-05 10:13:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/eeitoCZzNV",
      "expanded_url" : "https:\/\/twitter.com\/Lobot\/status\/673080440929038336",
      "display_url" : "twitter.com\/Lobot\/status\/6\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36304463042095, 4.885948818085025 ]
  },
  "id_str" : "673081159308414976",
  "text" : "Amsterdam, where vegan breakfast places sell distilled water for 6\u20AC\/bottle\u2026 https:\/\/t.co\/eeitoCZzNV",
  "id" : 673081159308414976,
  "created_at" : "2015-12-05 10:07:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672932911700643840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36303979808513, 4.885988528318089 ]
  },
  "id_str" : "673079634649587712",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen more like Noteingang ;)",
  "id" : 673079634649587712,
  "in_reply_to_status_id" : 672932911700643840,
  "created_at" : "2015-12-05 10:01:04 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/673079272584687616\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/JsPjPjboax",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVdCCB3WsAEqewk.jpg",
      "id_str" : "673079271942959105",
      "id" : 673079271942959105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVdCCB3WsAEqewk.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1127,
        "resize" : "fit",
        "w" : 1503
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1127,
        "resize" : "fit",
        "w" : 1503
      } ],
      "display_url" : "pic.twitter.com\/JsPjPjboax"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.363023, 4.886012 ]
  },
  "id_str" : "673079272584687616",
  "text" : "Yes, with confectioners sugar, honey, different artificial sweeteners, \u2026 https:\/\/t.co\/JsPjPjboax",
  "id" : 673079272584687616,
  "created_at" : "2015-12-05 09:59:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/672932356215463936\/photo\/1",
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/vQgomU44aB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVa8aZrWEAAGr8l.jpg",
      "id_str" : "672932356093775872",
      "id" : 672932356093775872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVa8aZrWEAAGr8l.jpg",
      "sizes" : [ {
        "h" : 970,
        "resize" : "fit",
        "w" : 1293
      }, {
        "h" : 970,
        "resize" : "fit",
        "w" : 1293
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/vQgomU44aB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.365951, 4.960604 ]
  },
  "id_str" : "672932356215463936",
  "text" : "entree deluxe https:\/\/t.co\/vQgomU44aB",
  "id" : 672932356215463936,
  "created_at" : "2015-12-05 00:15:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Nathan Pearson",
      "screen_name" : "GenomeNathan",
      "indices" : [ 10, 23 ],
      "id_str" : "543876839",
      "id" : 543876839
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 24, 35 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672913996908003334",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36341329762001, 4.922014810149485 ]
  },
  "id_str" : "672918921335480320",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @GenomeNathan @openSNPorg I guess it\u2019s because it\u2019s taken from user given sex, not inferred from data.",
  "id" : 672918921335480320,
  "in_reply_to_status_id" : 672913996908003334,
  "created_at" : "2015-12-04 23:22:27 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/LbwBg0LZJe",
      "expanded_url" : "https:\/\/twitter.com\/GenomeNathan\/status\/672883310318755841",
      "display_url" : "twitter.com\/GenomeNathan\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36422693999999, 4.89758291 ]
  },
  "id_str" : "672912351931277313",
  "text" : "Wow, very nice PCA on openSNP data (amongst other data sources) https:\/\/t.co\/LbwBg0LZJe",
  "id" : 672912351931277313,
  "created_at" : "2015-12-04 22:56:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672867551966339072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36451177186793, 4.897724593221433 ]
  },
  "id_str" : "672867638176055300",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze \u2018interessant\u2019 ;)",
  "id" : 672867638176055300,
  "in_reply_to_status_id" : 672867551966339072,
  "created_at" : "2015-12-04 19:58:40 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672860742777970688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36771005118472, 4.899833487752749 ]
  },
  "id_str" : "672867456784965632",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze jetzt hast du mir spannendes Kopfkino gemacht \uD83D\uDE0A",
  "id" : 672867456784965632,
  "in_reply_to_status_id" : 672860742777970688,
  "created_at" : "2015-12-04 19:57:57 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/6J1hAl8PYX",
      "expanded_url" : "https:\/\/media4.giphy.com\/media\/OCMGLUo7d5jJ6\/200.gif",
      "display_url" : "media4.giphy.com\/media\/OCMGLUo7\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "672859784257921027",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3666518135484, 4.926366023723898 ]
  },
  "id_str" : "672860384576053248",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze \u201Cwas ist das?! Ein Sextoy f\u00FCr Ameisen?!\u201D https:\/\/t.co\/6J1hAl8PYX",
  "id" : 672860384576053248,
  "in_reply_to_status_id" : 672859784257921027,
  "created_at" : "2015-12-04 19:29:51 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672854863349444608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3666518135484, 4.926366023723898 ]
  },
  "id_str" : "672859814834384896",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor \uD83D\uDE07\uD83D\uDE04",
  "id" : 672859814834384896,
  "in_reply_to_status_id" : 672854863349444608,
  "created_at" : "2015-12-04 19:27:35 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672854863101992960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36664535948296, 4.926372729246435 ]
  },
  "id_str" : "672859714468913154",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg oh well, it\u2019s only forbidden if you get caught. \uD83D\uDE09",
  "id" : 672859714468913154,
  "in_reply_to_status_id" : 672854863101992960,
  "created_at" : "2015-12-04 19:27:11 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/Cl4n22xhpC",
      "expanded_url" : "http:\/\/www.machsmit.de\/img\/pool\/695x240\/2008-2008.jpg",
      "display_url" : "machsmit.de\/img\/pool\/695x2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "672850255264784384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36664535948296, 4.926372729246435 ]
  },
  "id_str" : "672859587704430593",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze https:\/\/t.co\/Cl4n22xhpC",
  "id" : 672859587704430593,
  "in_reply_to_status_id" : 672850255264784384,
  "created_at" : "2015-12-04 19:26:41 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672847790507220993",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36577561130036, 4.961199872200341 ]
  },
  "id_str" : "672849479737991168",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze that\u2019s code, right? \uD83D\uDE09",
  "id" : 672849479737991168,
  "in_reply_to_status_id" : 672847790507220993,
  "created_at" : "2015-12-04 18:46:31 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672811352684175364",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.33207694554853, 4.856277719485657 ]
  },
  "id_str" : "672838868354392064",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC sounds like the worst of both worlds ;)",
  "id" : 672838868354392064,
  "in_reply_to_status_id" : 672811352684175364,
  "created_at" : "2015-12-04 18:04:21 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/672838807272726529\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/D8xFxTRIhg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVZnU6BWUAAFqa1.jpg",
      "id_str" : "672838803208425472",
      "id" : 672838803208425472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVZnU6BWUAAFqa1.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/D8xFxTRIhg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.33207078764588, 4.856297047285434 ]
  },
  "id_str" : "672838807272726529",
  "text" : "Amsterdam, where the Spa has those helpful pictograms. Also, I think the last one wasn\u2019t here last time I visited\u2026 https:\/\/t.co\/D8xFxTRIhg",
  "id" : 672838807272726529,
  "created_at" : "2015-12-04 18:04:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.37115060619522, 4.962271015568039 ]
  },
  "id_str" : "672777060113375232",
  "text" : "Misread the tea box as \u2018Chai Latke\u2019 and thought I might be onto an interesting Hanukkah food idea.",
  "id" : 672777060113375232,
  "created_at" : "2015-12-04 13:58:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 4, 11 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/672763210060140544\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/l1BcbKrJfp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVYiksHXAAAV7fs.jpg",
      "id_str" : "672763208051130368",
      "id" : 672763208051130368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVYiksHXAAAV7fs.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/l1BcbKrJfp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36666296147962, 4.92666609585744 ]
  },
  "id_str" : "672763210060140544",
  "text" : "Ok, @malech, what are your Dutch colleagues doing that they need bars on their windows?! https:\/\/t.co\/l1BcbKrJfp",
  "id" : 672763210060140544,
  "created_at" : "2015-12-04 13:03:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672739538758955008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36606855796527, 4.9128008663106 ]
  },
  "id_str" : "672758776773128192",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC the worst is that this crap is taking over academia now as well :(",
  "id" : 672758776773128192,
  "in_reply_to_status_id" : 672739538758955008,
  "created_at" : "2015-12-04 12:46:06 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/672754698248691713\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/vCdl0bATAi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVYa1I7UwAI_QYt.jpg",
      "id_str" : "672754694570164226",
      "id" : 672754694570164226,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVYa1I7UwAI_QYt.jpg",
      "sizes" : [ {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/vCdl0bATAi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36602223870315, 4.912660004842822 ]
  },
  "id_str" : "672754698248691713",
  "text" : "How they deal with first world problems in Amsterdam https:\/\/t.co\/vCdl0bATAi",
  "id" : 672754698248691713,
  "created_at" : "2015-12-04 12:29:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/2Vm4f4ZHnR",
      "expanded_url" : "http:\/\/Academia.edu",
      "display_url" : "Academia.edu"
    }, {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/0ZUe89qqip",
      "expanded_url" : "https:\/\/twitter.com\/HLWiencko\/status\/672662264927887360",
      "display_url" : "twitter.com\/HLWiencko\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36598818303825, 4.912811417425595 ]
  },
  "id_str" : "672745699864391680",
  "text" : "Also: don\u2019t use https:\/\/t.co\/2Vm4f4ZHnR and ResearchGate for anything please. https:\/\/t.co\/0ZUe89qqip",
  "id" : 672745699864391680,
  "created_at" : "2015-12-04 11:54:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672591369848901632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36595717535608, 4.912840321103142 ]
  },
  "id_str" : "672743977716723713",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute you know I have trouble with the concept of privacy :p",
  "id" : 672743977716723713,
  "in_reply_to_status_id" : 672591369848901632,
  "created_at" : "2015-12-04 11:47:17 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    }, {
      "name" : "MakerBay",
      "screen_name" : "MakerBay",
      "indices" : [ 11, 20 ],
      "id_str" : "2917700821",
      "id" : 2917700821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672611554873995264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36595717535608, 4.912840321103142 ]
  },
  "id_str" : "672743405471035392",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds @MakerBay very cool, wish I could come by for those :)",
  "id" : 672743405471035392,
  "in_reply_to_status_id" : 672611554873995264,
  "created_at" : "2015-12-04 11:45:01 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Nix",
      "screen_name" : "diodenschein",
      "indices" : [ 0, 13 ],
      "id_str" : "54732697",
      "id" : 54732697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672576869674414080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36599978530068, 4.960961407055111 ]
  },
  "id_str" : "672577172322852864",
  "in_reply_to_user_id" : 54732697,
  "text" : "@diodenschein yep: \u2018let\u2019s not spend time with other people together\u2019",
  "id" : 672577172322852864,
  "in_reply_to_status_id" : 672576869674414080,
  "created_at" : "2015-12-04 00:44:28 +0000",
  "in_reply_to_screen_name" : "diodenschein",
  "in_reply_to_user_id_str" : "54732697",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3658300536659, 4.960706840651671 ]
  },
  "id_str" : "672575334374576130",
  "text" : "Back from the meeting of Introverts Anonymous.",
  "id" : 672575334374576130,
  "created_at" : "2015-12-04 00:37:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/nD2mZKfJuC",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/-16QEwhwhW\/",
      "display_url" : "instagram.com\/p\/-16QEwhwhW\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3624, 4.9042 ]
  },
  "id_str" : "672506145010024448",
  "text" : "Up there @ Carr\u00E9 Theatre https:\/\/t.co\/nD2mZKfJuC",
  "id" : 672506145010024448,
  "created_at" : "2015-12-03 20:02:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/oopOfJAuEC",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/hCIN8xDOeN3",
      "display_url" : "swarmapp.com\/c\/hCIN8xDOeN3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.37082524767297, 4.9006002087034 ]
  },
  "id_str" : "672494178878799873",
  "text" : "Mayor of the Hummus House \uD83C\uDF89 (@ HummusHouse in Amsterdam) https:\/\/t.co\/oopOfJAuEC",
  "id" : 672494178878799873,
  "created_at" : "2015-12-03 19:14:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.53910450176479, 6.863055545843078 ]
  },
  "id_str" : "672437691804491777",
  "text" : "3 hours in the passenger seat and this ugly csv is finally taken care of.",
  "id" : 672437691804491777,
  "created_at" : "2015-12-03 15:30:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.22907538865394, 8.651745153107475 ]
  },
  "id_str" : "672393697007427585",
  "text" : "And off to Amsterdam once again. \uD83D\uDE98",
  "id" : 672393697007427585,
  "created_at" : "2015-12-03 12:35:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 3, 10 ],
      "id_str" : "71654283",
      "id" : 71654283
    }, {
      "name" : "matthew braga",
      "screen_name" : "mattbraga",
      "indices" : [ 96, 106 ],
      "id_str" : "19092024",
      "id" : 19092024
    }, {
      "name" : "\u30AA\u30FC\u30C7\u30E5\u30DC\u30F3",
      "screen_name" : "Audubon",
      "indices" : [ 116, 124 ],
      "id_str" : "14491067",
      "id" : 14491067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/xkdAraGUHZ",
      "expanded_url" : "http:\/\/motherboard.vice.com\/read\/all-the-ways-birds-are-getting-screwed-by-climate-change",
      "display_url" : "motherboard.vice.com\/read\/all-the-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672197807370018816",
  "text" : "RT @arikia: All the Ways Birds Are Getting Screwed by Climate Change https:\/\/t.co\/xkdAraGUHZ by @mattbraga based on @audubon research #dive\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "matthew braga",
        "screen_name" : "mattbraga",
        "indices" : [ 84, 94 ],
        "id_str" : "19092024",
        "id" : 19092024
      }, {
        "name" : "\u30AA\u30FC\u30C7\u30E5\u30DC\u30F3",
        "screen_name" : "Audubon",
        "indices" : [ 104, 112 ],
        "id_str" : "14491067",
        "id" : 14491067
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "divestfrompalmoil",
        "indices" : [ 122, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/xkdAraGUHZ",
        "expanded_url" : "http:\/\/motherboard.vice.com\/read\/all-the-ways-birds-are-getting-screwed-by-climate-change",
        "display_url" : "motherboard.vice.com\/read\/all-the-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "672166113426427904",
    "text" : "All the Ways Birds Are Getting Screwed by Climate Change https:\/\/t.co\/xkdAraGUHZ by @mattbraga based on @audubon research #divestfrompalmoil",
    "id" : 672166113426427904,
    "created_at" : "2015-12-02 21:31:04 +0000",
    "user" : {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "protected" : false,
      "id_str" : "71654283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897255084073025537\/5uB8YwJG_normal.jpg",
      "id" : 71654283,
      "verified" : false
    }
  },
  "id" : 672197807370018816,
  "created_at" : "2015-12-02 23:37:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672132336834752513",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17678736013535, 8.6305447289441 ]
  },
  "id_str" : "672140083147993088",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick it\u2019s like \u2018getting the printer to work or writing another aligner\u2019 and we know the result.",
  "id" : 672140083147993088,
  "in_reply_to_status_id" : 672132336834752513,
  "created_at" : "2015-12-02 19:47:38 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHL Paket",
      "screen_name" : "DHLPaket",
      "indices" : [ 0, 9 ],
      "id_str" : "42414621",
      "id" : 42414621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17343275147791, 8.628015665697893 ]
  },
  "id_str" : "672113313971634176",
  "in_reply_to_user_id" : 42414621,
  "text" : "@DHLPaket k\u00F6nntet ihr JJD000390007070003745 rerouten?",
  "id" : 672113313971634176,
  "created_at" : "2015-12-02 18:01:15 +0000",
  "in_reply_to_screen_name" : "DHLPaket",
  "in_reply_to_user_id_str" : "42414621",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 0, 8 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672106961186500609",
  "geo" : { },
  "id_str" : "672108156953174016",
  "in_reply_to_user_id" : 454724555,
  "text" : "@marc_rr That\u2019s exactly why I answered \u201Eyou can\u2019t\u201C yesterday, when a student asked how he could access dbGAP\u2026",
  "id" : 672108156953174016,
  "in_reply_to_status_id" : 672106961186500609,
  "created_at" : "2015-12-02 17:40:46 +0000",
  "in_reply_to_screen_name" : "marc_rr",
  "in_reply_to_user_id_str" : "454724555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ga4gh",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672105900161789953",
  "geo" : { },
  "id_str" : "672106387376336896",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime Global Alliance for Good Hummus. Doesn\u2019t even require a switch of acronym. #ga4gh",
  "id" : 672106387376336896,
  "in_reply_to_status_id" : 672105900161789953,
  "created_at" : "2015-12-02 17:33:44 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 13, 27 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672100933791318016",
  "text" : "Misread that @OpenHumansOrg newsletter as \u201EOpen Hummus\u201C and now I\u2019m really hungry.",
  "id" : 672100933791318016,
  "created_at" : "2015-12-02 17:12:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672095929059704832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235054696293, 8.627515694125623 ]
  },
  "id_str" : "672096986246553600",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks go for it!",
  "id" : 672096986246553600,
  "in_reply_to_status_id" : 672095929059704832,
  "created_at" : "2015-12-02 16:56:23 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672071384638558208",
  "geo" : { },
  "id_str" : "672073253276528640",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds please don\u2019t become famous for the \u201EBauhinia killings\u201C after you go insane from living only amongst them.",
  "id" : 672073253276528640,
  "in_reply_to_status_id" : 672071384638558208,
  "created_at" : "2015-12-02 15:22:04 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/YpUC3bWVzK",
      "expanded_url" : "http:\/\/45.media.tumblr.com\/tumblr_m7n3buUgd91r2nm60o1_250.gif",
      "display_url" : "45.media.tumblr.com\/tumblr_m7n3buU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672071629854347264",
  "text" : "widespread horizontal gene transfer in tardigrades? https:\/\/t.co\/YpUC3bWVzK",
  "id" : 672071629854347264,
  "created_at" : "2015-12-02 15:15:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/jGSTbdH2ky",
      "expanded_url" : "http:\/\/www.googlesheepview.com",
      "display_url" : "googlesheepview.com"
    } ]
  },
  "geo" : { },
  "id_str" : "672069570480496640",
  "text" : "I spent an unreasonable amount of time, 1st on https:\/\/t.co\/jGSTbdH2ky &amp; then street-viewing through Iceland\u2019s Westfjords, photo-hunting \uD83D\uDC11.",
  "id" : 672069570480496640,
  "created_at" : "2015-12-02 15:07:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672067369846575104",
  "geo" : { },
  "id_str" : "672069052261646336",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute wait, what did I do wrongly now?! :D",
  "id" : 672069052261646336,
  "in_reply_to_status_id" : 672067369846575104,
  "created_at" : "2015-12-02 15:05:23 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/ukmcid7uvr",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Handk%C3%A4se",
      "display_url" : "en.wikipedia.org\/wiki\/Handk%C3%\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672043039490224128",
  "text" : "I feel a bit guilty. Now people in the office are having a battle on whether Durian or Handk\u00E4se smells worse. https:\/\/t.co\/ukmcid7uvr",
  "id" : 672043039490224128,
  "created_at" : "2015-12-02 13:22:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/7A8FB9Peyv",
      "expanded_url" : "https:\/\/twitter.com\/michaelhoffman\/status\/672040372583817217",
      "display_url" : "twitter.com\/michaelhoffman\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672040688113065984",
  "text" : "who said \u201Eanonymous\u201C peer-review wasn\u2019t broken? https:\/\/t.co\/7A8FB9Peyv",
  "id" : 672040688113065984,
  "created_at" : "2015-12-02 13:12:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/MOLEEh6mA2",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/12\/01\/style\/meet-tumblrs-15-year-old-secret-keeper.html",
      "display_url" : "nytimes.com\/2015\/12\/01\/sty\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672038220591439874",
  "text" : "About \u2018The Last Message Received\u2019 https:\/\/t.co\/MOLEEh6mA2",
  "id" : 672038220591439874,
  "created_at" : "2015-12-02 13:02:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Ben Edwards",
      "screen_name" : "lava_ice",
      "indices" : [ 40, 49 ],
      "id_str" : "26018679",
      "id" : 26018679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672035959693774848",
  "geo" : { },
  "id_str" : "672036678463262720",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich yep, you might want to follow @lava_ice for nice volcano tweets :D",
  "id" : 672036678463262720,
  "in_reply_to_status_id" : 672035959693774848,
  "created_at" : "2015-12-02 12:56:44 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/9mFbMxe6GA",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/22488007-island-on-fire",
      "display_url" : "goodreads.com\/book\/show\/2248\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "672023613843898370",
  "geo" : { },
  "id_str" : "672031211158683648",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich dazu sehr cool: https:\/\/t.co\/9mFbMxe6GA",
  "id" : 672031211158683648,
  "in_reply_to_status_id" : 672023613843898370,
  "created_at" : "2015-12-02 12:35:01 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672021787480358913",
  "geo" : { },
  "id_str" : "672030821340078080",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson that\u2019s why some people use zsh ;)",
  "id" : 672030821340078080,
  "in_reply_to_status_id" : 672021787480358913,
  "created_at" : "2015-12-02 12:33:28 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 8, 18 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Jack Scanlan",
      "screen_name" : "JackLScanlan",
      "indices" : [ 19, 32 ],
      "id_str" : "10342612",
      "id" : 10342612
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 33, 46 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672015370358808576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232135268835, 8.627522421592996 ]
  },
  "id_str" : "672018532721401856",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @Julie_B92 @JackLScanlan @PhilippBayer ah, I thought I had seen something like this :)",
  "id" : 672018532721401856,
  "in_reply_to_status_id" : 672015370358808576,
  "created_at" : "2015-12-02 11:44:38 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672004248499040256",
  "geo" : { },
  "id_str" : "672005148634411008",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 I will!",
  "id" : 672005148634411008,
  "in_reply_to_status_id" : 672004248499040256,
  "created_at" : "2015-12-02 10:51:27 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Erik Garrison",
      "screen_name" : "erikgarrison",
      "indices" : [ 7, 20 ],
      "id_str" : "95685725",
      "id" : 95685725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672004331982487552",
  "geo" : { },
  "id_str" : "672005052735844352",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @erikgarrison what do you mean by switches?",
  "id" : 672005052735844352,
  "in_reply_to_status_id" : 672004331982487552,
  "created_at" : "2015-12-02 10:51:04 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671988997850308608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238422529507, 8.627535609435593 ]
  },
  "id_str" : "672003303782416385",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 that comes 2 days too late. Had ~15 biology students learn the shell on Monday. :D",
  "id" : 672003303782416385,
  "in_reply_to_status_id" : 671988997850308608,
  "created_at" : "2015-12-02 10:44:07 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Jack Scanlan",
      "screen_name" : "JackLScanlan",
      "indices" : [ 11, 24 ],
      "id_str" : "10342612",
      "id" : 10342612
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 25, 38 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 39, 46 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672001908891099136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238540937236, 8.627534962178894 ]
  },
  "id_str" : "672002092786188288",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @JackLScanlan @PhilippBayer @sujaik looking forward to that. I\u2019m just toying around with the genome right now.",
  "id" : 672002092786188288,
  "in_reply_to_status_id" : 672001908891099136,
  "created_at" : "2015-12-02 10:39:18 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Jack Scanlan",
      "screen_name" : "JackLScanlan",
      "indices" : [ 11, 24 ],
      "id_str" : "10342612",
      "id" : 10342612
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 25, 38 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672001743971090432",
  "geo" : { },
  "id_str" : "672001854008647680",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @JackLScanlan @PhilippBayer okay, then it's just the assembly and other stuff. :)",
  "id" : 672001854008647680,
  "in_reply_to_status_id" : 672001743971090432,
  "created_at" : "2015-12-02 10:38:21 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Scanlan",
      "screen_name" : "JackLScanlan",
      "indices" : [ 0, 13 ],
      "id_str" : "10342612",
      "id" : 10342612
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 14, 24 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 25, 38 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672001449962811393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238540937236, 8.627534962178894 ]
  },
  "id_str" : "672001688480411648",
  "in_reply_to_user_id" : 10342612,
  "text" : "@JackLScanlan @Julie_B92 @PhilippBayer not sure whether it\u2019s raw reads.",
  "id" : 672001688480411648,
  "in_reply_to_status_id" : 672001449962811393,
  "created_at" : "2015-12-02 10:37:42 +0000",
  "in_reply_to_screen_name" : "JackLScanlan",
  "in_reply_to_user_id_str" : "10342612",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Scanlan",
      "screen_name" : "JackLScanlan",
      "indices" : [ 0, 13 ],
      "id_str" : "10342612",
      "id" : 10342612
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 14, 24 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 25, 38 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672001449962811393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238540937236, 8.627534962178894 ]
  },
  "id_str" : "672001638249439233",
  "in_reply_to_user_id" : 10342612,
  "text" : "@JackLScanlan @Julie_B92 @PhilippBayer i just looked at the genome, but there was some other data as well",
  "id" : 672001638249439233,
  "in_reply_to_status_id" : 672001449962811393,
  "created_at" : "2015-12-02 10:37:30 +0000",
  "in_reply_to_screen_name" : "JackLScanlan",
  "in_reply_to_user_id_str" : "10342612",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Jack Scanlan",
      "screen_name" : "JackLScanlan",
      "indices" : [ 11, 24 ],
      "id_str" : "10342612",
      "id" : 10342612
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 25, 38 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672001047389319168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238540937236, 8.627534962178894 ]
  },
  "id_str" : "672001363816017920",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @JackLScanlan @PhilippBayer but there\u2019s a download link for the genome given in the preprint? I downloaded the genome fasta today",
  "id" : 672001363816017920,
  "in_reply_to_status_id" : 672001047389319168,
  "created_at" : "2015-12-02 10:36:24 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671990538304925696",
  "text" : "Do you folks have some recommendation for dotted softcover notebooks?",
  "id" : 671990538304925696,
  "created_at" : "2015-12-02 09:53:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Garrison",
      "screen_name" : "erikgarrison",
      "indices" : [ 0, 13 ],
      "id_str" : "95685725",
      "id" : 95685725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671986593603915776",
  "geo" : { },
  "id_str" : "671990007754792964",
  "in_reply_to_user_id" : 95685725,
  "text" : "@erikgarrison I\u2019m not sure how Siri handles it. But I use it when I can\u2019t type myself (e.g. driving) &amp; largely want mid-sentence changes :)",
  "id" : 671990007754792964,
  "in_reply_to_status_id" : 671986593603915776,
  "created_at" : "2015-12-02 09:51:17 +0000",
  "in_reply_to_screen_name" : "erikgarrison",
  "in_reply_to_user_id_str" : "95685725",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Garrison",
      "screen_name" : "erikgarrison",
      "indices" : [ 0, 13 ],
      "id_str" : "95685725",
      "id" : 95685725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671985685772021760",
  "geo" : { },
  "id_str" : "671986028442484736",
  "in_reply_to_user_id" : 95685725,
  "text" : "@erikgarrison you could stop dictation, switch language, dictate again etc. But that\u2019s impractical for single foreign words.",
  "id" : 671986028442484736,
  "in_reply_to_status_id" : 671985685772021760,
  "created_at" : "2015-12-02 09:35:28 +0000",
  "in_reply_to_screen_name" : "erikgarrison",
  "in_reply_to_user_id_str" : "95685725",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Garrison",
      "screen_name" : "erikgarrison",
      "indices" : [ 0, 13 ],
      "id_str" : "95685725",
      "id" : 95685725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671985685772021760",
  "geo" : { },
  "id_str" : "671985906744729600",
  "in_reply_to_user_id" : 95685725,
  "text" : "@erikgarrison you can switch keyboards (and thus the language for dictation). But once it listens it sticks to one language as far as i know",
  "id" : 671985906744729600,
  "in_reply_to_status_id" : 671985685772021760,
  "created_at" : "2015-12-02 09:34:59 +0000",
  "in_reply_to_screen_name" : "erikgarrison",
  "in_reply_to_user_id_str" : "95685725",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Garrison",
      "screen_name" : "erikgarrison",
      "indices" : [ 3, 16 ],
      "id_str" : "95685725",
      "id" : 95685725
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 18, 34 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671982282358525952",
  "text" : "RT @erikgarrison: @gedankenstuecke It feels easier to talk to it in my non native languages! I must use simpler expressions. What a weird e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "671971953553592320",
    "geo" : { },
    "id_str" : "671981927021301760",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke It feels easier to talk to it in my non native languages! I must use simpler expressions. What a weird effect! 2\/2",
    "id" : 671981927021301760,
    "in_reply_to_status_id" : 671971953553592320,
    "created_at" : "2015-12-02 09:19:10 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Erik Garrison",
      "screen_name" : "erikgarrison",
      "protected" : false,
      "id_str" : "95685725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2208200726\/IwR0DADz_normal",
      "id" : 95685725,
      "verified" : false
    }
  },
  "id" : 671982282358525952,
  "created_at" : "2015-12-02 09:20:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Garrison",
      "screen_name" : "erikgarrison",
      "indices" : [ 3, 16 ],
      "id_str" : "95685725",
      "id" : 95685725
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 18, 34 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671982261479333888",
  "text" : "RT @erikgarrison: @gedankenstuecke When talking to myself I fall into local pronunciation and hilarious things come out of my phone's text \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "671971953553592320",
    "geo" : { },
    "id_str" : "671981475890372609",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke When talking to myself I fall into local pronunciation and hilarious things come out of my phone's text to speech 1\/2",
    "id" : 671981475890372609,
    "in_reply_to_status_id" : 671971953553592320,
    "created_at" : "2015-12-02 09:17:23 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Erik Garrison",
      "screen_name" : "erikgarrison",
      "protected" : false,
      "id_str" : "95685725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2208200726\/IwR0DADz_normal",
      "id" : 95685725,
      "verified" : false
    }
  },
  "id" : 671982261479333888,
  "created_at" : "2015-12-02 09:20:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Garrison",
      "screen_name" : "erikgarrison",
      "indices" : [ 0, 13 ],
      "id_str" : "95685725",
      "id" : 95685725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671981927021301760",
  "geo" : { },
  "id_str" : "671982245914259456",
  "in_reply_to_user_id" : 95685725,
  "text" : "@erikgarrison and then there\u2019s also the problem of sprinkling in English words when speaking German, which confuses the hell out of dict.",
  "id" : 671982245914259456,
  "in_reply_to_status_id" : 671981927021301760,
  "created_at" : "2015-12-02 09:20:26 +0000",
  "in_reply_to_screen_name" : "erikgarrison",
  "in_reply_to_user_id_str" : "95685725",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Garrison",
      "screen_name" : "erikgarrison",
      "indices" : [ 0, 13 ],
      "id_str" : "95685725",
      "id" : 95685725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671981927021301760",
  "geo" : { },
  "id_str" : "671982120915632128",
  "in_reply_to_user_id" : 95685725,
  "text" : "@erikgarrison yep, I noticed the same here. When trying to dictate German it often leads to hilarious results due to regionalisms.",
  "id" : 671982120915632128,
  "in_reply_to_status_id" : 671981927021301760,
  "created_at" : "2015-12-02 09:19:57 +0000",
  "in_reply_to_screen_name" : "erikgarrison",
  "in_reply_to_user_id_str" : "95685725",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Jack Scanlan",
      "screen_name" : "JackLScanlan",
      "indices" : [ 14, 27 ],
      "id_str" : "10342612",
      "id" : 10342612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/0qOVlSomAY",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/671791399671603200",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "671879865491054592",
  "geo" : { },
  "id_str" : "671975193389244416",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @JackLScanlan yep, saw it yesterday, see: https:\/\/t.co\/0qOVlSomAY",
  "id" : 671975193389244416,
  "in_reply_to_status_id" : 671879865491054592,
  "created_at" : "2015-12-02 08:52:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671973081066377216",
  "geo" : { },
  "id_str" : "671973333076992000",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch :D my guestimation was the job will take roughly 2 days to finish, given cluster load\/input data etc. Took ~43 hours.",
  "id" : 671973333076992000,
  "in_reply_to_status_id" : 671973081066377216,
  "created_at" : "2015-12-02 08:45:01 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671972228343406592",
  "geo" : { },
  "id_str" : "671972653960445952",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch yep, I think for those kinds of things you just develop a gut feeling which is more reliable than the estimator anyhow. :D",
  "id" : 671972653960445952,
  "in_reply_to_status_id" : 671972228343406592,
  "created_at" : "2015-12-02 08:42:20 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671971217054789632",
  "geo" : { },
  "id_str" : "671971953553592320",
  "in_reply_to_user_id" : 14286491,
  "text" : "Also: I\u2019m amazed how well it understands me murdering pronunciation of English words, even while Hebrew rap music playing in the background.",
  "id" : 671971953553592320,
  "in_reply_to_status_id" : 671971217054789632,
  "created_at" : "2015-12-02 08:39:33 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671971217054789632",
  "text" : "Gotta admit: By now I really love Siri. Just dictating location-based reminders to nudge other people about their progress is great.",
  "id" : 671971217054789632,
  "created_at" : "2015-12-02 08:36:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671865113444540416",
  "geo" : { },
  "id_str" : "671865219363147776",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute just doing those last graphs. And now \uD83D\uDC36\uD83D\uDCA4",
  "id" : 671865219363147776,
  "in_reply_to_status_id" : 671865113444540416,
  "created_at" : "2015-12-02 01:35:25 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671862305215406080",
  "geo" : { },
  "id_str" : "671864777271074816",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute i guess someone just failed on this end, with the \u201Egoing to bed\u201C-priority :D",
  "id" : 671864777271074816,
  "in_reply_to_status_id" : 671862305215406080,
  "created_at" : "2015-12-02 01:33:40 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/671864701555462144\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/dTpgLUNOBZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVLxYP6UwAE1lti.png",
      "id_str" : "671864693321940993",
      "id" : 671864693321940993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVLxYP6UwAE1lti.png",
      "sizes" : [ {
        "h" : 2245,
        "resize" : "fit",
        "w" : 4263
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1079,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/dTpgLUNOBZ"
    } ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671864701555462144",
  "text" : "My daily heart rate according to Apple Watch: the mean\/median\/max\/min distribution and over time. #quantifiedself https:\/\/t.co\/dTpgLUNOBZ",
  "id" : 671864701555462144,
  "created_at" : "2015-12-02 01:33:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671842485409341441",
  "geo" : { },
  "id_str" : "671843702566973440",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston should just regularly put out \u201Ewe\u2019re nearly done-ish\u201C",
  "id" : 671843702566973440,
  "in_reply_to_status_id" : 671842485409341441,
  "created_at" : "2015-12-02 00:09:55 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671841865918976001",
  "text" : "The status since ~38hs: \u00ABestimated remaining time: 0.0h\u00BB How bioinformatics time estimations give you trust issues.",
  "id" : 671841865918976001,
  "created_at" : "2015-12-02 00:02:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/R6Xg8x4VW3",
      "expanded_url" : "https:\/\/media3.giphy.com\/media\/7vABRNyFuCv84\/200.gif",
      "display_url" : "media3.giphy.com\/media\/7vABRNyF\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "671836691347415040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403648490987, 8.753414113386919 ]
  },
  "id_str" : "671837812497498112",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC https:\/\/t.co\/R6Xg8x4VW3",
  "id" : 671837812497498112,
  "in_reply_to_status_id" : 671836691347415040,
  "created_at" : "2015-12-01 23:46:31 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671834873762619392",
  "geo" : { },
  "id_str" : "671835217594818560",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC you\u2019re just proving that some people don\u2019t need weaponry in order to be dangerous ;)",
  "id" : 671835217594818560,
  "in_reply_to_status_id" : 671834873762619392,
  "created_at" : "2015-12-01 23:36:12 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theshelf",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671825594464804868",
  "text" : "\u00ABIf you put Shakespeare in a room and made him write for 10 hours a day, year after year, eventually he might sound like a monkey\u00BB #theshelf",
  "id" : 671825594464804868,
  "created_at" : "2015-12-01 22:57:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671812830581170176",
  "geo" : { },
  "id_str" : "671813366864855040",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC as long as you\u2019re not carrying live ammunition with it I\u2019d also go with the tits. ;)",
  "id" : 671813366864855040,
  "in_reply_to_status_id" : 671812830581170176,
  "created_at" : "2015-12-01 22:09:23 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671810995527000064",
  "geo" : { },
  "id_str" : "671811550173339648",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC i can\u2019t decide which of the things would be more intimidating.",
  "id" : 671811550173339648,
  "in_reply_to_status_id" : 671810995527000064,
  "created_at" : "2015-12-01 22:02:09 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671808904968413184",
  "geo" : { },
  "id_str" : "671810463940943872",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC which means the background explosions are a bit smaller? ;)",
  "id" : 671810463940943872,
  "in_reply_to_status_id" : 671808904968413184,
  "created_at" : "2015-12-01 21:57:50 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/gWGm9gsqr2",
      "expanded_url" : "https:\/\/twitter.com\/PhytophthoraLab\/status\/671793471712190465",
      "display_url" : "twitter.com\/PhytophthoraLa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671807099752554497",
  "text" : "But everyone knows one way or another to hack it. At least there\u2019s that. https:\/\/t.co\/gWGm9gsqr2",
  "id" : 671807099752554497,
  "created_at" : "2015-12-01 21:44:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/chSePrcRPl",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/1755-0998.12463\/abstract",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/17\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "671782511522029572",
  "geo" : { },
  "id_str" : "671791399671603200",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik good point on how stoichiometry can drive assemblies in the wrong direction. Saw similar effect in my work: https:\/\/t.co\/chSePrcRPl",
  "id" : 671791399671603200,
  "in_reply_to_status_id" : 671782511522029572,
  "created_at" : "2015-12-01 20:42:05 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Skelton",
      "screen_name" : "chadskelton",
      "indices" : [ 3, 15 ],
      "id_str" : "17533332",
      "id" : 17533332
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/chadskelton\/status\/671742138598612996\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/o8C1gz3XUs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVKB6mPUsAAw6io.png",
      "id_str" : "671742138128838656",
      "id" : 671742138128838656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVKB6mPUsAAw6io.png",
      "sizes" : [ {
        "h" : 298,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/o8C1gz3XUs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/60Q5yQnqTe",
      "expanded_url" : "http:\/\/www.chadskelton.com\/2015\/12\/in-defence-of-data-visualization-rules.html",
      "display_url" : "chadskelton.com\/2015\/12\/in-def\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671748465395920897",
  "text" : "RT @chadskelton: New blog post: \"In defence of data visualization rules.\" https:\/\/t.co\/60Q5yQnqTe https:\/\/t.co\/o8C1gz3XUs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/chadskelton\/status\/671742138598612996\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/o8C1gz3XUs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVKB6mPUsAAw6io.png",
        "id_str" : "671742138128838656",
        "id" : 671742138128838656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVKB6mPUsAAw6io.png",
        "sizes" : [ {
          "h" : 298,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 298,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 298,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 298,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/o8C1gz3XUs"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/60Q5yQnqTe",
        "expanded_url" : "http:\/\/www.chadskelton.com\/2015\/12\/in-defence-of-data-visualization-rules.html",
        "display_url" : "chadskelton.com\/2015\/12\/in-def\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "671742138598612996",
    "text" : "New blog post: \"In defence of data visualization rules.\" https:\/\/t.co\/60Q5yQnqTe https:\/\/t.co\/o8C1gz3XUs",
    "id" : 671742138598612996,
    "created_at" : "2015-12-01 17:26:20 +0000",
    "user" : {
      "name" : "Chad Skelton",
      "screen_name" : "chadskelton",
      "protected" : false,
      "id_str" : "17533332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3574318801\/a7e1b63c88939679248e05406a747124_normal.jpeg",
      "id" : 17533332,
      "verified" : false
    }
  },
  "id" : 671748465395920897,
  "created_at" : "2015-12-01 17:51:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Wei\u00DF",
      "screen_name" : "pfadintegral",
      "indices" : [ 0, 13 ],
      "id_str" : "102668707",
      "id" : 102668707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/QYN7tscBzb",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=a5k6X9HLyvM",
      "display_url" : "youtube.com\/watch?v=a5k6X9\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "671722581104398336",
  "geo" : { },
  "id_str" : "671723782881591297",
  "in_reply_to_user_id" : 102668707,
  "text" : "@pfadintegral gute Tradition &lt;3 https:\/\/t.co\/QYN7tscBzb",
  "id" : 671723782881591297,
  "in_reply_to_status_id" : 671722581104398336,
  "created_at" : "2015-12-01 16:13:24 +0000",
  "in_reply_to_screen_name" : "pfadintegral",
  "in_reply_to_user_id_str" : "102668707",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "dEUS",
      "screen_name" : "dEUSbe",
      "indices" : [ 7, 14 ],
      "id_str" : "20078711",
      "id" : 20078711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671689079646502912",
  "geo" : { },
  "id_str" : "671690300381929473",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @dEUSbe so taking forbidden items is fine as long as I\u2019m convinced? :P",
  "id" : 671690300381929473,
  "in_reply_to_status_id" : 671689079646502912,
  "created_at" : "2015-12-01 14:00:21 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "dEUS",
      "screen_name" : "dEUSbe",
      "indices" : [ 7, 14 ],
      "id_str" : "20078711",
      "id" : 20078711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/pzIreWqptU",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=5WD7Oh6GRiE",
      "display_url" : "youtube.com\/watch?v=5WD7Oh\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "671684336916275200",
  "geo" : { },
  "id_str" : "671687606640447488",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @dEUSbe and what about https:\/\/t.co\/pzIreWqptU ?",
  "id" : 671687606640447488,
  "in_reply_to_status_id" : 671684336916275200,
  "created_at" : "2015-12-01 13:49:39 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671673906995068928",
  "text" : "\u00ABCan I ask you something about the nano text editor?\u00BB \u2013 \u00ABSure, the answer is: Use vim!\u00BB",
  "id" : 671673906995068928,
  "created_at" : "2015-12-01 12:55:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671664148162486272",
  "geo" : { },
  "id_str" : "671664406862954497",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich yep, took us some practice here today :D",
  "id" : 671664406862954497,
  "in_reply_to_status_id" : 671664148162486272,
  "created_at" : "2015-12-01 12:17:28 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671658055130554370",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232990175121, 8.62752775896342 ]
  },
  "id_str" : "671658248651612160",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC even if the outfits would be a good fit to your style :p",
  "id" : 671658248651612160,
  "in_reply_to_status_id" : 671658055130554370,
  "created_at" : "2015-12-01 11:52:59 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/GTVddMaPFe",
      "expanded_url" : "https:\/\/media3.giphy.com\/media\/xTiTnA4QzNCtGdA2OI\/200.gif",
      "display_url" : "media3.giphy.com\/media\/xTiTnA4Q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "671655479794409472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232174948039, 8.627528070255417 ]
  },
  "id_str" : "671656532245946368",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC much better than https:\/\/t.co\/GTVddMaPFe ;)",
  "id" : 671656532245946368,
  "in_reply_to_status_id" : 671655479794409472,
  "created_at" : "2015-12-01 11:46:10 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/L9m5e8NTds",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=jgX2q9WPoqo",
      "display_url" : "youtube.com\/watch?v=jgX2q9\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "671644779046916097",
  "geo" : { },
  "id_str" : "671644974627340288",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich see the comments here https:\/\/t.co\/L9m5e8NTds ;)",
  "id" : 671644974627340288,
  "in_reply_to_status_id" : 671644779046916097,
  "created_at" : "2015-12-01 11:00:15 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671642633790443520",
  "geo" : { },
  "id_str" : "671643877963636736",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot now I sounded like someone poisoned me and I was trying to name the poisoner with my dying breath.",
  "id" : 671643877963636736,
  "in_reply_to_status_id" : 671642633790443520,
  "created_at" : "2015-12-01 10:55:53 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671641042630918144",
  "geo" : { },
  "id_str" : "671642090393194496",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot ich habs probiert und jetzt schauen mich meine Kollegen seltsam an :p",
  "id" : 671642090393194496,
  "in_reply_to_status_id" : 671641042630918144,
  "created_at" : "2015-12-01 10:48:47 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671639560691011584",
  "geo" : { },
  "id_str" : "671640826506801152",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot ph\u1EDFntastisch :D",
  "id" : 671640826506801152,
  "in_reply_to_status_id" : 671639560691011584,
  "created_at" : "2015-12-01 10:43:46 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 92, 108 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/UH2iqp4WpJ",
      "expanded_url" : "http:\/\/www.thekitchn.com\/faux-fuh-watch-this-video-never-mispronounce-pho-again-196227",
      "display_url" : "thekitchn.com\/faux-fuh-watch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671638778780471296",
  "text" : "RT @Lobot: Watch this video and never mispronounce \"Pho\" again. https:\/\/t.co\/UH2iqp4WpJ via @gedankenstuecke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 81, 97 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/UH2iqp4WpJ",
        "expanded_url" : "http:\/\/www.thekitchn.com\/faux-fuh-watch-this-video-never-mispronounce-pho-again-196227",
        "display_url" : "thekitchn.com\/faux-fuh-watch\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "671638162784043008",
    "text" : "Watch this video and never mispronounce \"Pho\" again. https:\/\/t.co\/UH2iqp4WpJ via @gedankenstuecke",
    "id" : 671638162784043008,
    "created_at" : "2015-12-01 10:33:11 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 671638778780471296,
  "created_at" : "2015-12-01 10:35:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671638162784043008",
  "geo" : { },
  "id_str" : "671638726498525184",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Ph\u1EDF :p",
  "id" : 671638726498525184,
  "in_reply_to_status_id" : 671638162784043008,
  "created_at" : "2015-12-01 10:35:25 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 0, 11 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/oR9WrXfxwY",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Tetrahedron_in_Bottrop",
      "display_url" : "en.wikipedia.org\/wiki\/Tetrahedr\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "671634855994724352",
  "geo" : { },
  "id_str" : "671635168977887232",
  "in_reply_to_user_id" : 20342875,
  "text" : "@LouWoodley they featured https:\/\/t.co\/oR9WrXfxwY which is probably only interesting if there\u2019s indeed some treasure hidden underneath it.",
  "id" : 671635168977887232,
  "in_reply_to_status_id" : 671634855994724352,
  "created_at" : "2015-12-01 10:21:17 +0000",
  "in_reply_to_screen_name" : "LouWoodley",
  "in_reply_to_user_id_str" : "20342875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671634556554973185",
  "text" : "My travel photo calendar at work is weird in the selection of \u2018notable\u2019 destinations it features: Iceland, Cichen Itz\u00E1, Paris, Bottrop.",
  "id" : 671634556554973185,
  "created_at" : "2015-12-01 10:18:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671625578437607424",
  "geo" : { },
  "id_str" : "671630439304531968",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC the outfit should fit the event. ;)",
  "id" : 671630439304531968,
  "in_reply_to_status_id" : 671625578437607424,
  "created_at" : "2015-12-01 10:02:29 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 57, 70 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/UwT6tGTkiN",
      "expanded_url" : "http:\/\/factually.gizmodo.com\/study-some-deepak-chopra-tweets-are-indistinguishable-1745338066",
      "display_url" : "factually.gizmodo.com\/study-some-dee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671629586480947200",
  "text" : "So, it\u2019s now scientifically proven that \u201Esome\u201C tweets of @DeepakChopra are \u201Epseudo-profound bullshit\u201C. \uD83D\uDD2C\uD83D\uDCCA https:\/\/t.co\/UwT6tGTkiN",
  "id" : 671629586480947200,
  "created_at" : "2015-12-01 09:59:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Carpentry",
      "screen_name" : "datacarpentry",
      "indices" : [ 29, 43 ],
      "id_str" : "2493407430",
      "id" : 2493407430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/E7bQQW0YlS",
      "expanded_url" : "http:\/\/www.datacarpentry.org\/blog\/associate-director-posting\/",
      "display_url" : "datacarpentry.org\/blog\/associate\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671625701943058432",
  "text" : "If you\u2019re looking for a job, @datacarpentry is hiring an Associate Director: https:\/\/t.co\/E7bQQW0YlS",
  "id" : 671625701943058432,
  "created_at" : "2015-12-01 09:43:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671624061278121984",
  "geo" : { },
  "id_str" : "671625093492133888",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC until then I didn\u2019t know how hard it is to find explosion gifs featuring women walking away. At least if they should be dressed m)",
  "id" : 671625093492133888,
  "in_reply_to_status_id" : 671624061278121984,
  "created_at" : "2015-12-01 09:41:15 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/5RFiLy9az4",
      "expanded_url" : "http:\/\/2.bp.blogspot.com\/-2cueIB0k7tw\/UyfEPSN5C4I\/AAAAAAAAGAc\/i4VgCik-300\/s1600\/tumblr_mrak5eAh8Z1qih3ojo2_500.gif",
      "display_url" : "2.bp.blogspot.com\/-2cueIB0k7tw\/U\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "671616719018946560",
  "geo" : { },
  "id_str" : "671617191092076544",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC https:\/\/t.co\/5RFiLy9az4 ;)",
  "id" : 671617191092076544,
  "in_reply_to_status_id" : 671616719018946560,
  "created_at" : "2015-12-01 09:09:51 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671615924307402752",
  "geo" : { },
  "id_str" : "671616433940492288",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC \u201Ecouldn\u2019t be bothered\u201C sounds much cooler though ;)",
  "id" : 671616433940492288,
  "in_reply_to_status_id" : 671615924307402752,
  "created_at" : "2015-12-01 09:06:50 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/GO6myF6kFm",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/671607557182595072",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "671607557182595072",
  "geo" : { },
  "id_str" : "671608736432132096",
  "in_reply_to_user_id" : 14286491,
  "text" : "In other words: If you\u2019re an openSNP user you should have gotten an invite to a survey we\u2019d love you to take. https:\/\/t.co\/GO6myF6kFm",
  "id" : 671608736432132096,
  "in_reply_to_status_id" : 671607557182595072,
  "created_at" : "2015-12-01 08:36:15 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671607557182595072",
  "text" : "\u00ABHow carefully did you read the terms and conditions for sharing data while registering on\u00A0openSNP?\u00BB Uhm, somewhat?",
  "id" : 671607557182595072,
  "created_at" : "2015-12-01 08:31:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671503551592558592",
  "geo" : { },
  "id_str" : "671504468513566720",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC oh, this is why people subtweet",
  "id" : 671504468513566720,
  "in_reply_to_status_id" : 671503551592558592,
  "created_at" : "2015-12-01 01:41:55 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/DUwxAtSdan",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=AykZO_EamiI",
      "display_url" : "youtube.com\/watch?v=AykZO_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671504218914750464",
  "text" : "\u05DC\u05DE\u05D4 \u05DC\u05D0 \u05E2\u05DB\u05E9\u05D9\u05D5 https:\/\/t.co\/DUwxAtSdan",
  "id" : 671504218914750464,
  "created_at" : "2015-12-01 01:40:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/KS9UldMfpv",
      "expanded_url" : "http:\/\/www.gifbin.com\/bin\/072010\/1279705457_locker-dominos.gif",
      "display_url" : "gifbin.com\/bin\/072010\/127\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671499937633333248",
  "text" : "working with badly formatted csv files https:\/\/t.co\/KS9UldMfpv",
  "id" : 671499937633333248,
  "created_at" : "2015-12-01 01:23:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]