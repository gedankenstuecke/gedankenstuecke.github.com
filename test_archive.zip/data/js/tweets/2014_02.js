Grailbird.data.tweets_2014_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/lqoZJfOdct",
      "expanded_url" : "http:\/\/www.raspberrypi.org\/archives\/6299",
      "display_url" : "raspberrypi.org\/archives\/6299"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009625958, 8.28297026 ]
  },
  "id_str" : "439523450097795072",
  "text" : "Oh, Raspberry Pi is paying $10,000 for optimizing their q3config.cfg so Q3A will run w\/ 125 fps! http:\/\/t.co\/lqoZJfOdct",
  "id" : 439523450097795072,
  "created_at" : "2014-02-28 22:12:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard E. Lenski",
      "screen_name" : "RELenski",
      "indices" : [ 3, 12 ],
      "id_str" : "1676175931",
      "id" : 1676175931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/vjh1sf6sdE",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/02\/28\/opinion\/when-may-i-shoot-a-student.html",
      "display_url" : "nytimes.com\/2014\/02\/28\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439517625434251264",
  "text" : "RT @RELenski: On-Target Op-Ed from NY Times: \"When May I Shoot a Student\" http:\/\/t.co\/vjh1sf6sdE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/vjh1sf6sdE",
        "expanded_url" : "http:\/\/www.nytimes.com\/2014\/02\/28\/opinion\/when-may-i-shoot-a-student.html",
        "display_url" : "nytimes.com\/2014\/02\/28\/opi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "439516602925461504",
    "text" : "On-Target Op-Ed from NY Times: \"When May I Shoot a Student\" http:\/\/t.co\/vjh1sf6sdE",
    "id" : 439516602925461504,
    "created_at" : "2014-02-28 21:44:58 +0000",
    "user" : {
      "name" : "Richard E. Lenski",
      "screen_name" : "RELenski",
      "protected" : false,
      "id_str" : "1676175931",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000308561492\/551f971caf79be291e28933aa3be3616_normal.png",
      "id" : 1676175931,
      "verified" : false
    }
  },
  "id" : 439517625434251264,
  "created_at" : "2014-02-28 21:49:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/Q55RsQ0Htz",
      "expanded_url" : "http:\/\/tabs.ultimate-guitar.com\/d\/dire_straits\/romeo_and_juliet_ver5_tab.htm",
      "display_url" : "tabs.ultimate-guitar.com\/d\/dire_straits\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "439498394600734721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009625958, 8.28297026 ]
  },
  "id_str" : "439502412391649281",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich das geht, aber das klingt auch nicht soo schlecht http:\/\/t.co\/Q55RsQ0Htz",
  "id" : 439502412391649281,
  "in_reply_to_status_id" : 439498394600734721,
  "created_at" : "2014-02-28 20:48:35 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/QXvWGma3fb",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=89bcFDlP5rw",
      "display_url" : "youtube.com\/watch?v=89bcFD\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009625958, 8.28297026 ]
  },
  "id_str" : "439498033420853248",
  "text" : "do want http:\/\/t.co\/QXvWGma3fb",
  "id" : 439498033420853248,
  "created_at" : "2014-02-28 20:31:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439351435315380225",
  "text" : "\u00ABYou did the emergency procedures for the next blackout?\u00BB\u2013\u00ABYes, all workstations will play the Benny Hill theme once we're on battery power\u00BB",
  "id" : 439351435315380225,
  "created_at" : "2014-02-28 10:48:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/JcAZ4UDzFg",
      "expanded_url" : "http:\/\/www.livescience.com\/43726-bering-strait-populations-lived.html",
      "display_url" : "livescience.com\/43726-bering-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439345719586344961",
  "text" : "Humans May Have Been Stuck on Bering Strait for 10,000 Years http:\/\/t.co\/JcAZ4UDzFg",
  "id" : 439345719586344961,
  "created_at" : "2014-02-28 10:25:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/xyUQlMdjNw",
      "expanded_url" : "http:\/\/i.imgur.com\/bv67RGV.jpg",
      "display_url" : "i.imgur.com\/bv67RGV.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "439341252795199488",
  "text" : "drive http:\/\/t.co\/xyUQlMdjNw",
  "id" : 439341252795199488,
  "created_at" : "2014-02-28 10:08:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pablo Barrantes",
      "screen_name" : "jpablobr",
      "indices" : [ 0, 9 ],
      "id_str" : "20365288",
      "id" : 20365288
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/52hd6NVsDb",
      "expanded_url" : "https:\/\/www.goodreads.com\/user\/show\/5925863-bastian-greshake",
      "display_url" : "goodreads.com\/user\/show\/5925\u2026"
    }, {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/wWTIIRShr1",
      "expanded_url" : "https:\/\/www.goodreads.com\/user\/show\/8325737-philipp",
      "display_url" : "goodreads.com\/user\/show\/8325\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "439337590500507648",
  "geo" : { },
  "id_str" : "439338392992878592",
  "in_reply_to_user_id" : 20365288,
  "text" : "@jpablobr @PhilippBayer eg https:\/\/t.co\/52hd6NVsDb &amp; https:\/\/t.co\/wWTIIRShr1",
  "id" : 439338392992878592,
  "in_reply_to_status_id" : 439337590500507648,
  "created_at" : "2014-02-28 09:56:50 +0000",
  "in_reply_to_screen_name" : "jpablobr",
  "in_reply_to_user_id_str" : "20365288",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pablo Barrantes",
      "screen_name" : "jpablobr",
      "indices" : [ 0, 9 ],
      "id_str" : "20365288",
      "id" : 20365288
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 16, 29 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439337590500507648",
  "geo" : { },
  "id_str" : "439338325867249664",
  "in_reply_to_user_id" : 20365288,
  "text" : "@jpablobr cool! @PhilippBayer probably told you, but if you see something on our goodreads profiles that you want: let us know. :)",
  "id" : 439338325867249664,
  "in_reply_to_status_id" : 439337590500507648,
  "created_at" : "2014-02-28 09:56:34 +0000",
  "in_reply_to_screen_name" : "jpablobr",
  "in_reply_to_user_id_str" : "20365288",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Pablo Barrantes",
      "screen_name" : "jpablobr",
      "indices" : [ 23, 32 ],
      "id_str" : "20365288",
      "id" : 20365288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439336508596572161",
  "geo" : { },
  "id_str" : "439336757327585280",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nice, hi @jpablobr. Glad to see that the community grows :)",
  "id" : 439336757327585280,
  "in_reply_to_status_id" : 439336508596572161,
  "created_at" : "2014-02-28 09:50:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/9JVQAjz6Lm",
      "expanded_url" : "http:\/\/www.rockpapershotgun.com\/2014\/02\/27\/shadowrun-returns-dragonfall-review\/",
      "display_url" : "rockpapershotgun.com\/2014\/02\/27\/sha\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1581898125, 8.5839528413 ]
  },
  "id_str" : "439309922095099904",
  "text" : "Looks like I will give the Berlin campaign of Shadowrun Returns a chance. http:\/\/t.co\/9JVQAjz6Lm",
  "id" : 439309922095099904,
  "created_at" : "2014-02-28 08:03:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/jQ42vnhkvO",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plos\/blogs\/main\/~3\/SDRf9numUSM\/",
      "display_url" : "feeds.plos.org\/~r\/plos\/blogs\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439306861637296128",
  "text" : "Disambiguation with ORCID at PLOS http:\/\/t.co\/jQ42vnhkvO",
  "id" : 439306861637296128,
  "created_at" : "2014-02-28 07:51:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Simpson",
      "screen_name" : "jaredtsimpson",
      "indices" : [ 3, 17 ],
      "id_str" : "74599038",
      "id" : 74599038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/92R1wPHR7k",
      "expanded_url" : "http:\/\/googleresearch.blogspot.ca\/2014\/02\/google-joins-global-alliance-for.html",
      "display_url" : "googleresearch.blogspot.ca\/2014\/02\/google\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439197636969889793",
  "text" : "RT @jaredtsimpson: Google joins the Global Alliance for genomics and health: http:\/\/t.co\/92R1wPHR7k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/92R1wPHR7k",
        "expanded_url" : "http:\/\/googleresearch.blogspot.ca\/2014\/02\/google-joins-global-alliance-for.html",
        "display_url" : "googleresearch.blogspot.ca\/2014\/02\/google\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "439196840387280896",
    "text" : "Google joins the Global Alliance for genomics and health: http:\/\/t.co\/92R1wPHR7k",
    "id" : 439196840387280896,
    "created_at" : "2014-02-28 00:34:21 +0000",
    "user" : {
      "name" : "Jared Simpson",
      "screen_name" : "jaredtsimpson",
      "protected" : false,
      "id_str" : "74599038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3502968604\/c3e5abff8694fd290bf308f24a0a1a3a_normal.jpeg",
      "id" : 74599038,
      "verified" : false
    }
  },
  "id" : 439197636969889793,
  "created_at" : "2014-02-28 00:37:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/uiYvCkSdkk",
      "expanded_url" : "http:\/\/s3.amazonaws.com\/dk-production\/images\/61390\/large\/motivational-funny-posters-3-18_1_.jpg?1386876101",
      "display_url" : "s3.amazonaws.com\/dk-production\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "439176377028587520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009544336, 8.282954342 ]
  },
  "id_str" : "439178385139703808",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot so hot, very burn http:\/\/t.co\/uiYvCkSdkk",
  "id" : 439178385139703808,
  "in_reply_to_status_id" : 439176377028587520,
  "created_at" : "2014-02-27 23:21:01 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "General Boles",
      "screen_name" : "GeneralBoles",
      "indices" : [ 3, 16 ],
      "id_str" : "1288271136",
      "id" : 1288271136
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GeneralBoles\/status\/439162520339636224\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/vFlKVfxXG0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bhg3_EfCYAAa5XN.jpg",
      "id_str" : "439162520343830528",
      "id" : 439162520343830528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bhg3_EfCYAAa5XN.jpg",
      "sizes" : [ {
        "h" : 351,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/vFlKVfxXG0"
    } ],
    "hashtags" : [ {
      "text" : "Poonami",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439175321083199488",
  "text" : "RT @GeneralBoles: Apoocalypse Now #Poonami http:\/\/t.co\/vFlKVfxXG0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GeneralBoles\/status\/439162520339636224\/photo\/1",
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/vFlKVfxXG0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bhg3_EfCYAAa5XN.jpg",
        "id_str" : "439162520343830528",
        "id" : 439162520343830528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bhg3_EfCYAAa5XN.jpg",
        "sizes" : [ {
          "h" : 351,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 351,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 351,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 351,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/vFlKVfxXG0"
      } ],
      "hashtags" : [ {
        "text" : "Poonami",
        "indices" : [ 16, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439162520339636224",
    "text" : "Apoocalypse Now #Poonami http:\/\/t.co\/vFlKVfxXG0",
    "id" : 439162520339636224,
    "created_at" : "2014-02-27 22:17:58 +0000",
    "user" : {
      "name" : "General Boles",
      "screen_name" : "GeneralBoles",
      "protected" : false,
      "id_str" : "1288271136",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822440320398950400\/S8RrCKhK_normal.jpg",
      "id" : 1288271136,
      "verified" : false
    }
  },
  "id" : 439175321083199488,
  "created_at" : "2014-02-27 23:08:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/v6TUs4kJti",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/4bWWKmUnn5E4\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/4bWWKmUn\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "439173324040863744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095473314, 8.2829148529 ]
  },
  "id_str" : "439174794169581568",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot my typical experience w\/ you http:\/\/t.co\/v6TUs4kJti",
  "id" : 439174794169581568,
  "in_reply_to_status_id" : 439173324040863744,
  "created_at" : "2014-02-27 23:06:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/lah1fSdbOl",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/03\/02\/magazine\/the-mammoth-cometh.html?_r=0",
      "display_url" : "nytimes.com\/2014\/03\/02\/mag\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009609568, 8.28283381 ]
  },
  "id_str" : "439173508615393280",
  "text" : "\u00ABThe Mammoth Cometh\u00BB long read on de-extinction http:\/\/t.co\/lah1fSdbOl",
  "id" : 439173508615393280,
  "created_at" : "2014-02-27 23:01:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439167773865172993",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439168398204100610",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich not to brag, aber 6.35 mm Klinke won\u2019t cut it.",
  "id" : 439168398204100610,
  "in_reply_to_status_id" : 439167773865172993,
  "created_at" : "2014-02-27 22:41:20 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439167557153853440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439167764532826112",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot bist du erregt oder ist das wieder nur Angstschweiss?",
  "id" : 439167764532826112,
  "in_reply_to_status_id" : 439167557153853440,
  "created_at" : "2014-02-27 22:38:49 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 9, 15 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439167607699419136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439167694810906626",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju @Lobot don\u2019t microwave \u00D6tzi!",
  "id" : 439167694810906626,
  "in_reply_to_status_id" : 439167607699419136,
  "created_at" : "2014-02-27 22:38:32 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spektrum.de",
      "screen_name" : "spektrum_de",
      "indices" : [ 4, 16 ],
      "id_str" : "40201139",
      "id" : 40201139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/wEHCXPOcxE",
      "expanded_url" : "http:\/\/www.spektrum.de\/alias\/totenkulte\/10-mumien-die-sie-unbedingt-kennen-sollten\/1241379",
      "display_url" : "spektrum.de\/alias\/totenkul\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439167045281017857",
  "text" : "Oh, @spektrum_de goes Buzzfeed: \u00AB10 Mumien, die Sie unbedingt kennen sollten\u00BB http:\/\/t.co\/wEHCXPOcxE",
  "id" : 439167045281017857,
  "created_at" : "2014-02-27 22:35:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439165497708658688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439165693125480448",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ah, na dann ist\u2019s kein Problem.",
  "id" : 439165693125480448,
  "in_reply_to_status_id" : 439165497708658688,
  "created_at" : "2014-02-27 22:30:35 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439164717014482944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439165246822158336",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot Nachmittage sind bei mir schwieriger. Wochenends?",
  "id" : 439165246822158336,
  "in_reply_to_status_id" : 439164717014482944,
  "created_at" : "2014-02-27 22:28:48 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 10, 19 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439164679332823041",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439164937022500864",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @JP_Stich f\u00FCrs Romeo &amp; Juliet-Intro meinte ich.",
  "id" : 439164937022500864,
  "in_reply_to_status_id" : 439164679332823041,
  "created_at" : "2014-02-27 22:27:34 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/FblMbgwrae",
      "expanded_url" : "http:\/\/www.benfoster.co.nz\/goldenboy.html",
      "display_url" : "benfoster.co.nz\/goldenboy.html"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439163749682143232",
  "text" : "Maybe it wouldn\u2019t hurt to have some art around after all, at least once we move to a bigger flat. http:\/\/t.co\/FblMbgwrae",
  "id" : 439163749682143232,
  "created_at" : "2014-02-27 22:22:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439158886063697920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439159391213060096",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich aye, wobei iirc ist das Ding Stereo und man sollte gezielt L\/R ansprechen k\u00F6nnen.",
  "id" : 439159391213060096,
  "in_reply_to_status_id" : 439158886063697920,
  "created_at" : "2014-02-27 22:05:32 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439157577726054400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439157938952077314",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich oder so. Ich schleife meine immer durch ein GT-Irgendwas in den Acoustic Amp, das ist ok.",
  "id" : 439157938952077314,
  "in_reply_to_status_id" : 439157577726054400,
  "created_at" : "2014-02-27 21:59:46 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439156787565314048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439157194672865281",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ok, wenn du das auf regul\u00E4re Klinke rausbekommst k\u00F6nnte ich dich mit in den Acoustic Amp stecken.",
  "id" : 439157194672865281,
  "in_reply_to_status_id" : 439156787565314048,
  "created_at" : "2014-02-27 21:56:49 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439155858703155200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439156302628265986",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich hast du noch ein pre-amp taugliches Effektboard?",
  "id" : 439156302628265986,
  "in_reply_to_status_id" : 439155858703155200,
  "created_at" : "2014-02-27 21:53:16 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439155086703734784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "439155673738514432",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich nein, nur wenn ich getrunken habe.",
  "id" : 439155673738514432,
  "in_reply_to_status_id" : 439155086703734784,
  "created_at" : "2014-02-27 21:50:46 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439150170849427457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095598336, 8.2829135173 ]
  },
  "id_str" : "439152093098962944",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon das picking braucht man ja nur f\u00FCrs Intro. Und daf\u00FCr habe ich die passende Gitarre as well. :)",
  "id" : 439152093098962944,
  "in_reply_to_status_id" : 439150170849427457,
  "created_at" : "2014-02-27 21:36:32 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439149045563813889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095567105, 8.2829194245 ]
  },
  "id_str" : "439149550323126272",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon komm vorbei, dann zeige ich dir wie In Flames und Pantera trotzdem gehen. ;)",
  "id" : 439149550323126272,
  "in_reply_to_status_id" : 439149045563813889,
  "created_at" : "2014-02-27 21:26:26 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439146775312859136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095596827, 8.2829614758 ]
  },
  "id_str" : "439147461559730178",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich bei dir ist es ja sowieso egal auf was du spielst. :p",
  "id" : 439147461559730178,
  "in_reply_to_status_id" : 439146775312859136,
  "created_at" : "2014-02-27 21:18:08 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439144295178985473",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009573947, 8.2829876943 ]
  },
  "id_str" : "439146939876376576",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon das trifft sich gut, ich kann gar nicht mit Plektrum. :p",
  "id" : 439146939876376576,
  "in_reply_to_status_id" : 439144295178985473,
  "created_at" : "2014-02-27 21:16:04 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439128075503403009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095602679, 8.2829062398 ]
  },
  "id_str" : "439129993260834816",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon sagst du mir gleich das du Romeo &amp; Juliet spielen willst? ;)",
  "id" : 439129993260834816,
  "in_reply_to_status_id" : 439128075503403009,
  "created_at" : "2014-02-27 20:08:43 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 20, 26 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439127157135384576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096882419, 8.2831148003 ]
  },
  "id_str" : "439129101056884736",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich alles was @lobot mir aufzwingt. ;)",
  "id" : 439129101056884736,
  "in_reply_to_status_id" : 439127157135384576,
  "created_at" : "2014-02-27 20:05:10 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 10, 19 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439120089930285056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095940542, 8.2829678648 ]
  },
  "id_str" : "439120922067611648",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @JP_Stich mit den politischen Differenzen h\u00E4tte ich leben k\u00F6nnen, aber bei Les Paul h\u00F6rt der Spass auf. Dann lieber nen Gr\u00FCnen!",
  "id" : 439120922067611648,
  "in_reply_to_status_id" : 439120089930285056,
  "created_at" : "2014-02-27 19:32:40 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439109291963064321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009689323, 8.2830407753 ]
  },
  "id_str" : "439115685705551872",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon sehr gern!",
  "id" : 439115685705551872,
  "in_reply_to_status_id" : 439109291963064321,
  "created_at" : "2014-02-27 19:11:52 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439104349089046528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0660793766, 8.27355035 ]
  },
  "id_str" : "439105340580589569",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon lass dich knutschen (nach dem secret Handshake ;)) Du musst mal vorbeikommen und meine Strat kennenlernen.",
  "id" : 439105340580589569,
  "in_reply_to_status_id" : 439104349089046528,
  "created_at" : "2014-02-27 18:30:46 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 62, 71 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439102272107446272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0659986049, 8.2738602507 ]
  },
  "id_str" : "439102931678535680",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich und damit liebe ich dich seit gerade etwas mehr als @Senficon &lt;3",
  "id" : 439102931678535680,
  "in_reply_to_status_id" : 439102272107446272,
  "created_at" : "2014-02-27 18:21:11 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439101817243598849",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0625995301, 8.2785234333 ]
  },
  "id_str" : "439102524470333441",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj doch, so viel steht fest. Was noch nicht klar ist: Klassik, Western oder Dobro.",
  "id" : 439102524470333441,
  "in_reply_to_status_id" : 439101817243598849,
  "created_at" : "2014-02-27 18:19:34 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.056194244, 8.3191307634 ]
  },
  "id_str" : "439101550649434112",
  "text" : "Ganz intime Dates* mit meinen Studenten ausmachen. *Bei der Gitarrenauswahl begleiten d\u00FCrfen",
  "id" : 439101550649434112,
  "created_at" : "2014-02-27 18:15:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/KOp3L01Xc4",
      "expanded_url" : "http:\/\/massgenomics.org\/2014\/02\/genetic-privacy-whole-genome-era.html",
      "display_url" : "massgenomics.org\/2014\/02\/geneti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439071419511877632",
  "text" : "Genetic Privacy and Right to Know in the Whole-Genome Era http:\/\/t.co\/KOp3L01Xc4",
  "id" : 439071419511877632,
  "created_at" : "2014-02-27 16:15:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439038604531474432",
  "geo" : { },
  "id_str" : "439039829310177280",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher Passend zum restlichen Verhalten gibt es dann halt auch Social Network Analysis auf Grundschulniveau.",
  "id" : 439039829310177280,
  "in_reply_to_status_id" : 439038604531474432,
  "created_at" : "2014-02-27 14:10:26 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/CdD6pUcWuY",
      "expanded_url" : "http:\/\/rebellmarkt.blogger.de\/static\/antville\/rebellmarkt\/images\/reformrebell3.jpg",
      "display_url" : "rebellmarkt.blogger.de\/static\/antvill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439038436469927936",
  "text" : "Gesinnungsanalyse per Intersection? Sind die Ergebnisse schon f\u00FCr eine Runde Alphonso's Creed weitergereicht worden? http:\/\/t.co\/CdD6pUcWuY",
  "id" : 439038436469927936,
  "created_at" : "2014-02-27 14:04:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 121, 134 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/HorZNxsSbM",
      "expanded_url" : "http:\/\/www.biomedcentral.com\/1471-2105\/14\/S11\/S5",
      "display_url" : "biomedcentral.com\/1471-2105\/14\/S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438971973725876224",
  "text" : "A base composition analysis of natural patterns for the preprocessing of metagenome sequences http:\/\/t.co\/HorZNxsSbM \/cc @PhilippBayer",
  "id" : 438971973725876224,
  "created_at" : "2014-02-27 09:40:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 44, 57 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/aPK7wkuGqO",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/N5z71CHHLTo\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.166709, 8.628333 ]
  },
  "id_str" : "438957599611183104",
  "text" : "Learn to write with William S\u00A0Burroughs \/cc @philippbayer  http:\/\/t.co\/aPK7wkuGqO",
  "id" : 438957599611183104,
  "created_at" : "2014-02-27 08:43:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438955944425172992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1657688043, 8.6406712325 ]
  },
  "id_str" : "438957374582566912",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I guess Twitter is making me smarter due to a diverse list of followings? ;)",
  "id" : 438957374582566912,
  "in_reply_to_status_id" : 438955944425172992,
  "created_at" : "2014-02-27 08:42:48 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438955336808943616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1476279258, 8.6690164159 ]
  },
  "id_str" : "438955633933840384",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez yes, most of the time it has worked great for me and I try to look through the tag once in a while to pay it forward.",
  "id" : 438955633933840384,
  "in_reply_to_status_id" : 438955336808943616,
  "created_at" : "2014-02-27 08:35:53 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438954319467921408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1408838627, 8.6685853481 ]
  },
  "id_str" : "438955251509768192",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez and delete the tweet once you got the paper, so others don\u2019t have to perform unnecessary work :)",
  "id" : 438955251509768192,
  "in_reply_to_status_id" : 438954319467921408,
  "created_at" : "2014-02-27 08:34:22 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438954319467921408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1382574371, 8.6694602687 ]
  },
  "id_str" : "438955115580768256",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez the etiquette is quite simple: post link to the paper you want + email along with the hashtag.",
  "id" : 438955115580768256,
  "in_reply_to_status_id" : 438954319467921408,
  "created_at" : "2014-02-27 08:33:49 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438953155364012032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1100853337, 8.6851065184 ]
  },
  "id_str" : "438953893662580737",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I guess the icanhazpdf hashtag does this already, albeit manually. :)",
  "id" : 438953893662580737,
  "in_reply_to_status_id" : 438953155364012032,
  "created_at" : "2014-02-27 08:28:58 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438951407169703936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1079841374, 8.6770115313 ]
  },
  "id_str" : "438952914594590720",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez great, thanks! And best of luck with your connectivity :)",
  "id" : 438952914594590720,
  "in_reply_to_status_id" : 438951407169703936,
  "created_at" : "2014-02-27 08:25:04 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438946994631880704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0925309258, 8.5183318891 ]
  },
  "id_str" : "438947993329631232",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez can you mail me the pdf? :)",
  "id" : 438947993329631232,
  "in_reply_to_status_id" : 438946994631880704,
  "created_at" : "2014-02-27 08:05:31 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0197978774, 8.4330604852 ]
  },
  "id_str" : "438945148622614528",
  "text" : "\u00ABIt is an awful thing to have an idea that is bigger than you are.\u00BB",
  "id" : 438945148622614528,
  "created_at" : "2014-02-27 07:54:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/fGotuCZjlt",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0089642",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "438822600803123201",
  "text" : "\u2018musical sophistication\u2019 is correlated with wealth? you don\u2019t say! http:\/\/t.co\/fGotuCZjlt",
  "id" : 438822600803123201,
  "created_at" : "2014-02-26 23:47:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Moss",
      "screen_name" : "gawbul",
      "indices" : [ 89, 96 ],
      "id_str" : "49344076",
      "id" : 49344076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/lV1VYYBwna",
      "expanded_url" : "http:\/\/www.brainpickings.org\/index.php\/2013\/09\/16\/e-b-white-dog-obituary\/",
      "display_url" : "brainpickings.org\/index.php\/2013\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "438821657135026176",
  "text" : "\u00ABShe suffered from a chronic perplexity. \u2026 She died sniffing life, and enjoying it.\u00BB \/ht @gawbul http:\/\/t.co\/lV1VYYBwna",
  "id" : 438821657135026176,
  "created_at" : "2014-02-26 23:43:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438820856802705409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096698936, 8.2830762003 ]
  },
  "id_str" : "438821213818093568",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes! Loved especially that one as well!",
  "id" : 438821213818093568,
  "in_reply_to_status_id" : 438820856802705409,
  "created_at" : "2014-02-26 23:41:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/MfnGNozKV1",
      "expanded_url" : "http:\/\/amzn.com\/k\/ZNZPPkoITCqMziQwicapXg",
      "display_url" : "amzn.com\/k\/ZNZPPkoITCqM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438817570905686016",
  "text" : "\u00ABLove is the one way that you can behave like everyone else &amp; still claim that you did it your way.\u00BB http:\/\/t.co\/MfnGNozKV1 The socia...",
  "id" : 438817570905686016,
  "created_at" : "2014-02-26 23:27:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 113, 126 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/kv6SPzXIzk",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0088977",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "438814256042369024",
  "text" : "Openstage: A Low-Cost Motorized Microscope Stage with Sub-Micron Positioning Accuracy http:\/\/t.co\/kv6SPzXIzk \/cc @PhilippBayer",
  "id" : 438814256042369024,
  "created_at" : "2014-02-26 23:14:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009672854, 8.28306135 ]
  },
  "id_str" : "438809843722629120",
  "text" : "\u00ABDivorce is one of the many privileges of marriage, one of the many benefits that accrue to those who are permitted to marry.\u00BB",
  "id" : 438809843722629120,
  "created_at" : "2014-02-26 22:56:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenna Lang",
      "screen_name" : "jennomics",
      "indices" : [ 3, 13 ],
      "id_str" : "199462709",
      "id" : 199462709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/fNcp5gSaZa",
      "expanded_url" : "http:\/\/ow.ly\/tPy4v",
      "display_url" : "ow.ly\/tPy4v"
    } ]
  },
  "geo" : { },
  "id_str" : "438807649355038720",
  "text" : "RT @jennomics: Released today: ExaBayes for faster, highly parallelized, large-scale Bayesian phylogenetic inference. http:\/\/t.co\/fNcp5gSaZa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/fNcp5gSaZa",
        "expanded_url" : "http:\/\/ow.ly\/tPy4v",
        "display_url" : "ow.ly\/tPy4v"
      } ]
    },
    "geo" : { },
    "id_str" : "436588114573012992",
    "text" : "Released today: ExaBayes for faster, highly parallelized, large-scale Bayesian phylogenetic inference. http:\/\/t.co\/fNcp5gSaZa",
    "id" : 436588114573012992,
    "created_at" : "2014-02-20 19:48:12 +0000",
    "user" : {
      "name" : "Jenna Lang",
      "screen_name" : "jennomics",
      "protected" : false,
      "id_str" : "199462709",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2632762465\/2ea23470288a3ef78f7c7aa087776693_normal.jpeg",
      "id" : 199462709,
      "verified" : false
    }
  },
  "id" : 438807649355038720,
  "created_at" : "2014-02-26 22:47:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "indices" : [ 3, 18 ],
      "id_str" : "1040758742",
      "id" : 1040758742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438803784807219200",
  "text" : "RT @BioDataGanache: Ack! Just heard that Paco de Luc\u00EDa- the great flamenco guitarist- died yesterday at 66. What a loss. http:\/\/t.co\/21E4Fd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/21E4Fd8644",
        "expanded_url" : "http:\/\/abcnews.go.com\/Entertainment\/wireStory\/spain-flamenco-guitarist-paco-de-lucia-dies-66-22677104",
        "display_url" : "abcnews.go.com\/Entertainment\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "438803747360501763",
    "text" : "Ack! Just heard that Paco de Luc\u00EDa- the great flamenco guitarist- died yesterday at 66. What a loss. http:\/\/t.co\/21E4Fd8644",
    "id" : 438803747360501763,
    "created_at" : "2014-02-26 22:32:20 +0000",
    "user" : {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "protected" : false,
      "id_str" : "1040758742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/825446808696483840\/nMI6-h4y_normal.jpg",
      "id" : 1040758742,
      "verified" : false
    }
  },
  "id" : 438803784807219200,
  "created_at" : "2014-02-26 22:32:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Daniel McDonald",
      "screen_name" : "mcdonadt",
      "indices" : [ 95, 104 ],
      "id_str" : "2301852505",
      "id" : 2301852505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/zJb8NwSmXF",
      "expanded_url" : "http:\/\/biocore.github.io\/emperor\/",
      "display_url" : "biocore.github.io\/emperor\/"
    } ]
  },
  "geo" : { },
  "id_str" : "438794673336094720",
  "text" : "RT @pathogenomenick: Emperor - interactive visualiser for PCoA plots http:\/\/t.co\/zJb8NwSmXF ht @mcdonadt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel McDonald",
        "screen_name" : "mcdonadt",
        "indices" : [ 74, 83 ],
        "id_str" : "2301852505",
        "id" : 2301852505
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/zJb8NwSmXF",
        "expanded_url" : "http:\/\/biocore.github.io\/emperor\/",
        "display_url" : "biocore.github.io\/emperor\/"
      } ]
    },
    "geo" : { },
    "id_str" : "438793996241231872",
    "text" : "Emperor - interactive visualiser for PCoA plots http:\/\/t.co\/zJb8NwSmXF ht @mcdonadt",
    "id" : 438793996241231872,
    "created_at" : "2014-02-26 21:53:35 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 438794673336094720,
  "created_at" : "2014-02-26 21:56:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/3lywVYdenU",
      "expanded_url" : "http:\/\/www.theatlantic.com\/politics\/archive\/2014\/02\/a-glimpse-into-1970s-gay-activism\/284077\/",
      "display_url" : "theatlantic.com\/politics\/archi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095361683, 8.2829336217 ]
  },
  "id_str" : "438789413167190016",
  "text" : "A Glimpse Into 1970s Gay Activism http:\/\/t.co\/3lywVYdenU",
  "id" : 438789413167190016,
  "created_at" : "2014-02-26 21:35:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/VvV33Yv5ip",
      "expanded_url" : "http:\/\/thenewinquiry.com\/essays\/everybodys-doing-it\/",
      "display_url" : "thenewinquiry.com\/essays\/everybo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095361683, 8.2829336217 ]
  },
  "id_str" : "438788544015118336",
  "text" : "Peer pressure has dissipated since its \u201990s heyday, but the adolescent flat world is harder to navigate http:\/\/t.co\/VvV33Yv5ip",
  "id" : 438788544015118336,
  "created_at" : "2014-02-26 21:31:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/moqOA2xtAw",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/statuses\/282140945372295169",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "438759573928030208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096713343, 8.2830788 ]
  },
  "id_str" : "438760027453931520",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog im Bademantel\u2026 https:\/\/t.co\/moqOA2xtAw",
  "id" : 438760027453931520,
  "in_reply_to_status_id" : 438759573928030208,
  "created_at" : "2014-02-26 19:38:36 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1270157553, 8.6763076064 ]
  },
  "id_str" : "438742220108496896",
  "text" : "\u00ABit gives us access to a source of personal meaning [\u2026] to make sense of our lives. That\u2019s exactly what\u2019s so dangerous about romantic love.\u00BB",
  "id" : 438742220108496896,
  "created_at" : "2014-02-26 18:27:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438731746515759104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1707939459, 8.6237411697 ]
  },
  "id_str" : "438733846440599552",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks \u2026the more realistic version is an addiction: do it for the brief high of actually figuring out stuff between lots of cold turkey.",
  "id" : 438733846440599552,
  "in_reply_to_status_id" : 438731746515759104,
  "created_at" : "2014-02-26 17:54:34 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438731746515759104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1717076404, 8.6253026594 ]
  },
  "id_str" : "438733485638184960",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks if you want to put it nicely you could argue a self-improvement spirit along Beckett\u2019s \u2018try again, fail better\u2019 but\u2026",
  "id" : 438733485638184960,
  "in_reply_to_status_id" : 438731746515759104,
  "created_at" : "2014-02-26 17:53:08 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438731453409787904",
  "text" : "Science is a harsh mistress: the only result that looked a bit promising goes the way of all false-positives\u2026 Time to call it a day\u2026",
  "id" : 438731453409787904,
  "created_at" : "2014-02-26 17:45:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/aTYc2m6big",
      "expanded_url" : "http:\/\/instagram.com\/p\/k4poZ9hwph\/",
      "display_url" : "instagram.com\/p\/k4poZ9hwph\/"
    } ]
  },
  "geo" : { },
  "id_str" : "438704628050722816",
  "text" : "\u00ABEs ist nicht wie es aussieht, wir haben wirklich keinen Kindergarten \u00FCberfallen in der Mittagspause!\u00BB http:\/\/t.co\/aTYc2m6big",
  "id" : 438704628050722816,
  "created_at" : "2014-02-26 15:58:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 59, 68 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/p4nbg7UwYU",
      "expanded_url" : "http:\/\/modelviewculture.com\/pieces\/quantify-everything-a-dream-of-a-feminist-data-future",
      "display_url" : "modelviewculture.com\/pieces\/quantif\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438607732212789248",
  "text" : "Quantify Everything: A Dream of a Feminist Data Future \/cc @eramirez http:\/\/t.co\/p4nbg7UwYU",
  "id" : 438607732212789248,
  "created_at" : "2014-02-26 09:33:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Z4cUZW6AgW",
      "expanded_url" : "http:\/\/www.dnainfo.com\/new-york\/20140225\/williamsburg\/facial-hair-transplants-growing-amid-hipster-beard-craze-doctors-say",
      "display_url" : "dnainfo.com\/new-york\/20140\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438595516776321024",
  "text" : "\u00ABIn addition to beardless hipsters [\u2026] clients include men who have struggled since adolescence to grow a beard\u00BB http:\/\/t.co\/Z4cUZW6AgW",
  "id" : 438595516776321024,
  "created_at" : "2014-02-26 08:44:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/Rc41pjD0Z8",
      "expanded_url" : "https:\/\/theconversation.com\/how-to-get-ants-to-solve-a-chess-problem-22282",
      "display_url" : "theconversation.com\/how-to-get-ant\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438594320644710400",
  "text" : "How to get ants to solve a chess problem https:\/\/t.co\/Rc41pjD0Z8",
  "id" : 438594320644710400,
  "created_at" : "2014-02-26 08:40:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/QIQDe4WYG5",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/artful-amoeba\/2014\/02\/19\/graphic-the-many-ways-to-be-multicellular-on-planet-earth\/",
      "display_url" : "blogs.scientificamerican.com\/artful-amoeba\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438586323138805761",
  "text" : "An Illustration of the Many Ways to Be Multicellular on Planet Earth http:\/\/t.co\/QIQDe4WYG5",
  "id" : 438586323138805761,
  "created_at" : "2014-02-26 08:08:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/wBRKdBtNNB",
      "expanded_url" : "http:\/\/www.medicinalgenomics.com\/wp-content\/uploads\/2011\/12\/Sudden-unexpected-death-under-acute-influence-of-cannabis.pdf",
      "display_url" : "medicinalgenomics.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438585726796828672",
  "text" : "Sudden unexpected death under acute influence of cannabis http:\/\/t.co\/wBRKdBtNNB",
  "id" : 438585726796828672,
  "created_at" : "2014-02-26 08:06:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0752782869, 8.4987068363 ]
  },
  "id_str" : "438570532691537920",
  "text" : "\u00ABIf they laugh at situations that are horrifying\/tragic that\u2019s not because they do not feel the horror\/tragedy of them but because they do.\u00BB",
  "id" : 438570532691537920,
  "created_at" : "2014-02-26 07:05:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/gmJ1LDAlrH",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0089184",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096713343, 8.2830788 ]
  },
  "id_str" : "438470435022589952",
  "text" : "Comparing Distributions of Color Words: Pitfalls and Metric Choices http:\/\/t.co\/gmJ1LDAlrH",
  "id" : 438470435022589952,
  "created_at" : "2014-02-26 00:27:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/6gbCjpSkRp",
      "expanded_url" : "http:\/\/www.shapeways.com\/model\/208702\/goatsearring-oversized.html",
      "display_url" : "shapeways.com\/model\/208702\/g\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096713343, 8.2830788 ]
  },
  "id_str" : "438464995626848256",
  "text" : "browsing shapeways I suddenly felt the urge to get an earlobe piercing http:\/\/t.co\/6gbCjpSkRp",
  "id" : 438464995626848256,
  "created_at" : "2014-02-26 00:06:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drunk Grad Student",
      "screen_name" : "DrunkGrad",
      "indices" : [ 3, 13 ],
      "id_str" : "855845088",
      "id" : 855845088
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DrunkGrad\/status\/438458757149114368\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/etW2f2jflu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhW36pyIAAA5XXB.jpg",
      "id_str" : "438458757014880256",
      "id" : 438458757014880256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhW36pyIAAA5XXB.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 287
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 287
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 191
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 287
      } ],
      "display_url" : "pic.twitter.com\/etW2f2jflu"
    } ],
    "hashtags" : [ {
      "text" : "gradschoolproblems",
      "indices" : [ 15, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438458988892790784",
  "text" : "RT @DrunkGrad: #gradschoolproblems http:\/\/t.co\/etW2f2jflu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrunkGrad\/status\/438458757149114368\/photo\/1",
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/etW2f2jflu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhW36pyIAAA5XXB.jpg",
        "id_str" : "438458757014880256",
        "id" : 438458757014880256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhW36pyIAAA5XXB.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 287
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 287
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 191
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 287
        } ],
        "display_url" : "pic.twitter.com\/etW2f2jflu"
      } ],
      "hashtags" : [ {
        "text" : "gradschoolproblems",
        "indices" : [ 0, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438458757149114368",
    "text" : "#gradschoolproblems http:\/\/t.co\/etW2f2jflu",
    "id" : 438458757149114368,
    "created_at" : "2014-02-25 23:41:28 +0000",
    "user" : {
      "name" : "Drunk Grad Student",
      "screen_name" : "DrunkGrad",
      "protected" : false,
      "id_str" : "855845088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738784339761188864\/24yIsBB5_normal.jpg",
      "id" : 855845088,
      "verified" : false
    }
  },
  "id" : 438458988892790784,
  "created_at" : "2014-02-25 23:42:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/qojuWmrJlo",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0087763",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096713343, 8.2830788 ]
  },
  "id_str" : "438458253417402368",
  "text" : "Sleep-Wake Cycle in Young and Older Persons with a Lifetime History of Mood Disorders http:\/\/t.co\/qojuWmrJlo",
  "id" : 438458253417402368,
  "created_at" : "2014-02-25 23:39:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/lHfeFwaGck",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=WhQOJY2zBj4",
      "display_url" : "youtube.com\/watch?v=WhQOJY\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096713343, 8.2830788 ]
  },
  "id_str" : "438451517595852800",
  "text" : "\u00ABI used to be a scientist, making numbers match the pictures\u2026\u00BB thx to photoshop it\u2019s now vice versa\u2026 http:\/\/t.co\/lHfeFwaGck",
  "id" : 438451517595852800,
  "created_at" : "2014-02-25 23:12:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "indices" : [ 3, 10 ],
      "id_str" : "11322372",
      "id" : 11322372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/SpkJosrwhY",
      "expanded_url" : "http:\/\/zachholman.com\/posts\/only-90s-developers\/",
      "display_url" : "zachholman.com\/posts\/only-90s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438426584631214080",
  "text" : "RT @holman: Only 90s Web Developers will Remember This: http:\/\/t.co\/SpkJosrwhY\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;Click to join my WebRing",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/SpkJosrwhY",
        "expanded_url" : "http:\/\/zachholman.com\/posts\/only-90s-developers\/",
        "display_url" : "zachholman.com\/posts\/only-90s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "438416335970635776",
    "text" : "Only 90s Web Developers will Remember This: http:\/\/t.co\/SpkJosrwhY\n\n&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;Click to join my WebRing",
    "id" : 438416335970635776,
    "created_at" : "2014-02-25 20:52:54 +0000",
    "user" : {
      "name" : "Zach Holman",
      "screen_name" : "holman",
      "protected" : false,
      "id_str" : "11322372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822539344288350209\/fX0Xi3oZ_normal.jpg",
      "id" : 11322372,
      "verified" : true
    }
  },
  "id" : 438426584631214080,
  "created_at" : "2014-02-25 21:33:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne Alleyne",
      "screen_name" : "Cotesia1",
      "indices" : [ 3, 12 ],
      "id_str" : "184737993",
      "id" : 184737993
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Cotesia1\/status\/438421042738888705\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/F5eMkDrjjn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhWVnZMCAAAAivH.jpg",
      "id_str" : "438421042747277312",
      "id" : 438421042747277312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhWVnZMCAAAAivH.jpg",
      "sizes" : [ {
        "h" : 244,
        "resize" : "fit",
        "w" : 375
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 375
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 375
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 375
      } ],
      "display_url" : "pic.twitter.com\/F5eMkDrjjn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Jtq6qsJmmh",
      "expanded_url" : "http:\/\/www.sciencedirect.com\/science\/article\/pii\/S146780391100079X",
      "display_url" : "sciencedirect.com\/science\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438421332175634432",
  "text" : "RT @Cotesia1: One rarely encounters something as beautiful &amp; elegant as a Zoraptera egg http:\/\/t.co\/Jtq6qsJmmh http:\/\/t.co\/F5eMkDrjjn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cotesia1\/status\/438421042738888705\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/F5eMkDrjjn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhWVnZMCAAAAivH.jpg",
        "id_str" : "438421042747277312",
        "id" : 438421042747277312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhWVnZMCAAAAivH.jpg",
        "sizes" : [ {
          "h" : 244,
          "resize" : "fit",
          "w" : 375
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 375
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 375
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 375
        } ],
        "display_url" : "pic.twitter.com\/F5eMkDrjjn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/Jtq6qsJmmh",
        "expanded_url" : "http:\/\/www.sciencedirect.com\/science\/article\/pii\/S146780391100079X",
        "display_url" : "sciencedirect.com\/science\/articl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "438421042738888705",
    "text" : "One rarely encounters something as beautiful &amp; elegant as a Zoraptera egg http:\/\/t.co\/Jtq6qsJmmh http:\/\/t.co\/F5eMkDrjjn",
    "id" : 438421042738888705,
    "created_at" : "2014-02-25 21:11:36 +0000",
    "user" : {
      "name" : "Marianne Alleyne",
      "screen_name" : "Cotesia1",
      "protected" : false,
      "id_str" : "184737993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/826176197918879745\/0t5MBVV0_normal.jpg",
      "id" : 184737993,
      "verified" : false
    }
  },
  "id" : 438421332175634432,
  "created_at" : "2014-02-25 21:12:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438403850501107712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096516608, 8.2831400861 ]
  },
  "id_str" : "438404367390363649",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot guess that\u2019s a first step in the general direction. Not too bad. ;)",
  "id" : 438404367390363649,
  "in_reply_to_status_id" : 438403850501107712,
  "created_at" : "2014-02-25 20:05:21 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438402127720095745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096872123, 8.2831881568 ]
  },
  "id_str" : "438402778797731840",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot you\u2019d guess that you\u2019d be able to find that place on your own, but past experience tells me that this just isn\u2019t true.",
  "id" : 438402778797731840,
  "in_reply_to_status_id" : 438402127720095745,
  "created_at" : "2014-02-25 19:59:02 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438401619940892672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096872123, 8.2831881568 ]
  },
  "id_str" : "438401967006945280",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot but for once you should try to use them for pathfinding instead of eating them!",
  "id" : 438401967006945280,
  "in_reply_to_status_id" : 438401619940892672,
  "created_at" : "2014-02-25 19:55:48 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/OTwvWpSLnj",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/beards\/comments\/1yw2xq\/moustache_over_mouth_how_do_you_eat\/",
      "display_url" : "reddit.com\/r\/beards\/comme\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0036340532, 8.356749795 ]
  },
  "id_str" : "438398242561478656",
  "text" : "\u00ABI brush my mustache to the sides the best I can, and eat like I\u2019m navigating a mine field.\u00BB http:\/\/t.co\/OTwvWpSLnj",
  "id" : 438398242561478656,
  "created_at" : "2014-02-25 19:41:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Voytek",
      "screen_name" : "bradleyvoytek",
      "indices" : [ 3, 17 ],
      "id_str" : "162535413",
      "id" : 162535413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438392144207036417",
  "text" : "RT @bradleyvoytek: SCIENCE! \"Sausages made with bacteria from infant poop, though offputting, helps make the sausages healthier.\" http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/rgnTfREw6O",
        "expanded_url" : "http:\/\/bit.ly\/1mFxelY",
        "display_url" : "bit.ly\/1mFxelY"
      } ]
    },
    "geo" : { },
    "id_str" : "438391585303060480",
    "text" : "SCIENCE! \"Sausages made with bacteria from infant poop, though offputting, helps make the sausages healthier.\" http:\/\/t.co\/rgnTfREw6O",
    "id" : 438391585303060480,
    "created_at" : "2014-02-25 19:14:33 +0000",
    "user" : {
      "name" : "Brad Voytek",
      "screen_name" : "bradleyvoytek",
      "protected" : false,
      "id_str" : "162535413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688408740651909124\/mz2GSnS0_normal.jpg",
      "id" : 162535413,
      "verified" : true
    }
  },
  "id" : 438392144207036417,
  "created_at" : "2014-02-25 19:16:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/T49tTypUG9",
      "expanded_url" : "http:\/\/www.thedailybeast.com\/articles\/2014\/02\/23\/whole-foods-america-s-temple-of-pseudoscience.html",
      "display_url" : "thedailybeast.com\/articles\/2014\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009649, 8.283048 ]
  },
  "id_str" : "438385843070570496",
  "text" : "Whole Foods: America\u2019s Temple of Pseudoscience http:\/\/t.co\/T49tTypUG9",
  "id" : 438385843070570496,
  "created_at" : "2014-02-25 18:51:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 52, 64 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/9VT330GiGF",
      "expanded_url" : "http:\/\/www.popsci.com\/article\/science\/scientific-look-why-you-hate-hawaiian-shirts",
      "display_url" : "popsci.com\/article\/scienc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438319062305996800",
  "text" : "\u00ABA Scientific Look At Why You Hate Hawaiian Shirts\u00BB @herr_schrat and I don't approve! http:\/\/t.co\/9VT330GiGF",
  "id" : 438319062305996800,
  "created_at" : "2014-02-25 14:26:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/RL7nAKEG8D",
      "expanded_url" : "http:\/\/vetaro.wordpress.com\/2014\/02\/25\/matthias-mattussek-schlagt-spontan-auf-einen-schwulen-ein\/",
      "display_url" : "vetaro.wordpress.com\/2014\/02\/25\/mat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965, 8.283046 ]
  },
  "id_str" : "438226697260126208",
  "text" : "\u00ABMatthias Matussek schl\u00E4gt spontan auf einen Schwulen ein.\u00BB http:\/\/t.co\/RL7nAKEG8D",
  "id" : 438226697260126208,
  "created_at" : "2014-02-25 08:19:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magdalena Skipper",
      "screen_name" : "Magda_Skipper",
      "indices" : [ 3, 17 ],
      "id_str" : "256793538",
      "id" : 256793538
    }, {
      "name" : "Nature News&Comment",
      "screen_name" : "NatureNews",
      "indices" : [ 93, 104 ],
      "id_str" : "15862891",
      "id" : 15862891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/OH4Ej1cZLK",
      "expanded_url" : "http:\/\/www.nature.com\/news\/publishers-withdraw-more-than-120-gibberish-papers-1.14763",
      "display_url" : "nature.com\/news\/publisher\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438221901983662080",
  "text" : "RT @Magda_Skipper: Publishers withdraw more than 120 gibberish papers http:\/\/t.co\/OH4Ej1cZLK @naturenews",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nature News&Comment",
        "screen_name" : "NatureNews",
        "indices" : [ 74, 85 ],
        "id_str" : "15862891",
        "id" : 15862891
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/OH4Ej1cZLK",
        "expanded_url" : "http:\/\/www.nature.com\/news\/publishers-withdraw-more-than-120-gibberish-papers-1.14763",
        "display_url" : "nature.com\/news\/publisher\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "438219573309894656",
    "text" : "Publishers withdraw more than 120 gibberish papers http:\/\/t.co\/OH4Ej1cZLK @naturenews",
    "id" : 438219573309894656,
    "created_at" : "2014-02-25 07:51:02 +0000",
    "user" : {
      "name" : "Magdalena Skipper",
      "screen_name" : "Magda_Skipper",
      "protected" : false,
      "id_str" : "256793538",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3328335336\/ec2e4239e8896dfb9b615cc6f11ee636_normal.jpeg",
      "id" : 256793538,
      "verified" : true
    }
  },
  "id" : 438221901983662080,
  "created_at" : "2014-02-25 08:00:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/Y6LZOMbqNF",
      "expanded_url" : "http:\/\/omicsomics.blogspot.com\/2014\/02\/a-sunset-for-draft-genomes.html",
      "display_url" : "omicsomics.blogspot.com\/2014\/02\/a-suns\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009639, 8.283046 ]
  },
  "id_str" : "438221062841827328",
  "text" : "A Sunset for Draft Genomes? http:\/\/t.co\/Y6LZOMbqNF",
  "id" : 438221062841827328,
  "created_at" : "2014-02-25 07:56:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438215644819894272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096713343, 8.2830788 ]
  },
  "id_str" : "438216715240222720",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yay, thanks :)",
  "id" : 438216715240222720,
  "in_reply_to_status_id" : 438215644819894272,
  "created_at" : "2014-02-25 07:39:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438213759677378560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096713343, 8.2830788 ]
  },
  "id_str" : "438215517770633216",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer machine is back up, but haven\u2019t started any servers so far.",
  "id" : 438215517770633216,
  "in_reply_to_status_id" : 438213759677378560,
  "created_at" : "2014-02-25 07:34:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 9, 22 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438212971916169216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096713343, 8.2830788 ]
  },
  "id_str" : "438215288610631680",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @PhilippBayer it will remain religious, but fortunately from what I\u2019ve seen the framework and chance agree. ;)",
  "id" : 438215288610631680,
  "in_reply_to_status_id" : 438212971916169216,
  "created_at" : "2014-02-25 07:34:01 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438213759677378560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096713343, 8.2830788 ]
  },
  "id_str" : "438214396809326592",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay, keep your fingers crossed that the machine comes back up. :)",
  "id" : 438214396809326592,
  "in_reply_to_status_id" : 438213759677378560,
  "created_at" : "2014-02-25 07:30:28 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438213238530908160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096823268, 8.2830704139 ]
  },
  "id_str" : "438213485575819264",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer k, in that case I can skip the graceful way and go for the reset button. :)",
  "id" : 438213485575819264,
  "in_reply_to_status_id" : 438213238530908160,
  "created_at" : "2014-02-25 07:26:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438146217587908609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096898322, 8.2830310081 ]
  },
  "id_str" : "438212685042556928",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer how hard are we talking? ;)",
  "id" : 438212685042556928,
  "in_reply_to_status_id" : 438146217587908609,
  "created_at" : "2014-02-25 07:23:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438108720749621248",
  "text" : "RT @edyong209: Legendary biologist Robert Trivers is suspended for refusing to teach a course he wasn't qualified to teach. http:\/\/t.co\/Wae\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/WaerBJzICU",
        "expanded_url" : "http:\/\/www.michigandaily.com\/opinion\/02daily-better-balance19",
        "display_url" : "michigandaily.com\/opinion\/02dail\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "437960377968889856",
    "text" : "Legendary biologist Robert Trivers is suspended for refusing to teach a course he wasn't qualified to teach. http:\/\/t.co\/WaerBJzICU",
    "id" : 437960377968889856,
    "created_at" : "2014-02-24 14:41:05 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 438108720749621248,
  "created_at" : "2014-02-25 00:30:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/jbzJWWYQIJ",
      "expanded_url" : "http:\/\/i.imgur.com\/GPq7G6x.jpg",
      "display_url" : "i.imgur.com\/GPq7G6x.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096774686, 8.2830748029 ]
  },
  "id_str" : "438101931232608257",
  "text" : "i guess he was more than well prepared for that to happen http:\/\/t.co\/jbzJWWYQIJ",
  "id" : 438101931232608257,
  "created_at" : "2014-02-25 00:03:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 100, 113 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/kIMTEADFJh",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0088941#s4",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096774686, 8.2830748029 ]
  },
  "id_str" : "438083028364296192",
  "text" : "An Evaluation Framework and Comparative Analysis of the Widely Used First Programming Languages \/cc @PhilippBayer http:\/\/t.co\/kIMTEADFJh",
  "id" : 438083028364296192,
  "created_at" : "2014-02-24 22:48:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Steltner",
      "screen_name" : "nplhse",
      "indices" : [ 80, 87 ],
      "id_str" : "111716214",
      "id" : 111716214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/hgK4bM2OLe",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0088995",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "438079566473883648",
  "text" : "The German Version of the Manchester Triage System and Its Quality Criteria \/cc @nplhse http:\/\/t.co\/hgK4bM2OLe",
  "id" : 438079566473883648,
  "created_at" : "2014-02-24 22:34:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/f8akT3okJV",
      "expanded_url" : "http:\/\/instagram.com\/p\/k0GFmshwtn\/",
      "display_url" : "instagram.com\/p\/k0GFmshwtn\/"
    } ]
  },
  "geo" : { },
  "id_str" : "438063515409342464",
  "text" : "wear some flowers in your\u2026 http:\/\/t.co\/f8akT3okJV",
  "id" : 438063515409342464,
  "created_at" : "2014-02-24 21:30:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/aKGZu1RW1K",
      "expanded_url" : "http:\/\/youtu.be\/3yz_yxKxXuc",
      "display_url" : "youtu.be\/3yz_yxKxXuc"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "438061006343135232",
  "text" : "Okay, a last one: Low(!!) does a cover of Toto\u2019s Africa. http:\/\/t.co\/aKGZu1RW1K",
  "id" : 438061006343135232,
  "created_at" : "2014-02-24 21:20:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/WFMojLPz5z",
      "expanded_url" : "http:\/\/youtu.be\/erXbBoZRgBo",
      "display_url" : "youtu.be\/erXbBoZRgBo"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "438059979745263616",
  "text" : "Gosh, could listen to AV Undercovers all evening! Sharon Van Etten covers She Drives Me Crazy by Fine Young Cannibals http:\/\/t.co\/WFMojLPz5z",
  "id" : 438059979745263616,
  "created_at" : "2014-02-24 21:16:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/IQOB6jgSsv",
      "expanded_url" : "http:\/\/youtu.be\/FHEnjgGUtQ8",
      "display_url" : "youtu.be\/FHEnjgGUtQ8"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009684198, 8.283019252 ]
  },
  "id_str" : "438054460188004352",
  "text" : "10\/10 would bang heads again http:\/\/t.co\/IQOB6jgSsv",
  "id" : 438054460188004352,
  "created_at" : "2014-02-24 20:54:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/L1NXWE6XBH",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=B-UqPQ7ORGM",
      "display_url" : "youtube.com\/watch?v=B-UqPQ\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "438039696393117696",
  "text" : "Trampled By Turtles covers Arcade Fire &lt;3 http:\/\/t.co\/L1NXWE6XBH",
  "id" : 438039696393117696,
  "created_at" : "2014-02-24 19:56:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/9cWjdXEuiQ",
      "expanded_url" : "http:\/\/instagram.com\/p\/kzqdnuBwpf\/",
      "display_url" : "instagram.com\/p\/kzqdnuBwpf\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172374546, 8.627694567 ]
  },
  "id_str" : "438002769887506432",
  "text" : "getting there @ Biologicum http:\/\/t.co\/9cWjdXEuiQ",
  "id" : 438002769887506432,
  "created_at" : "2014-02-24 17:29:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438000684869230592",
  "text" : "\u00ABHey, ich war total verantwortungsbewusst und habe den Einkaufswagen wieder weggebracht! Also in das Geb\u00FCsch da hinten geschoben\u2026\u00BB",
  "id" : 438000684869230592,
  "created_at" : "2014-02-24 17:21:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/wnzRJkcmKT",
      "expanded_url" : "http:\/\/www.theallium.com\/biology\/immunologist-discovers-new-acronym\/",
      "display_url" : "theallium.com\/biology\/immuno\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437987154405253120",
  "text" : "Immunologist discovers new acronym http:\/\/t.co\/wnzRJkcmKT",
  "id" : 437987154405253120,
  "created_at" : "2014-02-24 16:27:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/gWGqNdsglZ",
      "expanded_url" : "http:\/\/www.theguardian.com\/society\/2014\/feb\/23\/london-houseboat-slum-rents-barge",
      "display_url" : "theguardian.com\/society\/2014\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437983641159745536",
  "text" : "\u00ABMy life in London's houseboat slums\u00BB http:\/\/t.co\/gWGqNdsglZ",
  "id" : 437983641159745536,
  "created_at" : "2014-02-24 16:13:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Grittner",
      "screen_name" : "SamGrittner",
      "indices" : [ 3, 15 ],
      "id_str" : "24272129",
      "id" : 24272129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437962426945130496",
  "text" : "RT @SamGrittner: \"Son, when I was your age we had to walk 50 miles uphill, in the snow with no shoes just to find out if hot, local singles\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "437935551413772288",
    "text" : "\"Son, when I was your age we had to walk 50 miles uphill, in the snow with no shoes just to find out if hot, local singles were in the area\"",
    "id" : 437935551413772288,
    "created_at" : "2014-02-24 13:02:26 +0000",
    "user" : {
      "name" : "Sam Grittner",
      "screen_name" : "SamGrittner",
      "protected" : false,
      "id_str" : "24272129",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918708979911368704\/eG68ihPi_normal.jpg",
      "id" : 24272129,
      "verified" : false
    }
  },
  "id" : 437962426945130496,
  "created_at" : "2014-02-24 14:49:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/u8nIjjUePF",
      "expanded_url" : "http:\/\/www.peerreviewedbymyneurons.com\/2014\/02\/23\/people-wired-help-needy\/",
      "display_url" : "peerreviewedbymyneurons.com\/2014\/02\/23\/peo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437952478986792960",
  "text" : "Are People Wired to Help the Needy? http:\/\/t.co\/u8nIjjUePF",
  "id" : 437952478986792960,
  "created_at" : "2014-02-24 14:09:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/cj0z6cNwUt",
      "expanded_url" : "http:\/\/xkcd.com\/1334\/",
      "display_url" : "xkcd.com\/1334\/"
    } ]
  },
  "geo" : { },
  "id_str" : "437945628203565057",
  "text" : "whatever quest drives you, abandon it! http:\/\/t.co\/cj0z6cNwUt",
  "id" : 437945628203565057,
  "created_at" : "2014-02-24 13:42:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/HmGWna4NRc",
      "expanded_url" : "http:\/\/girlsgotafacelikemurder.tumblr.com\/post\/77592877250\/what-about-when-you-get-old-tattooed-seniors",
      "display_url" : "girlsgotafacelikemurder.tumblr.com\/post\/775928772\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437943704251150337",
  "text" : "\"What about when you get old?\" http:\/\/t.co\/HmGWna4NRc",
  "id" : 437943704251150337,
  "created_at" : "2014-02-24 13:34:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437929027618091008",
  "text" : "\u00ABOh Gott, da bist du ja endlich. Wir sitzen schon alle ganz traurig im B\u00FCro und warten auf dich!\u00BB",
  "id" : 437929027618091008,
  "created_at" : "2014-02-24 12:36:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kovalic",
      "screen_name" : "muskrat_john",
      "indices" : [ 3, 16 ],
      "id_str" : "14167540",
      "id" : 14167540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437639383492349952",
  "text" : "RT @muskrat_john: \"WHAT ARE WE TO TELL THE CHILDREN ABOUT GAYS MARRYING?\"\n\nDunno. I'll ask my 5-year-old, who just married her stuffed bear\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "437615174699073536",
    "text" : "\"WHAT ARE WE TO TELL THE CHILDREN ABOUT GAYS MARRYING?\"\n\nDunno. I'll ask my 5-year-old, who just married her stuffed bear to a stuffed pony.",
    "id" : 437615174699073536,
    "created_at" : "2014-02-23 15:49:22 +0000",
    "user" : {
      "name" : "John Kovalic",
      "screen_name" : "muskrat_john",
      "protected" : false,
      "id_str" : "14167540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728235715092324352\/ezqqgWJ9_normal.jpg",
      "id" : 14167540,
      "verified" : false
    }
  },
  "id" : 437639383492349952,
  "created_at" : "2014-02-23 17:25:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/2SuebDueZI",
      "expanded_url" : "http:\/\/www.smithsonianmag.com\/science-nature\/why-carl-sagan-truly-irreplaceable-180949818\/",
      "display_url" : "smithsonianmag.com\/science-nature\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009601, 8.282971 ]
  },
  "id_str" : "437611077359398914",
  "text" : "Why Carl Sagan Is Truly Irreplaceable http:\/\/t.co\/2SuebDueZI",
  "id" : 437611077359398914,
  "created_at" : "2014-02-23 15:33:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/ydRkbYF9Hc",
      "expanded_url" : "http:\/\/instagram.com\/p\/kwqSUnhwt1\/",
      "display_url" : "instagram.com\/p\/kwqSUnhwt1\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.010031565, 8.267708943 ]
  },
  "id_str" : "437580166823690240",
  "text" : "Hosen?! @ Rheinallee http:\/\/t.co\/ydRkbYF9Hc",
  "id" : 437580166823690240,
  "created_at" : "2014-02-23 13:30:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/miAF3VWwJw",
      "expanded_url" : "http:\/\/instagram.com\/p\/kwnpRFBwq8\/",
      "display_url" : "instagram.com\/p\/kwnpRFBwq8\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.011114981, 8.263028594 ]
  },
  "id_str" : "437574358140469248",
  "text" : "Papa Ratso @ Gr\u00FCne Br\u00FCcke http:\/\/t.co\/miAF3VWwJw",
  "id" : 437574358140469248,
  "created_at" : "2014-02-23 13:07:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437562612998754304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097859632, 8.2824378003 ]
  },
  "id_str" : "437562945737097216",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach unser Bett ist dein Bett (iirc ist da in der Nacht noch Platz, sonst haben wir auch noch ein Sofa :))",
  "id" : 437562945737097216,
  "in_reply_to_status_id" : 437562612998754304,
  "created_at" : "2014-02-23 12:21:50 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437561338177814528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096632054, 8.2829813406 ]
  },
  "id_str" : "437561885219901440",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach komm auf einen bis n Drinks vorbei wenn du magst :)",
  "id" : 437561885219901440,
  "in_reply_to_status_id" : 437561338177814528,
  "created_at" : "2014-02-23 12:17:37 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098153801, 8.2830273317 ]
  },
  "id_str" : "437554334679990272",
  "text" : "Achievement des Tages so weit: In die worldwide Top 5 bei Futuridium EP gespielt.",
  "id" : 437554334679990272,
  "created_at" : "2014-02-23 11:47:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 0, 12 ],
      "id_str" : "48357885",
      "id" : 48357885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437353366076002305",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009684198, 8.283019252 ]
  },
  "id_str" : "437353809774669824",
  "in_reply_to_user_id" : 48357885,
  "text" : "@Whitey_chan I guess we all have some weird creatures we can identify with &lt;3",
  "id" : 437353809774669824,
  "in_reply_to_status_id" : 437353366076002305,
  "created_at" : "2014-02-22 22:30:48 +0000",
  "in_reply_to_screen_name" : "Whitey_chan",
  "in_reply_to_user_id_str" : "48357885",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/fzlpr4wMci",
      "expanded_url" : "https:\/\/medium.com\/this-happened-to-me\/dee8da1cfc09",
      "display_url" : "medium.com\/this-happened-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009684198, 8.283019252 ]
  },
  "id_str" : "437353246450274306",
  "text" : "How To Get a Lego X-Wing https:\/\/t.co\/fzlpr4wMci",
  "id" : 437353246450274306,
  "created_at" : "2014-02-22 22:28:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 0, 12 ],
      "id_str" : "48357885",
      "id" : 48357885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437352115133222913",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009684198, 8.283019252 ]
  },
  "id_str" : "437352518692405248",
  "in_reply_to_user_id" : 48357885,
  "text" : "@Whitey_chan i try to stick to dogs\/animals in general. If there\u2019s no dog expressing the emotion I probably can\u2019t feel it either ;)",
  "id" : 437352518692405248,
  "in_reply_to_status_id" : 437352115133222913,
  "created_at" : "2014-02-22 22:25:40 +0000",
  "in_reply_to_screen_name" : "Whitey_chan",
  "in_reply_to_user_id_str" : "48357885",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/BLqa7I9vwU",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/77496649222\/how-i-feel-every-day-in-grad-school",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/774966492\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009684198, 8.283019252 ]
  },
  "id_str" : "437351331880529920",
  "text" : "the #1 reason for using gifs http:\/\/t.co\/BLqa7I9vwU",
  "id" : 437351331880529920,
  "created_at" : "2014-02-22 22:20:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/w5Vz4qxAeE",
      "expanded_url" : "http:\/\/chapmangamo.tumblr.com\/post\/76549119900\/happy-valentines-day-whoever-youre-spending",
      "display_url" : "chapmangamo.tumblr.com\/post\/765491199\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009684198, 8.283019252 ]
  },
  "id_str" : "437347906514079744",
  "text" : "mopsti http:\/\/t.co\/w5Vz4qxAeE",
  "id" : 437347906514079744,
  "created_at" : "2014-02-22 22:07:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437339265165705216",
  "text" : "\u00ABI will take your head into my hands\u2026\u00BB \u2013 \u00AB\u2026and choke me with a dead cat?\u00BB",
  "id" : 437339265165705216,
  "created_at" : "2014-02-22 21:33:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buttersafe",
      "screen_name" : "buttersafe",
      "indices" : [ 3, 14 ],
      "id_str" : "26570921",
      "id" : 26570921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437329014525804544",
  "text" : "RT @buttersafe: Good makeouts are like good steaks: rare.\n\nBut, good makeouts are also like bad steaks: well done.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "437318119166459904",
    "text" : "Good makeouts are like good steaks: rare.\n\nBut, good makeouts are also like bad steaks: well done.",
    "id" : 437318119166459904,
    "created_at" : "2014-02-22 20:08:59 +0000",
    "user" : {
      "name" : "Buttersafe",
      "screen_name" : "buttersafe",
      "protected" : false,
      "id_str" : "26570921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2791886027\/eb4aa9dad743da57e070b26a9be1c06d_normal.jpeg",
      "id" : 26570921,
      "verified" : false
    }
  },
  "id" : 437329014525804544,
  "created_at" : "2014-02-22 20:52:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/6qDQs3bguC",
      "expanded_url" : "https:\/\/www.piratenpartei.de\/2014\/02\/22\/grenzenlos-internet\/",
      "display_url" : "piratenpartei.de\/2014\/02\/22\/gre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437316135437221888",
  "text" : "RT @Senficon: Grenzenlos Internet! Mit der Netzneutralit\u00E4t steht und f\u00E4llt das freie Netz. Jetzt aktiv werden: https:\/\/t.co\/6qDQs3bguC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/6qDQs3bguC",
        "expanded_url" : "https:\/\/www.piratenpartei.de\/2014\/02\/22\/grenzenlos-internet\/",
        "display_url" : "piratenpartei.de\/2014\/02\/22\/gre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "437315993824927745",
    "text" : "Grenzenlos Internet! Mit der Netzneutralit\u00E4t steht und f\u00E4llt das freie Netz. Jetzt aktiv werden: https:\/\/t.co\/6qDQs3bguC",
    "id" : 437315993824927745,
    "created_at" : "2014-02-22 20:00:32 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 437316135437221888,
  "created_at" : "2014-02-22 20:01:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096679151, 8.2830185494 ]
  },
  "id_str" : "437312017939312640",
  "text" : "\u00ABDie alte Leier: Tweetup, Twittagessen, Fuckup.\u00BB",
  "id" : 437312017939312640,
  "created_at" : "2014-02-22 19:44:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 9, 15 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 16, 25 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437309539453796352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096953164, 8.2830605193 ]
  },
  "id_str" : "437310959590584320",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju @Lobot @Senficon dito, und one day vielleicht sogar mal das selbe.",
  "id" : 437310959590584320,
  "in_reply_to_status_id" : 437309539453796352,
  "created_at" : "2014-02-22 19:40:32 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 35, 41 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 66, 75 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437308320857489410",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097002022, 8.2831140745 ]
  },
  "id_str" : "437309281667674112",
  "in_reply_to_user_id" : 14861745,
  "text" : "@moeffju &amp; erst vorgestern hat @Lobot das vorgeschlagen &amp; @Senficon bekommt noch DMs die das supporten. Klingt nach majority-rule consensus.",
  "id" : 437309281667674112,
  "in_reply_to_status_id" : 437308320857489410,
  "created_at" : "2014-02-22 19:33:52 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\/r\/DataIsBeautiful",
      "screen_name" : "DataIsBeautiful",
      "indices" : [ 3, 19 ],
      "id_str" : "1201186872",
      "id" : 1201186872
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dataviz",
      "indices" : [ 85, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/RwPs1piQZx",
      "expanded_url" : "http:\/\/goo.gl\/Jv5UEF",
      "display_url" : "goo.gl\/Jv5UEF"
    } ]
  },
  "geo" : { },
  "id_str" : "437287312993832960",
  "text" : "RT @DataIsBeautiful: How much is time wrong around the world? http:\/\/t.co\/RwPs1piQZx #dataviz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.reddit.com\/r\/dataisbeautiful\" rel=\"nofollow\"\u003E\/r\/dataisbeautiful tweeter bot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dataviz",
        "indices" : [ 64, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/RwPs1piQZx",
        "expanded_url" : "http:\/\/goo.gl\/Jv5UEF",
        "display_url" : "goo.gl\/Jv5UEF"
      } ]
    },
    "geo" : { },
    "id_str" : "437285739936505856",
    "text" : "How much is time wrong around the world? http:\/\/t.co\/RwPs1piQZx #dataviz",
    "id" : 437285739936505856,
    "created_at" : "2014-02-22 18:00:19 +0000",
    "user" : {
      "name" : "\/r\/DataIsBeautiful",
      "screen_name" : "DataIsBeautiful",
      "protected" : false,
      "id_str" : "1201186872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572447924701786112\/FOnkOPJP_normal.png",
      "id" : 1201186872,
      "verified" : false
    }
  },
  "id" : 437287312993832960,
  "created_at" : "2014-02-22 18:06:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Arzheimer",
      "screen_name" : "kai_arzheimer",
      "indices" : [ 119, 133 ],
      "id_str" : "16736320",
      "id" : 16736320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/IGufHp23bn",
      "expanded_url" : "http:\/\/www.luizotaviobarros.com\/2013\/04\/academic-writing-useful-expressions.html",
      "display_url" : "luizotaviobarros.com\/2013\/04\/academ\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437268111969226752",
  "text" : "Not completely sure whether this is satire or not: 70 useful sentences for academic writing http:\/\/t.co\/IGufHp23bn \/HT @kai_arzheimer",
  "id" : 437268111969226752,
  "created_at" : "2014-02-22 16:50:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 43, 51 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437267064047566848",
  "text" : "\u00ABDu auch?! Wieso wollen alle, dass ich mit @moeffju ins Bett gehe?\u00BB\u2013\u00ABEs soll ja jemand sein den du magst, und Eddie Vedder wird wohl nichts\u00BB",
  "id" : 437267064047566848,
  "created_at" : "2014-02-22 16:46:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 0, 12 ],
      "id_str" : "48357885",
      "id" : 48357885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437226366011183104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096404949, 8.2829207973 ]
  },
  "id_str" : "437227326993342464",
  "in_reply_to_user_id" : 48357885,
  "text" : "@Whitey_chan awww :)",
  "id" : 437227326993342464,
  "in_reply_to_status_id" : 437226366011183104,
  "created_at" : "2014-02-22 14:08:12 +0000",
  "in_reply_to_screen_name" : "Whitey_chan",
  "in_reply_to_user_id_str" : "48357885",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 0, 12 ],
      "id_str" : "48357885",
      "id" : 48357885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437217656111128576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009588298, 8.2829549833 ]
  },
  "id_str" : "437225643894636544",
  "in_reply_to_user_id" : 48357885,
  "text" : "@Whitey_chan Leidensgenossin, ist der Geruch noch da? :)",
  "id" : 437225643894636544,
  "in_reply_to_status_id" : 437217656111128576,
  "created_at" : "2014-02-22 14:01:31 +0000",
  "in_reply_to_screen_name" : "Whitey_chan",
  "in_reply_to_user_id_str" : "48357885",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 15, 25 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095563926, 8.2854494276 ]
  },
  "id_str" : "437213846764527616",
  "text" : "\u00ABDas w\u00FCrde dem @sparta644 gefallen!\u00BB\u2014\u00ABPotenzpr\u00E4parate?!\u00BB\u2014\u00ABDass hier Springsteen l\u00E4uft\u2026\u00BB",
  "id" : 437213846764527616,
  "created_at" : "2014-02-22 13:14:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096757709, 8.2829991624 ]
  },
  "id_str" : "437166960976355328",
  "text" : "\u00ABWenn sie welche haben nehme ich auch von den Traditionsbr\u00F6tchen.\u00BB\u2014\u00ABDie mit dem Bart, mit dem langen Bart?\u00BB",
  "id" : 437166960976355328,
  "created_at" : "2014-02-22 10:08:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis Zaman",
      "screen_name" : "LuisZaman",
      "indices" : [ 3, 13 ],
      "id_str" : "51947712",
      "id" : 51947712
    }, {
      "name" : "Ian Dworkin",
      "screen_name" : "IanDworkin",
      "indices" : [ 78, 89 ],
      "id_str" : "1115365544",
      "id" : 1115365544
    }, {
      "name" : "Richard E. Lenski",
      "screen_name" : "RELenski",
      "indices" : [ 90, 99 ],
      "id_str" : "1676175931",
      "id" : 1676175931
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 100, 112 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/Hs1bId25BV",
      "expanded_url" : "http:\/\/bit.ly\/1fGGJby",
      "display_url" : "bit.ly\/1fGGJby"
    } ]
  },
  "geo" : { },
  "id_str" : "437048341772648448",
  "text" : "RT @LuisZaman: How Excel nearly ended my relationship: http:\/\/t.co\/Hs1bId25BV @IanDworkin @RELenski @ctitusbrown",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ian Dworkin",
        "screen_name" : "IanDworkin",
        "indices" : [ 63, 74 ],
        "id_str" : "1115365544",
        "id" : 1115365544
      }, {
        "name" : "Richard E. Lenski",
        "screen_name" : "RELenski",
        "indices" : [ 75, 84 ],
        "id_str" : "1676175931",
        "id" : 1676175931
      }, {
        "name" : "Titus Brown",
        "screen_name" : "ctitusbrown",
        "indices" : [ 85, 97 ],
        "id_str" : "26616462",
        "id" : 26616462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/Hs1bId25BV",
        "expanded_url" : "http:\/\/bit.ly\/1fGGJby",
        "display_url" : "bit.ly\/1fGGJby"
      } ]
    },
    "geo" : { },
    "id_str" : "437041125330001921",
    "text" : "How Excel nearly ended my relationship: http:\/\/t.co\/Hs1bId25BV @IanDworkin @RELenski @ctitusbrown",
    "id" : 437041125330001921,
    "created_at" : "2014-02-22 01:48:18 +0000",
    "user" : {
      "name" : "Luis Zaman",
      "screen_name" : "LuisZaman",
      "protected" : false,
      "id_str" : "51947712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1294600387\/DSC_0436-3_normal.JPG",
      "id" : 51947712,
      "verified" : false
    }
  },
  "id" : 437048341772648448,
  "created_at" : "2014-02-22 02:16:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437046871018971137",
  "text" : "Tonights somniloquy: \u00ABThanks! You\u2019re awesome!\u00BB Too bad I will only hear it under these circumstances.",
  "id" : 437046871018971137,
  "created_at" : "2014-02-22 02:11:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 63, 76 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/69o9buPazb",
      "expanded_url" : "http:\/\/chimerasthebooks.blogspot.de\/2014\/02\/converging-genes-reveal-how-plagues.html",
      "display_url" : "chimerasthebooks.blogspot.de\/2014\/02\/conver\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437032789377318913",
  "text" : "Converging genes reveal how plagues have shaped our genome \/cc @PhilippBayer http:\/\/t.co\/69o9buPazb",
  "id" : 437032789377318913,
  "created_at" : "2014-02-22 01:15:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 54, 63 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/PEc2aUcD63",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2014\/02\/how-to-effectively-use-civ-iv-in-higher-education\/",
      "display_url" : "arstechnica.com\/science\/2014\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437032120742338560",
  "text" : "How to effectively use Civ IV in higher education \/cc @Senficon http:\/\/t.co\/PEc2aUcD63",
  "id" : 437032120742338560,
  "created_at" : "2014-02-22 01:12:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/J4qraDa0IU",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0089142#s6",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437031638858743808",
  "text" : "Am I missing something or are those similarity-based \u2018genome codes\u2019 not overly useful? http:\/\/t.co\/J4qraDa0IU",
  "id" : 437031638858743808,
  "created_at" : "2014-02-22 01:10:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 42, 55 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/BKAlARm1rE",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/inkfish\/2014\/02\/21\/how-to-build-a-high-altitude-superdog\/#.Uwf0_GRDtUt",
      "display_url" : "blogs.discovermagazine.com\/inkfish\/2014\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437027609831292928",
  "text" : "How to Build a High-Altitude Superdog \/cc @PhilippBayer http:\/\/t.co\/BKAlARm1rE",
  "id" : 437027609831292928,
  "created_at" : "2014-02-22 00:54:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 3, 10 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Greg Knauss",
      "screen_name" : "gknauss",
      "indices" : [ 120, 128 ],
      "id_str" : "3163591",
      "id" : 3163591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437025870566686720",
  "text" : "RT @buster: \"3 essential tools that online life requires: a sense of humor, a sense of perspective and a thick skin.\" - @gknauss http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter for  iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Greg Knauss",
        "screen_name" : "gknauss",
        "indices" : [ 108, 116 ],
        "id_str" : "3163591",
        "id" : 3163591
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/ixXX8fjit1",
        "expanded_url" : "http:\/\/www.eod.com\/blog\/2014\/02\/empathy-vacuum\/",
        "display_url" : "eod.com\/blog\/2014\/02\/e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "436965295899430912",
    "text" : "\"3 essential tools that online life requires: a sense of humor, a sense of perspective and a thick skin.\" - @gknauss http:\/\/t.co\/ixXX8fjit1",
    "id" : 436965295899430912,
    "created_at" : "2014-02-21 20:46:59 +0000",
    "user" : {
      "name" : "Buster",
      "screen_name" : "buster",
      "protected" : false,
      "id_str" : "2185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/909207953223204864\/DDQjg3OQ_normal.jpg",
      "id" : 2185,
      "verified" : false
    }
  },
  "id" : 437025870566686720,
  "created_at" : "2014-02-22 00:47:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437017863170183169",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437018312615407616",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez drop me an email about what that web app should include and we will see how realistic 2 hours are for that :)",
  "id" : 437018312615407616,
  "in_reply_to_status_id" : 437017863170183169,
  "created_at" : "2014-02-22 00:17:39 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437017524681445378",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437017701383688192",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez but I really don\u2019t mind investing the 15-20 minutes it should take me to get it done :)",
  "id" : 437017701383688192,
  "in_reply_to_status_id" : 437017524681445378,
  "created_at" : "2014-02-22 00:15:14 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/hnyY1jCd3s",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/1871524\/convert-from-json-to-csv-using-python",
      "display_url" : "stackoverflow.com\/questions\/1871\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "437016751822209024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437017318091403264",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez along those lines http:\/\/t.co\/hnyY1jCd3s but really depends on what columns you want &amp; how the json is structured.",
  "id" : 437017318091403264,
  "in_reply_to_status_id" : 437016751822209024,
  "created_at" : "2014-02-22 00:13:42 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437016430148476928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437016635384545280",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez what about: \u201CI will do it if you email me the json-file and say what columns you need\u201D? ;)",
  "id" : 437016635384545280,
  "in_reply_to_status_id" : 437016430148476928,
  "created_at" : "2014-02-22 00:10:59 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/RfCaxKlJbM",
      "expanded_url" : "http:\/\/www.moves-export.com\/",
      "display_url" : "moves-export.com"
    } ]
  },
  "in_reply_to_status_id_str" : "437013434043887616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437016350318690304",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez what about http:\/\/t.co\/RfCaxKlJbM for json export? converting it to csv afterwards should be easy enough.",
  "id" : 437016350318690304,
  "in_reply_to_status_id" : 437013434043887616,
  "created_at" : "2014-02-22 00:09:51 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437014262062387200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437015364149727232",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez oh, that\u2019s a nice idea and I guess ruby isn\u2019t a bad choice for starters. :)",
  "id" : 437015364149727232,
  "in_reply_to_status_id" : 437014262062387200,
  "created_at" : "2014-02-22 00:05:56 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437013434043887616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437013991907684352",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez wasn\u2019t meant to rub it in. I have that much faith in your learning skills, I thought you might have mastered programming by now :)",
  "id" : 437013991907684352,
  "in_reply_to_status_id" : 437013434043887616,
  "created_at" : "2014-02-22 00:00:29 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437012854034542592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437013384945737728",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez oh, that would be great. Looking forward to it!",
  "id" : 437013384945737728,
  "in_reply_to_status_id" : 437012854034542592,
  "created_at" : "2014-02-21 23:58:04 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437012487687270400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437013182474104832",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez well, that would work fine in principle (if you have programming skills). Would a csv help you?",
  "id" : 437013182474104832,
  "in_reply_to_status_id" : 437012487687270400,
  "created_at" : "2014-02-21 23:57:16 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437011618367406080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437012660132257793",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez all the APIs that openSNP offers are there because I\u2019m lazy as hell and wanted an easy way for myself ;)",
  "id" : 437012660132257793,
  "in_reply_to_status_id" : 437011618367406080,
  "created_at" : "2014-02-21 23:55:12 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437011618367406080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437012415247822848",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez but you would guess that at least the developers would love to have an easy way to access data.",
  "id" : 437012415247822848,
  "in_reply_to_status_id" : 437011618367406080,
  "created_at" : "2014-02-21 23:54:13 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @sckottie",
      "screen_name" : "recology_",
      "indices" : [ 0, 10 ],
      "id_str" : "4465848374",
      "id" : 4465848374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437009959302082560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437011455884673024",
  "in_reply_to_user_id" : 103004948,
  "text" : "@recology_ thanks, that means a lot :)",
  "id" : 437011455884673024,
  "in_reply_to_status_id" : 437009959302082560,
  "created_at" : "2014-02-21 23:50:25 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437010618504069120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437011428818821120",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez meh, why are there still apps that don\u2019t allow easy exports?",
  "id" : 437011428818821120,
  "in_reply_to_status_id" : 437010618504069120,
  "created_at" : "2014-02-21 23:50:18 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437010355303108608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437010498144710656",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I guess using the API you could automate it a bit, depending on how you counted your steps at the fitbit-free time.",
  "id" : 437010498144710656,
  "in_reply_to_status_id" : 437010355303108608,
  "created_at" : "2014-02-21 23:46:36 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437009681874055168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437010185740357632",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez that\u2019s a pain to do. Had to do that for a couple of weeks myself as I couldn\u2019t find the charger.",
  "id" : 437010185740357632,
  "in_reply_to_status_id" : 437009681874055168,
  "created_at" : "2014-02-21 23:45:22 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437009164192055299",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437009548000649216",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I keep an eye on the slope of the life time step count over time to see whether it\u2019s \u00B1 constant.",
  "id" : 437009548000649216,
  "in_reply_to_status_id" : 437009164192055299,
  "created_at" : "2014-02-21 23:42:50 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437008572690337792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437009062845501440",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez (but so far I haven\u2019t denied any request, because I don\u2019t look at the ranking often enough to take it too seriously)",
  "id" : 437009062845501440,
  "in_reply_to_status_id" : 437008572690337792,
  "created_at" : "2014-02-21 23:40:54 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437008083542233088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437008414049566720",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez have some of those as well, catch myself looking at average step count before accepting friend requests now.",
  "id" : 437008414049566720,
  "in_reply_to_status_id" : 437008083542233088,
  "created_at" : "2014-02-21 23:38:19 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437007195893280768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437007934145699840",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez thanks, you too! From what I\u2019ve seen we\u2019re often direct rivals for a spot in the top 5 (at least on my friends list :))",
  "id" : 437007934145699840,
  "in_reply_to_status_id" : 437007195893280768,
  "created_at" : "2014-02-21 23:36:25 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437006814102560768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437006985826140160",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez until then I will collect my data with the Flex ;)",
  "id" : 437006985826140160,
  "in_reply_to_status_id" : 437006814102560768,
  "created_at" : "2014-02-21 23:32:39 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437006526377517056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437006718175039488",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez me too, I will let you know if it arrives (and may get back to you in March if it doesn\u2019t arrive by then :))",
  "id" : 437006718175039488,
  "in_reply_to_status_id" : 437006526377517056,
  "created_at" : "2014-02-21 23:31:35 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437006230817472512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437006438872141824",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez nah, no problem. And I\u2019ve seen the recall they started. But we will see, so far I don\u2019t know about me having any allergies :)",
  "id" : 437006438872141824,
  "in_reply_to_status_id" : 437006230817472512,
  "created_at" : "2014-02-21 23:30:28 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437005691039907840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "437006158478733312",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez from my experience with USPS -&gt; Europe it may very well be 4-6 weeks for standard delivery. :)",
  "id" : 437006158478733312,
  "in_reply_to_status_id" : 437005691039907840,
  "created_at" : "2014-02-21 23:29:22 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437005429923516417",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096923318, 8.2830559784 ]
  },
  "id_str" : "437005577789898752",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez still waiting, guess 10 workdays was a bit over-optimistic. ;)",
  "id" : 437005577789898752,
  "in_reply_to_status_id" : 437005429923516417,
  "created_at" : "2014-02-21 23:27:03 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ice Cream Assasin",
      "screen_name" : "_Firebug_",
      "indices" : [ 0, 10 ],
      "id_str" : "15837895",
      "id" : 15837895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436934134616031232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "436934221446512641",
  "in_reply_to_user_id" : 15837895,
  "text" : "@_Firebug_ nope, noch nicht.",
  "id" : 436934221446512641,
  "in_reply_to_status_id" : 436934134616031232,
  "created_at" : "2014-02-21 18:43:30 +0000",
  "in_reply_to_screen_name" : "_Firebug_",
  "in_reply_to_user_id_str" : "15837895",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ice Cream Assasin",
      "screen_name" : "_Firebug_",
      "indices" : [ 0, 10 ],
      "id_str" : "15837895",
      "id" : 15837895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/iYRxoKXzaq",
      "expanded_url" : "https:\/\/www.songkick.com\/concerts\/19465154-bad-religion-at-batschkapp",
      "display_url" : "songkick.com\/concerts\/19465\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "436933477246988288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "436933782172876800",
  "in_reply_to_user_id" : 15837895,
  "text" : "@_Firebug_ 29.05. https:\/\/t.co\/iYRxoKXzaq",
  "id" : 436933782172876800,
  "in_reply_to_status_id" : 436933477246988288,
  "created_at" : "2014-02-21 18:41:46 +0000",
  "in_reply_to_screen_name" : "_Firebug_",
  "in_reply_to_user_id_str" : "15837895",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "It\u2019s SUE! Your Favorite Tyrannosaurus rex \uD83E\uDD96",
      "screen_name" : "SUEtheTrex",
      "indices" : [ 3, 14 ],
      "id_str" : "62127399",
      "id" : 62127399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/adHRzehaDU",
      "expanded_url" : "http:\/\/jezebel.com\/female-minifig-set-under-consideration-for-production-b-1517300685",
      "display_url" : "jezebel.com\/female-minifig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436932444219252736",
  "text" : "RT @SUEtheTrex: LEGO considering releasing a fan-designed female paleontologist set. Best news I've heard all month! http:\/\/t.co\/adHRzehaDU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/adHRzehaDU",
        "expanded_url" : "http:\/\/jezebel.com\/female-minifig-set-under-consideration-for-production-b-1517300685",
        "display_url" : "jezebel.com\/female-minifig\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "436931072303976448",
    "text" : "LEGO considering releasing a fan-designed female paleontologist set. Best news I've heard all month! http:\/\/t.co\/adHRzehaDU",
    "id" : 436931072303976448,
    "created_at" : "2014-02-21 18:31:00 +0000",
    "user" : {
      "name" : "It\u2019s SUE! Your Favorite Tyrannosaurus rex \uD83E\uDD96",
      "screen_name" : "SUEtheTrex",
      "protected" : false,
      "id_str" : "62127399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926471126838136832\/MifuCC5E_normal.jpg",
      "id" : 62127399,
      "verified" : false
    }
  },
  "id" : 436932444219252736,
  "created_at" : "2014-02-21 18:36:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @sckottie",
      "screen_name" : "recology_",
      "indices" : [ 0, 10 ],
      "id_str" : "4465848374",
      "id" : 4465848374
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 53, 62 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436930697576452096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096605033, 8.2830374867 ]
  },
  "id_str" : "436931867099791361",
  "in_reply_to_user_id" : 103004948,
  "text" : "@recology_ no problem, you\u2019re doing a great job with @rOpenSci :)",
  "id" : 436931867099791361,
  "in_reply_to_status_id" : 436930697576452096,
  "created_at" : "2014-02-21 18:34:09 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Religion",
      "screen_name" : "badreligion",
      "indices" : [ 4, 16 ],
      "id_str" : "111678563",
      "id" : 111678563
    }, {
      "name" : "Greg Graffin",
      "screen_name" : "DoctorGraffin",
      "indices" : [ 122, 136 ],
      "id_str" : "54780669",
      "id" : 54780669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096631283, 8.2830754817 ]
  },
  "id_str" : "436931469349761024",
  "text" : "Oh, @badreligion will play in Frankfurt. Tempted to go, if only to get a chance for a neutralist-selectionist debate with @DoctorGraffin\u2026",
  "id" : 436931469349761024,
  "created_at" : "2014-02-21 18:32:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 0, 9 ],
      "id_str" : "342250615",
      "id" : 342250615
    }, {
      "name" : "renamed @sckottie",
      "screen_name" : "recology_",
      "indices" : [ 33, 43 ],
      "id_str" : "4465848374",
      "id" : 4465848374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436929701261488128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096631283, 8.2830754817 ]
  },
  "id_str" : "436930223528235009",
  "in_reply_to_user_id" : 342250615,
  "text" : "@rOpenSci awesome, thanks a lot! @recology_",
  "id" : 436930223528235009,
  "in_reply_to_status_id" : 436929701261488128,
  "created_at" : "2014-02-21 18:27:37 +0000",
  "in_reply_to_screen_name" : "rOpenSci",
  "in_reply_to_user_id_str" : "342250615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436892578211180544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1652297872, 8.6201226347 ]
  },
  "id_str" : "436892689846796288",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot k\u00F6nnte also doch deine sein. ;)",
  "id" : 436892689846796288,
  "in_reply_to_status_id" : 436892578211180544,
  "created_at" : "2014-02-21 15:58:28 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436891484168921088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1653123272, 8.6202609107 ]
  },
  "id_str" : "436892006414295040",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nur weil mir deine Hosen zu gross sind? :p",
  "id" : 436892006414295040,
  "in_reply_to_status_id" : 436891484168921088,
  "created_at" : "2014-02-21 15:55:46 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436890539808808960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1654199217, 8.6204411595 ]
  },
  "id_str" : "436891274113994752",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot mit Betonung auf _ich_ ;)",
  "id" : 436891274113994752,
  "in_reply_to_status_id" : 436890539808808960,
  "created_at" : "2014-02-21 15:52:51 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "offenbach",
      "indices" : [ 111, 121 ]
    }, {
      "text" : "bendit",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436859835024695296",
  "text" : "RT @Lobot: \"K\u00F6rper und Raum\" ist Thema bei der Bended Realities 2014 (&amp; Make Rhein-Main), 23.-25.\u200B5.\u200B2014, #offenbach #bendit. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "offenbach",
        "indices" : [ 100, 110 ]
      }, {
        "text" : "bendit",
        "indices" : [ 111, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/2zSDPEVDhB",
        "expanded_url" : "http:\/\/bendedrealities.blogsport.de\/2014\/02\/08\/bended-realitiesmake-rhein-main-2014-bodycloud\/",
        "display_url" : "bendedrealities.blogsport.de\/2014\/02\/08\/ben\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "436858980661743617",
    "text" : "\"K\u00F6rper und Raum\" ist Thema bei der Bended Realities 2014 (&amp; Make Rhein-Main), 23.-25.\u200B5.\u200B2014, #offenbach #bendit. http:\/\/t.co\/2zSDPEVDhB",
    "id" : 436858980661743617,
    "created_at" : "2014-02-21 13:44:32 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 436859835024695296,
  "created_at" : "2014-02-21 13:47:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436857044294197249",
  "text" : "\u00ABIch finde dich so niedlich. Und deswegen mache ich hier jetzt mal dieses Bett kaputt, ja?\u00BB",
  "id" : 436857044294197249,
  "created_at" : "2014-02-21 13:36:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Y8w0gZxpIi",
      "expanded_url" : "http:\/\/www.wired.com\/wiredscience\/2014\/02\/absurd-creature-of-the-week-pearlfish\/",
      "display_url" : "wired.com\/wiredscience\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436850983864639488",
  "text" : "why being a sea cucumber can suck: fish may swim up your butt, which you also breath through, and eat your gonads. http:\/\/t.co\/Y8w0gZxpIi",
  "id" : 436850983864639488,
  "created_at" : "2014-02-21 13:12:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcrowd",
      "screen_name" : "bitcrowd",
      "indices" : [ 3, 12 ],
      "id_str" : "91092351",
      "id" : 91092351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "programming",
      "indices" : [ 79, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/j9Vcdd7wIo",
      "expanded_url" : "http:\/\/buff.ly\/1l4h3gw",
      "display_url" : "buff.ly\/1l4h3gw"
    } ]
  },
  "geo" : { },
  "id_str" : "436844827033223168",
  "text" : "RT @bitcrowd: \"Gently pass the pointer to the function\" http:\/\/t.co\/j9Vcdd7wIo #programming",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "programming",
        "indices" : [ 65, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/j9Vcdd7wIo",
        "expanded_url" : "http:\/\/buff.ly\/1l4h3gw",
        "display_url" : "buff.ly\/1l4h3gw"
      } ]
    },
    "geo" : { },
    "id_str" : "436837238375456768",
    "text" : "\"Gently pass the pointer to the function\" http:\/\/t.co\/j9Vcdd7wIo #programming",
    "id" : 436837238375456768,
    "created_at" : "2014-02-21 12:18:08 +0000",
    "user" : {
      "name" : "bitcrowd",
      "screen_name" : "bitcrowd",
      "protected" : false,
      "id_str" : "91092351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487605589317386241\/Rfcw0sdp_normal.png",
      "id" : 91092351,
      "verified" : false
    }
  },
  "id" : 436844827033223168,
  "created_at" : "2014-02-21 12:48:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/xowMn7dkVc",
      "expanded_url" : "http:\/\/i.imgur.com\/zH9L4Gr.gif",
      "display_url" : "i.imgur.com\/zH9L4Gr.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "436842126736125952",
  "text" : "i'd probably love that new park http:\/\/t.co\/xowMn7dkVc",
  "id" : 436842126736125952,
  "created_at" : "2014-02-21 12:37:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/C6ZWSziAlC",
      "expanded_url" : "http:\/\/thescienceweb.wordpress.com\/2014\/02\/21\/bioinformatics-software-companies-have-no-clue-why-no-one-buys-their-products\/",
      "display_url" : "thescienceweb.wordpress.com\/2014\/02\/21\/bio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436831025873027072",
  "text" : "Bioinformatics software companies have no clue why no-one buys their products http:\/\/t.co\/C6ZWSziAlC",
  "id" : 436831025873027072,
  "created_at" : "2014-02-21 11:53:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Umlwnqip6u",
      "expanded_url" : "http:\/\/www.theonion.com\/articles\/open-relationship-gives-couple-freedom-to-emotiona,35334\/",
      "display_url" : "theonion.com\/articles\/open-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436808731180163073",
  "text" : "\u00ABOpen Relationship Gives Couple Freedom To Emotionally Drain Other People From Time To Time\u00BB http:\/\/t.co\/Umlwnqip6u",
  "id" : 436808731180163073,
  "created_at" : "2014-02-21 10:24:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gegengewalt",
      "screen_name" : "ekelias",
      "indices" : [ 0, 8 ],
      "id_str" : "15890805",
      "id" : 15890805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436799114303770624",
  "geo" : { },
  "id_str" : "436805157729599488",
  "in_reply_to_user_id" : 15890805,
  "text" : "@ekelias gedankenplag darf gerne mein Twitterarchiv auf Plagiate untersuchen!",
  "id" : 436805157729599488,
  "in_reply_to_status_id" : 436799114303770624,
  "created_at" : "2014-02-21 10:10:39 +0000",
  "in_reply_to_screen_name" : "ekelias",
  "in_reply_to_user_id_str" : "15890805",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/FQxv0Dn1WC",
      "expanded_url" : "http:\/\/www.wired.com\/wiredscience\/2014\/02\/dog-brains-vocal-processing\/",
      "display_url" : "wired.com\/wiredscience\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436803917415190529",
  "text" : "Damn, I could have gone for a career of doing fMRI w\/ golden retrievers &amp; border collies?! These bad life decisions\u2026 http:\/\/t.co\/FQxv0Dn1WC",
  "id" : 436803917415190529,
  "created_at" : "2014-02-21 10:05:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/Fb4w1Giybn",
      "expanded_url" : "http:\/\/instagram.com\/p\/krIRvhhwjy\/",
      "display_url" : "instagram.com\/p\/krIRvhhwjy\/"
    } ]
  },
  "geo" : { },
  "id_str" : "436801692366274560",
  "text" : "\u00ABLiebe Kollegen, f\u00FCr die Zukunft finden sie ab sofort Notfall-'H\u00FCte der Schande' auf den Fluren\u2026 http:\/\/t.co\/Fb4w1Giybn",
  "id" : 436801692366274560,
  "created_at" : "2014-02-21 09:56:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723200879, 8.6276451801 ]
  },
  "id_str" : "436798676355514368",
  "text" : "Status: Doktor Rant",
  "id" : 436798676355514368,
  "created_at" : "2014-02-21 09:44:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/0Jwn4C6hXF",
      "expanded_url" : "http:\/\/www.theatlantic.com\/features\/archive\/2014\/03\/the-dark-power-of-fraternities\/357580\/",
      "display_url" : "theatlantic.com\/features\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436794337738129408",
  "text" : "\u00ABnot an excellent idea was to misjudge the tightness of a 20-year-old sphincter &amp; the reliability of a 20cent rocket\u00BB http:\/\/t.co\/0Jwn4C6hXF",
  "id" : 436794337738129408,
  "created_at" : "2014-02-21 09:27:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436793155988758528",
  "geo" : { },
  "id_str" : "436793904399400960",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot not sure whether male privilege or with whom the dog is associated explains the difference in status. ;)",
  "id" : 436793904399400960,
  "in_reply_to_status_id" : 436793155988758528,
  "created_at" : "2014-02-21 09:25:56 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/52gTuGwLsK",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/02\/20\/the-difference-between-a-white.html",
      "display_url" : "boingboing.net\/2014\/02\/20\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436793230395711488",
  "text" : "The difference between a white guy breaking into a car and a black guy breaking into a car http:\/\/t.co\/52gTuGwLsK",
  "id" : 436793230395711488,
  "created_at" : "2014-02-21 09:23:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436792262274867200",
  "text" : "at my last job the office dog was given a postdog position. at my current job the office dog is filed only as a lowly undergrad.",
  "id" : 436792262274867200,
  "created_at" : "2014-02-21 09:19:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436790631642710016",
  "text" : "RT @PhilippBayer: Little known fact: Eclipse is actually an art project to find out whether Kafka's 'The Trial' can be expressed in softwar\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "436683590269562880",
    "text" : "Little known fact: Eclipse is actually an art project to find out whether Kafka's 'The Trial' can be expressed in software.",
    "id" : 436683590269562880,
    "created_at" : "2014-02-21 02:07:35 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 436790631642710016,
  "created_at" : "2014-02-21 09:12:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/mhSIjQZ9tl",
      "expanded_url" : "http:\/\/www.wellsortedversion.com\/",
      "display_url" : "wellsortedversion.com"
    } ]
  },
  "geo" : { },
  "id_str" : "436789495867125761",
  "text" : "\u00ABThis is the \"Well-Sorted Version\", a Bible containing the complete text of the King James Version, alphabetized.\u00BB http:\/\/t.co\/mhSIjQZ9tl",
  "id" : 436789495867125761,
  "created_at" : "2014-02-21 09:08:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Parker",
      "screen_name" : "Alex_Parker",
      "indices" : [ 3, 15 ],
      "id_str" : "18644734",
      "id" : 18644734
    }, {
      "name" : "plotly",
      "screen_name" : "plotlygraphs",
      "indices" : [ 78, 91 ],
      "id_str" : "1392826357",
      "id" : 1392826357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/N0RkudgoTL",
      "expanded_url" : "https:\/\/plot.ly\/~alexhp\/61\/",
      "display_url" : "plot.ly\/~alexhp\/61\/"
    } ]
  },
  "geo" : { },
  "id_str" : "436786928823062528",
  "text" : "RT @Alex_Parker: How popular is \"space\" vs. \"spaaace?\" I turned to Google and @plotlygraphs to find out: https:\/\/t.co\/N0RkudgoTL http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "plotly",
        "screen_name" : "plotlygraphs",
        "indices" : [ 61, 74 ],
        "id_str" : "1392826357",
        "id" : 1392826357
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Alex_Parker\/status\/436595992347963392\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/e3R4CRsofJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bg8ZverCcAA5I0a.jpg",
        "id_str" : "436595992356352000",
        "id" : 436595992356352000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bg8ZverCcAA5I0a.jpg",
        "sizes" : [ {
          "h" : 365,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 645,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/e3R4CRsofJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/N0RkudgoTL",
        "expanded_url" : "https:\/\/plot.ly\/~alexhp\/61\/",
        "display_url" : "plot.ly\/~alexhp\/61\/"
      } ]
    },
    "geo" : { },
    "id_str" : "436595992347963392",
    "text" : "How popular is \"space\" vs. \"spaaace?\" I turned to Google and @plotlygraphs to find out: https:\/\/t.co\/N0RkudgoTL http:\/\/t.co\/e3R4CRsofJ",
    "id" : 436595992347963392,
    "created_at" : "2014-02-20 20:19:30 +0000",
    "user" : {
      "name" : "Alex Parker",
      "screen_name" : "Alex_Parker",
      "protected" : false,
      "id_str" : "18644734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616729283768266752\/es8ydAzc_normal.jpg",
      "id" : 18644734,
      "verified" : true
    }
  },
  "id" : 436786928823062528,
  "created_at" : "2014-02-21 08:58:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/YAsKHPLBbj",
      "expanded_url" : "http:\/\/xkcd.com\/1333\/",
      "display_url" : "xkcd.com\/1333\/"
    } ]
  },
  "geo" : { },
  "id_str" : "436786341821812736",
  "text" : "awkward first dates http:\/\/t.co\/YAsKHPLBbj",
  "id" : 436786341821812736,
  "created_at" : "2014-02-21 08:55:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436676397914787840",
  "geo" : { },
  "id_str" : "436781930659713024",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks, still haven't done a course on git with my group, but doing it is still on my to-do. :)",
  "id" : 436781930659713024,
  "in_reply_to_status_id" : 436676397914787840,
  "created_at" : "2014-02-21 08:38:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/e0zIHPYM9E",
      "expanded_url" : "http:\/\/www.allyourbasearebelongtous.com\/gif\/allyourbase.gif",
      "display_url" : "allyourbasearebelongtous.com\/gif\/allyourbas\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009677941, 8.2830025902 ]
  },
  "id_str" : "436656126227394560",
  "text" : "\u00ABSomebody set up us the bomb.\u00BB \u2014 \u00ABAll your gate are belong to us.\u00BB http:\/\/t.co\/e0zIHPYM9E",
  "id" : 436656126227394560,
  "created_at" : "2014-02-21 00:18:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/B3FgXNnxAz",
      "expanded_url" : "http:\/\/minimaxir.com\/2014\/02\/glory-to-the-helix\/",
      "display_url" : "minimaxir.com\/2014\/02\/glory-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436519773502189568",
  "text" : "\u00ABKnowing how to fail gracefully is always valuable\u00BB Game Theory: How 70,000 Pokemon Players Sabotage Themselves http:\/\/t.co\/B3FgXNnxAz",
  "id" : 436519773502189568,
  "created_at" : "2014-02-20 15:16:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/XZLkParcSL",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view\/454505\/airplane-panic-o.gif",
      "display_url" : "stream1.gifsoup.com\/view\/454505\/ai\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723028277, 8.6276389156 ]
  },
  "id_str" : "436502574158868480",
  "text" : "the cluster is now running on emergency batteries, general mood: http:\/\/t.co\/XZLkParcSL",
  "id" : 436502574158868480,
  "created_at" : "2014-02-20 14:08:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436479511652491264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723126649, 8.6276219902 ]
  },
  "id_str" : "436482317859971072",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy \u2018anlassunabh\u00E4ngige Verkehrskontrolle\u2019*, der Drogenfahndung. *Fahrer hat bunte Haare.",
  "id" : 436482317859971072,
  "in_reply_to_status_id" : 436479511652491264,
  "created_at" : "2014-02-20 12:47:48 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1730106492, 8.6277171504 ]
  },
  "id_str" : "436478884478222336",
  "text" : "\u00ABSie machen jetzt mal einen Drogentest.\u00BB\u2014\u00ABAuf welcher Grundlage?\u00BB\u2014\u00ABDer ist freiwillig.\u00BB\u2014\u00ABAh, also mache ich jetzt mal keinen Drogentest.\u00BB",
  "id" : 436478884478222336,
  "created_at" : "2014-02-20 12:34:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436458472277032961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.9330804553, 7.8824255616 ]
  },
  "id_str" : "436459500347097089",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot let the doge drive home. wow, so fast, very road.",
  "id" : 436459500347097089,
  "in_reply_to_status_id" : 436458472277032961,
  "created_at" : "2014-02-20 11:17:08 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436456929926606848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.9331010748, 7.8824326862 ]
  },
  "id_str" : "436457157979303936",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot handed the driving to Siri for a while, so I can catch up on my timeline!",
  "id" : 436457157979303936,
  "in_reply_to_status_id" : 436456929926606848,
  "created_at" : "2014-02-20 11:07:50 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.9331064811, 7.8824108932 ]
  },
  "id_str" : "436455899985899520",
  "text" : "putting the fun in funeral: road trips with empty highways and lots of me time.",
  "id" : 436455899985899520,
  "created_at" : "2014-02-20 11:02:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nigel Warburton",
      "screen_name" : "philosophybites",
      "indices" : [ 3, 19 ],
      "id_str" : "37238862",
      "id" : 37238862
    }, {
      "name" : "Radiolab \uD83D\uDD2C",
      "screen_name" : "Radiolab",
      "indices" : [ 107, 116 ],
      "id_str" : "28583197",
      "id" : 28583197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/zkukleMR6f",
      "expanded_url" : "http:\/\/theappendix.net\/blog\/2014\/2\/darwins-children-drew-vegetable-battles-on-the-origin-of-species",
      "display_url" : "theappendix.net\/blog\/2014\/2\/da\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436287381235585024",
  "text" : "RT @philosophybites: Darwin's children drew on his Origin of Species manuscript http:\/\/t.co\/zkukleMR6f via @Radiolab",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Radiolab \uD83D\uDD2C",
        "screen_name" : "Radiolab",
        "indices" : [ 86, 95 ],
        "id_str" : "28583197",
        "id" : 28583197
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/zkukleMR6f",
        "expanded_url" : "http:\/\/theappendix.net\/blog\/2014\/2\/darwins-children-drew-vegetable-battles-on-the-origin-of-species",
        "display_url" : "theappendix.net\/blog\/2014\/2\/da\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "436284563543707648",
    "text" : "Darwin's children drew on his Origin of Species manuscript http:\/\/t.co\/zkukleMR6f via @Radiolab",
    "id" : 436284563543707648,
    "created_at" : "2014-02-19 23:42:00 +0000",
    "user" : {
      "name" : "Nigel Warburton",
      "screen_name" : "philosophybites",
      "protected" : false,
      "id_str" : "37238862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/878329460180656128\/Ut9ffVks_normal.jpg",
      "id" : 37238862,
      "verified" : false
    }
  },
  "id" : 436287381235585024,
  "created_at" : "2014-02-19 23:53:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/gY2q7pc2TP",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/gaireczhDG4\/info%3Adoi%2F10.1371%2Fjournal.pone.0087184",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436276854283333632",
  "text" : "Fate of Clinical Research Studies after Ethical Approval \u2013 Follow-Up of Study Protocols until Publication http:\/\/t.co\/gY2q7pc2TP",
  "id" : 436276854283333632,
  "created_at" : "2014-02-19 23:11:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 3, 16 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436256863353856000",
  "text" : "RT @MishaAngrist: \u201CI use the words you taught me. If they don't mean anything any more, teach me others. Or let me be silent.\u201D  - S. Becket\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "436256516786905088",
    "text" : "\u201CI use the words you taught me. If they don't mean anything any more, teach me others. Or let me be silent.\u201D  - S. Beckett after IRB review",
    "id" : 436256516786905088,
    "created_at" : "2014-02-19 21:50:33 +0000",
    "user" : {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "protected" : false,
      "id_str" : "116877838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747461459974717441\/GIrZkLT-_normal.jpg",
      "id" : 116877838,
      "verified" : false
    }
  },
  "id" : 436256863353856000,
  "created_at" : "2014-02-19 21:51:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/nupv99pFhw",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/NerdcoreRSS2\/~3\/_x006rGwYyA\/",
      "display_url" : "feedproxy.google.com\/~r\/NerdcoreRSS\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.089437, 7.613489 ]
  },
  "id_str" : "436250143537786880",
  "text" : "Marc Almond sings Tainted Love on old Hardware http:\/\/t.co\/nupv99pFhw",
  "id" : 436250143537786880,
  "created_at" : "2014-02-19 21:25:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.0894544732, 7.6134513565 ]
  },
  "id_str" : "436240965058457601",
  "text" : "\u00ABSie haben ihm vier mal die Letzte \u00D6lung gegeben. Und jedes mal hat er sich wieder erholt. Irgendwas muss da drin sein!\u00BB",
  "id" : 436240965058457601,
  "created_at" : "2014-02-19 20:48:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.8197262714, 7.5915898422 ]
  },
  "id_str" : "436157580390723584",
  "text" : "\u00ABWie un\u00FCbersichtlich, mit wem darf ich nicht reden weil du sie nicht magst? K\u00F6nnte man ihnen nicht Armbinden geben? Opa h\u00E4tte es gefallen!\u00BB",
  "id" : 436157580390723584,
  "created_at" : "2014-02-19 15:17:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.8196634258, 7.5916699683 ]
  },
  "id_str" : "436145667896246272",
  "text" : "Catholicism, the overly successful codification of abusive relationships\u2026",
  "id" : 436145667896246272,
  "created_at" : "2014-02-19 14:30:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.0893614281, 7.6135016474 ]
  },
  "id_str" : "436098623592742912",
  "text" : "\u00ABDein Cousin 3. Grades sagt bei Facebook stehe du bist bisexuell. Echt?\u00BB\u2014\u00ABYep\u00BB\u2014\u00ABCool, aber da schwinden die Chancen auf Enkel wieder dahin\u2026\u00BB",
  "id" : 436098623592742912,
  "created_at" : "2014-02-19 11:23:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/8ae34QKCcX",
      "expanded_url" : "http:\/\/www.scilogs.de\/sciencezest\/sex-im-19-jahrhundert\/",
      "display_url" : "scilogs.de\/sciencezest\/se\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.089331, 7.613587 ]
  },
  "id_str" : "436092053559455744",
  "text" : "Sex im 19. Jahrhundert  http:\/\/t.co\/8ae34QKCcX",
  "id" : 436092053559455744,
  "created_at" : "2014-02-19 10:57:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/eQJN3GMXhi",
      "expanded_url" : "http:\/\/simplystatistics.org\/2014\/02\/18\/k-means-clustering-in-a-gif\/",
      "display_url" : "simplystatistics.org\/2014\/02\/18\/k-m\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.089284, 7.613674 ]
  },
  "id_str" : "436091522107600896",
  "text" : "k-means clustering in a GIF http:\/\/t.co\/eQJN3GMXhi",
  "id" : 436091522107600896,
  "created_at" : "2014-02-19 10:54:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/tLLF1bF6RT",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/GDHjncRHcX4\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.089358, 7.613467 ]
  },
  "id_str" : "436077260710637568",
  "text" : "Now I know what I need for the next baking session: Tessellated Escher\u00A0cookies http:\/\/t.co\/tLLF1bF6RT",
  "id" : 436077260710637568,
  "created_at" : "2014-02-19 09:58:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/SQuXAwAZ4e",
      "expanded_url" : "http:\/\/xkcd.com\/1332\/",
      "display_url" : "xkcd.com\/1332\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.085916, 7.620135 ]
  },
  "id_str" : "436076381207015424",
  "text" : "Slippery Slope http:\/\/t.co\/SQuXAwAZ4e",
  "id" : 436076381207015424,
  "created_at" : "2014-02-19 09:54:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 0, 12 ],
      "id_str" : "48357885",
      "id" : 48357885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436069990379585536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.0894791987, 7.6134034198 ]
  },
  "id_str" : "436071001101991936",
  "in_reply_to_user_id" : 48357885,
  "text" : "@Whitey_chan ja, zumindest im Punkt Akzeptanz meiner Sexualit\u00E4t &amp; Beziehungen kann ich nicht klagen.",
  "id" : 436071001101991936,
  "in_reply_to_status_id" : 436069990379585536,
  "created_at" : "2014-02-19 09:33:23 +0000",
  "in_reply_to_screen_name" : "Whitey_chan",
  "in_reply_to_user_id_str" : "48357885",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.0893589991, 7.6134998201 ]
  },
  "id_str" : "436068697908973568",
  "text" : "\u00ABMeine G\u00FCte, wieviele Freundinnen hast du denn?! Und: Habe ich jetzt eigentlich bessere Chancen Gro\u00DFmutter zu werden?!\u00BB",
  "id" : 436068697908973568,
  "created_at" : "2014-02-19 09:24:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.0894486108, 7.6134698574 ]
  },
  "id_str" : "435933274117275648",
  "text" : "\u00ABIch bin ganz unruhig geworden &amp; hab fest an ihn gedacht und dann ist er gestorben!\u00BB\u2014\u00ABDann tu mir den gefallen und denk nie wieder an mich!\u00BB",
  "id" : 435933274117275648,
  "created_at" : "2014-02-19 00:26:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.0895044003, 7.613401047 ]
  },
  "id_str" : "435914568456765440",
  "text" : "pretending to care +1",
  "id" : 435914568456765440,
  "created_at" : "2014-02-18 23:11:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/nFOHgh81Cp",
      "expanded_url" : "http:\/\/www.theallium.com\/science-life\/public-health-study-reveals-dissertation-deadline-day-is-most-significant-cause-of-grandparent-mortality\/",
      "display_url" : "theallium.com\/science-life\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435797578571997184",
  "text" : "Dissertation deadline day is most significant cause of grandparent mortality http:\/\/t.co\/nFOHgh81Cp",
  "id" : 435797578571997184,
  "created_at" : "2014-02-18 15:26:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 30, 42 ],
      "id_str" : "48357885",
      "id" : 48357885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/ds7jW8Z738",
      "expanded_url" : "http:\/\/en.meetinghalfway.eu\/2013\/12\/31\/polyamory-three-views\/",
      "display_url" : "en.meetinghalfway.eu\/2013\/12\/31\/pol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435793791228710912",
  "text" : "\u00ABPolyamory \u2013 Three Views\u00BB Thx @Whitey_chan http:\/\/t.co\/ds7jW8Z738",
  "id" : 435793791228710912,
  "created_at" : "2014-02-18 15:11:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435781940021448704",
  "geo" : { },
  "id_str" : "435786639994920960",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a awesome, thanks :)",
  "id" : 435786639994920960,
  "in_reply_to_status_id" : 435781940021448704,
  "created_at" : "2014-02-18 14:43:26 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 3, 8 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 10, 26 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/OXb7ZoeHer",
      "expanded_url" : "http:\/\/sleeptalkinman.blogspot.de\/",
      "display_url" : "sleeptalkinman.blogspot.de"
    } ]
  },
  "geo" : { },
  "id_str" : "435786600497545216",
  "text" : "RT @li5a: @gedankenstuecke pff, http:\/\/t.co\/OXb7ZoeHer will always win that one.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/OXb7ZoeHer",
        "expanded_url" : "http:\/\/sleeptalkinman.blogspot.de\/",
        "display_url" : "sleeptalkinman.blogspot.de"
      } ]
    },
    "in_reply_to_status_id_str" : "435769277690310657",
    "geo" : { },
    "id_str" : "435781940021448704",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke pff, http:\/\/t.co\/OXb7ZoeHer will always win that one.",
    "id" : 435781940021448704,
    "in_reply_to_status_id" : 435769277690310657,
    "created_at" : "2014-02-18 14:24:45 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "li5a",
      "screen_name" : "li5a",
      "protected" : false,
      "id_str" : "11712822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/42645812\/P1010897_normal.JPG",
      "id" : 11712822,
      "verified" : false
    }
  },
  "id" : 435786600497545216,
  "created_at" : "2014-02-18 14:43:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/4OEC6XHXbM",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/AskReddit\/comments\/1y7al5\/whats_the_funniest_thing_youve_heard_someone_say\/",
      "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435769277690310657",
  "text" : "\/r\/askreddit: \u00ABWhat's the funniest thing you've heard someone say in their sleep?\u00BB http:\/\/t.co\/4OEC6XHXbM",
  "id" : 435769277690310657,
  "created_at" : "2014-02-18 13:34:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/OIZfQg0uD1",
      "expanded_url" : "http:\/\/america.aljazeera.com\/opinions\/2014\/2\/maps-cartographycolonialismnortheurocentricglobe.html",
      "display_url" : "america.aljazeera.com\/opinions\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435763037929086976",
  "text" : "How the north ended up on top of the map http:\/\/t.co\/OIZfQg0uD1",
  "id" : 435763037929086976,
  "created_at" : "2014-02-18 13:09:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 3, 13 ],
      "id_str" : "35304791",
      "id" : 35304791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/eWTmK8bAce",
      "expanded_url" : "http:\/\/feedly.com\/e\/rxy_8Wxg",
      "display_url" : "feedly.com\/e\/rxy_8Wxg"
    } ]
  },
  "geo" : { },
  "id_str" : "435746715816452096",
  "text" : "RT @razibkhan: w. d. hamilton smiles. Fairness Through Spite http:\/\/t.co\/eWTmK8bAce",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/eWTmK8bAce",
        "expanded_url" : "http:\/\/feedly.com\/e\/rxy_8Wxg",
        "display_url" : "feedly.com\/e\/rxy_8Wxg"
      } ]
    },
    "geo" : { },
    "id_str" : "435732285875167232",
    "text" : "w. d. hamilton smiles. Fairness Through Spite http:\/\/t.co\/eWTmK8bAce",
    "id" : 435732285875167232,
    "created_at" : "2014-02-18 11:07:27 +0000",
    "user" : {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "protected" : false,
      "id_str" : "35304791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890083843385958400\/YKPy0Uup_normal.jpg",
      "id" : 35304791,
      "verified" : true
    }
  },
  "id" : 435746715816452096,
  "created_at" : "2014-02-18 12:04:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/TugQigkB1r",
      "expanded_url" : "http:\/\/i.imgur.com\/JOoufzQ.gif",
      "display_url" : "i.imgur.com\/JOoufzQ.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "435745664664748033",
  "text" : "\u00ABIch glaube ich falle gerade in das ber\u00FCchtigte Mittagsloch\u2026\u00BB http:\/\/t.co\/TugQigkB1r",
  "id" : 435745664664748033,
  "created_at" : "2014-02-18 12:00:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 0, 12 ],
      "id_str" : "48357885",
      "id" : 48357885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435733767547015169",
  "geo" : { },
  "id_str" : "435745293422718976",
  "in_reply_to_user_id" : 48357885,
  "text" : "@Whitey_chan auch das kommt mir sehr bekannt vor ;)",
  "id" : 435745293422718976,
  "in_reply_to_status_id" : 435733767547015169,
  "created_at" : "2014-02-18 11:59:08 +0000",
  "in_reply_to_screen_name" : "Whitey_chan",
  "in_reply_to_user_id_str" : "48357885",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 0, 12 ],
      "id_str" : "48357885",
      "id" : 48357885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435731019296423936",
  "geo" : { },
  "id_str" : "435732809353670656",
  "in_reply_to_user_id" : 48357885,
  "text" : "@Whitey_chan hilft es bei dir? ;)",
  "id" : 435732809353670656,
  "in_reply_to_status_id" : 435731019296423936,
  "created_at" : "2014-02-18 11:09:31 +0000",
  "in_reply_to_screen_name" : "Whitey_chan",
  "in_reply_to_user_id_str" : "48357885",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 0, 12 ],
      "id_str" : "48357885",
      "id" : 48357885
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/435728977865760768\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/XsaMP9zVBZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgwFMlfIgAA1YVj.png",
      "id_str" : "435728977727356928",
      "id" : 435728977727356928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgwFMlfIgAA1YVj.png",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/XsaMP9zVBZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435726179057041408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723338753, 8.6276088812 ]
  },
  "id_str" : "435728977865760768",
  "in_reply_to_user_id" : 48357885,
  "text" : "@Whitey_chan kommt mir bekannt vor. http:\/\/t.co\/XsaMP9zVBZ",
  "id" : 435728977865760768,
  "in_reply_to_status_id" : 435726179057041408,
  "created_at" : "2014-02-18 10:54:18 +0000",
  "in_reply_to_screen_name" : "Whitey_chan",
  "in_reply_to_user_id_str" : "48357885",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/Ew4PzPlBpu",
      "expanded_url" : "http:\/\/instagram.com\/p\/kjcFPnBwtr\/",
      "display_url" : "instagram.com\/p\/kjcFPnBwtr\/"
    } ]
  },
  "geo" : { },
  "id_str" : "435719345873108992",
  "text" : "For all the things we don't like about our jobs in academia, this also happens http:\/\/t.co\/Ew4PzPlBpu",
  "id" : 435719345873108992,
  "created_at" : "2014-02-18 10:16:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Sg0HYPCaac",
      "expanded_url" : "http:\/\/www.theatlantic.com\/health\/archive\/2014\/02\/big-breakthroughs-come-in-your-late-30s\/283858\/",
      "display_url" : "theatlantic.com\/health\/archive\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435713871643287553",
  "text" : "Damn, so I might not even whine about not having a Nobel yet but will have to wait at least 10 more years for that?! http:\/\/t.co\/Sg0HYPCaac",
  "id" : 435713871643287553,
  "created_at" : "2014-02-18 09:54:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1330954107, 8.6720391857 ]
  },
  "id_str" : "435698350395236352",
  "text" : "\u00ABYou look horrible.\u00BB \u2014 \u00ABHad to discuss the n-body problem all night.\u00BB \u2014 \u00ABSo did you talk celestial mechanics, spree-killing or polyamory?\u00BB",
  "id" : 435698350395236352,
  "created_at" : "2014-02-18 08:52:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/z4N9kVBpsV",
      "expanded_url" : "http:\/\/kleinerdrei.org\/2014\/02\/die-abenteuer-von-konservatives-feuilleton-man-ein-exklusives-interview\/",
      "display_url" : "kleinerdrei.org\/2014\/02\/die-ab\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435689299435331584",
  "text" : "Die Abenteuer von Konservatives Feuilleton Man: \u00ABein Held von gestern, abgefeiert in den Medien von heute\u00BB\n\n http:\/\/t.co\/z4N9kVBpsV",
  "id" : 435689299435331584,
  "created_at" : "2014-02-18 08:16:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/xarfkT67Mj",
      "expanded_url" : "http:\/\/mendeliandisorder.blogspot.com\/2014\/02\/why-we-didnt-sequence-hela.html",
      "display_url" : "mendeliandisorder.blogspot.com\/2014\/02\/why-we\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.01736, 8.431648 ]
  },
  "id_str" : "435683702790946816",
  "text" : "\u00ABWhy we didn't sequence HeLa\u00BB http:\/\/t.co\/xarfkT67Mj",
  "id" : 435683702790946816,
  "created_at" : "2014-02-18 07:54:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/6WWp3ak32K",
      "expanded_url" : "http:\/\/www.ripleys.com\/weird\/daily-dose-of-weird-wtf-blog\/strange-places-and-customs\/spend-the-night-in-a-giant-anus\/",
      "display_url" : "ripleys.com\/weird\/daily-do\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.153707, 8.660389 ]
  },
  "id_str" : "435682213188091904",
  "text" : "I might have said I would never move to Brussels and surroundings. I also might have to reconsider that.  http:\/\/t.co\/6WWp3ak32K",
  "id" : 435682213188091904,
  "created_at" : "2014-02-18 07:48:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096555416, 8.2829699643 ]
  },
  "id_str" : "435672047197622272",
  "text" : "\u00ABI\u2019m not sure yet on whether I\u2019m in love, I haven\u2019t collected enough data to make a rational decision. More research is clearly needed.\u00BB",
  "id" : 435672047197622272,
  "created_at" : "2014-02-18 07:08:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096631283, 8.2830754817 ]
  },
  "id_str" : "435570596882415616",
  "text" : "\u00ABDu hast versehentlich Ratte gegessen? Aber du bist doch Vegetarier!\u00BB",
  "id" : 435570596882415616,
  "created_at" : "2014-02-18 00:24:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Glasser",
      "screen_name" : "glasserp",
      "indices" : [ 0, 9 ],
      "id_str" : "15051699",
      "id" : 15051699
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 77, 90 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435562044939448320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096631283, 8.2830754817 ]
  },
  "id_str" : "435562606804602880",
  "in_reply_to_user_id" : 15051699,
  "text" : "@glasserp currently don\u2019t have access to the queue to have a look, but maybe @PhilippBayer can help out. :)",
  "id" : 435562606804602880,
  "in_reply_to_status_id" : 435562044939448320,
  "created_at" : "2014-02-17 23:53:12 +0000",
  "in_reply_to_screen_name" : "glasserp",
  "in_reply_to_user_id_str" : "15051699",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/vyI9kv0neT",
      "expanded_url" : "http:\/\/i.imgur.com\/KheQBqG.gif",
      "display_url" : "i.imgur.com\/KheQBqG.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "435559039045345281",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096631283, 8.2830754817 ]
  },
  "id_str" : "435561240761761792",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot all the reason more to get up to speed http:\/\/t.co\/vyI9kv0neT",
  "id" : 435561240761761792,
  "in_reply_to_status_id" : 435559039045345281,
  "created_at" : "2014-02-17 23:47:46 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/QO1iqhfk3t",
      "expanded_url" : "http:\/\/i.imgur.com\/5cIXXbL.gif",
      "display_url" : "i.imgur.com\/5cIXXbL.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096631283, 8.2830754817 ]
  },
  "id_str" : "435557061557239808",
  "text" : "on the run http:\/\/t.co\/QO1iqhfk3t",
  "id" : 435557061557239808,
  "created_at" : "2014-02-17 23:31:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/uqbWZbR9RK",
      "expanded_url" : "http:\/\/i.imgur.com\/oyPFqcv.gif",
      "display_url" : "i.imgur.com\/oyPFqcv.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096631283, 8.2830754817 ]
  },
  "id_str" : "435550371587829760",
  "text" : "for some reason I had to watch this gif for like 5 minutes and laugh tears over the last scene again and again. http:\/\/t.co\/uqbWZbR9RK",
  "id" : 435550371587829760,
  "created_at" : "2014-02-17 23:04:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan Maher",
      "screen_name" : "bmahersciwriter",
      "indices" : [ 3, 19 ],
      "id_str" : "4874562838",
      "id" : 4874562838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/ei6QqKtkFj",
      "expanded_url" : "http:\/\/www.nature.com\/news\/acid-bath-stem-cell-study-under-investigation-1.14738?WT.mc_id=TWT_NatureNews",
      "display_url" : "nature.com\/news\/acid-bath\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435549731130212352",
  "text" : "RT @bmahersciwriter: Acid bath stem-cell study under investigation. http:\/\/t.co\/ei6QqKtkFj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/ei6QqKtkFj",
        "expanded_url" : "http:\/\/www.nature.com\/news\/acid-bath-stem-cell-study-under-investigation-1.14738?WT.mc_id=TWT_NatureNews",
        "display_url" : "nature.com\/news\/acid-bath\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "435506602704375808",
    "text" : "Acid bath stem-cell study under investigation. http:\/\/t.co\/ei6QqKtkFj",
    "id" : 435506602704375808,
    "created_at" : "2014-02-17 20:10:40 +0000",
    "user" : {
      "name" : "Brendan Maher",
      "screen_name" : "bmaher",
      "protected" : false,
      "id_str" : "18089292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67268364\/brendan_hs_normal.jpg",
      "id" : 18089292,
      "verified" : true
    }
  },
  "id" : 435549731130212352,
  "created_at" : "2014-02-17 23:02:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/IrEAx6GPJ5",
      "expanded_url" : "http:\/\/simplystatistics.org\/2014\/02\/17\/repost-ronald-fisher-is-one-of-the-few-scientists-with-a-legit-claim-to-most-influential-scientist-ever\/",
      "display_url" : "simplystatistics.org\/2014\/02\/17\/rep\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435496636899680256",
  "text" : "\u00ABRonald Fisher is one of the few scientists with a legit claim to most influential scientist ever\u00BB http:\/\/t.co\/IrEAx6GPJ5",
  "id" : 435496636899680256,
  "created_at" : "2014-02-17 19:31:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/r9XXcIJx8G",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/zc4c2beGT_w\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435495911364784128",
  "text" : "In R'lyeh FlapThulhu lies\u00A0flapping http:\/\/t.co\/r9XXcIJx8G",
  "id" : 435495911364784128,
  "created_at" : "2014-02-17 19:28:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/ysXHcVN8Lp",
      "expanded_url" : "http:\/\/instagram.com\/p\/khbsAHhwn1\/",
      "display_url" : "instagram.com\/p\/khbsAHhwn1\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.173781239, 8.628703027 ]
  },
  "id_str" : "435437002130202624",
  "text" : "voff @ Goethe-Universit\u00E4t Frankfurt\/Main - Campus Riedberg http:\/\/t.co\/ysXHcVN8Lp",
  "id" : 435437002130202624,
  "created_at" : "2014-02-17 15:34:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435419271909224448",
  "geo" : { },
  "id_str" : "435419420429545473",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me und jetzt weisst du wieso ich die Pipette an den Nagel geh\u00E4ngt habe.",
  "id" : 435419420429545473,
  "in_reply_to_status_id" : 435419271909224448,
  "created_at" : "2014-02-17 14:24:14 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435419019118526464",
  "text" : "\u00ABDu blutest ja!\u00BB \u2013 \u00ABArbeitsunfall\u2026 Also ich hab versucht Klebeband zu schneiden um damit einen Comic an der T\u00FCr aufzuh\u00E4ngen\u2026\u00BB",
  "id" : 435419019118526464,
  "created_at" : "2014-02-17 14:22:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435400375638581248",
  "text" : "\u00ABH\u00E4ttest du gesagt das du trauerst h\u00E4ttest du einen meiner Spezielknuddler bekommen!\u00BB \u2013 \u00ABDamn\u2026\u00BB \u2013 \u00ABTja, nun muss erst wieder wer sterben.\u00BB",
  "id" : 435400375638581248,
  "created_at" : "2014-02-17 13:08:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/zdjaXWmoNe",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=YTovORb24UQ",
      "display_url" : "youtube.com\/watch?v=YTovOR\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723207026, 8.6276272737 ]
  },
  "id_str" : "435392372919513088",
  "text" : "Guess I would love them for their name alone http:\/\/t.co\/zdjaXWmoNe",
  "id" : 435392372919513088,
  "created_at" : "2014-02-17 12:36:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435371691204546561",
  "geo" : { },
  "id_str" : "435380396847403008",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot unlikely, equids are known from the Eocene (52 mya) on. But at least your dating is soo much closer!",
  "id" : 435380396847403008,
  "in_reply_to_status_id" : 435371691204546561,
  "created_at" : "2014-02-17 11:49:10 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 18, 24 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3UaQ1dw4FM",
      "expanded_url" : "http:\/\/i.imgur.com\/swb50Wj.jpg",
      "display_url" : "i.imgur.com\/swb50Wj.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "435366932309495809",
  "text" : "This explains why @Lobot wants a lawn dinosaur (yes, the dating is off by factor 2-3, it's Cretaceous, not Jurassic) http:\/\/t.co\/3UaQ1dw4FM",
  "id" : 435366932309495809,
  "created_at" : "2014-02-17 10:55:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Rm8Mfy8Xlv",
      "expanded_url" : "http:\/\/blog.app.io\/wp-content\/uploads\/2013\/06\/frustration.gif",
      "display_url" : "blog.app.io\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435361312617414656",
  "text" : "at work we now have whiteboards in the hallway to publicly announce our mood. but i'd prefer a gif-capable display http:\/\/t.co\/Rm8Mfy8Xlv",
  "id" : 435361312617414656,
  "created_at" : "2014-02-17 10:33:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435357572380786688",
  "text" : "RT @PhilippBayer: LGB individuals living in anti-gay communities live, on average, 12 years shorter lives than peers in accepting comm. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/LanjSjSf7L",
        "expanded_url" : "http:\/\/www.sciencedaily.com\/releases\/2014\/02\/140215122534.htm?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+sciencedaily+%28Latest+Science+News+--+ScienceDaily%29",
        "display_url" : "sciencedaily.com\/releases\/2014\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "435302054337077249",
    "text" : "LGB individuals living in anti-gay communities live, on average, 12 years shorter lives than peers in accepting comm. http:\/\/t.co\/LanjSjSf7L",
    "id" : 435302054337077249,
    "created_at" : "2014-02-17 06:37:51 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 435357572380786688,
  "created_at" : "2014-02-17 10:18:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 103, 116 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/7rmWZoYoFM",
      "expanded_url" : "http:\/\/scienceblogs.com\/pharyngula\/2014\/02\/14\/the-state-of-modern-evolutionary-theory-may-not-be-what-you-think-it-is\/",
      "display_url" : "scienceblogs.com\/pharyngula\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435345835203637248",
  "text" : "On modern evolutionary theory. Includes nice primer on selection theory vs (nearly) neutral theory \/HT @PhilippBayer http:\/\/t.co\/7rmWZoYoFM",
  "id" : 435345835203637248,
  "created_at" : "2014-02-17 09:31:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatjana Scheffler",
      "screen_name" : "tschfflr",
      "indices" : [ 0, 9 ],
      "id_str" : "313810815",
      "id" : 313810815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435341074299510784",
  "geo" : { },
  "id_str" : "435341907015655424",
  "in_reply_to_user_id" : 313810815,
  "text" : "@tschfflr Guess I would need to look at the whole data from both languages to make sense of it.",
  "id" : 435341907015655424,
  "in_reply_to_status_id" : 435341074299510784,
  "created_at" : "2014-02-17 09:16:13 +0000",
  "in_reply_to_screen_name" : "tschfflr",
  "in_reply_to_user_id_str" : "313810815",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatjana Scheffler",
      "screen_name" : "tschfflr",
      "indices" : [ 0, 9 ],
      "id_str" : "313810815",
      "id" : 313810815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435339319876665344",
  "geo" : { },
  "id_str" : "435340397988958209",
  "in_reply_to_user_id" : 313810815,
  "text" : "@tschfflr so it'more of a question whether sentiment can be predicted correctly given training data or whether impossible regardless of TD.",
  "id" : 435340397988958209,
  "in_reply_to_status_id" : 435339319876665344,
  "created_at" : "2014-02-17 09:10:13 +0000",
  "in_reply_to_screen_name" : "tschfflr",
  "in_reply_to_user_id_str" : "313810815",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatjana Scheffler",
      "screen_name" : "tschfflr",
      "indices" : [ 0, 9 ],
      "id_str" : "313810815",
      "id" : 313810815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435339319876665344",
  "geo" : { },
  "id_str" : "435339736513654784",
  "in_reply_to_user_id" : 313810815,
  "text" : "@tschfflr the thing is: I don't care about language identification itself, just want the sentiment to be correctly identified.",
  "id" : 435339736513654784,
  "in_reply_to_status_id" : 435339319876665344,
  "created_at" : "2014-02-17 09:07:36 +0000",
  "in_reply_to_screen_name" : "tschfflr",
  "in_reply_to_user_id_str" : "313810815",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435334122924306432",
  "geo" : { },
  "id_str" : "435334564320251904",
  "in_reply_to_user_id" : 14286491,
  "text" : "This reminds me: computational linguists, are there any sentiment analysis frameworks that can +\/- deal with mid-sentence language changes?",
  "id" : 435334564320251904,
  "in_reply_to_status_id" : 435334122924306432,
  "created_at" : "2014-02-17 08:47:02 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/LVJIA87zjV",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2014\/02\/when-you-fall-in-love-this-is-what-facebook-sees\/283865\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435334122924306432",
  "text" : "'When You Fall in Love, This Is What Facebook Sees' Would love to see the variance for each day\u2026 http:\/\/t.co\/LVJIA87zjV",
  "id" : 435334122924306432,
  "created_at" : "2014-02-17 08:45:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/YSWJBYD5pU",
      "expanded_url" : "http:\/\/xkcd.com\/1331\/",
      "display_url" : "xkcd.com\/1331\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1537117314, 8.6604023168 ]
  },
  "id_str" : "435317808965373952",
  "text" : "The offset for the turn signals is driving me mad http:\/\/t.co\/YSWJBYD5pU",
  "id" : 435317808965373952,
  "created_at" : "2014-02-17 07:40:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435302890425823232",
  "text" : "RT @PhilippBayer: Disappointed that the term \"shruggaloes\" for unreflecting Ayn Rand fans hasn't caught on",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "435211529487532032",
    "text" : "Disappointed that the term \"shruggaloes\" for unreflecting Ayn Rand fans hasn't caught on",
    "id" : 435211529487532032,
    "created_at" : "2014-02-17 00:38:09 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 435302890425823232,
  "created_at" : "2014-02-17 06:41:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00F6nig",
      "screen_name" : "OldHolgi_PP",
      "indices" : [ 0, 12 ],
      "id_str" : "88326034",
      "id" : 88326034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/0EhaX9QOh0",
      "expanded_url" : "http:\/\/scienceblogs.de\/weitergen\/2009\/04\/genmais-mon810-das-politische-spiel-mit-zukunftstechnologien\/",
      "display_url" : "scienceblogs.de\/weitergen\/2009\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "435197934552895488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097035225, 8.2830628125 ]
  },
  "id_str" : "435199074338635776",
  "in_reply_to_user_id" : 88326034,
  "text" : "@OldHolgi_PP keine Ahnung von 1507 im speziellen, hatte das nur damals bei MON810 verfolgt, eg http:\/\/t.co\/0EhaX9QOh0 vermute es ist Analog.",
  "id" : 435199074338635776,
  "in_reply_to_status_id" : 435197934552895488,
  "created_at" : "2014-02-16 23:48:39 +0000",
  "in_reply_to_screen_name" : "OldHolgi_PP",
  "in_reply_to_user_id_str" : "88326034",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/wYN0PX4Vkw",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=VTV23B5gBsQ&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=VTV23B\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097035225, 8.2830628125 ]
  },
  "id_str" : "435195736352096256",
  "text" : "True facts about the kinkiest animal in the world... the land snail http:\/\/t.co\/wYN0PX4Vkw",
  "id" : 435195736352096256,
  "created_at" : "2014-02-16 23:35:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00F6nig",
      "screen_name" : "OldHolgi_PP",
      "indices" : [ 0, 12 ],
      "id_str" : "88326034",
      "id" : 88326034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435194372296937472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097035225, 8.2830628125 ]
  },
  "id_str" : "435194721917730816",
  "in_reply_to_user_id" : 88326034,
  "text" : "@OldHolgi_PP kannst du die Frage etwas spezifizieren? All die Gentechnik hat mich von der Politik abgehalten :p",
  "id" : 435194721917730816,
  "in_reply_to_status_id" : 435194372296937472,
  "created_at" : "2014-02-16 23:31:21 +0000",
  "in_reply_to_screen_name" : "OldHolgi_PP",
  "in_reply_to_user_id_str" : "88326034",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/VhSaUsCAoD",
      "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2575",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097035225, 8.2830628125 ]
  },
  "id_str" : "435193524708196353",
  "text" : "why would you make me feel these dumb feelings?! http:\/\/t.co\/VhSaUsCAoD",
  "id" : 435193524708196353,
  "created_at" : "2014-02-16 23:26:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Natalie Matosin",
      "screen_name" : "nataliematosin",
      "indices" : [ 3, 18 ],
      "id_str" : "58171977",
      "id" : 58171977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/uFBtzQY2Tj",
      "expanded_url" : "http:\/\/wp.me\/p2Ojvp-co",
      "display_url" : "wp.me\/p2Ojvp-co"
    } ]
  },
  "geo" : { },
  "id_str" : "435191890192121856",
  "text" : "RT @nataliematosin: sick of posts about leaving science. here's my post about NOT leaving science. http:\/\/t.co\/uFBtzQY2Tj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/uFBtzQY2Tj",
        "expanded_url" : "http:\/\/wp.me\/p2Ojvp-co",
        "display_url" : "wp.me\/p2Ojvp-co"
      } ]
    },
    "geo" : { },
    "id_str" : "435172820264308736",
    "text" : "sick of posts about leaving science. here's my post about NOT leaving science. http:\/\/t.co\/uFBtzQY2Tj",
    "id" : 435172820264308736,
    "created_at" : "2014-02-16 22:04:20 +0000",
    "user" : {
      "name" : "Dr Natalie Matosin",
      "screen_name" : "nataliematosin",
      "protected" : false,
      "id_str" : "58171977",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926132202303315969\/F-qdHMQ7_normal.jpg",
      "id" : 58171977,
      "verified" : false
    }
  },
  "id" : 435191890192121856,
  "created_at" : "2014-02-16 23:20:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/cKSUXMxDAF",
      "expanded_url" : "http:\/\/i.imgur.com\/NW2jCUS.gif",
      "display_url" : "i.imgur.com\/NW2jCUS.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009530245, 8.2829143825 ]
  },
  "id_str" : "435187723503423488",
  "text" : "\u00AB[\u2026] dew glittering on the hinges of the garden gate. All these things will be lost, like snails in the rain.\u00BB http:\/\/t.co\/cKSUXMxDAF",
  "id" : 435187723503423488,
  "created_at" : "2014-02-16 23:03:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/pDlyWlmO19",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0088640",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096227467, 8.2829211 ]
  },
  "id_str" : "435183263196647424",
  "text" : "This is so cool: mesozoic fossil strongly indicates a terrestrial origin of live birth. http:\/\/t.co\/pDlyWlmO19",
  "id" : 435183263196647424,
  "created_at" : "2014-02-16 22:45:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/SnUD8UBTDb",
      "expanded_url" : "http:\/\/jeffarchibald.ca\/60-hour-work-week-badge-honour\/",
      "display_url" : "jeffarchibald.ca\/60-hour-work-w\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096227467, 8.2829211 ]
  },
  "id_str" : "435177359579574272",
  "text" : "\u00ABYour 60-Hour Work Week Is Not A Badge Of Honour\u00BB yadda yadda\u2026 taking pride is a coping strategy for the workload http:\/\/t.co\/SnUD8UBTDb",
  "id" : 435177359579574272,
  "created_at" : "2014-02-16 22:22:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0704329121, 8.243950628 ]
  },
  "id_str" : "435165323461787648",
  "text" : "The \u2018it\u2019s natural and is a result of natural selection\u2019 meme\u2026 pretty certain it\u2019s deleterious and was fixed by drift\u2026",
  "id" : 435165323461787648,
  "created_at" : "2014-02-16 21:34:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435150313730097153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1003481918, 8.2650241161 ]
  },
  "id_str" : "435150739586187264",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 Opa, dem Altnazi, h\u00E4tte es bestimmt gefallen!",
  "id" : 435150739586187264,
  "in_reply_to_status_id" : 435150313730097153,
  "created_at" : "2014-02-16 20:36:35 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/435147697008693248\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/Nso791oXhu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bgn0hkWIAAALDEm.jpg",
      "id_str" : "435147696547299328",
      "id" : 435147696547299328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bgn0hkWIAAALDEm.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/Nso791oXhu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1003624736, 8.2648957307 ]
  },
  "id_str" : "435147697008693248",
  "text" : "test-driving the dress for the funeral next week http:\/\/t.co\/Nso791oXhu",
  "id" : 435147697008693248,
  "created_at" : "2014-02-16 20:24:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.100389605, 8.2647987966 ]
  },
  "id_str" : "435115905950154752",
  "text" : "\u00ABWir starten doch jetzt kein Kickstarter-Projekt f\u00FCrs Abendessen!\u00BB",
  "id" : 435115905950154752,
  "created_at" : "2014-02-16 18:18:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/UZATxLeW7X",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/bm5BvBVuVcc\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009612, 8.282961 ]
  },
  "id_str" : "435063746864898048",
  "text" : "How all great math problems are stated for the first time http:\/\/t.co\/UZATxLeW7X",
  "id" : 435063746864898048,
  "created_at" : "2014-02-16 14:50:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/Jje7lzmhkz",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/health_and_science\/climate_desk\/2014\/02\/internet_troll_personality_study_machiavellianism_narcissism_psychopathy.html",
      "display_url" : "slate.com\/articles\/healt\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096227467, 8.2829211 ]
  },
  "id_str" : "435051058373873664",
  "text" : "science says: trolls are horrible people &amp; don\u2019t read the damn comments (surprise!) http:\/\/t.co\/Jje7lzmhkz",
  "id" : 435051058373873664,
  "created_at" : "2014-02-16 14:00:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/v8FHzLWBJB",
      "expanded_url" : "http:\/\/chaoscontrolled123.tumblr.com\/post\/76305632587\/luke-and-i-were-looking-at-hieronymus-boschs",
      "display_url" : "chaoscontrolled123.tumblr.com\/post\/763056325\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009661875, 8.2830256067 ]
  },
  "id_str" : "435039641235124224",
  "text" : "Hieronymus Bosch\u2019s Butt Song From Hell http:\/\/t.co\/v8FHzLWBJB",
  "id" : 435039641235124224,
  "created_at" : "2014-02-16 13:15:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096902738, 8.2830349391 ]
  },
  "id_str" : "434872763774291968",
  "text" : "\u00ABF\u00FChlst du dich jetzt voll?\u00BB \u2014 \u00ABWundervoll!\u00BB",
  "id" : 434872763774291968,
  "created_at" : "2014-02-16 02:12:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009634745, 8.282922565 ]
  },
  "id_str" : "434769792789393408",
  "text" : "\u00ABIch lasse dich ja nur w\u00FCrzen weil du so anspruchsvoll bist. Ich hingegen esse alles, gerade versehentlich sogar rohes Rattenfleisch\u2026\u00BB",
  "id" : 434769792789393408,
  "created_at" : "2014-02-15 19:22:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095962652, 8.2829600854 ]
  },
  "id_str" : "434742101075832834",
  "text" : "\u00ABIch mag dich in dem Kleid. Oh, und nat\u00FCrlich nackt!\u00BB \u2014 \u00ABJa, aber wehe ich trage mal ausnahmsweise eine Hose.\u00BB",
  "id" : 434742101075832834,
  "created_at" : "2014-02-15 17:32:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/6c5xjNZsBS",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/eXjEDNVQzEk\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434728532108115968",
  "text" : "Adulthood\u2026  http:\/\/t.co\/6c5xjNZsBS",
  "id" : 434728532108115968,
  "created_at" : "2014-02-15 16:38:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095784729, 8.2829655196 ]
  },
  "id_str" : "434727043105054720",
  "text" : "\u00ABIndustrial espionage is a crime I would not commit under any circumstances.\u00BB \u2014 \u00ABBecause you can\u2019t even pronounce it correctly?\u00BB",
  "id" : 434727043105054720,
  "created_at" : "2014-02-15 16:32:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095784729, 8.2829655196 ]
  },
  "id_str" : "434725486342995968",
  "text" : "\u00ABIch liebe dich so sehr.\u00BB \u2014 \u00ABWie sehr?\u00BB \u2014 \u00ABBis zu den Ellenbogen!\u00BB",
  "id" : 434725486342995968,
  "created_at" : "2014-02-15 16:26:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Danger [@jack, don\u2019t enable nazis]",
      "screen_name" : "jackdanger",
      "indices" : [ 3, 14 ],
      "id_str" : "3496901",
      "id" : 3496901
    }, {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 16, 25 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434420176835338240",
  "text" : "RT @jackdanger: @climagic Because neither of you know how to quit each other.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Command Line Magic",
        "screen_name" : "climagic",
        "indices" : [ 0, 9 ],
        "id_str" : "91333167",
        "id" : 91333167
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "434414459273351168",
    "geo" : { },
    "id_str" : "434414549375008768",
    "in_reply_to_user_id" : 91333167,
    "text" : "@climagic Because neither of you know how to quit each other.",
    "id" : 434414549375008768,
    "in_reply_to_status_id" : 434414459273351168,
    "created_at" : "2014-02-14 19:51:14 +0000",
    "in_reply_to_screen_name" : "climagic",
    "in_reply_to_user_id_str" : "91333167",
    "user" : {
      "name" : "Jack Danger [@jack, don\u2019t enable nazis]",
      "screen_name" : "jackdanger",
      "protected" : false,
      "id_str" : "3496901",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883042061380866048\/w4bALMaT_normal.jpg",
      "id" : 3496901,
      "verified" : false
    }
  },
  "id" : 434420176835338240,
  "created_at" : "2014-02-14 20:13:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 3, 12 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434420113908178945",
  "text" : "RT @climagic: And if you need proof of true love, I use vi, my wife uses emacs and we sleep together.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/suso.suso.org\/xulu\/Command_Line_Magic\" rel=\"nofollow\"\u003ECLI Magic poster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "434414459273351168",
    "text" : "And if you need proof of true love, I use vi, my wife uses emacs and we sleep together.",
    "id" : 434414459273351168,
    "created_at" : "2014-02-14 19:50:52 +0000",
    "user" : {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "protected" : false,
      "id_str" : "91333167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535876218\/climagic-icon_normal.png",
      "id" : 91333167,
      "verified" : false
    }
  },
  "id" : 434420113908178945,
  "created_at" : "2014-02-14 20:13:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/VW8kRxRFvx",
      "expanded_url" : "http:\/\/simplystatistics.org\/2014\/02\/14\/on-the-scalability-of-statistical-procedures-why-the-p-value-bashers-just-dont-get-it\/",
      "display_url" : "simplystatistics.org\/2014\/02\/14\/on-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095364217, 8.2829329733 ]
  },
  "id_str" : "434405500986605568",
  "text" : "\u00ABThe problem is not p-values it is a fundamental shortage of data analytic skill\u00BB http:\/\/t.co\/VW8kRxRFvx",
  "id" : 434405500986605568,
  "created_at" : "2014-02-14 19:15:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/b0zu7zlkUF",
      "expanded_url" : "http:\/\/instagram.com\/p\/kZ4wD8hwuZ\/",
      "display_url" : "instagram.com\/p\/kZ4wD8hwuZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "434375013316460545",
  "text" : "\u00ABVon rubber duck debugging zu platypus psychotherapy?\u00BB http:\/\/t.co\/b0zu7zlkUF",
  "id" : 434375013316460545,
  "created_at" : "2014-02-14 17:14:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095364217, 8.2829329733 ]
  },
  "id_str" : "434336625691095040",
  "text" : "\u00ABWoran denkst du?\u00BB \u2013 \u00ABStatistical Power\u2026\u00BB \u2013 \u00ABDu machst mich so an!\u00BB",
  "id" : 434336625691095040,
  "created_at" : "2014-02-14 14:41:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434314640823037952",
  "text" : "\u00ABZu dir w\u00FCrde Mistress of Science doch viel besser passen.\u00BB \u2013 \u00ABUnd das von jemandem der immer Lederhosen tr\u00E4gt?\u00BB",
  "id" : 434314640823037952,
  "created_at" : "2014-02-14 13:14:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/OXhCVmsezi",
      "expanded_url" : "http:\/\/www.pewinternet.org\/2014\/02\/11\/couples-the-internet-and-social-media\/",
      "display_url" : "pewinternet.org\/2014\/02\/11\/cou\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1725378367, 8.6275400723 ]
  },
  "id_str" : "434306761789820929",
  "text" : "Couples, the Internet, and Social Media http:\/\/t.co\/OXhCVmsezi",
  "id" : 434306761789820929,
  "created_at" : "2014-02-14 12:42:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joost Plattel",
      "screen_name" : "jplattel",
      "indices" : [ 0, 9 ],
      "id_str" : "16376925",
      "id" : 16376925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/YtzEPFK42x",
      "expanded_url" : "https:\/\/opensnp.org\/fitbit\/show\/1",
      "display_url" : "opensnp.org\/fitbit\/show\/1"
    } ]
  },
  "in_reply_to_status_id_str" : "434280420977291264",
  "geo" : { },
  "id_str" : "434283138131324928",
  "in_reply_to_user_id" : 16376925,
  "text" : "@jplattel the data is already open source :) https:\/\/t.co\/YtzEPFK42x",
  "id" : 434283138131324928,
  "in_reply_to_status_id" : 434280420977291264,
  "created_at" : "2014-02-14 11:09:03 +0000",
  "in_reply_to_screen_name" : "jplattel",
  "in_reply_to_user_id_str" : "16376925",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434274761871351808",
  "text" : "Analysing my sleep data over time and running some correlations. For equal parts fun and depressing.",
  "id" : 434274761871351808,
  "created_at" : "2014-02-14 10:35:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/JxCjpobBdJ",
      "expanded_url" : "http:\/\/corpsmoderne.itch.io\/flappy-space-program",
      "display_url" : "corpsmoderne.itch.io\/flappy-space-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434266431308324864",
  "text" : "Flappy Space Program. (this counts as doing science, right?) http:\/\/t.co\/JxCjpobBdJ",
  "id" : 434266431308324864,
  "created_at" : "2014-02-14 10:02:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/8qpY9P9SGn",
      "expanded_url" : "http:\/\/www.languageonthemove.com\/intercultural-communication\/inventing-languages?utm_source=rss&utm_medium=rss&utm_campaign=inventing-languages&utm_reader=feedly",
      "display_url" : "languageonthemove.com\/intercultural-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434245587244826624",
  "text" : "Inventing languages http:\/\/t.co\/8qpY9P9SGn",
  "id" : 434245587244826624,
  "created_at" : "2014-02-14 08:39:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434108855585611776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967297, 8.283059338 ]
  },
  "id_str" : "434109617661304832",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC one of the best non-achievement compliments :p",
  "id" : 434109617661304832,
  "in_reply_to_status_id" : 434108855585611776,
  "created_at" : "2014-02-13 23:39:32 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/JnvhHZUtvH",
      "expanded_url" : "http:\/\/aeon.co\/magazine\/being-human\/why-rude-doctors-make-bad-doctors\/",
      "display_url" : "aeon.co\/magazine\/being\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967297, 8.283059338 ]
  },
  "id_str" : "434108751000645632",
  "text" : "\u00ABWe can\u2019t ignore a system that takes loads of formerly \u2018nice\u2019 people and churns out jaded, bitter, and gruff ones\u00BB http:\/\/t.co\/JnvhHZUtvH",
  "id" : 434108751000645632,
  "created_at" : "2014-02-13 23:36:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434103649670017025",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967297, 8.283059338 ]
  },
  "id_str" : "434105205966524416",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC sounds pretty glamorous to me, but then you already noticed my weird hard-wiring.",
  "id" : 434105205966524416,
  "in_reply_to_status_id" : 434103649670017025,
  "created_at" : "2014-02-13 23:22:01 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cachat",
      "screen_name" : "jcachat",
      "indices" : [ 3, 11 ],
      "id_str" : "19866053",
      "id" : 19866053
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PublishPerish14",
      "indices" : [ 115, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/wP68RBdsXa",
      "expanded_url" : "http:\/\/www.universalrejection.org\/",
      "display_url" : "universalrejection.org"
    } ]
  },
  "geo" : { },
  "id_str" : "434104384444985344",
  "text" : "RT @jcachat: looking for a journal for that article you been working on? check this one out http:\/\/t.co\/wP68RBdsXa #PublishPerish14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PublishPerish14",
        "indices" : [ 102, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/wP68RBdsXa",
        "expanded_url" : "http:\/\/www.universalrejection.org\/",
        "display_url" : "universalrejection.org"
      } ]
    },
    "geo" : { },
    "id_str" : "434100807990910976",
    "text" : "looking for a journal for that article you been working on? check this one out http:\/\/t.co\/wP68RBdsXa #PublishPerish14",
    "id" : 434100807990910976,
    "created_at" : "2014-02-13 23:04:32 +0000",
    "user" : {
      "name" : "Jonathan Cachat",
      "screen_name" : "jcachat",
      "protected" : false,
      "id_str" : "19866053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561112701531742208\/EowWI6Lq_normal.png",
      "id" : 19866053,
      "verified" : false
    }
  },
  "id" : 434104384444985344,
  "created_at" : "2014-02-13 23:18:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434101503209766912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967297, 8.283059338 ]
  },
  "id_str" : "434102038285541376",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC probably just commuters who missed their stop ;)",
  "id" : 434102038285541376,
  "in_reply_to_status_id" : 434101503209766912,
  "created_at" : "2014-02-13 23:09:25 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/3xX5OnoDJr",
      "expanded_url" : "http:\/\/i.imgur.com\/XJXDjFO.gif",
      "display_url" : "i.imgur.com\/XJXDjFO.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096682478, 8.2831009467 ]
  },
  "id_str" : "434084759728582656",
  "text" : "Waschb\u00E4r &amp; Waschbart http:\/\/t.co\/3xX5OnoDJr",
  "id" : 434084759728582656,
  "created_at" : "2014-02-13 22:00:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434066174851051520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967297, 8.283059338 ]
  },
  "id_str" : "434067121753325568",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC point taken, and just imagine i did both.",
  "id" : 434067121753325568,
  "in_reply_to_status_id" : 434066174851051520,
  "created_at" : "2014-02-13 20:50:41 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434062259925422080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967297, 8.283059338 ]
  },
  "id_str" : "434065108382523392",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC is that an implicit request for compassion or do you just like to see me play the bigot? ;)",
  "id" : 434065108382523392,
  "in_reply_to_status_id" : 434062259925422080,
  "created_at" : "2014-02-13 20:42:41 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434053187234844673",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096553071, 8.2830599186 ]
  },
  "id_str" : "434053876153868288",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC still, why would I then have bothered with #2? Didn\u2019t I tell you how I feel about getting bored? ;)",
  "id" : 434053876153868288,
  "in_reply_to_status_id" : 434053187234844673,
  "created_at" : "2014-02-13 19:58:03 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434051837524598784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968205, 8.283038114 ]
  },
  "id_str" : "434052133630267392",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC how would I have made it to #2 in that case? :p",
  "id" : 434052133630267392,
  "in_reply_to_status_id" : 434051837524598784,
  "created_at" : "2014-02-13 19:51:07 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434051316369743873",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968205, 8.283038114 ]
  },
  "id_str" : "434051589418913792",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC isn\u2019t that pretty obvious? ;)",
  "id" : 434051589418913792,
  "in_reply_to_status_id" : 434051316369743873,
  "created_at" : "2014-02-13 19:48:57 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434050527370829824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968205, 8.283038114 ]
  },
  "id_str" : "434050759077142529",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC yeah, finished that one as well.",
  "id" : 434050759077142529,
  "in_reply_to_status_id" : 434050527370829824,
  "created_at" : "2014-02-13 19:45:39 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434041491070001152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0074180623, 8.2882368331 ]
  },
  "id_str" : "434042395530108928",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Schadenfreude w\u00E4re aber auch total okay :)",
  "id" : 434042395530108928,
  "in_reply_to_status_id" : 434041491070001152,
  "created_at" : "2014-02-13 19:12:25 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096290295, 8.2829766792 ]
  },
  "id_str" : "434038734829682689",
  "text" : "Close call: nearly missed getting off the train for the second day in a row. Where\u2019s my mind?",
  "id" : 434038734829682689,
  "created_at" : "2014-02-13 18:57:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434013616480600064",
  "text" : "\u00ABIch habe dir einen Sch\u00E4del mitgebracht. Und einen zweiten, falls du Lust hast mir auch einen zu pr\u00E4parieren.\u00BB Beste Studenten ever &lt;3",
  "id" : 434013616480600064,
  "created_at" : "2014-02-13 17:18:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/4Y58ALgISh",
      "expanded_url" : "http:\/\/simplystatistics.org\/2014\/02\/13\/loess-explained-in-a-gif\/",
      "display_url" : "simplystatistics.org\/2014\/02\/13\/loe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434003715171684354",
  "text" : "loess explained in a GIF http:\/\/t.co\/4Y58ALgISh",
  "id" : 434003715171684354,
  "created_at" : "2014-02-13 16:38:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 0, 12 ],
      "id_str" : "48357885",
      "id" : 48357885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433995159035191296",
  "geo" : { },
  "id_str" : "433997034282962945",
  "in_reply_to_user_id" : 48357885,
  "text" : "@Whitey_chan I tend to forget that my SFW definition might not apply universally.",
  "id" : 433997034282962945,
  "in_reply_to_status_id" : 433995159035191296,
  "created_at" : "2014-02-13 16:12:10 +0000",
  "in_reply_to_screen_name" : "Whitey_chan",
  "in_reply_to_user_id_str" : "48357885",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 98, 111 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/mWvObjf8xQ",
      "expanded_url" : "http:\/\/f1000research.com\/article-collections\/BioJS",
      "display_url" : "f1000research.com\/article-collec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433993220792406017",
  "text" : "Nice: The BioJS article collection of open source components for biological data visualisation by @manuelcorpas http:\/\/t.co\/mWvObjf8xQ",
  "id" : 433993220792406017,
  "created_at" : "2014-02-13 15:57:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/gug54KQdq8",
      "expanded_url" : "http:\/\/instagram.com\/p\/kXGFemBwuM\/",
      "display_url" : "instagram.com\/p\/kXGFemBwuM\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172374546, 8.627694567 ]
  },
  "id_str" : "433982124333748224",
  "text" : "no longer doing pure biology this is one of the few things I actually miss @ Biologicum http:\/\/t.co\/gug54KQdq8",
  "id" : 433982124333748224,
  "created_at" : "2014-02-13 15:12:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723378416, 8.6276041312 ]
  },
  "id_str" : "433973543664357376",
  "text" : "\u00ABSchnell komm rein und riech. Sie haben den Darm angeschnitten!\u00BB \u2014 \u00ABAh, wie zuhause!\u00BB",
  "id" : 433973543664357376,
  "created_at" : "2014-02-13 14:38:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433962443216138241",
  "geo" : { },
  "id_str" : "433962850835369984",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer glad you enjoyed the book! Always think positive: there are some rare cases of survivors!",
  "id" : 433962850835369984,
  "in_reply_to_status_id" : 433962443216138241,
  "created_at" : "2014-02-13 13:56:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433962626322677760",
  "text" : "\u00ABDa bist du ja, ich soll dir ausrichten: Du kannst jetzt runterkommen, tote Ratte anschauen.\u00BB So motivierend! &lt;3",
  "id" : 433962626322677760,
  "created_at" : "2014-02-13 13:55:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/t9wd3B5uB5",
      "expanded_url" : "http:\/\/www.wired.com\/wiredscience\/2014\/02\/dating-advice-for-spiders\/",
      "display_url" : "wired.com\/wiredscience\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433936399985696768",
  "text" : "Science Offers Dating Advice for Spiders: Bring dead insects http:\/\/t.co\/t9wd3B5uB5",
  "id" : 433936399985696768,
  "created_at" : "2014-02-13 12:11:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0935852238, 8.6381790216 ]
  },
  "id_str" : "433872423688339456",
  "text" : "\u00ABAlso ich bin fertig, die Arbeit soweit auch.\u00BB",
  "id" : 433872423688339456,
  "created_at" : "2014-02-13 07:57:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433780925785051136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096681016, 8.2831071876 ]
  },
  "id_str" : "433781119977521152",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot how does the hammer make you feel? (Please give the RGB code emitted by the LEDs)",
  "id" : 433781119977521152,
  "in_reply_to_status_id" : 433780925785051136,
  "created_at" : "2014-02-13 01:54:12 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433780502865010688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096681016, 8.2831071876 ]
  },
  "id_str" : "433780756226531330",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot why do you think that I just passed the Turing test?",
  "id" : 433780756226531330,
  "in_reply_to_status_id" : 433780502865010688,
  "created_at" : "2014-02-13 01:52:46 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096637338, 8.2830714666 ]
  },
  "id_str" : "433780082369626114",
  "text" : "\u00ABELIZA taught me everything I know about human interaction.\u00BB",
  "id" : 433780082369626114,
  "created_at" : "2014-02-13 01:50:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 10, 18 ],
      "id_str" : "19210703",
      "id" : 19210703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433763660977016832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968205, 8.283038114 ]
  },
  "id_str" : "433763751930904576",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @junaxup please feel free to mention them again. Some day I might order some more :D",
  "id" : 433763751930904576,
  "in_reply_to_status_id" : 433763660977016832,
  "created_at" : "2014-02-13 00:45:12 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 0, 8 ],
      "id_str" : "19210703",
      "id" : 19210703
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 9, 18 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433763216083021824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968205, 8.283038114 ]
  },
  "id_str" : "433763477275287553",
  "in_reply_to_user_id" : 19210703,
  "text" : "@junaxup @eramirez glad it\u2019s not only me thinking that :)",
  "id" : 433763477275287553,
  "in_reply_to_status_id" : 433763216083021824,
  "created_at" : "2014-02-13 00:44:06 +0000",
  "in_reply_to_screen_name" : "junaxup",
  "in_reply_to_user_id_str" : "19210703",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 10, 18 ],
      "id_str" : "19210703",
      "id" : 19210703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433753556160503809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968205, 8.283038114 ]
  },
  "id_str" : "433754323747872768",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @junaxup how nice of you! They did arrive sound and safe and I regularly use them (as does the cat ;))",
  "id" : 433754323747872768,
  "in_reply_to_status_id" : 433753556160503809,
  "created_at" : "2014-02-13 00:07:44 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 76, 84 ],
      "id_str" : "19210703",
      "id" : 19210703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433751872315195392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968205, 8.283038114 ]
  },
  "id_str" : "433753375344455680",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez indeed, they are awesome and I was one of the original backers of @junaxup. Still love them! :)",
  "id" : 433753375344455680,
  "in_reply_to_status_id" : 433751872315195392,
  "created_at" : "2014-02-13 00:03:58 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/iuRvsNU3Lp",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/02\/12\/cuddly-giant-isopod-toy.html",
      "display_url" : "boingboing.net\/2014\/02\/12\/cud\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968205, 8.283038114 ]
  },
  "id_str" : "433751497164476416",
  "text" : "giant plush isopods &lt;3 http:\/\/t.co\/iuRvsNU3Lp",
  "id" : 433751497164476416,
  "created_at" : "2014-02-12 23:56:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/Bns3hER2iM",
      "expanded_url" : "http:\/\/i.imgur.com\/zAuxnTw.gif",
      "display_url" : "i.imgur.com\/zAuxnTw.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968205, 8.283038114 ]
  },
  "id_str" : "433745634236325888",
  "text" : "looking into my inbox and finding yet another draft that needs proofreading http:\/\/t.co\/Bns3hER2iM",
  "id" : 433745634236325888,
  "created_at" : "2014-02-12 23:33:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433739452951699456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968205, 8.283038114 ]
  },
  "id_str" : "433740158849273856",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot reading that made me cringe. \u2018do stuff that makes _you_ happy\u2019 .\/. \u2018think of them first\u2019",
  "id" : 433740158849273856,
  "in_reply_to_status_id" : 433739452951699456,
  "created_at" : "2014-02-12 23:11:27 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433738041891356672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968205, 8.283038114 ]
  },
  "id_str" : "433739115579052032",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot noticed that as well and was puzzled. The weighting is also weird. e.g. \u2018talk about money\u2019 &gt; \u2018be open &amp; honest\u2019",
  "id" : 433739115579052032,
  "in_reply_to_status_id" : 433738041891356672,
  "created_at" : "2014-02-12 23:07:18 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/He64NnGGi4",
      "expanded_url" : "http:\/\/www.informationisbeautiful.net\/visualizations\/good-relationtips-most-commonly-given-relationship-advice\/",
      "display_url" : "informationisbeautiful.net\/visualizations\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965486, 8.2830642629 ]
  },
  "id_str" : "433736052357210112",
  "text" : "most repeated relationship advice http:\/\/t.co\/He64NnGGi4",
  "id" : 433736052357210112,
  "created_at" : "2014-02-12 22:55:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433708291298840576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096980064, 8.2830591974 ]
  },
  "id_str" : "433708746955841537",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC how could I? It made at least a small part of my task a tad easier.",
  "id" : 433708746955841537,
  "in_reply_to_status_id" : 433708291298840576,
  "created_at" : "2014-02-12 21:06:37 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/sggN9Nt0QR",
      "expanded_url" : "http:\/\/i.imgur.com\/Q6PDmMw.png",
      "display_url" : "i.imgur.com\/Q6PDmMw.png"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965486, 8.2830642629 ]
  },
  "id_str" : "433703447662456832",
  "text" : "\u00ABIch bin so froh dass du einen Bart hast der dich retten kann, falls du mal in Eis einbrichst.\u00BB http:\/\/t.co\/sggN9Nt0QR",
  "id" : 433703447662456832,
  "created_at" : "2014-02-12 20:45:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433700078709006336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965486, 8.2830642629 ]
  },
  "id_str" : "433702339556687872",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC and that\u2019s exactly why I ask you for ethical advice.",
  "id" : 433702339556687872,
  "in_reply_to_status_id" : 433700078709006336,
  "created_at" : "2014-02-12 20:41:10 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433695926478057472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433696475756130305",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC oh, I wasn\u2019t aware that your high moral standards also apply outside of science. ;)",
  "id" : 433696475756130305,
  "in_reply_to_status_id" : 433695926478057472,
  "created_at" : "2014-02-12 20:17:52 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433690796877832192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433691627346198529",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC but paper-clips + ballpoint pen-parts doesn\u2019t sound too bad. :p",
  "id" : 433691627346198529,
  "in_reply_to_status_id" : 433690796877832192,
  "created_at" : "2014-02-12 19:58:36 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433690796877832192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433691358520705024",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC have to admit I wouldn\u2019t even know what kind of office supplies are around at my place. ;)",
  "id" : 433691358520705024,
  "in_reply_to_status_id" : 433690796877832192,
  "created_at" : "2014-02-12 19:57:32 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433688769972023296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433689765440159744",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC at least I didn\u2019t give you a hard time for forgetting it ;) But hunting for a makeshift wrench &amp; pick amongst the office supplies?",
  "id" : 433689765440159744,
  "in_reply_to_status_id" : 433688769972023296,
  "created_at" : "2014-02-12 19:51:12 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433687005415759872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433688129330249729",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC you could always try your picking skills to go through the drawers of your colleagues.",
  "id" : 433688129330249729,
  "in_reply_to_status_id" : 433687005415759872,
  "created_at" : "2014-02-12 19:44:42 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/nypan0UWPc",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1068",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433682603548610560",
  "text" : "it\u2019s the same for getting kids http:\/\/t.co\/nypan0UWPc",
  "id" : 433682603548610560,
  "created_at" : "2014-02-12 19:22:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433673404361617408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433681229050044416",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC always keep emergency nuts in your desk.",
  "id" : 433681229050044416,
  "in_reply_to_status_id" : 433673404361617408,
  "created_at" : "2014-02-12 19:17:17 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 3, 16 ],
      "id_str" : "116877838",
      "id" : 116877838
    }, {
      "name" : "readmatter",
      "screen_name" : "readmatter",
      "indices" : [ 74, 85 ],
      "id_str" : "733340760473403392",
      "id" : 733340760473403392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/CpjfCXdlH5",
      "expanded_url" : "https:\/\/medium.com\/matter\/76d9913c6011",
      "display_url" : "medium.com\/matter\/76d9913\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433670480135225345",
  "text" : "RT @MishaAngrist: \u201CWhat tear gas taught me about Twitter and the NSA\u00A0\u201D by @readmatter https:\/\/t.co\/CpjfCXdlH5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "readmatter",
        "screen_name" : "readmatter",
        "indices" : [ 56, 67 ],
        "id_str" : "733340760473403392",
        "id" : 733340760473403392
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/CpjfCXdlH5",
        "expanded_url" : "https:\/\/medium.com\/matter\/76d9913c6011",
        "display_url" : "medium.com\/matter\/76d9913\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "433666980768280576",
    "text" : "\u201CWhat tear gas taught me about Twitter and the NSA\u00A0\u201D by @readmatter https:\/\/t.co\/CpjfCXdlH5",
    "id" : 433666980768280576,
    "created_at" : "2014-02-12 18:20:40 +0000",
    "user" : {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "protected" : false,
      "id_str" : "116877838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747461459974717441\/GIrZkLT-_normal.jpg",
      "id" : 116877838,
      "verified" : false
    }
  },
  "id" : 433670480135225345,
  "created_at" : "2014-02-12 18:34:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0287310431, 8.3615917554 ]
  },
  "id_str" : "433641982481948672",
  "text" : "\u00ABIch wollte Chocolatier werden aber das gibt es in Deutschland nicht. Nur \u2018Fachkraft f\u00FCr S\u00FC\u00DFwarentechnik. Fachrichtung Schokolade\/Konfekt\u2019.\u00BB",
  "id" : 433641982481948672,
  "created_at" : "2014-02-12 16:41:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DarwinDay",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/oqDOXBw4WE",
      "expanded_url" : "http:\/\/www.jayhosler.com\/Charlie.jpg",
      "display_url" : "jayhosler.com\/Charlie.jpg"
    } ]
  },
  "in_reply_to_status_id_str" : "433602968450240512",
  "geo" : { },
  "id_str" : "433609047938306048",
  "in_reply_to_user_id" : 14286491,
  "text" : "complete comic strip on 'Good ol' Charlie Darwin' http:\/\/t.co\/oqDOXBw4WE #DarwinDay",
  "id" : 433609047938306048,
  "in_reply_to_status_id" : 433602968450240512,
  "created_at" : "2014-02-12 14:30:27 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "darwinday",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/DuasLeuuz2",
      "expanded_url" : "http:\/\/instagram.com\/p\/kUZqm1hwg0\/",
      "display_url" : "instagram.com\/p\/kUZqm1hwg0\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172374546, 8.627694567 ]
  },
  "id_str" : "433602968450240512",
  "text" : "\u00ABMan still bears in his bodily frame the indelible stamp of his lowly origin\u00BB Happy #darwinday fellow\u2026 http:\/\/t.co\/DuasLeuuz2",
  "id" : 433602968450240512,
  "created_at" : "2014-02-12 14:06:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433570360915533824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723155724, 8.6276218949 ]
  },
  "id_str" : "433573139948503040",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks to HN \u2018hacker\u2019 is becoming shorthand for \u2018thinks has an idea of science while actually knowing shit\u2019",
  "id" : 433573139948503040,
  "in_reply_to_status_id" : 433570360915533824,
  "created_at" : "2014-02-12 12:07:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433543836066152448",
  "geo" : { },
  "id_str" : "433544502985232384",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich wenn ich zuhause nicht auch einen standing desk h\u00E4tte f\u00E4nde ich es auch nur halb so lustig.",
  "id" : 433544502985232384,
  "in_reply_to_status_id" : 433543836066152448,
  "created_at" : "2014-02-12 10:13:59 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/IvdWjv3UZh",
      "expanded_url" : "http:\/\/xkcd.com\/1329\/",
      "display_url" : "xkcd.com\/1329\/"
    } ]
  },
  "geo" : { },
  "id_str" : "433543605500661761",
  "text" : "works best if on a paleo diet http:\/\/t.co\/IvdWjv3UZh",
  "id" : 433543605500661761,
  "created_at" : "2014-02-12 10:10:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/433540680414425088\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/m6E8eL95s1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgQ-859IYAA8csu.jpg",
      "id_str" : "433540680204705792",
      "id" : 433540680204705792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgQ-859IYAA8csu.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/m6E8eL95s1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433536510189912064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723155758, 8.6276314378 ]
  },
  "id_str" : "433540680414425088",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon says so right in front of me. In grand scheme of things it\u2019s not much of an interesting question I guess. http:\/\/t.co\/m6E8eL95s1",
  "id" : 433540680414425088,
  "in_reply_to_status_id" : 433536510189912064,
  "created_at" : "2014-02-12 09:58:47 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/6RHHCwObU2",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/433536020496134146",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433537624288919553",
  "text" : "What I'm really looking for is a gf that will scold me for choosing FDR over a more stringent Bonferroni correction https:\/\/t.co\/6RHHCwObU2",
  "id" : 433537624288919553,
  "created_at" : "2014-02-12 09:46:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/5wIor1BSO6",
      "expanded_url" : "http:\/\/biostatisticsryangoslingreturns.tumblr.com\/post\/26127475400",
      "display_url" : "\u2026atisticsryangoslingreturns.tumblr.com\/post\/261274754\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "433533985751171072",
  "geo" : { },
  "id_str" : "433536020496134146",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon hey girl, you don't have to tell me about the multiple testing problem and false discovery rate correction http:\/\/t.co\/5wIor1BSO6",
  "id" : 433536020496134146,
  "in_reply_to_status_id" : 433533985751171072,
  "created_at" : "2014-02-12 09:40:16 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Seay",
      "screen_name" : "texasinafrica",
      "indices" : [ 3, 17 ],
      "id_str" : "33400961",
      "id" : 33400961
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AcademicValentines",
      "indices" : [ 66, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433528533550661632",
  "text" : "RT @texasinafrica: I'm 95% confident...about my feelings for you. #AcademicValentines",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AcademicValentines",
        "indices" : [ 47, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433398688044441600",
    "text" : "I'm 95% confident...about my feelings for you. #AcademicValentines",
    "id" : 433398688044441600,
    "created_at" : "2014-02-12 00:34:34 +0000",
    "user" : {
      "name" : "Laura Seay",
      "screen_name" : "texasinafrica",
      "protected" : false,
      "id_str" : "33400961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690643712\/texasinafrica_normal.jpg",
      "id" : 33400961,
      "verified" : true
    }
  },
  "id" : 433528533550661632,
  "created_at" : "2014-02-12 09:10:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433528006162669568",
  "text" : "Thought I could get around lab animal husbandry by going into bioinformatics. Now the first &amp; last task of a given day is feeding students.",
  "id" : 433528006162669568,
  "created_at" : "2014-02-12 09:08:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433507946073313280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0051738089, 8.342252411 ]
  },
  "id_str" : "433508123547299840",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez great, for fall my schedule is still quite empty. ;)",
  "id" : 433508123547299840,
  "in_reply_to_status_id" : 433507946073313280,
  "created_at" : "2014-02-12 07:49:25 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433507354756120576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0066393445, 8.2839312224 ]
  },
  "id_str" : "433507599225745408",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez already thought about that, but so far no master plan has shown itself. :)",
  "id" : 433507599225745408,
  "in_reply_to_status_id" : 433507354756120576,
  "created_at" : "2014-02-12 07:47:20 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433506662876327936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0071708261, 8.2829317889 ]
  },
  "id_str" : "433507173692637184",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez snap, you need to do another conference on your home turf and get some travel grants in place ;)",
  "id" : 433507173692637184,
  "in_reply_to_status_id" : 433506662876327936,
  "created_at" : "2014-02-12 07:45:39 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0070992838, 8.2831707192 ]
  },
  "id_str" : "433506708930199552",
  "text" : "\u00ABMy pattern for falling in love with strangers from the internet is more bob-rossian: \u2018I don\u2019t make mistakes, just happy little accidents\u2019.\u00BB",
  "id" : 433506708930199552,
  "created_at" : "2014-02-12 07:43:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433505202562662400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0070204743, 8.2829326282 ]
  },
  "id_str" : "433506432952987648",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez arrived: nope, but today should be the 10 workdays iirc.",
  "id" : 433506432952987648,
  "in_reply_to_status_id" : 433505202562662400,
  "created_at" : "2014-02-12 07:42:42 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433505202562662400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0068471302, 8.2825739309 ]
  },
  "id_str" : "433506333334458368",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez so sad! I have no plans for mainland US so far this year :( there\u2019s probably no chance you can extend your stay after Amsterdam?",
  "id" : 433506333334458368,
  "in_reply_to_status_id" : 433505202562662400,
  "created_at" : "2014-02-12 07:42:18 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433425944196308992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0070115678, 8.2835168511 ]
  },
  "id_str" : "433504550612656128",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez damn, our timing really sucks, I\u2019m in London for a conference at that time :(",
  "id" : 433504550612656128,
  "in_reply_to_status_id" : 433425944196308992,
  "created_at" : "2014-02-12 07:35:13 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433405248255066112",
  "text" : "handing out epistemological relationship advice. what could possibly go wrong.",
  "id" : 433405248255066112,
  "created_at" : "2014-02-12 01:00:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Paul J Berkman",
      "screen_name" : "pjberkman",
      "indices" : [ 14, 24 ],
      "id_str" : "251847117",
      "id" : 251847117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433404552344133633",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433404998853332994",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @pjberkman and it\u2019s not even that \u201Cback in the days\u201D for me, I\u2019m still working with RNAseq data sets regularly.",
  "id" : 433404998853332994,
  "in_reply_to_status_id" : 433404552344133633,
  "created_at" : "2014-02-12 00:59:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433400732700901376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433401334248013825",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC can\u2019t argue with that, not even from a popperian point of view :)",
  "id" : 433401334248013825,
  "in_reply_to_status_id" : 433400732700901376,
  "created_at" : "2014-02-12 00:45:04 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433397372933390336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433400078104281089",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC you should have told me about your arachnophilia ;)",
  "id" : 433400078104281089,
  "in_reply_to_status_id" : 433397372933390336,
  "created_at" : "2014-02-12 00:40:05 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/gWhulw6LSC",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1067",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433395647036026880",
  "text" : "pretty sure they mean terrific instead of terrible! http:\/\/t.co\/gWhulw6LSC",
  "id" : 433395647036026880,
  "created_at" : "2014-02-12 00:22:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 106, 119 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/mD9VsMsnOT",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0088462",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433394938353831936",
  "text" : "De Novo Assembly and Transcriptome Analysis of Contrasting Sugarcane Varieties http:\/\/t.co\/mD9VsMsnOT \/cc @PhilippBayer",
  "id" : 433394938353831936,
  "created_at" : "2014-02-12 00:19:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/Z05ixl0d3d",
      "expanded_url" : "http:\/\/i.imgur.com\/2kQcifM.gif",
      "display_url" : "i.imgur.com\/2kQcifM.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433392750701318144",
  "text" : "happiness is\u2026 http:\/\/t.co\/Z05ixl0d3d",
  "id" : 433392750701318144,
  "created_at" : "2014-02-12 00:10:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Ntrm2DLiqI",
      "expanded_url" : "http:\/\/i.imgur.com\/FumqHxx.jpg",
      "display_url" : "i.imgur.com\/FumqHxx.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433390177919447040",
  "text" : "Remember those \u2018How to Walk on Ice\u2019 guides that say \u2018think of yourself as a penguin\u2019? http:\/\/t.co\/Ntrm2DLiqI",
  "id" : 433390177919447040,
  "created_at" : "2014-02-12 00:00:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433387754429227008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433388511677661184",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot makes #8 so much easier.",
  "id" : 433388511677661184,
  "in_reply_to_status_id" : 433387754429227008,
  "created_at" : "2014-02-11 23:54:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433386885117788160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433387522060996608",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot pretty meaningless for people who are content with living out of a backpack in general.",
  "id" : 433387522060996608,
  "in_reply_to_status_id" : 433386885117788160,
  "created_at" : "2014-02-11 23:50:11 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/Hr1asw450G",
      "expanded_url" : "http:\/\/www.slideshare.net\/cunningminx\/8-things-i-wish-id-known-about-polyamory-before-i-tried-it-and-it-kicked-my-ass",
      "display_url" : "slideshare.net\/cunningminx\/8-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433383895112118272",
  "text" : "\u00AB8 Things I Wish I'd Known About Polyamory (Before I Tried It and It Kicked My Ass)\u00BB http:\/\/t.co\/Hr1asw450G",
  "id" : 433383895112118272,
  "created_at" : "2014-02-11 23:35:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/WkqqhRA78r",
      "expanded_url" : "http:\/\/www.biosphereonline.com\/2014\/02\/07\/new-species-of-sea-cucumber-named-after-pet-dog\/",
      "display_url" : "biosphereonline.com\/2014\/02\/07\/new\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096614167, 8.2830274517 ]
  },
  "id_str" : "433377080169218048",
  "text" : "So cute! New species of sea cucumber named after pet dog http:\/\/t.co\/WkqqhRA78r",
  "id" : 433377080169218048,
  "created_at" : "2014-02-11 23:08:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/2SjXEDsXlQ",
      "expanded_url" : "http:\/\/thescienceweb.wordpress.com\/2014\/02\/10\/science-articles-to-be-published-as-graphic-novels\/",
      "display_url" : "thescienceweb.wordpress.com\/2014\/02\/10\/sci\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009691945, 8.2830838233 ]
  },
  "id_str" : "433347575760957440",
  "text" : "Science articles to be published as graphic\u00A0novels http:\/\/t.co\/2SjXEDsXlQ",
  "id" : 433347575760957440,
  "created_at" : "2014-02-11 21:11:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/9Aqze6cTya",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=s-OoG1aGYO0",
      "display_url" : "youtube.com\/watch?v=s-OoG1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009691945, 8.2830838233 ]
  },
  "id_str" : "433345435256635392",
  "text" : "\u2018if you're in love, then you are the lucky one cause most of us are bitter over someone\u2019 sweet simple fingerpickings http:\/\/t.co\/9Aqze6cTya",
  "id" : 433345435256635392,
  "created_at" : "2014-02-11 21:02:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1718358342, 8.627909338 ]
  },
  "id_str" : "433319570049622016",
  "text" : "Frankfurt, where smiling at fellow commuters yields one of two things: either invites to the gay sauna or requests for cocaine.",
  "id" : 433319570049622016,
  "created_at" : "2014-02-11 19:20:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1162541614, 8.6817566111 ]
  },
  "id_str" : "433315730378199040",
  "text" : "\u00ABWow, siehst du zerst\u00F6rt aus!\u00BB \u2014 \u00ABVerl\u00E4ngertes Wochenende.\u00BB",
  "id" : 433315730378199040,
  "created_at" : "2014-02-11 19:04:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1705407759, 8.6233582591 ]
  },
  "id_str" : "433308902986612736",
  "text" : "\u00ABWie hie\u00DF das wenn man genug Partner hat? Polysaccharided?\u00BB",
  "id" : 433308902986612736,
  "created_at" : "2014-02-11 18:37:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433295368546037760",
  "text" : "\u00ABlet me know which date(s) you would prefer and how many human-people you wish to bring\u00BB",
  "id" : 433295368546037760,
  "created_at" : "2014-02-11 17:44:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Lior Pachter",
      "screen_name" : "lpachter",
      "indices" : [ 52, 61 ],
      "id_str" : "31936449",
      "id" : 31936449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/s4dNXy4wyF",
      "expanded_url" : "http:\/\/liorpachter.wordpress.com\/2014\/02\/11\/the-network-nonsense-of-manolis-kellis\/",
      "display_url" : "liorpachter.wordpress.com\/2014\/02\/11\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433265895461638145",
  "text" : "RT @pathogenomenick: The maths of this elude me but @lpachter is on fire here: http:\/\/t.co\/s4dNXy4wyF Also attacks unscholarly \u201CIn preparat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lior Pachter",
        "screen_name" : "lpachter",
        "indices" : [ 31, 40 ],
        "id_str" : "31936449",
        "id" : 31936449
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/s4dNXy4wyF",
        "expanded_url" : "http:\/\/liorpachter.wordpress.com\/2014\/02\/11\/the-network-nonsense-of-manolis-kellis\/",
        "display_url" : "liorpachter.wordpress.com\/2014\/02\/11\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "433263460605231104",
    "text" : "The maths of this elude me but @lpachter is on fire here: http:\/\/t.co\/s4dNXy4wyF Also attacks unscholarly \u201CIn preparation for &lt;X&gt;\u201D citation",
    "id" : 433263460605231104,
    "created_at" : "2014-02-11 15:37:13 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 433265895461638145,
  "created_at" : "2014-02-11 15:46:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "indices" : [ 43, 57 ],
      "id_str" : "2315551122",
      "id" : 2315551122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/N1JUqN8NZm",
      "expanded_url" : "http:\/\/wp.me\/p4ik2k-1b",
      "display_url" : "wp.me\/p4ik2k-1b"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723185053, 8.6276494244 ]
  },
  "id_str" : "433262676756942848",
  "text" : "I always suspected something like this! RT @TheScienceWeb: Assembly done in my head, admits author of MIRA http:\/\/t.co\/N1JUqN8NZm",
  "id" : 433262676756942848,
  "created_at" : "2014-02-11 15:34:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/nk2xyb9vR4",
      "expanded_url" : "http:\/\/www.dogetek.co\/game\/",
      "display_url" : "dogetek.co\/game\/"
    } ]
  },
  "geo" : { },
  "id_str" : "433260439384760320",
  "text" : "Flappy Doge. Much Over http:\/\/t.co\/nk2xyb9vR4",
  "id" : 433260439384760320,
  "created_at" : "2014-02-11 15:25:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723241028, 8.6276247849 ]
  },
  "id_str" : "433240269145006080",
  "text" : "\u00ABMensch auf Foto gesehen &amp; gedacht \u2018den finde ich nicht sexy\u2019, aber dann haben wir uns afk getroffen\u2026\u00BB\u2014\u00AB\u2026und jetzt liegst du hier im Bett.\u00BB",
  "id" : 433240269145006080,
  "created_at" : "2014-02-11 14:05:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097059459, 8.2830254641 ]
  },
  "id_str" : "433031014848684033",
  "text" : "\u00AB55 Gallonen Lube in einem kleinen Raum versch\u00FCtten und 20 Leute darin einsperren? Ich mein, wie nennt man das \u00FCberhaupt?!\u00BB \u2014 \u00ABWochenende.\u00BB",
  "id" : 433031014848684033,
  "created_at" : "2014-02-11 00:13:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/iT5ehNhjOp",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/Massgenomics\/~3\/A-m36jBgMfA\/low-hanging-fruit-human-wgs.html",
      "display_url" : "feedproxy.google.com\/~r\/Massgenomic\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009536, 8.77657 ]
  },
  "id_str" : "432992293835251713",
  "text" : "Low-hanging Fruit for Human WGS http:\/\/t.co\/iT5ehNhjOp",
  "id" : 432992293835251713,
  "created_at" : "2014-02-10 21:39:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/aOdJRVNi9p",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/TtyBpcGXNAg\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009493, 8.776649 ]
  },
  "id_str" : "432991726744387584",
  "text" : "What's climate change ruining now? Baby penguin\u00A0edition http:\/\/t.co\/aOdJRVNi9p",
  "id" : 432991726744387584,
  "created_at" : "2014-02-10 21:37:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432976526670172160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1148536478, 8.682808973 ]
  },
  "id_str" : "432977146160889856",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC good thing I seldom spent more than 4h\/day @ the office as a student, oh glorious sshd and lack of responsibility for 3rd parties.",
  "id" : 432977146160889856,
  "in_reply_to_status_id" : 432976526670172160,
  "created_at" : "2014-02-10 20:39:30 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 3, 11 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432976590738587648",
  "text" : "RT @heyaudy: How do German electronic metal fans dye their bacteria? Grammstein!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "432923793720221697",
    "text" : "How do German electronic metal fans dye their bacteria? Grammstein!",
    "id" : 432923793720221697,
    "created_at" : "2014-02-10 17:07:30 +0000",
    "user" : {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "protected" : false,
      "id_str" : "14534523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923034147777474561\/zZvXWmSQ_normal.jpg",
      "id" : 14534523,
      "verified" : false
    }
  },
  "id" : 432976590738587648,
  "created_at" : "2014-02-10 20:37:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432975984954834944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1146096594, 8.6826056759 ]
  },
  "id_str" : "432976449822552064",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC for that they have good mentoring. One of the few things not affected by impostor syndrome.",
  "id" : 432976449822552064,
  "in_reply_to_status_id" : 432975984954834944,
  "created_at" : "2014-02-10 20:36:44 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432974865201524736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1149577765, 8.6824615814 ]
  },
  "id_str" : "432975468820955136",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC hopefully the sheer beauty of their forearms will save them ;) But thought more of \u2018sending them home to get a good nights sleep\u2019.",
  "id" : 432975468820955136,
  "in_reply_to_status_id" : 432974865201524736,
  "created_at" : "2014-02-10 20:32:50 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1138776645, 8.6786891225 ]
  },
  "id_str" : "432971981215252481",
  "text" : "Not sure whether it counts as good deed if you feed deadline ridden students and give out advice on how to sleep in the office.",
  "id" : 432971981215252481,
  "created_at" : "2014-02-10 20:18:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNAdigest.org",
      "screen_name" : "DNADigest",
      "indices" : [ 22, 32 ],
      "id_str" : "334912047",
      "id" : 334912047
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "database",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/bdwjvSjroU",
      "expanded_url" : "https:\/\/opensnp.org",
      "display_url" : "opensnp.org"
    } ]
  },
  "geo" : { },
  "id_str" : "432946785040863232",
  "text" : "My submission for the @DNADigest sharing competition: https:\/\/t.co\/bdwjvSjroU, your favorite open (source|data) personal genomics #database.",
  "id" : 432946785040863232,
  "created_at" : "2014-02-10 18:38:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/63iLpyElOr",
      "expanded_url" : "http:\/\/l.yimg.com\/os\/423\/2013\/09\/05\/02seymour-gif_001246.gif",
      "display_url" : "l.yimg.com\/os\/423\/2013\/09\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432899396095590402",
  "text" : "science or: how i learned to stop worrying and love the wait http:\/\/t.co\/63iLpyElOr",
  "id" : 432899396095590402,
  "created_at" : "2014-02-10 15:30:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 103, 116 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/paRtZu5mVl",
      "expanded_url" : "http:\/\/www.biomedcentral.com\/1471-2288\/13\/134",
      "display_url" : "biomedcentral.com\/1471-2288\/13\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432856271142658048",
  "text" : "\u00ABreaders would be better served by reviewing actual results than reading the authors\u2019 conclusions\u00BB \/HT @PhilippBayer http:\/\/t.co\/paRtZu5mVl",
  "id" : 432856271142658048,
  "created_at" : "2014-02-10 12:39:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432846058377342977",
  "text" : "\u00ABSo far my thesis is lacking a storyline. I could rewrite it in verse.\u00BB \u2013 \u00ABOnce upon a midnight dreary, while I clustered, weak and weary\u2026\u00BB",
  "id" : 432846058377342977,
  "created_at" : "2014-02-10 11:58:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/jPQPJ7Q6xx",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view1\/1217449\/shrimp-on-a-treadmill-o.gif",
      "display_url" : "stream1.gifsoup.com\/view1\/1217449\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432828681434566657",
  "text" : "\u00ABwe're not slacking off, we're feeding the shrimps!\u00BB the benefits of having aquaria in the office. http:\/\/t.co\/jPQPJ7Q6xx",
  "id" : 432828681434566657,
  "created_at" : "2014-02-10 10:49:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/Y8Yiu4SBjR",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/polyamory\/comments\/1xhjmx\/do_you_know_whats_really_great_about_having_two\/cfbf4b7",
      "display_url" : "reddit.com\/r\/polyamory\/co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432821734564057088",
  "text" : "on the benefits of polyamory for workaholics http:\/\/t.co\/Y8Yiu4SBjR",
  "id" : 432821734564057088,
  "created_at" : "2014-02-10 10:21:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432802779803815936",
  "text" : "\u00ABHabt ihr nicht mal zusammen gewohnt?\u00BB \u2013 \u00ABDas tun wir auch immer noch, also zumindest hoffe ich das sie noch die Miete \u00FCberweist.\u00BB",
  "id" : 432802779803815936,
  "created_at" : "2014-02-10 09:06:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432793646975291392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1640037264, 8.6441134367 ]
  },
  "id_str" : "432795021902110720",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer k, intuitively had agreed that should be small enough,but then I\u2019ve never tried to handle objects with 250 trillion elements",
  "id" : 432795021902110720,
  "in_reply_to_status_id" : 432793646975291392,
  "created_at" : "2014-02-10 08:35:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432792270782210048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1453548835, 8.668317592 ]
  },
  "id_str" : "432793467979563008",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer what are you storing in the matrix? ;)",
  "id" : 432793467979563008,
  "in_reply_to_status_id" : 432792270782210048,
  "created_at" : "2014-02-10 08:29:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9960796694, 8.3546136006 ]
  },
  "id_str" : "432782662252916736",
  "text" : "jam-packed commuter trains, aka the poor man\u2019s standing desk\u2026",
  "id" : 432782662252916736,
  "created_at" : "2014-02-10 07:46:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/n5xeeeLRkI",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=surS1xgLwzg&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=surS1x\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096609067, 8.2830398167 ]
  },
  "id_str" : "432671827979403264",
  "text" : "getting over it http:\/\/t.co\/n5xeeeLRkI",
  "id" : 432671827979403264,
  "created_at" : "2014-02-10 00:26:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432665625316438018",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096609067, 8.2830398167 ]
  },
  "id_str" : "432667989021036544",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer in a way, though guess it\u2019s probably just a subset of perfect information assumption in game theory\/economics.",
  "id" : 432667989021036544,
  "in_reply_to_status_id" : 432665625316438018,
  "created_at" : "2014-02-10 00:11:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 60, 73 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/tcn3YdcZR0",
      "expanded_url" : "http:\/\/www.replicatedtypo.com\/retiring-procrustean-linguistics\/7186.html",
      "display_url" : "replicatedtypo.com\/retiring-procr\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096609067, 8.2830398167 ]
  },
  "id_str" : "432664019846303744",
  "text" : "Retiring Procrustean Linguistics (w\/ nod to Carl Woese) \/cc @PhilippBayer http:\/\/t.co\/tcn3YdcZR0",
  "id" : 432664019846303744,
  "created_at" : "2014-02-09 23:55:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/TgM8z5dPN1",
      "expanded_url" : "http:\/\/imgur.com\/PG9s48U",
      "display_url" : "imgur.com\/PG9s48U"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096609067, 8.2830398167 ]
  },
  "id_str" : "432658914115862529",
  "text" : "and then we kissed like http:\/\/t.co\/TgM8z5dPN1",
  "id" : 432658914115862529,
  "created_at" : "2014-02-09 23:34:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432587541817348096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.072071108, 8.2465306019 ]
  },
  "id_str" : "432597647145578496",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC \u2018To a surrounded enemy, you must leave a way of escape.\u2019 (not from the lost chapters!)",
  "id" : 432597647145578496,
  "in_reply_to_status_id" : 432587541817348096,
  "created_at" : "2014-02-09 19:31:31 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.034042179, 8.260981338 ]
  },
  "id_str" : "432594784931561472",
  "text" : "\u00ABThat went better than expected: you still have all your extremities.\u00BB \u2014 \u00ABWait, what was your best case scenario?!\u00BB",
  "id" : 432594784931561472,
  "created_at" : "2014-02-09 19:20:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095586467, 8.2829299383 ]
  },
  "id_str" : "432588561142259712",
  "text" : "\u00ABI don\u2019t really believe in hierarchical polyamory, I\u2019m against doing OSO layers.\u00BB",
  "id" : 432588561142259712,
  "created_at" : "2014-02-09 18:55:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/4xSVWoTJrr",
      "expanded_url" : "https:\/\/31.media.tumblr.com\/05426812984147f398d9978a3dd29300\/tumblr_inline_mzcz44NOu51r3axz6.gif",
      "display_url" : "31.media.tumblr.com\/05426812984147\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "432161655296753664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095177957, 8.2829837843 ]
  },
  "id_str" : "432163070975434752",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot symbolbild: https:\/\/t.co\/4xSVWoTJrr",
  "id" : 432163070975434752,
  "in_reply_to_status_id" : 432161655296753664,
  "created_at" : "2014-02-08 14:44:39 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "snipe, mother of assets \uD83D\uDC3E",
      "screen_name" : "snipeyhead",
      "indices" : [ 3, 14 ],
      "id_str" : "14246782",
      "id" : 14246782
    }, {
      "name" : "Dual Core",
      "screen_name" : "dualcoremusic",
      "indices" : [ 70, 84 ],
      "id_str" : "32910267",
      "id" : 32910267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/n7OsPg1XW0",
      "expanded_url" : "http:\/\/i.imgur.com\/3KrmRf7.gif",
      "display_url" : "i.imgur.com\/3KrmRf7.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "432160421685248001",
  "text" : "RT @snipeyhead: How crytocurrencies work: http:\/\/t.co\/n7OsPg1XW0 (via @dualcoremusic)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dual Core",
        "screen_name" : "dualcoremusic",
        "indices" : [ 54, 68 ],
        "id_str" : "32910267",
        "id" : 32910267
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/n7OsPg1XW0",
        "expanded_url" : "http:\/\/i.imgur.com\/3KrmRf7.gif",
        "display_url" : "i.imgur.com\/3KrmRf7.gif"
      } ]
    },
    "geo" : { },
    "id_str" : "432005702786514944",
    "text" : "How crytocurrencies work: http:\/\/t.co\/n7OsPg1XW0 (via @dualcoremusic)",
    "id" : 432005702786514944,
    "created_at" : "2014-02-08 04:19:20 +0000",
    "user" : {
      "name" : "snipe, mother of assets \uD83D\uDC3E",
      "screen_name" : "snipeyhead",
      "protected" : false,
      "id_str" : "14246782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545415835675033600\/gDuSi44o_normal.jpeg",
      "id" : 14246782,
      "verified" : true
    }
  },
  "id" : 432160421685248001,
  "created_at" : "2014-02-08 14:34:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432156636489064449",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095614089, 8.2830186049 ]
  },
  "id_str" : "432157700743782400",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot it works both ways. After getting rid of your fat layer it also got better, just w\/ about 30 min delay and not immediately.",
  "id" : 432157700743782400,
  "in_reply_to_status_id" : 432156636489064449,
  "created_at" : "2014-02-08 14:23:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432154338438287360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095099387, 8.2830077468 ]
  },
  "id_str" : "432155920798601216",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u2018too fucked to drink\u2019 was my first guess, in that case getting rid of the fat layer was a great placebo.",
  "id" : 432155920798601216,
  "in_reply_to_status_id" : 432154338438287360,
  "created_at" : "2014-02-08 14:16:15 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/UHHAbblfIQ",
      "expanded_url" : "http:\/\/instagram.com\/p\/kKAxDMBwo8\/",
      "display_url" : "instagram.com\/p\/kKAxDMBwo8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "432140839255810049",
  "text" : "Lost http:\/\/t.co\/UHHAbblfIQ",
  "id" : 432140839255810049,
  "created_at" : "2014-02-08 13:16:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 11, 17 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095177957, 8.2829837843 ]
  },
  "id_str" : "432111462040223744",
  "text" : "Impressed: @Lobot can guesstimate my dress size correctly while I couldn\u2019t figure it out if my life depended on it (luckily it seldom does).",
  "id" : 432111462040223744,
  "created_at" : "2014-02-08 11:19:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095177957, 8.2829837843 ]
  },
  "id_str" : "432104281974767616",
  "text" : "stumbling around like in a drunken stupor: one of the signs I should try to clean my glasses for once.",
  "id" : 432104281974767616,
  "created_at" : "2014-02-08 10:51:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/UpPHX2jbB7",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3261",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431800266808365056",
  "text" : "never build robots if you fail at formal logic http:\/\/t.co\/UpPHX2jbB7",
  "id" : 431800266808365056,
  "created_at" : "2014-02-07 14:43:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/ouIz0Nq66b",
      "expanded_url" : "http:\/\/i.imgur.com\/bp2x4Yv.gif",
      "display_url" : "i.imgur.com\/bp2x4Yv.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "431796588458291200",
  "text" : "a yawnsome wave http:\/\/t.co\/ouIz0Nq66b",
  "id" : 431796588458291200,
  "created_at" : "2014-02-07 14:28:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tamas nagy \u26F7\uFE0F",
      "screen_name" : "tlngy",
      "indices" : [ 3, 9 ],
      "id_str" : "553965890",
      "id" : 553965890
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tlngy\/status\/431582107316408320\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/QnHLb1ktN2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf1Jo8MCEAAJK-z.jpg",
      "id_str" : "431582106997624832",
      "id" : 431582106997624832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf1Jo8MCEAAJK-z.jpg",
      "sizes" : [ {
        "h" : 633,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1906,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2244,
        "resize" : "fit",
        "w" : 2411
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1117,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/QnHLb1ktN2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/RYceHVgM8i",
      "expanded_url" : "http:\/\/jasonya.com\/wp\/the-uncanny-valley-of-multidisciplinary-studies\/",
      "display_url" : "jasonya.com\/wp\/the-uncanny\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431775050086490112",
  "text" : "RT @tlngy: \"The uncanny valley of multidisciplinary studies\" from http:\/\/t.co\/RYceHVgM8i http:\/\/t.co\/QnHLb1ktN2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tlngy\/status\/431582107316408320\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/QnHLb1ktN2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf1Jo8MCEAAJK-z.jpg",
        "id_str" : "431582106997624832",
        "id" : 431582106997624832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf1Jo8MCEAAJK-z.jpg",
        "sizes" : [ {
          "h" : 633,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1906,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2244,
          "resize" : "fit",
          "w" : 2411
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1117,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/QnHLb1ktN2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/RYceHVgM8i",
        "expanded_url" : "http:\/\/jasonya.com\/wp\/the-uncanny-valley-of-multidisciplinary-studies\/",
        "display_url" : "jasonya.com\/wp\/the-uncanny\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "431582107316408320",
    "text" : "\"The uncanny valley of multidisciplinary studies\" from http:\/\/t.co\/RYceHVgM8i http:\/\/t.co\/QnHLb1ktN2",
    "id" : 431582107316408320,
    "created_at" : "2014-02-07 00:16:07 +0000",
    "user" : {
      "name" : "tamas nagy \u26F7\uFE0F",
      "screen_name" : "tlngy",
      "protected" : false,
      "id_str" : "553965890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699690378883018753\/1B_zfHS2_normal.jpg",
      "id" : 553965890,
      "verified" : false
    }
  },
  "id" : 431775050086490112,
  "created_at" : "2014-02-07 13:02:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431742553168572416",
  "text" : "meetings in bioinformatics: a bunch of people sitting around a computer, watching file transfers.",
  "id" : 431742553168572416,
  "created_at" : "2014-02-07 10:53:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Chapman",
      "screen_name" : "chapmangamo",
      "indices" : [ 54, 66 ],
      "id_str" : "30633376",
      "id" : 30633376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/Q0lwNf72oW",
      "expanded_url" : "http:\/\/chapmangamo.tumblr.com\/post\/58440651720\/worldwide-woofs-how-to-sound-like-a-dog-in-14",
      "display_url" : "chapmangamo.tumblr.com\/post\/584406517\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1342132174, 8.5420207211 ]
  },
  "id_str" : "431690852512333824",
  "text" : "Now I know all the Icelandic I will ever need. Thanks @chapmangamo! http:\/\/t.co\/Q0lwNf72oW",
  "id" : 431690852512333824,
  "created_at" : "2014-02-07 07:28:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/LBJgsBR7ed",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/02\/06\/reggie-watts-is-americas-alt.html",
      "display_url" : "boingboing.net\/2014\/02\/06\/reg\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723197138, 8.6276289988 ]
  },
  "id_str" : "431427056728293376",
  "text" : "Reggie\u00A0Watts is America's alternate-universe sitcom science\u00A0teacher http:\/\/t.co\/LBJgsBR7ed",
  "id" : 431427056728293376,
  "created_at" : "2014-02-06 14:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/FFXJckG4sw",
      "expanded_url" : "http:\/\/i.imgur.com\/BAps9iB.gif",
      "display_url" : "i.imgur.com\/BAps9iB.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723197138, 8.6276289988 ]
  },
  "id_str" : "431420920407019520",
  "text" : "status: http:\/\/t.co\/FFXJckG4sw",
  "id" : 431420920407019520,
  "created_at" : "2014-02-06 13:35:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/aH0rwwjIFd",
      "expanded_url" : "http:\/\/thescienceweb.wordpress.com\/2014\/02\/05\/r-help-mailing-list-to-use-cage-fighting-to-resolve-conflicts\/",
      "display_url" : "thescienceweb.wordpress.com\/2014\/02\/05\/r-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431406438083076096",
  "text" : "R-help mailing list to use cage-fighting to resolve conflicts http:\/\/t.co\/aH0rwwjIFd",
  "id" : 431406438083076096,
  "created_at" : "2014-02-06 12:38:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1652447666, 8.6159237284 ]
  },
  "id_str" : "431397357004267520",
  "text" : "\u00ABWurdest du schon von einem Syntax-Error in Versuchung gef\u00FChrt?\u00BB \u2014 \u00ABEy, hast du mich gerade Fehler genannt?!\u00BB",
  "id" : 431397357004267520,
  "created_at" : "2014-02-06 12:01:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 91, 100 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/LUiNJtOHdC",
      "expanded_url" : "http:\/\/www.theallium.com\/math\/inter-faith-marriage-bayesian-and-frequentist-tie-the-knot\/",
      "display_url" : "theallium.com\/math\/inter-fai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431362259688767488",
  "text" : "\u00ABInter-faith marriage: bayesian &amp; frequentist tie the knot\u00BB So you know what to expect @Senficon http:\/\/t.co\/LUiNJtOHdC",
  "id" : 431362259688767488,
  "created_at" : "2014-02-06 09:42:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1773153068, 8.6241256933 ]
  },
  "id_str" : "431343974985764864",
  "text" : "\u00ABHow I was converted to poly? Der Mann und die Frau vom Mann haben gekocht!\u00BB",
  "id" : 431343974985764864,
  "created_at" : "2014-02-06 08:29:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/FGX3HZDByg",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view6\/4852038\/indiana-jones-hat-grab-o.gif",
      "display_url" : "stream1.gifsoup.com\/view6\/4852038\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1461159509, 8.6675045862 ]
  },
  "id_str" : "431339615229067264",
  "text" : "Every other day thanks to the transfer times on my commute. http:\/\/t.co\/FGX3HZDByg",
  "id" : 431339615229067264,
  "created_at" : "2014-02-06 08:12:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431293615621431296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0071517921, 8.2827004676 ]
  },
  "id_str" : "431324599272615936",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thx :)",
  "id" : 431324599272615936,
  "in_reply_to_status_id" : 431293615621431296,
  "created_at" : "2014-02-06 07:12:52 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096522044, 8.283012654 ]
  },
  "id_str" : "431233732004306944",
  "text" : "\u00ABAu\u00DFerdem schmeckt dein Naseninneres besser wenn du nicht rauchst.\u00BB \u2014 \u00ABSold!\u00BB",
  "id" : 431233732004306944,
  "created_at" : "2014-02-06 01:11:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096830317, 8.2830705917 ]
  },
  "id_str" : "431224436684234752",
  "text" : "\u00ABZ\u00E4hlen Arschl\u00F6cher eigentlich zu den Genitalien?\u00BB \u2013 \u00ABNur bei uns\u2026\u00BB",
  "id" : 431224436684234752,
  "created_at" : "2014-02-06 00:34:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 107, 117 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/7Y5oT1AR11",
      "expanded_url" : "http:\/\/porngram.sexualitics.org\/",
      "display_url" : "porngram.sexualitics.org"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096830317, 8.2830705917 ]
  },
  "id_str" : "431206684493877248",
  "text" : "Looks like some1 already did a title-based n-gram equivalent for porn. We should offer the scraped tagdata @eltonjohn http:\/\/t.co\/7Y5oT1AR11",
  "id" : 431206684493877248,
  "created_at" : "2014-02-05 23:24:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/WvqcQfRohM",
      "expanded_url" : "http:\/\/kotaku.com\/what-games-taught-me-about-having-two-girlfriends-at-on-1511252093",
      "display_url" : "kotaku.com\/what-games-tau\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096830317, 8.2830705917 ]
  },
  "id_str" : "431202603264143360",
  "text" : "What Games Taught Me About Having Two Girlfriends At Once (spoiler: nothing except scheduling) http:\/\/t.co\/WvqcQfRohM",
  "id" : 431202603264143360,
  "created_at" : "2014-02-05 23:08:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/5UTuZxh4pW",
      "expanded_url" : "http:\/\/www.dorktower.com\/2014\/02\/05\/the-only-thing-you-ever-need-know-about-writing-dork-tower-05-02-14\/",
      "display_url" : "dorktower.com\/2014\/02\/05\/the\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096830317, 8.2830705917 ]
  },
  "id_str" : "431200115110727680",
  "text" : "i\u2019m an imposter\u2026  http:\/\/t.co\/5UTuZxh4pW",
  "id" : 431200115110727680,
  "created_at" : "2014-02-05 22:58:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 117, 130 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/GqS5heTyPs",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0086803",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096830317, 8.2830705917 ]
  },
  "id_str" : "431198195423924225",
  "text" : "From Days to Hours: Reporting Clinically Actionable Variants from Whole Genome Sequencing http:\/\/t.co\/GqS5heTyPs \/cc @PhilippBayer",
  "id" : 431198195423924225,
  "created_at" : "2014-02-05 22:50:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096830317, 8.2830705917 ]
  },
  "id_str" : "431197372652478464",
  "text" : "\u00ABDa gab es doch noch diese andere Klasse von Algorithmen. Markov chain Monte Cristo?\u00BB",
  "id" : 431197372652478464,
  "created_at" : "2014-02-05 22:47:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431170751018721280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096830317, 8.2830705917 ]
  },
  "id_str" : "431172216013996032",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC that\u2019s the best thing. I didn\u2019t teach in any measurable way. It\u2019s just aping ;)",
  "id" : 431172216013996032,
  "in_reply_to_status_id" : 431170751018721280,
  "created_at" : "2014-02-05 21:07:21 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431170020513558529",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096830317, 8.2830705917 ]
  },
  "id_str" : "431170400564027394",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC really wanted to give that student a hug for learning the one really useful skill if working in academia.",
  "id" : 431170400564027394,
  "in_reply_to_status_id" : 431170020513558529,
  "created_at" : "2014-02-05 21:00:08 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095638883, 8.28293005 ]
  },
  "id_str" : "431159163457400832",
  "text" : "\u00ABDu bist mein R-Mentor. Hab dir lang beim googlen \u00FCber die Schulter geschaut &amp; kann jetzt selbst suchen.\u00BB \u2013 \u00ABIch muss weinen vor R\u00FChrung!\u00BB",
  "id" : 431159163457400832,
  "created_at" : "2014-02-05 20:15:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0036885776, 8.3658024576 ]
  },
  "id_str" : "431137431564582913",
  "text" : "Alternativnutzung der zu gro\u00DFen In-Ears: (Ohrk)anal dilator.",
  "id" : 431137431564582913,
  "created_at" : "2014-02-05 18:49:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430852503500881920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1780278986, 8.6244038624 ]
  },
  "id_str" : "431136578283765760",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer did you get a good answer on that?",
  "id" : 431136578283765760,
  "in_reply_to_status_id" : 430852503500881920,
  "created_at" : "2014-02-05 18:45:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 25 ],
      "url" : "http:\/\/t.co\/xaI6hkwDOu",
      "expanded_url" : "http:\/\/cellfate.org",
      "display_url" : "cellfate.org"
    } ]
  },
  "geo" : { },
  "id_str" : "431097041251348481",
  "text" : "So http:\/\/t.co\/xaI6hkwDOu did meet the same ultimate end that the URL suggests\u2026 Too bad I wanted their data\u2026",
  "id" : 431097041251348481,
  "created_at" : "2014-02-05 16:08:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431080447141879808",
  "text" : "\u00ABIch kann mich doch nicht mal entscheiden was ich Mittags essen soll. Wie soll ich dir da sagen welchen Bewerber du einstellen sollst?\u00BB",
  "id" : 431080447141879808,
  "created_at" : "2014-02-05 15:02:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431034868181372928",
  "text" : "\u00ABWir haben schon wieder Leute in der Mensa verloren?\u00BB \u2013 \u00ABIn Zukunft z\u00E4hlen wir durch und gehen nur noch h\u00E4ndchenhaltend in Zweierreihen.\u00BB",
  "id" : 431034868181372928,
  "created_at" : "2014-02-05 12:01:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/07EPjPSay6",
      "expanded_url" : "http:\/\/nowiknow.com\/invisible-pink\/",
      "display_url" : "nowiknow.com\/invisible-pink\/"
    } ]
  },
  "geo" : { },
  "id_str" : "431017590777843713",
  "text" : "Camouflage during WW2: Invisible Pink http:\/\/t.co\/07EPjPSay6",
  "id" : 431017590777843713,
  "created_at" : "2014-02-05 10:52:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431011760988889088",
  "text" : "Speed of peer review: suddenly revised manuscripts \u2013 for which I totally forgot I'm a co-author \u2013 appear in my inbox.",
  "id" : 431011760988889088,
  "created_at" : "2014-02-05 10:29:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 3, 12 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/ih7mFfoPXQ",
      "expanded_url" : "http:\/\/nblo.gs\/TuNEz",
      "display_url" : "nblo.gs\/TuNEz"
    } ]
  },
  "geo" : { },
  "id_str" : "431001599092465664",
  "text" : "RT @BobOHara: Detonation Aftermath http:\/\/t.co\/ih7mFfoPXQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/ih7mFfoPXQ",
        "expanded_url" : "http:\/\/nblo.gs\/TuNEz",
        "display_url" : "nblo.gs\/TuNEz"
      } ]
    },
    "geo" : { },
    "id_str" : "430977677424472064",
    "text" : "Detonation Aftermath http:\/\/t.co\/ih7mFfoPXQ",
    "id" : 430977677424472064,
    "created_at" : "2014-02-05 08:14:20 +0000",
    "user" : {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "protected" : false,
      "id_str" : "19146944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/624292977\/twitterProfilePhoto_normal.jpg",
      "id" : 19146944,
      "verified" : false
    }
  },
  "id" : 431001599092465664,
  "created_at" : "2014-02-05 09:49:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/ourfdH0sVY",
      "expanded_url" : "http:\/\/i.imgur.com\/rcHhvtu.gif",
      "display_url" : "i.imgur.com\/rcHhvtu.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "430998206231502848",
  "text" : "interspecies cooperation http:\/\/t.co\/ourfdH0sVY",
  "id" : 430998206231502848,
  "created_at" : "2014-02-05 09:35:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430986184672948224",
  "text" : "RT @PhilippBayer: \/u\/jetRink on \/r\/dataisbeautiful uses Arduino + artificial neural network to predict when he's going to have a coffee htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/eIQXhBmrba",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/dataisbeautiful\/comments\/1wzruo\/an_artificial_neural_network_in_my_coffeemaker\/",
        "display_url" : "reddit.com\/r\/dataisbeauti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "430872022843793408",
    "text" : "\/u\/jetRink on \/r\/dataisbeautiful uses Arduino + artificial neural network to predict when he's going to have a coffee http:\/\/t.co\/eIQXhBmrba",
    "id" : 430872022843793408,
    "created_at" : "2014-02-05 01:14:30 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 430986184672948224,
  "created_at" : "2014-02-05 08:48:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/r82PSiZpZw",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1063",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430983202706948097",
  "text" : "Life, Liberty and the pursuit of Crappiness http:\/\/t.co\/r82PSiZpZw",
  "id" : 430983202706948097,
  "created_at" : "2014-02-05 08:36:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096179727, 8.2830130732 ]
  },
  "id_str" : "430861090650865664",
  "text" : "\u00ABWie hei\u00DFen noch mal die vier Reiter der Apokalypse?\u00BB \u2014 \u00ABPestilenz, Krieg, Hunger und Poly-Drama?\u00BB",
  "id" : 430861090650865664,
  "created_at" : "2014-02-05 00:31:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096900121, 8.2830804184 ]
  },
  "id_str" : "430800251843526657",
  "text" : "\u00ABWie hei\u00DFt noch mal das Instrument das ich spiele seit ich 16 bin? Irgendwas mit \u2018G\u2019\u2026\u00BB \u2014 \u00ABGeigerz\u00E4hler?\u00BB",
  "id" : 430800251843526657,
  "created_at" : "2014-02-04 20:29:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096309424, 8.2829806596 ]
  },
  "id_str" : "430791910547267584",
  "text" : "\u00ABDu bist so unhygienisch\u2026 Deshalb liebe ich dich so sehr!\u00BB",
  "id" : 430791910547267584,
  "created_at" : "2014-02-04 19:56:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/hejeGMnUi6",
      "expanded_url" : "http:\/\/xkcd.com\/833\/",
      "display_url" : "xkcd.com\/833\/"
    } ]
  },
  "in_reply_to_status_id_str" : "430731010972471296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095638883, 8.28293005 ]
  },
  "id_str" : "430736178095357952",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC just make sure the labeling is right http:\/\/t.co\/hejeGMnUi6",
  "id" : 430736178095357952,
  "in_reply_to_status_id" : 430731010972471296,
  "created_at" : "2014-02-04 16:14:42 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/ZlNQsS3Dd6",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3258",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095638883, 8.28293005 ]
  },
  "id_str" : "430716673881288704",
  "text" : "object permanence http:\/\/t.co\/ZlNQsS3Dd6",
  "id" : 430716673881288704,
  "created_at" : "2014-02-04 14:57:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "indices" : [ 3, 18 ],
      "id_str" : "19416598",
      "id" : 19416598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430701817932943361",
  "text" : "RT @leonidkruglyak: \"Traditionally, biotech companies use AGBT to announce things they can\u2019t do yet, and probably never will.\" http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "satire",
        "indices" : [ 130, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/Cy3ju0FUJZ",
        "expanded_url" : "http:\/\/thescienceweb.wordpress.com\/2014\/02\/02\/biotech-companies-with-no-product-are-worth-more\/",
        "display_url" : "thescienceweb.wordpress.com\/2014\/02\/02\/bio\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "430496221451386880",
    "text" : "\"Traditionally, biotech companies use AGBT to announce things they can\u2019t do yet, and probably never will.\" http:\/\/t.co\/Cy3ju0FUJZ #satire",
    "id" : 430496221451386880,
    "created_at" : "2014-02-04 00:21:12 +0000",
    "user" : {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "protected" : false,
      "id_str" : "19416598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1095542276\/MyRecentPhoto_normal.jpg",
      "id" : 19416598,
      "verified" : false
    }
  },
  "id" : 430701817932943361,
  "created_at" : "2014-02-04 13:58:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096682912, 8.2830156666 ]
  },
  "id_str" : "430701444673847296",
  "text" : "\u00ABYour \u2018An Introduction into Perl\u2019 trainer will have a longstanding experience of never having used perl at all.\u00BB",
  "id" : 430701444673847296,
  "created_at" : "2014-02-04 13:56:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/z7ZBLzDNn9",
      "expanded_url" : "http:\/\/photos.travelblog.org\/Photos\/1446\/5435\/f\/20821-Dogs-Stuck-Together-After-Getting-Theirs-0.jpg",
      "display_url" : "photos.travelblog.org\/Photos\/1446\/54\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "430687070466478080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096067, 8.28296905 ]
  },
  "id_str" : "430689050732023808",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot stuck to the ground http:\/\/t.co\/z7ZBLzDNn9",
  "id" : 430689050732023808,
  "in_reply_to_status_id" : 430687070466478080,
  "created_at" : "2014-02-04 13:07:26 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096067, 8.28296905 ]
  },
  "id_str" : "430676016705859584",
  "text" : "\u00ABSchade das du den Anal-Vibrator wegwerfen musstest.\u00BB \u2013 \u00ABJa, sonst k\u00F6nnte ich jetzt viel entspannter arbeiten.\u00BB",
  "id" : 430676016705859584,
  "created_at" : "2014-02-04 12:15:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/cLd9y29XVN",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2014\/02\/the-squalid-grace-of-flappy-bird\/283526\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096067, 8.28296905 ]
  },
  "id_str" : "430672750169305089",
  "text" : "The Squalid Grace of Flappy Bird: Why playing stupid games staves off existential despair http:\/\/t.co\/cLd9y29XVN",
  "id" : 430672750169305089,
  "created_at" : "2014-02-04 12:02:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/affwtKoBIR",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0087908",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096067, 8.28296905 ]
  },
  "id_str" : "430670241191182336",
  "text" : "A Computational Approach to Qualitative Analysis in Large Textual Datasets http:\/\/t.co\/affwtKoBIR",
  "id" : 430670241191182336,
  "created_at" : "2014-02-04 11:52:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097462629, 8.2830617577 ]
  },
  "id_str" : "430668321701523457",
  "text" : "Home office, oder auch: Per Email dar\u00FCber informiert werden was der Hund im B\u00FCro treibt.",
  "id" : 430668321701523457,
  "created_at" : "2014-02-04 11:45:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Hills",
      "screen_name" : "rocza",
      "indices" : [ 3, 9 ],
      "id_str" : "14075844",
      "id" : 14075844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430648084583157760",
  "text" : "RT @rocza: \"he began signing his e-mails, \u201CTyrone B. Hayes, Ph.D., A.B.M.,\u201D for \u201Carticulate black man.\u201D\" after lobbyist email http:\/\/t.co\/R\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/RFtWX7BJkZ",
        "expanded_url" : "http:\/\/www.newyorker.com\/reporting\/2014\/02\/10\/140210fa_fact_aviv?currentPage=all",
        "display_url" : "newyorker.com\/reporting\/2014\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "430406668313063424",
    "text" : "\"he began signing his e-mails, \u201CTyrone B. Hayes, Ph.D., A.B.M.,\u201D for \u201Carticulate black man.\u201D\" after lobbyist email http:\/\/t.co\/RFtWX7BJkZ",
    "id" : 430406668313063424,
    "created_at" : "2014-02-03 18:25:20 +0000",
    "user" : {
      "name" : "Kelly Hills",
      "screen_name" : "rocza",
      "protected" : false,
      "id_str" : "14075844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788549856528859136\/dco0kme__normal.jpg",
      "id" : 14075844,
      "verified" : false
    }
  },
  "id" : 430648084583157760,
  "created_at" : "2014-02-04 10:24:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/dWwMapS5VE",
      "expanded_url" : "http:\/\/davidkanigan.files.wordpress.com\/2012\/06\/dog-sleeping-on-vent-its-hot.gif",
      "display_url" : "davidkanigan.files.wordpress.com\/2012\/06\/dog-sl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096067, 8.28296905 ]
  },
  "id_str" : "430646883934289920",
  "text" : "venting http:\/\/t.co\/dWwMapS5VE",
  "id" : 430646883934289920,
  "created_at" : "2014-02-04 10:19:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/35u6JJAmmM",
      "expanded_url" : "http:\/\/www.pbh2.com\/wordpress\/wp-content\/uploads\/2013\/05\/cutest-corgi-gifs-confused.gif",
      "display_url" : "pbh2.com\/wordpress\/wp-c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009665205, 8.283028485 ]
  },
  "id_str" : "430601711536070656",
  "text" : "status: http:\/\/t.co\/35u6JJAmmM",
  "id" : 430601711536070656,
  "created_at" : "2014-02-04 07:20:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009711472, 8.283076224 ]
  },
  "id_str" : "430504879959052288",
  "text" : "\u00ABThat embargo makes me feel so mysterious, I better buy some smokebombs and ninja costumes..\u00BB",
  "id" : 430504879959052288,
  "created_at" : "2014-02-04 00:55:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lex Nederbragt",
      "screen_name" : "lexnederbragt",
      "indices" : [ 3, 17 ],
      "id_str" : "48966898",
      "id" : 48966898
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opensource",
      "indices" : [ 64, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/tfvTbXBmb7",
      "expanded_url" : "http:\/\/flxlexblog.wordpress.com\/2014\/01\/31\/make-newbler-open-source\/",
      "display_url" : "flxlexblog.wordpress.com\/2014\/01\/31\/mak\u2026"
    }, {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/oStZgLtBhV",
      "expanded_url" : "https:\/\/docs.google.com\/spreadsheet\/viewform?formkey=dHRvZDFUcldvZXVnWmhvSnlMWDBLQ1E6MA",
      "display_url" : "docs.google.com\/spreadsheet\/vi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430474001878876160",
  "text" : "RT @lexnederbragt: Closing in on 100 signees. Help make Newbler #opensource  http:\/\/t.co\/tfvTbXBmb7 Petition https:\/\/t.co\/oStZgLtBhV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opensource",
        "indices" : [ 45, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/tfvTbXBmb7",
        "expanded_url" : "http:\/\/flxlexblog.wordpress.com\/2014\/01\/31\/make-newbler-open-source\/",
        "display_url" : "flxlexblog.wordpress.com\/2014\/01\/31\/mak\u2026"
      }, {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/oStZgLtBhV",
        "expanded_url" : "https:\/\/docs.google.com\/spreadsheet\/viewform?formkey=dHRvZDFUcldvZXVnWmhvSnlMWDBLQ1E6MA",
        "display_url" : "docs.google.com\/spreadsheet\/vi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "430451555788406785",
    "text" : "Closing in on 100 signees. Help make Newbler #opensource  http:\/\/t.co\/tfvTbXBmb7 Petition https:\/\/t.co\/oStZgLtBhV",
    "id" : 430451555788406785,
    "created_at" : "2014-02-03 21:23:42 +0000",
    "user" : {
      "name" : "Lex Nederbragt",
      "screen_name" : "lexnederbragt",
      "protected" : false,
      "id_str" : "48966898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1099225219\/DSC01628a_normal.jpg",
      "id" : 48966898,
      "verified" : false
    }
  },
  "id" : 430474001878876160,
  "created_at" : "2014-02-03 22:52:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009711472, 8.283076224 ]
  },
  "id_str" : "430470094926659585",
  "text" : "\u00ABHaha, du liest das Grundgesetz!\u00BB \u2013 \u00ABAber erz\u00E4hl es keinem\u2026\u00BB",
  "id" : 430470094926659585,
  "created_at" : "2014-02-03 22:37:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430462710942543872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009711472, 8.283076224 ]
  },
  "id_str" : "430463447504269312",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC there\u2019s probably some journal on phylomemetics that would publish it.",
  "id" : 430463447504269312,
  "in_reply_to_status_id" : 430462710942543872,
  "created_at" : "2014-02-03 22:10:58 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430458661061001216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009711472, 8.283076224 ]
  },
  "id_str" : "430461468317073408",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC ah, the application was mine* (*at least i don\u2019t remember having it heard before).",
  "id" : 430461468317073408,
  "in_reply_to_status_id" : 430458661061001216,
  "created_at" : "2014-02-03 22:03:06 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0078558084, 8.2664417848 ]
  },
  "id_str" : "430455998894329857",
  "text" : "\u00ABBefore I answer that let me ask: do\nyou want to know the rational choice or just have your own biases confirmed?\u00BB",
  "id" : 430455998894329857,
  "created_at" : "2014-02-03 21:41:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430450862377689089",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9939896982, 8.3305365036 ]
  },
  "id_str" : "430451142888550400",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon nah, took it Saturday when you dragged me to the library.",
  "id" : 430451142888550400,
  "in_reply_to_status_id" : 430450862377689089,
  "created_at" : "2014-02-03 21:22:04 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/091LHrY24E",
      "expanded_url" : "http:\/\/instagram.com\/p\/j-AGhXBwtu\/",
      "display_url" : "instagram.com\/p\/j-AGhXBwtu\/"
    } ]
  },
  "geo" : { },
  "id_str" : "430450528406208512",
  "text" : "Daf\u00FCr gibt es Treuepunkte http:\/\/t.co\/091LHrY24E",
  "id" : 430450528406208512,
  "created_at" : "2014-02-03 21:19:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430449171615588352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9870587823, 8.389731537 ]
  },
  "id_str" : "430450140521185280",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC this is the right time to admit: this analogy is so old I can\u2019t even google who did it first.",
  "id" : 430450140521185280,
  "in_reply_to_status_id" : 430449171615588352,
  "created_at" : "2014-02-03 21:18:05 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/U74GwxHRNf",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/PtEehwNALl0\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.99218, 8.416847 ]
  },
  "id_str" : "430448886759841792",
  "text" : "Marx's prescient predictions for the 21st\u00A0century http:\/\/t.co\/U74GwxHRNf",
  "id" : 430448886759841792,
  "created_at" : "2014-02-03 21:13:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430447317024403457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0107492223, 8.3001784604 ]
  },
  "id_str" : "430448571994087425",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC in that way it\u2019s also like teenagers &amp; sex: everyone\u2019s talking about it but nobody is doing it.",
  "id" : 430448571994087425,
  "in_reply_to_status_id" : 430447317024403457,
  "created_at" : "2014-02-03 21:11:51 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430444700802105344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.065485424, 8.6112520691 ]
  },
  "id_str" : "430446062349090816",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC let\u2019s talk work-life balance, from one hypocrite to another. ;)",
  "id" : 430446062349090816,
  "in_reply_to_status_id" : 430444700802105344,
  "created_at" : "2014-02-03 21:01:53 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430443688796254208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0760148659, 8.6447365437 ]
  },
  "id_str" : "430443825514180608",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC so I\u2019d be totally game for a chat instead :p",
  "id" : 430443825514180608,
  "in_reply_to_status_id" : 430443688796254208,
  "created_at" : "2014-02-03 20:52:59 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1062191935, 8.6487324949 ]
  },
  "id_str" : "430442763440881664",
  "text" : "Submitted an abstract on time, so no sleeping in the office today. \\o\/",
  "id" : 430442763440881664,
  "created_at" : "2014-02-03 20:48:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/RNhUbxrJkI",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3256",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430382138232299520",
  "text" : "enhanced interrogation technique http:\/\/t.co\/RNhUbxrJkI",
  "id" : 430382138232299520,
  "created_at" : "2014-02-03 16:47:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430359385169084416",
  "geo" : { },
  "id_str" : "430360902001385472",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot sorry f\u00FCr den Typo. Und ich glaube am \"Early Devonian\" kann man auch nichts ekelhaft finden ;)",
  "id" : 430360902001385472,
  "in_reply_to_status_id" : 430359385169084416,
  "created_at" : "2014-02-03 15:23:29 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430358674410700800",
  "geo" : { },
  "id_str" : "430358966057435136",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ja, Caps. war gemein, aber die Logik ist flawed: Gerade wenn ich es geschrieben habe kann der gegen\u00FCber leicht den Ekelfaktor meinen.",
  "id" : 430358966057435136,
  "in_reply_to_status_id" : 430358674410700800,
  "created_at" : "2014-02-03 15:15:47 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430357370741350401",
  "text" : "Wenn die Draft-Comments zwischen Deutsch &amp; Englisch wechseln &amp; man sich nicht sicher ist ob \"gross?!\" Ekelfaktor oder Capitalization meint\u2026",
  "id" : 430357370741350401,
  "created_at" : "2014-02-03 15:09:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430123432970170368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.3011781211, 8.2349282596 ]
  },
  "id_str" : "430319983303069696",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch \\o\/",
  "id" : 430319983303069696,
  "in_reply_to_status_id" : 430123432970170368,
  "created_at" : "2014-02-03 12:40:53 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heiko S.",
      "screen_name" : "hkos",
      "indices" : [ 3, 8 ],
      "id_str" : "27012673",
      "id" : 27012673
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "frankfurt",
      "indices" : [ 65, 75 ]
    }, {
      "text" : "afeturm",
      "indices" : [ 109, 117 ]
    }, {
      "text" : "afe",
      "indices" : [ 118, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/kHrXv7iRWH",
      "expanded_url" : "http:\/\/tmblr.co\/ZdlaZw16BMnVN",
      "display_url" : "tmblr.co\/ZdlaZw16BMnVN"
    } ]
  },
  "geo" : { },
  "id_str" : "429939329990160386",
  "text" : "RT @hkos: individual still photos of the afe tower demolition in #frankfurt, just now http:\/\/t.co\/kHrXv7iRWH #afeturm #afe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "frankfurt",
        "indices" : [ 55, 65 ]
      }, {
        "text" : "afeturm",
        "indices" : [ 99, 107 ]
      }, {
        "text" : "afe",
        "indices" : [ 108, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/kHrXv7iRWH",
        "expanded_url" : "http:\/\/tmblr.co\/ZdlaZw16BMnVN",
        "display_url" : "tmblr.co\/ZdlaZw16BMnVN"
      } ]
    },
    "geo" : { },
    "id_str" : "429916607306280960",
    "text" : "individual still photos of the afe tower demolition in #frankfurt, just now http:\/\/t.co\/kHrXv7iRWH #afeturm #afe",
    "id" : 429916607306280960,
    "created_at" : "2014-02-02 09:58:01 +0000",
    "user" : {
      "name" : "Heiko S.",
      "screen_name" : "hkos",
      "protected" : false,
      "id_str" : "27012673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425168062887624705\/9rE8MHkw_normal.jpeg",
      "id" : 27012673,
      "verified" : false
    }
  },
  "id" : 429939329990160386,
  "created_at" : "2014-02-02 11:28:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 20, 28 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1069388069, 8.7328284185 ]
  },
  "id_str" : "429938612726423552",
  "text" : "\u00ABTasche packen nach @moeffju-Art: 5 kg Sex-Equipment. Und 2 Zahnb\u00FCrsten.\u00BB",
  "id" : 429938612726423552,
  "created_at" : "2014-02-02 11:25:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prof Emma L Johnston",
      "screen_name" : "DrEmmaLJohnston",
      "indices" : [ 3, 19 ],
      "id_str" : "20956102",
      "id" : 20956102
    }, {
      "name" : "The Skewer",
      "screen_name" : "TheSkewerNews",
      "indices" : [ 124, 138 ],
      "id_str" : "1672221354",
      "id" : 1672221354
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GreatBarrierReef",
      "indices" : [ 65, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429885914975072256",
  "text" : "RT @DrEmmaLJohnston: Government asks if Australia really needs a #GreatBarrierReef when an Adequate one would do. Satire by @TheSkewerNews \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Skewer",
        "screen_name" : "TheSkewerNews",
        "indices" : [ 103, 117 ],
        "id_str" : "1672221354",
        "id" : 1672221354
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GreatBarrierReef",
        "indices" : [ 44, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/NXnkMNG4GA",
        "expanded_url" : "http:\/\/www.theskewer.com.au\/2014\/01\/adequate-barrier-reef-would-be-good-enough\/",
        "display_url" : "theskewer.com.au\/2014\/01\/adequa\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "429429643179851776",
    "geo" : { },
    "id_str" : "429850443628298241",
    "in_reply_to_user_id" : 1672221354,
    "text" : "Government asks if Australia really needs a #GreatBarrierReef when an Adequate one would do. Satire by @TheSkewerNews http:\/\/t.co\/NXnkMNG4GA",
    "id" : 429850443628298241,
    "in_reply_to_status_id" : 429429643179851776,
    "created_at" : "2014-02-02 05:35:06 +0000",
    "in_reply_to_screen_name" : "TheSkewerNews",
    "in_reply_to_user_id_str" : "1672221354",
    "user" : {
      "name" : "Prof Emma L Johnston",
      "screen_name" : "DrEmmaLJohnston",
      "protected" : false,
      "id_str" : "20956102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714716797405151232\/SNB3aOkg_normal.jpg",
      "id" : 20956102,
      "verified" : false
    }
  },
  "id" : 429885914975072256,
  "created_at" : "2014-02-02 07:56:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/9DINFPewVd",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/EhIS_KBSHjw\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429885137195917312",
  "text" : "Cockney\u00A0ATM http:\/\/t.co\/9DINFPewVd",
  "id" : 429885137195917312,
  "created_at" : "2014-02-02 07:52:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/d4tmJcWZNl",
      "expanded_url" : "http:\/\/linguistlist.org\/blog\/2013\/04\/finnish-origins-traced-back-to-klingon\/",
      "display_url" : "linguistlist.org\/blog\/2013\/04\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429767565351870464",
  "text" : "Finnish Origins Traced Back to Klingon http:\/\/t.co\/d4tmJcWZNl",
  "id" : 429767565351870464,
  "created_at" : "2014-02-02 00:05:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/hdEhgtEbWt",
      "expanded_url" : "http:\/\/jaysimons.deviantart.com\/art\/Map-of-the-Internet-1-0-427143215",
      "display_url" : "jaysimons.deviantart.com\/art\/Map-of-the\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009711472, 8.283076224 ]
  },
  "id_str" : "429756017896079360",
  "text" : "Map of the Internet 1.0 http:\/\/t.co\/hdEhgtEbWt",
  "id" : 429756017896079360,
  "created_at" : "2014-02-01 23:19:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 19, 29 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/VXw5UUF1kW",
      "expanded_url" : "http:\/\/oceanwildthings.com\/2014\/02\/look-at-the-size-of-that-gray-whale-penis\/",
      "display_url" : "oceanwildthings.com\/2014\/02\/look-a\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009711472, 8.283076224 ]
  },
  "id_str" : "429748171892596736",
  "text" : "\u00ABGet a lagoon!\u00BB MT @Fischblog: Heute Journal wieder ausgemacht. Stattdessen Blogeintrag \u00FCber Walpenisse gelesen: http:\/\/t.co\/VXw5UUF1kW",
  "id" : 429748171892596736,
  "created_at" : "2014-02-01 22:48:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/3ks5Z5w160",
      "expanded_url" : "http:\/\/24.media.tumblr.com\/8da547104c7be737413a025ab3520ea2\/tumblr_mzq54kcqPi1qj30m9o5_400.gif",
      "display_url" : "24.media.tumblr.com\/8da547104c7be7\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009711472, 8.283076224 ]
  },
  "id_str" : "429744006424457216",
  "text" : "current status: http:\/\/t.co\/3ks5Z5w160",
  "id" : 429744006424457216,
  "created_at" : "2014-02-01 22:32:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096596314, 8.2830763196 ]
  },
  "id_str" : "429724864346587136",
  "text" : "\u00ABonly academia could turn successes into mere not-failures\u00BB",
  "id" : 429724864346587136,
  "created_at" : "2014-02-01 21:16:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hawks",
      "screen_name" : "johnhawks",
      "indices" : [ 3, 13 ],
      "id_str" : "52584039",
      "id" : 52584039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429724778443051008",
  "text" : "RT @johnhawks: \u201CShe was on the verge of tears. She asked how they could be so mean to me. It was an accept with minor revisions.\u201D http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/NIw0Dozwtk",
        "expanded_url" : "http:\/\/scientopia.org\/blogs\/scicurious\/2014\/01\/24\/you-will-be-assimilated\/",
        "display_url" : "scientopia.org\/blogs\/scicurio\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "429705269845581824",
    "text" : "\u201CShe was on the verge of tears. She asked how they could be so mean to me. It was an accept with minor revisions.\u201D http:\/\/t.co\/NIw0Dozwtk",
    "id" : 429705269845581824,
    "created_at" : "2014-02-01 19:58:14 +0000",
    "user" : {
      "name" : "John Hawks",
      "screen_name" : "johnhawks",
      "protected" : false,
      "id_str" : "52584039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2162500613\/scio12-0442-jhawks-twitter-focus_normal.jpg",
      "id" : 52584039,
      "verified" : false
    }
  },
  "id" : 429724778443051008,
  "created_at" : "2014-02-01 21:15:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/m27J2V9V6d",
      "expanded_url" : "http:\/\/instagram.com\/p\/j4i6t8BwmN\/",
      "display_url" : "instagram.com\/p\/j4i6t8BwmN\/"
    } ]
  },
  "geo" : { },
  "id_str" : "429682663738605568",
  "text" : "nom the police http:\/\/t.co\/m27J2V9V6d",
  "id" : 429682663738605568,
  "created_at" : "2014-02-01 18:28:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429653007441997824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0051239369, 8.2692757619 ]
  },
  "id_str" : "429654139908681728",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy lack of data, as the consumption\/payment mails only go out irregularly.",
  "id" : 429654139908681728,
  "in_reply_to_status_id" : 429653007441997824,
  "created_at" : "2014-02-01 16:35:04 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Awl",
      "screen_name" : "Awl",
      "indices" : [ 3, 7 ],
      "id_str" : "13566872",
      "id" : 13566872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/hFS3hWOZCR",
      "expanded_url" : "http:\/\/www.theawl.com\/?p=186377",
      "display_url" : "theawl.com\/?p=186377"
    } ]
  },
  "geo" : { },
  "id_str" : "429542763739488256",
  "text" : "RT @Awl: Pete Seeger\u2019s Death Inspires Brief Fantasies About Participating in Social Change - http:\/\/t.co\/hFS3hWOZCR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.theawl.com\" rel=\"nofollow\"\u003EThe Awl\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/hFS3hWOZCR",
        "expanded_url" : "http:\/\/www.theawl.com\/?p=186377",
        "display_url" : "theawl.com\/?p=186377"
      } ]
    },
    "geo" : { },
    "id_str" : "429374841117237248",
    "text" : "Pete Seeger\u2019s Death Inspires Brief Fantasies About Participating in Social Change - http:\/\/t.co\/hFS3hWOZCR",
    "id" : 429374841117237248,
    "created_at" : "2014-01-31 22:05:14 +0000",
    "user" : {
      "name" : "The Awl",
      "screen_name" : "Awl",
      "protected" : false,
      "id_str" : "13566872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590954473008148480\/pJH9BapJ_normal.png",
      "id" : 13566872,
      "verified" : false
    }
  },
  "id" : 429542763739488256,
  "created_at" : "2014-02-01 09:12:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]