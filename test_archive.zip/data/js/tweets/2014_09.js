Grailbird.data.tweets_2014_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cAMP \u00D6ther",
      "screen_name" : "CampOther",
      "indices" : [ 0, 10 ],
      "id_str" : "258870463",
      "id" : 258870463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517038925345337344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140501277, 8.75335731 ]
  },
  "id_str" : "517039366418726912",
  "in_reply_to_user_id" : 258870463,
  "text" : "@CampOther it is, great way to recover after a long day in the office.",
  "id" : 517039366418726912,
  "in_reply_to_status_id" : 517038925345337344,
  "created_at" : "2014-09-30 19:52:45 +0000",
  "in_reply_to_screen_name" : "CampOther",
  "in_reply_to_user_id_str" : "258870463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/aWn1TGN2Lt",
      "expanded_url" : "http:\/\/instagram.com\/p\/tlNpMDhwhq\/",
      "display_url" : "instagram.com\/p\/tlNpMDhwhq\/"
    } ]
  },
  "geo" : { },
  "id_str" : "517033861877075968",
  "text" : "Mindlessly drilling holes into things http:\/\/t.co\/aWn1TGN2Lt",
  "id" : 517033861877075968,
  "created_at" : "2014-09-30 19:30:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/TkACD2txcW",
      "expanded_url" : "http:\/\/instagram.com\/p\/tk8I2zhwl6\/",
      "display_url" : "instagram.com\/p\/tk8I2zhwl6\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.182681627, 8.625550547 ]
  },
  "id_str" : "516995368593395713",
  "text" : "20 seconds before the sun went away. @ Riedberg http:\/\/t.co\/TkACD2txcW",
  "id" : 516995368593395713,
  "created_at" : "2014-09-30 16:57:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516637726993817600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172332746, 8.627549435 ]
  },
  "id_str" : "516991580704886784",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a okay, I'm not even close to meeting that deadline. Won't make it for a meeting tomorrow :(",
  "id" : 516991580704886784,
  "in_reply_to_status_id" : 516637726993817600,
  "created_at" : "2014-09-30 16:42:52 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/Lh2yEPUABR",
      "expanded_url" : "http:\/\/www.spiegel.de\/unispiegel\/studium\/bob-dylan-forscher-aus-schweden-zitieren-songs-in-aufsaetzen-a-994328.html",
      "display_url" : "spiegel.de\/unispiegel\/stu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516921198966759425",
  "text" : "Masters of War: Forscher liefern sich Bob-Dylan-Battle http:\/\/t.co\/Lh2yEPUABR",
  "id" : 516921198966759425,
  "created_at" : "2014-09-30 12:03:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1775587007, 8.6185387359 ]
  },
  "id_str" : "516910782106587136",
  "text" : "\u00AB[Nach einem Abgleich] steht nun fest, dass Du in 2014 noch einen Resturlaub von 22 Tagen hast.\u00BB m)",
  "id" : 516910782106587136,
  "created_at" : "2014-09-30 11:21:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516856391265296384",
  "geo" : { },
  "id_str" : "516856536245997569",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer definitely beats googling for your tweets. :p",
  "id" : 516856536245997569,
  "in_reply_to_status_id" : 516856391265296384,
  "created_at" : "2014-09-30 07:46:15 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516847132695732224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723348856, 8.6275655382 ]
  },
  "id_str" : "516852716094889984",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you know you can download a searchable archive of your tweets? ;)",
  "id" : 516852716094889984,
  "in_reply_to_status_id" : 516847132695732224,
  "created_at" : "2014-09-30 07:31:04 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SwiftOnSecurity",
      "screen_name" : "SwiftOnSecurity",
      "indices" : [ 3, 19 ],
      "id_str" : "2436389418",
      "id" : 2436389418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516851091901014016",
  "text" : "RT @SwiftOnSecurity: My Tumblr blog is read by 5,000 teenagers who apparently follow anything about me. They got a present last night. =| h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/aqXJO7Uz2r",
        "expanded_url" : "http:\/\/swiftonsecurity.tumblr.com\/post\/98675308034\/a-story-about-jessica",
        "display_url" : "swiftonsecurity.tumblr.com\/post\/986753080\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "516816005096435712",
    "text" : "My Tumblr blog is read by 5,000 teenagers who apparently follow anything about me. They got a present last night. =| http:\/\/t.co\/aqXJO7Uz2r",
    "id" : 516816005096435712,
    "created_at" : "2014-09-30 05:05:12 +0000",
    "user" : {
      "name" : "SwiftOnSecurity",
      "screen_name" : "SwiftOnSecurity",
      "protected" : false,
      "id_str" : "2436389418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932760905363935232\/gRvK3QAX_normal.jpg",
      "id" : 2436389418,
      "verified" : false
    }
  },
  "id" : 516851091901014016,
  "created_at" : "2014-09-30 07:24:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/MSThdWPAMV",
      "expanded_url" : "http:\/\/instagram.com\/p\/tjCs08Bwm_\/",
      "display_url" : "instagram.com\/p\/tjCs08Bwm_\/"
    } ]
  },
  "geo" : { },
  "id_str" : "516728322848743425",
  "text" : "Read all the PLOS. http:\/\/t.co\/MSThdWPAMV",
  "id" : 516728322848743425,
  "created_at" : "2014-09-29 23:16:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 3, 17 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/E33ecDlh2Q",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2014\/07\/16\/007187",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516725188768313344",
  "text" : "RT @BioMickWatson: Just to be clear, this paper annihilates a huge amount of 16S work: http:\/\/t.co\/E33ecDlh2Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/E33ecDlh2Q",
        "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2014\/07\/16\/007187",
        "display_url" : "biorxiv.org\/content\/early\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "516547431350407168",
    "text" : "Just to be clear, this paper annihilates a huge amount of 16S work: http:\/\/t.co\/E33ecDlh2Q",
    "id" : 516547431350407168,
    "created_at" : "2014-09-29 11:17:59 +0000",
    "user" : {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "protected" : false,
      "id_str" : "228586748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870214569679093760\/YIZGIDTS_normal.jpg",
      "id" : 228586748,
      "verified" : false
    }
  },
  "id" : 516725188768313344,
  "created_at" : "2014-09-29 23:04:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/A5iP1QWHMg",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/09\/28\/opinion\/sunday\/god-darwin-and-my-college-biology-class.html?smid=fb-nytimes&smtyp=cur&bicmp=AD&bicmlukp=WT.mc_id&bicmst=1409232722000&bicmet=1419773522000&_r=0",
      "display_url" : "nytimes.com\/2014\/09\/28\/opi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1153411772, 8.7503509498 ]
  },
  "id_str" : "516723555644751872",
  "text" : "Best misquoted Gould ever, see corrections after the article. http:\/\/t.co\/A5iP1QWHMg",
  "id" : 516723555644751872,
  "created_at" : "2014-09-29 22:57:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serena Caplins",
      "screen_name" : "SapCaps",
      "indices" : [ 3, 11 ],
      "id_str" : "21439133",
      "id" : 21439133
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/OQkzo1F7Me",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/09\/28\/opinion\/sunday\/god-darwin-and-my-college-biology-class.html?smid=fb-nytimes&smtyp=cur&bicmp=AD&bicmlukp=WT.mc_id&bicmst=1409232722000&bicmet=1419773522000&_r=0",
      "display_url" : "nytimes.com\/2014\/09\/28\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516723396399624192",
  "text" : "RT @SapCaps: Have you had \"The Talk\" with your students?http:\/\/t.co\/OQkzo1F7Me",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/OQkzo1F7Me",
        "expanded_url" : "http:\/\/www.nytimes.com\/2014\/09\/28\/opinion\/sunday\/god-darwin-and-my-college-biology-class.html?smid=fb-nytimes&smtyp=cur&bicmp=AD&bicmlukp=WT.mc_id&bicmst=1409232722000&bicmet=1419773522000&_r=0",
        "display_url" : "nytimes.com\/2014\/09\/28\/opi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "516708055216422912",
    "text" : "Have you had \"The Talk\" with your students?http:\/\/t.co\/OQkzo1F7Me",
    "id" : 516708055216422912,
    "created_at" : "2014-09-29 21:56:14 +0000",
    "user" : {
      "name" : "Serena Caplins",
      "screen_name" : "SapCaps",
      "protected" : false,
      "id_str" : "21439133",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933027297577152512\/lbjnS__I_normal.jpg",
      "id" : 21439133,
      "verified" : false
    }
  },
  "id" : 516723396399624192,
  "created_at" : "2014-09-29 22:57:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114026425, 8.7533059112 ]
  },
  "id_str" : "516679657543172096",
  "text" : "\u00ABHast du dir nach dem Katzenklo sauber machen eigentlich die Z\u00E4hne geputzt?\u00BB",
  "id" : 516679657543172096,
  "created_at" : "2014-09-29 20:03:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 61, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1129839881, 8.7551217687 ]
  },
  "id_str" : "516671570203668481",
  "text" : "\u00ABWas?! Der Bundesvorstand der Piratenpartei hat euch auf der #om14 die Reifen aufgeschlitzt?!\u00BB",
  "id" : 516671570203668481,
  "created_at" : "2014-09-29 19:31:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516637726993817600",
  "geo" : { },
  "id_str" : "516638364859387905",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a should be able to tell whether it works out tomorrow evening.",
  "id" : 516638364859387905,
  "in_reply_to_status_id" : 516637726993817600,
  "created_at" : "2014-09-29 17:19:19 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516637726993817600",
  "geo" : { },
  "id_str" : "516638219581288448",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a I will be in Berlin (of all places!) on 2nd, but the 1st could work out. Depends on whether I got deadline-ridden work done by then.",
  "id" : 516638219581288448,
  "in_reply_to_status_id" : 516637726993817600,
  "created_at" : "2014-09-29 17:18:44 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 7, 11 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "D.Hi",
      "screen_name" : "Dahie",
      "indices" : [ 12, 18 ],
      "id_str" : "50637773",
      "id" : 50637773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516615987211550720",
  "geo" : { },
  "id_str" : "516617628811816961",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @scy @Dahie und zum Abschied dann Burn America Burn. Damit wir auch endlich mal was von den Levellers k\u00F6nnen.",
  "id" : 516617628811816961,
  "in_reply_to_status_id" : 516615987211550720,
  "created_at" : "2014-09-29 15:56:55 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 7, 11 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om15",
      "indices" : [ 73, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516614004756992000",
  "geo" : { },
  "id_str" : "516615272690896896",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @scy Wenn wir schon bei PJ sind: Lernen wir noch Kamikaze bis zur #om15?",
  "id" : 516615272690896896,
  "in_reply_to_status_id" : 516614004756992000,
  "created_at" : "2014-09-29 15:47:33 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 7, 11 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516605202989088768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723438994, 8.6275864318 ]
  },
  "id_str" : "516609866983829504",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @scy You Said Something geht in dem Kontext nat\u00FCrlich auch super.",
  "id" : 516609866983829504,
  "in_reply_to_status_id" : 516605202989088768,
  "created_at" : "2014-09-29 15:26:05 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D.Hi",
      "screen_name" : "Dahie",
      "indices" : [ 0, 6 ],
      "id_str" : "50637773",
      "id" : 50637773
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 7, 13 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "ennomane",
      "screen_name" : "ennomane",
      "indices" : [ 94, 103 ],
      "id_str" : "850704103814705152",
      "id" : 850704103814705152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516606481572331520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723438994, 8.6275864318 ]
  },
  "id_str" : "516609489362223105",
  "in_reply_to_user_id" : 50637773,
  "text" : "@Dahie @Lobot das kann ich nur zur\u00FCckgeben. N\u00E4chstes Jahr dann zu dritt auf der Leseb\u00FChne von @ennomane!",
  "id" : 516609489362223105,
  "in_reply_to_status_id" : 516606481572331520,
  "created_at" : "2014-09-29 15:24:35 +0000",
  "in_reply_to_screen_name" : "Dahie",
  "in_reply_to_user_id_str" : "50637773",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723123266, 8.627561744 ]
  },
  "id_str" : "516584190599782400",
  "text" : "\u00ABIch hab nur mit einem Ohr zugeh\u00F6rt. Wen hast du tiefer implementiert?\u00BB",
  "id" : 516584190599782400,
  "created_at" : "2014-09-29 13:44:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 3, 8 ],
      "id_str" : "1147751",
      "id" : 1147751
    }, {
      "name" : "fukami",
      "screen_name" : "fukami",
      "indices" : [ 74, 81 ],
      "id_str" : "1209301",
      "id" : 1209301
    }, {
      "name" : "anke domscheit-berg",
      "screen_name" : "anked",
      "indices" : [ 83, 89 ],
      "id_str" : "16557497",
      "id" : 16557497
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 91, 107 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "mntmn \uA66E",
      "screen_name" : "mntmn",
      "indices" : [ 112, 118 ],
      "id_str" : "19429480",
      "id" : 19429480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516541988020445184",
  "text" : "RT @johl: Am Donnerstag darf ich eine tolle Veranstaltung moderieren. Mit @fukami, @anked, @gedankenstuecke und @mntmn. https:\/\/t.co\/Bk8jyo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "fukami",
        "screen_name" : "fukami",
        "indices" : [ 64, 71 ],
        "id_str" : "1209301",
        "id" : 1209301
      }, {
        "name" : "anke domscheit-berg",
        "screen_name" : "anked",
        "indices" : [ 73, 79 ],
        "id_str" : "16557497",
        "id" : 16557497
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 81, 97 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "mntmn \uA66E",
        "screen_name" : "mntmn",
        "indices" : [ 102, 108 ],
        "id_str" : "19429480",
        "id" : 19429480
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/Bk8jyoOH8c",
        "expanded_url" : "https:\/\/www.wikimedia.de\/wiki\/Wikimedia-Salon_-_Das_ABC_des_Freien_Wissens",
        "display_url" : "wikimedia.de\/wiki\/Wikimedia\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "516530982259011584",
    "text" : "Am Donnerstag darf ich eine tolle Veranstaltung moderieren. Mit @fukami, @anked, @gedankenstuecke und @mntmn. https:\/\/t.co\/Bk8jyoOH8c",
    "id" : 516530982259011584,
    "created_at" : "2014-09-29 10:12:37 +0000",
    "user" : {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "protected" : false,
      "id_str" : "1147751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/876909912185597952\/E61jm8M3_normal.jpg",
      "id" : 1147751,
      "verified" : false
    }
  },
  "id" : 516541988020445184,
  "created_at" : "2014-09-29 10:56:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conrad Hackett",
      "screen_name" : "conradhackett",
      "indices" : [ 3, 17 ],
      "id_str" : "71643224",
      "id" : 71643224
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/conradhackett\/status\/516281186847449088\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/S17vPS3lMZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByozAPqCYAIbraN.png",
      "id_str" : "516281186583207938",
      "id" : 516281186583207938,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByozAPqCYAIbraN.png",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 877,
        "resize" : "fit",
        "w" : 580
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 877,
        "resize" : "fit",
        "w" : 580
      }, {
        "h" : 877,
        "resize" : "fit",
        "w" : 580
      } ],
      "display_url" : "pic.twitter.com\/S17vPS3lMZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/OzBrGGWNrB",
      "expanded_url" : "http:\/\/www.gallup.com\/poll\/170789\/new-record-highs-moral-acceptability.aspx",
      "display_url" : "gallup.com\/poll\/170789\/ne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516302163853991936",
  "text" : "RT @conradhackett: More Americans say polygamy is morally acceptable\n2006 5%\n2014 14%\n\nhttp:\/\/t.co\/OzBrGGWNrB http:\/\/t.co\/S17vPS3lMZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/conradhackett\/status\/516281186847449088\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/S17vPS3lMZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByozAPqCYAIbraN.png",
        "id_str" : "516281186583207938",
        "id" : 516281186583207938,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByozAPqCYAIbraN.png",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 877,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 877,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 877,
          "resize" : "fit",
          "w" : 580
        } ],
        "display_url" : "pic.twitter.com\/S17vPS3lMZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/OzBrGGWNrB",
        "expanded_url" : "http:\/\/www.gallup.com\/poll\/170789\/new-record-highs-moral-acceptability.aspx",
        "display_url" : "gallup.com\/poll\/170789\/ne\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "516281186847449088",
    "text" : "More Americans say polygamy is morally acceptable\n2006 5%\n2014 14%\n\nhttp:\/\/t.co\/OzBrGGWNrB http:\/\/t.co\/S17vPS3lMZ",
    "id" : 516281186847449088,
    "created_at" : "2014-09-28 17:40:01 +0000",
    "user" : {
      "name" : "Conrad Hackett",
      "screen_name" : "conradhackett",
      "protected" : false,
      "id_str" : "71643224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932396599942303746\/QGFfcGdB_normal.jpg",
      "id" : 71643224,
      "verified" : true
    }
  },
  "id" : 516302163853991936,
  "created_at" : "2014-09-28 19:03:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "indices" : [ 3, 12 ],
      "id_str" : "2442015493",
      "id" : 2442015493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/xwL9JIuE75",
      "expanded_url" : "http:\/\/lgbtstem.wordpress.com\/2014\/09\/28\/an-interview-with-kirsty-flower\/",
      "display_url" : "lgbtstem.wordpress.com\/2014\/09\/28\/an-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516299626828533760",
  "text" : "RT @LGBTSTEM: We've a new contributor to the blog.  If you're LGBT and work in STEM, how about you join us? http:\/\/t.co\/xwL9JIuE75 cc @cass\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kirsty Flower",
        "screen_name" : "cassyorkirsty",
        "indices" : [ 120, 134 ],
        "id_str" : "57331016",
        "id" : 57331016
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/xwL9JIuE75",
        "expanded_url" : "http:\/\/lgbtstem.wordpress.com\/2014\/09\/28\/an-interview-with-kirsty-flower\/",
        "display_url" : "lgbtstem.wordpress.com\/2014\/09\/28\/an-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "516259150578593793",
    "text" : "We've a new contributor to the blog.  If you're LGBT and work in STEM, how about you join us? http:\/\/t.co\/xwL9JIuE75 cc @cassyorkirsty",
    "id" : 516259150578593793,
    "created_at" : "2014-09-28 16:12:27 +0000",
    "user" : {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "protected" : false,
      "id_str" : "2442015493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685082380223295488\/XGTcyfxo_normal.jpg",
      "id" : 2442015493,
      "verified" : false
    }
  },
  "id" : 516299626828533760,
  "created_at" : "2014-09-28 18:53:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 88, 94 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om15",
      "indices" : [ 30, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140397046, 8.7533118828 ]
  },
  "id_str" : "516297570457772032",
  "text" : "Angesichts des Datums f\u00FCr die #om15 freue ich mich schon sehr darauf vor Ort wieder mit @Lobot 'Leaving on a Jet Plane' zu spielen.",
  "id" : 516297570457772032,
  "created_at" : "2014-09-28 18:45:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gero Nagel",
      "screen_name" : "zweifeln",
      "indices" : [ 3, 12 ],
      "id_str" : "170420130",
      "id" : 170420130
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/zweifeln\/status\/516229172352397312\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/sEpyZqtxMs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByoDsTQIQAA3ZXf.jpg",
      "id_str" : "516229166904393728",
      "id" : 516229166904393728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByoDsTQIQAA3ZXf.jpg",
      "sizes" : [ {
        "h" : 288,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1139,
        "resize" : "fit",
        "w" : 2688
      }, {
        "h" : 868,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/sEpyZqtxMs"
    } ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 14, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516293943601152001",
  "text" : "RT @zweifeln: #om14 - macht doch anders! http:\/\/t.co\/sEpyZqtxMs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/zweifeln\/status\/516229172352397312\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/sEpyZqtxMs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByoDsTQIQAA3ZXf.jpg",
        "id_str" : "516229166904393728",
        "id" : 516229166904393728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByoDsTQIQAA3ZXf.jpg",
        "sizes" : [ {
          "h" : 288,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1139,
          "resize" : "fit",
          "w" : 2688
        }, {
          "h" : 868,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 508,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/sEpyZqtxMs"
      } ],
      "hashtags" : [ {
        "text" : "om14",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516229172352397312",
    "text" : "#om14 - macht doch anders! http:\/\/t.co\/sEpyZqtxMs",
    "id" : 516229172352397312,
    "created_at" : "2014-09-28 14:13:20 +0000",
    "user" : {
      "name" : "Gero Nagel",
      "screen_name" : "zweifeln",
      "protected" : false,
      "id_str" : "170420130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792075587921870848\/9Pu-OVPG_normal.jpg",
      "id" : 170420130,
      "verified" : false
    }
  },
  "id" : 516293943601152001,
  "created_at" : "2014-09-28 18:30:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516263764535291904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400708, 8.7534265872 ]
  },
  "id_str" : "516293758951116802",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 danke, haben es heile geschafft. :)",
  "id" : 516293758951116802,
  "in_reply_to_status_id" : 516263764535291904,
  "created_at" : "2014-09-28 18:29:59 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 17, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/Zb2kOBpJsz",
      "expanded_url" : "http:\/\/instagram.com\/p\/tfnrZVBwsJ\/",
      "display_url" : "instagram.com\/p\/tfnrZVBwsJ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "516246687917281280",
  "text" : "Und das Ende der #om14 http:\/\/t.co\/Zb2kOBpJsz",
  "id" : 516246687917281280,
  "created_at" : "2014-09-28 15:22:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Jens-Wolfhard",
      "screen_name" : "Drahflow",
      "indices" : [ 9, 18 ],
      "id_str" : "92904426",
      "id" : 92904426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516224862680281089",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.317659475, 9.478085446 ]
  },
  "id_str" : "516225848010346498",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy hat @Drahflow dich aufgekl\u00E4rt? ;)",
  "id" : 516225848010346498,
  "in_reply_to_status_id" : 516224862680281089,
  "created_at" : "2014-09-28 14:00:07 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EuropeBeyondDivision",
      "screen_name" : "jungePiraten",
      "indices" : [ 77, 90 ],
      "id_str" : "736908496055205888",
      "id" : 736908496055205888
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3198976393, 9.4680117674 ]
  },
  "id_str" : "516218930957135872",
  "text" : "\u00ABDer Bundesvorstand hat entschieden das die openmind 2015 unter dem Dach der @JungePiraten stattfinden wird.\u00BB #om14",
  "id" : 516218930957135872,
  "created_at" : "2014-09-28 13:32:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chief Blocka",
      "screen_name" : "FeministaJones",
      "indices" : [ 3, 18 ],
      "id_str" : "40684090",
      "id" : 40684090
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SexPositiveSunday",
      "indices" : [ 20, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/kySh4Pp3Vo",
      "expanded_url" : "http:\/\/www.ebony.com\/love-sex\/talk-like-sex-when-yes-means-yes-777#.VCf5ZhyYMVA.twitter",
      "display_url" : "ebony.com\/love-sex\/talk-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516200158049361920",
  "text" : "RT @FeministaJones: #SexPositiveSunday When \u2018Yes!\u2019 Means \u2018Yes!\u2019  http:\/\/t.co\/kySh4Pp3Vo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SexPositiveSunday",
        "indices" : [ 0, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/kySh4Pp3Vo",
        "expanded_url" : "http:\/\/www.ebony.com\/love-sex\/talk-like-sex-when-yes-means-yes-777#.VCf5ZhyYMVA.twitter",
        "display_url" : "ebony.com\/love-sex\/talk-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "516196919098359808",
    "text" : "#SexPositiveSunday When \u2018Yes!\u2019 Means \u2018Yes!\u2019  http:\/\/t.co\/kySh4Pp3Vo",
    "id" : 516196919098359808,
    "created_at" : "2014-09-28 12:05:10 +0000",
    "user" : {
      "name" : "Chief Blocka",
      "screen_name" : "FeministaJones",
      "protected" : false,
      "id_str" : "40684090",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/931704506232004609\/DnehDeXw_normal.jpg",
      "id" : 40684090,
      "verified" : true
    }
  },
  "id" : 516200158049361920,
  "created_at" : "2014-09-28 12:18:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192915499, 9.4755979754 ]
  },
  "id_str" : "516182686256623617",
  "text" : "\u00ABBist du auch nicht so ein Fan von dem Auflauf?\u00BB \u2014 \u00ABDu meinst von dem Block Reis?\u00BB #om14",
  "id" : 516182686256623617,
  "created_at" : "2014-09-28 11:08:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 34, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/gBTdnyUEmI",
      "expanded_url" : "http:\/\/instagram.com\/p\/tfIMFNhwmh\/",
      "display_url" : "instagram.com\/p\/tfIMFNhwmh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "516177442038640640",
  "text" : "open your mind and open your lock #om14 http:\/\/t.co\/gBTdnyUEmI",
  "id" : 516177442038640640,
  "created_at" : "2014-09-28 10:47:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/QNU2tqIPPM",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/yGP_dGPmU4k\/cash-strapped-kansas-auctions.html",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516169700339109888",
  "text" : "Cash-strapped Kansas auctions huge lot of seized\u00A0sex-toys http:\/\/t.co\/QNU2tqIPPM",
  "id" : 516169700339109888,
  "created_at" : "2014-09-28 10:17:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192595434, 9.4751854643 ]
  },
  "id_str" : "516166881196384256",
  "text" : "\u00ABMan sollte auch nicht \u00FCber sexistische Witze lachen wenn man weiss das es ein Witz ist.\u00BB\u2013\u00ABDeine Mutter lacht \u00FCber sexistische Witze!\u00BB #om14",
  "id" : 516166881196384256,
  "created_at" : "2014-09-28 10:05:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openmind #om17",
      "screen_name" : "openmindkonf",
      "indices" : [ 0, 13 ],
      "id_str" : "158112993",
      "id" : 158112993
    }, {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 14, 21 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 22, 28 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516150935798968321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.318670938, 9.4770428954 ]
  },
  "id_str" : "516153341353951232",
  "in_reply_to_user_id" : 158112993,
  "text" : "@openmindkonf @acid23 @Lobot n\u00E4chstes Jahr dann Fleisch nur per opt-in?",
  "id" : 516153341353951232,
  "in_reply_to_status_id" : 516150935798968321,
  "created_at" : "2014-09-28 09:12:00 +0000",
  "in_reply_to_screen_name" : "openmindkonf",
  "in_reply_to_user_id_str" : "158112993",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516146986140327936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3193853154, 9.475253437 ]
  },
  "id_str" : "516147675893596160",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach das Ergebnis wird dann als einzelne Schmuckaktie ausgegeben.",
  "id" : 516147675893596160,
  "in_reply_to_status_id" : 516146986140327936,
  "created_at" : "2014-09-28 08:49:30 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 23, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3193378696, 9.4755157776 ]
  },
  "id_str" : "516146930934874113",
  "text" : "Ein St\u00FCck Freiheit 2.0 #om14",
  "id" : 516146930934874113,
  "created_at" : "2014-09-28 08:46:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 23, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/vHMAl62UVD",
      "expanded_url" : "http:\/\/xkcd.com\/1013\/",
      "display_url" : "xkcd.com\/1013\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3193378696, 9.4755157776 ]
  },
  "id_str" : "516146453564366848",
  "text" : "http:\/\/t.co\/vHMAl62UVD #om14",
  "id" : 516146453564366848,
  "created_at" : "2014-09-28 08:44:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516052383655133184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3191397861, 9.4758583042 ]
  },
  "id_str" : "516124558332805121",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nope , just discovered the paper. Might give it a shot next week.",
  "id" : 516124558332805121,
  "in_reply_to_status_id" : 516052383655133184,
  "created_at" : "2014-09-28 07:17:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 24, 31 ],
      "id_str" : "41419667",
      "id" : 41419667
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 64, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/IAi0UYpM72",
      "expanded_url" : "http:\/\/instagram.com\/p\/tdBATAhwvr\/",
      "display_url" : "instagram.com\/p\/tdBATAhwvr\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3193129595, 9.4751902398 ]
  },
  "id_str" : "515880277965832192",
  "text" : "Ich glaube ich kann den @lutoma in Sachen Hochbett noch toppen. #om14 http:\/\/t.co\/IAi0UYpM72",
  "id" : 515880277965832192,
  "created_at" : "2014-09-27 15:06:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Krennmair",
      "screen_name" : "der_ak",
      "indices" : [ 3, 10 ],
      "id_str" : "26962623",
      "id" : 26962623
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 12, 28 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/6Ly4iD3bM1",
      "expanded_url" : "http:\/\/hitchhikers.wikia.com\/wiki\/Shoe_Event_Horizon",
      "display_url" : "hitchhikers.wikia.com\/wiki\/Shoe_Even\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "515868654706393088",
  "text" : "RT @der_ak: @gedankenstuecke the example \u201Eevery civilization that accepted shoes failed\u201C reminds me of http:\/\/t.co\/6Ly4iD3bM1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/6Ly4iD3bM1",
        "expanded_url" : "http:\/\/hitchhikers.wikia.com\/wiki\/Shoe_Event_Horizon",
        "display_url" : "hitchhikers.wikia.com\/wiki\/Shoe_Even\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "515858403936468992",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 52.5262540693, 13.3278167311 ]
    },
    "id_str" : "515868533058994177",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke the example \u201Eevery civilization that accepted shoes failed\u201C reminds me of http:\/\/t.co\/6Ly4iD3bM1",
    "id" : 515868533058994177,
    "in_reply_to_status_id" : 515858403936468992,
    "created_at" : "2014-09-27 14:20:17 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Andreas Krennmair",
      "screen_name" : "der_ak",
      "protected" : false,
      "id_str" : "26962623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748533181176029184\/81fXMTdq_normal.jpg",
      "id" : 26962623,
      "verified" : false
    }
  },
  "id" : 515868654706393088,
  "created_at" : "2014-09-27 14:20:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3190375453, 9.4763263288 ]
  },
  "id_str" : "515866461509005313",
  "text" : "\u00ABIch hab ja keine Ahnung von Doctor Who, aber was macht der mit diesem Sonic Screwdriver? Darmspiegelungen?!\u00BB #om14",
  "id" : 515866461509005313,
  "created_at" : "2014-09-27 14:12:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/KLxwoyD4hF",
      "expanded_url" : "http:\/\/instagram.com\/p\/tc5YAShwvj\/",
      "display_url" : "instagram.com\/p\/tc5YAShwvj\/"
    } ]
  },
  "geo" : { },
  "id_str" : "515863391538515968",
  "text" : "M\u00FCdes (St|D)reamteam http:\/\/t.co\/KLxwoyD4hF",
  "id" : 515863391538515968,
  "created_at" : "2014-09-27 13:59:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/KmJxhGQtrp",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/09\/27\/rebutting-every-civilization.html#more-334352",
      "display_url" : "boingboing.net\/2014\/09\/27\/reb\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.319285, 9.475274 ]
  },
  "id_str" : "515858403936468992",
  "text" : "Rebutting \"Every civilization that accepted homosexuality failed\" http:\/\/t.co\/KmJxhGQtrp",
  "id" : 515858403936468992,
  "created_at" : "2014-09-27 13:40:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515848120878792704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3191750097, 9.4752036739 ]
  },
  "id_str" : "515849005868531712",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot &lt;3",
  "id" : 515849005868531712,
  "in_reply_to_status_id" : 515848120878792704,
  "created_at" : "2014-09-27 13:02:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515846708224593920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3191644226, 9.4753059576 ]
  },
  "id_str" : "515847014337495040",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot es fehlt nicht nur das G\u00FCrkchen-Emoji, sondern auch das Nutella-G\u00FCrkchen-Emoji!",
  "id" : 515847014337495040,
  "in_reply_to_status_id" : 515846708224593920,
  "created_at" : "2014-09-27 12:54:46 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515845625209163776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3191644226, 9.4753059576 ]
  },
  "id_str" : "515846261929701376",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Darauf freue ich mich schon so! \uD83D\uDC1C",
  "id" : 515846261929701376,
  "in_reply_to_status_id" : 515845625209163776,
  "created_at" : "2014-09-27 12:51:47 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515843130676224000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192583192, 9.4751443627 ]
  },
  "id_str" : "515844375612784640",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot f\u00FCtter mich!",
  "id" : 515844375612784640,
  "in_reply_to_status_id" : 515843130676224000,
  "created_at" : "2014-09-27 12:44:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 44, 50 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/QazzErTNQA",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=Zm-sQnazFAQ",
      "display_url" : "m.youtube.com\/watch?v=Zm-sQn\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192431105, 9.4751489567 ]
  },
  "id_str" : "515843283118223361",
  "text" : "The Crying Game https:\/\/t.co\/QazzErTNQA \/cc @Lobot",
  "id" : 515843283118223361,
  "created_at" : "2014-09-27 12:39:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 58, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/czMAIKaTcY",
      "expanded_url" : "http:\/\/kompass.im\/wp-content\/uploads\/2013\/12\/GREGORY-ENGELS-DICHTER-FOTO-by-bartjez-CC-BY-SA-BLOG.jpg",
      "display_url" : "kompass.im\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192560713, 9.4751919521 ]
  },
  "id_str" : "515838755782266881",
  "text" : "Aber es gibt doch schon eine ber\u00FChmte Piraten-Kunstfigur. #om14 http:\/\/t.co\/czMAIKaTcY",
  "id" : 515838755782266881,
  "created_at" : "2014-09-27 12:21:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 86, 99 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/S8BAWW2mWL",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plosone\/PLoSONE\/~3\/QnvAayqJsgg\/info%3Adoi%2F10.1371%2Fjournal.pone.0108425",
      "display_url" : "feeds.plos.org\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.319254, 9.475242 ]
  },
  "id_str" : "515833903278751744",
  "text" : "parallelMCMCcombine: An R Package for Bayesian Methods for Big Data and Analytics \/cc @PhilippBayer  http:\/\/t.co\/S8BAWW2mWL",
  "id" : 515833903278751744,
  "created_at" : "2014-09-27 12:02:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u2726rg Pre\u2726send\u2726rfer",
      "screen_name" : "jpreisendoerfer",
      "indices" : [ 0, 16 ],
      "id_str" : "868852108124196864",
      "id" : 868852108124196864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192588574, 9.4751516691 ]
  },
  "id_str" : "515833169103564800",
  "in_reply_to_user_id" : 234894027,
  "text" : "@jpreisendoerfer sollte wieder gehen. :)",
  "id" : 515833169103564800,
  "created_at" : "2014-09-27 11:59:45 +0000",
  "in_reply_to_screen_name" : "preisendoerferj",
  "in_reply_to_user_id_str" : "234894027",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192692314, 9.4751670655 ]
  },
  "id_str" : "515830881236557824",
  "text" : "\u00ABSorry, aber die Frankfurter Rundschau hat mich versaut.\u00BB \u2013 \u00ABKlar, die FR und nicht \u2018elbow_deep_doublefisting.avi'.\u00BB",
  "id" : 515830881236557824,
  "created_at" : "2014-09-27 11:50:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3184749909, 9.476423654 ]
  },
  "id_str" : "515826729714470912",
  "text" : "\u00ABImmer willst du Spielfilme sehen\u2026 'Lass uns einen Arthouse-Film schauen.'\u2026 Dabei will ich lieber einen Arschhouse-Film sehen!\u00BB #om14",
  "id" : 515826729714470912,
  "created_at" : "2014-09-27 11:34:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515804933074206720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192947466, 9.4755213594 ]
  },
  "id_str" : "515805573628325888",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Hauptsache Bild ;)",
  "id" : 515805573628325888,
  "in_reply_to_status_id" : 515804933074206720,
  "created_at" : "2014-09-27 10:10:06 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 62, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515804803713466368",
  "text" : "\u00ABAuf Twitter sind Screenshots vom Stream. Das hei\u00DFt es geht!\u00BB #om14",
  "id" : 515804803713466368,
  "created_at" : "2014-09-27 10:07:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 6, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/GtyptKlc4L",
      "expanded_url" : "http:\/\/instagram.com\/p\/tcdPSkBwlP\/",
      "display_url" : "instagram.com\/p\/tcdPSkBwlP\/"
    } ]
  },
  "geo" : { },
  "id_str" : "515801519082700800",
  "text" : "L\u00E4uft #om14 http:\/\/t.co\/GtyptKlc4L",
  "id" : 515801519082700800,
  "created_at" : "2014-09-27 09:53:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess-O-Lantern \uD83C\uDF08\uD83D\uDD25",
      "screen_name" : "JessFink",
      "indices" : [ 3, 12 ],
      "id_str" : "13109502",
      "id" : 13109502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515795276981096448",
  "text" : "RT @JessFink: RE: that pic of a guy in a sailor moon sweater with the caption \"hipster final boss\" here's what HE says about it: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/kk1f5dpyCD",
        "expanded_url" : "http:\/\/damianoisfamous.tumblr.com\/post\/83572025089\/excadrill-the-look-so-the-internet-just-gave",
        "display_url" : "damianoisfamous.tumblr.com\/post\/835720250\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "515589289774948353",
    "text" : "RE: that pic of a guy in a sailor moon sweater with the caption \"hipster final boss\" here's what HE says about it: http:\/\/t.co\/kk1f5dpyCD",
    "id" : 515589289774948353,
    "created_at" : "2014-09-26 19:50:40 +0000",
    "user" : {
      "name" : "Jess-O-Lantern \uD83C\uDF08\uD83D\uDD25",
      "screen_name" : "JessFink",
      "protected" : false,
      "id_str" : "13109502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927603781948329984\/mOf0qNHj_normal.jpg",
      "id" : 13109502,
      "verified" : true
    }
  },
  "id" : 515795276981096448,
  "created_at" : "2014-09-27 09:29:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 8, 15 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515788185369321472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192958553, 9.475511051 ]
  },
  "id_str" : "515788338390134786",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 @Seb666 ja, bekommen wir hin :)",
  "id" : 515788338390134786,
  "in_reply_to_status_id" : 515788185369321472,
  "created_at" : "2014-09-27 09:01:37 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515651918782558209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192995587, 9.4754322009 ]
  },
  "id_str" : "515656174952525824",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 immerhin die Piraten hinter mir gelassen ;)",
  "id" : 515656174952525824,
  "in_reply_to_status_id" : 515651918782558209,
  "created_at" : "2014-09-27 00:16:27 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515651191490236416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.31919538, 9.4755348883 ]
  },
  "id_str" : "515651923916386304",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC this years logo is so fitting. ;)",
  "id" : 515651923916386304,
  "in_reply_to_status_id" : 515651191490236416,
  "created_at" : "2014-09-26 23:59:33 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 23, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/haY2p1lC58",
      "expanded_url" : "http:\/\/instagram.com\/p\/tbZFeihwip\/",
      "display_url" : "instagram.com\/p\/tbZFeihwip\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.319388605, 9.475763686 ]
  },
  "id_str" : "515651649676013569",
  "text" : "Setting up the streams #om14 @ Jugendherberge Kassel http:\/\/t.co\/haY2p1lC58",
  "id" : 515651649676013569,
  "created_at" : "2014-09-26 23:58:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/515649164446011392\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/vbKv1BJpgX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Byf0LitCMAAIgdq.jpg",
      "id_str" : "515649161488642048",
      "id" : 515649161488642048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Byf0LitCMAAIgdq.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/vbKv1BJpgX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3191662169, 9.4757697641 ]
  },
  "id_str" : "515649164446011392",
  "text" : "\u00ABWas ist das?! Ein Beamerbild f\u00FCr Ameisen? Das muss mindestens 3x so gro\u00DF sein!\u00BB http:\/\/t.co\/vbKv1BJpgX",
  "id" : 515649164446011392,
  "created_at" : "2014-09-26 23:48:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/515647807005683712\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/KLdR0P6Jeb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Byfy8XfIQAEaGor.jpg",
      "id_str" : "515647801267863553",
      "id" : 515647801267863553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Byfy8XfIQAEaGor.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/KLdR0P6Jeb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515646612304318464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192362977, 9.4754619585 ]
  },
  "id_str" : "515647807005683712",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC at least it was virtually 0 work in the months leading to this. Plus I got a shirt showing my seniority! http:\/\/t.co\/KLdR0P6Jeb",
  "id" : 515647807005683712,
  "in_reply_to_status_id" : 515646612304318464,
  "created_at" : "2014-09-26 23:43:12 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 101, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3193025064, 9.4752576451 ]
  },
  "id_str" : "515645765642125312",
  "text" : "Zum ersten Mal bei einer openmind offiziell nicht Orga sein. So lange aufbauen wie sonst noch nie m) #om14",
  "id" : 515645765642125312,
  "created_at" : "2014-09-26 23:35:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3192962378, 9.4754943918 ]
  },
  "id_str" : "515623404716949504",
  "text" : "\u00ABIch liebe dich, auf allen erdenklichen Ebenen. Das glaubst du gar nicht!\u00BB \u2014 \u00ABWas macht deine Hand in meiner Hose?!\u00BB #om14",
  "id" : 515623404716949504,
  "created_at" : "2014-09-26 22:06:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515539394326192128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1457357363, 8.8074347014 ]
  },
  "id_str" : "515539511296929792",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 danke! ETA momentan 2020",
  "id" : 515539511296929792,
  "in_reply_to_status_id" : 515539394326192128,
  "created_at" : "2014-09-26 16:32:52 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 36, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1457196335, 8.8074451871 ]
  },
  "id_str" : "515539219746664448",
  "text" : "Gepackt \u2714\uFE0FGetankt \u2714\uFE0FAuf dem Weg zur #om14 \u2714\uFE0F",
  "id" : 515539219746664448,
  "created_at" : "2014-09-26 16:31:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515520380828938240",
  "text" : "\u00ABW\u00E4re das sch\u00F6n wenn die Piraten sich aufl\u00F6sen!\u00BB \u2014 \u00ABWir k\u00F6nnen ja S\u00E4ure &amp; Wannen zur #om14 mitnehmen und mit ein paar Piraten anfangen.\u00BB",
  "id" : 515520380828938240,
  "created_at" : "2014-09-26 15:16:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515442559318261760",
  "geo" : { },
  "id_str" : "515442945835937793",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach gibt afaik ein shortcut was man gern mal versehentlich dr\u00FCckt, alt+shift oder so.",
  "id" : 515442945835937793,
  "in_reply_to_status_id" : 515442559318261760,
  "created_at" : "2014-09-26 10:09:09 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/noscatJtQZ",
      "expanded_url" : "http:\/\/instagram.com\/p\/tZsg0chwuw\/",
      "display_url" : "instagram.com\/p\/tZsg0chwuw\/"
    } ]
  },
  "geo" : { },
  "id_str" : "515412894151114752",
  "text" : "Torture http:\/\/t.co\/noscatJtQZ",
  "id" : 515412894151114752,
  "created_at" : "2014-09-26 08:09:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515250280615526401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1112057208, 8.7507582095 ]
  },
  "id_str" : "515251348028555264",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks!",
  "id" : 515251348028555264,
  "in_reply_to_status_id" : 515250280615526401,
  "created_at" : "2014-09-25 21:27:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515249509597585408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1112771428, 8.7498948091 ]
  },
  "id_str" : "515249727781470208",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, should have been signed with my key as well. :)",
  "id" : 515249727781470208,
  "in_reply_to_status_id" : 515249509597585408,
  "created_at" : "2014-09-25 21:21:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515227152997175296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1110603749, 8.753819382 ]
  },
  "id_str" : "515242177614864384",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u05EA\u05D5\u05D3\u05D4 \u05E8\u05D1\u05D4",
  "id" : 515242177614864384,
  "in_reply_to_status_id" : 515227152997175296,
  "created_at" : "2014-09-25 20:51:22 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1113921232, 8.7505746281 ]
  },
  "id_str" : "515241881832554496",
  "text" : "Getting a new phone aka password re-entry time\u2026",
  "id" : 515241881832554496,
  "created_at" : "2014-09-25 20:50:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 101, 107 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/15Cofx6FCc",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plosone\/PLoSONE\/~3\/UbdgY6DDM8s\/info%3Adoi%2F10.1371%2Fjournal.pone.0108099",
      "display_url" : "feeds.plos.org\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172319, 8.627518 ]
  },
  "id_str" : "515112360659660800",
  "text" : "Sperm Competition in Humans: Mate Guarding Behavior Negatively Correlates with Ejaculate Quality \/cc @Lobot  http:\/\/t.co\/15Cofx6FCc",
  "id" : 515112360659660800,
  "created_at" : "2014-09-25 12:15:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515015515907973121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1143222604, 8.753406282 ]
  },
  "id_str" : "515034549664096256",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks! :)",
  "id" : 515034549664096256,
  "in_reply_to_status_id" : 515015515907973121,
  "created_at" : "2014-09-25 07:06:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1109731129, 8.7536642395 ]
  },
  "id_str" : "514849623618621440",
  "text" : "\u00ABBlute mich voll Baby!\u00BB \u2014 \u00ABSp\u00E4ter\u2026\u00BB \u2014 \u00ABOk, dann lass uns L\u00F6cher bohren und dann blute mich voll!\u00BB",
  "id" : 514849623618621440,
  "created_at" : "2014-09-24 18:51:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1153411694, 8.750381465 ]
  },
  "id_str" : "514841077262852096",
  "text" : "\u00ABIch finde ich bin eine bessere Text-Editorin als\u2026\u00BB \u2013 \u00ABvim?!\u00BB",
  "id" : 514841077262852096,
  "created_at" : "2014-09-24 18:17:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1153367977, 8.7503802628 ]
  },
  "id_str" : "514840862023753729",
  "text" : "\u00ABWir sagten \u2018Verschl\u00FCsseln muss einfacher werden\u2019. Das machen nun alle, leider haben wir \u2018Entschl\u00FCsseln muss einfacher werden\u2019 vergessen\u2026\u00BB",
  "id" : 514840862023753729,
  "created_at" : "2014-09-24 18:16:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Harrison",
      "screen_name" : "oldbie",
      "indices" : [ 3, 10 ],
      "id_str" : "803883",
      "id" : 803883
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 26, 42 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 53, 64 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opendata",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Vqr9S4HTbo",
      "expanded_url" : "http:\/\/red.ht\/ZIhjd2",
      "display_url" : "red.ht\/ZIhjd2"
    } ]
  },
  "geo" : { },
  "id_str" : "514790387807186944",
  "text" : "RT @oldbie: I interviewed @gedankenstuecke about the @openSNPorg genetic #opendata project: http:\/\/t.co\/Vqr9S4HTbo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 14, 30 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 41, 52 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opendata",
        "indices" : [ 61, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/Vqr9S4HTbo",
        "expanded_url" : "http:\/\/red.ht\/ZIhjd2",
        "display_url" : "red.ht\/ZIhjd2"
      } ]
    },
    "geo" : { },
    "id_str" : "514785360371412993",
    "text" : "I interviewed @gedankenstuecke about the @openSNPorg genetic #opendata project: http:\/\/t.co\/Vqr9S4HTbo",
    "id" : 514785360371412993,
    "created_at" : "2014-09-24 14:36:08 +0000",
    "user" : {
      "name" : "Michael Harrison",
      "screen_name" : "oldbie",
      "protected" : false,
      "id_str" : "803883",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/424322747821350912\/DAGulM5c_normal.jpeg",
      "id" : 803883,
      "verified" : false
    }
  },
  "id" : 514790387807186944,
  "created_at" : "2014-09-24 14:56:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/os30XkOBgM",
      "expanded_url" : "http:\/\/www.newyorker.com\/tech\/elements\/hacking-breast-pump",
      "display_url" : "newyorker.com\/tech\/elements\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514777009063739392",
  "text" : "Hacking the Breast Pump  http:\/\/t.co\/os30XkOBgM",
  "id" : 514777009063739392,
  "created_at" : "2014-09-24 14:02:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514739985418039297",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1939992582, 8.5915717997 ]
  },
  "id_str" : "514741375045468160",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer right, but the traffic is less the problem than the number of computations we nevertheless want to perform?",
  "id" : 514741375045468160,
  "in_reply_to_status_id" : 514739985418039297,
  "created_at" : "2014-09-24 11:41:21 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514738489288822785",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723539573, 8.6275130527 ]
  },
  "id_str" : "514738621627531264",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer no more research? :p",
  "id" : 514738621627531264,
  "in_reply_to_status_id" : 514738489288822785,
  "created_at" : "2014-09-24 11:30:25 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/7OLmImoKSf",
      "expanded_url" : "http:\/\/feeds.wired.com\/c\/35185\/f\/661470\/s\/3ec6c89a\/sc\/10\/l\/0L0Swired0N0C20A140C0A90Cfantastically0Ewrong0Eeuropes0Einsane0Ehistory0Eputting0Eanimals0Etrial0Eexecuting0C\/story01.htm",
      "display_url" : "feeds.wired.com\/c\/35185\/f\/6614\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514732009173024768",
  "text" : "Fantastically Wrong: Europe\u2019s Insane History of Putting Animals on Trial and Executing Them http:\/\/t.co\/7OLmImoKSf",
  "id" : 514732009173024768,
  "created_at" : "2014-09-24 11:04:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 71, 83 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514701358377623552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172352954, 8.6275423101 ]
  },
  "id_str" : "514701467878703106",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer maybe we should look into this closer before moving. :-) @helgerausch",
  "id" : 514701467878703106,
  "in_reply_to_status_id" : 514701358377623552,
  "created_at" : "2014-09-24 09:02:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 88, 101 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/l0zHfuR3qm",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/EvTps-yjazs\/info%3Adoi%2F10.1371%2Fjournal.pone.0108490",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.174265, 8.624415 ]
  },
  "id_str" : "514701193059520512",
  "text" : "Benchmarking Undedicated Cloud Computing Providers for Analysis of Genomic Datasets \/cc @PhilippBayer  http:\/\/t.co\/l0zHfuR3qm",
  "id" : 514701193059520512,
  "created_at" : "2014-09-24 09:01:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 110, 116 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/gLVoZwJO3t",
      "expanded_url" : "https:\/\/adainitiative.org\/donate\/?campaign=python",
      "display_url" : "adainitiative.org\/donate\/?campai\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723326139, 8.6275548446 ]
  },
  "id_str" : "514693483828084736",
  "text" : "Supported the Ada Initiative. Bioinformaticians: You are allowed to do the same, even if coding in Perl. \/via @tante https:\/\/t.co\/gLVoZwJO3t",
  "id" : 514693483828084736,
  "created_at" : "2014-09-24 08:31:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1785630316, 8.6227942955 ]
  },
  "id_str" : "514682252446666752",
  "text" : "\u00ABDaran wei\u00DF man das man endlich zuhause ist: Die Menschen sind nicht mehr so richtig freundlich zu einem.\u00BB",
  "id" : 514682252446666752,
  "created_at" : "2014-09-24 07:46:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Harrison",
      "screen_name" : "oldbie",
      "indices" : [ 0, 7 ],
      "id_str" : "803883",
      "id" : 803883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514543053223104512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1095342683, 8.7548152268 ]
  },
  "id_str" : "514560170853408768",
  "in_reply_to_user_id" : 803883,
  "text" : "@oldbie thanks for having us!",
  "id" : 514560170853408768,
  "in_reply_to_status_id" : 514543053223104512,
  "created_at" : "2014-09-23 23:41:19 +0000",
  "in_reply_to_screen_name" : "oldbie",
  "in_reply_to_user_id_str" : "803883",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Harrison",
      "screen_name" : "oldbie",
      "indices" : [ 3, 10 ],
      "id_str" : "803883",
      "id" : 803883
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 46, 62 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 68, 79 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opendata",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514558579366690817",
  "text" : "RT @oldbie: Posting an awesome interview with @gedankenstuecke from @openSNPorg tomorrow. I love #opendata projects like this.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 34, 50 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 56, 67 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opendata",
        "indices" : [ 85, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514543053223104512",
    "text" : "Posting an awesome interview with @gedankenstuecke from @openSNPorg tomorrow. I love #opendata projects like this.",
    "id" : 514543053223104512,
    "created_at" : "2014-09-23 22:33:18 +0000",
    "user" : {
      "name" : "Michael Harrison",
      "screen_name" : "oldbie",
      "protected" : false,
      "id_str" : "803883",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/424322747821350912\/DAGulM5c_normal.jpeg",
      "id" : 803883,
      "verified" : false
    }
  },
  "id" : 514558579366690817,
  "created_at" : "2014-09-23 23:35:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Svavar Kn\u00FAtur",
      "screen_name" : "SvavarKnutur",
      "indices" : [ 0, 13 ],
      "id_str" : "74624782",
      "id" : 74624782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1112873779, 8.7498826419 ]
  },
  "id_str" : "514526776060440576",
  "in_reply_to_user_id" : 74624782,
  "text" : "@SvavarKnutur thanks for the nice evening! :)",
  "id" : 514526776060440576,
  "created_at" : "2014-09-23 21:28:37 +0000",
  "in_reply_to_screen_name" : "SvavarKnutur",
  "in_reply_to_user_id_str" : "74624782",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514497997317873665",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.8744049072, 8.6587982178 ]
  },
  "id_str" : "514499750528569344",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich die guten Tipps kommen einfach immer zu sp\u00E4t!",
  "id" : 514499750528569344,
  "in_reply_to_status_id" : 514497997317873665,
  "created_at" : "2014-09-23 19:41:14 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514436622994382849",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.8744509407, 8.6586878835 ]
  },
  "id_str" : "514495151088340993",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich und das sagst du jetzt erst?!",
  "id" : 514495151088340993,
  "in_reply_to_status_id" : 514436622994382849,
  "created_at" : "2014-09-23 19:22:57 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.87563291, 8.6534194242 ]
  },
  "id_str" : "514487946310090752",
  "text" : "\u00ABI know why you are not played on the radio. You are too fat and happy to be Indie!\u00BB",
  "id" : 514487946310090752,
  "created_at" : "2014-09-23 18:54:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.8763308047, 8.6541821779 ]
  },
  "id_str" : "514485903994396673",
  "text" : "\u00ABI really  like the word 'Weltschmerz'. It's the secret ingredient in German beer.\u00BB",
  "id" : 514485903994396673,
  "created_at" : "2014-09-23 18:46:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514406350156476416",
  "text" : "\u00ABThey say I preached revolution. Let me say in my defence that all I did wherever I went was to talk a lot of common sense.\u00BB",
  "id" : 514406350156476416,
  "created_at" : "2014-09-23 13:30:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vince Buffalo",
      "screen_name" : "vsbuffalo",
      "indices" : [ 3, 13 ],
      "id_str" : "62183077",
      "id" : 62183077
    }, {
      "name" : "Hilary Parker",
      "screen_name" : "hspter",
      "indices" : [ 44, 51 ],
      "id_str" : "24228154",
      "id" : 24228154
    }, {
      "name" : "Karl Broman",
      "screen_name" : "kwbroman",
      "indices" : [ 52, 61 ],
      "id_str" : "1237502864",
      "id" : 1237502864
    }, {
      "name" : "Rafael Irizarry",
      "screen_name" : "rafalab",
      "indices" : [ 122, 130 ],
      "id_str" : "177729631",
      "id" : 177729631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "statgen",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514370855166812160",
  "text" : "RT @vsbuffalo: RA Fisher bomb! #statgen RT: @hspter @kwbroman did you see this stellar exchange on simplystats? BOOM from @rafalab http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hilary Parker",
        "screen_name" : "hspter",
        "indices" : [ 29, 36 ],
        "id_str" : "24228154",
        "id" : 24228154
      }, {
        "name" : "Karl Broman",
        "screen_name" : "kwbroman",
        "indices" : [ 37, 46 ],
        "id_str" : "1237502864",
        "id" : 1237502864
      }, {
        "name" : "Rafael Irizarry",
        "screen_name" : "rafalab",
        "indices" : [ 107, 115 ],
        "id_str" : "177729631",
        "id" : 177729631
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hspter\/status\/514241685682155520\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/c8LzRoD9uA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByL0FmSCQAApgsn.png",
        "id_str" : "514241684486373376",
        "id" : 514241684486373376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByL0FmSCQAApgsn.png",
        "sizes" : [ {
          "h" : 742,
          "resize" : "fit",
          "w" : 1398
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 637,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 742,
          "resize" : "fit",
          "w" : 1398
        } ],
        "display_url" : "pic.twitter.com\/c8LzRoD9uA"
      } ],
      "hashtags" : [ {
        "text" : "statgen",
        "indices" : [ 16, 24 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "514241685682155520",
    "geo" : { },
    "id_str" : "514248839306285057",
    "in_reply_to_user_id" : 24228154,
    "text" : "RA Fisher bomb! #statgen RT: @hspter @kwbroman did you see this stellar exchange on simplystats? BOOM from @rafalab http:\/\/t.co\/c8LzRoD9uA",
    "id" : 514248839306285057,
    "in_reply_to_status_id" : 514241685682155520,
    "created_at" : "2014-09-23 03:04:12 +0000",
    "in_reply_to_screen_name" : "hspter",
    "in_reply_to_user_id_str" : "24228154",
    "user" : {
      "name" : "Vince Buffalo",
      "screen_name" : "vsbuffalo",
      "protected" : false,
      "id_str" : "62183077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797204252535857152\/I_Bk8pup_normal.jpg",
      "id" : 62183077,
      "verified" : false
    }
  },
  "id" : 514370855166812160,
  "created_at" : "2014-09-23 11:09:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 87, 92 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514336200266506240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723360371, 8.6275368324 ]
  },
  "id_str" : "514336453095346176",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer and our offices are always open for stranded bioinformaticians, just ask @li5a ;)",
  "id" : 514336453095346176,
  "in_reply_to_status_id" : 514336200266506240,
  "created_at" : "2014-09-23 08:52:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514332079304093696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.177381795, 8.6192612347 ]
  },
  "id_str" : "514332461158121472",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer will be in Berlin from 2.-4. of October, but otherwise I\u2019m around in Frankfurt. I can offer a place to sleep &amp; WiFi.",
  "id" : 514332461158121472,
  "in_reply_to_status_id" : 514332079304093696,
  "created_at" : "2014-09-23 08:36:29 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beatrice Lugger",
      "screen_name" : "BLugger",
      "indices" : [ 3, 11 ],
      "id_str" : "14699615",
      "id" : 14699615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/5ORuOO0L1S",
      "expanded_url" : "http:\/\/www.nature.com\/press_releases\/ncomms-oa.html",
      "display_url" : "nature.com\/press_releases\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514331034989887489",
  "text" : "RT @BLugger: WOW! Nature Communications is going to become fully open access (gold) http:\/\/t.co\/5ORuOO0L1S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/5ORuOO0L1S",
        "expanded_url" : "http:\/\/www.nature.com\/press_releases\/ncomms-oa.html",
        "display_url" : "nature.com\/press_releases\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "514330544650584064",
    "text" : "WOW! Nature Communications is going to become fully open access (gold) http:\/\/t.co\/5ORuOO0L1S",
    "id" : 514330544650584064,
    "created_at" : "2014-09-23 08:28:52 +0000",
    "user" : {
      "name" : "Beatrice Lugger",
      "screen_name" : "BLugger",
      "protected" : false,
      "id_str" : "14699615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664456759243874304\/UGZuDROe_normal.jpg",
      "id" : 14699615,
      "verified" : true
    }
  },
  "id" : 514331034989887489,
  "created_at" : "2014-09-23 08:30:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514329519453249536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723358277, 8.6275192073 ]
  },
  "id_str" : "514329663389564930",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, so feel free to drop by, would love to have a beer with you.",
  "id" : 514329663389564930,
  "in_reply_to_status_id" : 514329519453249536,
  "created_at" : "2014-09-23 08:25:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514325004394065921",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1669221241, 8.6198084965 ]
  },
  "id_str" : "514329235352457216",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer so when will you be in Germany? ;)",
  "id" : 514329235352457216,
  "in_reply_to_status_id" : 514325004394065921,
  "created_at" : "2014-09-23 08:23:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514252232187867136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722746236, 8.6276128781 ]
  },
  "id_str" : "514323185714855936",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ouch!",
  "id" : 514323185714855936,
  "in_reply_to_status_id" : 514252232187867136,
  "created_at" : "2014-09-23 07:59:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514155744569339905",
  "text" : "RT @edyong209: \"To linguists, this is like finding a planet on which matter is made up of molecules that don\u2019t decompose into atoms\" http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/a9IRu1gJ2r",
        "expanded_url" : "http:\/\/nautil.us\/blog\/the-unusual-language-that-linguists-thought-couldnt-exist",
        "display_url" : "nautil.us\/blog\/the-unusu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "514152478708101120",
    "text" : "\"To linguists, this is like finding a planet on which matter is made up of molecules that don\u2019t decompose into atoms\" http:\/\/t.co\/a9IRu1gJ2r",
    "id" : 514152478708101120,
    "created_at" : "2014-09-22 20:41:18 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 514155744569339905,
  "created_at" : "2014-09-22 20:54:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Haaretz.com",
      "screen_name" : "haaretzcom",
      "indices" : [ 3, 14 ],
      "id_str" : "24506246",
      "id" : 24506246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/HFc4ypRzUB",
      "expanded_url" : "http:\/\/htz.li\/kI",
      "display_url" : "htz.li\/kI"
    } ]
  },
  "geo" : { },
  "id_str" : "514154402966671361",
  "text" : "RT @haaretzcom: High Court orders closure of detention facility for African asylum seekers http:\/\/t.co\/HFc4ypRzUB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/HFc4ypRzUB",
        "expanded_url" : "http:\/\/htz.li\/kI",
        "display_url" : "htz.li\/kI"
      } ]
    },
    "geo" : { },
    "id_str" : "514109412265308161",
    "text" : "High Court orders closure of detention facility for African asylum seekers http:\/\/t.co\/HFc4ypRzUB",
    "id" : 514109412265308161,
    "created_at" : "2014-09-22 17:50:10 +0000",
    "user" : {
      "name" : "Haaretz.com",
      "screen_name" : "haaretzcom",
      "protected" : false,
      "id_str" : "24506246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669523420774858753\/Q3O8r8FJ_normal.png",
      "id" : 24506246,
      "verified" : true
    }
  },
  "id" : 514154402966671361,
  "created_at" : "2014-09-22 20:48:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/514131145400025088\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/0Fw1NauvLg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByKPjWmIQAAhITu.jpg",
      "id_str" : "514131144997355520",
      "id" : 514131144997355520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByKPjWmIQAAhITu.jpg",
      "sizes" : [ {
        "h" : 896,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/0Fw1NauvLg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1143984644, 8.7533756451 ]
  },
  "id_str" : "514131145400025088",
  "text" : "What happens if you put me in charge of baking for the vegan conference participants. http:\/\/t.co\/0Fw1NauvLg",
  "id" : 514131145400025088,
  "created_at" : "2014-09-22 19:16:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1141282011, 8.7500489946 ]
  },
  "id_str" : "514113871414820864",
  "text" : "\u00ABIch f\u00FChl mich eigentlich auch nicht schwanger. Bis auf das mit den Nippeln.\u00BB",
  "id" : 514113871414820864,
  "created_at" : "2014-09-22 18:07:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/I1jSn6lbFi",
      "expanded_url" : "http:\/\/www.languageonthemove.com\/language-globalization\/language-work-in-the-internet-cafe",
      "display_url" : "languageonthemove.com\/language-globa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514066863895371776",
  "text" : "Language work in the internet caf\u00E9 http:\/\/t.co\/I1jSn6lbFi",
  "id" : 514066863895371776,
  "created_at" : "2014-09-22 15:01:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724158953, 8.6275431094 ]
  },
  "id_str" : "514047019883982849",
  "text" : "\u00ABDer B\u00E4cker hat sich hinterher bestimmt sehr schmutzig gef\u00FChlt.\u00BB \u2014 \u00ABNaja, wenn da 5 Leute durch den Hintereingang kommen\u2026\u00BB",
  "id" : 514047019883982849,
  "created_at" : "2014-09-22 13:42:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722772188, 8.627614707 ]
  },
  "id_str" : "514045357064749056",
  "text" : "Students commence writing their theses by googling \u2018LaTeX is bullshit\u2019.",
  "id" : 514045357064749056,
  "created_at" : "2014-09-22 13:35:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/eEA7lZ7tj1",
      "expanded_url" : "http:\/\/acko.net\/blog\/the-cargo-cult-of-game-mechanics\/",
      "display_url" : "acko.net\/blog\/the-cargo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723057876, 8.6275985836 ]
  },
  "id_str" : "513997341616259072",
  "text" : "The Cargo Cult of Game Mechanics \u2013 Form without Function http:\/\/t.co\/eEA7lZ7tj1",
  "id" : 513997341616259072,
  "created_at" : "2014-09-22 10:24:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Piper",
      "screen_name" : "piper_jason",
      "indices" : [ 3, 15 ],
      "id_str" : "15256301",
      "id" : 15256301
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/piper_jason\/status\/513972774935986176\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/iXEx3z6Bu4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByH_g9RIEAAf5El.jpg",
      "id_str" : "513972774164238336",
      "id" : 513972774164238336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByH_g9RIEAAf5El.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/iXEx3z6Bu4"
    } ],
    "hashtags" : [ {
      "text" : "gi2014",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513973037763657728",
  "text" : "RT @piper_jason: I'm going to try doing this for all the remaining talks. Such summary. #gi2014 http:\/\/t.co\/iXEx3z6Bu4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/piper_jason\/status\/513972774935986176\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/iXEx3z6Bu4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByH_g9RIEAAf5El.jpg",
        "id_str" : "513972774164238336",
        "id" : 513972774164238336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByH_g9RIEAAf5El.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/iXEx3z6Bu4"
      } ],
      "hashtags" : [ {
        "text" : "gi2014",
        "indices" : [ 71, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513972774935986176",
    "text" : "I'm going to try doing this for all the remaining talks. Such summary. #gi2014 http:\/\/t.co\/iXEx3z6Bu4",
    "id" : 513972774935986176,
    "created_at" : "2014-09-22 08:47:13 +0000",
    "user" : {
      "name" : "Jason Piper",
      "screen_name" : "piper_jason",
      "protected" : false,
      "id_str" : "15256301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3125128890\/80471a53dcd78eb10f96cc05bb0ade9f_normal.jpeg",
      "id" : 15256301,
      "verified" : false
    }
  },
  "id" : 513973037763657728,
  "created_at" : "2014-09-22 08:48:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/x5Qw42BdcD",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=dH573B1bkHI&list=UU3XTzVzaHQEd30rQbuvCtTQ",
      "display_url" : "youtube.com\/watch?v=dH573B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513971432574156800",
  "text" : "Don't Visit Antarctica https:\/\/t.co\/x5Qw42BdcD",
  "id" : 513971432574156800,
  "created_at" : "2014-09-22 08:41:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dang-Anh",
      "screen_name" : "mdanganh",
      "indices" : [ 3, 12 ],
      "id_str" : "34256782",
      "id" : 34256782
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 92, 104 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "linguistics",
      "indices" : [ 45, 57 ]
    }, {
      "text" : "corpusMOOC",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513967531405873152",
  "text" : "RT @mdanganh: If you're interested in corpus #linguistics, there starts an online course by @TonyMcEnery at 29\/9 #corpusMOOC https:\/\/t.co\/Z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tony McEnery",
        "screen_name" : "TonyMcEnery",
        "indices" : [ 78, 90 ],
        "id_str" : "849729062",
        "id" : 849729062
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "linguistics",
        "indices" : [ 31, 43 ]
      }, {
        "text" : "corpusMOOC",
        "indices" : [ 99, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/ZHuHKim9SO",
        "expanded_url" : "https:\/\/www.futurelearn.com\/courses\/corpus-linguistics-2014-q3",
        "display_url" : "futurelearn.com\/courses\/corpus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "513966829820456960",
    "text" : "If you're interested in corpus #linguistics, there starts an online course by @TonyMcEnery at 29\/9 #corpusMOOC https:\/\/t.co\/ZHuHKim9SO",
    "id" : 513966829820456960,
    "created_at" : "2014-09-22 08:23:35 +0000",
    "user" : {
      "name" : "Mark Dang-Anh",
      "screen_name" : "mdanganh",
      "protected" : false,
      "id_str" : "34256782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3404459244\/8c6e70cddf1d6002b1618241e012dff1_normal.jpeg",
      "id" : 34256782,
      "verified" : false
    }
  },
  "id" : 513967531405873152,
  "created_at" : "2014-09-22 08:26:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "indices" : [ 3, 16 ],
      "id_str" : "1891806212",
      "id" : 1891806212
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AcademicsSay\/status\/513494620056334336\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/pmHb4yGUTB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByBMoqtCYAEwcsK.jpg",
      "id_str" : "513494619061903361",
      "id" : 513494619061903361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByBMoqtCYAEwcsK.jpg",
      "sizes" : [ {
        "h" : 320,
        "resize" : "fit",
        "w" : 376
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 376
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 376
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 376
      } ],
      "display_url" : "pic.twitter.com\/pmHb4yGUTB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513965472292012032",
  "text" : "RT @AcademicsSay: Well that escalated quickly. http:\/\/t.co\/pmHb4yGUTB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AcademicsSay\/status\/513494620056334336\/photo\/1",
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/pmHb4yGUTB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByBMoqtCYAEwcsK.jpg",
        "id_str" : "513494619061903361",
        "id" : 513494619061903361,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByBMoqtCYAEwcsK.jpg",
        "sizes" : [ {
          "h" : 320,
          "resize" : "fit",
          "w" : 376
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 376
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 376
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 376
        } ],
        "display_url" : "pic.twitter.com\/pmHb4yGUTB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513494620056334336",
    "text" : "Well that escalated quickly. http:\/\/t.co\/pmHb4yGUTB",
    "id" : 513494620056334336,
    "created_at" : "2014-09-21 01:07:12 +0000",
    "user" : {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "protected" : false,
      "id_str" : "1891806212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748151916836716546\/Ldn_dhiC_normal.jpg",
      "id" : 1891806212,
      "verified" : false
    }
  },
  "id" : 513965472292012032,
  "created_at" : "2014-09-22 08:18:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "God",
      "screen_name" : "TheTweetOfGod",
      "indices" : [ 3, 17 ],
      "id_str" : "204832963",
      "id" : 204832963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513961780310466560",
  "text" : "RT @TheTweetOfGod: WHO LEAKED THIS? WHO THE HELL LEAKED THIS? MY SON\u2019S PRIVACY HAS BEEN VIOLATED! THIS TIME YOU\u2019VE GONE TOO FAR, REDDIT! ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheTweetOfGod\/status\/513864428409094144\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/82L8jnCfJv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByGc-ZAIgAIVF7j.jpg",
        "id_str" : "513864428174213122",
        "id" : 513864428174213122,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByGc-ZAIgAIVF7j.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 1346
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 596
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 1346
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1052
        } ],
        "display_url" : "pic.twitter.com\/82L8jnCfJv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513864428409094144",
    "text" : "WHO LEAKED THIS? WHO THE HELL LEAKED THIS? MY SON\u2019S PRIVACY HAS BEEN VIOLATED! THIS TIME YOU\u2019VE GONE TOO FAR, REDDIT! http:\/\/t.co\/82L8jnCfJv",
    "id" : 513864428409094144,
    "created_at" : "2014-09-22 01:36:41 +0000",
    "user" : {
      "name" : "God",
      "screen_name" : "TheTweetOfGod",
      "protected" : false,
      "id_str" : "204832963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577952058680070144\/6hlNZ0_Y_normal.jpeg",
      "id" : 204832963,
      "verified" : false
    }
  },
  "id" : 513961780310466560,
  "created_at" : "2014-09-22 08:03:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513955528322846721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724521661, 8.627284359 ]
  },
  "id_str" : "513955802802298880",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me danke",
  "id" : 513955802802298880,
  "in_reply_to_status_id" : 513955528322846721,
  "created_at" : "2014-09-22 07:39:46 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513955210512039937",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723825191, 8.6272931021 ]
  },
  "id_str" : "513955321505918976",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me absolut.",
  "id" : 513955321505918976,
  "in_reply_to_status_id" : 513955210512039937,
  "created_at" : "2014-09-22 07:37:52 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513955092488151040",
  "text" : "Es war ja nicht alles schlecht bei den Piraten. Der Online-Austritt ist zum Beispiel ganz bequem.",
  "id" : 513955092488151040,
  "created_at" : "2014-09-22 07:36:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/eOEQIqi8ly",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3488&utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+smbc-comics%2FPvLb+%28Saturday+Morning+Breakfast+Cereal+%28updated+daily%29%29",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513720474942308352",
  "text" : "sounds like fun http:\/\/t.co\/eOEQIqi8ly",
  "id" : 513720474942308352,
  "created_at" : "2014-09-21 16:04:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513714670918959105",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1151885995, 8.7503395083 ]
  },
  "id_str" : "513715525491646464",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC either that or (given the small n just as likely) it\u2019s PEBKAC for the both of us ;)",
  "id" : 513715525491646464,
  "in_reply_to_status_id" : 513714670918959105,
  "created_at" : "2014-09-21 15:45:00 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513713953441329152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1138332393, 8.7531458773 ]
  },
  "id_str" : "513714147985747968",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC ah, of course. The reversal of writing directions also always fucks up my phone.",
  "id" : 513714147985747968,
  "in_reply_to_status_id" : 513713953441329152,
  "created_at" : "2014-09-21 15:39:31 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513713267785863168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1137521444, 8.7528258562 ]
  },
  "id_str" : "513713686234808320",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante bei mir ab dem 26.10. Laufe mit meiner AG beim Staffelmarathon in Frankfurt mit. :)",
  "id" : 513713686234808320,
  "in_reply_to_status_id" : 513713267785863168,
  "created_at" : "2014-09-21 15:37:41 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513708538720702464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1135159932, 8.751260859 ]
  },
  "id_str" : "513713034741944320",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante das erkl\u00E4rt wieso ich seit einiger Zeit no dice im Fitbit-Ranking hab. Viel Erfolg!",
  "id" : 513713034741944320,
  "in_reply_to_status_id" : 513708538720702464,
  "created_at" : "2014-09-21 15:35:06 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/1Bq6QSAhsf",
      "expanded_url" : "http:\/\/de.m.wikipedia.org\/wiki\/Zatar_(Gew%C3%BCrzmischung)",
      "display_url" : "de.m.wikipedia.org\/wiki\/Zatar_(Ge\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "513432728961024000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1114361392, 8.7501441086 ]
  },
  "id_str" : "513433444924522496",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC there's always Google. ;) http:\/\/t.co\/1Bq6QSAhsf",
  "id" : 513433444924522496,
  "in_reply_to_status_id" : 513432728961024000,
  "created_at" : "2014-09-20 21:04:07 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513411446651490304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1112767571, 8.749875232 ]
  },
  "id_str" : "513412191643770880",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I was, but I just had Halloumi with lots of \u05D6\u05E2\u05EA\u05E8. Nom :)",
  "id" : 513412191643770880,
  "in_reply_to_status_id" : 513411446651490304,
  "created_at" : "2014-09-20 19:39:39 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FAZ Feuilleton",
      "screen_name" : "FAZ_Feuilleton",
      "indices" : [ 3, 18 ],
      "id_str" : "24277906",
      "id" : 24277906
    }, {
      "name" : "Billy Bragg",
      "screen_name" : "billybragg",
      "indices" : [ 75, 86 ],
      "id_str" : "13496142",
      "id" : 13496142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513411559541198848",
  "text" : "RT @FAZ_Feuilleton: Statt mit seiner Gitarre vor ihnen aufzutreten, dr\u00FCckt @billybragg den H\u00E4ftlingen Instrumente in die Hand http:\/\/t.co\/i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.faz.net\" rel=\"nofollow\"\u003EFAZ.NET\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Billy Bragg",
        "screen_name" : "billybragg",
        "indices" : [ 55, 66 ],
        "id_str" : "13496142",
        "id" : 13496142
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/iFKSuHcnRY",
        "expanded_url" : "http:\/\/www.faz.net\/aktuell\/feuilleton\/pop\/resozialisierung-von-haeftlingen-mit-gitarren-13162797.html",
        "display_url" : "faz.net\/aktuell\/feuill\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "513383385465901057",
    "text" : "Statt mit seiner Gitarre vor ihnen aufzutreten, dr\u00FCckt @billybragg den H\u00E4ftlingen Instrumente in die Hand http:\/\/t.co\/iFKSuHcnRY",
    "id" : 513383385465901057,
    "created_at" : "2014-09-20 17:45:11 +0000",
    "user" : {
      "name" : "FAZ Feuilleton",
      "screen_name" : "FAZ_Feuilleton",
      "protected" : false,
      "id_str" : "24277906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477440728142843904\/eVs4Hqwm_normal.jpeg",
      "id" : 24277906,
      "verified" : true
    }
  },
  "id" : 513411559541198848,
  "created_at" : "2014-09-20 19:37:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 7, 14 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513377024279601152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1141204834, 8.7500457764 ]
  },
  "id_str" : "513377179116515328",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @lsanoj bald kann ich \u201EF\u00FCr sie immer noch Dr. Panda!\u201C sagen.",
  "id" : 513377179116515328,
  "in_reply_to_status_id" : 513377024279601152,
  "created_at" : "2014-09-20 17:20:32 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 7, 14 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513376547685011456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1141204837, 8.7500457764 ]
  },
  "id_str" : "513376680455716864",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @lsanoj h\u00E4ng deiner Bewerbung das Foto von mir im Panda-Look an, dann wirst du sicher genommen.",
  "id" : 513376680455716864,
  "in_reply_to_status_id" : 513376547685011456,
  "created_at" : "2014-09-20 17:18:33 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513375345073209345",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1141210786, 8.7500459401 ]
  },
  "id_str" : "513375724234104832",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot safe travels!",
  "id" : 513375724234104832,
  "in_reply_to_status_id" : 513375345073209345,
  "created_at" : "2014-09-20 17:14:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. NerdLove",
      "screen_name" : "DrNerdLove",
      "indices" : [ 3, 14 ],
      "id_str" : "265636267",
      "id" : 265636267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513375511402512385",
  "text" : "RT @DrNerdLove: Well this is fucking horrifying. PUA guru sees dating tips in a chart designed to highlight abusive behavior\u2026 http:\/\/t.co\/9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/9AtI2EOUvH",
        "expanded_url" : "http:\/\/wehuntedthemammoth.com\/2014\/09\/20\/youll-be-horrified-to-learn-where-one-popular-pickup-guru-has-found-what-he-claims-are-useful-dating-tips\/",
        "display_url" : "wehuntedthemammoth.com\/2014\/09\/20\/you\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "513352763217313792",
    "text" : "Well this is fucking horrifying. PUA guru sees dating tips in a chart designed to highlight abusive behavior\u2026 http:\/\/t.co\/9AtI2EOUvH",
    "id" : 513352763217313792,
    "created_at" : "2014-09-20 15:43:31 +0000",
    "user" : {
      "name" : "Dr. NerdLove",
      "screen_name" : "DrNerdLove",
      "protected" : false,
      "id_str" : "265636267",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682434654708826112\/X8ovg84O_normal.jpg",
      "id" : 265636267,
      "verified" : true
    }
  },
  "id" : 513375511402512385,
  "created_at" : "2014-09-20 17:13:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 3, 17 ],
      "id_str" : "15154811",
      "id" : 15154811
    }, {
      "name" : "Nature Methods",
      "screen_name" : "naturemethods",
      "indices" : [ 41, 55 ],
      "id_str" : "264399952",
      "id" : 264399952
    }, {
      "name" : "Marc Facciotti",
      "screen_name" : "saltyprof",
      "indices" : [ 117, 127 ],
      "id_str" : "308040413",
      "id" : 308040413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513368598786887680",
  "text" : "RT @phylogenomics: Hmm: print version of @naturemethods papers don't actually have methods sections; pics &amp; h\/t: @saltyprof http:\/\/t.co\/NIV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nature Methods",
        "screen_name" : "naturemethods",
        "indices" : [ 22, 36 ],
        "id_str" : "264399952",
        "id" : 264399952
      }, {
        "name" : "Marc Facciotti",
        "screen_name" : "saltyprof",
        "indices" : [ 98, 108 ],
        "id_str" : "308040413",
        "id" : 308040413
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/phylogenomics\/status\/513354935660847104\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/NIV2EAdGKA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx_Nl9_CYAAYFmw.jpg",
        "id_str" : "513354934721339392",
        "id" : 513354934721339392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx_Nl9_CYAAYFmw.jpg",
        "sizes" : [ {
          "h" : 1245,
          "resize" : "fit",
          "w" : 1890
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 790,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1245,
          "resize" : "fit",
          "w" : 1890
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/NIV2EAdGKA"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/phylogenomics\/status\/513354935660847104\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/NIV2EAdGKA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx_Nll3CEAAVpg-.jpg",
        "id_str" : "513354928245313536",
        "id" : 513354928245313536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx_Nll3CEAAVpg-.jpg",
        "sizes" : [ {
          "h" : 637,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 637,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 212,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/NIV2EAdGKA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513354935660847104",
    "text" : "Hmm: print version of @naturemethods papers don't actually have methods sections; pics &amp; h\/t: @saltyprof http:\/\/t.co\/NIV2EAdGKA",
    "id" : 513354935660847104,
    "created_at" : "2014-09-20 15:52:09 +0000",
    "user" : {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "protected" : false,
      "id_str" : "15154811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751288576403382273\/AKfTiFxx_normal.jpg",
      "id" : 15154811,
      "verified" : true
    }
  },
  "id" : 513368598786887680,
  "created_at" : "2014-09-20 16:46:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Till Zimmermann",
      "screen_name" : "tillzz",
      "indices" : [ 0, 7 ],
      "id_str" : "18678858",
      "id" : 18678858
    }, {
      "name" : "Lars Reineke",
      "screen_name" : "larsreineke",
      "indices" : [ 8, 20 ],
      "id_str" : "6338182",
      "id" : 6338182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513339517693362176",
  "geo" : { },
  "id_str" : "513358301858631680",
  "in_reply_to_user_id" : 18678858,
  "text" : "@tillzz @larsreineke Sehr sch\u00F6n, f\u00FCr mich als Vegetarier auch besonders passend. ;)",
  "id" : 513358301858631680,
  "in_reply_to_status_id" : 513339517693362176,
  "created_at" : "2014-09-20 16:05:31 +0000",
  "in_reply_to_screen_name" : "tillzz",
  "in_reply_to_user_id_str" : "18678858",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1138654858, 8.6836695252 ]
  },
  "id_str" : "513335607935111169",
  "text" : "Verlesen bei der Fitbitnotificatiom: 'Geschafft! Du hast dein Schnitzel f\u00FCr heute erreicht.\u00BB",
  "id" : 513335607935111169,
  "created_at" : "2014-09-20 14:35:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/k4IfRWpWzf",
      "expanded_url" : "http:\/\/instagram.com\/p\/tKuZMMBwsn\/",
      "display_url" : "instagram.com\/p\/tKuZMMBwsn\/"
    } ]
  },
  "geo" : { },
  "id_str" : "513305967766036480",
  "text" : "Unser gut sortiertes B\u00FCcherregal: von 'Liebe Radikal' bis zu 'Welcher Pilz ist das?' http:\/\/t.co\/k4IfRWpWzf",
  "id" : 513305967766036480,
  "created_at" : "2014-09-20 12:37:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Shumway",
      "screen_name" : "alcest",
      "indices" : [ 0, 7 ],
      "id_str" : "481115527",
      "id" : 481115527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513276889604296704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.111433755, 8.750140784 ]
  },
  "id_str" : "513279659866611712",
  "in_reply_to_user_id" : 481115527,
  "text" : "@alcest ist halt relativ viel Grundlagen in Informatik was ich so von meinen Studis mitbekomme.",
  "id" : 513279659866611712,
  "in_reply_to_status_id" : 513276889604296704,
  "created_at" : "2014-09-20 10:53:01 +0000",
  "in_reply_to_screen_name" : "alcest",
  "in_reply_to_user_id_str" : "481115527",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Shumway",
      "screen_name" : "alcest",
      "indices" : [ 0, 7 ],
      "id_str" : "481115527",
      "id" : 481115527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513276889604296704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1114024959, 8.7502321856 ]
  },
  "id_str" : "513279574193758208",
  "in_reply_to_user_id" : 481115527,
  "text" : "@alcest dann w\u00FCrde ich mir mal anschauen was f\u00FCr Kurse der Bioinformatik-Studiengang in Frankfurt hat und ob das was ist.",
  "id" : 513279574193758208,
  "in_reply_to_status_id" : 513276889604296704,
  "created_at" : "2014-09-20 10:52:41 +0000",
  "in_reply_to_screen_name" : "alcest",
  "in_reply_to_user_id_str" : "481115527",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Shumway",
      "screen_name" : "alcest",
      "indices" : [ 0, 7 ],
      "id_str" : "481115527",
      "id" : 481115527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513249502107795456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1112823486, 8.7498626709 ]
  },
  "id_str" : "513251145847173120",
  "in_reply_to_user_id" : 481115527,
  "text" : "@alcest dann vielleicht lieber nur Bio studieren? ;)",
  "id" : 513251145847173120,
  "in_reply_to_status_id" : 513249502107795456,
  "created_at" : "2014-09-20 08:59:43 +0000",
  "in_reply_to_screen_name" : "alcest",
  "in_reply_to_user_id_str" : "481115527",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513245659567095808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1123537473, 8.7502224838 ]
  },
  "id_str" : "513245899095830528",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer too bad :(",
  "id" : 513245899095830528,
  "in_reply_to_status_id" : 513245659567095808,
  "created_at" : "2014-09-20 08:38:52 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513244812493873153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096486662, 8.2829879132 ]
  },
  "id_str" : "513245335712694273",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer where did you find the data?",
  "id" : 513245335712694273,
  "in_reply_to_status_id" : 513244812493873153,
  "created_at" : "2014-09-20 08:36:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513243043680772096",
  "text" : "RT @SnarkyMinion: Went back to the office because I Don't know what else to do with myself.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513141959339544576",
    "text" : "Went back to the office because I Don't know what else to do with myself.",
    "id" : 513141959339544576,
    "created_at" : "2014-09-20 01:45:51 +0000",
    "user" : {
      "name" : "Witty Academic",
      "screen_name" : "WittyAcademic_",
      "protected" : false,
      "id_str" : "2329396697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/888827296609689605\/svOmBDRL_normal.jpg",
      "id" : 2329396697,
      "verified" : false
    }
  },
  "id" : 513243043680772096,
  "created_at" : "2014-09-20 08:27:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/mdBXrDRJI6",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=-K4s7cV4Us4",
      "display_url" : "m.youtube.com\/watch?v=-K4s7c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1114160119, 8.750102372 ]
  },
  "id_str" : "513108443620999168",
  "text" : "Are Video Games Sexist? https:\/\/t.co\/mdBXrDRJI6",
  "id" : 513108443620999168,
  "created_at" : "2014-09-19 23:32:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Shumway",
      "screen_name" : "alcest",
      "indices" : [ 0, 7 ],
      "id_str" : "481115527",
      "id" : 481115527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513092677509062657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1113078918, 8.7497075006 ]
  },
  "id_str" : "513103819585384448",
  "in_reply_to_user_id" : 481115527,
  "text" : "@alcest und je nachdem wie viel Informatik du schon kennst ist der Informatik-Teil des Studiums dann eventuell \u00F6de f\u00FCr dich.",
  "id" : 513103819585384448,
  "in_reply_to_status_id" : 513092677509062657,
  "created_at" : "2014-09-19 23:14:18 +0000",
  "in_reply_to_screen_name" : "alcest",
  "in_reply_to_user_id_str" : "481115527",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Shumway",
      "screen_name" : "alcest",
      "indices" : [ 0, 7 ],
      "id_str" : "481115527",
      "id" : 481115527
    }, {
      "name" : "Sir Beef-A-Lot \uD83C\uDDE9\uD83C\uDDEA\uD83D\uDD1C\uD83C\uDDEF\uD83C\uDDF5",
      "screen_name" : "FreXxX",
      "indices" : [ 17, 24 ],
      "id_str" : "22941893",
      "id" : 22941893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513092677509062657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1113078918, 8.7497075006 ]
  },
  "id_str" : "513103588592066560",
  "in_reply_to_user_id" : 481115527,
  "text" : "@alcest also der @FreXxX hat den Bachelor mal in Frankfurt angefangen.",
  "id" : 513103588592066560,
  "in_reply_to_status_id" : 513092677509062657,
  "created_at" : "2014-09-19 23:13:23 +0000",
  "in_reply_to_screen_name" : "alcest",
  "in_reply_to_user_id_str" : "481115527",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Shumway",
      "screen_name" : "alcest",
      "indices" : [ 0, 7 ],
      "id_str" : "481115527",
      "id" : 481115527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513090763862065152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1113463957, 8.7497309707 ]
  },
  "id_str" : "513091842645458944",
  "in_reply_to_user_id" : 481115527,
  "text" : "@alcest wie kann man denn helfen?",
  "id" : 513091842645458944,
  "in_reply_to_status_id" : 513090763862065152,
  "created_at" : "2014-09-19 22:26:42 +0000",
  "in_reply_to_screen_name" : "alcest",
  "in_reply_to_user_id_str" : "481115527",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Shumway",
      "screen_name" : "alcest",
      "indices" : [ 0, 7 ],
      "id_str" : "481115527",
      "id" : 481115527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513090763862065152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1113463957, 8.7497309707 ]
  },
  "id_str" : "513091786383048704",
  "in_reply_to_user_id" : 481115527,
  "text" : "@alcest ich hab gar nicht Bioinformatik studiert sondern \u00D6kologie und Evolution. Bin jetzt aber in der Bioinformatik f\u00FCr den PhD.",
  "id" : 513091786383048704,
  "in_reply_to_status_id" : 513090763862065152,
  "created_at" : "2014-09-19 22:26:29 +0000",
  "in_reply_to_screen_name" : "alcest",
  "in_reply_to_user_id_str" : "481115527",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 7, 18 ],
      "id_str" : "28090494",
      "id" : 28090494
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 19, 28 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "@zeitweise",
      "screen_name" : "zeitweise",
      "indices" : [ 29, 39 ],
      "id_str" : "15494684",
      "id" : 15494684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513059589974405120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1141204834, 8.7500457764 ]
  },
  "id_str" : "513060056804626433",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ @herrurbach @Senficon @zeitweise mea culpa, mea maxima culpa.",
  "id" : 513060056804626433,
  "in_reply_to_status_id" : 513059589974405120,
  "created_at" : "2014-09-19 20:20:24 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513050973862764544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1141967745, 8.7500667564 ]
  },
  "id_str" : "513051827211091968",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez haha, I know that problem. :) Well done in any case!",
  "id" : 513051827211091968,
  "in_reply_to_status_id" : 513050973862764544,
  "created_at" : "2014-09-19 19:47:42 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513050336257269760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.115340591, 8.7503813059 ]
  },
  "id_str" : "513050778492477440",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez but maybe I\u2019m totally biased because I love plotting data so much :)",
  "id" : 513050778492477440,
  "in_reply_to_status_id" : 513050336257269760,
  "created_at" : "2014-09-19 19:43:32 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513050336257269760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.115340591, 8.7503813059 ]
  },
  "id_str" : "513050722393677824",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez i see. Alternatively you could just do a scatterplot with the 7 days on the x-axis. That could be pretty intuitive.",
  "id" : 513050722393677824,
  "in_reply_to_status_id" : 513050336257269760,
  "created_at" : "2014-09-19 19:43:18 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513049794567090176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1141204845, 8.7500457767 ]
  },
  "id_str" : "513050061262311424",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez you will be in no time! (And it would be really easy to do it with R ;))",
  "id" : 513050061262311424,
  "in_reply_to_status_id" : 513049794567090176,
  "created_at" : "2014-09-19 19:40:41 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513048746486018048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1141204845, 8.7500457767 ]
  },
  "id_str" : "513049502295785472",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez personally I would try doing a boxplot for the 7 days, so you take variability into account.",
  "id" : 513049502295785472,
  "in_reply_to_status_id" : 513048746486018048,
  "created_at" : "2014-09-19 19:38:28 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513048746486018048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1141206311, 8.750045817 ]
  },
  "id_str" : "513048982449573888",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez yes, though I'm still kind of unhappy about the comparison in the lower right, the censored y-axis makes it look overly dramatic.",
  "id" : 513048982449573888,
  "in_reply_to_status_id" : 513048746486018048,
  "created_at" : "2014-09-19 19:36:24 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513047627295100928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1142730569, 8.7500877347 ]
  },
  "id_str" : "513048675657187328",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 win-win!",
  "id" : 513048675657187328,
  "in_reply_to_status_id" : 513047627295100928,
  "created_at" : "2014-09-19 19:35:10 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513047071469748224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1151809401, 8.7503798743 ]
  },
  "id_str" : "513047205838880769",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez i already wanted to complain ;)",
  "id" : 513047205838880769,
  "in_reply_to_status_id" : 513047071469748224,
  "created_at" : "2014-09-19 19:29:20 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 41, 52 ],
      "id_str" : "28090494",
      "id" : 28090494
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 53, 62 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "@zeitweise",
      "screen_name" : "zeitweise",
      "indices" : [ 63, 73 ],
      "id_str" : "15494684",
      "id" : 15494684
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om14",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1135638031, 8.7529796641 ]
  },
  "id_str" : "513046695354318848",
  "text" : "So, \u201E\u00DCberparteilich\u201C endg\u00FCltig erreicht, @herrurbach @Senficon @zeitweise &amp; ich k\u00F6nnen uns mit Recht auf die Schultern klopfen. #om14",
  "id" : 513046695354318848,
  "created_at" : "2014-09-19 19:27:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/QkWr80rVxh",
      "expanded_url" : "https:\/\/twitter.com\/openmindkonf\/status\/513034627343478784",
      "display_url" : "twitter.com\/openmindkonf\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1135638031, 8.7529796641 ]
  },
  "id_str" : "513045602444533760",
  "text" : "Damit ist dann der Weg frei f\u00FCr die Unabh\u00E4ngigkeitserkl\u00E4rung der openmind. Die Kleinen werden so schnell erwachsen! https:\/\/t.co\/QkWr80rVxh",
  "id" : 513045602444533760,
  "created_at" : "2014-09-19 19:22:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 3, 12 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BuzzFeed\/status\/512987409798422528\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/wfoqg3OcQz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx5_VJrIUAEKD4h.png",
      "id_str" : "512987408917614593",
      "id" : 512987408917614593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx5_VJrIUAEKD4h.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/wfoqg3OcQz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/uFQ6bbG2GD",
      "expanded_url" : "http:\/\/bzfd.it\/1uNUXl6",
      "display_url" : "bzfd.it\/1uNUXl6"
    } ]
  },
  "geo" : { },
  "id_str" : "513015978331238400",
  "text" : "RT @BuzzFeed: 14 Things You Might Not Know About How Women Watch Porn\nhttp:\/\/t.co\/uFQ6bbG2GD http:\/\/t.co\/wfoqg3OcQz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BuzzFeed\/status\/512987409798422528\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/wfoqg3OcQz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx5_VJrIUAEKD4h.png",
        "id_str" : "512987408917614593",
        "id" : 512987408917614593,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx5_VJrIUAEKD4h.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/wfoqg3OcQz"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/uFQ6bbG2GD",
        "expanded_url" : "http:\/\/bzfd.it\/1uNUXl6",
        "display_url" : "bzfd.it\/1uNUXl6"
      } ]
    },
    "geo" : { },
    "id_str" : "512987409798422528",
    "text" : "14 Things You Might Not Know About How Women Watch Porn\nhttp:\/\/t.co\/uFQ6bbG2GD http:\/\/t.co\/wfoqg3OcQz",
    "id" : 512987409798422528,
    "created_at" : "2014-09-19 15:31:44 +0000",
    "user" : {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "protected" : false,
      "id_str" : "5695632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687767655214891008\/n9pHVYUl_normal.png",
      "id" : 5695632,
      "verified" : true
    }
  },
  "id" : 513015978331238400,
  "created_at" : "2014-09-19 17:25:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/gSUaw2exh6",
      "expanded_url" : "http:\/\/isisthescientist.com\/2014\/09\/19\/science-has-a-thomas-jefferson-problem\/",
      "display_url" : "isisthescientist.com\/2014\/09\/19\/sci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513000163208884225",
  "text" : "\u00ABWhat we need to do is knock down the narrative that academia is an enlightened, safe place\u00BB http:\/\/t.co\/gSUaw2exh6",
  "id" : 513000163208884225,
  "created_at" : "2014-09-19 16:22:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bioinformatics",
      "indices" : [ 77, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/JgX9mSaS14",
      "expanded_url" : "http:\/\/www.bio.uni-frankfurt.de\/47481454\/open-positions",
      "display_url" : "bio.uni-frankfurt.de\/47481454\/open-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512993385364611073",
  "text" : "You want to play mad scientist with me and like genome mangling? We have two #bioinformatics PhD student positions http:\/\/t.co\/JgX9mSaS14",
  "id" : 512993385364611073,
  "created_at" : "2014-09-19 15:55:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512962021944745984",
  "text" : "The Star Trek Voyager theme is blasting through our offices. Now I wonder whether our data is lost in the Delta Quadrant.",
  "id" : 512962021944745984,
  "created_at" : "2014-09-19 13:50:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "indices" : [ 3, 12 ],
      "id_str" : "2442015493",
      "id" : 2442015493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512961799621455872",
  "text" : "RT @LGBTSTEM: The first step to visibility for LGBT+ in STEM is proving we exist. Tell us where you work and go on the map. https:\/\/t.co\/p1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/p10T10mRp5",
        "expanded_url" : "https:\/\/www.google.com\/maps\/d\/viewer?mid=zVWbAYzQncF4.kA4aADlRJYl0",
        "display_url" : "google.com\/maps\/d\/viewer?\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "512946068716142592",
    "text" : "The first step to visibility for LGBT+ in STEM is proving we exist. Tell us where you work and go on the map. https:\/\/t.co\/p10T10mRp5",
    "id" : 512946068716142592,
    "created_at" : "2014-09-19 12:47:27 +0000",
    "user" : {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "protected" : false,
      "id_str" : "2442015493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685082380223295488\/XGTcyfxo_normal.jpg",
      "id" : 2442015493,
      "verified" : false
    }
  },
  "id" : 512961799621455872,
  "created_at" : "2014-09-19 13:49:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/zeWVbwsXs3",
      "expanded_url" : "http:\/\/www.wired.com\/2014\/09\/absurd-creature-of-the-week-disco-worm\/",
      "display_url" : "wired.com\/2014\/09\/absurd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512940592582914048",
  "text" : "The Parasitic Worm That Turns Snails Into Disco Zombies http:\/\/t.co\/zeWVbwsXs3",
  "id" : 512940592582914048,
  "created_at" : "2014-09-19 12:25:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Smith",
      "screen_name" : "theotherdrsmith",
      "indices" : [ 3, 19 ],
      "id_str" : "1561888556",
      "id" : 1561888556
    }, {
      "name" : "Hope Jahren",
      "screen_name" : "HopeJahren",
      "indices" : [ 38, 49 ],
      "id_str" : "322658299",
      "id" : 322658299
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 52, 60 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512926756576460800",
  "text" : "RT @theotherdrsmith: You need to read @HopeJahren's @nytimes piece. Because this has got to stop, and men in science have got to stop it ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hope Jahren",
        "screen_name" : "HopeJahren",
        "indices" : [ 17, 28 ],
        "id_str" : "322658299",
        "id" : 322658299
      }, {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 31, 39 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/MCv1IXStFu",
        "expanded_url" : "http:\/\/www.nytimes.com\/2014\/09\/20\/opinion\/science-has-a-sexual-assault-problem.html",
        "display_url" : "nytimes.com\/2014\/09\/20\/opi\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "512718562721411073",
    "geo" : { },
    "id_str" : "512750235190177793",
    "in_reply_to_user_id" : 322658299,
    "text" : "You need to read @HopeJahren's @nytimes piece. Because this has got to stop, and men in science have got to stop it http:\/\/t.co\/MCv1IXStFu",
    "id" : 512750235190177793,
    "in_reply_to_status_id" : 512718562721411073,
    "created_at" : "2014-09-18 23:49:17 +0000",
    "in_reply_to_screen_name" : "HopeJahren",
    "in_reply_to_user_id_str" : "322658299",
    "user" : {
      "name" : "Dr Smith",
      "screen_name" : "theotherdrsmith",
      "protected" : false,
      "id_str" : "1561888556",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579188334540427264\/GaIpEbR6_normal.jpg",
      "id" : 1561888556,
      "verified" : false
    }
  },
  "id" : 512926756576460800,
  "created_at" : "2014-09-19 11:30:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 7, 14 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 15, 24 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512901049292963840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723183039, 8.6275256186 ]
  },
  "id_str" : "512901314062610433",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Seb666 @JP_Stich ich bin halt so hei\u00DF das ich mich intern k\u00FChlen muss!",
  "id" : 512901314062610433,
  "in_reply_to_status_id" : 512901049292963840,
  "created_at" : "2014-09-19 09:49:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 15, 24 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512899981800636416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723183039, 8.6275256186 ]
  },
  "id_str" : "512900922260074496",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 @Lobot @JP_Stich zumindest wenn man es als Hauptnahrungsmittel verwendet so wie ich.",
  "id" : 512900922260074496,
  "in_reply_to_status_id" : 512899981800636416,
  "created_at" : "2014-09-19 09:48:03 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 7, 14 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 15, 24 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512898837640667136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723186172, 8.6275255724 ]
  },
  "id_str" : "512899425338138624",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Seb666 @JP_Stich ja, dabei h\u00E4tte man von dem Geld bestimmt ca. 3 Eis bezahlen k\u00F6nnen!",
  "id" : 512899425338138624,
  "in_reply_to_status_id" : 512898837640667136,
  "created_at" : "2014-09-19 09:42:06 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 10, 17 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 18, 24 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512898420458397696",
  "geo" : { },
  "id_str" : "512898534275026944",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Seb666 @Lobot \u201CLenkrad\u201D",
  "id" : 512898534275026944,
  "in_reply_to_status_id" : 512898420458397696,
  "created_at" : "2014-09-19 09:38:34 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 15, 24 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512898238807289856",
  "geo" : { },
  "id_str" : "512898447083843584",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 @Lobot @JP_Stich ja, weil ich bei unserer Reisegeschwindigkeit beide H\u00E4nde am Lenkrad haben wollte.",
  "id" : 512898447083843584,
  "in_reply_to_status_id" : 512898238807289856,
  "created_at" : "2014-09-19 09:38:13 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 15, 24 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512897761214464000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723270001, 8.6275512984 ]
  },
  "id_str" : "512898127578550272",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 @Lobot @JP_Stich das sagen auch nur Leute die von der Truppe nicht 250\u20AC abgenommen bekommen haben! ;)",
  "id" : 512898127578550272,
  "in_reply_to_status_id" : 512897761214464000,
  "created_at" : "2014-09-19 09:36:57 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cleese",
      "screen_name" : "JohnCleese",
      "indices" : [ 3, 14 ],
      "id_str" : "10810102",
      "id" : 10810102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512897706252316672",
  "text" : "RT @JohnCleese: The DM reminds its readers yet again that I have been married a lot.I would like to remind them that during the 30s,the DM \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512893877972656128",
    "text" : "The DM reminds its readers yet again that I have been married a lot.I would like to remind them that during the 30s,the DM supported Hitler",
    "id" : 512893877972656128,
    "created_at" : "2014-09-19 09:20:04 +0000",
    "user" : {
      "name" : "John Cleese",
      "screen_name" : "JohnCleese",
      "protected" : false,
      "id_str" : "10810102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2622284361\/1emzqsaz3t5glbyndf66_normal.jpeg",
      "id" : 10810102,
      "verified" : true
    }
  },
  "id" : 512897706252316672,
  "created_at" : "2014-09-19 09:35:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/sMN0BIVf5L",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/neuroskeptic\/2014\/09\/18\/coffee-drinkers-emotions-alexithymia\/#.VBvwsGSSzFc",
      "display_url" : "blogs.discovermagazine.com\/neuroskeptic\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512893111283249153",
  "text" : "\u00ABMaybe neurotic people don\u2019t drink more coffee, they just worry about drinking coffee more.\u00BB http:\/\/t.co\/sMN0BIVf5L",
  "id" : 512893111283249153,
  "created_at" : "2014-09-19 09:17:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/ScJEzQF4wN",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0102078",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512890573406339072",
  "text" : "Personality Effects on Romantic Relationship Quality through Friendship Quality http:\/\/t.co\/ScJEzQF4wN",
  "id" : 512890573406339072,
  "created_at" : "2014-09-19 09:06:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722775417, 8.6276141715 ]
  },
  "id_str" : "512882425245224961",
  "text" : "'No disk space left on device' \u2014 I guess we can call it an early weekend.",
  "id" : 512882425245224961,
  "created_at" : "2014-09-19 08:34:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/LqC2i4vkJ1",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0105920",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512874903289475072",
  "text" : "RT @PhilippBayer: 'Revisiting Herodotus's Theory on the Origin of the Etruscans' using genomic data http:\/\/t.co\/LqC2i4vkJ1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/LqC2i4vkJ1",
        "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0105920",
        "display_url" : "plosone.org\/article\/info%3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "512827314426486784",
    "text" : "'Revisiting Herodotus's Theory on the Origin of the Etruscans' using genomic data http:\/\/t.co\/LqC2i4vkJ1",
    "id" : 512827314426486784,
    "created_at" : "2014-09-19 04:55:34 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 512874903289475072,
  "created_at" : "2014-09-19 08:04:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/8VdtjX4G1X",
      "expanded_url" : "http:\/\/instagram.com\/p\/tHj2GUBwkH\/",
      "display_url" : "instagram.com\/p\/tHj2GUBwkH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "512860560082231296",
  "text" : "Late Breakfast http:\/\/t.co\/8VdtjX4G1X",
  "id" : 512860560082231296,
  "created_at" : "2014-09-19 07:07:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    }, {
      "name" : "alios",
      "screen_name" : "alios",
      "indices" : [ 12, 18 ],
      "id_str" : "16309072",
      "id" : 16309072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512703749601521664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1125113947, 8.7493904432 ]
  },
  "id_str" : "512727931248840705",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen @alios in unserem Wohnzimmer sieht es dazu passend auch gerade nach Kiss Behind The Barricades aus.",
  "id" : 512727931248840705,
  "in_reply_to_status_id" : 512703749601521664,
  "created_at" : "2014-09-18 22:20:39 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.115036013, 8.750297547 ]
  },
  "id_str" : "512655576435015680",
  "text" : "\u00ABGiven that all must die, it is better to die with distinction than to live long.\u00BB \u2013 Musonius Rufus",
  "id" : 512655576435015680,
  "created_at" : "2014-09-18 17:33:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 50, 58 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/iEcrf4tq8s",
      "expanded_url" : "http:\/\/www.molecularecologist.com\/2014\/09\/fishing-for-genetic-signals-of-adaptation\/",
      "display_url" : "molecularecologist.com\/2014\/09\/fishin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512605323908366337",
  "text" : "Fishing for genetic signals of adaptation. Thanks @JBYoder http:\/\/t.co\/iEcrf4tq8s",
  "id" : 512605323908366337,
  "created_at" : "2014-09-18 14:13:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/9KJJtQmc8Z",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0107216",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512564523468070912",
  "text" : "Open-Source Syringe Pump Library http:\/\/t.co\/9KJJtQmc8Z",
  "id" : 512564523468070912,
  "created_at" : "2014-09-18 11:31:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/x92Aqifd3m",
      "expanded_url" : "http:\/\/brainsidea.wordpress.com\/2014\/09\/17\/why-are-ethical-standards-higher-in-science-than-in-business-and-media\/",
      "display_url" : "brainsidea.wordpress.com\/2014\/09\/17\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512564309847965697",
  "text" : "Why are ethical standards higher in science than in business and media? http:\/\/t.co\/x92Aqifd3m",
  "id" : 512564309847965697,
  "created_at" : "2014-09-18 11:30:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723669945, 8.6275248046 ]
  },
  "id_str" : "512550090347921408",
  "text" : "\u00ABVoll praktisch das du so viele Allergien hast. Andere Menschen w\u00FCrden viel Geld daf\u00FCr bezahlen den Effekt mit Botox zu emulieren.\u00BB",
  "id" : 512550090347921408,
  "created_at" : "2014-09-18 10:33:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/BNEBmMr9tS",
      "expanded_url" : "http:\/\/instagram.com\/p\/tD8hCThwrC\/",
      "display_url" : "instagram.com\/p\/tD8hCThwrC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "512351863027400707",
  "text" : "\u00ABNicht f\u00FCr Kinder unter 38 Jahren. Kleinteile k\u00F6nnen verschluckt werden.\u00BB \u2014 \u00ABHaha, schlucken!\u00BB http:\/\/t.co\/BNEBmMr9tS",
  "id" : 512351863027400707,
  "created_at" : "2014-09-17 21:26:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412534, 8.75004462 ]
  },
  "id_str" : "512335945597984768",
  "text" : "\u00ABAlle Hotels waren ausgebucht in der Stadt. Aber ich rausgefunden: F\u00FCr 50\u20AC pro Nacht kann man auch im Bordell schlafen!\u00BB",
  "id" : 512335945597984768,
  "created_at" : "2014-09-17 20:23:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/jUGIxpVsqg",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/09\/16\/how-i-learned-to-think-like-a.html",
      "display_url" : "boingboing.net\/2014\/09\/16\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512191751109742593",
  "text" : "How I learned to think like a\u00A0mushroom http:\/\/t.co\/jUGIxpVsqg",
  "id" : 512191751109742593,
  "created_at" : "2014-09-17 10:50:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/P2ijP9AqYn",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/09\/16\/willpower-as-a-rechargeable-ba.html",
      "display_url" : "boingboing.net\/2014\/09\/16\/wil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512161124390019072",
  "text" : "never leave home without the charging cable for your ego http:\/\/t.co\/P2ijP9AqYn",
  "id" : 512161124390019072,
  "created_at" : "2014-09-17 08:48:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/FR2g6tX3D0",
      "expanded_url" : "http:\/\/www.vox.com\/2014\/9\/16\/6226961\/23andme-reverses-its-decision-to-move-to-more-lax-privacy-settings",
      "display_url" : "vox.com\/2014\/9\/16\/6226\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512158595790934016",
  "text" : "23andMe reverses its decision to move to more lax privacy settings http:\/\/t.co\/FR2g6tX3D0",
  "id" : 512158595790934016,
  "created_at" : "2014-09-17 08:38:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1122774324, 8.7511536582 ]
  },
  "id_str" : "512016808115986432",
  "text" : "\u00ABWollte der Kater doch nicht raus?\u00BB\u2014\u00ABDoch, er hat 3 Schritte gemacht &amp; als er den Rasen betreten h\u00E4tte ist er als guter Deutscher umgedreht\u00BB",
  "id" : 512016808115986432,
  "created_at" : "2014-09-16 23:14:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723087905, 8.6274159886 ]
  },
  "id_str" : "511901816058290176",
  "text" : "\u00ABErstmal das Tigger-Ei aus dem Mund sp\u00FClen.\u00BB \u2014 \u00ABWieso, ist das so haarig?\u00BB",
  "id" : 511901816058290176,
  "created_at" : "2014-09-16 15:37:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511863185612472321",
  "text" : "Die Uni will mir also keinen Nebenerwerb als externer Dozent erlauben, weil sie mich ja schon f\u00FCr Lehre bezahlt &amp; es damit abgegolten sei\u2026",
  "id" : 511863185612472321,
  "created_at" : "2014-09-16 13:04:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AliciaMstt",
      "screen_name" : "AliciaMstt",
      "indices" : [ 3, 14 ],
      "id_str" : "955629306",
      "id" : 955629306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511845137199419392",
  "text" : "RT @AliciaMstt: New paper out!: If you can't beat your enemy, join them. Of how we ended up using paralogs instead of filtering them  http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/mr6oot4j86",
        "expanded_url" : "http:\/\/gbe.oxfordjournals.org\/cgi\/content\/long\/evu205v1",
        "display_url" : "gbe.oxfordjournals.org\/cgi\/content\/lo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "511823100472606720",
    "text" : "New paper out!: If you can't beat your enemy, join them. Of how we ended up using paralogs instead of filtering them  http:\/\/t.co\/mr6oot4j86",
    "id" : 511823100472606720,
    "created_at" : "2014-09-16 10:25:11 +0000",
    "user" : {
      "name" : "AliciaMstt",
      "screen_name" : "AliciaMstt",
      "protected" : false,
      "id_str" : "955629306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/859579998566572032\/LAraVQ4N_normal.jpg",
      "id" : 955629306,
      "verified" : false
    }
  },
  "id" : 511845137199419392,
  "created_at" : "2014-09-16 11:52:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/OCCSFo6DNe",
      "expanded_url" : "http:\/\/www.theatlantic.com\/features\/archive\/2014\/09\/the-simple-life-in-a-dumpster\/379947\/",
      "display_url" : "theatlantic.com\/features\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "511832523895472128",
  "text" : "Living Simply in a Dumpster http:\/\/t.co\/OCCSFo6DNe",
  "id" : 511832523895472128,
  "created_at" : "2014-09-16 11:02:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/n7vrAQWASy",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0106918",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "511831410429399040",
  "text" : "Testing Genetic Association by Regressing Genotype over Multiple Phenotypes http:\/\/t.co\/n7vrAQWASy",
  "id" : 511831410429399040,
  "created_at" : "2014-09-16 10:58:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/E6eSO6AnGT",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/46",
      "display_url" : "existentialcomics.com\/comic\/46"
    } ]
  },
  "geo" : { },
  "id_str" : "511817029377327105",
  "text" : "Authentic Man doesn\u2019t wear a costume, because he is true to himself! http:\/\/t.co\/E6eSO6AnGT",
  "id" : 511817029377327105,
  "created_at" : "2014-09-16 10:01:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/q586XkvOUF",
      "expanded_url" : "http:\/\/paintingsforants.tumblr.com\/",
      "display_url" : "paintingsforants.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "511815587857965057",
  "text" : "postcards for ants http:\/\/t.co\/q586XkvOUF",
  "id" : 511815587857965057,
  "created_at" : "2014-09-16 09:55:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511800540704296961",
  "geo" : { },
  "id_str" : "511800699693568000",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon Die Augenringe sind der Spiegel zur Seele.",
  "id" : 511800699693568000,
  "in_reply_to_status_id" : 511800540704296961,
  "created_at" : "2014-09-16 08:56:10 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511795874570444801",
  "geo" : { },
  "id_str" : "511799400591790080",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon \u201CIch seh\u2019 Dir in die Augenringe, Kleines.\u201D",
  "id" : 511799400591790080,
  "in_reply_to_status_id" : 511795874570444801,
  "created_at" : "2014-09-16 08:51:00 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/511795656143691776\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/JuSRH9nU7B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxpDb3RCYAAutJu.jpg",
      "id_str" : "511795653630910464",
      "id" : 511795653630910464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxpDb3RCYAAutJu.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/JuSRH9nU7B"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722772845, 8.6276152458 ]
  },
  "id_str" : "511795656143691776",
  "text" : "Meine Studenten k\u00F6nnen Gedanken lesen und k\u00FCmmern sich entsprechend um mich. http:\/\/t.co\/JuSRH9nU7B",
  "id" : 511795656143691776,
  "created_at" : "2014-09-16 08:36:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511605975447789568",
  "text" : "My archaic language goal is close: nearly speak enough Hebrew to use it for complaining about Perl APIs.",
  "id" : 511605975447789568,
  "created_at" : "2014-09-15 20:02:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/U8vVp8Y5yF",
      "expanded_url" : "http:\/\/i.imgur.com\/SqZlt1I.gif",
      "display_url" : "i.imgur.com\/SqZlt1I.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "511518450981044224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723164669, 8.6275077351 ]
  },
  "id_str" : "511518710352605184",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 @Lobot http:\/\/t.co\/U8vVp8Y5yF",
  "id" : 511518710352605184,
  "in_reply_to_status_id" : 511518450981044224,
  "created_at" : "2014-09-15 14:15:38 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Clark",
      "screen_name" : "clonemanager",
      "indices" : [ 3, 16 ],
      "id_str" : "54503593",
      "id" : 54503593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511517576162459649",
  "text" : "RT @clonemanager: The end of Sanger sequencing reads always remind me of Hey Jude. NNNAAA, NNNNA NANNANNAANANAAAA, NANNANNNNNANNNNAA, NNNA \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509994751161274368",
    "text" : "The end of Sanger sequencing reads always remind me of Hey Jude. NNNAAA, NNNNA NANNANNAANANAAAA, NANNANNNNNANNNNAA, NNNA NNNNNAA",
    "id" : 509994751161274368,
    "created_at" : "2014-09-11 09:19:58 +0000",
    "user" : {
      "name" : "Laura Clark",
      "screen_name" : "clonemanager",
      "protected" : false,
      "id_str" : "54503593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1506403648\/2008_06010152_normal.JPG",
      "id" : 54503593,
      "verified" : false
    }
  },
  "id" : 511517576162459649,
  "created_at" : "2014-09-15 14:11:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel P\u00E9an",
      "screen_name" : "SamuelPEAN",
      "indices" : [ 3, 14 ],
      "id_str" : "334239079",
      "id" : 334239079
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SamuelPEAN\/status\/511423801158946816\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/oaft0VwJNg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxjxPEWIcAARbp4.png",
      "id_str" : "511423798873452544",
      "id" : 511423798873452544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxjxPEWIcAARbp4.png",
      "sizes" : [ {
        "h" : 362,
        "resize" : "fit",
        "w" : 309
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 309
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 309
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 309
      } ],
      "display_url" : "pic.twitter.com\/oaft0VwJNg"
    } ],
    "hashtags" : [ {
      "text" : "OpenAccess",
      "indices" : [ 80, 91 ]
    }, {
      "text" : "OpenScience",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/JcWCzucZKH",
      "expanded_url" : "http:\/\/pnis.co\/editorial1.html",
      "display_url" : "pnis.co\/editorial1.html"
    } ]
  },
  "geo" : { },
  "id_str" : "511442185519394816",
  "text" : "RT @SamuelPEAN: PNIS, the new satirical science journal. http:\/\/t.co\/JcWCzucZKH #OpenAccess #OpenScience http:\/\/t.co\/oaft0VwJNg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SamuelPEAN\/status\/511423801158946816\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/oaft0VwJNg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxjxPEWIcAARbp4.png",
        "id_str" : "511423798873452544",
        "id" : 511423798873452544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxjxPEWIcAARbp4.png",
        "sizes" : [ {
          "h" : 362,
          "resize" : "fit",
          "w" : 309
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 309
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 309
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 309
        } ],
        "display_url" : "pic.twitter.com\/oaft0VwJNg"
      } ],
      "hashtags" : [ {
        "text" : "OpenAccess",
        "indices" : [ 64, 75 ]
      }, {
        "text" : "OpenScience",
        "indices" : [ 76, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/JcWCzucZKH",
        "expanded_url" : "http:\/\/pnis.co\/editorial1.html",
        "display_url" : "pnis.co\/editorial1.html"
      } ]
    },
    "geo" : { },
    "id_str" : "511423801158946816",
    "text" : "PNIS, the new satirical science journal. http:\/\/t.co\/JcWCzucZKH #OpenAccess #OpenScience http:\/\/t.co\/oaft0VwJNg",
    "id" : 511423801158946816,
    "created_at" : "2014-09-15 07:58:30 +0000",
    "user" : {
      "name" : "Samuel P\u00E9an",
      "screen_name" : "SamuelPEAN",
      "protected" : false,
      "id_str" : "334239079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/850660432062926848\/zig_9y1I_normal.jpg",
      "id" : 334239079,
      "verified" : false
    }
  },
  "id" : 511442185519394816,
  "created_at" : "2014-09-15 09:11:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511296942035333121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1114760802, 8.7530040944 ]
  },
  "id_str" : "511312461170212864",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer last night I dreamt about my death. Yours sounds worse.",
  "id" : 511312461170212864,
  "in_reply_to_status_id" : 511296942035333121,
  "created_at" : "2014-09-15 00:36:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511273274853298178",
  "text" : "\u00ABI saw that Angela Merkel took part in some kind of 'embrace your Jew' campaign. It's a good idea as I would really like to be embraced.\u00BB",
  "id" : 511273274853298178,
  "created_at" : "2014-09-14 22:00:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 77, 90 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 91, 97 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/1pKIrrDOiv",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0107623",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.115287, 8.750377 ]
  },
  "id_str" : "511045918335180800",
  "text" : "Rapoport's Rule Revisited: Geographical Distributions of Human Languages \/cc @PhilippBayer @Lobot  http:\/\/t.co\/1pKIrrDOiv",
  "id" : 511045918335180800,
  "created_at" : "2014-09-14 06:56:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/r5CCC4bMIM",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0107619?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosone%2FPLoSONE+%28PLOS+ONE+Alerts%3A+New+Articles%29",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "511044467378626560",
  "text" : "Age-Related Differences in Multiple Task Monitoring http:\/\/t.co\/r5CCC4bMIM",
  "id" : 511044467378626560,
  "created_at" : "2014-09-14 06:51:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Gillis",
      "screen_name" : "JustinHGillis",
      "indices" : [ 3, 17 ],
      "id_str" : "764204616",
      "id" : 764204616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511039012912771072",
  "text" : "RT @JustinHGillis: Norman Borlaug died 5 years ago today. A blank to many young people, he was a towering figure of 20th century. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/wTakSocoYX",
        "expanded_url" : "http:\/\/nyti.ms\/1xVoU7i",
        "display_url" : "nyti.ms\/1xVoU7i"
      } ]
    },
    "geo" : { },
    "id_str" : "510554862594301953",
    "text" : "Norman Borlaug died 5 years ago today. A blank to many young people, he was a towering figure of 20th century. http:\/\/t.co\/wTakSocoYX",
    "id" : 510554862594301953,
    "created_at" : "2014-09-12 22:25:39 +0000",
    "user" : {
      "name" : "Justin Gillis",
      "screen_name" : "JustinHGillis",
      "protected" : false,
      "id_str" : "764204616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504401664388771840\/IdG9i3iy_normal.jpeg",
      "id" : 764204616,
      "verified" : false
    }
  },
  "id" : 511039012912771072,
  "created_at" : "2014-09-14 06:29:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "indices" : [ 3, 10 ],
      "id_str" : "47876842",
      "id" : 47876842
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/brembs\/status\/510794342005747712\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/U7kdXAs63B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bxa0vxlIEAAq0Gu.jpg",
      "id_str" : "510794340609036288",
      "id" : 510794340609036288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bxa0vxlIEAAq0Gu.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 587,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 587,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 587,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/U7kdXAs63B"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/3MUtBFqKpk",
      "expanded_url" : "https:\/\/medium.com\/matter\/louisiana-loses-its-boot-b55b3bd52d1e",
      "display_url" : "medium.com\/matter\/louisia\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "511038704883097600",
  "text" : "RT @brembs: The actual map of Louisiana, without denial: https:\/\/t.co\/3MUtBFqKpk http:\/\/t.co\/U7kdXAs63B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/brembs\/status\/510794342005747712\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/U7kdXAs63B",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bxa0vxlIEAAq0Gu.jpg",
        "id_str" : "510794340609036288",
        "id" : 510794340609036288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bxa0vxlIEAAq0Gu.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/U7kdXAs63B"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/3MUtBFqKpk",
        "expanded_url" : "https:\/\/medium.com\/matter\/louisiana-loses-its-boot-b55b3bd52d1e",
        "display_url" : "medium.com\/matter\/louisia\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "510794342005747712",
    "text" : "The actual map of Louisiana, without denial: https:\/\/t.co\/3MUtBFqKpk http:\/\/t.co\/U7kdXAs63B",
    "id" : 510794342005747712,
    "created_at" : "2014-09-13 14:17:15 +0000",
    "user" : {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "protected" : false,
      "id_str" : "47876842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524937570984013824\/uPSUsTcU_normal.png",
      "id" : 47876842,
      "verified" : false
    }
  },
  "id" : 511038704883097600,
  "created_at" : "2014-09-14 06:28:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leon \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08\uD83C\uDF3F\uD83D\uDD2C",
      "screen_name" : "orchidhunter",
      "indices" : [ 3, 16 ],
      "id_str" : "21607925",
      "id" : 21607925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510896807111843840",
  "text" : "RT @orchidhunter: \"You're right. Lichens aren't plants.\" \n\"No, I said leggings aren't pants.\"\n\"...\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510892087269535744",
    "text" : "\"You're right. Lichens aren't plants.\" \n\"No, I said leggings aren't pants.\"\n\"...\"",
    "id" : 510892087269535744,
    "created_at" : "2014-09-13 20:45:40 +0000",
    "user" : {
      "name" : "Leon \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08\uD83C\uDF3F\uD83D\uDD2C",
      "screen_name" : "orchidhunter",
      "protected" : false,
      "id_str" : "21607925",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/860516945430429696\/NhIYG1Lp_normal.jpg",
      "id" : 21607925,
      "verified" : false
    }
  },
  "id" : 510896807111843840,
  "created_at" : "2014-09-13 21:04:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 0, 12 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510825582033371136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0938014444, 8.7528102821 ]
  },
  "id_str" : "510836751204495361",
  "in_reply_to_user_id" : 14728378,
  "text" : "@terrorzicke ne, keine Ahnung.",
  "id" : 510836751204495361,
  "in_reply_to_status_id" : 510825582033371136,
  "created_at" : "2014-09-13 17:05:47 +0000",
  "in_reply_to_screen_name" : "terrorzicke",
  "in_reply_to_user_id_str" : "14728378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 0, 12 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510824406885863425",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11522612, 8.75038742 ]
  },
  "id_str" : "510824633973874688",
  "in_reply_to_user_id" : 14728378,
  "text" : "@terrorzicke noch mal 48h bis es wieder in Kalifornien ist, dann ca. 3 Wochen bis zur fertigen Analyse.",
  "id" : 510824633973874688,
  "in_reply_to_status_id" : 510824406885863425,
  "created_at" : "2014-09-13 16:17:38 +0000",
  "in_reply_to_screen_name" : "terrorzicke",
  "in_reply_to_user_id_str" : "14728378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 0, 12 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510824015817351168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1138529368, 8.7534161098 ]
  },
  "id_str" : "510824287109144577",
  "in_reply_to_user_id" : 14728378,
  "text" : "@terrorzicke bei mir war es binnen 48h da. :)",
  "id" : 510824287109144577,
  "in_reply_to_status_id" : 510824015817351168,
  "created_at" : "2014-09-13 16:16:15 +0000",
  "in_reply_to_screen_name" : "terrorzicke",
  "in_reply_to_user_id_str" : "14728378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 0, 12 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510823671653732352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1138529368, 8.7534161098 ]
  },
  "id_str" : "510823896304848896",
  "in_reply_to_user_id" : 14728378,
  "text" : "@terrorzicke promethease ist ganz cool, die Reports sind relativ vergleichbar zu den alten von 23andme.",
  "id" : 510823896304848896,
  "in_reply_to_status_id" : 510823671653732352,
  "created_at" : "2014-09-13 16:14:42 +0000",
  "in_reply_to_screen_name" : "terrorzicke",
  "in_reply_to_user_id_str" : "14728378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 0, 12 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510821650024370176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139511308, 8.7533375714 ]
  },
  "id_str" : "510823347371126784",
  "in_reply_to_user_id" : 14728378,
  "text" : "@terrorzicke viel Spass damit. Und bei Fragen gerne melden :)",
  "id" : 510823347371126784,
  "in_reply_to_status_id" : 510821650024370176,
  "created_at" : "2014-09-13 16:12:31 +0000",
  "in_reply_to_screen_name" : "terrorzicke",
  "in_reply_to_user_id_str" : "14728378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/DxUXr1lKnF",
      "expanded_url" : "http:\/\/instagram.com\/p\/s5FRqBBwk6\/",
      "display_url" : "instagram.com\/p\/s5FRqBBwk6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "510823011805835264",
  "text" : "\u00ABBitte nicht diese Farbkombination. Ich hab die 80er schon bewusst erlebt!\u00BB http:\/\/t.co\/DxUXr1lKnF",
  "id" : 510823011805835264,
  "created_at" : "2014-09-13 16:11:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/gxVcZyBjQc",
      "expanded_url" : "http:\/\/instagram.com\/p\/s4nL_Ehwgw\/",
      "display_url" : "instagram.com\/p\/s4nL_Ehwgw\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.113868442, 8.753692928 ]
  },
  "id_str" : "510756846404386816",
  "text" : "Desk job @ Hafeninsel http:\/\/t.co\/gxVcZyBjQc",
  "id" : 510756846404386816,
  "created_at" : "2014-09-13 11:48:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140321419, 8.7530851085 ]
  },
  "id_str" : "510720687213146112",
  "text" : "\u00ABWieder alles ok?\u00BB \u2014 \u00ABJa, ist doch ein guter Tweet bei rausgekommen. Daf\u00FCr vergie\u00DFe ich gerne ein paar Tr\u00E4nen.\u00BB",
  "id" : 510720687213146112,
  "created_at" : "2014-09-13 09:24:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ipoow",
      "indices" : [ 76, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1114361025, 8.750144102 ]
  },
  "id_str" : "510720277010219009",
  "text" : "\u00ABI love you very much because with you I found a way to love myself again.\u00BB #ipoow",
  "id" : 510720277010219009,
  "created_at" : "2014-09-13 09:22:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ipoow",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1138066687, 8.7527369242 ]
  },
  "id_str" : "510705681872474112",
  "text" : "\u00ABThe only thing you really want is to make a woman go off with a big bang. It had to be men who invented the atomic bomb.\u00BB #ipoow",
  "id" : 510705681872474112,
  "created_at" : "2014-09-13 08:24:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1114462398, 8.7516747281 ]
  },
  "id_str" : "510565570501423104",
  "text" : "\u00ABWenn du meine Katze w\u00E4rest dann d\u00FCrftest du ja schon raus. Andererseits wurde meine andere Katze auch \u00FCberfahren.\u00BB",
  "id" : 510565570501423104,
  "created_at" : "2014-09-12 23:08:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ipoow",
      "indices" : [ 111, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1129578054, 8.7514843166 ]
  },
  "id_str" : "510555825421950977",
  "text" : "\u00ABBut who can reassure himself with his own rationalizations? No argument can fill the void of a dead feeling.\u00BB #ipoow",
  "id" : 510555825421950977,
  "created_at" : "2014-09-12 22:29:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jhermes",
      "screen_name" : "spinfocl",
      "indices" : [ 0, 9 ],
      "id_str" : "214008538",
      "id" : 214008538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510363990745444352",
  "geo" : { },
  "id_str" : "510364182639026177",
  "in_reply_to_user_id" : 214008538,
  "text" : "@spinfocl news at 11? ;)",
  "id" : 510364182639026177,
  "in_reply_to_status_id" : 510363990745444352,
  "created_at" : "2014-09-12 09:47:57 +0000",
  "in_reply_to_screen_name" : "spinfocl",
  "in_reply_to_user_id_str" : "214008538",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben White",
      "screen_name" : "benabyad",
      "indices" : [ 3, 12 ],
      "id_str" : "248670810",
      "id" : 248670810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/0Xc0htYdt4",
      "expanded_url" : "http:\/\/www.timesofisrael.com\/reservists-from-top-intel-unit-refuse-to-operate-against-palestinians\/",
      "display_url" : "timesofisrael.com\/reservists-fro\u2026"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/wHWUhBZ6kV",
      "expanded_url" : "http:\/\/uk.reuters.com\/article\/2014\/09\/12\/uk-palestinians-israel-wiretappers-idUKKBN0H70LJ20140912",
      "display_url" : "uk.reuters.com\/article\/2014\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510352470439395329",
  "text" : "RT @benabyad: Reservists from top IDF intel unit 8200 refuse to \u2018operate against Palestinians\u2019 http:\/\/t.co\/0Xc0htYdt4 http:\/\/t.co\/wHWUhBZ6kV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/0Xc0htYdt4",
        "expanded_url" : "http:\/\/www.timesofisrael.com\/reservists-from-top-intel-unit-refuse-to-operate-against-palestinians\/",
        "display_url" : "timesofisrael.com\/reservists-fro\u2026"
      }, {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/wHWUhBZ6kV",
        "expanded_url" : "http:\/\/uk.reuters.com\/article\/2014\/09\/12\/uk-palestinians-israel-wiretappers-idUKKBN0H70LJ20140912",
        "display_url" : "uk.reuters.com\/article\/2014\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "510337842883866624",
    "text" : "Reservists from top IDF intel unit 8200 refuse to \u2018operate against Palestinians\u2019 http:\/\/t.co\/0Xc0htYdt4 http:\/\/t.co\/wHWUhBZ6kV",
    "id" : 510337842883866624,
    "created_at" : "2014-09-12 08:03:18 +0000",
    "user" : {
      "name" : "Ben White",
      "screen_name" : "benabyad",
      "protected" : false,
      "id_str" : "248670810",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504918766799433728\/zKd13LLy_normal.jpeg",
      "id" : 248670810,
      "verified" : false
    }
  },
  "id" : 510352470439395329,
  "created_at" : "2014-09-12 09:01:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510174167535452160",
  "text" : "more conversational help, this time too close home: \n\u05D0\u05E0\u05D9 \u05DE\u05D3\u05E2\u05DF, \u05D0\u05DA \u05D0\u05E0\u05D9 \u05E2\u05D5\u05D1\u05D3 \u05DB\u05E8\u05D2\u05E2 \u05DB\u05E0\u05D4\u05D2 \u05DE\u05D5\u05E0\u05D9\u05EA.",
  "id" : 510174167535452160,
  "created_at" : "2014-09-11 21:12:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WikimediaDeutschland",
      "screen_name" : "WikimediaDE",
      "indices" : [ 3, 15 ],
      "id_str" : "47948264",
      "id" : 47948264
    }, {
      "name" : "anke domscheit-berg",
      "screen_name" : "anked",
      "indices" : [ 45, 51 ],
      "id_str" : "16557497",
      "id" : 16557497
    }, {
      "name" : "fukami",
      "screen_name" : "fukami",
      "indices" : [ 54, 61 ],
      "id_str" : "1209301",
      "id" : 1209301
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 64, 80 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "mntmn \uA66E",
      "screen_name" : "mntmn",
      "indices" : [ 83, 89 ],
      "id_str" : "19429480",
      "id" : 19429480
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WikimediaDE\/status\/510055287353778177\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/xTfxD8pquo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxQUlISCIAEn8lr.png",
      "id_str" : "510055285910544385",
      "id" : 510055285910544385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxQUlISCIAEn8lr.png",
      "sizes" : [ {
        "h" : 563,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/xTfxD8pquo"
    } ],
    "hashtags" : [ {
      "text" : "wmdesalon",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510064475723280384",
  "text" : "RT @WikimediaDE: D=DATENBERG. 2.Oktober. Mit @anked + @fukami + @gedankenstuecke + @mntmn #wmdesalon http:\/\/t.co\/xTfxD8pquo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "anke domscheit-berg",
        "screen_name" : "anked",
        "indices" : [ 28, 34 ],
        "id_str" : "16557497",
        "id" : 16557497
      }, {
        "name" : "fukami",
        "screen_name" : "fukami",
        "indices" : [ 37, 44 ],
        "id_str" : "1209301",
        "id" : 1209301
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 47, 63 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "mntmn \uA66E",
        "screen_name" : "mntmn",
        "indices" : [ 66, 72 ],
        "id_str" : "19429480",
        "id" : 19429480
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WikimediaDE\/status\/510055287353778177\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/xTfxD8pquo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxQUlISCIAEn8lr.png",
        "id_str" : "510055285910544385",
        "id" : 510055285910544385,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxQUlISCIAEn8lr.png",
        "sizes" : [ {
          "h" : 563,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/xTfxD8pquo"
      } ],
      "hashtags" : [ {
        "text" : "wmdesalon",
        "indices" : [ 73, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510055287353778177",
    "text" : "D=DATENBERG. 2.Oktober. Mit @anked + @fukami + @gedankenstuecke + @mntmn #wmdesalon http:\/\/t.co\/xTfxD8pquo",
    "id" : 510055287353778177,
    "created_at" : "2014-09-11 13:20:31 +0000",
    "user" : {
      "name" : "WikimediaDeutschland",
      "screen_name" : "WikimediaDE",
      "protected" : false,
      "id_str" : "47948264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/827518840456220674\/5GpStvKz_normal.jpg",
      "id" : 47948264,
      "verified" : true
    }
  },
  "id" : 510064475723280384,
  "created_at" : "2014-09-11 13:57:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/j2b2eZEt8C",
      "expanded_url" : "http:\/\/www.biomedcentral.com\/1471-2105\/13\/110",
      "display_url" : "biomedcentral.com\/1471-2105\/13\/1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "510001219461316609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723178329, 8.6275758161 ]
  },
  "id_str" : "510001652347441152",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer google turns out there is one. And I even know one of the authors m) http:\/\/t.co\/j2b2eZEt8C",
  "id" : 510001652347441152,
  "in_reply_to_status_id" : 510001219461316609,
  "created_at" : "2014-09-11 09:47:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510000615821295618",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723178329, 8.6275758161 ]
  },
  "id_str" : "510001041539342336",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer do you know whether there are similar tools that convert images of phylogenetic trees to newick? :p",
  "id" : 510001041539342336,
  "in_reply_to_status_id" : 510000615821295618,
  "created_at" : "2014-09-11 09:44:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509999827581562880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723178329, 8.6275758161 ]
  },
  "id_str" : "510000225814315008",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer cool, pretty close :)",
  "id" : 510000225814315008,
  "in_reply_to_status_id" : 509999827581562880,
  "created_at" : "2014-09-11 09:41:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509981682754420736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1757405365, 8.6191222334 ]
  },
  "id_str" : "509983391354454016",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon you shook my world apart like only a direct hit of a 767 could?",
  "id" : 509983391354454016,
  "in_reply_to_status_id" : 509981682754420736,
  "created_at" : "2014-09-11 08:34:50 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723391475, 8.6275151321 ]
  },
  "id_str" : "509981239550705664",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon alles gute zum jahrestag :3",
  "id" : 509981239550705664,
  "created_at" : "2014-09-11 08:26:17 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509937836615671808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172135333, 8.6273939967 ]
  },
  "id_str" : "509977264352935936",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that\u2019s cool, have you compared it to the real data?",
  "id" : 509977264352935936,
  "in_reply_to_status_id" : 509937836615671808,
  "created_at" : "2014-09-11 08:10:29 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "indices" : [ 3, 18 ],
      "id_str" : "1040758742",
      "id" : 1040758742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509972964595744768",
  "text" : "RT @BioDataGanache: Some assembly required. Yep- in this paper the genome scaffolds were assembled on pieces of paper. PAPER http:\/\/t.co\/02\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/02Y1ryrH3Q",
        "expanded_url" : "http:\/\/tmblr.co\/Zldygq1QWzZHi",
        "display_url" : "tmblr.co\/Zldygq1QWzZHi"
      } ]
    },
    "geo" : { },
    "id_str" : "509897225074647042",
    "text" : "Some assembly required. Yep- in this paper the genome scaffolds were assembled on pieces of paper. PAPER http:\/\/t.co\/02Y1ryrH3Q",
    "id" : 509897225074647042,
    "created_at" : "2014-09-11 02:52:26 +0000",
    "user" : {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "protected" : false,
      "id_str" : "1040758742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/825446808696483840\/nMI6-h4y_normal.jpg",
      "id" : 1040758742,
      "verified" : false
    }
  },
  "id" : 509972964595744768,
  "created_at" : "2014-09-11 07:53:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723425356, 8.6275400948 ]
  },
  "id_str" : "509972135285387264",
  "text" : "But by far my favorite: \u05D0\u05D9\u05DA \u05D0\u05E4\u05E9\u05E8 \u05DC\u05D4\u05D9\u05D5\u05EA \u05D4\u05D9\u05D5\u05DD \u05D2\u05E8\u05DE\u05E0\u05D9 \u05D2\u05D0\u05D4",
  "id" : 509972135285387264,
  "created_at" : "2014-09-11 07:50:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17584673, 8.61921124 ]
  },
  "id_str" : "509971611769143296",
  "text" : "This German\u2013Hebrew conversation book is full of useful sentences: \u05D0\u05D1\u05DC \u05D0\u05DC \u05D3\u05D0\u05D2\u05D4: \u05DB\u05DC \u05E2\u05D5\u05D3 \u05D0\u05EA\u05D4 \u05E4\u05D4, \u05DC\u05D0 \u05EA\u05D4\u05D9\u05D4 \u05DE\u05DC\u05D7\u05DE\u05D4",
  "id" : 509971611769143296,
  "created_at" : "2014-09-11 07:48:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/Dhi22WCUkI",
      "expanded_url" : "http:\/\/altjband.com\/map\/",
      "display_url" : "altjband.com\/map\/"
    } ]
  },
  "geo" : { },
  "id_str" : "509724581377363968",
  "text" : "So if you\u2019re standing on top of the Sk\u00F3gafoss you can listen to the new record of alt-J\u2026 http:\/\/t.co\/Dhi22WCUkI",
  "id" : 509724581377363968,
  "created_at" : "2014-09-10 15:26:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Take That Darwin",
      "screen_name" : "TakeThatDarwin",
      "indices" : [ 3, 18 ],
      "id_str" : "920925912",
      "id" : 920925912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509710616542842880",
  "text" : "RT @TakeThatDarwin: Sorry, creationists, but I just looked at MY copy of Origin of Species, and it doesn't say anything about \"races.\" http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TakeThatDarwin\/status\/509693751275827200\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/z0K0jTtdJc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxLLw-fCEAMHRVM.jpg",
        "id_str" : "509693750113603587",
        "id" : 509693750113603587,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxLLw-fCEAMHRVM.jpg",
        "sizes" : [ {
          "h" : 819,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 819,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 819,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 557,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/z0K0jTtdJc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509693751275827200",
    "text" : "Sorry, creationists, but I just looked at MY copy of Origin of Species, and it doesn't say anything about \"races.\" http:\/\/t.co\/z0K0jTtdJc",
    "id" : 509693751275827200,
    "created_at" : "2014-09-10 13:23:54 +0000",
    "user" : {
      "name" : "Take That Darwin",
      "screen_name" : "TakeThatDarwin",
      "protected" : false,
      "id_str" : "920925912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927743009336315904\/J7E5E6hz_normal.jpg",
      "id" : 920925912,
      "verified" : false
    }
  },
  "id" : 509710616542842880,
  "created_at" : "2014-09-10 14:30:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/e8eCaCKFgm",
      "expanded_url" : "http:\/\/instagram.com\/p\/swv0DhBwsU\/",
      "display_url" : "instagram.com\/p\/swv0DhBwsU\/"
    } ]
  },
  "geo" : { },
  "id_str" : "509649916231041024",
  "text" : "It's 72 miles to \u00CDsafj\u00F6r\u00F0ur, we've got a full tank and it never gets dark out. Hit it. http:\/\/t.co\/e8eCaCKFgm",
  "id" : 509649916231041024,
  "created_at" : "2014-09-10 10:29:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106735783, 8.7574969463 ]
  },
  "id_str" : "509426096736325633",
  "text" : "\u00ABWieso bist du angeblich noch in Wiesbaden? Ist dein Geotag-Nachsendeauftrag nicht angekommen?\u00BB",
  "id" : 509426096736325633,
  "created_at" : "2014-09-09 19:40:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1108907064, 8.7557149845 ]
  },
  "id_str" : "509424598174412800",
  "text" : "Misread the lid of the litter-box: \u2018Lift here for easy pooping\u2019",
  "id" : 509424598174412800,
  "created_at" : "2014-09-09 19:34:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1151573221, 8.7503659953 ]
  },
  "id_str" : "509423204180692992",
  "text" : "\u00ABWas war das f\u00FCr ein Geschrei?!\u00BB \u2013 \u00ABBestimmt ein Nachbar der die Apple Keynote gesehen hat, hier im Hipster-Viertel.\u00BB",
  "id" : 509423204180692992,
  "created_at" : "2014-09-09 19:28:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 26, 32 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509410996147224576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412534, 8.75004462 ]
  },
  "id_str" : "509422752873594880",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Ne, diejenige die @Lobot gebraucht besorgt hat.",
  "id" : 509422752873594880,
  "in_reply_to_status_id" : 509410996147224576,
  "created_at" : "2014-09-09 19:27:03 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509367323921088512",
  "geo" : { },
  "id_str" : "509367464099340288",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj die holen wir kommenden Sonntag, bist hiermit eingeladen mitzuhelfen ;)",
  "id" : 509367464099340288,
  "in_reply_to_status_id" : 509367323921088512,
  "created_at" : "2014-09-09 15:47:21 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Primitives Element",
      "screen_name" : "drseilzug",
      "indices" : [ 0, 10 ],
      "id_str" : "243633845",
      "id" : 243633845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509366506682351616",
  "geo" : { },
  "id_str" : "509367216979333120",
  "in_reply_to_user_id" : 243633845,
  "text" : "@drseilzug for now we were desperate enough to use the windows as a substitute. ;)",
  "id" : 509367216979333120,
  "in_reply_to_status_id" : 509366506682351616,
  "created_at" : "2014-09-09 15:46:22 +0000",
  "in_reply_to_screen_name" : "drseilzug",
  "in_reply_to_user_id_str" : "243633845",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509366463040606209",
  "geo" : { },
  "id_str" : "509366572264468480",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher 90x60 &amp; 180x90 cm",
  "id" : 509366572264468480,
  "in_reply_to_status_id" : 509366463040606209,
  "created_at" : "2014-09-09 15:43:49 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509366300863655936",
  "text" : "Yay, the whiteboards for the new apartment should arrive at the end of the week. \\o\/",
  "id" : 509366300863655936,
  "created_at" : "2014-09-09 15:42:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509363283241861122",
  "geo" : { },
  "id_str" : "509363560984875008",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez yes, it\u2019s the difference between data, information and knowledge :)",
  "id" : 509363560984875008,
  "in_reply_to_status_id" : 509363283241861122,
  "created_at" : "2014-09-09 15:31:51 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/MK0M2igkeV",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0106588",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509354406609833984",
  "text" : "Statistical Approach of Functional Profiling for a Microbial Community http:\/\/t.co\/MK0M2igkeV",
  "id" : 509354406609833984,
  "created_at" : "2014-09-09 14:55:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 63, 72 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/9qok4kGmM3",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/anthropology-in-practice\/2014\/09\/08\/is-data-really-changing-the-nature-of-wearable-technology\/",
      "display_url" : "blogs.scientificamerican.com\/anthropology-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509352123113668608",
  "text" : "Is data really changing the nature of wearable technology? \/cc @eramirez http:\/\/t.co\/9qok4kGmM3",
  "id" : 509352123113668608,
  "created_at" : "2014-09-09 14:46:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/UPFst3UtSY",
      "expanded_url" : "http:\/\/vimeo.com\/105365388",
      "display_url" : "vimeo.com\/105365388"
    } ]
  },
  "geo" : { },
  "id_str" : "509342521642979328",
  "text" : "Drone's view of Burning Man 2014 http:\/\/t.co\/UPFst3UtSY",
  "id" : 509342521642979328,
  "created_at" : "2014-09-09 14:08:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/KNfL7x6vcJ",
      "expanded_url" : "http:\/\/the-toast.net\/2014\/09\/08\/every-type-email-students-send-professors\/",
      "display_url" : "the-toast.net\/2014\/09\/08\/eve\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723273858, 8.6275629907 ]
  },
  "id_str" : "509324042881732608",
  "text" : "Every Type Of Email College Students Send Their Professors http:\/\/t.co\/KNfL7x6vcJ",
  "id" : 509324042881732608,
  "created_at" : "2014-09-09 12:54:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muchlatergram",
      "indices" : [ 12, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/hg45D0nUeD",
      "expanded_url" : "http:\/\/instagram.com\/p\/suXNAoBwro\/",
      "display_url" : "instagram.com\/p\/suXNAoBwro\/"
    } ]
  },
  "geo" : { },
  "id_str" : "509314322292813824",
  "text" : "And another #muchlatergram, leaving Drangaj\u00F6kull. http:\/\/t.co\/hg45D0nUeD",
  "id" : 509314322292813824,
  "created_at" : "2014-09-09 12:16:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muchlatergram",
      "indices" : [ 29, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/4o0CDjWuJL",
      "expanded_url" : "http:\/\/instagram.com\/p\/suVWL5hwpW\/",
      "display_url" : "instagram.com\/p\/suVWL5hwpW\/"
    } ]
  },
  "geo" : { },
  "id_str" : "509310240144113664",
  "text" : "Cleaning up my photo library #muchlatergram http:\/\/t.co\/4o0CDjWuJL",
  "id" : 509310240144113664,
  "created_at" : "2014-09-09 11:59:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Harford",
      "screen_name" : "TimHarford",
      "indices" : [ 3, 14 ],
      "id_str" : "32493647",
      "id" : 32493647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/UwyGLcuEwY",
      "expanded_url" : "http:\/\/dlvr.it\/6s0BYv",
      "display_url" : "dlvr.it\/6s0BYv"
    } ]
  },
  "geo" : { },
  "id_str" : "509274207763845120",
  "text" : "RT @TimHarford: The travelers' dilemma - I like this! It's a new one on me. http:\/\/t.co\/UwyGLcuEwY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/UwyGLcuEwY",
        "expanded_url" : "http:\/\/dlvr.it\/6s0BYv",
        "display_url" : "dlvr.it\/6s0BYv"
      } ]
    },
    "geo" : { },
    "id_str" : "509273771601965056",
    "text" : "The travelers' dilemma - I like this! It's a new one on me. http:\/\/t.co\/UwyGLcuEwY",
    "id" : 509273771601965056,
    "created_at" : "2014-09-09 09:35:03 +0000",
    "user" : {
      "name" : "Tim Harford",
      "screen_name" : "TimHarford",
      "protected" : false,
      "id_str" : "32493647",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1338890256\/Harford_Cropped_normal.JPG",
      "id" : 32493647,
      "verified" : true
    }
  },
  "id" : 509274207763845120,
  "created_at" : "2014-09-09 09:36:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1313479763, 8.626132094 ]
  },
  "id_str" : "509040652190236673",
  "text" : "Lieber 2 Jahre fr\u00FCher sterben als interoperable Gesundheitsdaten zu haben. Deutschland 2014.",
  "id" : 509040652190236673,
  "created_at" : "2014-09-08 18:08:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508962789893750785",
  "geo" : { },
  "id_str" : "508964711317372928",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, I had :)",
  "id" : 508964711317372928,
  "in_reply_to_status_id" : 508962789893750785,
  "created_at" : "2014-09-08 13:06:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 3, 17 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/Y9hk3tMT0p",
      "expanded_url" : "http:\/\/wp.me\/p1PnkE-bj",
      "display_url" : "wp.me\/p1PnkE-bj"
    } ]
  },
  "geo" : { },
  "id_str" : "508949678797651968",
  "text" : "RT @BioMickWatson: Thoughts on Oxford Nanopore's MinION mobile DNA sequencer http:\/\/t.co\/Y9hk3tMT0p (for those that don't work at weekends!)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/Y9hk3tMT0p",
        "expanded_url" : "http:\/\/wp.me\/p1PnkE-bj",
        "display_url" : "wp.me\/p1PnkE-bj"
      } ]
    },
    "geo" : { },
    "id_str" : "508887339599273984",
    "text" : "Thoughts on Oxford Nanopore's MinION mobile DNA sequencer http:\/\/t.co\/Y9hk3tMT0p (for those that don't work at weekends!)",
    "id" : 508887339599273984,
    "created_at" : "2014-09-08 07:59:31 +0000",
    "user" : {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "protected" : false,
      "id_str" : "228586748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870214569679093760\/YIZGIDTS_normal.jpg",
      "id" : 228586748,
      "verified" : false
    }
  },
  "id" : 508949678797651968,
  "created_at" : "2014-09-08 12:07:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508886933624619008",
  "geo" : { },
  "id_str" : "508887776893612032",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Und zack ist dir der Nobel f\u00FCr Economics sicher.",
  "id" : 508887776893612032,
  "in_reply_to_status_id" : 508886933624619008,
  "created_at" : "2014-09-08 08:01:15 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508885506848194560",
  "geo" : { },
  "id_str" : "508885750533083137",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog vor allem die mit erfolgreichen Versuchen in jungen Jahren.",
  "id" : 508885750533083137,
  "in_reply_to_status_id" : 508885506848194560,
  "created_at" : "2014-09-08 07:53:12 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508884581572169728",
  "text" : "Nachdem ich gestern zwangsweise auf Mavericks updated wurde: Gibt es einen fix f\u00FCr das \u201CEmails werden in Mail nicht angezeigt\u201D-Problem?",
  "id" : 508884581572169728,
  "created_at" : "2014-09-08 07:48:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412534, 8.75004462 ]
  },
  "id_str" : "508719675145203712",
  "text" : "\u00ABWar das eine sehr dumme Frage?\u00BB \u2013 \u00ABNicht f\u00FCr deine Verh\u00E4ltnisse\u2026\u00BB",
  "id" : 508719675145203712,
  "created_at" : "2014-09-07 20:53:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/kbqWLsfVRk",
      "expanded_url" : "http:\/\/instagram.com\/p\/spKS09hwm2\/",
      "display_url" : "instagram.com\/p\/spKS09hwm2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "508582247105331200",
  "text" : "Dead Sea reenactment http:\/\/t.co\/kbqWLsfVRk",
  "id" : 508582247105331200,
  "created_at" : "2014-09-07 11:47:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508454546142527488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11147332, 8.75011513 ]
  },
  "id_str" : "508568152163504128",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer will be in the office later and have a look. But pretty sure it goes down with rising N50.",
  "id" : 508568152163504128,
  "in_reply_to_status_id" : 508454546142527488,
  "created_at" : "2014-09-07 10:51:10 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1133435037, 8.7530842873 ]
  },
  "id_str" : "508337709593952257",
  "text" : "\u00ABManche sind Fisting-arm, wir haben einen Fisting-Arm.\u00BB \u2013 \u00ABIch hab sogar zwei!\u00BB",
  "id" : 508337709593952257,
  "created_at" : "2014-09-06 19:35:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 9, 22 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508164873193545729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412534, 8.75004462 ]
  },
  "id_str" : "508169217993367552",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @PhilippBayer i hadn\u2019t, thanks a lot. :)",
  "id" : 508169217993367552,
  "in_reply_to_status_id" : 508164873193545729,
  "created_at" : "2014-09-06 08:25:57 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508068771903176704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106705902, 8.7495974779 ]
  },
  "id_str" : "508144160638255104",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ouch, I know that problem re: reading a different a manuscript. :(",
  "id" : 508144160638255104,
  "in_reply_to_status_id" : 508068771903176704,
  "created_at" : "2014-09-06 06:46:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    }, {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 45, 51 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508136415692324864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1107667752, 8.7496595301 ]
  },
  "id_str" : "508143742629732352",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule puh, spontan nicht, aber vielleicht @dvzrv? Der hat meine genetischen Daten ja vertont.",
  "id" : 508143742629732352,
  "in_reply_to_status_id" : 508136415692324864,
  "created_at" : "2014-09-06 06:44:43 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508077936692297729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11147327, 8.7501150711 ]
  },
  "id_str" : "508143603747921921",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer total bases assembled is virtually identical in all assemblies. Could maybe normalize by n50?",
  "id" : 508143603747921921,
  "in_reply_to_status_id" : 508077936692297729,
  "created_at" : "2014-09-06 06:44:10 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/L6GWl2CulE",
      "expanded_url" : "http:\/\/instagram.com\/p\/slVTF9hwl6\/",
      "display_url" : "instagram.com\/p\/slVTF9hwl6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "508043496519786497",
  "text" : "Foodwatch http:\/\/t.co\/L6GWl2CulE",
  "id" : 508043496519786497,
  "created_at" : "2014-09-06 00:06:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Ram",
      "screen_name" : "_inundata",
      "indices" : [ 7, 17 ],
      "id_str" : "267256091",
      "id" : 267256091
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 26, 35 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/507934366811832320\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/ftwQUGwd98",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwyLnXKIgAA5872.jpg",
      "id_str" : "507934366333698048",
      "id" : 507934366333698048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwyLnXKIgAA5872.jpg",
      "sizes" : [ {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 896,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/ftwQUGwd98"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1141592967, 8.7500551946 ]
  },
  "id_str" : "507934366811832320",
  "text" : "Thanks @_inundata for the @rOpenSci stickers. I will return the favor with ours of openSNP. http:\/\/t.co\/ftwQUGwd98",
  "id" : 507934366811832320,
  "created_at" : "2014-09-05 16:52:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1151374593, 8.7503598093 ]
  },
  "id_str" : "507933853106073600",
  "text" : "Eine Stunde lang mit dem Bohrloch abqu\u00E4len. Dann erst die Frage stellen wof\u00FCr dieser Schalter mit einem Schlag-Piktogram drauf ist.",
  "id" : 507933853106073600,
  "created_at" : "2014-09-05 16:50:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723169709, 8.6275164999 ]
  },
  "id_str" : "507877820820099072",
  "text" : "\u00ABDie Eule der Weisheit sagt: Nimm einen Schluck aus dem Schrank der Gl\u00FCckseligkeit.\u00BB",
  "id" : 507877820820099072,
  "created_at" : "2014-09-05 13:08:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507869540391608320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1665225691, 8.6201530152 ]
  },
  "id_str" : "507870961409208321",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot kinky to the bones. ;)",
  "id" : 507870961409208321,
  "in_reply_to_status_id" : 507869540391608320,
  "created_at" : "2014-09-05 12:40:47 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 65, 74 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 75, 81 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/7XZ7bZkVJx",
      "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2014\/09\/05\/the-erotic-endurance-of-whale-hips\/",
      "display_url" : "phenomena.nationalgeographic.com\/2014\/09\/05\/the\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723188165, 8.6274928058 ]
  },
  "id_str" : "507868618101895168",
  "text" : "Looks like my story about cetacean penis bones was close enough, @JP_Stich @Lobot! http:\/\/t.co\/7XZ7bZkVJx",
  "id" : 507868618101895168,
  "created_at" : "2014-09-05 12:31:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723285304, 8.6275548719 ]
  },
  "id_str" : "507855676757278720",
  "text" : "\u00ABHad crystal meth existed in the ancient world, the Stoics would doubtless have counseled against its use.\u00BB Say philosophy is useless!",
  "id" : 507855676757278720,
  "created_at" : "2014-09-05 11:40:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jakob Err",
      "screen_name" : "Jakob_Err",
      "indices" : [ 3, 13 ],
      "id_str" : "490871541",
      "id" : 490871541
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Jakob_Err\/status\/507845338926170112\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/d4QDl3g2PZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bww6pRaIAAEfMzP.png",
      "id_str" : "507845338708049921",
      "id" : 507845338708049921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bww6pRaIAAEfMzP.png",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/d4QDl3g2PZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507851393190096896",
  "text" : "RT @Jakob_Err: K\u00F6nnt ihr helfen?\nSuche Praktikum\/Hiwi-Stelle im Bereich (Zell-)Biologie: \nBitte RT http:\/\/t.co\/d4QDl3g2PZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Jakob_Err\/status\/507845338926170112\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/d4QDl3g2PZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bww6pRaIAAEfMzP.png",
        "id_str" : "507845338708049921",
        "id" : 507845338708049921,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bww6pRaIAAEfMzP.png",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 320
        } ],
        "display_url" : "pic.twitter.com\/d4QDl3g2PZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507845338926170112",
    "text" : "K\u00F6nnt ihr helfen?\nSuche Praktikum\/Hiwi-Stelle im Bereich (Zell-)Biologie: \nBitte RT http:\/\/t.co\/d4QDl3g2PZ",
    "id" : 507845338926170112,
    "created_at" : "2014-09-05 10:58:58 +0000",
    "user" : {
      "name" : "Jakob Err",
      "screen_name" : "Jakob_Err",
      "protected" : false,
      "id_str" : "490871541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/597699211891712000\/OYfa6Is9_normal.jpg",
      "id" : 490871541,
      "verified" : false
    }
  },
  "id" : 507851393190096896,
  "created_at" : "2014-09-05 11:23:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/ax7bvKm2Zg",
      "expanded_url" : "http:\/\/www.lrb.co.uk\/v36\/n17\/jenny-diski\/a-diagnosis",
      "display_url" : "lrb.co.uk\/v36\/n17\/jenny-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507816352078643200",
  "text" : "\u00ABbefore I\u2019d properly started out on the cancer road, I\u2019d committed my first platitude.\u00BB http:\/\/t.co\/ax7bvKm2Zg",
  "id" : 507816352078643200,
  "created_at" : "2014-09-05 09:03:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/tV2XNUNHuo",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/faqoHlHyxJs\/lava-lamp-inventor-a-world-wa.html",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507814530081366016",
  "text" : "Lava Lamp inventor: a World War II veteran turned ardent\u00A0nudist http:\/\/t.co\/tV2XNUNHuo",
  "id" : 507814530081366016,
  "created_at" : "2014-09-05 08:56:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 87, 100 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/uYfz8nwTIG",
      "expanded_url" : "http:\/\/www.ploscompbiol.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pcbi.1003825?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ploscompbiol%2FNewArticles+%28PLOS+Computational+Biology+-+New+Articles%29",
      "display_url" : "ploscompbiol.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507812954222657536",
  "text" : "A Probabilistic Model to Predict Clinical Phenotypic Traits from Genome Sequencing \/cc @PhilippBayer  http:\/\/t.co\/uYfz8nwTIG",
  "id" : 507812954222657536,
  "created_at" : "2014-09-05 08:50:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723243673, 8.6274833261 ]
  },
  "id_str" : "507811025958469632",
  "text" : "Still not sure why you wouldn\u2019t throw in some PacBio reads instead of going for the synthetic long reads of Illumina.",
  "id" : 507811025958469632,
  "created_at" : "2014-09-05 08:42:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/sdSvguL0y8",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plosone\/PLoSONE\/~3\/yxZvyKaJZlI\/info%3Adoi%2F10.1371%2Fjournal.pone.0106689",
      "display_url" : "feeds.plos.org\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172324, 8.627483 ]
  },
  "id_str" : "507810698022637568",
  "text" : "Illumina TruSeq Synthetic Long-Reads Empower De Novo Assembly &amp; Resolve Complex, Highly-Repetitive TEs http:\/\/t.co\/sdSvguL0y8",
  "id" : 507810698022637568,
  "created_at" : "2014-09-05 08:41:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 66, 72 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/99ozKNyLjY",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/AyGogHyYc6U\/wall-tiled-with-worn-keyboard.html",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172325, 8.627569 ]
  },
  "id_str" : "507808256279207936",
  "text" : "Room tiled with worn keyboard\u00A0keys. Let's do some room decoration @Lobot!  http:\/\/t.co\/99ozKNyLjY",
  "id" : 507808256279207936,
  "created_at" : "2014-09-05 08:31:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507633675958104064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723248188, 8.6275692545 ]
  },
  "id_str" : "507807972467429376",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer not necessarily. The best assembler would be high n50 with no misassembled contigs, thus length = 0 -&gt; bottom right.",
  "id" : 507807972467429376,
  "in_reply_to_status_id" : 507633675958104064,
  "created_at" : "2014-09-05 08:30:29 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/507512299503226880\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/VEYpY3Ciwj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwsLv05IgAI9H76.png",
      "id_str" : "507512299289346050",
      "id" : 507512299289346050,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwsLv05IgAI9H76.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2099,
        "resize" : "fit",
        "w" : 2096
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2045
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1198
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 679
      } ],
      "display_url" : "pic.twitter.com\/VEYpY3Ciwj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507500075262541825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723207189, 8.6274967835 ]
  },
  "id_str" : "507512299503226880",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer the # of misassemblies doesn\u2019t show too much, but here is \u201Ctotal length of misass. contigs\u201D http:\/\/t.co\/VEYpY3Ciwj",
  "id" : 507512299503226880,
  "in_reply_to_status_id" : 507500075262541825,
  "created_at" : "2014-09-04 12:55:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507498133845073921",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723169566, 8.6275711783 ]
  },
  "id_str" : "507498693504008193",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, okay. No, I meant misassemblies as compared to a known reference, in this case the known truth.",
  "id" : 507498693504008193,
  "in_reply_to_status_id" : 507498133845073921,
  "created_at" : "2014-09-04 12:01:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507497667283259392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723169566, 8.6275711783 ]
  },
  "id_str" : "507498000386887683",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer but by joining two contigs which shouldn\u2019t be joined you are creating misassemblies in comparison to the reference?",
  "id" : 507498000386887683,
  "in_reply_to_status_id" : 507497667283259392,
  "created_at" : "2014-09-04 11:58:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 146 ],
      "url" : "http:\/\/t.co\/NgFZEEInKP",
      "expanded_url" : "http:\/\/quast.bioinf.spbau.ru",
      "display_url" : "quast.bioinf.spbau.ru"
    } ]
  },
  "in_reply_to_status_id_str" : "507495565899206656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723169566, 8.6275711783 ]
  },
  "id_str" : "507496432505733120",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thx, because have a look at the example report here. comparing spades &amp; velvet in misassemblies &amp; n50 http:\/\/t.co\/NgFZEEInKP",
  "id" : 507496432505733120,
  "in_reply_to_status_id" : 507495565899206656,
  "created_at" : "2014-09-04 11:52:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507495104169263104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723211226, 8.6275304131 ]
  },
  "id_str" : "507495502880178176",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ok thx, guess I then will have to think about it for a while. :)",
  "id" : 507495502880178176,
  "in_reply_to_status_id" : 507495104169263104,
  "created_at" : "2014-09-04 11:48:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507493827406352384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723211226, 8.6275304131 ]
  },
  "id_str" : "507494995251982336",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer so in principle I\u2019m looking for a way to normalize # of mismatches for the likelihood of observing them, which grows with N50.",
  "id" : 507494995251982336,
  "in_reply_to_status_id" : 507493827406352384,
  "created_at" : "2014-09-04 11:46:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507493827406352384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723211226, 8.6275304131 ]
  },
  "id_str" : "507494716557258752",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u2026getting the complete chromosome back together with a single inversion would give 100% of assembly as misassembled.",
  "id" : 507494716557258752,
  "in_reply_to_status_id" : 507493827406352384,
  "created_at" : "2014-09-04 11:45:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507493827406352384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723211226, 8.6275304131 ]
  },
  "id_str" : "507494567936262145",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer my completely unassembled set of reads would map to truth without any errors. That would be the one extreme. On the other hand",
  "id" : 507494567936262145,
  "in_reply_to_status_id" : 507493827406352384,
  "created_at" : "2014-09-04 11:45:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507493827406352384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723211226, 8.6275304131 ]
  },
  "id_str" : "507494223349043200",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer working with simulated data I know the truth already. But # of misassemblies of course grows with mean contig length I guess",
  "id" : 507494223349043200,
  "in_reply_to_status_id" : 507493827406352384,
  "created_at" : "2014-09-04 11:43:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 127, 140 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723211226, 8.6275304131 ]
  },
  "id_str" : "507493480240017409",
  "text" : "Is there a good way to compare number of misassemblies of e.g. QUAST? Are highly dependent on other assembly metrics I assume. @PhilippBayer",
  "id" : 507493480240017409,
  "created_at" : "2014-09-04 11:40:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Kitchen Sisters",
      "screen_name" : "kitchensisters",
      "indices" : [ 3, 18 ],
      "id_str" : "16459243",
      "id" : 16459243
    }, {
      "name" : "Carrie Brownstein",
      "screen_name" : "Carrie_Rachel",
      "indices" : [ 20, 34 ],
      "id_str" : "56436152",
      "id" : 56436152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FugitiveWaves",
      "indices" : [ 35, 49 ]
    }, {
      "text" : "PattiSmith",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/C2c3TCbFcQ",
      "expanded_url" : "http:\/\/tinyurl.com\/p49l3hr",
      "display_url" : "tinyurl.com\/p49l3hr"
    } ]
  },
  "geo" : { },
  "id_str" : "507420839109992449",
  "text" : "RT @kitchensisters: @Carrie_Rachel #FugitiveWaves Episode 7:Just Girls:The Hidden World of #PattiSmith Listen here http:\/\/t.co\/C2c3TCbFcQ h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Carrie Brownstein",
        "screen_name" : "Carrie_Rachel",
        "indices" : [ 0, 14 ],
        "id_str" : "56436152",
        "id" : 56436152
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kitchensisters\/status\/507276143351717888\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/vHcYZWsjmo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwo09rKCUAAL-Yh.jpg",
        "id_str" : "507276142194085888",
        "id" : 507276142194085888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwo09rKCUAAL-Yh.jpg",
        "sizes" : [ {
          "h" : 881,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1151,
          "resize" : "fit",
          "w" : 1567
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1151,
          "resize" : "fit",
          "w" : 1567
        } ],
        "display_url" : "pic.twitter.com\/vHcYZWsjmo"
      } ],
      "hashtags" : [ {
        "text" : "FugitiveWaves",
        "indices" : [ 15, 29 ]
      }, {
        "text" : "PattiSmith",
        "indices" : [ 71, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/C2c3TCbFcQ",
        "expanded_url" : "http:\/\/tinyurl.com\/p49l3hr",
        "display_url" : "tinyurl.com\/p49l3hr"
      } ]
    },
    "geo" : { },
    "id_str" : "507276143351717888",
    "in_reply_to_user_id" : 56436152,
    "text" : "@Carrie_Rachel #FugitiveWaves Episode 7:Just Girls:The Hidden World of #PattiSmith Listen here http:\/\/t.co\/C2c3TCbFcQ http:\/\/t.co\/vHcYZWsjmo",
    "id" : 507276143351717888,
    "created_at" : "2014-09-03 21:17:11 +0000",
    "in_reply_to_screen_name" : "Carrie_Rachel",
    "in_reply_to_user_id_str" : "56436152",
    "user" : {
      "name" : "The Kitchen Sisters",
      "screen_name" : "kitchensisters",
      "protected" : false,
      "id_str" : "16459243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525087107002687488\/wzj1a4No_normal.jpeg",
      "id" : 16459243,
      "verified" : false
    }
  },
  "id" : 507420839109992449,
  "created_at" : "2014-09-04 06:52:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "offenbach",
      "indices" : [ 134, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1125020836, 8.749067482 ]
  },
  "id_str" : "507273052942790656",
  "text" : "\u00ABJemand hat ihn Hurensohn &amp; Moppel genannt. Und deshalb wollen sie jetzt die Polizei rufen. So hab ich ihn zumindest verstanden.\u00BB #offenbach",
  "id" : 507273052942790656,
  "created_at" : "2014-09-03 21:04:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723454011, 8.6274763432 ]
  },
  "id_str" : "507172216438788097",
  "text" : "\u00ABGet all the DNA out of urine!\u00BB Sounds like advertising for privacy-conscious fetishists\u2026",
  "id" : 507172216438788097,
  "created_at" : "2014-09-03 14:24:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/ULfiazrDXh",
      "expanded_url" : "http:\/\/i.imgur.com\/OLiAzVH.gif",
      "display_url" : "i.imgur.com\/OLiAzVH.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172334311, 8.6275138871 ]
  },
  "id_str" : "507140119321903104",
  "text" : "the real reason why the slowness of the german customs office bugs me so much. http:\/\/t.co\/ULfiazrDXh",
  "id" : 507140119321903104,
  "created_at" : "2014-09-03 12:16:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507131794102439936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172331756, 8.6274952414 ]
  },
  "id_str" : "507131964902871041",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ich vermute damit hast du gerade viele potentielle K\u00E4ufer davon \u00FCberzeugt es lieber sein zu lassen.",
  "id" : 507131964902871041,
  "in_reply_to_status_id" : 507131794102439936,
  "created_at" : "2014-09-03 11:44:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723469248, 8.6275122905 ]
  },
  "id_str" : "507128428764884994",
  "text" : "\u00ABOh, ist das der \u2018Hut des Neuanfangs\u2019?\u00BB \u2013 \u00ABNein, das neben der \u2018Eule der Weisheit\u2019 ist der \u2018Sexy Hexy-Hut\u2019.\u00BB",
  "id" : 507128428764884994,
  "created_at" : "2014-09-03 11:30:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 126, 139 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723452031, 8.6275205826 ]
  },
  "id_str" : "507087317975445504",
  "text" : "Searching for the best way to extract only uniquely mapping reads from bowtie2 SAMs. Finding a 2 year old biostars Q&amp;A of @PhilippBayer.",
  "id" : 507087317975445504,
  "created_at" : "2014-09-03 08:46:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "encode",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/WOJc9fIMJ5",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plos\/blogs\/main\/~3\/et76EeSl17k\/",
      "display_url" : "feeds.plos.org\/~r\/plos\/blogs\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.115226, 8.750387 ]
  },
  "id_str" : "506942515392811008",
  "text" : "\u00ABHow Much of Your Genome Is Functional?\u00BB The question that doesn't get old. #encode http:\/\/t.co\/WOJc9fIMJ5",
  "id" : 506942515392811008,
  "created_at" : "2014-09-02 23:11:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/wt6sVJjsym",
      "expanded_url" : "http:\/\/www.vanityfair.com\/online\/daily\/2014\/08\/the-farm-born-on-a-commune",
      "display_url" : "vanityfair.com\/online\/daily\/2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.115226, 8.750387 ]
  },
  "id_str" : "506941843171721216",
  "text" : "What Life Is Like When You\u2019re Born on a Commune http:\/\/t.co\/wt6sVJjsym",
  "id" : 506941843171721216,
  "created_at" : "2014-09-02 23:08:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1114698479, 8.7501110451 ]
  },
  "id_str" : "506936662874947584",
  "text" : "\u00ABWenn ich von der Terrasse aus twittere sagt der Geotag 'Offenbach', von unserem Bett aus 'Frankfurt'.\u00BB",
  "id" : 506936662874947584,
  "created_at" : "2014-09-02 22:48:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506934692978118657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1112691756, 8.7498839389 ]
  },
  "id_str" : "506935825809289217",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU dann musst du mal auf Heimaturlaub welchen mitbringen ;)",
  "id" : 506935825809289217,
  "in_reply_to_status_id" : 506934692978118657,
  "created_at" : "2014-09-02 22:44:53 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1113250962, 8.7498928491 ]
  },
  "id_str" : "506934543820283904",
  "text" : "\u00ABGegen was hast du eigentlich in deiner Jugend demonstriert?\u00BB\u2014\u00ABDen Irakkrieg.\u00BB\u2014\u00ABIch in meiner auch! Bei mir war es allerdings der Zweite.\u00BB",
  "id" : 506934543820283904,
  "created_at" : "2014-09-02 22:39:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 102, 115 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506928487593410560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114801433, 8.7534138467 ]
  },
  "id_str" : "506933166029172737",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch nein, keine Ahnung. Aber danke f\u00FCrs k\u00FCmmern. K\u00F6nnten jetzt auch den Umzug zu AWS planen. @PhilippBayer",
  "id" : 506933166029172737,
  "in_reply_to_status_id" : 506928487593410560,
  "created_at" : "2014-09-02 22:34:19 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506923259406061571",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1145076633, 8.7531416515 ]
  },
  "id_str" : "506933036689416192",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU wo ist denn vorbei? :)",
  "id" : 506933036689416192,
  "in_reply_to_status_id" : 506923259406061571,
  "created_at" : "2014-09-02 22:33:48 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yolo",
      "indices" : [ 50, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/wLsxyYoNQD",
      "expanded_url" : "http:\/\/instagram.com\/p\/sdJGzThwrU\/",
      "display_url" : "instagram.com\/p\/sdJGzThwrU\/"
    } ]
  },
  "geo" : { },
  "id_str" : "506890785200275457",
  "text" : "Hauptsache das Internet in der neuen Wohnung geht #yolo http:\/\/t.co\/wLsxyYoNQD",
  "id" : 506890785200275457,
  "created_at" : "2014-09-02 19:45:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506856748935024641",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11655277, 8.74927711 ]
  },
  "id_str" : "506856927138414593",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch ja, der Webserver ist zumindest unerreichbar und auf mein ssh reagierte es gerade auch nicht.",
  "id" : 506856927138414593,
  "in_reply_to_status_id" : 506856748935024641,
  "created_at" : "2014-09-02 17:31:23 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1165527704, 8.7492771093 ]
  },
  "id_str" : "506848080730554368",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch k\u00F6nntest du den Restart veranlassen? Ich komm gar nicht drauf atm und hab das PW nicht zur Hand.",
  "id" : 506848080730554368,
  "created_at" : "2014-09-02 16:56:13 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506809745416937473",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.19964438, 8.58240211 ]
  },
  "id_str" : "506810976310943745",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog am 6. Tag die restlichen Tiere, am 7. Tag den Sequencer?",
  "id" : 506810976310943745,
  "in_reply_to_status_id" : 506809745416937473,
  "created_at" : "2014-09-02 14:28:47 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506808362944974848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.19964438, 8.58240211 ]
  },
  "id_str" : "506809215542104064",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog sanger sequencing ;)",
  "id" : 506809215542104064,
  "in_reply_to_status_id" : 506808362944974848,
  "created_at" : "2014-09-02 14:21:47 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/87U6MJ0MFK",
      "expanded_url" : "http:\/\/theappendix.net\/issues\/2014\/7\/present-tense-future-perfect-protest-and-progress-at-the-1964-worlds-fair",
      "display_url" : "theappendix.net\/issues\/2014\/7\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "506787081482690560",
  "text" : "\u00ABgood civil disobedience is always experienced as disruption.\u00BB \u2013 Protest and Progress at the 1964 World\u2019s Fair http:\/\/t.co\/87U6MJ0MFK",
  "id" : 506787081482690560,
  "created_at" : "2014-09-02 12:53:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723340578, 8.6275829353 ]
  },
  "id_str" : "506765288277565440",
  "text" : "\u00ABDarf ich mir eigentlich mal deine Freundin zum Haare f\u00E4rben ausleihen?\u00BB",
  "id" : 506765288277565440,
  "created_at" : "2014-09-02 11:27:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723251111, 8.6275121989 ]
  },
  "id_str" : "506756892614742016",
  "text" : "\u00ABIch hab noch so krasses Kopfkino vom Wochenende. Und es kommen fast keine Autos darin vor, wei\u00DFte Bescheid.\u00BB",
  "id" : 506756892614742016,
  "created_at" : "2014-09-02 10:53:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/ZskppF8IuI",
      "expanded_url" : "http:\/\/www.newstatesman.com\/future-proof\/2014\/08\/tropes-vs-anita-sarkeesian-passing-anti-feminist-nonsense-critique",
      "display_url" : "newstatesman.com\/future-proof\/2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233, 8.62751 ]
  },
  "id_str" : "506742720288030720",
  "text" : "Tropes vs Anita Sarkeesian: on passing off anti-feminist nonsense as critique http:\/\/t.co\/ZskppF8IuI",
  "id" : 506742720288030720,
  "created_at" : "2014-09-02 09:57:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 36, 52 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/4Y41Fko2RF",
      "expanded_url" : "http:\/\/kleinanzeigen.ebay.de\/anzeigen\/s-anzeige\/macbook-pro,-early-2011,-mattes-15-zoll-display\/235867348-278-4354",
      "display_url" : "kleinanzeigen.ebay.de\/anzeigen\/s-anz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "506720283903135744",
  "text" : "RT @Lobot: Aktion \u00ABSchickermoos f\u00FCr @gedankenstuecke\u00BB http:\/\/t.co\/4Y41Fko2RF (Super MacBook Pro zu verkaufen! Nur ein bisschen verbogen!)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 25, 41 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/4Y41Fko2RF",
        "expanded_url" : "http:\/\/kleinanzeigen.ebay.de\/anzeigen\/s-anzeige\/macbook-pro,-early-2011,-mattes-15-zoll-display\/235867348-278-4354",
        "display_url" : "kleinanzeigen.ebay.de\/anzeigen\/s-anz\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "506718808015634432",
    "text" : "Aktion \u00ABSchickermoos f\u00FCr @gedankenstuecke\u00BB http:\/\/t.co\/4Y41Fko2RF (Super MacBook Pro zu verkaufen! Nur ein bisschen verbogen!)",
    "id" : 506718808015634432,
    "created_at" : "2014-09-02 08:22:32 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 506720283903135744,
  "created_at" : "2014-09-02 08:28:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506712094780440576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723616141, 8.6275111288 ]
  },
  "id_str" : "506712571844784129",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot but I got my work done! ;)",
  "id" : 506712571844784129,
  "in_reply_to_status_id" : 506712094780440576,
  "created_at" : "2014-09-02 07:57:46 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/rDDRTc8DaW",
      "expanded_url" : "http:\/\/instagram.com\/p\/sautwYhwiP\/",
      "display_url" : "instagram.com\/p\/sautwYhwiP\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172192593, 8.630112991 ]
  },
  "id_str" : "506551276172505088",
  "text" : "and now do the unicorn! @ Goethe-Universit\u00E4t Frankfurt, Campus Riedberg http:\/\/t.co\/rDDRTc8DaW",
  "id" : 506551276172505088,
  "created_at" : "2014-09-01 21:16:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724144132, 8.6272449123 ]
  },
  "id_str" : "506536583349436416",
  "text" : "How to make up for a week of vacation in two hours: have six cups of coffee\u2026",
  "id" : 506536583349436416,
  "created_at" : "2014-09-01 20:18:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0382966273, 8.5429075918 ]
  },
  "id_str" : "506390611533266944",
  "text" : "And I guess this concludes one of the most surreal journeys I've done so far.",
  "id" : 506390611533266944,
  "created_at" : "2014-09-01 10:38:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506345370465873920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0382085087, 8.5430810469 ]
  },
  "id_str" : "506390383723814912",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach and again ;)",
  "id" : 506390383723814912,
  "in_reply_to_status_id" : 506345370465873920,
  "created_at" : "2014-09-01 10:37:30 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.3499138328, 30.8981649447 ]
  },
  "id_str" : "506344102078984192",
  "text" : "\u00ABWhat do you mean? It's not called red eye flight because we will both cry that much when I'll leave for the airport?\u00BB",
  "id" : 506344102078984192,
  "created_at" : "2014-09-01 07:33:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506332575917699073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.3483109117, 30.8994994663 ]
  },
  "id_str" : "506335001257197568",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon nein, die Ausreisegenehmigung bekommen. ;)",
  "id" : 506335001257197568,
  "in_reply_to_status_id" : 506332575917699073,
  "created_at" : "2014-09-01 06:57:26 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506331314438799360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.3499020312, 30.8981411855 ]
  },
  "id_str" : "506332311802355712",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon der kritischste Teil ist geschafft ;)",
  "id" : 506332311802355712,
  "in_reply_to_status_id" : 506331314438799360,
  "created_at" : "2014-09-01 06:46:44 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/orKXjujY5T",
      "expanded_url" : "http:\/\/instagram.com\/p\/sZKX7shwnl\/",
      "display_url" : "instagram.com\/p\/sZKX7shwnl\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.349951908, 30.898193219 ]
  },
  "id_str" : "506330622907146240",
  "text" : "Limbo @ Gate D12 http:\/\/t.co\/orKXjujY5T",
  "id" : 506330622907146240,
  "created_at" : "2014-09-01 06:40:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/boub5AHQLf",
      "expanded_url" : "http:\/\/instagram.com\/p\/sZGVC-BwkA\/",
      "display_url" : "instagram.com\/p\/sZGVC-BwkA\/"
    } ]
  },
  "geo" : { },
  "id_str" : "506321728314671104",
  "text" : "90 minutes to go. http:\/\/t.co\/boub5AHQLf",
  "id" : 506321728314671104,
  "created_at" : "2014-09-01 06:04:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0025158658, 34.8726056154 ]
  },
  "id_str" : "506247393344385025",
  "text" : "\u00ABSo you need to get duplicates of each gift you bring home?\u00BB \u2013 \u00ABYep, \u2018bring two of every kind\u2019, you might have heard the story.\u00BB",
  "id" : 506247393344385025,
  "created_at" : "2014-09-01 01:09:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0034925829, 34.8726180294 ]
  },
  "id_str" : "506242535576989696",
  "text" : "Airports, where Borges and Kafka meet to wonder about surrealism.",
  "id" : 506242535576989696,
  "created_at" : "2014-09-01 00:50:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/DTCOMyWtUG",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plosone\/PLoSONE\/~3\/udocdSVTdbk\/info%3Adoi%2F10.1371%2Fjournal.pone.0105856",
      "display_url" : "feeds.plos.org\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "506237408258437120",
  "text" : "The Expression of Pre- and Postcopulatory Sexually Selected Traits Reflects Levels of Dietary Stress in Guppies http:\/\/t.co\/DTCOMyWtUG",
  "id" : 506237408258437120,
  "created_at" : "2014-09-01 00:29:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]