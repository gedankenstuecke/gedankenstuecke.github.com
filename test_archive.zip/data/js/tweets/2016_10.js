Grailbird.data.tweets_2016_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/ZkYGqCJ4SW",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BMPZHhWjyD-\/",
      "display_url" : "instagram.com\/p\/BMPZHhWjyD-\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5356, -0.125 ]
  },
  "id_str" : "793186048746676224",
  "text" : "London knows how to make me fall in love with it even more. @ Granary Square https:\/\/t.co\/ZkYGqCJ4SW",
  "id" : 793186048746676224,
  "created_at" : "2016-10-31 20:21:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793182633731645440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46919943114045, -0.44767658962327 ]
  },
  "id_str" : "793182787759071232",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke seriously, next time I\u2019ll fly out to Hawaii from Mozfest.",
  "id" : 793182787759071232,
  "in_reply_to_status_id" : 793182633731645440,
  "created_at" : "2016-10-31 20:08:07 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793180043627421696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4696497761996, -0.4484856965666009 ]
  },
  "id_str" : "793180198707556352",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik time to organize a conference there then :D",
  "id" : 793180198707556352,
  "in_reply_to_status_id" : 793180043627421696,
  "created_at" : "2016-10-31 19:57:50 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793178529345200129",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4697264861713, -0.448006258608205 ]
  },
  "id_str" : "793179308097413120",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik hope we can meet in Edinburgh at some point!",
  "id" : 793179308097413120,
  "in_reply_to_status_id" : 793178529345200129,
  "created_at" : "2016-10-31 19:54:18 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 51, 58 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46952024171758, -0.4475111932278105 ]
  },
  "id_str" : "793178101261930496",
  "text" : "One of the best parts of #MozFest: finally meeting @sujaik in person.",
  "id" : 793178101261930496,
  "created_at" : "2016-10-31 19:49:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Hohner",
      "screen_name" : "janhohner",
      "indices" : [ 0, 10 ],
      "id_str" : "114832665",
      "id" : 114832665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793174709072453633",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46969003265649, -0.4481867562117932 ]
  },
  "id_str" : "793175074807357441",
  "in_reply_to_user_id" : 114832665,
  "text" : "@janhohner ah, LH919 LHR\u2708\uFE0FFRA here. Let me know if you get stuck in Frankfurt, can host even in absentia ;)",
  "id" : 793175074807357441,
  "in_reply_to_status_id" : 793174709072453633,
  "created_at" : "2016-10-31 19:37:28 +0000",
  "in_reply_to_screen_name" : "janhohner",
  "in_reply_to_user_id_str" : "114832665",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Hohner",
      "screen_name" : "janhohner",
      "indices" : [ 0, 10 ],
      "id_str" : "114832665",
      "id" : 114832665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793173589751103488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.47014740518517, -0.4479312042084655 ]
  },
  "id_str" : "793174040986980353",
  "in_reply_to_user_id" : 114832665,
  "text" : "@janhohner Frankfurt too, on a LH flight. Scheduled for 1930, now at 2050.",
  "id" : 793174040986980353,
  "in_reply_to_status_id" : 793173589751103488,
  "created_at" : "2016-10-31 19:33:22 +0000",
  "in_reply_to_screen_name" : "janhohner",
  "in_reply_to_user_id_str" : "114832665",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46969900856298, -0.4474809442193017 ]
  },
  "id_str" : "793164603756781568",
  "text" : "Of course my flight out of London has been delayed. Being unable to leave #MozFest seems to become a tradition as well.",
  "id" : 793164603756781568,
  "created_at" : "2016-10-31 18:55:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/MaehcPptti",
      "expanded_url" : "https:\/\/twitter.com\/sujaik\/status\/793041332528934913",
      "display_url" : "twitter.com\/sujaik\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50944580794452, -0.08983413688846847 ]
  },
  "id_str" : "793044488528723969",
  "text" : "Protection is important for the polychargerous. https:\/\/t.co\/MaehcPptti",
  "id" : 793044488528723969,
  "created_at" : "2016-10-31 10:58:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793041645524684800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50524504953204, -0.08583244867630846 ]
  },
  "id_str" : "793042034621808640",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics whops, fixed that.",
  "id" : 793042034621808640,
  "in_reply_to_status_id" : 793041645524684800,
  "created_at" : "2016-10-31 10:48:49 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/793039938455560192\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/jVE2F2O7Cs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwFxnLfXYAEoppH.jpg",
      "id_str" : "793039927307100161",
      "id" : 793039927307100161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwFxnLfXYAEoppH.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/jVE2F2O7Cs"
    } ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50513020209102, -0.08505503601042297 ]
  },
  "id_str" : "793039938455560192",
  "text" : "I found the secret key of the order of balance in one of my pockets this morning. #MozFest https:\/\/t.co\/jVE2F2O7Cs",
  "id" : 793039938455560192,
  "created_at" : "2016-10-31 10:40:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/CoWXqVeuaQ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BMOOtqvDO2h\/",
      "display_url" : "instagram.com\/p\/BMOOtqvDO2h\/"
    } ]
  },
  "geo" : { },
  "id_str" : "793022432189743104",
  "text" : "Where did the Shard go? https:\/\/t.co\/CoWXqVeuaQ",
  "id" : 793022432189743104,
  "created_at" : "2016-10-31 09:30:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 7, 17 ],
      "id_str" : "186529934",
      "id" : 186529934
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 18, 25 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 30, 38 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/4FT6a8bXtU",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/792757566602436609",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "792757566602436609",
  "geo" : { },
  "id_str" : "792757771460575233",
  "in_reply_to_user_id" : 14286491,
  "text" : "Thanks @auremoser @sujaik and @Seplute and all others for the great session! #mozfest https:\/\/t.co\/4FT6a8bXtU",
  "id" : 792757771460575233,
  "in_reply_to_status_id" : 792757566602436609,
  "created_at" : "2016-10-30 15:59:16 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/792757566602436609\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ZU1Y6Db6Xk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwBwy7rWEAANgr7.jpg",
      "id_str" : "792757554732470272",
      "id" : 792757554732470272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwBwy7rWEAANgr7.jpg",
      "sizes" : [ {
        "h" : 636,
        "resize" : "fit",
        "w" : 1130
      }, {
        "h" : 636,
        "resize" : "fit",
        "w" : 1130
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 636,
        "resize" : "fit",
        "w" : 1130
      } ],
      "display_url" : "pic.twitter.com\/ZU1Y6Db6Xk"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/792757566602436609\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ZU1Y6Db6Xk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwBwzWDWEAEjO5W.jpg",
      "id_str" : "792757561812455425",
      "id" : 792757561812455425,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwBwzWDWEAEjO5W.jpg",
      "sizes" : [ {
        "h" : 564,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 564,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 564,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 564,
        "resize" : "fit",
        "w" : 658
      } ],
      "display_url" : "pic.twitter.com\/ZU1Y6Db6Xk"
    } ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792757566602436609",
  "text" : "The Nerdcator session went great. We have a prototype. Find us at the demo later today to enter your data! #mozfest https:\/\/t.co\/ZU1Y6Db6Xk",
  "id" : 792757566602436609,
  "created_at" : "2016-10-30 15:58:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/792703337418387456\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/w3jHQkwHFQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwA_e72WYAEwD8M.jpg",
      "id_str" : "792703335111483393",
      "id" : 792703335111483393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwA_e72WYAEwD8M.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/w3jHQkwHFQ"
    } ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/zKNKqLAY6v",
      "expanded_url" : "https:\/\/github.com\/auremoser\/nerdcator",
      "display_url" : "github.com\/auremoser\/nerd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792703337418387456",
  "text" : "Visit our session on scientific sightseeing today at 2pm on floor 9. https:\/\/t.co\/zKNKqLAY6v #mozfest https:\/\/t.co\/w3jHQkwHFQ",
  "id" : 792703337418387456,
  "created_at" : "2016-10-30 12:22:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 9, 16 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792699232192958464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50179857578531, 0.005286968555219438 ]
  },
  "id_str" : "792699383531839489",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute @sujaik appear.in",
  "id" : 792699383531839489,
  "in_reply_to_status_id" : 792699232192958464,
  "created_at" : "2016-10-30 12:07:15 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792673538742317056",
  "geo" : { },
  "id_str" : "792673628257214464",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute will do, after i\u2019ve finished that data analysis here :)",
  "id" : 792673628257214464,
  "in_reply_to_status_id" : 792673538742317056,
  "created_at" : "2016-10-30 10:24:54 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruud Steltenpool",
      "screen_name" : "steltenpower",
      "indices" : [ 0, 13 ],
      "id_str" : "76693160",
      "id" : 76693160
    }, {
      "name" : "Sid Rao",
      "screen_name" : "sidnext2none",
      "indices" : [ 25, 38 ],
      "id_str" : "357642770",
      "id" : 357642770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792662768767868928",
  "geo" : { },
  "id_str" : "792673320709787649",
  "in_reply_to_user_id" : 76693160,
  "text" : "@steltenpower If you ask @sidnext2none a question he might just give you one. At least that was the deal on Friday :D",
  "id" : 792673320709787649,
  "in_reply_to_status_id" : 792662768767868928,
  "created_at" : "2016-10-30 10:23:41 +0000",
  "in_reply_to_screen_name" : "steltenpower",
  "in_reply_to_user_id_str" : "76693160",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 3, 18 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    }, {
      "name" : "Sid Rao",
      "screen_name" : "sidnext2none",
      "indices" : [ 26, 39 ],
      "id_str" : "357642770",
      "id" : 357642770
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/792656855201964036\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/PMPbTUNqcM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwAVMbfXEAAwalF.jpg",
      "id_str" : "792656837699112960",
      "id" : 792656837699112960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwAVMbfXEAAwalF.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PMPbTUNqcM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50045642634062, 0.004228167235855226 ]
  },
  "id_str" : "792656855201964036",
  "text" : "My @MozOpenLeaders mentee @sidnext2none is taking good care of me, protecting me with a USB condom. https:\/\/t.co\/PMPbTUNqcM",
  "id" : 792656855201964036,
  "created_at" : "2016-10-30 09:18:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Ross",
      "screen_name" : "sw1ayfe",
      "indices" : [ 0, 8 ],
      "id_str" : "585100333",
      "id" : 585100333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792642761380036608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50501924346359, -0.08183013128046454 ]
  },
  "id_str" : "792646925040422912",
  "in_reply_to_user_id" : 585100333,
  "text" : "@sw1ayfe and then there was the dancing! \uD83D\uDC83",
  "id" : 792646925040422912,
  "in_reply_to_status_id" : 792642761380036608,
  "created_at" : "2016-10-30 08:38:48 +0000",
  "in_reply_to_screen_name" : "sw1ayfe",
  "in_reply_to_user_id_str" : "585100333",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792638030456745984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50495945070049, -0.08131791262475112 ]
  },
  "id_str" : "792638498381697024",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima thanks! \uD83D\uDC96",
  "id" : 792638498381697024,
  "in_reply_to_status_id" : 792638030456745984,
  "created_at" : "2016-10-30 08:05:19 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/pHWKvkEHOf",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/science\/comments\/59p98b\/rscience_the_winnower_and_authorea_are_having_an\/d9adg44\/",
      "display_url" : "reddit.com\/r\/science\/comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792635317849161728",
  "text" : "I think you can still vote for my contribution on how social media is beneficial to scientists by upvoting this \uD83D\uDC36\uD83D\uDC40 \uD83C\uDF89 https:\/\/t.co\/pHWKvkEHOf",
  "id" : 792635317849161728,
  "created_at" : "2016-10-30 07:52:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gepflegte Langeweile",
      "screen_name" : "krasserTerror",
      "indices" : [ 0, 14 ],
      "id_str" : "38024593",
      "id" : 38024593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792529927761461248",
  "geo" : { },
  "id_str" : "792530519602987008",
  "in_reply_to_user_id" : 38024593,
  "text" : "@krasserTerror that\u2019s a step I skipped. But I still have the F11 key they gave me at the entrance to the secret HQ.",
  "id" : 792530519602987008,
  "in_reply_to_status_id" : 792529927761461248,
  "created_at" : "2016-10-30 00:56:15 +0000",
  "in_reply_to_screen_name" : "krasserTerror",
  "in_reply_to_user_id_str" : "38024593",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Jenny Molloy",
      "screen_name" : "jenny_molloy",
      "indices" : [ 8, 21 ],
      "id_str" : "252245569",
      "id" : 252245569
    }, {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 22, 35 ],
      "id_str" : "478181304",
      "id" : 478181304
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 36, 44 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Lucy Crompton-Reid",
      "screen_name" : "lcromptonreid",
      "indices" : [ 45, 59 ],
      "id_str" : "37237125",
      "id" : 37237125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792510114569781248",
  "geo" : { },
  "id_str" : "792510746550792192",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @jenny_molloy @Mcarthur_Joe @Seplute @lcromptonreid I found eggsploit also quite good!",
  "id" : 792510746550792192,
  "in_reply_to_status_id" : 792510114569781248,
  "created_at" : "2016-10-29 23:37:40 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Jenny Molloy",
      "screen_name" : "jenny_molloy",
      "indices" : [ 8, 21 ],
      "id_str" : "252245569",
      "id" : 252245569
    }, {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 22, 35 ],
      "id_str" : "478181304",
      "id" : 478181304
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 36, 44 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Lucy Crompton-Reid",
      "screen_name" : "lcromptonreid",
      "indices" : [ 45, 59 ],
      "id_str" : "37237125",
      "id" : 37237125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792509481821343748",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50496904119977, -0.08129477602406893 ]
  },
  "id_str" : "792509770808848384",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @jenny_molloy @Mcarthur_Joe @Seplute @lcromptonreid I always thought about the twitter eggs when the topic came up.",
  "id" : 792509770808848384,
  "in_reply_to_status_id" : 792509481821343748,
  "created_at" : "2016-10-29 23:33:48 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 4, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50490457365641, -0.08140482581662827 ]
  },
  "id_str" : "792509359179825157",
  "text" : "So, #MozFest did make me wear my socks inside-out, follow a monk, explore the dark web and dance. I have no regrets.",
  "id" : 792509359179825157,
  "created_at" : "2016-10-29 23:32:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua McClure",
      "screen_name" : "joshuamcclure",
      "indices" : [ 0, 14 ],
      "id_str" : "14209307",
      "id" : 14209307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792421496396230657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50669059838063, -0.07915780244649154 ]
  },
  "id_str" : "792421671101685760",
  "in_reply_to_user_id" : 14209307,
  "text" : "@joshuamcclure in London, part of Mozfest.",
  "id" : 792421671101685760,
  "in_reply_to_status_id" : 792421496396230657,
  "created_at" : "2016-10-29 17:43:43 +0000",
  "in_reply_to_screen_name" : "joshuamcclure",
  "in_reply_to_user_id_str" : "14209307",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/yseOKHrGhO",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BMJ81zPjTrB\/",
      "display_url" : "instagram.com\/p\/BMJ81zPjTrB\/"
    } ]
  },
  "geo" : { },
  "id_str" : "792420179347111936",
  "text" : "Always follow your monk. https:\/\/t.co\/yseOKHrGhO",
  "id" : 792420179347111936,
  "created_at" : "2016-10-29 17:37:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5020263036426, 0.007793627544606554 ]
  },
  "id_str" : "792409139515457536",
  "text" : "My colleagues already always made fun of me for being in the open* cult. Now I\u2019m following a monk in a black robe through London. #MozFest",
  "id" : 792409139515457536,
  "created_at" : "2016-10-29 16:53:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uA9C1Terence Eden\uA9C2 \u23FB",
      "screen_name" : "edent",
      "indices" : [ 0, 6 ],
      "id_str" : "14054507",
      "id" : 14054507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/wwfIbNTCWg",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/792338617179996162",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50180082843886, 0.005268798654726826 ]
  },
  "id_str" : "792347057679990784",
  "in_reply_to_user_id" : 14054507,
  "text" : "@edent thanks for the lovely session. https:\/\/t.co\/wwfIbNTCWg",
  "id" : 792347057679990784,
  "created_at" : "2016-10-29 12:47:14 +0000",
  "in_reply_to_screen_name" : "edent",
  "in_reply_to_user_id_str" : "14054507",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50180615929379, 0.00525285415936492 ]
  },
  "id_str" : "792345664290250752",
  "text" : "\u00ABIn the future people will say, \u2018Granny, why did you sent Grandpa all these \uD83C\uDF46? Did you like Baba Ghanoush really that much?\u2019.\u00BB #MozFest",
  "id" : 792345664290250752,
  "created_at" : "2016-10-29 12:41:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50180726304963, 0.005265035872583416 ]
  },
  "id_str" : "792344587469725696",
  "text" : "\u00ABUnicode is inherently political and racist.\u00BB On what is getting encoded and what isn\u2019t. #MozFest",
  "id" : 792344587469725696,
  "created_at" : "2016-10-29 12:37:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/792338617179996162\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/0gUtj2OMMA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv7zwJsW8AAVkOs.jpg",
      "id_str" : "792338593025028096",
      "id" : 792338593025028096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv7zwJsW8AAVkOs.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/0gUtj2OMMA"
    } ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50180059834489, 0.00526994561981768 ]
  },
  "id_str" : "792338617179996162",
  "text" : "Learning about emoji at #MozFest \uD83C\uDF89\uD83D\uDCA9 https:\/\/t.co\/0gUtj2OMMA",
  "id" : 792338617179996162,
  "created_at" : "2016-10-29 12:13:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 15, 21 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792326925624680448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50181057881448, 0.005239939613550333 ]
  },
  "id_str" : "792329087876472832",
  "in_reply_to_user_id" : 2968079445,
  "text" : "@AnneAdamPluen @shefw always important to have a portrait picture for those ;)",
  "id" : 792329087876472832,
  "in_reply_to_status_id" : 792326925624680448,
  "created_at" : "2016-10-29 11:35:49 +0000",
  "in_reply_to_screen_name" : "AnneHTTP404",
  "in_reply_to_user_id_str" : "2968079445",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792328566818111488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50181057881448, 0.005239939613550333 ]
  },
  "id_str" : "792328997476659200",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw I will make sure it sticks this time :)",
  "id" : 792328997476659200,
  "in_reply_to_status_id" : 792328566818111488,
  "created_at" : "2016-10-29 11:35:28 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 85, 91 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/792326651392716800\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/KZ9p0CEhMH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv7o2teXgAAh5GC.jpg",
      "id_str" : "792326611081330688",
      "id" : 792326611081330688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv7o2teXgAAh5GC.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/KZ9p0CEhMH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Zjp2cmL67w",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/792322921725386752",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "792322921725386752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5018007515861, 0.005243662664484491 ]
  },
  "id_str" : "792326651392716800",
  "in_reply_to_user_id" : 14286491,
  "text" : "And that\u2019s so sweet. My new mind even has an area for seeing lichens. Thanks so much @shefw \uD83C\uDF89\uD83D\uDC96\uD83D\uDC9D https:\/\/t.co\/Zjp2cmL67w https:\/\/t.co\/KZ9p0CEhMH",
  "id" : 792326651392716800,
  "in_reply_to_status_id" : 792322921725386752,
  "created_at" : "2016-10-29 11:26:09 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 38, 44 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/792322921725386752\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/YZyGJSlX6l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv7lfZ0XgAAGRCO.jpg",
      "id_str" : "792322912133021696",
      "id" : 792322912133021696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv7lfZ0XgAAGRCO.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/YZyGJSlX6l"
    } ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50179446482581, 0.005332491216848209 ]
  },
  "id_str" : "792322921725386752",
  "text" : "I lost my mind yesterday. The awesome @shefw made me a new one! #MozFest https:\/\/t.co\/YZyGJSlX6l",
  "id" : 792322921725386752,
  "created_at" : "2016-10-29 11:11:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 3, 13 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kaythaney\/status\/792296599678492672\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/jB9N3EEkTA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv7NjV7XEAAYfrz.jpg",
      "id_str" : "792296591529021440",
      "id" : 792296591529021440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv7NjV7XEAAYfrz.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/jB9N3EEkTA"
    } ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792322311106007040",
  "text" : "RT @kaythaney: Want to learn about Open Leadership? Visit Ryan on floor 9! \uD83D\uDC4D\uD83C\uDFFC\uD83D\uDC4D\uD83C\uDFFD #mozfest https:\/\/t.co\/jB9N3EEkTA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kaythaney\/status\/792296599678492672\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/jB9N3EEkTA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv7NjV7XEAAYfrz.jpg",
        "id_str" : "792296591529021440",
        "id" : 792296591529021440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv7NjV7XEAAYfrz.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/jB9N3EEkTA"
      } ],
      "hashtags" : [ {
        "text" : "mozfest",
        "indices" : [ 65, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792296599678492672",
    "text" : "Want to learn about Open Leadership? Visit Ryan on floor 9! \uD83D\uDC4D\uD83C\uDFFC\uD83D\uDC4D\uD83C\uDFFD #mozfest https:\/\/t.co\/jB9N3EEkTA",
    "id" : 792296599678492672,
    "created_at" : "2016-10-29 09:26:44 +0000",
    "user" : {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "protected" : false,
      "id_str" : "22839233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932288468029509632\/_I0e0wgc_normal.jpg",
      "id" : 22839233,
      "verified" : false
    }
  },
  "id" : 792322311106007040,
  "created_at" : "2016-10-29 11:08:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792315162959212544",
  "geo" : { },
  "id_str" : "792315504832684032",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps that one I do find much much harder than pseudonymous.",
  "id" : 792315504832684032,
  "in_reply_to_status_id" : 792315162959212544,
  "created_at" : "2016-10-29 10:41:51 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 3, 12 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792315225806692353",
  "text" : "RT @MsPhelps: @gedankenstuecke And then on to level 2: 'operationalization' ;-) #mozfest",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mozfest",
        "indices" : [ 66, 74 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "792314679574093824",
    "geo" : { },
    "id_str" : "792315162959212544",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke And then on to level 2: 'operationalization' ;-) #mozfest",
    "id" : 792315162959212544,
    "in_reply_to_status_id" : 792314679574093824,
    "created_at" : "2016-10-29 10:40:30 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "protected" : false,
      "id_str" : "22963112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665529153576390660\/ukieWtR4_normal.jpg",
      "id" : 22963112,
      "verified" : false
    }
  },
  "id" : 792315225806692353,
  "created_at" : "2016-10-29 10:40:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792314679574093824",
  "text" : "Applied Data Sharing Advice: \u00ABAnd now everyone pronounce \u2018pseudonymous\u2019 5 times in a row, fast.\u00BB #MozFest",
  "id" : 792314679574093824,
  "created_at" : "2016-10-29 10:38:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/792310649657360384\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/EbgpHfwzD8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv7aUQmWEAAd6mL.jpg",
      "id_str" : "792310626051821568",
      "id" : 792310626051821568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv7aUQmWEAAd6mL.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/EbgpHfwzD8"
    } ],
    "hashtags" : [ {
      "text" : "Mozfest",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50179816033597, 0.005288315779150871 ]
  },
  "id_str" : "792310649657360384",
  "text" : "Design for sharing medical \u201Cdata\u201D: Organ donors in Austria vs Germany #Mozfest https:\/\/t.co\/EbgpHfwzD8",
  "id" : 792310649657360384,
  "created_at" : "2016-10-29 10:22:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 33, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/Sj1UAb39Lx",
      "expanded_url" : "https:\/\/twitter.com\/WhoIsTerror\/status\/792305718384820224",
      "display_url" : "twitter.com\/WhoIsTerror\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50179929761029, 0.005301914722977371 ]
  },
  "id_str" : "792309214253289472",
  "text" : "I\u2019ve accidentally become terror! #MozFest https:\/\/t.co\/Sj1UAb39Lx",
  "id" : 792309214253289472,
  "created_at" : "2016-10-29 10:16:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50180456326072, 0.005268856029023421 ]
  },
  "id_str" : "792286901260656640",
  "text" : "\u00ABDoing the scary face for the group photo is the best part of the whole weekend\u00BB\u2014\u00ABYeah, it\u2019s all downhill from here. Let\u2019s go home\u00BB #mozfest",
  "id" : 792286901260656640,
  "created_at" : "2016-10-29 08:48:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 8, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50179877994528, 0.005252313461860614 ]
  },
  "id_str" : "792279369540595712",
  "text" : "Back to #MozFest \uD83C\uDF89\uD83C\uDF8A",
  "id" : 792279369540595712,
  "created_at" : "2016-10-29 08:18:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 60, 72 ],
      "id_str" : "748018813",
      "id" : 748018813
    }, {
      "name" : "Authorea",
      "screen_name" : "authorea",
      "indices" : [ 73, 82 ],
      "id_str" : "483986116",
      "id" : 483986116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/pHWKvkn6WH",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/science\/comments\/59p98b\/rscience_the_winnower_and_authorea_are_having_an\/d9adg44\/",
      "display_url" : "reddit.com\/r\/science\/comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792016135147364352",
  "text" : "RT @gedankenstuecke: Are on reddit and wanna help me in the @theWinnower\/@authorea contest? Up vote here please. https:\/\/t.co\/pHWKvkn6WH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "the Winnower",
        "screen_name" : "theWinnower",
        "indices" : [ 39, 51 ],
        "id_str" : "748018813",
        "id" : 748018813
      }, {
        "name" : "Authorea",
        "screen_name" : "authorea",
        "indices" : [ 52, 61 ],
        "id_str" : "483986116",
        "id" : 483986116
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/pHWKvkn6WH",
        "expanded_url" : "https:\/\/www.reddit.com\/r\/science\/comments\/59p98b\/rscience_the_winnower_and_authorea_are_having_an\/d9adg44\/",
        "display_url" : "reddit.com\/r\/science\/comm\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 51.47016536850636, -0.4418614700881169 ]
    },
    "id_str" : "791752413925482496",
    "text" : "Are on reddit and wanna help me in the @theWinnower\/@authorea contest? Up vote here please. https:\/\/t.co\/pHWKvkn6WH",
    "id" : 791752413925482496,
    "created_at" : "2016-10-27 21:24:20 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 792016135147364352,
  "created_at" : "2016-10-28 14:52:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 50, 58 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 59, 66 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 67, 77 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/791997255045804032\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/wgfAFzt2Al",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv29RJ7WEAAfGA2.jpg",
      "id_str" : "791997211907330048",
      "id" : 791997211907330048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv29RJ7WEAAfGA2.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/wgfAFzt2Al"
    } ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/NQysjCW1Tu",
      "expanded_url" : "http:\/\/nerdcator.org",
      "display_url" : "nerdcator.org"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50179137884898, 0.005367785364593963 ]
  },
  "id_str" : "791997255045804032",
  "text" : "Poster for our https:\/\/t.co\/NQysjCW1Tu session w\/ @Seplute @sujaik @auremoser on Sun, 2pm, floor 9. #MozFest https:\/\/t.co\/wgfAFzt2Al",
  "id" : 791997255045804032,
  "created_at" : "2016-10-28 13:37:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791975742414397440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5018000443351, 0.005249842172199246 ]
  },
  "id_str" : "791983003270610945",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot fitting Halloween? ;)",
  "id" : 791983003270610945,
  "in_reply_to_status_id" : 791975742414397440,
  "created_at" : "2016-10-28 12:40:36 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/791982253765169152\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/umUseAMw8g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv2vo_zWYAAH815.jpg",
      "id_str" : "791982228343513088",
      "id" : 791982228343513088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv2vo_zWYAAH815.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/umUseAMw8g"
    } ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50180408207483, 0.005280316497208839 ]
  },
  "id_str" : "791982253765169152",
  "text" : "I just became part of an Italian art piece on how European copyright hinders creativity. #MozFest https:\/\/t.co\/umUseAMw8g",
  "id" : 791982253765169152,
  "created_at" : "2016-10-28 12:37:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/791978105292394496\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/UvCHygdbtX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv2r2_6XYAQSl1l.jpg",
      "id_str" : "791978070844596228",
      "id" : 791978070844596228,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv2r2_6XYAQSl1l.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/UvCHygdbtX"
    } ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50179682564165, 0.005281820801671903 ]
  },
  "id_str" : "791978105292394496",
  "text" : "I know a cool #MozFest session that has stickers. Visit us on floor 9 on Sunday at 2pm. https:\/\/t.co\/UvCHygdbtX",
  "id" : 791978105292394496,
  "created_at" : "2016-10-28 12:21:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/791959925278646272\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/rvakdfKmBh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv2bV-UUkAAPLtM.jpg",
      "id_str" : "791959911294865408",
      "id" : 791959911294865408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv2bV-UUkAAPLtM.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/rvakdfKmBh"
    } ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50179850518994, 0.00526919807807387 ]
  },
  "id_str" : "791959925278646272",
  "text" : "I finally got a brain! #mozfest https:\/\/t.co\/rvakdfKmBh",
  "id" : 791959925278646272,
  "created_at" : "2016-10-28 11:08:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 13, 25 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791948324295237635",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5017913263166, 0.005240383783405876 ]
  },
  "id_str" : "791948999683026944",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @billymeinke that\u2019s offering some comfort. But I\u2019ll also miss our hotel room party.",
  "id" : 791948999683026944,
  "in_reply_to_status_id" : 791948324295237635,
  "created_at" : "2016-10-28 10:25:29 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 47, 59 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791947692603678720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50178802023565, 0.005237295103908223 ]
  },
  "id_str" : "791948073995939840",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston will go for lunch without you and @billymeinke and silently cry into my Ramen.",
  "id" : 791948073995939840,
  "in_reply_to_status_id" : 791947692603678720,
  "created_at" : "2016-10-28 10:21:49 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 15, 23 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791929280133378049",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50179467646873, 0.005207175324543818 ]
  },
  "id_str" : "791930598486978560",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy @Seplute Oh, okay. But there\u2019s the after lunch thing going on!",
  "id" : 791930598486978560,
  "in_reply_to_status_id" : 791929280133378049,
  "created_at" : "2016-10-28 09:12:22 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 9, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/EMMvdTxvqF",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BMGcKLrDp6N\/",
      "display_url" : "instagram.com\/p\/BMGcKLrDp6N\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5017591034, 0.00505350446529 ]
  },
  "id_str" : "791926099445972992",
  "text" : "Starting #mozfest by building a brain hat. @ Ravensbourne UK https:\/\/t.co\/EMMvdTxvqF",
  "id" : 791926099445972992,
  "created_at" : "2016-10-28 08:54:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/791906506711109632\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/C4MXJIDS0T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv1qxUWXgAAM3Ak.jpg",
      "id_str" : "791906504995733504",
      "id" : 791906504995733504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv1qxUWXgAAM3Ak.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/C4MXJIDS0T"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791906506711109632",
  "text" : "Two nerds sharing a room totally need 8 power outlets to get through a single night. https:\/\/t.co\/C4MXJIDS0T",
  "id" : 791906506711109632,
  "created_at" : "2016-10-28 07:36:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791810571113029633",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50497654821279, -0.08127252023806952 ]
  },
  "id_str" : "791895414463164416",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs yes, let\u2019s see how they figure it out \uD83D\uDE02",
  "id" : 791895414463164416,
  "in_reply_to_status_id" : 791810571113029633,
  "created_at" : "2016-10-28 06:52:34 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791809438650863617",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50490472958971, -0.08141085400330468 ]
  },
  "id_str" : "791809745296429056",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs I showed them the email Marc sent to me and they gave me a room and want to figure it out somehow. :-)",
  "id" : 791809745296429056,
  "in_reply_to_status_id" : 791809438650863617,
  "created_at" : "2016-10-28 01:12:09 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791803005406437377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50495900550592, -0.08130436073683593 ]
  },
  "id_str" : "791807041073516549",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon that escalated quickly from \u201Ceveryone being at home at the same time\u201D \uD83D\uDC4B \uD83D\uDE02",
  "id" : 791807041073516549,
  "in_reply_to_status_id" : 791803005406437377,
  "created_at" : "2016-10-28 01:01:24 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/791804760101978112\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/XeU4FoQ6eW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv0OOzvWgAAx2Be.jpg",
      "id_str" : "791804757056847872",
      "id" : 791804757056847872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv0OOzvWgAAx2Be.jpg",
      "sizes" : [ {
        "h" : 704,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 704,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 704,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XeU4FoQ6eW"
    } ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791804760101978112",
  "text" : "#mozfest starts with the traditional night walk (if doing something twice makes a tradition). https:\/\/t.co\/XeU4FoQ6eW",
  "id" : 791804760101978112,
  "created_at" : "2016-10-28 00:52:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50472749389039, -0.08257474996656346 ]
  },
  "id_str" : "791781109679923204",
  "text" : "Starting off with the hotel not knowing about me being supposed at their place, awesome. \uD83D\uDE02",
  "id" : 791781109679923204,
  "created_at" : "2016-10-27 23:18:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.47213816702622, -0.3602354688524075 ]
  },
  "id_str" : "791762393751810048",
  "text" : "Hey London, feels like coming home by now.",
  "id" : 791762393751810048,
  "created_at" : "2016-10-27 22:03:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791753960369651712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46969827921232, -0.4121403715508037 ]
  },
  "id_str" : "791760896251035648",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe yes, hope soon!",
  "id" : 791760896251035648,
  "in_reply_to_status_id" : 791753960369651712,
  "created_at" : "2016-10-27 21:58:02 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791753690692612096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46997899950985, -0.4418557537858541 ]
  },
  "id_str" : "791753847710580736",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe that\u2019s a near miss. Leaving less than 1h earlier \uD83D\uDE22",
  "id" : 791753847710580736,
  "in_reply_to_status_id" : 791753690692612096,
  "created_at" : "2016-10-27 21:30:02 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Roman Valls",
      "screen_name" : "braincode",
      "indices" : [ 11, 21 ],
      "id_str" : "149460258",
      "id" : 149460258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791752318618333185",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46998009162956, -0.4419032723871386 ]
  },
  "id_str" : "791752620062932992",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe @braincode leaving 31st on the last flight to FRA.",
  "id" : 791752620062932992,
  "in_reply_to_status_id" : 791752318618333185,
  "created_at" : "2016-10-27 21:25:09 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 39, 51 ],
      "id_str" : "748018813",
      "id" : 748018813
    }, {
      "name" : "Authorea",
      "screen_name" : "authorea",
      "indices" : [ 52, 61 ],
      "id_str" : "483986116",
      "id" : 483986116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/pHWKvkn6WH",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/science\/comments\/59p98b\/rscience_the_winnower_and_authorea_are_having_an\/d9adg44\/",
      "display_url" : "reddit.com\/r\/science\/comm\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.47016536850636, -0.4418614700881169 ]
  },
  "id_str" : "791752413925482496",
  "text" : "Are on reddit and wanna help me in the @theWinnower\/@authorea contest? Up vote here please. https:\/\/t.co\/pHWKvkn6WH",
  "id" : 791752413925482496,
  "created_at" : "2016-10-27 21:24:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04813515881206, 8.570069746268821 ]
  },
  "id_str" : "791727252883009537",
  "text" : "Running a bit late, but now FRA \u2708\uFE0F LHR for #MozFest.",
  "id" : 791727252883009537,
  "created_at" : "2016-10-27 19:44:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/XWwML32ge8",
      "expanded_url" : "https:\/\/twitter.com\/keyboardpipette\/status\/791713133152919552",
      "display_url" : "twitter.com\/keyboardpipett\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04649692678054, 8.571507038044388 ]
  },
  "id_str" : "791716029810475008",
  "text" : "You either die despising file formats or live long enough to develop new ones. https:\/\/t.co\/XWwML32ge8",
  "id" : 791716029810475008,
  "created_at" : "2016-10-27 18:59:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Seiver",
      "screen_name" : "tweetotaler",
      "indices" : [ 0, 12 ],
      "id_str" : "29891068",
      "id" : 29891068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791714223281713152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0466574416077, 8.571705960078491 ]
  },
  "id_str" : "791714708063739905",
  "in_reply_to_user_id" : 29891068,
  "text" : "@tweetotaler yes, though you can at least export your Swarm data for free. :p",
  "id" : 791714708063739905,
  "in_reply_to_status_id" : 791714223281713152,
  "created_at" : "2016-10-27 18:54:30 +0000",
  "in_reply_to_screen_name" : "tweetotaler",
  "in_reply_to_user_id_str" : "29891068",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04660742572419, 8.571383793372304 ]
  },
  "id_str" : "791709746801831936",
  "text" : "\u00ABI was too busy plotting data.\u00BB \u2014 \u00ABI know that feeling. I lost so many nights and friends thanks to plotting stuff.\u00BB",
  "id" : 791709746801831936,
  "created_at" : "2016-10-27 18:34:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04671776695404, 8.57149229018213 ]
  },
  "id_str" : "791706364036997120",
  "text" : "wtf, there are now Elsevier ads in my Swarm timeline!? Predictive marketing at its worst.",
  "id" : 791706364036997120,
  "created_at" : "2016-10-27 18:21:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 3, 13 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/f9d4hZ6jiT",
      "expanded_url" : "https:\/\/twitter.com\/bobby\/status\/779535117073145857",
      "display_url" : "twitter.com\/bobby\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "791703584320679936",
  "text" : "RT @Julie_B92: Seriously dying with this thread https:\/\/t.co\/f9d4hZ6jiT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/f9d4hZ6jiT",
        "expanded_url" : "https:\/\/twitter.com\/bobby\/status\/779535117073145857",
        "display_url" : "twitter.com\/bobby\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "791698570378350592",
    "text" : "Seriously dying with this thread https:\/\/t.co\/f9d4hZ6jiT",
    "id" : 791698570378350592,
    "created_at" : "2016-10-27 17:50:22 +0000",
    "user" : {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "protected" : false,
      "id_str" : "1385861262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/813827716151644160\/JvmX-W-T_normal.jpg",
      "id" : 1385861262,
      "verified" : false
    }
  },
  "id" : 791703584320679936,
  "created_at" : "2016-10-27 18:10:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shiri Eisner",
      "screen_name" : "ShiriEisner",
      "indices" : [ 3, 15 ],
      "id_str" : "1085971416",
      "id" : 1085971416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791690121510813696",
  "text" : "RT @ShiriEisner: There's a meme going around saying \"Not gay as in the Supreme Court gave me my right to get married, but queer as... https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/zRht7EIS06",
        "expanded_url" : "http:\/\/fb.me\/3lkdMFJVI",
        "display_url" : "fb.me\/3lkdMFJVI"
      } ]
    },
    "geo" : { },
    "id_str" : "791689604432670720",
    "text" : "There's a meme going around saying \"Not gay as in the Supreme Court gave me my right to get married, but queer as... https:\/\/t.co\/zRht7EIS06",
    "id" : 791689604432670720,
    "created_at" : "2016-10-27 17:14:45 +0000",
    "user" : {
      "name" : "Shiri Eisner",
      "screen_name" : "ShiriEisner",
      "protected" : false,
      "id_str" : "1085971416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3250409823\/637ea88abd3f514ac6a2384f168672f3_normal.jpeg",
      "id" : 1085971416,
      "verified" : false
    }
  },
  "id" : 791690121510813696,
  "created_at" : "2016-10-27 17:16:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/g1JFVXVTA6",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BMEoZ6PjiTd\/",
      "display_url" : "instagram.com\/p\/BMEoZ6PjiTd\/"
    } ]
  },
  "geo" : { },
  "id_str" : "791671553498820608",
  "text" : "Alternative Bioinformatics Education today https:\/\/t.co\/g1JFVXVTA6",
  "id" : 791671553498820608,
  "created_at" : "2016-10-27 16:03:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/l2kCGSQH8o",
      "expanded_url" : "https:\/\/twitter.com\/WikiLibrary\/status\/791383894184656896",
      "display_url" : "twitter.com\/WikiLibrary\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "791596909999816704",
  "text" : "Needs a feature to replace all links with the Sci-Hub equivalent where no OA-version was found. https:\/\/t.co\/l2kCGSQH8o",
  "id" : 791596909999816704,
  "created_at" : "2016-10-27 11:06:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "indices" : [ 0, 10 ],
      "id_str" : "93434375",
      "id" : 93434375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791575824566812676",
  "geo" : { },
  "id_str" : "791575899795812352",
  "in_reply_to_user_id" : 93434375,
  "text" : "@elioqoshi Sounds awesome, will have a look!",
  "id" : 791575899795812352,
  "in_reply_to_status_id" : 791575824566812676,
  "created_at" : "2016-10-27 09:42:55 +0000",
  "in_reply_to_screen_name" : "elioqoshi",
  "in_reply_to_user_id_str" : "93434375",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "indices" : [ 0, 10 ],
      "id_str" : "93434375",
      "id" : 93434375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791572943767760896",
  "geo" : { },
  "id_str" : "791575610233593858",
  "in_reply_to_user_id" : 93434375,
  "text" : "@elioqoshi great! Are you having a session? :)",
  "id" : 791575610233593858,
  "in_reply_to_status_id" : 791572943767760896,
  "created_at" : "2016-10-27 09:41:46 +0000",
  "in_reply_to_screen_name" : "elioqoshi",
  "in_reply_to_user_id_str" : "93434375",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "indices" : [ 0, 10 ],
      "id_str" : "93434375",
      "id" : 93434375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791547229219786752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240047017836, 8.627486626111377 ]
  },
  "id_str" : "791571837419413504",
  "in_reply_to_user_id" : 93434375,
  "text" : "@elioqoshi hope we\u2019ll meet!",
  "id" : 791571837419413504,
  "in_reply_to_status_id" : 791547229219786752,
  "created_at" : "2016-10-27 09:26:47 +0000",
  "in_reply_to_screen_name" : "elioqoshi",
  "in_reply_to_user_id_str" : "93434375",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jojo Scoble \uD83D\uDD2C",
      "screen_name" : "Paraphyso",
      "indices" : [ 0, 10 ],
      "id_str" : "290019499",
      "id" : 290019499
    }, {
      "name" : "SwiftKey",
      "screen_name" : "SwiftKey",
      "indices" : [ 11, 20 ],
      "id_str" : "113034662",
      "id" : 113034662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791540761368166400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237831897245, 8.627460207568287 ]
  },
  "id_str" : "791551061265879040",
  "in_reply_to_user_id" : 290019499,
  "text" : "@Paraphyso @SwiftKey same here. That was the first message of the day and I was terrified.",
  "id" : 791551061265879040,
  "in_reply_to_status_id" : 791540761368166400,
  "created_at" : "2016-10-27 08:04:13 +0000",
  "in_reply_to_screen_name" : "Paraphyso",
  "in_reply_to_user_id_str" : "290019499",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/791550814431145984\/photo\/1",
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/Fh8p0DsdOt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvwnRSwW8AAiiEX.jpg",
      "id_str" : "791550812556292096",
      "id" : 791550812556292096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvwnRSwW8AAiiEX.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Fh8p0DsdOt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791550814431145984",
  "text" : "Dare https:\/\/t.co\/Fh8p0DsdOt",
  "id" : 791550814431145984,
  "created_at" : "2016-10-27 08:03:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SwiftKey",
      "screen_name" : "SwiftKey",
      "indices" : [ 4, 13 ],
      "id_str" : "113034662",
      "id" : 113034662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06080598474092, 8.81855959255392 ]
  },
  "id_str" : "791516576935768064",
  "text" : "So, @SwiftKey just tried to autocorrect \u2018true love\u2019 to \u2018Trump\u2019, and now I kind of want to use a different input device.",
  "id" : 791516576935768064,
  "created_at" : "2016-10-27 05:47:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/NCwR27YIps",
      "expanded_url" : "https:\/\/twitter.com\/sadanduseless\/status\/788755698490441730",
      "display_url" : "twitter.com\/sadanduseless\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "791417488944861184",
  "text" : "Totally enjoy all the masturdating before having a bedgasm. https:\/\/t.co\/NCwR27YIps",
  "id" : 791417488944861184,
  "created_at" : "2016-10-26 23:13:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791401692512354304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06077503658017, 8.818523960421272 ]
  },
  "id_str" : "791402102295781382",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 other people\u2019s data is always so more interesting than the one you should be looking at!",
  "id" : 791402102295781382,
  "in_reply_to_status_id" : 791401692512354304,
  "created_at" : "2016-10-26 22:12:19 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 0, 12 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791395516663889926",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06077503658017, 8.818523960421272 ]
  },
  "id_str" : "791401861194584064",
  "in_reply_to_user_id" : 208988759,
  "text" : "@GigaScience who of you will be there? :)",
  "id" : 791401861194584064,
  "in_reply_to_status_id" : 791395516663889926,
  "created_at" : "2016-10-26 22:11:21 +0000",
  "in_reply_to_screen_name" : "GigaScience",
  "in_reply_to_user_id_str" : "208988759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791388966436077572",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085976091595, 8.818668451704347 ]
  },
  "id_str" : "791401027090190340",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 thanks, guess whose brain is now running again too!",
  "id" : 791401027090190340,
  "in_reply_to_status_id" : 791388966436077572,
  "created_at" : "2016-10-26 22:08:03 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wellcome Collection",
      "screen_name" : "ExploreWellcome",
      "indices" : [ 30, 46 ],
      "id_str" : "48370227",
      "id" : 48370227
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/791375920766517254\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Yyw2nqxROL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvuIEPfW8AE9KVv.jpg",
      "id_str" : "791375765992566785",
      "id" : 791375765992566785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvuIEPfW8AE9KVv.jpg",
      "sizes" : [ {
        "h" : 161,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 1143
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 1143
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 1143
      } ],
      "display_url" : "pic.twitter.com\/Yyw2nqxROL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/2RsAPdV81R",
      "expanded_url" : "http:\/\/sexbynumbers.wellcomecollection.org\/",
      "display_url" : "sexbynumbers.wellcomecollection.org"
    } ]
  },
  "geo" : { },
  "id_str" : "791375920766517254",
  "text" : "You\u2019re sending mixed signals, @ExploreWellcome! https:\/\/t.co\/2RsAPdV81R \n--\nsent from a bedroom https:\/\/t.co\/Yyw2nqxROL",
  "id" : 791375920766517254,
  "created_at" : "2016-10-26 20:28:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791369110995214336",
  "geo" : { },
  "id_str" : "791369824937148417",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H or I\u2019ll just come by and visit one day. I\u2019ve never been to G\u00F6ttingen!",
  "id" : 791369824937148417,
  "in_reply_to_status_id" : 791369110995214336,
  "created_at" : "2016-10-26 20:04:03 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791366921631494145",
  "geo" : { },
  "id_str" : "791367050279215104",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H if I ever get stuck at G\u00F6ttingen International Airport after a trip I\u2019ll let you know :D",
  "id" : 791367050279215104,
  "in_reply_to_status_id" : 791366921631494145,
  "created_at" : "2016-10-26 19:53:02 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791366162575724545",
  "geo" : { },
  "id_str" : "791366469628096512",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H Sure, please do! Usually we even have a complete room free, so you\u2019d have your space.",
  "id" : 791366469628096512,
  "in_reply_to_status_id" : 791366162575724545,
  "created_at" : "2016-10-26 19:50:43 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791364939441201152",
  "geo" : { },
  "id_str" : "791365799520956416",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H okay, would have happily hosted you otherwise (even in absentia if needed ;))",
  "id" : 791365799520956416,
  "in_reply_to_status_id" : 791364939441201152,
  "created_at" : "2016-10-26 19:48:04 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791364203185668097",
  "geo" : { },
  "id_str" : "791364302821269504",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H need a place to stay on that Sat night?",
  "id" : 791364302821269504,
  "in_reply_to_status_id" : 791364203185668097,
  "created_at" : "2016-10-26 19:42:07 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791352988686254080",
  "geo" : { },
  "id_str" : "791362506505785345",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H not sure yet, I might be in Zurich on that weekend. Until when do you need to know?",
  "id" : 791362506505785345,
  "in_reply_to_status_id" : 791352988686254080,
  "created_at" : "2016-10-26 19:34:59 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/wmtdTLqDa3",
      "expanded_url" : "https:\/\/twitter.com\/TheLeakeyFndtn\/status\/791339326516842496",
      "display_url" : "twitter.com\/TheLeakeyFndtn\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085886863854, 8.818645390699368 ]
  },
  "id_str" : "791351124909580289",
  "text" : "\u00ABThis post originally misstated that Slayer is an \u201880s hair metal band. It is a metal band, but not a hair metal band.\u00BB https:\/\/t.co\/wmtdTLqDa3",
  "id" : 791351124909580289,
  "created_at" : "2016-10-26 18:49:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Virginia Hughes",
      "screen_name" : "virginiahughes",
      "indices" : [ 3, 18 ],
      "id_str" : "17042078",
      "id" : 17042078
    }, {
      "name" : "Stephanie M. Lee",
      "screen_name" : "stephaniemlee",
      "indices" : [ 60, 74 ],
      "id_str" : "15022464",
      "id" : 15022464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/bgZ3FPnyeh",
      "expanded_url" : "https:\/\/www.buzzfeed.com\/stephaniemlee\/helix-announces-debut",
      "display_url" : "buzzfeed.com\/stephaniemlee\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "791347437994639361",
  "text" : "RT @virginiahughes: If U follow genetic testing, gotta read @stephaniemlee on industry darlings Helix + 23andMe https:\/\/t.co\/bgZ3FPnyeh htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephanie M. Lee",
        "screen_name" : "stephaniemlee",
        "indices" : [ 40, 54 ],
        "id_str" : "15022464",
        "id" : 15022464
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/bgZ3FPnyeh",
        "expanded_url" : "https:\/\/www.buzzfeed.com\/stephaniemlee\/helix-announces-debut",
        "display_url" : "buzzfeed.com\/stephaniemlee\/\u2026"
      }, {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/86zZbw1KYh",
        "expanded_url" : "https:\/\/www.buzzfeed.com\/stephaniemlee\/23andme-anne-wojcicki-next-generation-sequencing?utm_term=.jkx5VG9lK#.gke5RgkNl",
        "display_url" : "buzzfeed.com\/stephaniemlee\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "791332020106518530",
    "text" : "If U follow genetic testing, gotta read @stephaniemlee on industry darlings Helix + 23andMe https:\/\/t.co\/bgZ3FPnyeh https:\/\/t.co\/86zZbw1KYh",
    "id" : 791332020106518530,
    "created_at" : "2016-10-26 17:33:50 +0000",
    "user" : {
      "name" : "Virginia Hughes",
      "screen_name" : "virginiahughes",
      "protected" : false,
      "id_str" : "17042078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554066251845083137\/ERzrr-4S_normal.jpeg",
      "id" : 17042078,
      "verified" : true
    }
  },
  "id" : 791347437994639361,
  "created_at" : "2016-10-26 18:35:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791337693049458688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06099147501168, 8.818490407961173 ]
  },
  "id_str" : "791340277873213444",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed yes, looking forward to watch the movie sometime soon (that was one reason for mentioning the book yesterday)",
  "id" : 791340277873213444,
  "in_reply_to_status_id" : 791337693049458688,
  "created_at" : "2016-10-26 18:06:39 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/wWjeYww9IX",
      "expanded_url" : "https:\/\/twitter.com\/ozaed\/status\/791337076348297217",
      "display_url" : "twitter.com\/ozaed\/status\/7\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06099147501168, 8.818490407961173 ]
  },
  "id_str" : "791340130158149632",
  "text" : "The patient zero story about how HIV spread in the US has been refuted thanks to phylogenetics. https:\/\/t.co\/wWjeYww9IX",
  "id" : 791340130158149632,
  "created_at" : "2016-10-26 18:06:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791337076348297217",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06097399794574, 8.818565814784927 ]
  },
  "id_str" : "791337502003105792",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed Oh thanks, just by chance I talked about the book twice yesterday! (Haven\u2019t watched the movie yet, wanted some distance to the book)",
  "id" : 791337502003105792,
  "in_reply_to_status_id" : 791337076348297217,
  "created_at" : "2016-10-26 17:55:37 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Cranston",
      "screen_name" : "kcranstn",
      "indices" : [ 3, 12 ],
      "id_str" : "88764812",
      "id" : 88764812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791312171456225282",
  "text" : "RT @kcranstn: OMG. I love this (as someone who knows both code and mortising chisels). Plus, my Dad taught me many of those quotes. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/tL8Af7nva1",
        "expanded_url" : "https:\/\/twitter.com\/davelunt\/status\/791275226629832704",
        "display_url" : "twitter.com\/davelunt\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "791277703483813888",
    "text" : "OMG. I love this (as someone who knows both code and mortising chisels). Plus, my Dad taught me many of those quotes. https:\/\/t.co\/tL8Af7nva1",
    "id" : 791277703483813888,
    "created_at" : "2016-10-26 13:58:00 +0000",
    "user" : {
      "name" : "Karen Cranston",
      "screen_name" : "kcranstn",
      "protected" : false,
      "id_str" : "88764812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695285811789611008\/1wbjZVH9_normal.jpg",
      "id" : 88764812,
      "verified" : false
    }
  },
  "id" : 791312171456225282,
  "created_at" : "2016-10-26 16:14:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/nvZtRu51u0",
      "expanded_url" : "https:\/\/twitter.com\/klmr\/status\/791250318982078464",
      "display_url" : "twitter.com\/klmr\/status\/79\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "791308583778541568",
  "text" : "You never know, with these new HiSeq Galaxy S7 everything can happen. https:\/\/t.co\/nvZtRu51u0",
  "id" : 791308583778541568,
  "created_at" : "2016-10-26 16:00:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 3, 18 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791302164203307008",
  "text" : "RT @EmilyGorcenski: I didn't need machine learning for this, but my cost function was \"is a stranger shoving their hands into my crotch yes\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "791242377679736832",
    "geo" : { },
    "id_str" : "791242809630158848",
    "in_reply_to_user_id" : 1483064670,
    "text" : "I didn't need machine learning for this, but my cost function was \"is a stranger shoving their hands into my crotch yes\/no.\"",
    "id" : 791242809630158848,
    "in_reply_to_status_id" : 791242377679736832,
    "created_at" : "2016-10-26 11:39:21 +0000",
    "in_reply_to_screen_name" : "EmilyGorcenski",
    "in_reply_to_user_id_str" : "1483064670",
    "user" : {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "protected" : false,
      "id_str" : "1483064670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/894321143917817856\/eTjpSt4h_normal.jpg",
      "id" : 1483064670,
      "verified" : true
    }
  },
  "id" : 791302164203307008,
  "created_at" : "2016-10-26 15:35:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 3, 18 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791302148780941312",
  "text" : "RT @EmilyGorcenski: True facts: I own an \"airport security\" outfit that I have observed is less likely to get me flagged as an anomaly and\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "791241576689364992",
    "geo" : { },
    "id_str" : "791242377679736832",
    "in_reply_to_user_id" : 1483064670,
    "text" : "True facts: I own an \"airport security\" outfit that I have observed is less likely to get me flagged as an anomaly and called \"it.\"",
    "id" : 791242377679736832,
    "in_reply_to_status_id" : 791241576689364992,
    "created_at" : "2016-10-26 11:37:38 +0000",
    "in_reply_to_screen_name" : "EmilyGorcenski",
    "in_reply_to_user_id_str" : "1483064670",
    "user" : {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "protected" : false,
      "id_str" : "1483064670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/894321143917817856\/eTjpSt4h_normal.jpg",
      "id" : 1483064670,
      "verified" : true
    }
  },
  "id" : 791302148780941312,
  "created_at" : "2016-10-26 15:35:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791301363204489217",
  "geo" : { },
  "id_str" : "791301496101109766",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ah, your UI is German I assume, because I didn\u2019t even get to the weird translation.",
  "id" : 791301496101109766,
  "in_reply_to_status_id" : 791301363204489217,
  "created_at" : "2016-10-26 15:32:32 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791283010221899777",
  "geo" : { },
  "id_str" : "791297509364817920",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot why the weird lingo? \u263A\uFE0F",
  "id" : 791297509364817920,
  "in_reply_to_status_id" : 791283010221899777,
  "created_at" : "2016-10-26 15:16:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791296750149574656",
  "geo" : { },
  "id_str" : "791297016437608448",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye any chance that there\u2019s a english\/german report on this? :)",
  "id" : 791297016437608448,
  "in_reply_to_status_id" : 791296750149574656,
  "created_at" : "2016-10-26 15:14:44 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791283010221899777",
  "geo" : { },
  "id_str" : "791295733056016384",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot bislang wollte ich nicht collared werden. Well\u2026",
  "id" : 791295733056016384,
  "in_reply_to_status_id" : 791283010221899777,
  "created_at" : "2016-10-26 15:09:38 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PersonalData.IO",
      "screen_name" : "PersonalDataIO",
      "indices" : [ 0, 15 ],
      "id_str" : "736639776821018626",
      "id" : 736639776821018626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791291974095601664",
  "geo" : { },
  "id_str" : "791295543297310720",
  "in_reply_to_user_id" : 736639776821018626,
  "text" : "@PersonalDataIO heated in which sense? :D",
  "id" : 791295543297310720,
  "in_reply_to_status_id" : 791291974095601664,
  "created_at" : "2016-10-26 15:08:53 +0000",
  "in_reply_to_screen_name" : "PersonalDataIO",
  "in_reply_to_user_id_str" : "736639776821018626",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 11, 18 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 19, 29 ],
      "id_str" : "186529934",
      "id" : 186529934
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 30, 38 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Micropia",
      "screen_name" : "Micropia",
      "indices" : [ 39, 48 ],
      "id_str" : "2482016394",
      "id" : 2482016394
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 49, 65 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 66, 76 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/HzQWYSeDTx",
      "expanded_url" : "https:\/\/instagram.com\/p\/-9Ht9phwvv\/",
      "display_url" : "instagram.com\/p\/-9Ht9phwvv\/"
    } ]
  },
  "in_reply_to_status_id_str" : "791249127749349376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240127754484, 8.627475738801145 ]
  },
  "id_str" : "791249906933563392",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @sujaik @auremoser @Seplute @Micropia @pathogenomenick @edyong209 https:\/\/t.co\/HzQWYSeDTx \uD83D\uDC4D",
  "id" : 791249906933563392,
  "in_reply_to_status_id" : 791249127749349376,
  "created_at" : "2016-10-26 12:07:33 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 34, 41 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 72, 82 ],
      "id_str" : "186529934",
      "id" : 186529934
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 83, 91 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/TB7N1PAIsN",
      "expanded_url" : "https:\/\/twitter.com\/sujaik\/status\/757478889610502144",
      "display_url" : "twitter.com\/sujaik\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "791248490882039808",
  "geo" : { },
  "id_str" : "791248878288900097",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 The idea started after @sujaik were both riding tardigrades! @auremoser @Seplute https:\/\/t.co\/TB7N1PAIsN",
  "id" : 791248878288900097,
  "in_reply_to_status_id" : 791248490882039808,
  "created_at" : "2016-10-26 12:03:27 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 149, 172 ],
      "url" : "https:\/\/t.co\/5Qle12Ww7H",
      "expanded_url" : "https:\/\/twitter.com\/auremoser\/status\/790981576876326912",
      "display_url" : "twitter.com\/auremoser\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "791242643464421376",
  "text" : "Since a few minutes: All session-materials are already available in English &amp; German. On-site we also offer support in Hindi (&amp; Lithuanian?) https:\/\/t.co\/5Qle12Ww7H",
  "id" : 791242643464421376,
  "created_at" : "2016-10-26 11:38:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791236950002835456",
  "geo" : { },
  "id_str" : "791237140126507008",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I also don\u2019t really see how it\u2019s different from \u201EVCF wrapped with some SQL-like stuff\u201C in the end.",
  "id" : 791237140126507008,
  "in_reply_to_status_id" : 791236950002835456,
  "created_at" : "2016-10-26 11:16:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791122491787845632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18368268302955, 8.62115813776952 ]
  },
  "id_str" : "791211215997591552",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski depends on size, in my experience (lower forearms &amp; back of my hand) it isn't too bad.",
  "id" : 791211215997591552,
  "in_reply_to_status_id" : 791122491787845632,
  "created_at" : "2016-10-26 09:33:48 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 53, 66 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/WJzchnGw9f",
      "expanded_url" : "http:\/\/bioinformatics.oxfordjournals.org\/content\/32\/20\/3081.full",
      "display_url" : "bioinformatics.oxfordjournals.org\/content\/32\/20\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "791201036560195589",
  "text" : "GORpipe: a query tool for working with sequence data @PhilippBayer https:\/\/t.co\/WJzchnGw9f",
  "id" : 791201036560195589,
  "created_at" : "2016-10-26 08:53:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/lnBMv3SLiQ",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/phonemes",
      "display_url" : "smbc-comics.com\/comic\/phonemes"
    } ]
  },
  "geo" : { },
  "id_str" : "791189695845830656",
  "text" : "And that, kids, is why statisticians and linguists have rough relationships. https:\/\/t.co\/lnBMv3SLiQ",
  "id" : 791189695845830656,
  "created_at" : "2016-10-26 08:08:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791164410429452288",
  "geo" : { },
  "id_str" : "791164564712853504",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy doh, because I\u2019ll touch down in LAX on 16th already but no clear plans for how to criss-cross CA so far.",
  "id" : 791164564712853504,
  "in_reply_to_status_id" : 791164410429452288,
  "created_at" : "2016-10-26 06:28:26 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791141513350770688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06099772958, 8.818989583111737 ]
  },
  "id_str" : "791149701265498112",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy Oh no, will you be around CA somewhere?",
  "id" : 791149701265498112,
  "in_reply_to_status_id" : 791141513350770688,
  "created_at" : "2016-10-26 05:29:22 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/791020110567837696\/photo\/1",
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/4Pb8dfskbt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvpEmN-WgAAL9Yh.jpg",
      "id_str" : "791020107933843456",
      "id" : 791020107933843456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvpEmN-WgAAL9Yh.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/4Pb8dfskbt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791020110567837696",
  "text" : "Teaching motto of the day. https:\/\/t.co\/4Pb8dfskbt",
  "id" : 791020110567837696,
  "created_at" : "2016-10-25 20:54:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/5Qle12Ww7H",
      "expanded_url" : "https:\/\/twitter.com\/auremoser\/status\/790981576876326912",
      "display_url" : "twitter.com\/auremoser\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05887234620491, 8.812409132830494 ]
  },
  "id_str" : "790983447980470275",
  "text" : "This will be so much fun! https:\/\/t.co\/5Qle12Ww7H",
  "id" : 790983447980470275,
  "created_at" : "2016-10-25 18:28:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790852050703749120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06083009157779, 8.818464048895969 ]
  },
  "id_str" : "790965981292224512",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin congrats!",
  "id" : 790965981292224512,
  "in_reply_to_status_id" : 790852050703749120,
  "created_at" : "2016-10-25 17:19:20 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 15, 25 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790868889798316032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238999138542, 8.627527446475083 ]
  },
  "id_str" : "790939115952955392",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima @Julie_B92 i think I just love traveling so much that I don\u2019t notice. \u263A\uFE0F",
  "id" : 790939115952955392,
  "in_reply_to_status_id" : 790868889798316032,
  "created_at" : "2016-10-25 15:32:34 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 11, 25 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790867951817809921",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238999138542, 8.627527446475083 ]
  },
  "id_str" : "790938979898195972",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @NazeefaFatima how does that even work? \uD83D\uDE02",
  "id" : 790938979898195972,
  "in_reply_to_status_id" : 790867951817809921,
  "created_at" : "2016-10-25 15:32:02 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 15, 25 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790862597725753345",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240642786778, 8.627481650190816 ]
  },
  "id_str" : "790864020840517632",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima @Julie_B92 usually I just don\u2019t. But if I do I just embrace the discomfort. \uD83D\uDE02",
  "id" : 790864020840517632,
  "in_reply_to_status_id" : 790862597725753345,
  "created_at" : "2016-10-25 10:34:10 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 11, 24 ],
      "id_str" : "22200760",
      "id" : 22200760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/KWcE7nJGaS",
      "expanded_url" : "https:\/\/pawstruck.com\/blog\/wp-content\/uploads\/2015\/11\/Dog_s_sleeping_position_is_just_awesome.jpeg",
      "display_url" : "pawstruck.com\/blog\/wp-conten\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "790845135265337348",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239229271546, 8.627522835652421 ]
  },
  "id_str" : "790860157395894273",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @vexedmuddler I mostly sleep like this while traveling https:\/\/t.co\/KWcE7nJGaS",
  "id" : 790860157395894273,
  "in_reply_to_status_id" : 790845135265337348,
  "created_at" : "2016-10-25 10:18:49 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "The Vexed Muddler",
      "screen_name" : "vexedmuddler",
      "indices" : [ 11, 24 ],
      "id_str" : "22200760",
      "id" : 22200760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790812553165373440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17245927353115, 8.627522895252724 ]
  },
  "id_str" : "790844561258053632",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @vexedmuddler I always managed without and preferred to travel with less stuff to carry around.",
  "id" : 790844561258053632,
  "in_reply_to_status_id" : 790812553165373440,
  "created_at" : "2016-10-25 09:16:51 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/dhZyPxvw4l",
      "expanded_url" : "https:\/\/twitter.com\/vexedmuddler\/status\/790762249447018496",
      "display_url" : "twitter.com\/vexedmuddler\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723927514284, 8.62751235974281 ]
  },
  "id_str" : "790809250276712449",
  "text" : "I never wanted a travel pillow so far. But this could convince me. https:\/\/t.co\/dhZyPxvw4l",
  "id" : 790809250276712449,
  "created_at" : "2016-10-25 06:56:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/790798127674580992\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/J5DELiFbWN",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cvl6su1XEAAwvGy.jpg",
      "id_str" : "790798118484905984",
      "id" : 790798118484905984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cvl6su1XEAAwvGy.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/J5DELiFbWN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790798127674580992",
  "text" : "My kind of IV drug use. https:\/\/t.co\/J5DELiFbWN",
  "id" : 790798127674580992,
  "created_at" : "2016-10-25 06:12:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 0, 10 ],
      "id_str" : "35304791",
      "id" : 35304791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790710026448932864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403257285868, 8.753385432291203 ]
  },
  "id_str" : "790710062830542848",
  "in_reply_to_user_id" : 35304791,
  "text" : "@razibkhan will do!",
  "id" : 790710062830542848,
  "in_reply_to_status_id" : 790710026448932864,
  "created_at" : "2016-10-25 00:22:24 +0000",
  "in_reply_to_screen_name" : "razibkhan",
  "in_reply_to_user_id_str" : "35304791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 0, 10 ],
      "id_str" : "35304791",
      "id" : 35304791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/wgpPxqZJqs",
      "expanded_url" : "https:\/\/www.electroniclibrarian.org\/conference-info\/",
      "display_url" : "electroniclibrarian.org\/conference-inf\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "790699132532817921",
  "geo" : { },
  "id_str" : "790708418101194752",
  "in_reply_to_user_id" : 35304791,
  "text" : "@razibkhan but i\u2019ll be in Austin in any case in early April, for https:\/\/t.co\/wgpPxqZJqs",
  "id" : 790708418101194752,
  "in_reply_to_status_id" : 790699132532817921,
  "created_at" : "2016-10-25 00:15:52 +0000",
  "in_reply_to_screen_name" : "razibkhan",
  "in_reply_to_user_id_str" : "35304791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/MdgzpJywYB",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/8N2tPBkltBYY0\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/8N2tPBkl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "790691676427804672",
  "geo" : { },
  "id_str" : "790694241441898496",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog here, take my answers! https:\/\/t.co\/MdgzpJywYB",
  "id" : 790694241441898496,
  "in_reply_to_status_id" : 790691676427804672,
  "created_at" : "2016-10-24 23:19:32 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 0, 10 ],
      "id_str" : "35304791",
      "id" : 35304791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790693988160286720",
  "geo" : { },
  "id_str" : "790694130192150529",
  "in_reply_to_user_id" : 35304791,
  "text" : "@razibkhan you! That it\u2019ll be in Austin I already knew, but forgot about you being there :-)",
  "id" : 790694130192150529,
  "in_reply_to_status_id" : 790693988160286720,
  "created_at" : "2016-10-24 23:19:05 +0000",
  "in_reply_to_screen_name" : "razibkhan",
  "in_reply_to_user_id_str" : "35304791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 0, 10 ],
      "id_str" : "35304791",
      "id" : 35304791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790685075767631872",
  "geo" : { },
  "id_str" : "790691402342686720",
  "in_reply_to_user_id" : 35304791,
  "text" : "@razibkhan damn, that would be a good reason to go to SMBE. Had thought about skipping next year.",
  "id" : 790691402342686720,
  "in_reply_to_status_id" : 790685075767631872,
  "created_at" : "2016-10-24 23:08:15 +0000",
  "in_reply_to_screen_name" : "razibkhan",
  "in_reply_to_user_id_str" : "35304791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 56, 70 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/qQwyTaWstz",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/ZcAY3yKiwqKbK\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/ZcAY3yKi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790682656287625216",
  "text" : "Why, oh why, did I volunteer myself for your interview, @Protohedgehog?! https:\/\/t.co\/qQwyTaWstz",
  "id" : 790682656287625216,
  "created_at" : "2016-10-24 22:33:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Oxford Nanopore",
      "screen_name" : "nanopore",
      "indices" : [ 11, 20 ],
      "id_str" : "37732219",
      "id" : 37732219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790641122108407808",
  "geo" : { },
  "id_str" : "790664870920413185",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @nanopore I hope that works :D",
  "id" : 790664870920413185,
  "in_reply_to_status_id" : 790641122108407808,
  "created_at" : "2016-10-24 21:22:49 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/790663240724381700\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/VZwXrwgrkY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvj__NQWAAEPsbH.jpg",
      "id_str" : "790663195958575105",
      "id" : 790663195958575105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvj__NQWAAEPsbH.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/VZwXrwgrkY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790662855729164289",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11386794164345, 8.753645791816481 ]
  },
  "id_str" : "790663240724381700",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez unrelated: each time I put these on I think of you! https:\/\/t.co\/VZwXrwgrkY",
  "id" : 790663240724381700,
  "in_reply_to_status_id" : 790662855729164289,
  "created_at" : "2016-10-24 21:16:21 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790662855729164289",
  "geo" : { },
  "id_str" : "790662907004612608",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez will do :)",
  "id" : 790662907004612608,
  "in_reply_to_status_id" : 790662855729164289,
  "created_at" : "2016-10-24 21:15:01 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790662280782368768",
  "geo" : { },
  "id_str" : "790662552493690882",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez thanks, I just reserved a car. Both of us going out from SFO on 26th, no plans until then so far. :)",
  "id" : 790662552493690882,
  "in_reply_to_status_id" : 790662280782368768,
  "created_at" : "2016-10-24 21:13:36 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790661503233818624",
  "geo" : { },
  "id_str" : "790662119851163648",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez having said this: partner &amp; I will \uD83D\uDE99-road-trip through CA, so might head up back through LAX. Have no route-plans so far.",
  "id" : 790662119851163648,
  "in_reply_to_status_id" : 790661503233818624,
  "created_at" : "2016-10-24 21:11:53 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790661503233818624",
  "geo" : { },
  "id_str" : "790661590932742148",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I think my plane arrives in the morning some time and I wanna head down to SAN later that day by train. :)",
  "id" : 790661590932742148,
  "in_reply_to_status_id" : 790661503233818624,
  "created_at" : "2016-10-24 21:09:47 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790656363240095744",
  "geo" : { },
  "id_str" : "790661222475661312",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez something completely different: I\u2019ll arrive at LAX on 16th of November. Wanna meet for lunch?",
  "id" : 790661222475661312,
  "in_reply_to_status_id" : 790656363240095744,
  "created_at" : "2016-10-24 21:08:19 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 10, 24 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790656363240095744",
  "geo" : { },
  "id_str" : "790660627329081344",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @beaugunderson y\u2019all so nice! :p",
  "id" : 790660627329081344,
  "in_reply_to_status_id" : 790656363240095744,
  "created_at" : "2016-10-24 21:05:57 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790651142447312896",
  "geo" : { },
  "id_str" : "790652806843826176",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson Thanks, just trying to make sure that the language barrier doesn\u2019t lead me astray!",
  "id" : 790652806843826176,
  "in_reply_to_status_id" : 790651142447312896,
  "created_at" : "2016-10-24 20:34:53 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790648511587115008",
  "geo" : { },
  "id_str" : "790648677748580353",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye yep, my UI language is english :)",
  "id" : 790648677748580353,
  "in_reply_to_status_id" : 790648511587115008,
  "created_at" : "2016-10-24 20:18:28 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790646831285960704",
  "geo" : { },
  "id_str" : "790646916673638402",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye Sure, please do!",
  "id" : 790646916673638402,
  "in_reply_to_status_id" : 790646831285960704,
  "created_at" : "2016-10-24 20:11:29 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790629935534800896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11041048918861, 8.749511567883891 ]
  },
  "id_str" : "790634972696735748",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye wanna do a second round?",
  "id" : 790634972696735748,
  "in_reply_to_status_id" : 790629935534800896,
  "created_at" : "2016-10-24 19:24:01 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790604977320386562",
  "geo" : { },
  "id_str" : "790626931020619776",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest yay! \uD83C\uDF89",
  "id" : 790626931020619776,
  "in_reply_to_status_id" : 790604977320386562,
  "created_at" : "2016-10-24 18:52:04 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scout Barbour-Evans",
      "screen_name" : "scoutriver",
      "indices" : [ 3, 14 ],
      "id_str" : "48618230",
      "id" : 48618230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790626016158941185",
  "text" : "RT @scoutriver: this article about how millennials have been gaslighted into thinking we're entitled, selfish and lazy is so good \uD83D\uDE43 https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/zaL5KWDMJf",
        "expanded_url" : "https:\/\/bornagainminimalist.com\/2016\/10\/17\/the-gaslighting-of-millennials\/",
        "display_url" : "bornagainminimalist.com\/2016\/10\/17\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "790615896708354048",
    "text" : "this article about how millennials have been gaslighted into thinking we're entitled, selfish and lazy is so good \uD83D\uDE43 https:\/\/t.co\/zaL5KWDMJf",
    "id" : 790615896708354048,
    "created_at" : "2016-10-24 18:08:13 +0000",
    "user" : {
      "name" : "Scout Barbour-Evans",
      "screen_name" : "scoutriver",
      "protected" : false,
      "id_str" : "48618230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925250116935544832\/nHRaE-Qt_normal.jpg",
      "id" : 48618230,
      "verified" : false
    }
  },
  "id" : 790626016158941185,
  "created_at" : "2016-10-24 18:48:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790609147939217408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403360243005, 8.75339990354565 ]
  },
  "id_str" : "790614668519899136",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson had the discussion recently: is folks okay? :)",
  "id" : 790614668519899136,
  "in_reply_to_status_id" : 790609147939217408,
  "created_at" : "2016-10-24 18:03:20 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140311663135, 8.753401432889232 ]
  },
  "id_str" : "790607084236800001",
  "text" : "Pretty good: Foursquare asks me whether I\u2019ll go Amsterdam soon, as it\u2019s my usual season for going there. Alas, I don\u2019t have plans to go. \uD83D\uDE22",
  "id" : 790607084236800001,
  "created_at" : "2016-10-24 17:33:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 0, 5 ],
      "id_str" : "1147751",
      "id" : 1147751
    }, {
      "name" : "nikki forebber",
      "screen_name" : "antischokke",
      "indices" : [ 6, 18 ],
      "id_str" : "2813661",
      "id" : 2813661
    }, {
      "name" : "Verena",
      "screen_name" : "Kommunikonautin",
      "indices" : [ 19, 35 ],
      "id_str" : "17021476",
      "id" : 17021476
    }, {
      "name" : "merle",
      "screen_name" : "maeusehaut",
      "indices" : [ 36, 47 ],
      "id_str" : "89219751",
      "id" : 89219751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790592287168425985",
  "geo" : { },
  "id_str" : "790592396362940416",
  "in_reply_to_user_id" : 1147751,
  "text" : "@johl @antischokke @Kommunikonautin @maeusehaut yay, so many friendly faces! \uD83C\uDF89",
  "id" : 790592396362940416,
  "in_reply_to_status_id" : 790592287168425985,
  "created_at" : "2016-10-24 16:34:50 +0000",
  "in_reply_to_screen_name" : "johl",
  "in_reply_to_user_id_str" : "1147751",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 0, 5 ],
      "id_str" : "1147751",
      "id" : 1147751
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 6, 21 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790591732463374337",
  "geo" : { },
  "id_str" : "790591870820880384",
  "in_reply_to_user_id" : 1147751,
  "text" : "@johl @MozillaScience yay! Wiki-Dataing again? (typo nearly made that wiki-dating \uD83D\uDE02).",
  "id" : 790591870820880384,
  "in_reply_to_status_id" : 790591732463374337,
  "created_at" : "2016-10-24 16:32:45 +0000",
  "in_reply_to_screen_name" : "johl",
  "in_reply_to_user_id_str" : "1147751",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/n7j9rNdE7b",
      "expanded_url" : "https:\/\/twitter.com\/MozillaScience\/status\/790583872157282304",
      "display_url" : "twitter.com\/MozillaScience\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790591510198808576",
  "text" : "I just prepared more of our session and I\u2019m getting more excited for it each passing day. \uD83C\uDF89\uD83C\uDF89\uD83C\uDF89 https:\/\/t.co\/n7j9rNdE7b",
  "id" : 790591510198808576,
  "created_at" : "2016-10-24 16:31:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790528758167941120",
  "geo" : { },
  "id_str" : "790566911864176644",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer wow, I didn\u2019t know that down under was really that different!",
  "id" : 790566911864176644,
  "in_reply_to_status_id" : 790528758167941120,
  "created_at" : "2016-10-24 14:53:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 11, 20 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790548805221507073",
  "geo" : { },
  "id_str" : "790566416361594882",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe @abbycabs yeah, the worst kind of WEIRD. :(",
  "id" : 790566416361594882,
  "in_reply_to_status_id" : 790548805221507073,
  "created_at" : "2016-10-24 14:51:36 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 10, 20 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/orcOpABRqS",
      "expanded_url" : "https:\/\/github.com\/openSNP\/presentations\/blob\/master\/2016\/2016-09-22-personalizedhealth.pdf",
      "display_url" : "github.com\/openSNP\/presen\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "790554609035116548",
  "geo" : { },
  "id_str" : "790564939803033601",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @biocrusoe yes, did a talk on the topic a month ago, see slides here. https:\/\/t.co\/orcOpABRqS",
  "id" : 790564939803033601,
  "in_reply_to_status_id" : 790554609035116548,
  "created_at" : "2016-10-24 14:45:44 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 14, 27 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790507737331425280",
  "geo" : { },
  "id_str" : "790508498576674816",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas @PhilippBayer e.g. the same people that need to be afraid of sharing data will still be afraid after it\u2019s cheaper.",
  "id" : 790508498576674816,
  "in_reply_to_status_id" : 790507737331425280,
  "created_at" : "2016-10-24 11:01:27 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 14, 27 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790507737331425280",
  "geo" : { },
  "id_str" : "790508364337975296",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas @PhilippBayer I\u2019m skeptical that this will change. It\u2019s less an attitude issue in that sense\/more a discrimination issue.",
  "id" : 790508364337975296,
  "in_reply_to_status_id" : 790507737331425280,
  "created_at" : "2016-10-24 11:00:55 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 14, 27 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790507237928235008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241510600897, 8.627527241325943 ]
  },
  "id_str" : "790507396754006016",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas @PhilippBayer yes, but the former will not change a lot if the latter doesn\u2019t :)",
  "id" : 790507396754006016,
  "in_reply_to_status_id" : 790507237928235008,
  "created_at" : "2016-10-24 10:57:04 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 14, 27 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790503331877752832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240032432539, 8.627486781059211 ]
  },
  "id_str" : "790503599142993922",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas @PhilippBayer that\u2019s only part of the problem I think. Having to fear consequences for doing so is another.",
  "id" : 790503599142993922,
  "in_reply_to_status_id" : 790503331877752832,
  "created_at" : "2016-10-24 10:41:59 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 14, 27 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790501190282817536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240032432539, 8.627486781059211 ]
  },
  "id_str" : "790503096677957632",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @manuelcorpas thanks, guess we\u2019ll need to find more funding for diversity like back in 2012.",
  "id" : 790503096677957632,
  "in_reply_to_status_id" : 790501190282817536,
  "created_at" : "2016-10-24 10:39:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/WNOCI5hxNa",
      "expanded_url" : "https:\/\/twitter.com\/manuelcorpas\/status\/790500472159281152",
      "display_url" : "twitter.com\/manuelcorpas\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240032432539, 8.627486781059211 ]
  },
  "id_str" : "790502949046845440",
  "text" : "Unfortunately openSNP et al. are still as WEIRD as they were about a year ago. \uD83D\uDE22 https:\/\/t.co\/WNOCI5hxNa",
  "id" : 790502949046845440,
  "created_at" : "2016-10-24 10:39:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/790482392653918208\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/qemgusBj2I",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CvhbiTXWIAA154w.jpg",
      "id_str" : "790482379475394560",
      "id" : 790482379475394560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CvhbiTXWIAA154w.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/qemgusBj2I"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790482392653918208",
  "text" : "Answering an interview about open science in a Word document. https:\/\/t.co\/qemgusBj2I",
  "id" : 790482392653918208,
  "created_at" : "2016-10-24 09:17:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Blaxter Lab",
      "screen_name" : "blaxterlab",
      "indices" : [ 46, 57 ],
      "id_str" : "708244146104967168",
      "id" : 708244146104967168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790460068290523136",
  "geo" : { },
  "id_str" : "790460596760285185",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 nope, but I admire the work of the @blaxterlab \uD83D\uDE07",
  "id" : 790460596760285185,
  "in_reply_to_status_id" : 790460068290523136,
  "created_at" : "2016-10-24 07:51:06 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/iTxdIRAoZE",
      "expanded_url" : "https:\/\/www.theguardian.com\/world\/2005\/oct\/18\/gender.uk",
      "display_url" : "theguardian.com\/world\/2005\/oct\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790459568342069248",
  "text" : "Today in 1975: 90% of Iceland\u2019s women go on strike. https:\/\/t.co\/iTxdIRAoZE",
  "id" : 790459568342069248,
  "created_at" : "2016-10-24 07:47:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790436077823725568",
  "geo" : { },
  "id_str" : "790457252415143936",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe framed differently: fake news gets accepted by fake journalist",
  "id" : 790457252415143936,
  "in_reply_to_status_id" : 790436077823725568,
  "created_at" : "2016-10-24 07:37:49 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/Tg2VCGOQyD",
      "expanded_url" : "https:\/\/twitter.com\/GigaScience\/status\/790407913257009153",
      "display_url" : "twitter.com\/GigaScience\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790454184449568768",
  "text" : "When you paid your hybrid-OA fee but the journal still doesn\u2019t freely distribute your paper. https:\/\/t.co\/Tg2VCGOQyD",
  "id" : 790454184449568768,
  "created_at" : "2016-10-24 07:25:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/36g5EzEPCB",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/790448463766917121",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790450329087270912",
  "text" : "I\u2019ll take it. \u00ABAs shown in Who et al., time is more like a big ball of wibbly wobbly... time-y wimey... stuff.\u00BB https:\/\/t.co\/36g5EzEPCB",
  "id" : 790450329087270912,
  "created_at" : "2016-10-24 07:10:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/790446605296144384\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/1sa134o2zn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvg6_txW8AAy5vx.jpg",
      "id_str" : "790446600896311296",
      "id" : 790446600896311296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvg6_txW8AAy5vx.jpg",
      "sizes" : [ {
        "h" : 129,
        "resize" : "fit",
        "w" : 221
      }, {
        "h" : 129,
        "resize" : "fit",
        "w" : 221
      }, {
        "h" : 129,
        "resize" : "fit",
        "w" : 221
      }, {
        "h" : 129,
        "resize" : "fit",
        "w" : 221
      }, {
        "h" : 129,
        "resize" : "crop",
        "w" : 129
      } ],
      "display_url" : "pic.twitter.com\/1sa134o2zn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790446605296144384",
  "text" : "Horizontal gene transfer is so 2015. Trusting my time-calibrated tree I proclaim time-traveling gene transfer. https:\/\/t.co\/1sa134o2zn",
  "id" : 790446605296144384,
  "created_at" : "2016-10-24 06:55:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790414421529165824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17205795931311, 8.628095674725468 ]
  },
  "id_str" : "790435232625352704",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 we did have a bit of a trouble to spin up CLIs for each of the 22 students. But I guess we just produced too much load.",
  "id" : 790435232625352704,
  "in_reply_to_status_id" : 790414421529165824,
  "created_at" : "2016-10-24 06:10:19 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/790336369524613120\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/7YioUQhPrG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvfWvMkWgAA8NDX.jpg",
      "id_str" : "790336365942702080",
      "id" : 790336365942702080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvfWvMkWgAA8NDX.jpg",
      "sizes" : [ {
        "h" : 281,
        "resize" : "fit",
        "w" : 676
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 676
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 676
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 676
      } ],
      "display_url" : "pic.twitter.com\/7YioUQhPrG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790336369524613120",
  "text" : "Similar books according to Goodreads: I knew some people have resentments towards math, but I didn\u2019t expect that\u2026 https:\/\/t.co\/7YioUQhPrG",
  "id" : 790336369524613120,
  "created_at" : "2016-10-23 23:37:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/0eYXd3yFye",
      "expanded_url" : "http:\/\/asofterworld.com\/index.php?id=460",
      "display_url" : "asofterworld.com\/index.php?id=4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790317244773441536",
  "text" : "\u00ABThe only surprise is that there was a second date. After telling me you don\u2019t enjoy \u2018a softer world\u2019 on the first.\u00BB https:\/\/t.co\/0eYXd3yFye",
  "id" : 790317244773441536,
  "created_at" : "2016-10-23 22:21:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790303254630506497",
  "geo" : { },
  "id_str" : "790303889195208709",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 all the best for it!",
  "id" : 790303889195208709,
  "in_reply_to_status_id" : 790303254630506497,
  "created_at" : "2016-10-23 21:28:24 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790299065011564544",
  "geo" : { },
  "id_str" : "790301877539921920",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 rightfully so. Especially given that\u2019s the first video edit!",
  "id" : 790301877539921920,
  "in_reply_to_status_id" : 790299065011564544,
  "created_at" : "2016-10-23 21:20:25 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790296015022788608",
  "geo" : { },
  "id_str" : "790298931972431878",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 it\u2019s hilarious. Watched it two times even :D",
  "id" : 790298931972431878,
  "in_reply_to_status_id" : 790296015022788608,
  "created_at" : "2016-10-23 21:08:43 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/mwG8ZXRSrI",
      "expanded_url" : "https:\/\/twitter.com\/Julie_B92\/status\/790289286201483268",
      "display_url" : "twitter.com\/Julie_B92\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790295792447844352",
  "text" : "\u00ABSick of not being any good at taxonomy? Nanopore has the answer for you!\u00BB \uD83D\uDE02\uD83D\uDE02\uD83D\uDE02 https:\/\/t.co\/mwG8ZXRSrI",
  "id" : 790295792447844352,
  "created_at" : "2016-10-23 20:56:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 10, 23 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790287381421236225",
  "geo" : { },
  "id_str" : "790289902223101952",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @jeroenbosman great, let me drop by yours!",
  "id" : 790289902223101952,
  "in_reply_to_status_id" : 790287381421236225,
  "created_at" : "2016-10-23 20:32:50 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790282201623584768",
  "geo" : { },
  "id_str" : "790282598929039360",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps i assume the survey_presets_frequencies_119 worksheet in the file linked in your draft is the raw-one?",
  "id" : 790282598929039360,
  "in_reply_to_status_id" : 790282201623584768,
  "created_at" : "2016-10-23 20:03:48 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 64, 72 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 74, 84 ],
      "id_str" : "186529934",
      "id" : 186529934
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 89, 96 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/ml2zsq6NVr",
      "expanded_url" : "https:\/\/app.mozillafestival.org\/#_session-443",
      "display_url" : "app.mozillafestival.org\/#_session-443"
    } ]
  },
  "in_reply_to_status_id_str" : "790282201623584768",
  "geo" : { },
  "id_str" : "790282446562533379",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps yes, https:\/\/t.co\/ml2zsq6NVr will be ours. Along with @Seplute, @auremoser and @sujaik.",
  "id" : 790282446562533379,
  "in_reply_to_status_id" : 790282201623584768,
  "created_at" : "2016-10-23 20:03:12 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790273167482884096",
  "geo" : { },
  "id_str" : "790281255153704960",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps I\u2019ll try to have a look tomorrow morning pre-teaching. Is the raw (and\/or corrected) tool-by-tool count-matrix somewhere? :)",
  "id" : 790281255153704960,
  "in_reply_to_status_id" : 790273167482884096,
  "created_at" : "2016-10-23 19:58:28 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790271562834382849",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140303330607, 8.753386871124738 ]
  },
  "id_str" : "790271760180674560",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps we can do that! but we can also do it in person at Mozfest after we missed the chance in San Diego?",
  "id" : 790271760180674560,
  "in_reply_to_status_id" : 790271562834382849,
  "created_at" : "2016-10-23 19:20:44 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "790267196727517184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402848786081, 8.753352247743802 ]
  },
  "id_str" : "790267919552942080",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette \uD83D\uDE0D guess i need some excuse to go to Porto \uD83D\uDE09",
  "id" : 790267919552942080,
  "in_reply_to_status_id" : 790267196727517184,
  "created_at" : "2016-10-23 19:05:29 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/ALptgSZwif",
      "expanded_url" : "https:\/\/de.wikipedia.org\/wiki\/Neubau_der_Europ%C3%A4ischen_Zentralbank#\/media\/File:EZB_Neubau_Detail.JPG",
      "display_url" : "de.wikipedia.org\/wiki\/Neubau_de\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "790223472710520832",
  "geo" : { },
  "id_str" : "790252810487078914",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette I like the spaceship-esk entry building. https:\/\/t.co\/ALptgSZwif",
  "id" : 790252810487078914,
  "in_reply_to_status_id" : 790223472710520832,
  "created_at" : "2016-10-23 18:05:26 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/ml2zsq6NVr",
      "expanded_url" : "https:\/\/app.mozillafestival.org\/#_session-443",
      "display_url" : "app.mozillafestival.org\/#_session-443"
    } ]
  },
  "geo" : { },
  "id_str" : "790248962016088065",
  "text" : "Prep for this year\u2019s #mozfest session. https:\/\/t.co\/ml2zsq6NVr",
  "id" : 790248962016088065,
  "created_at" : "2016-10-23 17:50:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/M4O81EyNS8",
      "expanded_url" : "http:\/\/www.theverge.com\/2016\/10\/22\/13367414\/tompkins-square-halloween-dog-parade-new-york-city-photos",
      "display_url" : "theverge.com\/2016\/10\/22\/133\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790238920407654400",
  "text" : "There was a Halloween Dog Parade and I was not informed? Internet friends, you\u2019re letting me down! https:\/\/t.co\/M4O81EyNS8",
  "id" : 790238920407654400,
  "created_at" : "2016-10-23 17:10:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/N8cRpXIgGC",
      "expanded_url" : "https:\/\/twitter.com\/lexnederbragt\/status\/789473542278701056",
      "display_url" : "twitter.com\/lexnederbragt\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11378923435706, 8.754168218009877 ]
  },
  "id_str" : "790219401014509568",
  "text" : "\u00ABYou forced me to become a bioinformatician.\u00BB Same here, thanks 454. https:\/\/t.co\/N8cRpXIgGC",
  "id" : 790219401014509568,
  "created_at" : "2016-10-23 15:52:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/EbpWJDxovw",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BL6O3oIDLxT\/",
      "display_url" : "instagram.com\/p\/BL6O3oIDLxT\/"
    } ]
  },
  "geo" : { },
  "id_str" : "790208025848143873",
  "text" : "ECB https:\/\/t.co\/EbpWJDxovw",
  "id" : 790208025848143873,
  "created_at" : "2016-10-23 15:07:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/sgpZ66VJTs",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BL5rq6lDxV_\/",
      "display_url" : "instagram.com\/p\/BL5rq6lDxV_\/"
    } ]
  },
  "geo" : { },
  "id_str" : "790130621989388288",
  "text" : "Floating around https:\/\/t.co\/sgpZ66VJTs",
  "id" : 790130621989388288,
  "created_at" : "2016-10-23 09:59:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 13, 25 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789945038486646784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403053776823, 8.753395416439181 ]
  },
  "id_str" : "789955755378151424",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @froggleston sounds awesome to me!",
  "id" : 789955755378151424,
  "in_reply_to_status_id" : 789945038486646784,
  "created_at" : "2016-10-22 22:25:03 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 13, 25 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789900663161491456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388303237249, 8.753630994997872 ]
  },
  "id_str" : "789936554655506433",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @billymeinke where do we apply for funding? :)",
  "id" : 789936554655506433,
  "in_reply_to_status_id" : 789900663161491456,
  "created_at" : "2016-10-22 21:08:45 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 13, 25 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789878571741294592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403096421433, 8.753397399031751 ]
  },
  "id_str" : "789896359230971905",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @froggleston nah, but how about a crowd funding campaign? \uD83D\uDE02",
  "id" : 789896359230971905,
  "in_reply_to_status_id" : 789878571741294592,
  "created_at" : "2016-10-22 18:29:02 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 13, 25 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789875477590573056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140304634916, 8.753387482451517 ]
  },
  "id_str" : "789875854696382464",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @froggleston nooo! now i need an excuse to go to Hawaii even more urgently!",
  "id" : 789875854696382464,
  "in_reply_to_status_id" : 789875477590573056,
  "created_at" : "2016-10-22 17:07:33 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140310428436, 8.753397427557239 ]
  },
  "id_str" : "789817818074255361",
  "text" : "\u00ABDon\u2019t worry, drinking the moisture from your mustache is already fun enough for me.\u00BB",
  "id" : 789817818074255361,
  "created_at" : "2016-10-22 13:16:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 13, 25 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 69, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139419461802, 8.7535330382706 ]
  },
  "id_str" : "789817464154619904",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @froggleston are we bringing the band back together for #mozfest? :)",
  "id" : 789817464154619904,
  "created_at" : "2016-10-22 13:15:32 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/nn3NVN3eoT",
      "expanded_url" : "https:\/\/twitter.com\/JordanRasko\/status\/789675713032880128",
      "display_url" : "twitter.com\/JordanRasko\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401216825336, 8.75305486056979 ]
  },
  "id_str" : "789714200557944832",
  "text" : "Yes, it's three-ness always gets me! https:\/\/t.co\/nn3NVN3eoT",
  "id" : 789714200557944832,
  "created_at" : "2016-10-22 06:25:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/v3HRTjxRhA",
      "expanded_url" : "https:\/\/45.media.tumblr.com\/bc12966e77b1762eeaae76883d398618\/tumblr_o3468wMIVs1sffhtao1_400.gif",
      "display_url" : "45.media.tumblr.com\/bc12966e77b176\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17149784141236, 8.627874059610653 ]
  },
  "id_str" : "789476784047882240",
  "text" : "Just making it through the day deserves this already. https:\/\/t.co\/v3HRTjxRhA",
  "id" : 789476784047882240,
  "created_at" : "2016-10-21 14:41:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789387148185051136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17245111100119, 8.62752145047522 ]
  },
  "id_str" : "789445875844182016",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 DBG-display with bandage?",
  "id" : 789445875844182016,
  "in_reply_to_status_id" : 789387148185051136,
  "created_at" : "2016-10-21 12:38:58 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/9lLA9uLGPz",
      "expanded_url" : "https:\/\/twitter.com\/Julie_B92\/status\/789381188741922816",
      "display_url" : "twitter.com\/Julie_B92\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172448588004, 8.627532266639536 ]
  },
  "id_str" : "789438785603964928",
  "text" : "Sorry, couldn\u2019t sequence the samples. Had to preserve battery to look at cat gifs on Twitter. https:\/\/t.co\/9lLA9uLGPz",
  "id" : 789438785603964928,
  "created_at" : "2016-10-21 12:10:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789371033908310016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237855681943, 8.627539603987914 ]
  },
  "id_str" : "789393432779173888",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU (my shower always performs weird actions on my watch ;))",
  "id" : 789393432779173888,
  "in_reply_to_status_id" : 789371033908310016,
  "created_at" : "2016-10-21 09:10:35 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789371645282705408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237855681943, 8.627539603987914 ]
  },
  "id_str" : "789393337975398400",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU and if you want to spend time with a SO that\u2019s physically not available you can use the phone :p",
  "id" : 789393337975398400,
  "in_reply_to_status_id" : 789371645282705408,
  "created_at" : "2016-10-21 09:10:12 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403226389991, 8.753389285790893 ]
  },
  "id_str" : "789336226839064577",
  "text" : "\u00ABOur relationship transcends language.\u00BB \u2014 \u00ABSuch a fancy way of saying you\u2019ve been sending out gifs of cats and dogs.\u00BB",
  "id" : 789336226839064577,
  "created_at" : "2016-10-21 05:23:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789244367131316224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403226389991, 8.753389285790893 ]
  },
  "id_str" : "789335706678259712",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU ever tried using a touchscreen while showering? Typing is so hard when it\u2019s wet!",
  "id" : 789335706678259712,
  "in_reply_to_status_id" : 789244367131316224,
  "created_at" : "2016-10-21 05:21:12 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate DiMeo",
      "screen_name" : "thememorypalace",
      "indices" : [ 0, 16 ],
      "id_str" : "60200577",
      "id" : 60200577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/ZAZhPhP4ol",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/8a228f270eefb00f60b522fb32292a92\/tumblr_n1vybbqJxA1sezoa7o1_400.gif",
      "display_url" : "25.media.tumblr.com\/8a228f270eefb0\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "789201727849320452",
  "geo" : { },
  "id_str" : "789202636654407680",
  "in_reply_to_user_id" : 60200577,
  "text" : "@thememorypalace sounds like https:\/\/t.co\/ZAZhPhP4ol (my favorite podcast just became even better! \uD83D\uDE0D\uD83D\uDC36)",
  "id" : 789202636654407680,
  "in_reply_to_status_id" : 789201727849320452,
  "created_at" : "2016-10-20 20:32:25 +0000",
  "in_reply_to_screen_name" : "thememorypalace",
  "in_reply_to_user_id_str" : "60200577",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate DiMeo",
      "screen_name" : "thememorypalace",
      "indices" : [ 0, 16 ],
      "id_str" : "60200577",
      "id" : 60200577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789201144278941696",
  "geo" : { },
  "id_str" : "789201495711322112",
  "in_reply_to_user_id" : 60200577,
  "text" : "@thememorypalace what\u2019s their name?",
  "id" : 789201495711322112,
  "in_reply_to_status_id" : 789201144278941696,
  "created_at" : "2016-10-20 20:27:53 +0000",
  "in_reply_to_screen_name" : "thememorypalace",
  "in_reply_to_user_id_str" : "60200577",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789194392246509568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11085602925169, 8.759191157304457 ]
  },
  "id_str" : "789195223473590272",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 \u201CI\u2019ll just keep doing that for a little while\u201D",
  "id" : 789195223473590272,
  "in_reply_to_status_id" : 789194392246509568,
  "created_at" : "2016-10-20 20:02:58 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/789194315708760064\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/n4kicSDSax",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CvPICCCUsAA8ixh.jpg",
      "id_str" : "789194296951877632",
      "id" : 789194296951877632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CvPICCCUsAA8ixh.jpg",
      "sizes" : [ {
        "h" : 472,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 472,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 472,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 472,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/n4kicSDSax"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789193545915609088",
  "geo" : { },
  "id_str" : "789194315708760064",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 trying to keep up my speed on the hamster wheel https:\/\/t.co\/n4kicSDSax",
  "id" : 789194315708760064,
  "in_reply_to_status_id" : 789193545915609088,
  "created_at" : "2016-10-20 19:59:22 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "789192305697665024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140329420296, 8.753388189026916 ]
  },
  "id_str" : "789193420099100673",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 yes, but all the work! \uD83D\uDE31",
  "id" : 789193420099100673,
  "in_reply_to_status_id" : 789192305697665024,
  "created_at" : "2016-10-20 19:55:48 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/789190428482412544\/photo\/1",
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/T40nkkk88l",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CvPD8JJVIAAitej.jpg",
      "id_str" : "789189797734588416",
      "id" : 789189797734588416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CvPD8JJVIAAitej.jpg",
      "sizes" : [ {
        "h" : 532,
        "resize" : "fit",
        "w" : 926
      }, {
        "h" : 532,
        "resize" : "fit",
        "w" : 926
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 532,
        "resize" : "fit",
        "w" : 926
      }, {
        "h" : 391,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/T40nkkk88l"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789190428482412544",
  "text" : "Can I call it a day, pls? https:\/\/t.co\/T40nkkk88l",
  "id" : 789190428482412544,
  "created_at" : "2016-10-20 19:43:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/y5mma2SY6U",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/the-gigantic-nazi-city-that-was-never-built",
      "display_url" : "atlasobscura.com\/articles\/the-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "789180795818692609",
  "text" : "The Gigantic Nazi City that Was Never Built. Or: Why \u201EGermania\u201C is the worst airline name ever. https:\/\/t.co\/y5mma2SY6U",
  "id" : 789180795818692609,
  "created_at" : "2016-10-20 19:05:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/789111513315442688\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/1dG2cWovjE",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CvN8uONWEAE7Mgi.jpg",
      "id_str" : "789111493249863681",
      "id" : 789111493249863681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CvN8uONWEAE7Mgi.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 220
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 220
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 220
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 220
      } ],
      "display_url" : "pic.twitter.com\/1dG2cWovjE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789111513315442688",
  "text" : "Haven't done anything but teaching all day. Feels like some nap time would be appropriate. https:\/\/t.co\/1dG2cWovjE",
  "id" : 789111513315442688,
  "created_at" : "2016-10-20 14:30:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 51, 61 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/DEBVnacstn",
      "expanded_url" : "http:\/\/rik.smith-unna.com\/command_line_bootcamp\/",
      "display_url" : "rik.smith-unna.com\/command_line_b\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239998034709, 8.627487355943746 ]
  },
  "id_str" : "789053192797585408",
  "text" : "So far: spend half a day of running people through @blahah404\u2032s bash bootcamp. https:\/\/t.co\/DEBVnacstn",
  "id" : 789053192797585408,
  "created_at" : "2016-10-20 10:38:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conner Habib",
      "screen_name" : "ConnerHabib",
      "indices" : [ 3, 15 ],
      "id_str" : "27513314",
      "id" : 27513314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788990685529645056",
  "text" : "RT @ConnerHabib: One of my favorite interviews w Susan Sontag. To answer the questions would be to lose herself. So she doesn't.\nhttps:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/SLHBhr2xyz",
        "expanded_url" : "https:\/\/youtu.be\/7Mmi03G5oV0",
        "display_url" : "youtu.be\/7Mmi03G5oV0"
      } ]
    },
    "geo" : { },
    "id_str" : "788906898531549184",
    "text" : "One of my favorite interviews w Susan Sontag. To answer the questions would be to lose herself. So she doesn't.\nhttps:\/\/t.co\/SLHBhr2xyz",
    "id" : 788906898531549184,
    "created_at" : "2016-10-20 00:57:16 +0000",
    "user" : {
      "name" : "Conner Habib",
      "screen_name" : "ConnerHabib",
      "protected" : false,
      "id_str" : "27513314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/921495228984332289\/LhDY3muU_normal.jpg",
      "id" : 27513314,
      "verified" : true
    }
  },
  "id" : 788990685529645056,
  "created_at" : "2016-10-20 06:30:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17154110206691, 8.627723081639735 ]
  },
  "id_str" : "788988099359600640",
  "text" : "Most transformative part of having a smart watch: easily doing calls while taking a shower.",
  "id" : 788988099359600640,
  "created_at" : "2016-10-20 06:19:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/JdaZhk7ouS",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/29358558?source=ebfg_tw",
      "display_url" : "goodreads.com\/book\/show\/2935\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06081431075349, 8.818664122126265 ]
  },
  "id_str" : "788877183225851904",
  "text" : "Meh, \u201CWhen in French: Love in a Second Language\u201D is +\/- a  ripoff of Guy Deutscher\u2019s \u201CThrough the Language Glass\u201D https:\/\/t.co\/JdaZhk7ouS",
  "id" : 788877183225851904,
  "created_at" : "2016-10-19 22:59:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/mzBdYfa000",
      "expanded_url" : "https:\/\/s-media-cache-ak0.pinimg.com\/736x\/7b\/a9\/3b\/7ba93b73cc3a54b71ee1fc79b4e70a59.jpg",
      "display_url" : "s-media-cache-ak0.pinimg.com\/736x\/7b\/a9\/3b\/\u2026"
    }, {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/ReSLW2lAZt",
      "expanded_url" : "https:\/\/twitter.com\/bella_velo\/status\/788848286975324162",
      "display_url" : "twitter.com\/bella_velo\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0609676624155, 8.818717389108805 ]
  },
  "id_str" : "788849359161061376",
  "text" : "Julian just didn\u2019t do his chores, failing #4 on the list. https:\/\/t.co\/mzBdYfa000 https:\/\/t.co\/ReSLW2lAZt",
  "id" : 788849359161061376,
  "created_at" : "2016-10-19 21:08:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788839869946720256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084219658267, 8.818548624268791 ]
  },
  "id_str" : "788839961000837124",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 nooo :( sucks, sorry to hear :(",
  "id" : 788839961000837124,
  "in_reply_to_status_id" : 788839869946720256,
  "created_at" : "2016-10-19 20:31:17 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788837802465173504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06088088926067, 8.818473763143775 ]
  },
  "id_str" : "788839716556836866",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 yes, polite reminder tomorrow morning I\u2019d say.",
  "id" : 788839716556836866,
  "in_reply_to_status_id" : 788837802465173504,
  "created_at" : "2016-10-19 20:30:19 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 3, 15 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "diversity",
      "indices" : [ 37, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/I0ODcb6PQf",
      "expanded_url" : "https:\/\/www.theguardian.com\/technology\/2016\/oct\/19\/peter-thiel-support-donald-trump-mark-zuckerberg?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/technology\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "788839185822191617",
  "text" : "RT @jonfwilkins: Country AND Western #diversity https:\/\/t.co\/I0ODcb6PQf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "diversity",
        "indices" : [ 20, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/I0ODcb6PQf",
        "expanded_url" : "https:\/\/www.theguardian.com\/technology\/2016\/oct\/19\/peter-thiel-support-donald-trump-mark-zuckerberg?CMP=share_btn_tw",
        "display_url" : "theguardian.com\/technology\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "788836291773358084",
    "text" : "Country AND Western #diversity https:\/\/t.co\/I0ODcb6PQf",
    "id" : 788836291773358084,
    "created_at" : "2016-10-19 20:16:42 +0000",
    "user" : {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "protected" : false,
      "id_str" : "214099847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1279449740\/Dev2DEC_normal.jpg",
      "id" : 214099847,
      "verified" : false
    }
  },
  "id" : 788839185822191617,
  "created_at" : "2016-10-19 20:28:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 9, 20 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788824892972072960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091711834138, 8.818463676276407 ]
  },
  "id_str" : "788830150922297344",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H @bella_velo I love how our silly conversations becomes more and more relevant.",
  "id" : 788830150922297344,
  "in_reply_to_status_id" : 788824892972072960,
  "created_at" : "2016-10-19 19:52:18 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788784226158116864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06095926604555, 8.818594942892124 ]
  },
  "id_str" : "788784389996089344",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog dammit!",
  "id" : 788784389996089344,
  "in_reply_to_status_id" : 788784226158116864,
  "created_at" : "2016-10-19 16:50:28 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788783539470864384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06095374007715, 8.818588089206086 ]
  },
  "id_str" : "788784145237442561",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog sure!",
  "id" : 788784145237442561,
  "in_reply_to_status_id" : 788783539470864384,
  "created_at" : "2016-10-19 16:49:29 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/GL1PdVBlVC",
      "expanded_url" : "https:\/\/twitter.com\/authorea\/status\/788774202321035264",
      "display_url" : "twitter.com\/authorea\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06136063956661, 8.807371258743858 ]
  },
  "id_str" : "788780235110113280",
  "text" : "Doing this is also known as: How to get away with making shit up. https:\/\/t.co\/GL1PdVBlVC",
  "id" : 788780235110113280,
  "created_at" : "2016-10-19 16:33:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Gailey",
      "screen_name" : "gaileyfrey",
      "indices" : [ 3, 14 ],
      "id_str" : "23715059",
      "id" : 23715059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788735496256118785",
  "text" : "RT @gaileyfrey: RT if you've ever said \"thank you\" to a strange dog after petting it",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788593914668261378",
    "text" : "RT if you've ever said \"thank you\" to a strange dog after petting it",
    "id" : 788593914668261378,
    "created_at" : "2016-10-19 04:13:35 +0000",
    "user" : {
      "name" : "Sarah Gailey",
      "screen_name" : "gaileyfrey",
      "protected" : false,
      "id_str" : "23715059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927982296543633408\/WOTQ3SAG_normal.jpg",
      "id" : 23715059,
      "verified" : false
    }
  },
  "id" : 788735496256118785,
  "created_at" : "2016-10-19 13:36:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788718819099410433",
  "geo" : { },
  "id_str" : "788724871664693248",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai awesome, congrats!",
  "id" : 788724871664693248,
  "in_reply_to_status_id" : 788718819099410433,
  "created_at" : "2016-10-19 12:53:57 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788717601035722752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241292680749, 8.627480703667958 ]
  },
  "id_str" : "788718025516126208",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that\u2019s the first time I feel I\u2019m missing out by being childless!",
  "id" : 788718025516126208,
  "in_reply_to_status_id" : 788717601035722752,
  "created_at" : "2016-10-19 12:26:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788716205678796801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240485436209, 8.627490663056827 ]
  },
  "id_str" : "788716664569430017",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I didn\u2019t know the Mosel area was known for carnivalesk humor as well \uD83D\uDE02",
  "id" : 788716664569430017,
  "in_reply_to_status_id" : 788716205678796801,
  "created_at" : "2016-10-19 12:21:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788713451489112064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240742645722, 8.627477875183653 ]
  },
  "id_str" : "788713924137025536",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u201Chere we\u2019re presenting the words smallest random forest\u201D.",
  "id" : 788713924137025536,
  "in_reply_to_status_id" : 788713451489112064,
  "created_at" : "2016-10-19 12:10:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/CLHIQJ7EF6",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/788711381516156928",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240542129288, 8.627489947343236 ]
  },
  "id_str" : "788711937886617600",
  "text" : "Should have used deep learning instead. *sigh* https:\/\/t.co\/CLHIQJ7EF6",
  "id" : 788711937886617600,
  "created_at" : "2016-10-19 12:02:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/VWEuXs62jV",
      "expanded_url" : "https:\/\/aeon.co\/ideas\/women-with-heart-disease-get-a-raw-deal-in-medicine",
      "display_url" : "aeon.co\/ideas\/women-wi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "788709484046712832",
  "text" : "On the gender bias of Medicine. https:\/\/t.co\/VWEuXs62jV",
  "id" : 788709484046712832,
  "created_at" : "2016-10-19 11:52:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237718421763, 8.627540280312461 ]
  },
  "id_str" : "788683432733933572",
  "text" : "Number of students for the evolutionary bioinformatics course skyrocketed from 5 to 23. Nice. And extremely terrifying.",
  "id" : 788683432733933572,
  "created_at" : "2016-10-19 10:09:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Reza Nazmi",
      "screen_name" : "FreeLantern",
      "indices" : [ 0, 12 ],
      "id_str" : "3103688958",
      "id" : 3103688958
    }, {
      "name" : "Paul Gardner",
      "screen_name" : "ppgardne",
      "indices" : [ 13, 22 ],
      "id_str" : "136532538",
      "id" : 136532538
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 23, 33 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788655329261203456",
  "geo" : { },
  "id_str" : "788663103147872257",
  "in_reply_to_user_id" : 3103688958,
  "text" : "@FreeLantern @ppgardne @Julie_B92 damn, why am I not doing this!",
  "id" : 788663103147872257,
  "in_reply_to_status_id" : 788655329261203456,
  "created_at" : "2016-10-19 08:48:31 +0000",
  "in_reply_to_screen_name" : "FreeLantern",
  "in_reply_to_user_id_str" : "3103688958",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788635924448088064",
  "geo" : { },
  "id_str" : "788636001061265413",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 an even better reason to exit the airport and visit the bio-campus!",
  "id" : 788636001061265413,
  "in_reply_to_status_id" : 788635924448088064,
  "created_at" : "2016-10-19 07:00:49 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/a16F1heB2S",
      "expanded_url" : "https:\/\/instagram.com\/p\/tZsg0chwuw\/",
      "display_url" : "instagram.com\/p\/tZsg0chwuw\/"
    } ]
  },
  "in_reply_to_status_id_str" : "788635208048381954",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239328263041, 8.627479794774587 ]
  },
  "id_str" : "788635701554323456",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 https:\/\/t.co\/a16F1heB2S happy to offee one if you come around FRA one day.",
  "id" : 788635701554323456,
  "in_reply_to_status_id" : 788635208048381954,
  "created_at" : "2016-10-19 06:59:38 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/788631450081955841\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/xegmclst0g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvHIH9GW8AARqy7.jpg",
      "id_str" : "788631448752418816",
      "id" : 788631448752418816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvHIH9GW8AARqy7.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xegmclst0g"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788631450081955841",
  "text" : "How many tons of coffee do you need to feed a group of bioinformaticians for a week? https:\/\/t.co\/xegmclst0g",
  "id" : 788631450081955841,
  "created_at" : "2016-10-19 06:42:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 3, 15 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788493255201742848",
  "text" : "RT @ctitusbrown: One mentor wrote letters claiming I was the worst graduate student they'd ever had, and then offered alternative sugg for\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/RW51tsPeys",
        "expanded_url" : "https:\/\/twitter.com\/DynamicEcology\/status\/788339663618449408",
        "display_url" : "twitter.com\/DynamicEcology\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "788411666446770177",
    "text" : "One mentor wrote letters claiming I was the worst graduate student they'd ever had, and then offered alternative sugg for position. 1\/3 https:\/\/t.co\/RW51tsPeys",
    "id" : 788411666446770177,
    "created_at" : "2016-10-18 16:09:23 +0000",
    "user" : {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "protected" : false,
      "id_str" : "26616462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662714429742514176\/bwLg2tBG_normal.jpg",
      "id" : 26616462,
      "verified" : false
    }
  },
  "id" : 788493255201742848,
  "created_at" : "2016-10-18 21:33:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788485900237934596",
  "geo" : { },
  "id_str" : "788485992550395904",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski cool, looking forward to it! :)",
  "id" : 788485992550395904,
  "in_reply_to_status_id" : 788485900237934596,
  "created_at" : "2016-10-18 21:04:44 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/788478646034071552\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/vKpancmSCg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvE9JiwXYAA2X8F.jpg",
      "id_str" : "788478643924328448",
      "id" : 788478643924328448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvE9JiwXYAA2X8F.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/vKpancmSCg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788478646034071552",
  "text" : "\u05D0\u05EA\u05D4 \u05E8\u05D5\u05D0\u05D4 \u05E6\u05D1\u05D4 \u05D1\u05DE\u05D3\u05D1\u05E8\u2026  \uD83D\uDC22\uD83C\uDFDC https:\/\/t.co\/vKpancmSCg",
  "id" : 788478646034071552,
  "created_at" : "2016-10-18 20:35:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788455701953863680",
  "geo" : { },
  "id_str" : "788470275037880321",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski I\u2019ll come in to BWI from KEF on 11th in the afternoon at some point. So will be tired, but sure! :-)",
  "id" : 788470275037880321,
  "in_reply_to_status_id" : 788455701953863680,
  "created_at" : "2016-10-18 20:02:17 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 8, 22 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 23, 32 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 33, 41 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788431175203360768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06090749739106, 8.818615363719358 ]
  },
  "id_str" : "788432536749899776",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb @Protohedgehog @open_con @mbeisen \uD83D\uDC96\uD83D\uDC96",
  "id" : 788432536749899776,
  "in_reply_to_status_id" : 788431175203360768,
  "created_at" : "2016-10-18 17:32:19 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 8, 22 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 23, 32 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 33, 41 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/788429442435518465\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/FGxnHZV9GO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvEQVd9WcAAERDt.jpg",
      "id_str" : "788429370771795968",
      "id" : 788429370771795968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvEQVd9WcAAERDt.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/FGxnHZV9GO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788428723460640769",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06089975395853, 8.818641395252964 ]
  },
  "id_str" : "788429442435518465",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb @Protohedgehog @open_con @mbeisen much appreciated. I know the pains :) https:\/\/t.co\/FGxnHZV9GO",
  "id" : 788429442435518465,
  "in_reply_to_status_id" : 788428723460640769,
  "created_at" : "2016-10-18 17:20:02 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey  Lee",
      "screen_name" : "leejoeyk",
      "indices" : [ 0, 9 ],
      "id_str" : "575961466",
      "id" : 575961466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788379606797676544",
  "geo" : { },
  "id_str" : "788379885165305856",
  "in_reply_to_user_id" : 575961466,
  "text" : "@leejoeyk cool, let\u2019s do this.",
  "id" : 788379885165305856,
  "in_reply_to_status_id" : 788379606797676544,
  "created_at" : "2016-10-18 14:03:06 +0000",
  "in_reply_to_screen_name" : "leejoeyk",
  "in_reply_to_user_id_str" : "575961466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey  Lee",
      "screen_name" : "leejoeyk",
      "indices" : [ 0, 9 ],
      "id_str" : "575961466",
      "id" : 575961466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788373179626577920",
  "geo" : { },
  "id_str" : "788379377641938944",
  "in_reply_to_user_id" : 575961466,
  "text" : "@leejoeyk for how long will you be in town? :)",
  "id" : 788379377641938944,
  "in_reply_to_status_id" : 788373179626577920,
  "created_at" : "2016-10-18 14:01:05 +0000",
  "in_reply_to_screen_name" : "leejoeyk",
  "in_reply_to_user_id_str" : "575961466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NKenge S. Barker",
      "screen_name" : "nkengesbarker",
      "indices" : [ 3, 17 ],
      "id_str" : "255224382",
      "id" : 255224382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/bg2HPJPfJM",
      "expanded_url" : "https:\/\/twitter.com\/Lg_on_the_Move\/status\/788152499329007616",
      "display_url" : "twitter.com\/Lg_on_the_Move\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "788361484577505280",
  "text" : "RT @nkengesbarker: As a bilingual, I say yes! https:\/\/t.co\/bg2HPJPfJM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/bg2HPJPfJM",
        "expanded_url" : "https:\/\/twitter.com\/Lg_on_the_Move\/status\/788152499329007616",
        "display_url" : "twitter.com\/Lg_on_the_Move\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "788170561344110596",
    "text" : "As a bilingual, I say yes! https:\/\/t.co\/bg2HPJPfJM",
    "id" : 788170561344110596,
    "created_at" : "2016-10-18 00:11:19 +0000",
    "user" : {
      "name" : "NKenge S. Barker",
      "screen_name" : "nkengesbarker",
      "protected" : false,
      "id_str" : "255224382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766103857969688576\/r2Fn680x_normal.jpg",
      "id" : 255224382,
      "verified" : false
    }
  },
  "id" : 788361484577505280,
  "created_at" : "2016-10-18 12:49:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 7, 21 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 22, 30 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/zx7ZIg9IUf",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/xT5LMILqdtZ4MPnTtC\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/xT5LMILq\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "788343803438661632",
  "geo" : { },
  "id_str" : "788346844829118464",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Protohedgehog @mbeisen meeting the paywall! https:\/\/t.co\/zx7ZIg9IUf",
  "id" : 788346844829118464,
  "in_reply_to_status_id" : 788343803438661632,
  "created_at" : "2016-10-18 11:51:49 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788330659991457792",
  "geo" : { },
  "id_str" : "788331365066502144",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin yeah, my student who wanted to basically re-implement your efforts will be happy that it\u2019s a) open source and b) easy to install!",
  "id" : 788331365066502144,
  "in_reply_to_status_id" : 788330659991457792,
  "created_at" : "2016-10-18 10:50:18 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788326406614839296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240448610322, 8.627487605578422 ]
  },
  "id_str" : "788328329678061569",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin wow, that\u2019s even better.",
  "id" : 788328329678061569,
  "in_reply_to_status_id" : 788326406614839296,
  "created_at" : "2016-10-18 10:38:14 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 7, 21 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 22, 30 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788324441667280896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238194177146, 8.627512596069835 ]
  },
  "id_str" : "788326308581367808",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Protohedgehog @mbeisen sending some disgusting sausages to a bunch of vegetarians? These are Elsevier tactics! \uD83D\uDE02",
  "id" : 788326308581367808,
  "in_reply_to_status_id" : 788324441667280896,
  "created_at" : "2016-10-18 10:30:13 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788324963438723073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238194177146, 8.627512596069835 ]
  },
  "id_str" : "788326103995846656",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin awesome, thanks!",
  "id" : 788326103995846656,
  "in_reply_to_status_id" : 788324963438723073,
  "created_at" : "2016-10-18 10:29:24 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17275085300044, 8.627578916347314 ]
  },
  "id_str" : "788322733021069312",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin you had a script to download bacterial genomes from NCBI somewhere, didn\u2019t you? :)",
  "id" : 788322733021069312,
  "created_at" : "2016-10-18 10:16:00 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 15, 23 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/PvQWK16xXC",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/788115336742797312",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "788311172848254976",
  "geo" : { },
  "id_str" : "788311533386366976",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @mbeisen can we go for black and pink or something for the colors though, c.f. https:\/\/t.co\/PvQWK16xXC",
  "id" : 788311533386366976,
  "in_reply_to_status_id" : 788311172848254976,
  "created_at" : "2016-10-18 09:31:30 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 58, 72 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/L8fWgGfAl1",
      "expanded_url" : "https:\/\/twitter.com\/mbeisen\/status\/788224927820197889",
      "display_url" : "twitter.com\/mbeisen\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "788310707150393344",
  "text" : "Going with #3. Next step: do crowdfunding campaign to get @Protohedgehog and me inked in DC. https:\/\/t.co\/L8fWgGfAl1",
  "id" : 788310707150393344,
  "created_at" : "2016-10-18 09:28:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 0, 13 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/7SxEryNyz7",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Choropleth_map#\/media\/File:Australian_Census_2011_demographic_map_-_Australia_by_SLA_-_BCP_field_2715_Christianity_Anglican_Persons.svg",
      "display_url" : "en.wikipedia.org\/wiki\/Choroplet\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "788306826379001856",
  "geo" : { },
  "id_str" : "788307344996306944",
  "in_reply_to_user_id" : 53639020,
  "text" : "@Unsichtbarer take here: A chlorochoropleth map! \uD83D\uDE02 https:\/\/t.co\/7SxEryNyz7",
  "id" : 788307344996306944,
  "in_reply_to_status_id" : 788306826379001856,
  "created_at" : "2016-10-18 09:14:51 +0000",
  "in_reply_to_screen_name" : "Unsichtbarer",
  "in_reply_to_user_id_str" : "53639020",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788306559294173184",
  "text" : "Will I ever not accidentally name them \u201EChloropleth Maps\u201C?",
  "id" : 788306559294173184,
  "created_at" : "2016-10-18 09:11:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/788145608053907456\/photo\/1",
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/bzq7UKHXam",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CvAONlTXgAUYUnf.jpg",
      "id_str" : "788145561304268805",
      "id" : 788145561304268805,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CvAONlTXgAUYUnf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/bzq7UKHXam"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788136050937978880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06093968223489, 8.818683758469547 ]
  },
  "id_str" : "788145608053907456",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 https:\/\/t.co\/bzq7UKHXam",
  "id" : 788145608053907456,
  "in_reply_to_status_id" : 788136050937978880,
  "created_at" : "2016-10-17 22:32:10 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/788119370342031361\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/zAjo6JW9v7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu_2Yl9XgAELRve.jpg",
      "id_str" : "788119362179923969",
      "id" : 788119362179923969,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu_2Yl9XgAELRve.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/zAjo6JW9v7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091302659205, 8.818600024915556 ]
  },
  "id_str" : "788119370342031361",
  "text" : "Learning the important deal breakers. \uD83C\uDF6B https:\/\/t.co\/zAjo6JW9v7",
  "id" : 788119370342031361,
  "created_at" : "2016-10-17 20:47:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 0, 8 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Dennis Eckmeier, not that kind of Dr.",
      "screen_name" : "DennisEckmeier",
      "indices" : [ 9, 24 ],
      "id_str" : "595982444",
      "id" : 595982444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788115976734650368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06081072553693, 8.818503797677431 ]
  },
  "id_str" : "788116540679983104",
  "in_reply_to_user_id" : 19843630,
  "text" : "@mbeisen @DennisEckmeier how about temporary tattoos? \uD83D\uDE02",
  "id" : 788116540679983104,
  "in_reply_to_status_id" : 788115976734650368,
  "created_at" : "2016-10-17 20:36:40 +0000",
  "in_reply_to_screen_name" : "mbeisen",
  "in_reply_to_user_id_str" : "19843630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/Ls2smtUikW",
      "expanded_url" : "https:\/\/twitter.com\/DennisEckmeier\/status\/788098939782369280",
      "display_url" : "twitter.com\/DennisEckmeier\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06087399093323, 8.818776482344633 ]
  },
  "id_str" : "788115336742797312",
  "text" : "\u00ABWhat\u2019s that? Did someone form the Waffen-open acceSS while I didn\u2019t read Twitter?\u00BB https:\/\/t.co\/Ls2smtUikW",
  "id" : 788115336742797312,
  "created_at" : "2016-10-17 20:31:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 0, 8 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788105469709590528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085776969545, 8.818719842930625 ]
  },
  "id_str" : "788107840393207808",
  "in_reply_to_user_id" : 19843630,
  "text" : "@mbeisen but I\u2019m still totally in for it!",
  "id" : 788107840393207808,
  "in_reply_to_status_id" : 788105469709590528,
  "created_at" : "2016-10-17 20:02:06 +0000",
  "in_reply_to_screen_name" : "mbeisen",
  "in_reply_to_user_id_str" : "19843630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 0, 8 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Dennis Eckmeier, not that kind of Dr.",
      "screen_name" : "DennisEckmeier",
      "indices" : [ 45, 60 ],
      "id_str" : "595982444",
      "id" : 595982444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788100789340246016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084547150444, 8.818715832098482 ]
  },
  "id_str" : "788101119201378304",
  "in_reply_to_user_id" : 19843630,
  "text" : "@mbeisen this one I like even better. But as @DennisEckmeier pointed out: the color combo might need some rethinking.",
  "id" : 788101119201378304,
  "in_reply_to_status_id" : 788100789340246016,
  "created_at" : "2016-10-17 19:35:23 +0000",
  "in_reply_to_screen_name" : "mbeisen",
  "in_reply_to_user_id_str" : "19843630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 0, 8 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 17, 25 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788098068985982976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06088577987808, 8.818636890324163 ]
  },
  "id_str" : "788099621037993984",
  "in_reply_to_user_id" : 19843630,
  "text" : "@mbeisen is this #opencon preparation?",
  "id" : 788099621037993984,
  "in_reply_to_status_id" : 788098068985982976,
  "created_at" : "2016-10-17 19:29:26 +0000",
  "in_reply_to_screen_name" : "mbeisen",
  "in_reply_to_user_id_str" : "19843630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 0, 8 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788098068985982976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06088577987808, 8.818636890324163 ]
  },
  "id_str" : "788099238781657088",
  "in_reply_to_user_id" : 19843630,
  "text" : "@mbeisen that\u2019s a good one!",
  "id" : 788099238781657088,
  "in_reply_to_status_id" : 788098068985982976,
  "created_at" : "2016-10-17 19:27:55 +0000",
  "in_reply_to_screen_name" : "mbeisen",
  "in_reply_to_user_id_str" : "19843630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 0, 8 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788096842156290048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06073778408073, 8.818689877783466 ]
  },
  "id_str" : "788097111703318528",
  "in_reply_to_user_id" : 19843630,
  "text" : "@mbeisen is this a quiz? Zodiac killer or open access? :p",
  "id" : 788097111703318528,
  "in_reply_to_status_id" : 788096842156290048,
  "created_at" : "2016-10-17 19:19:28 +0000",
  "in_reply_to_screen_name" : "mbeisen",
  "in_reply_to_user_id_str" : "19843630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788084235554975744",
  "text" : "When you ask about diversity at an event\/committee etc. and the answer is \u2018glad you asked\u2019 and not \u2018we don\u2019t care\u2019. That\u2019s still too rare. \uD83D\uDC96",
  "id" : 788084235554975744,
  "created_at" : "2016-10-17 18:28:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788010395051122689",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06100052902314, 8.818603615267177 ]
  },
  "id_str" : "788072845884653578",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice awwww \uD83D\uDE0D",
  "id" : 788072845884653578,
  "in_reply_to_status_id" : 788010395051122689,
  "created_at" : "2016-10-17 17:43:02 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    }, {
      "name" : "gltzrsckchn",
      "screen_name" : "gltzrsckchn",
      "indices" : [ 7, 19 ],
      "id_str" : "864161722638192648",
      "id" : 864161722638192648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788065855544365056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06112716880085, 8.818622012263976 ]
  },
  "id_str" : "788066398836781056",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna @gltzrsckchn zumindest unter MacOS gibt es 3 verschiedene \u05E2\u05D1\u05E8\u05D9\u05EA Layouts. \uD83D\uDE02",
  "id" : 788066398836781056,
  "in_reply_to_status_id" : 788065855544365056,
  "created_at" : "2016-10-17 17:17:25 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    }, {
      "name" : "gltzrsckchn",
      "screen_name" : "gltzrsckchn",
      "indices" : [ 7, 19 ],
      "id_str" : "864161722638192648",
      "id" : 864161722638192648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788065284359856128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06097585655448, 8.818844146863672 ]
  },
  "id_str" : "788066188601520128",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna @gltzrsckchn ausserdem Dildo und Seil! (Und mit einem Sofit am Anfang w\u00E4re es auch super Weird)",
  "id" : 788066188601520128,
  "in_reply_to_status_id" : 788065284359856128,
  "created_at" : "2016-10-17 17:16:35 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    }, {
      "name" : "gltzrsckchn",
      "screen_name" : "gltzrsckchn",
      "indices" : [ 7, 19 ],
      "id_str" : "864161722638192648",
      "id" : 864161722638192648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788063406641340417",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06066303231816, 8.818328472864236 ]
  },
  "id_str" : "788064440704966657",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna @gltzrsckchn \u05D9\u05E4\u05D4! Und ich dachte kurz ich m\u00FCsste noch mal \u05E2\u05D1\u05E8\u05D9\u05EA 101 machen :D",
  "id" : 788064440704966657,
  "in_reply_to_status_id" : 788063406641340417,
  "created_at" : "2016-10-17 17:09:38 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    }, {
      "name" : "gltzrsckchn",
      "screen_name" : "gltzrsckchn",
      "indices" : [ 7, 19 ],
      "id_str" : "864161722638192648",
      "id" : 864161722638192648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788058151312588800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.14386970205153, 8.70347800608828 ]
  },
  "id_str" : "788059062462218240",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna @gltzrsckchn \u05E5\u05D1\u05E8? \u05DC\u05D0 \u05F4\u05E2\u05D1\u05E8\u05F4?",
  "id" : 788059062462218240,
  "in_reply_to_status_id" : 788058151312588800,
  "created_at" : "2016-10-17 16:48:16 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    }, {
      "name" : "gltzrsckchn",
      "screen_name" : "gltzrsckchn",
      "indices" : [ 7, 19 ],
      "id_str" : "864161722638192648",
      "id" : 864161722638192648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788055940100653056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17208404633899, 8.637857467334616 ]
  },
  "id_str" : "788056673701269504",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna @gltzrsckchn sollns halt ein DE machen. Hat Windows doch auch zumindest fr\u00FCher so gmacht.",
  "id" : 788056673701269504,
  "in_reply_to_status_id" : 788055940100653056,
  "created_at" : "2016-10-17 16:38:47 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gltzrsckchn",
      "screen_name" : "gltzrsckchn",
      "indices" : [ 0, 12 ],
      "id_str" : "864161722638192648",
      "id" : 864161722638192648
    }, {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 13, 19 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17098960471355, 8.635983634748158 ]
  },
  "id_str" : "788055979871068160",
  "text" : "@gltzrsckchn @Ravna find ich verst\u00E4ndlich \uD83D\uDE22",
  "id" : 788055979871068160,
  "created_at" : "2016-10-17 16:36:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    }, {
      "name" : "gltzrsckchn",
      "screen_name" : "gltzrsckchn",
      "indices" : [ 7, 19 ],
      "id_str" : "864161722638192648",
      "id" : 864161722638192648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788053786736599044",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17199431969638, 8.627876483794497 ]
  },
  "id_str" : "788054313348268032",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna @gltzrsckchn und ich w\u00FCrde so gerne die h\u00E4ssliche schland-flagge entfernt bekommen.",
  "id" : 788054313348268032,
  "in_reply_to_status_id" : 788053786736599044,
  "created_at" : "2016-10-17 16:29:24 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gltzrsckchn",
      "screen_name" : "gltzrsckchn",
      "indices" : [ 0, 12 ],
      "id_str" : "864161722638192648",
      "id" : 864161722638192648
    }, {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 13, 19 ],
      "id_str" : "292968981",
      "id" : 292968981
    }, {
      "name" : "Apple",
      "screen_name" : "Apple",
      "indices" : [ 20, 26 ],
      "id_str" : "380749300",
      "id" : 380749300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788052405761998848",
  "text" : "@gltzrsckchn @Ravna @Apple sieht in yosemite genauso aus, gerade nachgeschaut.",
  "id" : 788052405761998848,
  "created_at" : "2016-10-17 16:21:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gltzrsckchn",
      "screen_name" : "gltzrsckchn",
      "indices" : [ 0, 12 ],
      "id_str" : "864161722638192648",
      "id" : 864161722638192648
    }, {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 13, 19 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788051649990361088",
  "text" : "@gltzrsckchn @Ravna yep, ich hab auch nicht mehr rausfinden k\u00F6nnen.",
  "id" : 788051649990361088,
  "created_at" : "2016-10-17 16:18:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788028965998981124",
  "geo" : { },
  "id_str" : "788029897717473280",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy yes, I \uD83D\uDC96 them \u263A\uFE0F",
  "id" : 788029897717473280,
  "in_reply_to_status_id" : 788028965998981124,
  "created_at" : "2016-10-17 14:52:23 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788028512837967872",
  "text" : "Students see me preparing figures for my manuscript: \u00ABHow much do you lichen this picture?\u00BB \uD83C\uDF44\uD83C\uDF31\uD83D\uDE02",
  "id" : 788028512837967872,
  "created_at" : "2016-10-17 14:46:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janina Wildfeuer",
      "screen_name" : "neous",
      "indices" : [ 0, 6 ],
      "id_str" : "14947380",
      "id" : 14947380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787986045740679168",
  "geo" : { },
  "id_str" : "787986328063541248",
  "in_reply_to_user_id" : 14947380,
  "text" : "@neous two things:\n1. haha, how life-science focussed I was\n2. Awesome, science on graphic novels!",
  "id" : 787986328063541248,
  "in_reply_to_status_id" : 787986045740679168,
  "created_at" : "2016-10-17 11:59:15 +0000",
  "in_reply_to_screen_name" : "neous",
  "in_reply_to_user_id_str" : "14947380",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badomics",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/W56tld22K5",
      "expanded_url" : "https:\/\/twitter.com\/neous\/status\/787972026774523904",
      "display_url" : "twitter.com\/neous\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787985029406351360",
  "text" : "My first thought was \u00ABOh no, not another weird *omics-conference.\u00BB \uD83D\uDE02 #badomics https:\/\/t.co\/W56tld22K5",
  "id" : 787985029406351360,
  "created_at" : "2016-10-17 11:54:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/1qgzVWHwXB",
      "expanded_url" : "http:\/\/thememorypalace.us\/2016\/10\/in-line\/",
      "display_url" : "thememorypalace.us\/2016\/10\/in-lin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787947917894094849",
  "text" : "In Line \uD83D\uDE22 https:\/\/t.co\/1qgzVWHwXB",
  "id" : 787947917894094849,
  "created_at" : "2016-10-17 09:26:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 8, 18 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787753460301172736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925201652213, 8.58759189665087 ]
  },
  "id_str" : "787776888752246785",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @Julie_B92 way to become an illegal immigrant by accident. \uD83D\uDE02",
  "id" : 787776888752246785,
  "in_reply_to_status_id" : 787753460301172736,
  "created_at" : "2016-10-16 22:07:01 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787687042050297856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925529219978, 8.587601075829054 ]
  },
  "id_str" : "787749408507064320",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 after all these years of having FRA as my home port I\u2019m still getting lost there from time to time.",
  "id" : 787749408507064320,
  "in_reply_to_status_id" : 787687042050297856,
  "created_at" : "2016-10-16 20:17:49 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35927454490126, 8.587610589078398 ]
  },
  "id_str" : "787743505351401473",
  "text" : "Took me halfway through to figure out why the movie she claimed to be Australian was only playing in Vienna.",
  "id" : 787743505351401473,
  "created_at" : "2016-10-16 19:54:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35924677910519, 8.587652806993802 ]
  },
  "id_str" : "787636419879702528",
  "text" : "\u00ABI didn\u2019t want to forward the email I got from Elsevier regarding reproducible science while you were driving. You\u2019d have crashed the car.\u00BB",
  "id" : 787636419879702528,
  "created_at" : "2016-10-16 12:48:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787386109571588104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35924677910519, 8.587652806993802 ]
  },
  "id_str" : "787636043096948736",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr still sounds like a somewhat reasonable idea to me. \uD83D\uDE02",
  "id" : 787636043096948736,
  "in_reply_to_status_id" : 787386109571588104,
  "created_at" : "2016-10-16 12:47:20 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787385448008146944",
  "geo" : { },
  "id_str" : "787392758042488832",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr cool, thanks for the input! :-)",
  "id" : 787392758042488832,
  "in_reply_to_status_id" : 787385448008146944,
  "created_at" : "2016-10-15 20:40:37 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787375077633458176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35934307965992, 8.587656221329295 ]
  },
  "id_str" : "787375802488856576",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog I don\u2019t think so!",
  "id" : 787375802488856576,
  "in_reply_to_status_id" : 787375077633458176,
  "created_at" : "2016-10-15 19:33:14 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Authorea",
      "screen_name" : "authorea",
      "indices" : [ 15, 24 ],
      "id_str" : "483986116",
      "id" : 483986116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787371926415106048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35931139320629, 8.587723974489014 ]
  },
  "id_str" : "787372734217068549",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @authorea wanna vote for each other? :D",
  "id" : 787372734217068549,
  "in_reply_to_status_id" : 787371926415106048,
  "created_at" : "2016-10-15 19:21:03 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787360188785389569",
  "geo" : { },
  "id_str" : "787372404507041793",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr are there many studies on children twin-pairs?",
  "id" : 787372404507041793,
  "in_reply_to_status_id" : 787360188785389569,
  "created_at" : "2016-10-15 19:19:44 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787360188785389569",
  "geo" : { },
  "id_str" : "787363405409751040",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr that explains a lot. Let me sleep on the idea for a night to see whether it\u2019s yet another weird idea that\u2019s worth following up!\uD83D\uDE02",
  "id" : 787363405409751040,
  "in_reply_to_status_id" : 787360188785389569,
  "created_at" : "2016-10-15 18:43:59 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787359499212484608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35932428096807, 8.587705601196147 ]
  },
  "id_str" : "787359740338774016",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr that\u2019s good to know. And how come you\u2019re so knowledgeable about it? \uD83D\uDE0A",
  "id" : 787359740338774016,
  "in_reply_to_status_id" : 787359499212484608,
  "created_at" : "2016-10-15 18:29:25 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787358491589705728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925057141579, 8.587589946278321 ]
  },
  "id_str" : "787358619889197057",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr time to build open-twins then ;)",
  "id" : 787358619889197057,
  "in_reply_to_status_id" : 787358491589705728,
  "created_at" : "2016-10-15 18:24:58 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787356707756343296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35921691934886, 8.58764596708618 ]
  },
  "id_str" : "787357225828356096",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr yeah, but I was more wondering: is there a way to - for free - contact a known list of twins willing to participate in research :)",
  "id" : 787357225828356096,
  "in_reply_to_status_id" : 787356707756343296,
  "created_at" : "2016-10-15 18:19:25 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787355205033689090",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35932114406973, 8.587684859739129 ]
  },
  "id_str" : "787355778441158656",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr that\u2019s a good idea :)",
  "id" : 787355778441158656,
  "in_reply_to_status_id" : 787355205033689090,
  "created_at" : "2016-10-15 18:13:40 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787354582326341633",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35916881762653, 8.587642692445268 ]
  },
  "id_str" : "787354765944623105",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr (wondering whether there\u2019s any need for such kind of resource)",
  "id" : 787354765944623105,
  "in_reply_to_status_id" : 787354582326341633,
  "created_at" : "2016-10-15 18:09:39 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787354582326341633",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35916881762653, 8.587642692445268 ]
  },
  "id_str" : "787354706641387521",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr old enough to use the Web and be able to consent to surveys. And ideally both. :)",
  "id" : 787354706641387521,
  "in_reply_to_status_id" : 787354582326341633,
  "created_at" : "2016-10-15 18:09:25 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787353593846390784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35929880854498, 8.587653250917844 ]
  },
  "id_str" : "787353803511267328",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr depends on the kind of genetic data. But I\u2019d not even want genetic data for now. Rather a list of twins you can contact easily.",
  "id" : 787353803511267328,
  "in_reply_to_status_id" : 787353593846390784,
  "created_at" : "2016-10-15 18:05:49 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787351610053783556",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925699042805, 8.58766312495031 ]
  },
  "id_str" : "787351932683841537",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr thanks, but you\u2019re right, not exactly what I\u2019m looking for. More: is there an openSNP for twins? ;)",
  "id" : 787351932683841537,
  "in_reply_to_status_id" : 787351610053783556,
  "created_at" : "2016-10-15 17:58:23 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35915846004561, 8.58774984019333 ]
  },
  "id_str" : "787331062057885696",
  "text" : "Wondering: is there any open data twin registry out there?",
  "id" : 787331062057885696,
  "created_at" : "2016-10-15 16:35:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/ZfsrE4vkj2",
      "expanded_url" : "https:\/\/twitter.com\/rpucheq\/status\/786759546018664448",
      "display_url" : "twitter.com\/rpucheq\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786856724888158208",
  "text" : "Most worrisome mention there must be Matlab. https:\/\/t.co\/ZfsrE4vkj2",
  "id" : 786856724888158208,
  "created_at" : "2016-10-14 09:10:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786834109523955712",
  "geo" : { },
  "id_str" : "786845383263653889",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon gesprochen wie ein Zen-Meister.",
  "id" : 786845383263653889,
  "in_reply_to_status_id" : 786834109523955712,
  "created_at" : "2016-10-14 08:25:32 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Molly Hensley-Clancy",
      "screen_name" : "mollyhc",
      "indices" : [ 3, 11 ],
      "id_str" : "308658903",
      "id" : 308658903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/kJyL4U5gSC",
      "expanded_url" : "https:\/\/twitter.com\/billhumphreyma\/status\/786621658203238400",
      "display_url" : "twitter.com\/billhumphreyma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786706362743058433",
  "text" : "RT @mollyhc: And have been on strike for 9 days. They're asking for a $35,000 salary. https:\/\/t.co\/kJyL4U5gSC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/kJyL4U5gSC",
        "expanded_url" : "https:\/\/twitter.com\/billhumphreyma\/status\/786621658203238400",
        "display_url" : "twitter.com\/billhumphreyma\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "786671063874867200",
    "text" : "And have been on strike for 9 days. They're asking for a $35,000 salary. https:\/\/t.co\/kJyL4U5gSC",
    "id" : 786671063874867200,
    "created_at" : "2016-10-13 20:52:51 +0000",
    "user" : {
      "name" : "Molly Hensley-Clancy",
      "screen_name" : "mollyhc",
      "protected" : false,
      "id_str" : "308658903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736039637257445376\/ww2hluD3_normal.jpg",
      "id" : 308658903,
      "verified" : true
    }
  },
  "id" : 786706362743058433,
  "created_at" : "2016-10-13 23:13:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786670818877210626",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06089732066896, 8.818644031742883 ]
  },
  "id_str" : "786671463763968000",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps yes, even if I ironically only find this at 10pm when calling it a day\u2026",
  "id" : 786671463763968000,
  "in_reply_to_status_id" : 786670818877210626,
  "created_at" : "2016-10-13 20:54:27 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/8Tjr6onqUF",
      "expanded_url" : "https:\/\/twitter.com\/internetofshit\/status\/786527614131441664",
      "display_url" : "twitter.com\/internetofshit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786668633531572224",
  "text" : "They\u2019re really serious about \u201Eeveryone needs to learn how to code\u201C these days\u2026 https:\/\/t.co\/8Tjr6onqUF",
  "id" : 786668633531572224,
  "created_at" : "2016-10-13 20:43:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/sycbz7bos0",
      "expanded_url" : "https:\/\/twitter.com\/herrurbach\/status\/786608581395226624",
      "display_url" : "twitter.com\/herrurbach\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786654828470628352",
  "text" : "\u00ABCorrelations between workaholism and all psychiatric disorder symptoms were positive and significant.\u00BB https:\/\/t.co\/sycbz7bos0",
  "id" : 786654828470628352,
  "created_at" : "2016-10-13 19:48:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/2aiI2DtiWp",
      "expanded_url" : "https:\/\/twitter.com\/tpoi\/status\/786589231216984064",
      "display_url" : "twitter.com\/tpoi\/status\/78\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786652552930746369",
  "text" : "I wish the lab I\u2019m working in would do this already! https:\/\/t.co\/2aiI2DtiWp",
  "id" : 786652552930746369,
  "created_at" : "2016-10-13 19:39:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey Comeau",
      "screen_name" : "joeycomeau",
      "indices" : [ 0, 11 ],
      "id_str" : "8858632",
      "id" : 8858632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786578526610657281",
  "geo" : { },
  "id_str" : "786650076764577792",
  "in_reply_to_user_id" : 8858632,
  "text" : "@joeycomeau next: crowdsourcing the +nobelprize clicks for you. how about peace instead?",
  "id" : 786650076764577792,
  "in_reply_to_status_id" : 786578526610657281,
  "created_at" : "2016-10-13 19:29:28 +0000",
  "in_reply_to_screen_name" : "joeycomeau",
  "in_reply_to_user_id_str" : "8858632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 78, 86 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/mXTIVEUJpF",
      "expanded_url" : "https:\/\/vimeo.com\/185305868",
      "display_url" : "vimeo.com\/185305868"
    } ]
  },
  "geo" : { },
  "id_str" : "786580497602404352",
  "text" : "Grybas &amp; Dumblis. I should always talk about my lichens like this! Thanks @Seplute! \uD83D\uDE0D\uD83D\uDE02 https:\/\/t.co\/mXTIVEUJpF",
  "id" : 786580497602404352,
  "created_at" : "2016-10-13 14:52:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786553171896258560",
  "geo" : { },
  "id_str" : "786553273847349248",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Did @PhilippBayer wear his banana costume?",
  "id" : 786553273847349248,
  "in_reply_to_status_id" : 786553171896258560,
  "created_at" : "2016-10-13 13:04:48 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/Izqy6lRTuU",
      "expanded_url" : "https:\/\/twitter.com\/matthewherper\/status\/786524968657965056",
      "display_url" : "twitter.com\/matthewherper\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786527021702742016",
  "text" : "As if Dylan-fans weren\u2019t fighting enough already about this. \uD83D\uDE02 https:\/\/t.co\/Izqy6lRTuU",
  "id" : 786527021702742016,
  "created_at" : "2016-10-13 11:20:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786450983169564672",
  "geo" : { },
  "id_str" : "786503159707414528",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer publishable in a piecemeal approach? :D",
  "id" : 786503159707414528,
  "in_reply_to_status_id" : 786450983169564672,
  "created_at" : "2016-10-13 09:45:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/n2zFjBout1",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/future_tense\/2016\/10\/12\/rejoice_the_iphone_just_became_a_little_more_accessible_to_the_left_handed.html",
      "display_url" : "slate.com\/blogs\/future_t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786481519279779841",
  "text" : "Being a southpaw I fully agree. Actually trained myself to use the my phone right-handed for UI reasons\u2026 https:\/\/t.co\/n2zFjBout1",
  "id" : 786481519279779841,
  "created_at" : "2016-10-13 08:19:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786470454957662208",
  "text" : "\u00ABIt\u2019s no long-distance relationship if you don\u2019t need to fly!\u00BB \n\n*googles schedule of the Trans-Siberian Railway &amp; postdocs in Ulan-Baatar*",
  "id" : 786470454957662208,
  "created_at" : "2016-10-13 07:35:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Seiver",
      "screen_name" : "tweetotaler",
      "indices" : [ 0, 12 ],
      "id_str" : "29891068",
      "id" : 29891068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786352284770770944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06081618811844, 8.818609221787709 ]
  },
  "id_str" : "786440574098432001",
  "in_reply_to_user_id" : 29891068,
  "text" : "@tweetotaler I saw that. But then after flying half the globe for some burgers that\u2019s okay \uD83D\uDE02",
  "id" : 786440574098432001,
  "in_reply_to_status_id" : 786352284770770944,
  "created_at" : "2016-10-13 05:36:58 +0000",
  "in_reply_to_screen_name" : "tweetotaler",
  "in_reply_to_user_id_str" : "29891068",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786364386495438848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06081618811844, 8.818609221787709 ]
  },
  "id_str" : "786440429562724352",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB coffee M&amp;Ms, pls? \uD83D\uDE0D",
  "id" : 786440429562724352,
  "in_reply_to_status_id" : 786364386495438848,
  "created_at" : "2016-10-13 05:36:24 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786312709943988228",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06087745109723, 8.81879791555877 ]
  },
  "id_str" : "786315773945995265",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks any time!\uD83C\uDF78",
  "id" : 786315773945995265,
  "in_reply_to_status_id" : 786312709943988228,
  "created_at" : "2016-10-12 21:21:04 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "molly clare wilson",
      "screen_name" : "mollyclare",
      "indices" : [ 0, 11 ],
      "id_str" : "12138192",
      "id" : 12138192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786314495777992704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06087745109723, 8.81879791555877 ]
  },
  "id_str" : "786315414913572864",
  "in_reply_to_user_id" : 12138192,
  "text" : "@mollyclare if it was \u201Clist of sexy Swiss poets\u201D it might even be a real Wikipedia entry. \uD83D\uDE02",
  "id" : 786315414913572864,
  "in_reply_to_status_id" : 786314495777992704,
  "created_at" : "2016-10-12 21:19:38 +0000",
  "in_reply_to_screen_name" : "mollyclare",
  "in_reply_to_user_id_str" : "12138192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/qYKLeWmmiT",
      "expanded_url" : "http:\/\/www.vox.com\/culture\/2016\/10\/11\/13186490\/when-in-french-lauren-collins-review",
      "display_url" : "vox.com\/culture\/2016\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786312862541180929",
  "text" : "\u00ABThey love each other, but because of their language barrier, they can\u2019t say each other\u2019s names\u00BB btdt \uD83D\uDE02 https:\/\/t.co\/qYKLeWmmiT",
  "id" : 786312862541180929,
  "created_at" : "2016-10-12 21:09:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 0, 13 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786308518257172481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06089644976897, 8.818529248245822 ]
  },
  "id_str" : "786310321329897473",
  "in_reply_to_user_id" : 760870811494297600,
  "text" : "@blueyedgenes we don\u2019t really do it in terms of delivering the results. But obviously the data would allow for that.",
  "id" : 786310321329897473,
  "in_reply_to_status_id" : 786308518257172481,
  "created_at" : "2016-10-12 20:59:24 +0000",
  "in_reply_to_screen_name" : "blueyedgenes",
  "in_reply_to_user_id_str" : "760870811494297600",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Seiver",
      "screen_name" : "tweetotaler",
      "indices" : [ 0, 12 ],
      "id_str" : "29891068",
      "id" : 29891068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786298794132385792",
  "geo" : { },
  "id_str" : "786300963233619974",
  "in_reply_to_user_id" : 29891068,
  "text" : "@tweetotaler will be in SF mid\/end November-ish. Wanna go for meat-free burgers then? \uD83D\uDE0D",
  "id" : 786300963233619974,
  "in_reply_to_status_id" : 786298794132385792,
  "created_at" : "2016-10-12 20:22:13 +0000",
  "in_reply_to_screen_name" : "tweetotaler",
  "in_reply_to_user_id_str" : "29891068",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stuart Ritchie",
      "screen_name" : "StuartJRitchie",
      "indices" : [ 0, 15 ],
      "id_str" : "180858875",
      "id" : 180858875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786299188447318016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06081100566552, 8.818539683017637 ]
  },
  "id_str" : "786300296100274176",
  "in_reply_to_user_id" : 180858875,
  "text" : "@StuartJRitchie maybe it wantes to say Jamie Oliver instead?",
  "id" : 786300296100274176,
  "in_reply_to_status_id" : 786299188447318016,
  "created_at" : "2016-10-12 20:19:34 +0000",
  "in_reply_to_screen_name" : "StuartJRitchie",
  "in_reply_to_user_id_str" : "180858875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/34qmHhySZt",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/785904798977691648",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "786268121363517440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06083894491442, 8.818647659966729 ]
  },
  "id_str" : "786289379778170880",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks https:\/\/t.co\/34qmHhySZt careful what you wish for.",
  "id" : 786289379778170880,
  "in_reply_to_status_id" : 786268121363517440,
  "created_at" : "2016-10-12 19:36:11 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isis agora lovecruft",
      "screen_name" : "isislovecruft",
      "indices" : [ 3, 17 ],
      "id_str" : "232680302",
      "id" : 232680302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786288205960282112",
  "text" : "RT @isislovecruft: Let's be clear: Jacob is a sociopathic narcisist, and his advisors are tenured academics actively covering up for other\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "785972070731517952",
    "geo" : { },
    "id_str" : "785972471912509440",
    "in_reply_to_user_id" : 232680302,
    "text" : "Let's be clear: Jacob is a sociopathic narcisist, and his advisors are tenured academics actively covering up for other reports of abuse.",
    "id" : 785972471912509440,
    "in_reply_to_status_id" : 785972070731517952,
    "created_at" : "2016-10-11 22:36:54 +0000",
    "in_reply_to_screen_name" : "isislovecruft",
    "in_reply_to_user_id_str" : "232680302",
    "user" : {
      "name" : "isis agora lovecruft",
      "screen_name" : "isislovecruft",
      "protected" : false,
      "id_str" : "232680302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2726879247\/c650a4ac75330afbacee3fc52d56a29b_normal.jpeg",
      "id" : 232680302,
      "verified" : false
    }
  },
  "id" : 786288205960282112,
  "created_at" : "2016-10-12 19:31:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/ootFRXY5JR",
      "expanded_url" : "https:\/\/twitter.com\/gberns\/status\/786217211379671040",
      "display_url" : "twitter.com\/gberns\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786282895291871232",
  "text" : "My initial reaction: any \uD83D\uDC36 that'll stay in the fMRI is a good service dog. \uD83D\uDE02 https:\/\/t.co\/ootFRXY5JR",
  "id" : 786282895291871232,
  "created_at" : "2016-10-12 19:10:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786277169379078144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06103399680001, 8.818764444448815 ]
  },
  "id_str" : "786277968398155776",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest that\u2019s a great sign! \uD83D\uDE0D\uD83D\uDC96",
  "id" : 786277968398155776,
  "in_reply_to_status_id" : 786277169379078144,
  "created_at" : "2016-10-12 18:50:50 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786222646564364288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06100843199534, 8.818598650404082 ]
  },
  "id_str" : "786275677880410112",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest \uD83D\uDE0D\uD83D\uDC53",
  "id" : 786275677880410112,
  "in_reply_to_status_id" : 786222646564364288,
  "created_at" : "2016-10-12 18:41:44 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AkabaneKoroudo",
      "screen_name" : "DrAkabane",
      "indices" : [ 0, 10 ],
      "id_str" : "41912831",
      "id" : 41912831
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 11, 17 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786226364240101377",
  "geo" : { },
  "id_str" : "786228668339281920",
  "in_reply_to_user_id" : 41912831,
  "text" : "@DrAkabane @Lobot ach, dein Punkt war die ganze Zeit das die patriarchale Gesellschaft Frauen entgegen ihrer Natur von STEM fernh\u00E4lt? \uD83D\uDE02",
  "id" : 786228668339281920,
  "in_reply_to_status_id" : 786226364240101377,
  "created_at" : "2016-10-12 15:34:56 +0000",
  "in_reply_to_screen_name" : "DrAkabane",
  "in_reply_to_user_id_str" : "41912831",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 58, 69 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/ByEXjoZ9Zm",
      "expanded_url" : "https:\/\/twitter.com\/MachaNikolski\/status\/786202469571231745",
      "display_url" : "twitter.com\/MachaNikolski\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786219206937280512",
  "text" : "RT @PhilippBayer: We see more or less the same pattern in @openSNPorg data https:\/\/t.co\/ByEXjoZ9Zm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 40, 51 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/ByEXjoZ9Zm",
        "expanded_url" : "https:\/\/twitter.com\/MachaNikolski\/status\/786202469571231745",
        "display_url" : "twitter.com\/MachaNikolski\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "786202663880753152",
    "text" : "We see more or less the same pattern in @openSNPorg data https:\/\/t.co\/ByEXjoZ9Zm",
    "id" : 786202663880753152,
    "created_at" : "2016-10-12 13:51:36 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 786219206937280512,
  "created_at" : "2016-10-12 14:57:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AkabaneKoroudo",
      "screen_name" : "DrAkabane",
      "indices" : [ 0, 10 ],
      "id_str" : "41912831",
      "id" : 41912831
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 11, 17 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786217537721675777",
  "geo" : { },
  "id_str" : "786218622154833920",
  "in_reply_to_user_id" : 41912831,
  "text" : "@DrAkabane @Lobot Die Links unterst\u00FCtzen vor allem das Menschen wie du nicht-M\u00E4nner davon abhalten solche Berufe zu ergreifen. \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 786218622154833920,
  "in_reply_to_status_id" : 786217537721675777,
  "created_at" : "2016-10-12 14:55:01 +0000",
  "in_reply_to_screen_name" : "DrAkabane",
  "in_reply_to_user_id_str" : "41912831",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Macha Nikolski",
      "screen_name" : "MachaNikolski",
      "indices" : [ 14, 28 ],
      "id_str" : "398066744",
      "id" : 398066744
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/orcOpABRqS",
      "expanded_url" : "https:\/\/github.com\/openSNP\/presentations\/blob\/master\/2016\/2016-09-22-personalizedhealth.pdf",
      "display_url" : "github.com\/openSNP\/presen\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "786202663880753152",
  "geo" : { },
  "id_str" : "786203035836055552",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @MachaNikolski c.f. slides in https:\/\/t.co\/orcOpABRqS",
  "id" : 786203035836055552,
  "in_reply_to_status_id" : 786202663880753152,
  "created_at" : "2016-10-12 13:53:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 3, 9 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786171894441578496",
  "text" : "RT @ozaed: \"If Holocaust denial were protected by copyright, the problem would likely quickly disappear from the site.\" https:\/\/t.co\/maVD95\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/maVD959h3h",
        "expanded_url" : "https:\/\/twitter.com\/skdh\/status\/786163094548418560",
        "display_url" : "twitter.com\/skdh\/status\/78\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "786163723945652224",
    "text" : "\"If Holocaust denial were protected by copyright, the problem would likely quickly disappear from the site.\" https:\/\/t.co\/maVD959h3h",
    "id" : 786163723945652224,
    "created_at" : "2016-10-12 11:16:52 +0000",
    "user" : {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "protected" : false,
      "id_str" : "15806521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1453053624\/me_normal.jpg",
      "id" : 15806521,
      "verified" : false
    }
  },
  "id" : 786171894441578496,
  "created_at" : "2016-10-12 11:49:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/uniUJsg8iq",
      "expanded_url" : "http:\/\/pythonhosted.org\/ORG.asm\/index.html",
      "display_url" : "pythonhosted.org\/ORG.asm\/index.\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "786122653400698880",
  "geo" : { },
  "id_str" : "786122845587959813",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 one of my favs in terms of how bad it is: https:\/\/t.co\/uniUJsg8iq",
  "id" : 786122845587959813,
  "in_reply_to_status_id" : 786122653400698880,
  "created_at" : "2016-10-12 08:34:26 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Blaxter Lab",
      "screen_name" : "blaxterlab",
      "indices" : [ 8, 19 ],
      "id_str" : "708244146104967168",
      "id" : 708244146104967168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786104928704004096",
  "geo" : { },
  "id_str" : "786120251796783105",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @blaxterlab now I want to do a second PhD after finishing this one! :D",
  "id" : 786120251796783105,
  "in_reply_to_status_id" : 786104928704004096,
  "created_at" : "2016-10-12 08:24:08 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786100654108504064",
  "geo" : { },
  "id_str" : "786120060918259712",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 what\u2019s the offending name of the day?",
  "id" : 786120060918259712,
  "in_reply_to_status_id" : 786100654108504064,
  "created_at" : "2016-10-12 08:23:22 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 11, 25 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 26, 31 ],
      "id_str" : "9377892",
      "id" : 9377892
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/786117709641777152\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/ukUMBszS44",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CujZ4x1W8AAieew.jpg",
      "id_str" : "786117704449191936",
      "id" : 786117704449191936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CujZ4x1W8AAieew.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      } ],
      "display_url" : "pic.twitter.com\/ukUMBszS44"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786070310923673600",
  "geo" : { },
  "id_str" : "786117709641777152",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @NazeefaFatima @tpoi not sure what to make of some of the passive-aggressive Hebrew lessons. https:\/\/t.co\/ukUMBszS44",
  "id" : 786117709641777152,
  "in_reply_to_status_id" : 786070310923673600,
  "created_at" : "2016-10-12 08:14:01 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786000993368444928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082911305865, 8.818615592893266 ]
  },
  "id_str" : "786095806088671233",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds yes, but Harvard PGP is 3000+ participants iirc. :)",
  "id" : 786095806088671233,
  "in_reply_to_status_id" : 786000993368444928,
  "created_at" : "2016-10-12 06:46:59 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785945353358942209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06080813314139, 8.818600180081463 ]
  },
  "id_str" : "785947005453467648",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime (And just want to make clear that it by no means was meant as an attack on the paper, just seriously curious about it)",
  "id" : 785947005453467648,
  "in_reply_to_status_id" : 785945353358942209,
  "created_at" : "2016-10-11 20:55:42 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785945353358942209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06080813314139, 8.818600180081463 ]
  },
  "id_str" : "785946743154282496",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime guess it\u2019s also a bit different in our case as people bring their own data.",
  "id" : 785946743154282496,
  "in_reply_to_status_id" : 785945353358942209,
  "created_at" : "2016-10-11 20:54:40 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785942635592687616",
  "text" : "RT @madprime: @gedankenstuecke We definitely talked about it. A lot. It's very much a case of \"easier said than done\" to enrich while tryin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "785940977533919232",
    "geo" : { },
    "id_str" : "785941382288379904",
    "in_reply_to_user_id" : 71557700,
    "text" : "@gedankenstuecke We definitely talked about it. A lot. It's very much a case of \"easier said than done\" to enrich while trying to be ethical",
    "id" : 785941382288379904,
    "in_reply_to_status_id" : 785940977533919232,
    "created_at" : "2016-10-11 20:33:22 +0000",
    "in_reply_to_screen_name" : "madprime",
    "in_reply_to_user_id_str" : "71557700",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 785942635592687616,
  "created_at" : "2016-10-11 20:38:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785942627724193792",
  "text" : "RT @madprime: @gedankenstuecke Selecting\/enriching is hard, onerous on operations. &amp; serious push on people themselves\u2026 has similar issues\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "785938632360296448",
    "geo" : { },
    "id_str" : "785940977533919232",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke Selecting\/enriching is hard, onerous on operations. &amp; serious push on people themselves\u2026 has similar issues to recruitment.",
    "id" : 785940977533919232,
    "in_reply_to_status_id" : 785938632360296448,
    "created_at" : "2016-10-11 20:31:45 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 785942627724193792,
  "created_at" : "2016-10-11 20:38:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785941382288379904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06079551987151, 8.81843603038615 ]
  },
  "id_str" : "785942615481024512",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime thanks for the explanation! \uD83D\uDE4F",
  "id" : 785942615481024512,
  "in_reply_to_status_id" : 785941382288379904,
  "created_at" : "2016-10-11 20:38:16 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785937211430543360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06089499997034, 8.818637872415087 ]
  },
  "id_str" : "785938632360296448",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime \u2026at least enrich from the participants one already has in the cohort when getting great data like this)",
  "id" : 785938632360296448,
  "in_reply_to_status_id" : 785937211430543360,
  "created_at" : "2016-10-11 20:22:26 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785937211430543360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06089499997034, 8.818637872415087 ]
  },
  "id_str" : "785938437648048128",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime sorry, more like 25, should have checked the paper again before guesstimating :) (honest Q though, just wonder whether one could\u2026",
  "id" : 785938437648048128,
  "in_reply_to_status_id" : 785937211430543360,
  "created_at" : "2016-10-11 20:21:40 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785936325316706304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06090737237076, 8.818687145468068 ]
  },
  "id_str" : "785937854648254464",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime but are there only ~10 non-white people donated blood to PGP w\/ consent so far?",
  "id" : 785937854648254464,
  "in_reply_to_status_id" : 785936325316706304,
  "created_at" : "2016-10-11 20:19:21 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785936325316706304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06090737237076, 8.818687145468068 ]
  },
  "id_str" : "785937803729403906",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime totally agree on not coercing people to share data, especially for less empwered groups.",
  "id" : 785937803729403906,
  "in_reply_to_status_id" : 785936325316706304,
  "created_at" : "2016-10-11 20:19:09 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 15, 24 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785935900026949632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091561931814, 8.81858342024712 ]
  },
  "id_str" : "785936138213130240",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson @madprime totally know that both of you care about this!",
  "id" : 785936138213130240,
  "in_reply_to_status_id" : 785935900026949632,
  "created_at" : "2016-10-11 20:12:31 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 15, 24 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/iCODhNg15F",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/785864456811245568",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "785921859208425472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091561931814, 8.81858342024712 ]
  },
  "id_str" : "785935193039306753",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson @madprime i know it's hard (openSNP sucks just as much at it), but was https:\/\/t.co\/iCODhNg15F considered?",
  "id" : 785935193039306753,
  "in_reply_to_status_id" : 785921859208425472,
  "created_at" : "2016-10-11 20:08:46 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/785929262880743425\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/936bfztLaX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuguf3SWIAAPnQE.jpg",
      "id_str" : "785929259927871488",
      "id" : 785929259927871488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuguf3SWIAAPnQE.jpg",
      "sizes" : [ {
        "h" : 209,
        "resize" : "fit",
        "w" : 889
      }, {
        "h" : 209,
        "resize" : "fit",
        "w" : 889
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 209,
        "resize" : "fit",
        "w" : 889
      } ],
      "display_url" : "pic.twitter.com\/936bfztLaX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785929262880743425",
  "text" : "Why did I just find this setting now? \uD83D\uDE0D https:\/\/t.co\/936bfztLaX",
  "id" : 785929262880743425,
  "created_at" : "2016-10-11 19:45:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/KGyEZq52ND",
      "expanded_url" : "https:\/\/twitter.com\/PoemHeaven\/status\/785857556799455234",
      "display_url" : "twitter.com\/PoemHeaven\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086146707865, 8.818615224724745 ]
  },
  "id_str" : "785927572773298176",
  "text" : "Ohai. \uD83D\uDC4B\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08 https:\/\/t.co\/KGyEZq52ND",
  "id" : 785927572773298176,
  "created_at" : "2016-10-11 19:38:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "Eve Gray",
      "screen_name" : "graysouth",
      "indices" : [ 66, 76 ],
      "id_str" : "47668635",
      "id" : 47668635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/HgRV4oM80V",
      "expanded_url" : "http:\/\/www.newyorker.com\/magazine\/2016\/10\/17\/leonard-cohen-makes-it-darker",
      "display_url" : "newyorker.com\/magazine\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785912951890907140",
  "text" : "RT @bella_velo: Leonard Cohen Makes It Darker - The New Yorker cc @graysouth  https:\/\/t.co\/HgRV4oM80V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eve Gray",
        "screen_name" : "graysouth",
        "indices" : [ 50, 60 ],
        "id_str" : "47668635",
        "id" : 47668635
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/HgRV4oM80V",
        "expanded_url" : "http:\/\/www.newyorker.com\/magazine\/2016\/10\/17\/leonard-cohen-makes-it-darker",
        "display_url" : "newyorker.com\/magazine\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "785874442752823297",
    "text" : "Leonard Cohen Makes It Darker - The New Yorker cc @graysouth  https:\/\/t.co\/HgRV4oM80V",
    "id" : 785874442752823297,
    "created_at" : "2016-10-11 16:07:22 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 785912951890907140,
  "created_at" : "2016-10-11 18:40:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785906593779032064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06101987167058, 8.818769364819365 ]
  },
  "id_str" : "785906852924104705",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule doch, ich war nur neugierig :)",
  "id" : 785906852924104705,
  "in_reply_to_status_id" : 785906593779032064,
  "created_at" : "2016-10-11 18:16:09 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/34qmHhySZt",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/785904798977691648",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "785904798977691648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06098940507514, 8.818524219103919 ]
  },
  "id_str" : "785905322418380800",
  "in_reply_to_user_id" : 14286491,
  "text" : "I somehow had hoped it would contain my printed genotype as well. \uD83D\uDE02\uD83D\uDCD2 https:\/\/t.co\/34qmHhySZt",
  "id" : 785905322418380800,
  "in_reply_to_status_id" : 785904798977691648,
  "created_at" : "2016-10-11 18:10:04 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/785904798977691648\/photo\/1",
      "indices" : [ 131, 154 ],
      "url" : "https:\/\/t.co\/UQrcspQXZO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CugYPF6WAAAHhGp.jpg",
      "id_str" : "785904782540144640",
      "id" : 785904782540144640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CugYPF6WAAAHhGp.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/UQrcspQXZO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785904798977691648",
  "text" : "Safe Harbor means: you can request your data and then you\u2019ll get screenshots printed on the US-equivalent of A3 and mailed to you. https:\/\/t.co\/UQrcspQXZO",
  "id" : 785904798977691648,
  "created_at" : "2016-10-11 18:08:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785864456811245568",
  "geo" : { },
  "id_str" : "785865200465510400",
  "in_reply_to_user_id" : 14286491,
  "text" : "Gender breakdown: 67 female, 107 male participants.",
  "id" : 785865200465510400,
  "in_reply_to_status_id" : 785864456811245568,
  "created_at" : "2016-10-11 15:30:39 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/785864456811245568\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/cyTeuXSNiP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CufzUPSWcAULah-.jpg",
      "id_str" : "785864189025873925",
      "id" : 785864189025873925,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CufzUPSWcAULah-.jpg",
      "sizes" : [ {
        "h" : 271,
        "resize" : "fit",
        "w" : 497
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 497
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 497
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 497
      } ],
      "display_url" : "pic.twitter.com\/cyTeuXSNiP"
    } ],
    "hashtags" : [ {
      "text" : "PHDA2016",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/DmeOxvG71E",
      "expanded_url" : "http:\/\/gigascience.biomedcentral.com\/articles\/10.1186\/s13742-016-0148-z",
      "display_url" : "gigascience.biomedcentral.com\/articles\/10.11\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785864456811245568",
  "text" : "Remember when I complained about lack of diversity in genomics data at #PHDA2016? https:\/\/t.co\/DmeOxvG71E https:\/\/t.co\/cyTeuXSNiP",
  "id" : 785864456811245568,
  "created_at" : "2016-10-11 15:27:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AkabaneKoroudo",
      "screen_name" : "DrAkabane",
      "indices" : [ 0, 10 ],
      "id_str" : "41912831",
      "id" : 41912831
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 11, 17 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785857832260362240",
  "geo" : { },
  "id_str" : "785859463949549568",
  "in_reply_to_user_id" : 41912831,
  "text" : "@DrAkabane @Lobot ungef\u00E4hr alle im 2 &amp; 3 Absatz. Lesen musst du allerdings noch selbst.",
  "id" : 785859463949549568,
  "in_reply_to_status_id" : 785857832260362240,
  "created_at" : "2016-10-11 15:07:51 +0000",
  "in_reply_to_screen_name" : "DrAkabane",
  "in_reply_to_user_id_str" : "41912831",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785822763550289920",
  "geo" : { },
  "id_str" : "785851910683299840",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik any chance to offer Nanopore workshops that include flights with the vomit comet? \uD83D\uDE02",
  "id" : 785851910683299840,
  "in_reply_to_status_id" : 785822763550289920,
  "created_at" : "2016-10-11 14:37:50 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 3, 11 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Josh Quick",
      "screen_name" : "Scalene",
      "indices" : [ 25, 33 ],
      "id_str" : "20441966",
      "id" : 20441966
    }, {
      "name" : "Oxford Nanopore",
      "screen_name" : "nanopore",
      "indices" : [ 86, 95 ],
      "id_str" : "37732219",
      "id" : 37732219
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/pjacock\/status\/785822654267789313\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/dSGApyIJba",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CufNe5eWEAAa8y7.jpg",
      "id_str" : "785822590707306496",
      "id" : 785822590707306496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CufNe5eWEAAa8y7.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/dSGApyIJba"
    } ],
    "hashtags" : [ {
      "text" : "NextGenBUG",
      "indices" : [ 13, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785851729023827969",
  "text" : "RT @pjacock: #NextGenBUG @Scalene\u2019s sequencing lab in a suitcase, based on the Oxford @nanopore https:\/\/t.co\/dSGApyIJba",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Quick",
        "screen_name" : "Scalene",
        "indices" : [ 12, 20 ],
        "id_str" : "20441966",
        "id" : 20441966
      }, {
        "name" : "Oxford Nanopore",
        "screen_name" : "nanopore",
        "indices" : [ 73, 82 ],
        "id_str" : "37732219",
        "id" : 37732219
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pjacock\/status\/785822654267789313\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/dSGApyIJba",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CufNe5eWEAAa8y7.jpg",
        "id_str" : "785822590707306496",
        "id" : 785822590707306496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CufNe5eWEAAa8y7.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 3024,
          "resize" : "fit",
          "w" : 4032
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/dSGApyIJba"
      } ],
      "hashtags" : [ {
        "text" : "NextGenBUG",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "785822068222857216",
    "geo" : { },
    "id_str" : "785822654267789313",
    "in_reply_to_user_id" : 58756672,
    "text" : "#NextGenBUG @Scalene\u2019s sequencing lab in a suitcase, based on the Oxford @nanopore https:\/\/t.co\/dSGApyIJba",
    "id" : 785822654267789313,
    "in_reply_to_status_id" : 785822068222857216,
    "created_at" : "2016-10-11 12:41:35 +0000",
    "in_reply_to_screen_name" : "pjacock",
    "in_reply_to_user_id_str" : "58756672",
    "user" : {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "protected" : false,
      "id_str" : "58756672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/324343873\/peter_cliff_normal.jpg",
      "id" : 58756672,
      "verified" : false
    }
  },
  "id" : 785851729023827969,
  "created_at" : "2016-10-11 14:37:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AkabaneKoroudo",
      "screen_name" : "DrAkabane",
      "indices" : [ 0, 10 ],
      "id_str" : "41912831",
      "id" : 41912831
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 11, 17 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/TeYh0cvT8C",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/3orieMtuAwZrUexSBq\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/3orieMtu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "785847652801994754",
  "geo" : { },
  "id_str" : "785851403407331328",
  "in_reply_to_user_id" : 41912831,
  "text" : "@DrAkabane @Lobot ungef\u00E4hr 15 Paper in dem Nature-Link tun genau das. Aber klar\u2026 https:\/\/t.co\/TeYh0cvT8C",
  "id" : 785851403407331328,
  "in_reply_to_status_id" : 785847652801994754,
  "created_at" : "2016-10-11 14:35:49 +0000",
  "in_reply_to_screen_name" : "DrAkabane",
  "in_reply_to_user_id_str" : "41912831",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AkabaneKoroudo",
      "screen_name" : "DrAkabane",
      "indices" : [ 0, 10 ],
      "id_str" : "41912831",
      "id" : 41912831
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 11, 17 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/dCFIHqSIrl",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/l3vRl9o6W90DnnqKs\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/l3vRl9o6\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "785842877788217345",
  "geo" : { },
  "id_str" : "785845386237845504",
  "in_reply_to_user_id" : 41912831,
  "text" : "@DrAkabane @Lobot der Link unterst\u00FCtzt nur keine der Aussagen von dir. https:\/\/t.co\/dCFIHqSIrl",
  "id" : 785845386237845504,
  "in_reply_to_status_id" : 785842877788217345,
  "created_at" : "2016-10-11 14:11:55 +0000",
  "in_reply_to_screen_name" : "DrAkabane",
  "in_reply_to_user_id_str" : "41912831",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AkabaneKoroudo",
      "screen_name" : "DrAkabane",
      "indices" : [ 0, 10 ],
      "id_str" : "41912831",
      "id" : 41912831
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 11, 17 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/3RBxYW78Fp",
      "expanded_url" : "http:\/\/www.picgifs.com\/reaction-gifs\/reaction-gifs\/deal-with-it\/picgifs-deal-with-it-1528635.gif",
      "display_url" : "picgifs.com\/reaction-gifs\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "785842008069906435",
  "geo" : { },
  "id_str" : "785842520282525696",
  "in_reply_to_user_id" : 41912831,
  "text" : "@DrAkabane @Lobot wo sind die relevanten quellen daf\u00FCr? https:\/\/t.co\/3RBxYW78Fp",
  "id" : 785842520282525696,
  "in_reply_to_status_id" : 785842008069906435,
  "created_at" : "2016-10-11 14:00:31 +0000",
  "in_reply_to_screen_name" : "DrAkabane",
  "in_reply_to_user_id_str" : "41912831",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AkabaneKoroudo",
      "screen_name" : "DrAkabane",
      "indices" : [ 0, 10 ],
      "id_str" : "41912831",
      "id" : 41912831
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 11, 17 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/U4iJRM2Ve0",
      "expanded_url" : "http:\/\/lmgtfy.com",
      "display_url" : "lmgtfy.com"
    }, {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/0dWBwBPCgK",
      "expanded_url" : "https:\/\/scholar.google.com\/scholar?hl=en&q=women+stem",
      "display_url" : "scholar.google.com\/scholar?hl=en&\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "785841374923030528",
  "geo" : { },
  "id_str" : "785842070191833088",
  "in_reply_to_user_id" : 41912831,
  "text" : "@DrAkabane @Lobot there you go. Gibt glaube ich noch kein academic https:\/\/t.co\/U4iJRM2Ve0 https:\/\/t.co\/0dWBwBPCgK",
  "id" : 785842070191833088,
  "in_reply_to_status_id" : 785841374923030528,
  "created_at" : "2016-10-11 13:58:44 +0000",
  "in_reply_to_screen_name" : "DrAkabane",
  "in_reply_to_user_id_str" : "41912831",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AkabaneKoroudo",
      "screen_name" : "DrAkabane",
      "indices" : [ 0, 10 ],
      "id_str" : "41912831",
      "id" : 41912831
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 11, 17 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/jMWH7Xd0sv",
      "expanded_url" : "http:\/\/blogs.nature.com\/soapboxscience\/2014\/09\/04\/nature-vs-nurture-girls-and-stem",
      "display_url" : "blogs.nature.com\/soapboxscience\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "785831730267557889",
  "geo" : { },
  "id_str" : "785836846270050305",
  "in_reply_to_user_id" : 41912831,
  "text" : "@DrAkabane @Lobot wer zu faul ist die relevante Literatur zu lesen muss selbst verschuldet uninformiert sterben\uD83C\uDFBB https:\/\/t.co\/jMWH7Xd0sv",
  "id" : 785836846270050305,
  "in_reply_to_status_id" : 785831730267557889,
  "created_at" : "2016-10-11 13:37:58 +0000",
  "in_reply_to_screen_name" : "DrAkabane",
  "in_reply_to_user_id_str" : "41912831",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/yCqz7Tr4h5",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/151657372130\/how-i-feel-every-morning",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/151657372\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "785420799423483904",
  "geo" : { },
  "id_str" : "785829732101292033",
  "in_reply_to_user_id" : 14286491,
  "text" : "the espresso machine is back! https:\/\/t.co\/yCqz7Tr4h5",
  "id" : 785829732101292033,
  "in_reply_to_status_id" : 785420799423483904,
  "created_at" : "2016-10-11 13:09:42 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785780150344364032",
  "geo" : { },
  "id_str" : "785780296851611648",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr they asked about ethnicity, not location though (well, both actually).",
  "id" : 785780296851611648,
  "in_reply_to_status_id" : 785780150344364032,
  "created_at" : "2016-10-11 09:53:16 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/rLG5WPyjLn",
      "expanded_url" : "https:\/\/modelviewculture.com\/pieces\/the-top-10-tech-rules",
      "display_url" : "modelviewculture.com\/pieces\/the-top\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785768793071058944",
  "text" : "The Top 10 (%) Tech Rules https:\/\/t.co\/rLG5WPyjLn",
  "id" : 785768793071058944,
  "created_at" : "2016-10-11 09:07:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785756351431634945",
  "text" : "Why do I need to (even if only optionally) provide my gender &amp; ethnicity to register for some bioinformatics-tool?",
  "id" : 785756351431634945,
  "created_at" : "2016-10-11 08:18:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785733709412663296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06089345270579, 8.818528531930056 ]
  },
  "id_str" : "785733921438851072",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr yes! Please take me with you if you do, same here!",
  "id" : 785733921438851072,
  "in_reply_to_status_id" : 785733709412663296,
  "created_at" : "2016-10-11 06:48:59 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/swnYGPciae",
      "expanded_url" : "https:\/\/twitter.com\/JacquelynGill\/status\/785581791318978560",
      "display_url" : "twitter.com\/JacquelynGill\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06069202822354, 8.818485615170541 ]
  },
  "id_str" : "785594659854745601",
  "text" : "Guess who had to cry a bit while reading this lovely portrait. \uD83D\uDE0D https:\/\/t.co\/swnYGPciae",
  "id" : 785594659854745601,
  "created_at" : "2016-10-10 21:35:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "indices" : [ 3, 17 ],
      "id_str" : "112475924",
      "id" : 112475924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/awWdZADzqf",
      "expanded_url" : "https:\/\/twitter.com\/jonrosenberg\/status\/785568641257472001",
      "display_url" : "twitter.com\/jonrosenberg\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785593356470616064",
  "text" : "RT @JacquelynGill: The Dispossessed is one of my favorites! https:\/\/t.co\/awWdZADzqf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/awWdZADzqf",
        "expanded_url" : "https:\/\/twitter.com\/jonrosenberg\/status\/785568641257472001",
        "display_url" : "twitter.com\/jonrosenberg\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "785581791318978560",
    "text" : "The Dispossessed is one of my favorites! https:\/\/t.co\/awWdZADzqf",
    "id" : 785581791318978560,
    "created_at" : "2016-10-10 20:44:29 +0000",
    "user" : {
      "name" : "Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "protected" : false,
      "id_str" : "112475924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816027573343965184\/qUfIq3xY_normal.jpg",
      "id" : 112475924,
      "verified" : true
    }
  },
  "id" : 785593356470616064,
  "created_at" : "2016-10-10 21:30:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785581255328956417",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06087510378442, 8.818623859663184 ]
  },
  "id_str" : "785581415652069377",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze which already tells you a lot \uD83D\uDE02",
  "id" : 785581415652069377,
  "in_reply_to_status_id" : 785581255328956417,
  "created_at" : "2016-10-10 20:42:59 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785577494158139393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06080101975895, 8.81871238293128 ]
  },
  "id_str" : "785579320010047488",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente \uD83D\uDE0D",
  "id" : 785579320010047488,
  "in_reply_to_status_id" : 785577494158139393,
  "created_at" : "2016-10-10 20:34:39 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785575118663811073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06090621468616, 8.818557914354669 ]
  },
  "id_str" : "785575235458326528",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog aber dann kann ich nicht mitspielen! \uD83D\uDE02",
  "id" : 785575235458326528,
  "in_reply_to_status_id" : 785575118663811073,
  "created_at" : "2016-10-10 20:18:26 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/sBn3nCW5HS",
      "expanded_url" : "https:\/\/twitter.com\/arstechnica\/status\/785568422029656065",
      "display_url" : "twitter.com\/arstechnica\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06073655701932, 8.818571788460059 ]
  },
  "id_str" : "785574779080286209",
  "text" : "Human biology still a hard problem, color me surprised. https:\/\/t.co\/sBn3nCW5HS",
  "id" : 785574779080286209,
  "created_at" : "2016-10-10 20:16:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785572094537043968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082967353231, 8.818586093265454 ]
  },
  "id_str" : "785572320396140544",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog W\u00E4re doch was nettes f\u00FCrs blog: Tippspiel was das N wohl war :D",
  "id" : 785572320396140544,
  "in_reply_to_status_id" : 785572094537043968,
  "created_at" : "2016-10-10 20:06:51 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785563091761295360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085597648887, 8.818527471829706 ]
  },
  "id_str" : "785571349976719360",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog hast du die Autoren\/das Journal angeschrieben? (War versucht es selbst zu tun)",
  "id" : 785571349976719360,
  "in_reply_to_status_id" : 785563091761295360,
  "created_at" : "2016-10-10 20:02:59 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/Ck2iga3bZA",
      "expanded_url" : "https:\/\/twitter.com\/MishaAngrist\/status\/785468884077903872",
      "display_url" : "twitter.com\/MishaAngrist\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785570006406950912",
  "text" : "RT @EffyVayena: On bio- and other rights. https:\/\/t.co\/Ck2iga3bZA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/Ck2iga3bZA",
        "expanded_url" : "https:\/\/twitter.com\/MishaAngrist\/status\/785468884077903872",
        "display_url" : "twitter.com\/MishaAngrist\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "785515068100337664",
    "text" : "On bio- and other rights. https:\/\/t.co\/Ck2iga3bZA",
    "id" : 785515068100337664,
    "created_at" : "2016-10-10 16:19:21 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 785570006406950912,
  "created_at" : "2016-10-10 19:57:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/kPPoyXPCno",
      "expanded_url" : "https:\/\/twitter.com\/erlichya\/status\/785511875052175360",
      "display_url" : "twitter.com\/erlichya\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085527264069, 8.818588206071853 ]
  },
  "id_str" : "785528930291843073",
  "text" : "Still waiting for the gene associated with making bogus genetic claims. https:\/\/t.co\/kPPoyXPCno",
  "id" : 785528930291843073,
  "created_at" : "2016-10-10 17:14:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/o3bR687FAn",
      "expanded_url" : "https:\/\/twitter.com\/_katsel\/status\/785446046440751105",
      "display_url" : "twitter.com\/_katsel\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785479620648894464",
  "text" : "Wow, that\u2019s a great list of things to keep in mind when designing any talk (or conference). Especially docs 3 &amp; 4! https:\/\/t.co\/o3bR687FAn",
  "id" : 785479620648894464,
  "created_at" : "2016-10-10 13:58:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/WK3PhXnTPW",
      "expanded_url" : "https:\/\/twitter.com\/romunov\/status\/785469082275573760",
      "display_url" : "twitter.com\/romunov\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785471602762903552",
  "text" : "Probably some UTF-8 confusion, the Kobayashi Maru test that\u2019s even more depressing. https:\/\/t.co\/WK3PhXnTPW",
  "id" : 785471602762903552,
  "created_at" : "2016-10-10 13:26:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/sdA0gBiCFn",
      "expanded_url" : "https:\/\/twitter.com\/BioMickWatson\/status\/785461097079996416",
      "display_url" : "twitter.com\/BioMickWatson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785468815878549504",
  "text" : "Nope Klingons, still can\u2019t hear you, have you tried restarting your browser? https:\/\/t.co\/sdA0gBiCFn",
  "id" : 785468815878549504,
  "created_at" : "2016-10-10 13:15:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785466687298691073",
  "text" : "Things you learn when googling why it\u2019s only the tumbleweed &amp; you in the conference call: Happy Thanksgiving, \uD83C\uDDE8\uD83C\uDDE6!",
  "id" : 785466687298691073,
  "created_at" : "2016-10-10 13:07:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/wnjzH09Cg3",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/785442816390471680",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238286583581, 8.627564962203255 ]
  },
  "id_str" : "785464024427274240",
  "text" : "I already put my answer in! https:\/\/t.co\/wnjzH09Cg3",
  "id" : 785464024427274240,
  "created_at" : "2016-10-10 12:56:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785435115908427776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17245241786026, 8.627522442787493 ]
  },
  "id_str" : "785453170063540224",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 aye, all the best for that.",
  "id" : 785453170063540224,
  "in_reply_to_status_id" : 785435115908427776,
  "created_at" : "2016-10-10 12:13:23 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "btdt",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785430434863845376",
  "geo" : { },
  "id_str" : "785431388967362560",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 the equivalent of computing things for weeks and then accidentally deleting the output w\/o having a backup. #btdt (to both\u2026)",
  "id" : 785431388967362560,
  "in_reply_to_status_id" : 785430434863845376,
  "created_at" : "2016-10-10 10:46:50 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/785420799423483904\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/KZ0RYQuU0R",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CuZgDKCXYAAshMe.jpg",
      "id_str" : "785420792372879360",
      "id" : 785420792372879360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CuZgDKCXYAAshMe.jpg",
      "sizes" : [ {
        "h" : 134,
        "resize" : "crop",
        "w" : 134
      }, {
        "h" : 134,
        "resize" : "fit",
        "w" : 246
      }, {
        "h" : 134,
        "resize" : "fit",
        "w" : 246
      }, {
        "h" : 134,
        "resize" : "fit",
        "w" : 246
      }, {
        "h" : 134,
        "resize" : "fit",
        "w" : 246
      } ],
      "display_url" : "pic.twitter.com\/KZ0RYQuU0R"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785420799423483904",
  "text" : "Coming into the office early, where there's not only still no espresso machine but also no working workstations\u2026 https:\/\/t.co\/KZ0RYQuU0R",
  "id" : 785420799423483904,
  "created_at" : "2016-10-10 10:04:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/hNV16hamdC",
      "expanded_url" : "https:\/\/twitter.com\/JungeAlexander\/status\/785395789048799232",
      "display_url" : "twitter.com\/JungeAlexander\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241152714533, 8.627498923053906 ]
  },
  "id_str" : "785416872871206912",
  "text" : "Who said code couldn\u2019t feel like it\u2019s written in stone! https:\/\/t.co\/hNV16hamdC",
  "id" : 785416872871206912,
  "created_at" : "2016-10-10 09:49:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/biWXALGACg",
      "expanded_url" : "https:\/\/twitter.com\/FT\/status\/785329065930682369",
      "display_url" : "twitter.com\/FT\/status\/7853\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241152714533, 8.627498923053906 ]
  },
  "id_str" : "785416571317526528",
  "text" : "Mine is so messy that I basically have 3 different desks by now. Wonder what that means. https:\/\/t.co\/biWXALGACg",
  "id" : 785416571317526528,
  "created_at" : "2016-10-10 09:47:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 3, 12 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Nature News&Comment",
      "screen_name" : "NatureNews",
      "indices" : [ 113, 124 ],
      "id_str" : "15862891",
      "id" : 15862891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/G9EgIy0Tbv",
      "expanded_url" : "https:\/\/101innovations.wordpress.com\/2016\/10\/09\/github-and-more-sharing-data-code\/",
      "display_url" : "101innovations.wordpress.com\/2016\/10\/09\/git\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785249991401111552",
  "text" : "RT @MsPhelps: Github and more: sharing data &amp; code https:\/\/t.co\/G9EgIy0Tbv - some survey data in response to @NatureNews https:\/\/t.co\/OPuO8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nature News&Comment",
        "screen_name" : "NatureNews",
        "indices" : [ 99, 110 ],
        "id_str" : "15862891",
        "id" : 15862891
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/G9EgIy0Tbv",
        "expanded_url" : "https:\/\/101innovations.wordpress.com\/2016\/10\/09\/github-and-more-sharing-data-code\/",
        "display_url" : "101innovations.wordpress.com\/2016\/10\/09\/git\u2026"
      }, {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/OPuO8gLDjB",
        "expanded_url" : "http:\/\/www.nature.com\/news\/democratic-databases-science-on-github-1.20719#comment-2941912642",
        "display_url" : "nature.com\/news\/democrati\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "785248112625455104",
    "text" : "Github and more: sharing data &amp; code https:\/\/t.co\/G9EgIy0Tbv - some survey data in response to @NatureNews https:\/\/t.co\/OPuO8gLDjB",
    "id" : 785248112625455104,
    "created_at" : "2016-10-09 22:38:33 +0000",
    "user" : {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "protected" : false,
      "id_str" : "22963112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665529153576390660\/ukieWtR4_normal.jpg",
      "id" : 22963112,
      "verified" : false
    }
  },
  "id" : 785249991401111552,
  "created_at" : "2016-10-09 22:46:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zeina Maasri",
      "screen_name" : "zeinamaasri",
      "indices" : [ 3, 15 ],
      "id_str" : "3662327057",
      "id" : 3662327057
    }, {
      "name" : "Lina Mounzer",
      "screen_name" : "warghetti",
      "indices" : [ 131, 141 ],
      "id_str" : "778189519971581952",
      "id" : 778189519971581952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785238973753024512",
  "text" : "RT @zeinamaasri: Poignant &amp; intelligent reflection on what it is to witness\/write\/translate violence &amp; the pain of others. @warghetti https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lina Mounzer",
        "screen_name" : "warghetti",
        "indices" : [ 114, 124 ],
        "id_str" : "778189519971581952",
        "id" : 778189519971581952
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 125, 148 ],
        "url" : "https:\/\/t.co\/YUb5C0Dzin",
        "expanded_url" : "https:\/\/twitter.com\/zeinamaasri\/status\/784701881973080064",
        "display_url" : "twitter.com\/zeinamaasri\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "784714331405549568",
    "text" : "Poignant &amp; intelligent reflection on what it is to witness\/write\/translate violence &amp; the pain of others. @warghetti https:\/\/t.co\/YUb5C0Dzin",
    "id" : 784714331405549568,
    "created_at" : "2016-10-08 11:17:30 +0000",
    "user" : {
      "name" : "Zeina Maasri",
      "screen_name" : "zeinamaasri",
      "protected" : false,
      "id_str" : "3662327057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643714802221756416\/S00AMsFb_normal.jpg",
      "id" : 3662327057,
      "verified" : false
    }
  },
  "id" : 785238973753024512,
  "created_at" : "2016-10-09 22:02:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785222197015089153",
  "geo" : { },
  "id_str" : "785222514356133888",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 gotta admit I never made it to Norway so far!",
  "id" : 785222514356133888,
  "in_reply_to_status_id" : 785222197015089153,
  "created_at" : "2016-10-09 20:56:50 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785221662232997889",
  "geo" : { },
  "id_str" : "785221784694054912",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 guess Norway is a different thing when it comes to winter. :D",
  "id" : 785221784694054912,
  "in_reply_to_status_id" : 785221662232997889,
  "created_at" : "2016-10-09 20:53:56 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/3buBZ8AkOa",
      "expanded_url" : "http:\/\/crazy-stork-company.de\/wp-content\/uploads\/2013\/02\/P1000581.jpg",
      "display_url" : "crazy-stork-company.de\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "785220250757365760",
  "geo" : { },
  "id_str" : "785221175953817600",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 random google image search for \u201EWintergrillen\u201C https:\/\/t.co\/3buBZ8AkOa",
  "id" : 785221175953817600,
  "in_reply_to_status_id" : 785220250757365760,
  "created_at" : "2016-10-09 20:51:31 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785219192555470850",
  "geo" : { },
  "id_str" : "785219904911896577",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 wanna try a European Winter-BBQ? \uD83D\uDE02",
  "id" : 785219904911896577,
  "in_reply_to_status_id" : 785219192555470850,
  "created_at" : "2016-10-09 20:46:28 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785215275574722561",
  "geo" : { },
  "id_str" : "785218389073682432",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 what kind of things do you usually do for these? :D",
  "id" : 785218389073682432,
  "in_reply_to_status_id" : 785215275574722561,
  "created_at" : "2016-10-09 20:40:27 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785215275574722561",
  "geo" : { },
  "id_str" : "785217291248136194",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 ah, no plans yet for that one.",
  "id" : 785217291248136194,
  "in_reply_to_status_id" : 785215275574722561,
  "created_at" : "2016-10-09 20:36:05 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785204519470784513",
  "geo" : { },
  "id_str" : "785216267229753345",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski cool, I\u2019ll be in DC 10th to 15th inclusive. So if you wanna meet up at some point! :)",
  "id" : 785216267229753345,
  "in_reply_to_status_id" : 785204519470784513,
  "created_at" : "2016-10-09 20:32:01 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785206124513550337",
  "geo" : { },
  "id_str" : "785206459621597184",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 which ones? :D",
  "id" : 785206459621597184,
  "in_reply_to_status_id" : 785206124513550337,
  "created_at" : "2016-10-09 19:53:03 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784959071279546368",
  "geo" : { },
  "id_str" : "785196284638625793",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski any chance you\u2019ll be in DC for opencon 12-14th of November? :)",
  "id" : 785196284638625793,
  "in_reply_to_status_id" : 784959071279546368,
  "created_at" : "2016-10-09 19:12:37 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 102, 112 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/Ld59oIJ1Mf",
      "expanded_url" : "https:\/\/medium.com\/@Mooseplainer\/why-i-dont-call-myself-a-male-feminist-2db25bbc31b4#.v61ezjtwp",
      "display_url" : "medium.com\/@Mooseplainer\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "785161434258898944",
  "text" : "tl;dr: Shut up, listen, apologize when you\u2019ve fucked up \u00ABWhy I Don\u2019t Call Myself A Male\u00A0Feminist\u00BB thx @Julie_B92! https:\/\/t.co\/Ld59oIJ1Mf",
  "id" : 785161434258898944,
  "created_at" : "2016-10-09 16:54:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405325501838, 8.753416063117548 ]
  },
  "id_str" : "785108286928457728",
  "text" : "\u00ABOnce you\u2019re gone I will at least still have your dirt to remind me of you.\u00BB\u2014\u00ABYou should start the \u2018sarcastic romanticism\u2019 movement.\u00BB",
  "id" : 785108286928457728,
  "created_at" : "2016-10-09 13:22:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785095042801274880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405325501838, 8.753416063117548 ]
  },
  "id_str" : "785107746857316356",
  "in_reply_to_user_id" : 2968079445,
  "text" : "@AnneAdamPluen \uD83D\uDC96\uD83D\uDC96",
  "id" : 785107746857316356,
  "in_reply_to_status_id" : 785095042801274880,
  "created_at" : "2016-10-09 13:20:48 +0000",
  "in_reply_to_screen_name" : "AnneHTTP404",
  "in_reply_to_user_id_str" : "2968079445",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/dohlzddgK0",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/punishment",
      "display_url" : "smbc-comics.com\/comic\/punishme\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "784852944525127681",
  "geo" : { },
  "id_str" : "784856607230418944",
  "in_reply_to_user_id" : 14286491,
  "text" : "Instead this is what I got https:\/\/t.co\/dohlzddgK0",
  "id" : 784856607230418944,
  "in_reply_to_status_id" : 784852944525127681,
  "created_at" : "2016-10-08 20:42:51 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/qBaKqH9hS9",
      "expanded_url" : "http:\/\/link.springer.com\/article\/10.1007%2Fs10508-016-0789-0",
      "display_url" : "link.springer.com\/article\/10.100\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "784852944525127681",
  "text" : "Totes feel I went into the wrong field of scientific inquiry by now. https:\/\/t.co\/qBaKqH9hS9",
  "id" : 784852944525127681,
  "created_at" : "2016-10-08 20:28:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "F1000Research",
      "screen_name" : "F1000Research",
      "indices" : [ 55, 69 ],
      "id_str" : "59126394",
      "id" : 59126394
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2016",
      "indices" : [ 18, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/5Hv4pAOnoz",
      "expanded_url" : "https:\/\/f1000research.com\/articles\/5-2464\/v1",
      "display_url" : "f1000research.com\/articles\/5-246\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "784643859557023744",
  "text" : "RT @OBF_BOSC: The #BOSC2016 report is now available at @F1000Research: https:\/\/t.co\/5Hv4pAOnoz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "F1000Research",
        "screen_name" : "F1000Research",
        "indices" : [ 41, 55 ],
        "id_str" : "59126394",
        "id" : 59126394
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2016",
        "indices" : [ 4, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/5Hv4pAOnoz",
        "expanded_url" : "https:\/\/f1000research.com\/articles\/5-2464\/v1",
        "display_url" : "f1000research.com\/articles\/5-246\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "784106126908411904",
    "text" : "The #BOSC2016 report is now available at @F1000Research: https:\/\/t.co\/5Hv4pAOnoz",
    "id" : 784106126908411904,
    "created_at" : "2016-10-06 19:00:43 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 784643859557023744,
  "created_at" : "2016-10-08 06:37:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784540805230948352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398920233034, 8.753383220546038 ]
  },
  "id_str" : "784643317258653696",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn \uD83D\uDC96\uD83D\uDC98\uD83D\uDC9D",
  "id" : 784643317258653696,
  "in_reply_to_status_id" : 784540805230948352,
  "created_at" : "2016-10-08 06:35:19 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 3, 13 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/0o1WRxPzad",
      "expanded_url" : "https:\/\/lab.interactivethings.com\/unwanted\/",
      "display_url" : "lab.interactivethings.com\/unwanted\/"
    } ]
  },
  "geo" : { },
  "id_str" : "784501743631622144",
  "text" : "RT @auremoser: \"We accept the first girl, the second should be killed, then the third will be a son.\" https:\/\/t.co\/0o1WRxPzad",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/0o1WRxPzad",
        "expanded_url" : "https:\/\/lab.interactivethings.com\/unwanted\/",
        "display_url" : "lab.interactivethings.com\/unwanted\/"
      } ]
    },
    "geo" : { },
    "id_str" : "784221820371275776",
    "text" : "\"We accept the first girl, the second should be killed, then the third will be a son.\" https:\/\/t.co\/0o1WRxPzad",
    "id" : 784221820371275776,
    "created_at" : "2016-10-07 02:40:26 +0000",
    "user" : {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "protected" : false,
      "id_str" : "186529934",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723868643688325122\/AHwUDHy3_normal.jpg",
      "id" : 186529934,
      "verified" : false
    }
  },
  "id" : 784501743631622144,
  "created_at" : "2016-10-07 21:12:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402729534711, 8.753392794401414 ]
  },
  "id_str" : "784481681378013184",
  "text" : "\u00ABWhen you ghosted me I thought you\u2019d have vanished the same way your signal would if you\u2019d correctly control for multiple testing.\u00BB",
  "id" : 784481681378013184,
  "created_at" : "2016-10-07 19:53:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784457906649460737",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402633211119, 8.753393753592125 ]
  },
  "id_str" : "784480824804642816",
  "in_reply_to_user_id" : 2968079445,
  "text" : "@AnneAdamPluen that\u2019s a nice new avatar!",
  "id" : 784480824804642816,
  "in_reply_to_status_id" : 784457906649460737,
  "created_at" : "2016-10-07 19:49:38 +0000",
  "in_reply_to_screen_name" : "AnneHTTP404",
  "in_reply_to_user_id_str" : "2968079445",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784418081099710466",
  "text" : "Getting more and more excited about going to #mozfest! \uD83C\uDF89\uD83C\uDF88\uD83D\uDC96",
  "id" : 784418081099710466,
  "created_at" : "2016-10-07 15:40:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karissa McKelvey",
      "screen_name" : "okdistribute",
      "indices" : [ 0, 13 ],
      "id_str" : "21713505",
      "id" : 21713505
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 69, 83 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784390280996847616",
  "geo" : { },
  "id_str" : "784390396730277890",
  "in_reply_to_user_id" : 21713505,
  "text" : "@okdistribute well, actually i\u2019m in frankfurt as my geotag says. but @Protohedgehog is in london right now.",
  "id" : 784390396730277890,
  "in_reply_to_status_id" : 784390280996847616,
  "created_at" : "2016-10-07 13:50:18 +0000",
  "in_reply_to_screen_name" : "okdistribute",
  "in_reply_to_user_id_str" : "21713505",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784387059280650240",
  "text" : "Orr, Authorea, how I can roll back to a former state of my article?!",
  "id" : 784387059280650240,
  "created_at" : "2016-10-07 13:37:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karissa McKelvey",
      "screen_name" : "okdistribute",
      "indices" : [ 0, 13 ],
      "id_str" : "21713505",
      "id" : 21713505
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 14, 28 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784384669123022848",
  "geo" : { },
  "id_str" : "784385626854526979",
  "in_reply_to_user_id" : 21713505,
  "text" : "@okdistribute @Protohedgehog no one of us in Berlin, in case you missed it :D",
  "id" : 784385626854526979,
  "in_reply_to_status_id" : 784384669123022848,
  "created_at" : "2016-10-07 13:31:21 +0000",
  "in_reply_to_screen_name" : "okdistribute",
  "in_reply_to_user_id_str" : "21713505",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 0, 12 ],
      "id_str" : "538714687",
      "id" : 538714687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784355812395200512",
  "geo" : { },
  "id_str" : "784359364962451456",
  "in_reply_to_user_id" : 538714687,
  "text" : "@monimunozto oh, bugger! :-(",
  "id" : 784359364962451456,
  "in_reply_to_status_id" : 784355812395200512,
  "created_at" : "2016-10-07 11:46:59 +0000",
  "in_reply_to_screen_name" : "monimunozto",
  "in_reply_to_user_id_str" : "538714687",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18879551999998, 8.617893859999997 ]
  },
  "id_str" : "784354630113329153",
  "text" : "My university sends their newsletter on offering German courses for international students in German\u2026",
  "id" : 784354630113329153,
  "created_at" : "2016-10-07 11:28:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 0, 12 ],
      "id_str" : "538714687",
      "id" : 538714687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784328173970259968",
  "geo" : { },
  "id_str" : "784329327001284610",
  "in_reply_to_user_id" : 538714687,
  "text" : "@monimunozto that sucks! I at least managed at the end!",
  "id" : 784329327001284610,
  "in_reply_to_status_id" : 784328173970259968,
  "created_at" : "2016-10-07 09:47:38 +0000",
  "in_reply_to_screen_name" : "monimunozto",
  "in_reply_to_user_id_str" : "538714687",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784327401870209025",
  "geo" : { },
  "id_str" : "784329205689425920",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette perfect looks at work too! \uD83D\uDC96",
  "id" : 784329205689425920,
  "in_reply_to_status_id" : 784327401870209025,
  "created_at" : "2016-10-07 09:47:09 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer de Vries",
      "screen_name" : "drjendevries",
      "indices" : [ 3, 16 ],
      "id_str" : "365486425",
      "id" : 365486425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784319876148060160",
  "text" : "RT @drjendevries: Making it easy to do the right thing. Gender balance in academic conference speakers spelled out. Thanks Jenny https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/naVJNAyzck",
        "expanded_url" : "https:\/\/twitter.com\/jenny_stem\/status\/783792100877885440",
        "display_url" : "twitter.com\/jenny_stem\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "783988154558668801",
    "text" : "Making it easy to do the right thing. Gender balance in academic conference speakers spelled out. Thanks Jenny https:\/\/t.co\/naVJNAyzck",
    "id" : 783988154558668801,
    "created_at" : "2016-10-06 11:11:56 +0000",
    "user" : {
      "name" : "Jennifer de Vries",
      "screen_name" : "drjendevries",
      "protected" : false,
      "id_str" : "365486425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822722437091442688\/_t7BrsFY_normal.jpg",
      "id" : 365486425,
      "verified" : false
    }
  },
  "id" : 784319876148060160,
  "created_at" : "2016-10-07 09:10:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "_katsel",
      "indices" : [ 0, 8 ],
      "id_str" : "892038837052076033",
      "id" : 892038837052076033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/A0h2AQxwso",
      "expanded_url" : "http:\/\/36.media.tumblr.com\/bf9aad901cb741e4badecff50ab897be\/tumblr_nleq30GCCN1tgzkcpo1_250.jpg",
      "display_url" : "36.media.tumblr.com\/bf9aad901cb741\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "784316699046580224",
  "geo" : { },
  "id_str" : "784316936763023360",
  "in_reply_to_user_id" : 730326143295959040,
  "text" : "@_katsel it\u2019s the best my tired brain could find! https:\/\/t.co\/A0h2AQxwso",
  "id" : 784316936763023360,
  "in_reply_to_status_id" : 784316699046580224,
  "created_at" : "2016-10-07 08:58:24 +0000",
  "in_reply_to_screen_name" : "katheyrina",
  "in_reply_to_user_id_str" : "730326143295959040",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/5De9uYsG6a",
      "expanded_url" : "http:\/\/xkcd.com\/1743\/",
      "display_url" : "xkcd.com\/1743\/"
    } ]
  },
  "in_reply_to_status_id_str" : "784299775428431872",
  "geo" : { },
  "id_str" : "784311283399008256",
  "in_reply_to_user_id" : 14286491,
  "text" : "That\u2019s more or less how we\u2019re doing it in our office right now, the only way we\u2019re surviving at all. https:\/\/t.co\/5De9uYsG6a",
  "id" : 784311283399008256,
  "in_reply_to_status_id" : 784299775428431872,
  "created_at" : "2016-10-07 08:35:56 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/gLrRLhURfP",
      "expanded_url" : "https:\/\/newrepublic.com\/article\/137425\/intersex-activists-beauty-difference",
      "display_url" : "newrepublic.com\/article\/137425\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "784310352171241472",
  "text" : "\u00ABImproved awareness of transgender-specific care among medical providers is a mixed blessing for intersex people\u00BB https:\/\/t.co\/gLrRLhURfP",
  "id" : 784310352171241472,
  "created_at" : "2016-10-07 08:32:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/784299775428431872\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/0bNoBSsyLo",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CuJkexbVMAAEJX7.jpg",
      "id_str" : "784299764942712832",
      "id" : 784299764942712832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CuJkexbVMAAEJX7.jpg",
      "sizes" : [ {
        "h" : 374,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/0bNoBSsyLo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784299775428431872",
  "text" : "Lack of coffee consequences:\n1) forgot office keycard at home\n2) waited in the elevator for minutes w\/o noticing I hadn\u2019t pushed the button https:\/\/t.co\/0bNoBSsyLo",
  "id" : 784299775428431872,
  "created_at" : "2016-10-07 07:50:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "iona inglesby",
      "screen_name" : "ionainglesby",
      "indices" : [ 7, 20 ],
      "id_str" : "139504376",
      "id" : 139504376
    }, {
      "name" : "Dot One",
      "screen_name" : "DotOne_DNA",
      "indices" : [ 22, 33 ],
      "id_str" : "3302735308",
      "id" : 3302735308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784048489185640448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11387118173984, 8.753579916606139 ]
  },
  "id_str" : "784132099741782016",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc @ionainglesby  @DotOne_DNA hey there! \uD83D\uDE0A",
  "id" : 784132099741782016,
  "in_reply_to_status_id" : 784048489185640448,
  "created_at" : "2016-10-06 20:43:55 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 60, 73 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "784093688070807552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402754791852, 8.753390188260624 ]
  },
  "id_str" : "784130203299831809",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy damn, thanks for the pointer. Will investigate. @PhilippBayer",
  "id" : 784130203299831809,
  "in_reply_to_status_id" : 784093688070807552,
  "created_at" : "2016-10-06 20:36:23 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/783950907809665024\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/Udr722EW2g",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CuEnDqIXEAAWsdg.jpg",
      "id_str" : "783950753941622784",
      "id" : 783950753941622784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CuEnDqIXEAAWsdg.jpg",
      "sizes" : [ {
        "h" : 374,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/Udr722EW2g"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/9ZYP9r3k7h",
      "expanded_url" : "https:\/\/twitter.com\/mgollery\/status\/783895933935161344",
      "display_url" : "twitter.com\/mgollery\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "783950907809665024",
  "text" : "Basically all of bioinformatics is a series of Batman-Onomatopoeia. https:\/\/t.co\/9ZYP9r3k7h https:\/\/t.co\/Udr722EW2g",
  "id" : 783950907809665024,
  "created_at" : "2016-10-06 08:43:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/qJHfvRZbJp",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BLMDLCLDjDK\/",
      "display_url" : "instagram.com\/p\/BLMDLCLDjDK\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1119266058, 8.75423348207 ]
  },
  "id_str" : "783708379776749568",
  "text" : "Home, haven't seen it like this in a while. @ Offenbach Hafeninsel https:\/\/t.co\/qJHfvRZbJp",
  "id" : 783708379776749568,
  "created_at" : "2016-10-05 16:40:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "The Local",
      "screen_name" : "TheLocalSwitzer",
      "indices" : [ 91, 107 ],
      "id_str" : "333354104",
      "id" : 333354104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/yOLCmye5q2",
      "expanded_url" : "https:\/\/www.thelocal.ch\/20161004\/tampon-tax-protest-turns-zurich-fountains-red",
      "display_url" : "thelocal.ch\/20161004\/tampo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "783705233520222208",
  "text" : "RT @EffyVayena: Tampon-tax protest turns Zurich fountains red  https:\/\/t.co\/yOLCmye5q2 via @TheLocalSwitzer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Local",
        "screen_name" : "TheLocalSwitzer",
        "indices" : [ 75, 91 ],
        "id_str" : "333354104",
        "id" : 333354104
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/yOLCmye5q2",
        "expanded_url" : "https:\/\/www.thelocal.ch\/20161004\/tampon-tax-protest-turns-zurich-fountains-red",
        "display_url" : "thelocal.ch\/20161004\/tampo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "783610084999827456",
    "text" : "Tampon-tax protest turns Zurich fountains red  https:\/\/t.co\/yOLCmye5q2 via @TheLocalSwitzer",
    "id" : 783610084999827456,
    "created_at" : "2016-10-05 10:09:37 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 783705233520222208,
  "created_at" : "2016-10-05 16:27:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angel Pizarro",
      "screen_name" : "delagoya",
      "indices" : [ 0, 9 ],
      "id_str" : "6977272",
      "id" : 6977272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783626062186110977",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239392833982, 8.627529683372934 ]
  },
  "id_str" : "783664968122109952",
  "in_reply_to_user_id" : 6977272,
  "text" : "@delagoya that\u2019s one way to put it \uD83D\uDE02",
  "id" : 783664968122109952,
  "in_reply_to_status_id" : 783626062186110977,
  "created_at" : "2016-10-05 13:47:42 +0000",
  "in_reply_to_screen_name" : "delagoya",
  "in_reply_to_user_id_str" : "6977272",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783660354459033600",
  "text" : "\u2708\uFE0F-tickets for going to #mozfest! \uD83C\uDF89\uD83C\uDF89\uD83C\uDF89",
  "id" : 783660354459033600,
  "created_at" : "2016-10-05 13:29:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/fTb4gOCQ3Q",
      "expanded_url" : "http:\/\/www.sciencealert.com\/80-of-the-data-in-chinese-clinical-trial-is-fabricated",
      "display_url" : "sciencealert.com\/80-of-the-data\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "783584883750952960",
  "text" : "\u00AB80% of data in Chinese clinical trials have been fabricated\u00BB So China is on par with Neuroscience? https:\/\/t.co\/fTb4gOCQ3Q",
  "id" : 783584883750952960,
  "created_at" : "2016-10-05 08:29:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/783581015667277824\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/nfmgQ5HxfG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct_Wx2sWYAEiVrW.png",
      "id_str" : "783581012169220097",
      "id" : 783581012169220097,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct_Wx2sWYAEiVrW.png",
      "sizes" : [ {
        "h" : 401,
        "resize" : "fit",
        "w" : 412
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 412
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 412
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 412
      } ],
      "display_url" : "pic.twitter.com\/nfmgQ5HxfG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783581015667277824",
  "text" : "Sure, the cluster might still be broken in parts. But at least there\u2019s a new MOTD when you ssh in. https:\/\/t.co\/nfmgQ5HxfG",
  "id" : 783581015667277824,
  "created_at" : "2016-10-05 08:14:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/AxGgEiAmNp",
      "expanded_url" : "https:\/\/metrouk2.files.wordpress.com\/2016\/05\/crying-gif-2.gif",
      "display_url" : "metrouk2.files.wordpress.com\/2016\/05\/crying\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "781769090641854464",
  "geo" : { },
  "id_str" : "783576930171887617",
  "in_reply_to_user_id" : 14286491,
  "text" : "No espresso machine until the end of next week?! \uD83D\uDE31\uD83D\uDE31\uD83D\uDE31 https:\/\/t.co\/AxGgEiAmNp",
  "id" : 783576930171887617,
  "in_reply_to_status_id" : 781769090641854464,
  "created_at" : "2016-10-05 07:57:52 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 0, 7 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783437794517651456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06077355398385, 8.818568883680872 ]
  },
  "id_str" : "783448278981632002",
  "in_reply_to_user_id" : 125928028,
  "text" : "@Gurdur lucky you!",
  "id" : 783448278981632002,
  "in_reply_to_status_id" : 783437794517651456,
  "created_at" : "2016-10-04 23:26:40 +0000",
  "in_reply_to_screen_name" : "Gurdur",
  "in_reply_to_user_id_str" : "125928028",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mooncakes :(",
      "screen_name" : "amatsuki",
      "indices" : [ 3, 12 ],
      "id_str" : "4253541",
      "id" : 4253541
    }, {
      "name" : "women in general",
      "screen_name" : "sarahjeong",
      "indices" : [ 18, 29 ],
      "id_str" : "47509268",
      "id" : 47509268
    }, {
      "name" : "Julia Carrie Wong",
      "screen_name" : "juliacarriew",
      "indices" : [ 34, 47 ],
      "id_str" : "481655487",
      "id" : 481655487
    }, {
      "name" : "Caity Weaver",
      "screen_name" : "caityweaver",
      "indices" : [ 91, 103 ],
      "id_str" : "191332968",
      "id" : 191332968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/gYuYDRS06u",
      "expanded_url" : "https:\/\/www.theguardian.com\/technology\/2016\/oct\/04\/twitter-women-gender-elon-musk-tim-cook?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/technology\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "783443842683002880",
  "text" : "RT @amatsuki: are @sarahjeong and @juliacarriew conspiring to get every tech ceo to follow @caityweaver https:\/\/t.co\/gYuYDRS06u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "women in general",
        "screen_name" : "sarahjeong",
        "indices" : [ 4, 15 ],
        "id_str" : "47509268",
        "id" : 47509268
      }, {
        "name" : "Julia Carrie Wong",
        "screen_name" : "juliacarriew",
        "indices" : [ 20, 33 ],
        "id_str" : "481655487",
        "id" : 481655487
      }, {
        "name" : "Caity Weaver",
        "screen_name" : "caityweaver",
        "indices" : [ 77, 89 ],
        "id_str" : "191332968",
        "id" : 191332968
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/gYuYDRS06u",
        "expanded_url" : "https:\/\/www.theguardian.com\/technology\/2016\/oct\/04\/twitter-women-gender-elon-musk-tim-cook?CMP=share_btn_tw",
        "display_url" : "theguardian.com\/technology\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "783420488928198657",
    "text" : "are @sarahjeong and @juliacarriew conspiring to get every tech ceo to follow @caityweaver https:\/\/t.co\/gYuYDRS06u",
    "id" : 783420488928198657,
    "created_at" : "2016-10-04 21:36:14 +0000",
    "user" : {
      "name" : "one band. one dream.",
      "screen_name" : "amatsuki",
      "protected" : false,
      "id_str" : "4253541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846599054469427201\/6HVFef6D_normal.jpg",
      "id" : 4253541,
      "verified" : false
    }
  },
  "id" : 783443842683002880,
  "created_at" : "2016-10-04 23:09:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783393838043889664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06089064064488, 8.818651062368764 ]
  },
  "id_str" : "783433532131643392",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 or buddies in general \uD83D\uDE02",
  "id" : 783433532131643392,
  "in_reply_to_status_id" : 783393838043889664,
  "created_at" : "2016-10-04 22:28:04 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783378319941263360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06081723193961, 8.818666388395787 ]
  },
  "id_str" : "783380426333253632",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye I hadn\u2019t, thanks!",
  "id" : 783380426333253632,
  "in_reply_to_status_id" : 783378319941263360,
  "created_at" : "2016-10-04 18:57:02 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/eaC9zj1CLT",
      "expanded_url" : "https:\/\/twitter.com\/sujaik\/status\/783217728651952128",
      "display_url" : "twitter.com\/sujaik\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "783327518673764353",
  "text" : "Went with JBrowse for now. Got a working prototype for what I want to do up and running in ~3 hours. \uD83C\uDF89 https:\/\/t.co\/eaC9zj1CLT",
  "id" : 783327518673764353,
  "created_at" : "2016-10-04 15:26:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 0, 4 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783323288709828610",
  "geo" : { },
  "id_str" : "783324903365808128",
  "in_reply_to_user_id" : 793517,
  "text" : "@tkb found that some are impossible if your keyboard layout isn\u2019t US\/UK. But \u201Eshift-ctrl-cmd + (\u256F\u00B0\u25A1\u00B0\uFF09\u256F\uFE35 \u253B\u2501\u253B\u201C is a nice one too!",
  "id" : 783324903365808128,
  "in_reply_to_status_id" : 783323288709828610,
  "created_at" : "2016-10-04 15:16:25 +0000",
  "in_reply_to_screen_name" : "tkb",
  "in_reply_to_user_id_str" : "793517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 0, 4 ],
      "id_str" : "793517",
      "id" : 793517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783322617029791744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241051679032, 8.627503520499674 ]
  },
  "id_str" : "783322997209829377",
  "in_reply_to_user_id" : 793517,
  "text" : "@tkb wait, there are 5-key combo shortcuts? \uD83D\uDE31",
  "id" : 783322997209829377,
  "in_reply_to_status_id" : 783322617029791744,
  "created_at" : "2016-10-04 15:08:50 +0000",
  "in_reply_to_screen_name" : "tkb",
  "in_reply_to_user_id_str" : "793517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathilde Cordellier",
      "screen_name" : "m_cordellier",
      "indices" : [ 0, 13 ],
      "id_str" : "3373710875",
      "id" : 3373710875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783287681237258240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240959695643, 8.62751429945118 ]
  },
  "id_str" : "783290209668624384",
  "in_reply_to_user_id" : 3373710875,
  "text" : "@m_cordellier not a bit ;)",
  "id" : 783290209668624384,
  "in_reply_to_status_id" : 783287681237258240,
  "created_at" : "2016-10-04 12:58:33 +0000",
  "in_reply_to_screen_name" : "m_cordellier",
  "in_reply_to_user_id_str" : "3373710875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783273312516448256",
  "text" : "\u00ABWe\u2019ll do our own Journal, the \u201EJournal of Pervert Twin Studies\u201C.\u00BB \u2013 \u00ABI guess Elsevier would publish it, no questions asked.\u00BB",
  "id" : 783273312516448256,
  "created_at" : "2016-10-04 11:51:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783257066974617636",
  "geo" : { },
  "id_str" : "783258649972047872",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette and as beavers are classified as fish and fish is not meat, beavers are vegetarian too.",
  "id" : 783258649972047872,
  "in_reply_to_status_id" : 783257066974617636,
  "created_at" : "2016-10-04 10:53:09 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783250660070420480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17182999433489, 8.631356943794154 ]
  },
  "id_str" : "783251850615218176",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette where I was born they still claim that bacon is vegetarian. \uD83D\uDE02",
  "id" : 783251850615218176,
  "in_reply_to_status_id" : 783250660070420480,
  "created_at" : "2016-10-04 10:26:07 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783246535295393792",
  "geo" : { },
  "id_str" : "783246604497260544",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr awesome, have fun!",
  "id" : 783246604497260544,
  "in_reply_to_status_id" : 783246535295393792,
  "created_at" : "2016-10-04 10:05:17 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/GHMBRc6s3h",
      "expanded_url" : "https:\/\/jakubmarian.com\/map-of-vegetarian-friendliness-number-of-vegetarian-restaurants-in-europe-by-country\/",
      "display_url" : "jakubmarian.com\/map-of-vegetar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "783243675660853248",
  "text" : "France, the vegetarian wasteland. https:\/\/t.co\/GHMBRc6s3h",
  "id" : 783243675660853248,
  "created_at" : "2016-10-04 09:53:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 8, 22 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783218111659012096",
  "geo" : { },
  "id_str" : "783218835667156992",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @BioMickWatson wow, thanks! The comp. viz. I don\u2019t really need, but some search\/BLAST might be cool!",
  "id" : 783218835667156992,
  "in_reply_to_status_id" : 783218111659012096,
  "created_at" : "2016-10-04 08:14:56 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783213533026721792",
  "text" : "What kind of genome browser does one want to set up these days if one doesn\u2019t enjoy configuration pain?",
  "id" : 783213533026721792,
  "created_at" : "2016-10-04 07:53:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "indices" : [ 3, 16 ],
      "id_str" : "19084034",
      "id" : 19084034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782921068763836416",
  "text" : "RT @ericmjohnson: Blaming the Victim: A Cultural Evolutionist Responds to the University of Chicago\u2019s Dismissal of Trauma https:\/\/t.co\/Ka7q\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "This View of Life",
        "screen_name" : "tvolmag",
        "indices" : [ 132, 140 ],
        "id_str" : "198738534",
        "id" : 198738534
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/Ka7q6uoWwz",
        "expanded_url" : "http:\/\/thisviewoflife.com\/article\/blaming-the-victim-a-cultural-evolutionist-responds-to-the-university-of-chicagos-dismissal-of-trauma\/",
        "display_url" : "thisviewoflife.com\/article\/blamin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "782920551266263040",
    "text" : "Blaming the Victim: A Cultural Evolutionist Responds to the University of Chicago\u2019s Dismissal of Trauma https:\/\/t.co\/Ka7q6uoWwz via @tvolmag",
    "id" : 782920551266263040,
    "created_at" : "2016-10-03 12:29:40 +0000",
    "user" : {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "protected" : false,
      "id_str" : "19084034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434953612825858048\/DckRYRye_normal.png",
      "id" : 19084034,
      "verified" : false
    }
  },
  "id" : 782921068763836416,
  "created_at" : "2016-10-03 12:31:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782912525016924160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11383767704991, 8.753581471368275 ]
  },
  "id_str" : "782912715115401216",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog but I\u2019m sure even without you\u2019ll get the gist. Your German swearing seems spot on!",
  "id" : 782912715115401216,
  "in_reply_to_status_id" : 782912525016924160,
  "created_at" : "2016-10-03 11:58:31 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782912525016924160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11378430948731, 8.753688325107234 ]
  },
  "id_str" : "782912603341328384",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog Google translate the lyrics posted there :p",
  "id" : 782912603341328384,
  "in_reply_to_status_id" : 782912525016924160,
  "created_at" : "2016-10-03 11:58:05 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/5IfhPMt4km",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=1qOPFhM8cPM",
      "display_url" : "m.youtube.com\/watch?v=1qOPFh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782911672725929984",
  "text" : "If you were under the mistaken impression that there ever was anything to celebrate in Germany on this day. https:\/\/t.co\/5IfhPMt4km",
  "id" : 782911672725929984,
  "created_at" : "2016-10-03 11:54:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 0, 7 ],
      "id_str" : "34880281",
      "id" : 34880281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781212432865853441",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1138399037731, 8.753617775701763 ]
  },
  "id_str" : "782868486880190464",
  "in_reply_to_user_id" : 34880281,
  "text" : "@otacke danke, das hab ich ja nun erst entdeckt! :-)",
  "id" : 782868486880190464,
  "in_reply_to_status_id" : 781212432865853441,
  "created_at" : "2016-10-03 09:02:46 +0000",
  "in_reply_to_screen_name" : "otacke",
  "in_reply_to_user_id_str" : "34880281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 3, 10 ],
      "id_str" : "34880281",
      "id" : 34880281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/kspzYAoSwi",
      "expanded_url" : "http:\/\/ift.tt\/2du6d7t",
      "display_url" : "ift.tt\/2du6d7t"
    } ]
  },
  "geo" : { },
  "id_str" : "782868430143819776",
  "text" : "RT @otacke: Frisch bei mir im Blog: Kehre dein Innerstes heraus mit openSNP https:\/\/t.co\/kspzYAoSwi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/kspzYAoSwi",
        "expanded_url" : "http:\/\/ift.tt\/2du6d7t",
        "display_url" : "ift.tt\/2du6d7t"
      } ]
    },
    "geo" : { },
    "id_str" : "781212432865853441",
    "text" : "Frisch bei mir im Blog: Kehre dein Innerstes heraus mit openSNP https:\/\/t.co\/kspzYAoSwi",
    "id" : 781212432865853441,
    "created_at" : "2016-09-28 19:22:12 +0000",
    "user" : {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "protected" : false,
      "id_str" : "34880281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737745028093612032\/5_FvGA1O_normal.jpg",
      "id" : 34880281,
      "verified" : false
    }
  },
  "id" : 782868430143819776,
  "created_at" : "2016-10-03 09:02:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/4Y0lfsdvGb",
      "expanded_url" : "https:\/\/media1.giphy.com\/media\/aTUrF9TPZYy6Q\/200.gif",
      "display_url" : "media1.giphy.com\/media\/aTUrF9TP\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "782846788214657025",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11384225414815, 8.753617004724273 ]
  },
  "id_str" : "782864056139014144",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg https:\/\/t.co\/4Y0lfsdvGb",
  "id" : 782864056139014144,
  "in_reply_to_status_id" : 782846788214657025,
  "created_at" : "2016-10-03 08:45:10 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 0, 16 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "Jeannie Hunnicutt",
      "screen_name" : "HelloHunnicutt",
      "indices" : [ 17, 32 ],
      "id_str" : "3364467014",
      "id" : 3364467014
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782800690754138112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393557359557, 8.753532497937941 ]
  },
  "id_str" : "782861544120061952",
  "in_reply_to_user_id" : 383289779,
  "text" : "@daniellecrobins @HelloHunnicutt \uD83D\uDE0D",
  "id" : 782861544120061952,
  "in_reply_to_status_id" : 782800690754138112,
  "created_at" : "2016-10-03 08:35:11 +0000",
  "in_reply_to_screen_name" : "daniellecrobins",
  "in_reply_to_user_id_str" : "383289779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/n6F5wblraw",
      "expanded_url" : "https:\/\/twitter.com\/o_guest\/status\/782712536068128768",
      "display_url" : "twitter.com\/o_guest\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11389638582298, 8.75352195619903 ]
  },
  "id_str" : "782856183124226048",
  "text" : "Henceforth the collective noun for a group of social psychologists should be \u201Cpower posse\u201D. https:\/\/t.co\/n6F5wblraw",
  "id" : 782856183124226048,
  "created_at" : "2016-10-03 08:13:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/782841390061522944\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/uiXcbYW8Wt",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ct02FvlXgAA1APn.jpg",
      "id_str" : "782841382532775936",
      "id" : 782841382532775936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ct02FvlXgAA1APn.jpg",
      "sizes" : [ {
        "h" : 252,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/uiXcbYW8Wt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782841390061522944",
  "text" : "\u00ABIt's perfect if you have to leave early, then I can even go for a run in the morning.\u00BB Well\u2026 https:\/\/t.co\/uiXcbYW8Wt",
  "id" : 782841390061522944,
  "created_at" : "2016-10-03 07:15:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782690670599438336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402820689284, 8.753389387115483 ]
  },
  "id_str" : "782837050940788740",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 best horrible adventure to read up on after waking up.",
  "id" : 782837050940788740,
  "in_reply_to_status_id" : 782690670599438336,
  "created_at" : "2016-10-03 06:57:52 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/6uFJmZScql",
      "expanded_url" : "https:\/\/twitter.com\/gossipgriII\/status\/781530649811312644",
      "display_url" : "twitter.com\/gossipgriII\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402865492438, 8.753389748516511 ]
  },
  "id_str" : "782835099456929793",
  "text" : "Fuckin\u2019 Internet of Things. https:\/\/t.co\/6uFJmZScql",
  "id" : 782835099456929793,
  "created_at" : "2016-10-03 06:50:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782738999337164800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402865534439, 8.753389765611967 ]
  },
  "id_str" : "782834504658460672",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn too bad that I\u2019m not a US citizen \uD83D\uDE02\uD83D\uDE02",
  "id" : 782834504658460672,
  "in_reply_to_status_id" : 782738999337164800,
  "created_at" : "2016-10-03 06:47:44 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782641820849274880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11386986595938, 8.753596975363594 ]
  },
  "id_str" : "782703143545176064",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 \uD83D\uDE31 good luck in getting rid of them!",
  "id" : 782703143545176064,
  "in_reply_to_status_id" : 782641820849274880,
  "created_at" : "2016-10-02 22:05:45 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782659920135094274",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11386986595938, 8.753596975363594 ]
  },
  "id_str" : "782702543881269248",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn happy birthday I guess? \uD83D\uDE33\uD83D\uDE18",
  "id" : 782702543881269248,
  "in_reply_to_status_id" : 782659920135094274,
  "created_at" : "2016-10-02 22:03:23 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mich\u24D0el\u24D0  Rossini",
      "screen_name" : "mr0ssini",
      "indices" : [ 0, 9 ],
      "id_str" : "161270361",
      "id" : 161270361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782666488226406401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1138932169217, 8.753523233733084 ]
  },
  "id_str" : "782667057007591424",
  "in_reply_to_user_id" : 161270361,
  "text" : "@mr0ssini a very weird and nice one :D",
  "id" : 782667057007591424,
  "in_reply_to_status_id" : 782666488226406401,
  "created_at" : "2016-10-02 19:42:22 +0000",
  "in_reply_to_screen_name" : "mr0ssini",
  "in_reply_to_user_id_str" : "161270361",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mich\u24D0el\u24D0  Rossini",
      "screen_name" : "mr0ssini",
      "indices" : [ 0, 9 ],
      "id_str" : "161270361",
      "id" : 161270361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782663794422124549",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11391877578678, 8.753523235286268 ]
  },
  "id_str" : "782666291379339264",
  "in_reply_to_user_id" : 161270361,
  "text" : "@mr0ssini in the sense that I was told this in person. Otherwise it\u2019s not :p",
  "id" : 782666291379339264,
  "in_reply_to_status_id" : 782663794422124549,
  "created_at" : "2016-10-02 19:39:19 +0000",
  "in_reply_to_screen_name" : "mr0ssini",
  "in_reply_to_user_id_str" : "161270361",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kayte SpectorBagdady",
      "screen_name" : "KayteSB",
      "indices" : [ 0, 8 ],
      "id_str" : "1410245676",
      "id" : 1410245676
    }, {
      "name" : "Patti Zettler",
      "screen_name" : "pzettler",
      "indices" : [ 9, 18 ],
      "id_str" : "1455790448",
      "id" : 1455790448
    }, {
      "name" : "J.Humphreys \u05D9\u05D5\u05D7\u05E0\u05DF",
      "screen_name" : "johnpharmd",
      "indices" : [ 19, 30 ],
      "id_str" : "48695135",
      "id" : 48695135
    }, {
      "name" : "Hank Greely",
      "screen_name" : "HankGreelyLSJU",
      "indices" : [ 31, 46 ],
      "id_str" : "378272434",
      "id" : 378272434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782651318842327040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399655368746, 8.75346859484475 ]
  },
  "id_str" : "782652474532499456",
  "in_reply_to_user_id" : 1410245676,
  "text" : "@KayteSB @pzettler @johnpharmd @HankGreelyLSJU think that\u2019s different. 23andme was giving combined interpretation in 2010, (eg overall risk)",
  "id" : 782652474532499456,
  "in_reply_to_status_id" : 782651318842327040,
  "created_at" : "2016-10-02 18:44:25 +0000",
  "in_reply_to_screen_name" : "KayteSB",
  "in_reply_to_user_id_str" : "1410245676",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11389424789905, 8.75352222750818 ]
  },
  "id_str" : "782650714552229888",
  "text" : "\u00ABShe reminds me of you. The female, lesbian, pornstar version of you.\u00BB",
  "id" : 782650714552229888,
  "created_at" : "2016-10-02 18:37:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kayte SpectorBagdady",
      "screen_name" : "KayteSB",
      "indices" : [ 0, 8 ],
      "id_str" : "1410245676",
      "id" : 1410245676
    }, {
      "name" : "Patti Zettler",
      "screen_name" : "pzettler",
      "indices" : [ 9, 18 ],
      "id_str" : "1455790448",
      "id" : 1455790448
    }, {
      "name" : "John Humphreys",
      "screen_name" : "johnpharmd",
      "indices" : [ 19, 30 ],
      "id_str" : "48695135",
      "id" : 48695135
    }, {
      "name" : "Hank Greely",
      "screen_name" : "HankGreelyLSJU",
      "indices" : [ 31, 46 ],
      "id_str" : "378272434",
      "id" : 378272434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782645583278407681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402726949627, 8.753389483754148 ]
  },
  "id_str" : "782648938478309376",
  "in_reply_to_user_id" : 1410245676,
  "text" : "@KayteSB @pzettler @johnpharmd @HankGreelyLSJU we\u2019re not doing any analysis on the data we host. Just data as reported by 3rd parties.",
  "id" : 782648938478309376,
  "in_reply_to_status_id" : 782645583278407681,
  "created_at" : "2016-10-02 18:30:22 +0000",
  "in_reply_to_screen_name" : "KayteSB",
  "in_reply_to_user_id_str" : "1410245676",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11389464870957, 8.753521991931805 ]
  },
  "id_str" : "782630824390881284",
  "text" : "\u05E9\u05E0\u05D4 \u05D8\u05D5\u05D1\u05D4!",
  "id" : 782630824390881284,
  "created_at" : "2016-10-02 17:18:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 26, 37 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/DG3G0L08Qj",
      "expanded_url" : "http:\/\/mobile.nytimes.com\/2016\/10\/02\/style\/how-to-express-sympathy.html?smprod=nytcore-iphone&smid=nytcore-iphone-share&_r=0&referer=http:\/\/m.facebook.com",
      "display_url" : "mobile.nytimes.com\/2016\/10\/02\/sty\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782237410293850112",
  "text" : "The Art of Condolence \/HT @bella_velo  https:\/\/t.co\/DG3G0L08Qj",
  "id" : 782237410293850112,
  "created_at" : "2016-10-01 15:15:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "[]",
      "screen_name" : "himbeer_",
      "indices" : [ 0, 9 ],
      "id_str" : "761209723794382848",
      "id" : 761209723794382848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781935813076643840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402714004159, 8.753389461299529 ]
  },
  "id_str" : "781993640935714816",
  "in_reply_to_user_id" : 761209723794382848,
  "text" : "@himbeer_ ja, musste auch lange suchen. War nur sicher das es einen geben sollte so wie ich die Leute dahinter einsch\u00E4tze.",
  "id" : 781993640935714816,
  "in_reply_to_status_id" : 781935813076643840,
  "created_at" : "2016-09-30 23:06:27 +0000",
  "in_reply_to_screen_name" : "himbeer_",
  "in_reply_to_user_id_str" : "761209723794382848",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]