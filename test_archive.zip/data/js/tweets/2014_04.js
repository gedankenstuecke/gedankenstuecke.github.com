Grailbird.data.tweets_2014_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461614996326453248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096540638, 8.282971355 ]
  },
  "id_str" : "461615039695552512",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng yay \\o\/",
  "id" : 461615039695552512,
  "in_reply_to_status_id" : 461614996326453248,
  "created_at" : "2014-04-30 21:16:16 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461612656282333184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096219425, 8.2829462499 ]
  },
  "id_str" : "461613267182706688",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule \u2026making everything explode. But only if logging is enabled _and_ it\u2019s run via the queue. Fun!",
  "id" : 461613267182706688,
  "in_reply_to_status_id" : 461612656282333184,
  "created_at" : "2014-04-30 21:09:13 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461612656282333184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096349112, 8.2829787233 ]
  },
  "id_str" : "461613100186501120",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule in my case it was log=\u201C\/dev\/stderr\u201D hardcoded in that script. qsub for submitting to the cluster changes stderr for log purposes\u2026",
  "id" : 461613100186501120,
  "in_reply_to_status_id" : 461612656282333184,
  "created_at" : "2014-04-30 21:08:34 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/5Gh4Zhy4ov",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Ernst_Haeckel#Polygenism_and_racial_theory",
      "display_url" : "en.wikipedia.org\/wiki\/Ernst_Hae\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096789117, 8.2829729067 ]
  },
  "id_str" : "461595482171912193",
  "text" : "Titel eines Vortrags der bald in Mainz stattfindet: \u00ABRichard Dawkins, der Haeckel unserer Zeit\u00BB *hust* http:\/\/t.co\/5Gh4Zhy4ov",
  "id" : 461595482171912193,
  "created_at" : "2014-04-30 19:58:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009657982, 8.2829729426 ]
  },
  "id_str" : "461590753576501248",
  "text" : "Beim Tanz in den Mai im Gemeindezentrum gegen\u00FCber spielen sie jetzt den Imperial March\u2026",
  "id" : 461590753576501248,
  "created_at" : "2014-04-30 19:39:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/3Uc8VFc3ss",
      "expanded_url" : "http:\/\/www.dailydot.com\/lol\/me-irl-internet-history\/",
      "display_url" : "dailydot.com\/lol\/me-irl-int\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009647444, 8.282987824 ]
  },
  "id_str" : "461585407902515201",
  "text" : "me irl http:\/\/t.co\/3Uc8VFc3ss",
  "id" : 461585407902515201,
  "created_at" : "2014-04-30 19:18:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461582318227169281",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009647444, 8.282987824 ]
  },
  "id_str" : "461582409092571136",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng rettet die Schildkr\u00F6ten!",
  "id" : 461582409092571136,
  "in_reply_to_status_id" : 461582318227169281,
  "created_at" : "2014-04-30 19:06:36 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/yEzFAEBqlm",
      "expanded_url" : "http:\/\/99percentinvisible.org\/episode\/young-ruin\/",
      "display_url" : "99percentinvisible.org\/episode\/young-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096687038, 8.2829931388 ]
  },
  "id_str" : "461568666157744128",
  "text" : "The latest episode of 99% Invisible about Sutro Baths really makes me regret I didn\u2019t do any sightseeing while in SF. http:\/\/t.co\/yEzFAEBqlm",
  "id" : 461568666157744128,
  "created_at" : "2014-04-30 18:12:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Alison Atkin",
      "screen_name" : "alisonatkin",
      "indices" : [ 30, 42 ],
      "id_str" : "21301376",
      "id" : 21301376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461544782440173568",
  "text" : "RT @edyong209: You\u2019re not. RT @alisonatkin: Srsly. I cannot be the only person who is all like shmeh about Richard III's genome: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alison Atkin",
        "screen_name" : "alisonatkin",
        "indices" : [ 15, 27 ],
        "id_str" : "21301376",
        "id" : 21301376
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/pn406PfU7N",
        "expanded_url" : "http:\/\/deathsplaining.wordpress.com\/2014\/04\/30\/whats-in-a-king-apparently-dna\/",
        "display_url" : "deathsplaining.wordpress.com\/2014\/04\/30\/wha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "461543049274089472",
    "text" : "You\u2019re not. RT @alisonatkin: Srsly. I cannot be the only person who is all like shmeh about Richard III's genome: http:\/\/t.co\/pn406PfU7N",
    "id" : 461543049274089472,
    "created_at" : "2014-04-30 16:30:12 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 461544782440173568,
  "created_at" : "2014-04-30 16:37:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Spear",
      "screen_name" : "mikesgene",
      "indices" : [ 0, 10 ],
      "id_str" : "13395272",
      "id" : 13395272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461507721125441536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461507932967149568",
  "in_reply_to_user_id" : 13395272,
  "text" : "@mikesgene hopefully in a couple of years you can legitimately claim not to know ;)",
  "id" : 461507932967149568,
  "in_reply_to_status_id" : 461507721125441536,
  "created_at" : "2014-04-30 14:10:40 +0000",
  "in_reply_to_screen_name" : "mikesgene",
  "in_reply_to_user_id_str" : "13395272",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Spear",
      "screen_name" : "mikesgene",
      "indices" : [ 84, 94 ],
      "id_str" : "13395272",
      "id" : 13395272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/0K1qViTEvH",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/04\/28\/opinion\/verbatim-what-is-a-photocopier.html?_r=2",
      "display_url" : "nytimes.com\/2014\/04\/28\/opi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461507017501597696",
  "text" : "\u00ABWhen you say \u201Cphotocopying machine,\u201D what do you mean?\u00BB http:\/\/t.co\/0K1qViTEvH \/HT @mikesgene",
  "id" : 461507017501597696,
  "created_at" : "2014-04-30 14:07:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461498194602762240",
  "text" : "Great fun to debug: software that crashes if the error log is enabled but works fine if you suppress the error log.",
  "id" : 461498194602762240,
  "created_at" : "2014-04-30 13:31:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461443591693676545",
  "text" : "\u00ABUnd wenn du ganz hart bist, und aus dem Vogelsberg kommst, dann schreibst du Musik auch mit drei \u2018g\u2019.\u00BB",
  "id" : 461443591693676545,
  "created_at" : "2014-04-30 09:55:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/61UDk1R275",
      "expanded_url" : "http:\/\/instagram.com\/p\/naExa2Bwqg\/",
      "display_url" : "instagram.com\/p\/naExa2Bwqg\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172192636, 8.630112153 ]
  },
  "id_str" : "461423046042345472",
  "text" : "\u00ABFinally we can claim to be busy with bench work as well!\u00BB @ Goethe-Universit\u00E4t Frankfurt, Campus\u2026 http:\/\/t.co\/61UDk1R275",
  "id" : 461423046042345472,
  "created_at" : "2014-04-30 08:33:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461160700304707585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461406612822192129",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a sorry, the JC was canceled, the student is currently ill. I\u2019ll keep you posted on the new date.",
  "id" : 461406612822192129,
  "in_reply_to_status_id" : 461160700304707585,
  "created_at" : "2014-04-30 07:28:03 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1008149314, 8.6381615017 ]
  },
  "id_str" : "461390427095334912",
  "text" : "Yesterday I wondered all day why my foot was itching that much. Today I discovered the ~ 3 cm long splinter of wood buried deep into it. m)",
  "id" : 461390427095334912,
  "created_at" : "2014-04-30 06:23:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/d3kA02NeDf",
      "expanded_url" : "http:\/\/stilldrinking.org\/programming-sucks",
      "display_url" : "stilldrinking.org\/programming-su\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0872066473, 8.51238889 ]
  },
  "id_str" : "461386743032610816",
  "text" : "Programming sucks: \u00ABeverything is broken because there's no good code and everybody's just trying to keep it running\u00BB http:\/\/t.co\/d3kA02NeDf",
  "id" : 461386743032610816,
  "created_at" : "2014-04-30 06:09:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461293278193664000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096036, 8.282958888 ]
  },
  "id_str" : "461293814041559040",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, pretty useful if you want to explain basic mol. bio. to non-experts I guess. (and the cited paper sounds interesting)",
  "id" : 461293814041559040,
  "in_reply_to_status_id" : 461293278193664000,
  "created_at" : "2014-04-29 23:59:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461282303139143680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096036, 8.282958888 ]
  },
  "id_str" : "461282519581986817",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nein, aber eine Telefon mit dem ich Schl\u00FCsselinhaber oder Pickset-Besitzer summonen kann. :p",
  "id" : 461282519581986817,
  "in_reply_to_status_id" : 461282303139143680,
  "created_at" : "2014-04-29 23:14:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/Z8Zot3vSu0",
      "expanded_url" : "http:\/\/acousticsauna.net\/videos\/",
      "display_url" : "acousticsauna.net\/videos\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096036, 8.282958888 ]
  },
  "id_str" : "461278035023777792",
  "text" : "\u00ABWhat would be a cooler place to play an acoustic set than a sauna?\u00BB http:\/\/t.co\/Z8Zot3vSu0",
  "id" : 461278035023777792,
  "created_at" : "2014-04-29 22:57:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 52, 59 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/aeXpwqFIZw",
      "expanded_url" : "https:\/\/medium.com\/ladybits-on-medium\/f1357d9aa9d6",
      "display_url" : "medium.com\/ladybits-on-me\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096036, 8.282958888 ]
  },
  "id_str" : "461272826570612736",
  "text" : "Fucking Like A Feminist https:\/\/t.co\/aeXpwqFIZw \/HT @arikia",
  "id" : 461272826570612736,
  "created_at" : "2014-04-29 22:36:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461272371933229056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096036, 8.282958888 ]
  },
  "id_str" : "461272523850911744",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot was meinst du wieso ich meinen so oft vergesse?",
  "id" : 461272523850911744,
  "in_reply_to_status_id" : 461272371933229056,
  "created_at" : "2014-04-29 22:35:14 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 24, 37 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/rInllRAoR2",
      "expanded_url" : "http:\/\/inspiringscience.net\/2014\/04\/29\/the-language-of-dna\/",
      "display_url" : "inspiringscience.net\/2014\/04\/29\/the\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096036, 8.282958888 ]
  },
  "id_str" : "461262482850725888",
  "text" : "The Language of\u00A0DNA \/cc @PhilippBayer http:\/\/t.co\/rInllRAoR2",
  "id" : 461262482850725888,
  "created_at" : "2014-04-29 21:55:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461234214978220033",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1024853942, 8.5706308815 ]
  },
  "id_str" : "461246537650405376",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot dann kannst du deinen Schl\u00FCssel ja zur\u00FCckgeben? ;)",
  "id" : 461246537650405376,
  "in_reply_to_status_id" : 461234214978220033,
  "created_at" : "2014-04-29 20:51:58 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461160618431893506",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461160740549042176",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a me too! That might be a lively discussion :D",
  "id" : 461160740549042176,
  "in_reply_to_status_id" : 461160618431893506,
  "created_at" : "2014-04-29 15:11:03 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461159994927624193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461160163115040768",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a afterwards I\u2019ll have a couple of meetings afterwards, so it will be 4pmish before you\u2019ll get my notes.",
  "id" : 461160163115040768,
  "in_reply_to_status_id" : 461159994927624193,
  "created_at" : "2014-04-29 15:08:45 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461159801524060162",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461159913117736960",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a nope, tomorrow at 11am. Haven\u2019t forgotten about it :)",
  "id" : 461159913117736960,
  "in_reply_to_status_id" : 461159801524060162,
  "created_at" : "2014-04-29 15:07:45 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/fyVQYe6Q5v",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/neuroskeptic\/2014\/04\/29\/recursive-fury-ethics-criticism\/#.U1-i562SyFc",
      "display_url" : "blogs.discovermagazine.com\/neuroskeptic\/2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461131159347666944",
  "text" : "\u00ABMisunderstanding The Ethics of Criticism\u00BB Another case where traditional research ethics &amp; the internet collide http:\/\/t.co\/fyVQYe6Q5v",
  "id" : 461131159347666944,
  "created_at" : "2014-04-29 13:13:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461119825142874112",
  "text" : "\u00ABIch dachte kurz du h\u00E4ttest am G\u00FCrtel auch so ein Leucht-Ding wie der Hund am Halsband.\u00BB \u2013 \u00ABOh yeah, mein landing strip ist beleuchtet!\u00BB",
  "id" : 461119825142874112,
  "created_at" : "2014-04-29 12:28:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461111447255527424",
  "text" : "somehow I feel my genome assembler of choice is handing out relationship advice: \u00ABclipping dubious poly-base stretches at the end.\u00BB",
  "id" : 461111447255527424,
  "created_at" : "2014-04-29 11:55:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 16, 29 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461103500714196993",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723332542, 8.6276160632 ]
  },
  "id_str" : "461103829451550720",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann @PhilippBayer testing as collaborators used k that large and wanted to reproduce their results. Will email you :)",
  "id" : 461103829451550720,
  "in_reply_to_status_id" : 461103500714196993,
  "created_at" : "2014-04-29 11:24:54 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461081896789626881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461082077321265152",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer somehow it always gives back the largest tested kmer-size as optimal one (even 251), which doesn\u2019t seem right. ;)",
  "id" : 461082077321265152,
  "in_reply_to_status_id" : 461081896789626881,
  "created_at" : "2014-04-29 09:58:28 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461064155324104704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461081719727456256",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw: do you have experience with using VelvetOptimiser?",
  "id" : 461081719727456256,
  "in_reply_to_status_id" : 461064155324104704,
  "created_at" : "2014-04-29 09:57:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/wD1P1w9g4a",
      "expanded_url" : "http:\/\/i0.wp.com\/jhack.co.uk\/wp-content\/uploads\/2013\/04\/horse-gif.gif?resize=500%2C421",
      "display_url" : "i0.wp.com\/jhack.co.uk\/wp\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "461077185055690752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461077408725348352",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot well, if you\u2019re asking for it: here\u2019s your slapping http:\/\/t.co\/wD1P1w9g4a",
  "id" : 461077408725348352,
  "in_reply_to_status_id" : 461077185055690752,
  "created_at" : "2014-04-29 09:39:55 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461075166244929536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461076433671323648",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot worse: it\u2019s per day, not per hour.",
  "id" : 461076433671323648,
  "in_reply_to_status_id" : 461075166244929536,
  "created_at" : "2014-04-29 09:36:02 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/Ywn5kZ7f1M",
      "expanded_url" : "http:\/\/www.horsenation.com\/wp-content\/uploads\/2013\/03\/tumblr_md44nadNyA1r6cd97o1_400.gif",
      "display_url" : "horsenation.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "461074153987379200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461074705987174400",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot they see you playing with balls http:\/\/t.co\/Ywn5kZ7f1M",
  "id" : 461074705987174400,
  "in_reply_to_status_id" : 461074153987379200,
  "created_at" : "2014-04-29 09:29:10 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/zg632I2OWa",
      "expanded_url" : "http:\/\/www.npr.org\/blogs\/thesalt\/2014\/04\/28\/306544406\/got-gas-it-could-mean-you-ve-got-healthy-gut-microbes",
      "display_url" : "npr.org\/blogs\/thesalt\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461073719390380032",
  "text" : "On the health benefits of smelly farts http:\/\/t.co\/zg632I2OWa",
  "id" : 461073719390380032,
  "created_at" : "2014-04-29 09:25:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/6lYjHFNVdV",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2014\/04\/mice-get-stressed-out-feel-less-pain-when-male-lab-workers-are-present\/",
      "display_url" : "arstechnica.com\/science\/2014\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461071575807438848",
  "text" : "Mice get stressed out, feel less pain when male lab workers are present http:\/\/t.co\/6lYjHFNVdV",
  "id" : 461071575807438848,
  "created_at" : "2014-04-29 09:16:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/wW4at7bKtL",
      "expanded_url" : "http:\/\/i.imgur.com\/Oyv0SDS.gif",
      "display_url" : "i.imgur.com\/Oyv0SDS.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "461068120862773248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461068539299119104",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot they told me I could be anything I wanted\u2026 http:\/\/t.co\/wW4at7bKtL",
  "id" : 461068539299119104,
  "in_reply_to_status_id" : 461068120862773248,
  "created_at" : "2014-04-29 09:04:40 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Herr Siering",
      "screen_name" : "HerrBertling",
      "indices" : [ 15, 28 ],
      "id_str" : "14115883",
      "id" : 14115883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461067157196247040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461067581596893184",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon @HerrBertling Als ich mich noch per Modem eingew\u00E4hlt habe gab es noch keine Podcasts ;)",
  "id" : 461067581596893184,
  "in_reply_to_status_id" : 461067157196247040,
  "created_at" : "2014-04-29 09:00:52 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Herr Siering",
      "screen_name" : "HerrBertling",
      "indices" : [ 15, 28 ],
      "id_str" : "14115883",
      "id" : 14115883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461066635680694272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461066866635833344",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon @HerrBertling Wir mussten 5 Kilometer durch den Schnee laufen, ohne Schuhe, um zum n\u00E4chsten DSL-Anschluss zu kommen.",
  "id" : 461066866635833344,
  "in_reply_to_status_id" : 461066635680694272,
  "created_at" : "2014-04-29 08:58:01 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SwiftOnSecurity",
      "screen_name" : "SwiftOnSecurity",
      "indices" : [ 3, 19 ],
      "id_str" : "2436389418",
      "id" : 2436389418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461066702110072832",
  "text" : "RT @SwiftOnSecurity: Based on how humanity has handled Windows XP EOL, I'd say the climate is pretty much screwed.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "460749603042631680",
    "text" : "Based on how humanity has handled Windows XP EOL, I'd say the climate is pretty much screwed.",
    "id" : 460749603042631680,
    "created_at" : "2014-04-28 11:57:20 +0000",
    "user" : {
      "name" : "SwiftOnSecurity",
      "screen_name" : "SwiftOnSecurity",
      "protected" : false,
      "id_str" : "2436389418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932760905363935232\/gRvK3QAX_normal.jpg",
      "id" : 2436389418,
      "verified" : false
    }
  },
  "id" : 461066702110072832,
  "created_at" : "2014-04-29 08:57:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461061438216613888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723470145, 8.6276025104 ]
  },
  "id_str" : "461066474086739968",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot du hast das mit den \uD83D\uDC34-M\u00E4dchen irgendwie falsch verstanden!",
  "id" : 461066474086739968,
  "in_reply_to_status_id" : 461061438216613888,
  "created_at" : "2014-04-29 08:56:28 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Herr Siering",
      "screen_name" : "HerrBertling",
      "indices" : [ 15, 28 ],
      "id_str" : "14115883",
      "id" : 14115883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461065784186646528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172331099, 8.6276207321 ]
  },
  "id_str" : "461066333669838848",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon @HerrBertling damals gab es noch gar keine Shorts! Wir mussten ewig auf die n\u00E4chste 1h Folge warten!",
  "id" : 461066333669838848,
  "in_reply_to_status_id" : 461065784186646528,
  "created_at" : "2014-04-29 08:55:54 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Herr Siering",
      "screen_name" : "HerrBertling",
      "indices" : [ 15, 28 ],
      "id_str" : "14115883",
      "id" : 14115883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461064440767840256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461064840086556672",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon @HerrBertling \u201CIch hab 99PI schon vor der ersten Funding-Runde geh\u00F6rt\u201D :p",
  "id" : 461064840086556672,
  "in_reply_to_status_id" : 461064440767840256,
  "created_at" : "2014-04-29 08:49:58 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461064155324104704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461064322983415808",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u201Chelp, we\u2019re fucked, save us with your magic somehow!\u201D, never gets old. Oh wait, it already did.",
  "id" : 461064322983415808,
  "in_reply_to_status_id" : 461064155324104704,
  "created_at" : "2014-04-29 08:47:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Herr Siering",
      "screen_name" : "HerrBertling",
      "indices" : [ 15, 28 ],
      "id_str" : "14115883",
      "id" : 14115883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461063898725363712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461064140547981312",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon @HerrBertling Danke, die Folge kenn ich schon, bin gro\u00DFer 99PI Fan :)",
  "id" : 461064140547981312,
  "in_reply_to_status_id" : 461063898725363712,
  "created_at" : "2014-04-29 08:47:11 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461063543349989377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461063981541916672",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch yeah, saw those too but couldn\u2019t find a problem. Sent out the invoice some days ago, let\u2019s keep fingers crossed.",
  "id" : 461063981541916672,
  "in_reply_to_status_id" : 461063543349989377,
  "created_at" : "2014-04-29 08:46:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461063451394072576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461063749512990721",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer (as still usual the bioinformaticians were contacted _after_ sequencing\u2026)",
  "id" : 461063749512990721,
  "in_reply_to_status_id" : 461063451394072576,
  "created_at" : "2014-04-29 08:45:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461063451394072576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461063717128777729",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, in the end the whole project was shelved due to the sequencing quality.",
  "id" : 461063717128777729,
  "in_reply_to_status_id" : 461063451394072576,
  "created_at" : "2014-04-29 08:45:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/g88LXCrQ7o",
      "expanded_url" : "http:\/\/dynamicecology.wordpress.com\/2014\/04\/28\/stereotype-threat-a-summary-of-the-problem\/",
      "display_url" : "dynamicecology.wordpress.com\/2014\/04\/28\/ste\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461061899325816832",
  "text" : "Stereotype threat: A summary of the\u00A0problem http:\/\/t.co\/g88LXCrQ7o",
  "id" : 461061899325816832,
  "created_at" : "2014-04-29 08:38:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Siering",
      "screen_name" : "HerrBertling",
      "indices" : [ 87, 100 ],
      "id_str" : "14115883",
      "id" : 14115883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/D3b2OA46bn",
      "expanded_url" : "http:\/\/futureinterface.tumblr.com\/",
      "display_url" : "futureinterface.tumblr.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461061420332109824",
  "text" : "Human-computer interaction, as imagined by science fiction. http:\/\/t.co\/D3b2OA46bn \/HT @HerrBertling",
  "id" : 461061420332109824,
  "created_at" : "2014-04-29 08:36:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461059891407622144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461060905246392320",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon thx!",
  "id" : 461060905246392320,
  "in_reply_to_status_id" : 461059891407622144,
  "created_at" : "2014-04-29 08:34:20 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461058628297187328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723750914, 8.6274249572 ]
  },
  "id_str" : "461059289881526272",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon (BTW magst du das GT-8 mal ausmachen, sieht so aus als w\u00E4re es noch an, auf der R\u00FCckseite ist ein Knopf :))",
  "id" : 461059289881526272,
  "in_reply_to_status_id" : 461058628297187328,
  "created_at" : "2014-04-29 08:27:55 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461058628297187328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723478679, 8.627590465 ]
  },
  "id_str" : "461059076789895168",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Katerfr\u00FChst\u00FCck?",
  "id" : 461059076789895168,
  "in_reply_to_status_id" : 461058628297187328,
  "created_at" : "2014-04-29 08:27:04 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461057474939092993",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461058020722475009",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon passed out rockstar? :p",
  "id" : 461058020722475009,
  "in_reply_to_status_id" : 461057474939092993,
  "created_at" : "2014-04-29 08:22:52 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461054800424353792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461056893369458688",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u201EWie Handschuhe f\u00FCr die F\u00FC\u00DFe. Damit ich Menschen mit meinen Zehen erw\u00FCrgen kann ohne Beweise zu hinterlassen.\u201D",
  "id" : 461056893369458688,
  "in_reply_to_status_id" : 461054800424353792,
  "created_at" : "2014-04-29 08:18:24 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "461055629336268800",
  "text" : "At least there\u2019s no data in the publication that Hauser did with Chomsky &amp; Lewontin, so we don\u2019t have to check for data fabrication\u2026",
  "id" : 461055629336268800,
  "created_at" : "2014-04-29 08:13:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarcastic_f",
      "screen_name" : "sarcastic_f",
      "indices" : [ 3, 15 ],
      "id_str" : "14096666",
      "id" : 14096666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/sHNIyUQOQ4",
      "expanded_url" : "http:\/\/journal.frontiersin.org\/Journal\/10.3389\/fpsyg.2014.00401\/abstract",
      "display_url" : "journal.frontiersin.org\/Journal\/10.338\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461050160152608768",
  "text" : "RT @sarcastic_f: The Mystery of Marc Hauser's Return: mystery of language evolution http:\/\/t.co\/sHNIyUQOQ4 Chomsky, Lewontin, 5 other guys:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/sHNIyUQOQ4",
        "expanded_url" : "http:\/\/journal.frontiersin.org\/Journal\/10.3389\/fpsyg.2014.00401\/abstract",
        "display_url" : "journal.frontiersin.org\/Journal\/10.338\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "461048811415011329",
    "text" : "The Mystery of Marc Hauser's Return: mystery of language evolution http:\/\/t.co\/sHNIyUQOQ4 Chomsky, Lewontin, 5 other guys: we know nothing!",
    "id" : 461048811415011329,
    "created_at" : "2014-04-29 07:46:17 +0000",
    "user" : {
      "name" : "sarcastic_f",
      "screen_name" : "sarcastic_f",
      "protected" : false,
      "id_str" : "14096666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620449671828258816\/PoJ6NM7n_normal.jpg",
      "id" : 14096666,
      "verified" : false
    }
  },
  "id" : 461050160152608768,
  "created_at" : "2014-04-29 07:51:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/461045089758752768\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/ATAKIQssPA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmX2EQDCMAATNRB.png",
      "id_str" : "461045089762947072",
      "id" : 461045089762947072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmX2EQDCMAATNRB.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/ATAKIQssPA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460929935385706497",
  "geo" : { },
  "id_str" : "461045089758752768",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Worst I have seen (with R1 looking completely normal). Funfact: Base 1-20 are the amplicon primer. :P http:\/\/t.co\/ATAKIQssPA",
  "id" : 461045089758752768,
  "in_reply_to_status_id" : 460929935385706497,
  "created_at" : "2014-04-29 07:31:29 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461021673592877056",
  "geo" : { },
  "id_str" : "461042603056975872",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch seems to work now, did you restart something?",
  "id" : 461042603056975872,
  "in_reply_to_status_id" : 461021673592877056,
  "created_at" : "2014-04-29 07:21:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/W23AsNc1V4",
      "expanded_url" : "http:\/\/www.slideshare.net\/rmorrill\/creating-a-keystroke-logger-in-unix-shell-scripting",
      "display_url" : "slideshare.net\/rmorrill\/creat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "460936418403954689",
  "geo" : { },
  "id_str" : "461042444407414784",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I still wonder about the backspace strokes, doesn't seem impossible http:\/\/t.co\/W23AsNc1V4",
  "id" : 461042444407414784,
  "in_reply_to_status_id" : 460936418403954689,
  "created_at" : "2014-04-29 07:20:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Diekmann",
      "screen_name" : "KaiDiekmann",
      "indices" : [ 42, 54 ],
      "id_str" : "834544453",
      "id" : 834544453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723041331, 8.6276068775 ]
  },
  "id_str" : "461037194984316929",
  "text" : "\u00ABWei\u00DFt du wer noch einen Bart hatte?!\u00BB \u2014 \u00AB@KaiDiekmann?\u00BB",
  "id" : 461037194984316929,
  "created_at" : "2014-04-29 07:00:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460757688083701760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "460758011414585344",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer caffeine-dependent would be rad. Or using frequency of backspace to determine fitness-lvl.",
  "id" : 460758011414585344,
  "in_reply_to_status_id" : 460757688083701760,
  "created_at" : "2014-04-28 12:30:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460757494646595585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "460757722053758976",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer dito, plus mv.",
  "id" : 460757722053758976,
  "in_reply_to_status_id" : 460757494646595585,
  "created_at" : "2014-04-28 12:29:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460756651734089728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342467, 8.62761305 ]
  },
  "id_str" : "460756906626527232",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer alias rm=\u2018rm -i\u2019 ;)",
  "id" : 460756906626527232,
  "in_reply_to_status_id" : 460756651734089728,
  "created_at" : "2014-04-28 12:26:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1163221805, 8.6489307894 ]
  },
  "id_str" : "460703860261408768",
  "text" : "And of course ssh isn\u2019t an option as the people here lack network ports and thus pulled the cable of their \u2018server\u2019\u2026",
  "id" : 460703860261408768,
  "created_at" : "2014-04-28 08:55:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1163220249, 8.6489193317 ]
  },
  "id_str" : "460702422332362752",
  "text" : "Software so badly written that I rather go to the campus at the other end of town than trying to install it once again\u2026",
  "id" : 460702422332362752,
  "created_at" : "2014-04-28 08:49:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1162597285, 8.6491571412 ]
  },
  "id_str" : "460685391528722432",
  "text" : "30 minutes to get back into the stuff I did a year ago. I\u2019ll take that as a sign that my documentation wasn\u2019t too bad.",
  "id" : 460685391528722432,
  "created_at" : "2014-04-28 07:42:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 27, 40 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/TXMrmU2ZpI",
      "expanded_url" : "http:\/\/karissamck.com\/blog\/2014\/04\/26\/why-you-shouldnt-say-its-easy-when-teaching\/",
      "display_url" : "karissamck.com\/blog\/2014\/04\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "460663469793353728",
  "text" : "\u2018That\u2019s really trivial\u2019 RT @PhilippBayer: Why You Shouldn\u2019t Say \u2018It\u2019s Easy\u2019 When Teaching http:\/\/t.co\/TXMrmU2ZpI",
  "id" : 460663469793353728,
  "created_at" : "2014-04-28 06:15:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460556565716561920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096447161, 8.28317835 ]
  },
  "id_str" : "460556715239669760",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 beating lvl1 crashed the twitter-client on my phone though :D",
  "id" : 460556715239669760,
  "in_reply_to_status_id" : 460556565716561920,
  "created_at" : "2014-04-27 23:10:52 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 3, 12 ],
      "id_str" : "14094265",
      "id" : 14094265
    }, {
      "name" : "Ludum Dare",
      "screen_name" : "ludumdare",
      "indices" : [ 37, 47 ],
      "id_str" : "16150760",
      "id" : 16150760
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ld48",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/onb8Ppqxlu",
      "expanded_url" : "http:\/\/www.ludumdare.com\/compo\/ludum-dare-29\/?action=preview&uid=12061",
      "display_url" : "ludumdare.com\/compo\/ludum-da\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "460555883312054272",
  "text" : "RT @snooze82: I submitted my (first) @ludumdare entry - Dr. Brainwire \\o\/ play and rate it here: http:\/\/t.co\/onb8Ppqxlu #ld48",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ludum Dare",
        "screen_name" : "ludumdare",
        "indices" : [ 23, 33 ],
        "id_str" : "16150760",
        "id" : 16150760
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ld48",
        "indices" : [ 106, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/onb8Ppqxlu",
        "expanded_url" : "http:\/\/www.ludumdare.com\/compo\/ludum-dare-29\/?action=preview&uid=12061",
        "display_url" : "ludumdare.com\/compo\/ludum-da\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "460554800648974337",
    "text" : "I submitted my (first) @ludumdare entry - Dr. Brainwire \\o\/ play and rate it here: http:\/\/t.co\/onb8Ppqxlu #ld48",
    "id" : 460554800648974337,
    "created_at" : "2014-04-27 23:03:15 +0000",
    "user" : {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "protected" : false,
      "id_str" : "14094265",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731789117483327488\/rs5L1Qbu_normal.jpg",
      "id" : 14094265,
      "verified" : false
    }
  },
  "id" : 460555883312054272,
  "created_at" : "2014-04-27 23:07:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460554800648974337",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096710439, 8.2830232704 ]
  },
  "id_str" : "460555427202093056",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 nice, well done! :)",
  "id" : 460555427202093056,
  "in_reply_to_status_id" : 460554800648974337,
  "created_at" : "2014-04-27 23:05:45 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/elZpr43cMB",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2014\/04\/speed-reading-apps-may-kill-comprehension\/",
      "display_url" : "arstechnica.com\/science\/2014\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967118, 8.283025442 ]
  },
  "id_str" : "460536886801334272",
  "text" : "I\u2019m also not too surprised: Speed reading apps may kill comprehension http:\/\/t.co\/elZpr43cMB",
  "id" : 460536886801334272,
  "created_at" : "2014-04-27 21:52:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 3, 15 ],
      "id_str" : "13766492",
      "id" : 13766492
    }, {
      "name" : "Leo Mirani",
      "screen_name" : "leomirani",
      "indices" : [ 101, 111 ],
      "id_str" : "1917024330",
      "id" : 1917024330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/o28eaWy8dz",
      "expanded_url" : "http:\/\/qz.com\/202187\/ubers-usage-maps-are-a-handy-tool-for-finding-the-worlds-rich-young-people\/",
      "display_url" : "qz.com\/202187\/ubers-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "460505423775535104",
  "text" : "RT @AkshatRathi: Uber\u2019s usage maps are a handy tool for finding the world\u2019s rich, young people... by @leomirani http:\/\/t.co\/o28eaWy8dz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Leo Mirani",
        "screen_name" : "leomirani",
        "indices" : [ 84, 94 ],
        "id_str" : "1917024330",
        "id" : 1917024330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/o28eaWy8dz",
        "expanded_url" : "http:\/\/qz.com\/202187\/ubers-usage-maps-are-a-handy-tool-for-finding-the-worlds-rich-young-people\/",
        "display_url" : "qz.com\/202187\/ubers-u\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "460501467204694016",
    "text" : "Uber\u2019s usage maps are a handy tool for finding the world\u2019s rich, young people... by @leomirani http:\/\/t.co\/o28eaWy8dz",
    "id" : 460501467204694016,
    "created_at" : "2014-04-27 19:31:20 +0000",
    "user" : {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "protected" : false,
      "id_str" : "13766492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/867091696508653568\/s5mhR4ru_normal.jpg",
      "id" : 13766492,
      "verified" : true
    }
  },
  "id" : 460505423775535104,
  "created_at" : "2014-04-27 19:47:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/ZibrNcXvgf",
      "expanded_url" : "http:\/\/i.imgur.com\/7lmctIZ.gif",
      "display_url" : "i.imgur.com\/7lmctIZ.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967118, 8.283025442 ]
  },
  "id_str" : "460496002626363392",
  "text" : "If I can\u2019t perform any meaningful calculations I might as well have some fun instead http:\/\/t.co\/ZibrNcXvgf",
  "id" : 460496002626363392,
  "created_at" : "2014-04-27 19:09:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096785522, 8.28303495 ]
  },
  "id_str" : "460492370623352832",
  "text" : "Meh, looks like I might have killed the cluster and all my jobs somehow\u2026",
  "id" : 460492370623352832,
  "created_at" : "2014-04-27 18:55:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096677663, 8.2829357777 ]
  },
  "id_str" : "460471414513229825",
  "text" : "\u00ABIch ziehe mich jetzt aus.\u00BB \u2014 \u00ABIch lese jetzt was \u00FCber die Klimaver\u00E4nderung durch Aerosol-Ausbringung im Europ\u00E4ischen Himmel.\u00BB",
  "id" : 460471414513229825,
  "created_at" : "2014-04-27 17:31:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holger Klang",
      "screen_name" : "HolgerKlang",
      "indices" : [ 0, 12 ],
      "id_str" : "48991385",
      "id" : 48991385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460428576677171200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0993491108, 8.6213884927 ]
  },
  "id_str" : "460436777854320640",
  "in_reply_to_user_id" : 48991385,
  "text" : "@HolgerKlang Blasphemie, die sind ganz gro\u00DFartig. :)",
  "id" : 460436777854320640,
  "in_reply_to_status_id" : 460428576677171200,
  "created_at" : "2014-04-27 15:14:17 +0000",
  "in_reply_to_screen_name" : "HolgerKlang",
  "in_reply_to_user_id_str" : "48991385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460409509564121088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.099442583, 8.6213549068 ]
  },
  "id_str" : "460409769095069696",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich wie gesagt: du kannst dir das Ding auch gern long-Term ausleihen und die anderen Gl\u00E4ser noch mitnehmen.",
  "id" : 460409769095069696,
  "in_reply_to_status_id" : 460409509564121088,
  "created_at" : "2014-04-27 13:26:57 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0995351478, 8.6214868119 ]
  },
  "id_str" : "460407938717614080",
  "text" : "\u00ABUnd dann, B\u00C4M, ist der Sack mit den Austernpilzen \u00FCber Nacht explodiert und der ganze Keller war wei\u00DF.\u00BB",
  "id" : 460407938717614080,
  "created_at" : "2014-04-27 13:19:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460405963602673664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0994382115, 8.6213366006 ]
  },
  "id_str" : "460406592002064384",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ich hatte gerade 30mm\/1.4 in der Hand und neide ein bisschen. :3",
  "id" : 460406592002064384,
  "in_reply_to_status_id" : 460405963602673664,
  "created_at" : "2014-04-27 13:14:20 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0994266843, 8.621343393 ]
  },
  "id_str" : "460401989923647488",
  "text" : "Pommes und Kuchen zum Fr\u00FChst\u00FCck. Ich w\u00FCnschte mein ganzes Leben w\u00E4re ein Kindergeburtstag.",
  "id" : 460401989923647488,
  "created_at" : "2014-04-27 12:56:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0994611288, 8.6214049061 ]
  },
  "id_str" : "460391269379092480",
  "text" : "\u00ABDu hast nur gesagt das Geschenk soll keine Sirene haben. Von \u2018kein Wassertank am Feuerwehrauto\u2019 war nie die Rede!\u00BB",
  "id" : 460391269379092480,
  "created_at" : "2014-04-27 12:13:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0992632117, 8.6114110657 ]
  },
  "id_str" : "460387104573648896",
  "text" : "Criminal Mastermind in der S-Bahn: \u00ABIn Hamburg haben sie mich erwischt mit den Drogen, aber jetzt verticke ich viel vorsichtiger!\u00BB",
  "id" : 460387104573648896,
  "created_at" : "2014-04-27 11:56:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uBiome",
      "screen_name" : "uBiome",
      "indices" : [ 62, 69 ],
      "id_str" : "852039852",
      "id" : 852039852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096785522, 8.28303495 ]
  },
  "id_str" : "460372831050932225",
  "text" : "Yay, my mouth, GI &amp; genital metagenome samples made it to @uBiome. \\o\/",
  "id" : 460372831050932225,
  "created_at" : "2014-04-27 11:00:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460369830462619649",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096450303, 8.2830189781 ]
  },
  "id_str" : "460370841403129856",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Hey, leicht nach Nokia-Art die Tastensperre. ;)",
  "id" : 460370841403129856,
  "in_reply_to_status_id" : 460369830462619649,
  "created_at" : "2014-04-27 10:52:16 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460364121985531904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096467538, 8.2830494369 ]
  },
  "id_str" : "460364534289821696",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich uff, ich hatte das Ding so lang nicht in der Hand, aber iirc hat der Power-Switch 3 Stellungen: on,on+Rad gesperrt, off?",
  "id" : 460364534289821696,
  "in_reply_to_status_id" : 460364121985531904,
  "created_at" : "2014-04-27 10:27:12 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460306033332981760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096735911, 8.2829935327 ]
  },
  "id_str" : "460360642386755585",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich das oben \u00E4ndert die Belichtungszeit, das auf der R\u00FCckseite die Blende (oder vice versa)",
  "id" : 460360642386755585,
  "in_reply_to_status_id" : 460306033332981760,
  "created_at" : "2014-04-27 10:11:44 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460187869160955904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096748732, 8.2830050423 ]
  },
  "id_str" : "460188177614266369",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich das habe ich nie behauptet. Das habe ich bislang nur in einer normalen Fritteuse gemacht (das geht &amp; schmeckt super).",
  "id" : 460188177614266369,
  "in_reply_to_status_id" : 460187869160955904,
  "created_at" : "2014-04-26 22:46:26 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460170816018456576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096785522, 8.28303495 ]
  },
  "id_str" : "460171430538534912",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot Okay, dann werde ich euch ausnahmsweise mal bekleidet \u2018bekochen\u2019.",
  "id" : 460171430538534912,
  "in_reply_to_status_id" : 460170816018456576,
  "created_at" : "2014-04-26 21:39:53 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460162794772758529",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096785522, 8.28303495 ]
  },
  "id_str" : "460166782436007936",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot wir k\u00F6nnen die Fritteuse auch voll fett beladen ;)",
  "id" : 460166782436007936,
  "in_reply_to_status_id" : 460162794772758529,
  "created_at" : "2014-04-26 21:21:25 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096785522, 8.28303495 ]
  },
  "id_str" : "460163026940080128",
  "text" : "\u00ABVortex me vigorously over night.\u00BB",
  "id" : 460163026940080128,
  "created_at" : "2014-04-26 21:06:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/TPty8OtaZj",
      "expanded_url" : "http:\/\/i.imgur.com\/qvM6Xho.gif",
      "display_url" : "i.imgur.com\/qvM6Xho.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "460161682565001218",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096785522, 8.28303495 ]
  },
  "id_str" : "460161824638664704",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich Wie ich immer schaue wenn ich versuche klarzumachen das ich auch noch mal von der Banane beissen mag http:\/\/t.co\/TPty8OtaZj",
  "id" : 460161824638664704,
  "in_reply_to_status_id" : 460161682565001218,
  "created_at" : "2014-04-26 21:01:43 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460161248009936896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096785522, 8.28303495 ]
  },
  "id_str" : "460161357447712771",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich die Low-Fat-Fritteuse und deine Definition von \u2018teilen\u2019 ;)",
  "id" : 460161357447712771,
  "in_reply_to_status_id" : 460161248009936896,
  "created_at" : "2014-04-26 20:59:51 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460158439935967232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00954789, 8.2828634533 ]
  },
  "id_str" : "460158977217937409",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot Ich weiss nicht ob mit \u2018ganz unten\u2019 die Stimmlage beim Growling gemeint war :P",
  "id" : 460158977217937409,
  "in_reply_to_status_id" : 460158439935967232,
  "created_at" : "2014-04-26 20:50:24 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460157964436111360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00954789, 8.2828634533 ]
  },
  "id_str" : "460158036192292864",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot mittlerweile rausgefunden wo das ist? ;)",
  "id" : 460158036192292864,
  "in_reply_to_status_id" : 460157964436111360,
  "created_at" : "2014-04-26 20:46:39 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460147063289020416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095955183, 8.2829924521 ]
  },
  "id_str" : "460147408681574400",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I know your current state suggests the latter, but I thought about the former ;)",
  "id" : 460147408681574400,
  "in_reply_to_status_id" : 460147063289020416,
  "created_at" : "2014-04-26 20:04:26 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460142681449304064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096028114, 8.2829127924 ]
  },
  "id_str" : "460143608172396544",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC \u2018I\u2019m a multidimensional person. But here\u2019s a PCA that might help you.\u2018",
  "id" : 460143608172396544,
  "in_reply_to_status_id" : 460142681449304064,
  "created_at" : "2014-04-26 19:49:19 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460141598836551680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009571236, 8.282930862 ]
  },
  "id_str" : "460141820887183360",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC if you keep adding to your job title you will need a bigger business card!",
  "id" : 460141820887183360,
  "in_reply_to_status_id" : 460141598836551680,
  "created_at" : "2014-04-26 19:42:13 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 0, 7 ],
      "id_str" : "34880281",
      "id" : 34880281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460139713190723584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009571236, 8.282930862 ]
  },
  "id_str" : "460141044420837377",
  "in_reply_to_user_id" : 34880281,
  "text" : "@otacke puh, noch mal Gl\u00FCck gehabt ;)",
  "id" : 460141044420837377,
  "in_reply_to_status_id" : 460139713190723584,
  "created_at" : "2014-04-26 19:39:08 +0000",
  "in_reply_to_screen_name" : "otacke",
  "in_reply_to_user_id_str" : "34880281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 0, 7 ],
      "id_str" : "34880281",
      "id" : 34880281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460136463569805312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095334343, 8.2829822914 ]
  },
  "id_str" : "460138294500945920",
  "in_reply_to_user_id" : 34880281,
  "text" : "@otacke der Song ist ganz ok, aber das Gesamtalbum hat mich nicht \u00FCberzeugt.",
  "id" : 460138294500945920,
  "in_reply_to_status_id" : 460136463569805312,
  "created_at" : "2014-04-26 19:28:13 +0000",
  "in_reply_to_screen_name" : "otacke",
  "in_reply_to_user_id_str" : "34880281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/PzRRWY53mV",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=E0BhQm27RA4",
      "display_url" : "youtube.com\/watch?v=E0BhQm\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095713967, 8.28294562 ]
  },
  "id_str" : "460127518016950272",
  "text" : "Now I\u2019m even more excited to go to Iceland this summer. http:\/\/t.co\/PzRRWY53mV",
  "id" : 460127518016950272,
  "created_at" : "2014-04-26 18:45:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/ebL4jhT6P1",
      "expanded_url" : "http:\/\/i.imgur.com\/zIZVLYX.jpg",
      "display_url" : "i.imgur.com\/zIZVLYX.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095713967, 8.28294562 ]
  },
  "id_str" : "460126893283745792",
  "text" : "camouflage done right http:\/\/t.co\/ebL4jhT6P1",
  "id" : 460126893283745792,
  "created_at" : "2014-04-26 18:42:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/h25zwwt5vH",
      "expanded_url" : "http:\/\/i3.kym-cdn.com\/photos\/images\/newsfeed\/000\/412\/568\/b7b.jpg",
      "display_url" : "i3.kym-cdn.com\/photos\/images\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "460125564041703424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095713967, 8.28294562 ]
  },
  "id_str" : "460125916384198656",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot given your age you could actually\u2026 http:\/\/t.co\/h25zwwt5vH",
  "id" : 460125916384198656,
  "in_reply_to_status_id" : 460125564041703424,
  "created_at" : "2014-04-26 18:39:01 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/NQta2pmS37",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3339",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095713967, 8.28294562 ]
  },
  "id_str" : "460125500649000961",
  "text" : "the love hormone http:\/\/t.co\/NQta2pmS37",
  "id" : 460125500649000961,
  "created_at" : "2014-04-26 18:37:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095713967, 8.28294562 ]
  },
  "id_str" : "460123874425061376",
  "text" : "\u00ABIch habe die Kekse die man aus diesem Meme kennt mitgebracht. Ich dachte das w\u00E4re genau das richtige f\u00FCr dich.\u00BB",
  "id" : 460123874425061376,
  "created_at" : "2014-04-26 18:30:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460121523651891200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095713967, 8.28294562 ]
  },
  "id_str" : "460123561005699073",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC if you would perform that job in situ you could also get the cat sitting one kickstarted at the same time ;)",
  "id" : 460123561005699073,
  "in_reply_to_status_id" : 460121523651891200,
  "created_at" : "2014-04-26 18:29:40 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460118140308185090",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009599458, 8.2829623446 ]
  },
  "id_str" : "460119146286837760",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot dazu passt shouting einfach besser!",
  "id" : 460119146286837760,
  "in_reply_to_status_id" : 460118140308185090,
  "created_at" : "2014-04-26 18:12:07 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 0, 7 ],
      "id_str" : "34880281",
      "id" : 34880281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460115088058626048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009599458, 8.2829623446 ]
  },
  "id_str" : "460117807032971264",
  "in_reply_to_user_id" : 34880281,
  "text" : "@otacke ich hab es versucht damals, hat nicht geklappt. ;)",
  "id" : 460117807032971264,
  "in_reply_to_status_id" : 460115088058626048,
  "created_at" : "2014-04-26 18:06:48 +0000",
  "in_reply_to_screen_name" : "otacke",
  "in_reply_to_user_id_str" : "34880281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460117386767908864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095515652, 8.2829119175 ]
  },
  "id_str" : "460117715110617089",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich Tee gab es heute schon und f\u00FCr ersteres: challenge accepted.",
  "id" : 460117715110617089,
  "in_reply_to_status_id" : 460117386767908864,
  "created_at" : "2014-04-26 18:06:26 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 75, 84 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460116202183213057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095865483, 8.282699588 ]
  },
  "id_str" : "460116846084378624",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot &amp;wenn du das n\u00E4chste mal einfach mitmachst? Ich denke ich trete @JP_Stich nicht zu nah wenn ich sage das wir noch Gesang brauchen. ;)",
  "id" : 460116846084378624,
  "in_reply_to_status_id" : 460116202183213057,
  "created_at" : "2014-04-26 18:02:59 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460106399314628608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9990985217, 8.3047172427 ]
  },
  "id_str" : "460107946664685568",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich hat mir in der Glas\/Body-Kombination auch \u00FCber viele Jahre gute Dienste auf Konzerten erwiesen. Zur\u00FCckbringen eilt auch nicht :)",
  "id" : 460107946664685568,
  "in_reply_to_status_id" : 460106399314628608,
  "created_at" : "2014-04-26 17:27:37 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/JcllkUQFkP",
      "expanded_url" : "http:\/\/upload.wikimedia.org\/wikipedia\/commons\/thumb\/3\/30\/Don_Wayne_Reno_playing_the_banjo_with_fingerpicks.jpg\/1024px-Don_Wayne_Reno_playing_the_banjo_with_fingerpicks.jpg",
      "display_url" : "upload.wikimedia.org\/wikipedia\/comm\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "460105398960537600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9965079269, 8.3000715729 ]
  },
  "id_str" : "460106565899812864",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich die Hilfsmittel die ich anerkenne sehen aber so aus. http:\/\/t.co\/JcllkUQFkP",
  "id" : 460106565899812864,
  "in_reply_to_status_id" : 460105398960537600,
  "created_at" : "2014-04-26 17:22:08 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 12, 21 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460103915774939137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9961616705, 8.291129088 ]
  },
  "id_str" : "460105028167274496",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach @JP_Stich wenn du mal wieder in der Gegend bist (oder ich vice versa) m\u00FCssen wir wieder einen hosenlosen Dosenbier-Abend machen.",
  "id" : 460105028167274496,
  "in_reply_to_status_id" : 460103915774939137,
  "created_at" : "2014-04-26 17:16:01 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460103414043910144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9964978266, 8.2818967616 ]
  },
  "id_str" : "460104733391593472",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC that\u2019s so sweet &lt;3 though I get the feeling that you\u2019re just trying out alternative career paths ;)",
  "id" : 460104733391593472,
  "in_reply_to_status_id" : 460103414043910144,
  "created_at" : "2014-04-26 17:14:51 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460102961608527874",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9964978266, 8.2818967616 ]
  },
  "id_str" : "460104537551155200",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Plecs sind doch nur f\u00FCr Leute die nicht hart genug fingern k\u00F6nnen!",
  "id" : 460104537551155200,
  "in_reply_to_status_id" : 460102961608527874,
  "created_at" : "2014-04-26 17:14:04 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 57, 68 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460102564584124417",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0017565908, 8.2851133961 ]
  },
  "id_str" : "460103316639608833",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich dito, dann zu Samsas Traum und von da an kennt @herrurbach die Entwicklung von gemeinsamen Sofa-Parties ;)",
  "id" : 460103316639608833,
  "in_reply_to_status_id" : 460102564584124417,
  "created_at" : "2014-04-26 17:09:13 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 9, 18 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 19, 26 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460102666430205952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0022295816, 8.2847758569 ]
  },
  "id_str" : "460102966964666371",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju @JP_Stich @Bediko \u2018besser\u2019 &amp; \u2018power metal lyrics\u2019. Da w\u00FCrde ich ja gern dein Kriterium kennen. ;)",
  "id" : 460102966964666371,
  "in_reply_to_status_id" : 460102666430205952,
  "created_at" : "2014-04-26 17:07:50 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460102389635493889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0044064457, 8.2837692741 ]
  },
  "id_str" : "460102604220268544",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich du nennst Pantera weinerlichen Indie? :p",
  "id" : 460102604220268544,
  "in_reply_to_status_id" : 460102389635493889,
  "created_at" : "2014-04-26 17:06:23 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 9, 18 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 19, 26 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460102136303742976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0044064457, 8.2837692741 ]
  },
  "id_str" : "460102434422267905",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju @JP_Stich @Bediko 101 fun use cases for Markov chains.",
  "id" : 460102434422267905,
  "in_reply_to_status_id" : 460102136303742976,
  "created_at" : "2014-04-26 17:05:43 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460101845135130625",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0050690426, 8.2837991496 ]
  },
  "id_str" : "460102199960690688",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC first I searched my cables to play electric guitar, then the A\/C adapter for my camera. Both have designated desk drawers\u2026",
  "id" : 460102199960690688,
  "in_reply_to_status_id" : 460101845135130625,
  "created_at" : "2014-04-26 17:04:47 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 9, 18 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 19, 26 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460101393555390464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0052005891, 8.2821216434 ]
  },
  "id_str" : "460101775866228736",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju @JP_Stich @Bediko die by steel for the king.",
  "id" : 460101775866228736,
  "in_reply_to_status_id" : 460101393555390464,
  "created_at" : "2014-04-26 17:03:06 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460100759418568704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0081635919, 8.2794510853 ]
  },
  "id_str" : "460101036922122240",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich h\u00E4ttest du doch was gesagt, dann h\u00E4tte ich dir gleich nackt Tee gemacht!",
  "id" : 460101036922122240,
  "in_reply_to_status_id" : 460100759418568704,
  "created_at" : "2014-04-26 17:00:10 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Darwin",
      "screen_name" : "cdarwin",
      "indices" : [ 3, 11 ],
      "id_str" : "19863141",
      "id" : 19863141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460096970548580352",
  "text" : "RT @cdarwin: During our absence, things have been going on pretty quietly, with the exception of a few revolutions",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.thebeaglevoyage.com\/\" rel=\"nofollow\"\u003EHMSBeagle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "460083640161300480",
    "text" : "During our absence, things have been going on pretty quietly, with the exception of a few revolutions",
    "id" : 460083640161300480,
    "created_at" : "2014-04-26 15:51:02 +0000",
    "user" : {
      "name" : "Charles Darwin",
      "screen_name" : "cdarwin",
      "protected" : false,
      "id_str" : "19863141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/75125076\/darwin_normal.jpg",
      "id" : 19863141,
      "verified" : false
    }
  },
  "id" : 460096970548580352,
  "created_at" : "2014-04-26 16:44:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095713967, 8.28294562 ]
  },
  "id_str" : "460094867864322048",
  "text" : "Heute 2x die Wohnung auf den Kopf gestellt um nach Dingen zu suchen. 2x nach 20 Minuten erinnert das sie jeweils einen festen Ort haben\u2026",
  "id" : 460094867864322048,
  "created_at" : "2014-04-26 16:35:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    }, {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 9, 16 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460085642266181632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096003191, 8.282909996 ]
  },
  "id_str" : "460092665779200000",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju @Bediko las!",
  "id" : 460092665779200000,
  "in_reply_to_status_id" : 460085642266181632,
  "created_at" : "2014-04-26 16:26:54 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    }, {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 9, 16 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460085642266181632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096296481, 8.2829486373 ]
  },
  "id_str" : "460092583600205824",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju @Bediko lass mutual masturbation und bin jetzt entt\u00E4uscht.",
  "id" : 460092583600205824,
  "in_reply_to_status_id" : 460085642266181632,
  "created_at" : "2014-04-26 16:26:34 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095935912, 8.282958189 ]
  },
  "id_str" : "460084300097257472",
  "text" : "\u00ABUnd dann kam \u2018A Night at the Opera\u2019 raus. Und ich hab mich nie getraut zu sagen was f\u00FCr Mist das ist.\u00BB",
  "id" : 460084300097257472,
  "created_at" : "2014-04-26 15:53:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460083661938098176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096185797, 8.2828992404 ]
  },
  "id_str" : "460083959649828864",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju me too, deshalb hab ich mich sehr gefreut.",
  "id" : 460083959649828864,
  "in_reply_to_status_id" : 460083661938098176,
  "created_at" : "2014-04-26 15:52:18 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095713967, 8.28294562 ]
  },
  "id_str" : "460082355794116608",
  "text" : "\u00ABSo mit 14 bin ich ja damals in die deutsche Metalszene abgerutscht. Bei uns auf dem Dorf musste man Blind Guardian _und_ Iced Earth h\u00F6ren.\u00BB",
  "id" : 460082355794116608,
  "created_at" : "2014-04-26 15:45:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/yPdc20yA1e",
      "expanded_url" : "http:\/\/instagram.com\/p\/nQSSEtBwsb\/",
      "display_url" : "instagram.com\/p\/nQSSEtBwsb\/"
    } ]
  },
  "geo" : { },
  "id_str" : "460049857177481217",
  "text" : "they see me rollin' http:\/\/t.co\/yPdc20yA1e",
  "id" : 460049857177481217,
  "created_at" : "2014-04-26 13:36:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460047426112745474",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096101168, 8.2829772379 ]
  },
  "id_str" : "460048891128598529",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ich soll mir also mal was anziehen und Kaffee aufsetzen? ;)",
  "id" : 460048891128598529,
  "in_reply_to_status_id" : 460047426112745474,
  "created_at" : "2014-04-26 13:32:57 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/tpHid0q3Ha",
      "expanded_url" : "http:\/\/gowers.wordpress.com\/2014\/04\/24\/elsevier-journals-some-facts\/",
      "display_url" : "gowers.wordpress.com\/2014\/04\/24\/els\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095713967, 8.28294562 ]
  },
  "id_str" : "460042597755801601",
  "text" : "Well done: Elsevier journals \u2014 some\u00A0facts http:\/\/t.co\/tpHid0q3Ha",
  "id" : 460042597755801601,
  "created_at" : "2014-04-26 13:07:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460031623556509696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096129889, 8.2830396311 ]
  },
  "id_str" : "460031701096628226",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich kein Ding :)",
  "id" : 460031701096628226,
  "in_reply_to_status_id" : 460031623556509696,
  "created_at" : "2014-04-26 12:24:39 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristine Pommert",
      "screen_name" : "Kristine3108",
      "indices" : [ 3, 16 ],
      "id_str" : "36908048",
      "id" : 36908048
    }, {
      "name" : "The Conversation",
      "screen_name" : "ConversationUK",
      "indices" : [ 115, 130 ],
      "id_str" : "1241258612",
      "id" : 1241258612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/FaIJSUSq68",
      "expanded_url" : "http:\/\/theconversation.com\/europes-hidden-shame-romani-nazi-death-camps-barely-merit-signposts-25933",
      "display_url" : "theconversation.com\/europes-hidden\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "460030740504543232",
  "text" : "RT @Kristine3108: Europe's hidden shame: Romani Nazi death camps barely merit signposts http:\/\/t.co\/FaIJSUSq68 via @ConversationUK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Conversation",
        "screen_name" : "ConversationUK",
        "indices" : [ 97, 112 ],
        "id_str" : "1241258612",
        "id" : 1241258612
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/FaIJSUSq68",
        "expanded_url" : "http:\/\/theconversation.com\/europes-hidden-shame-romani-nazi-death-camps-barely-merit-signposts-25933",
        "display_url" : "theconversation.com\/europes-hidden\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "459593949452070912",
    "text" : "Europe's hidden shame: Romani Nazi death camps barely merit signposts http:\/\/t.co\/FaIJSUSq68 via @ConversationUK",
    "id" : 459593949452070912,
    "created_at" : "2014-04-25 07:25:11 +0000",
    "user" : {
      "name" : "Kristine Pommert",
      "screen_name" : "Kristine3108",
      "protected" : false,
      "id_str" : "36908048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514403869950877697\/gH-W32tI_normal.jpeg",
      "id" : 36908048,
      "verified" : false
    }
  },
  "id" : 460030740504543232,
  "created_at" : "2014-04-26 12:20:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 3, 17 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/Re9k0GQ6y7",
      "expanded_url" : "http:\/\/go.nature.com\/ZoVtSn",
      "display_url" : "go.nature.com\/ZoVtSn"
    } ]
  },
  "geo" : { },
  "id_str" : "460020988814848000",
  "text" : "RT @BioMickWatson: So many kinds of awesome: If only ... http:\/\/t.co\/Re9k0GQ6y7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/Re9k0GQ6y7",
        "expanded_url" : "http:\/\/go.nature.com\/ZoVtSn",
        "display_url" : "go.nature.com\/ZoVtSn"
      } ]
    },
    "geo" : { },
    "id_str" : "460015751596744704",
    "text" : "So many kinds of awesome: If only ... http:\/\/t.co\/Re9k0GQ6y7",
    "id" : 460015751596744704,
    "created_at" : "2014-04-26 11:21:16 +0000",
    "user" : {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "protected" : false,
      "id_str" : "228586748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870214569679093760\/YIZGIDTS_normal.jpg",
      "id" : 228586748,
      "verified" : false
    }
  },
  "id" : 460020988814848000,
  "created_at" : "2014-04-26 11:42:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459995191831982080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096651014, 8.2829190862 ]
  },
  "id_str" : "459995676148244482",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Marke: billig, St\u00E4rke: mittel. ;) ich hoffe einfach das ich es diesmal \u00FCberhaupt schaffe sie Saiten aufzuziehen ;)",
  "id" : 459995676148244482,
  "in_reply_to_status_id" : 459995191831982080,
  "created_at" : "2014-04-26 10:01:30 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459989374336499712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095862479, 8.2829404838 ]
  },
  "id_str" : "459991439456608256",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich der Banjo-Saiten verkauft! Fette Finger haben den Subsatz gel\u00F6scht m)",
  "id" : 459991439456608256,
  "in_reply_to_status_id" : 459989374336499712,
  "created_at" : "2014-04-26 09:44:40 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459989374336499712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096086771, 8.2829655039 ]
  },
  "id_str" : "459989935781847040",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich passt auch schon, habe die Schublade mit den Kabeln gefunden m) einkaufen: wenn du an einem Laden vorbeikommst nehme ich welche ;)",
  "id" : 459989935781847040,
  "in_reply_to_status_id" : 459989374336499712,
  "created_at" : "2014-04-26 09:38:41 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459946320623853568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009615635, 8.2830236653 ]
  },
  "id_str" : "459987724293144576",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich falls du noch Klinken-Kabel hast: gern mitbringen, ich finde zu wenige (aka eins)",
  "id" : 459987724293144576,
  "in_reply_to_status_id" : 459946320623853568,
  "created_at" : "2014-04-26 09:29:54 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/5UiGnFJCEk",
      "expanded_url" : "http:\/\/www.npr.org\/blogs\/pictureshow\/2014\/04\/24\/306437432\/tyler-hicks-tells-the-story-behind-his-pulitzer-winning-nairobi-mall-photos",
      "display_url" : "npr.org\/blogs\/pictures\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964012, 8.2830300863 ]
  },
  "id_str" : "459975031796551680",
  "text" : "Tyler Hicks Tells The Story Behind His Pulitzer-Winning Nairobi Mall Photos http:\/\/t.co\/5UiGnFJCEk",
  "id" : 459975031796551680,
  "created_at" : "2014-04-26 08:39:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/1pAUkSp8oE",
      "expanded_url" : "https:\/\/www.sciencenews.org\/article\/name-fungus",
      "display_url" : "sciencenews.org\/article\/name-f\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964012, 8.2830300863 ]
  },
  "id_str" : "459965292979183616",
  "text" : "What mycologists have to put up with: \u00ABThe name of the fungus\u00BB https:\/\/t.co\/1pAUkSp8oE",
  "id" : 459965292979183616,
  "created_at" : "2014-04-26 08:00:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459964084058718209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009522392, 8.2829249905 ]
  },
  "id_str" : "459964487249178624",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer then your grandfathers must have been rather young at the time. ;)",
  "id" : 459964487249178624,
  "in_reply_to_status_id" : 459964084058718209,
  "created_at" : "2014-04-26 07:57:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459895200748298240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096493261, 8.2829855662 ]
  },
  "id_str" : "459954805956702208",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer oh, I thought Anzac Day goes back to WW1?",
  "id" : 459954805956702208,
  "in_reply_to_status_id" : 459895200748298240,
  "created_at" : "2014-04-26 07:19:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459867399764705280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009740647, 8.2830627635 ]
  },
  "id_str" : "459947541367640064",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer still nice :)",
  "id" : 459947541367640064,
  "in_reply_to_status_id" : 459867399764705280,
  "created_at" : "2014-04-26 06:50:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459946320623853568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096725943, 8.2831286032 ]
  },
  "id_str" : "459947432869363712",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Zehnthofstrasse 36 in Kastel. Rechts von der 36 ist ein Durchgang in einen Hinterhof. In dem Durchgang ist eine T\u00FCr\/Klingel. Da :)",
  "id" : 459947432869363712,
  "in_reply_to_status_id" : 459946320623853568,
  "created_at" : "2014-04-26 06:49:48 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459827575507152896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096563116, 8.2830111239 ]
  },
  "id_str" : "459827836136984576",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj schade, wieder eine Ausrede verpufft. ;)",
  "id" : 459827836136984576,
  "in_reply_to_status_id" : 459827575507152896,
  "created_at" : "2014-04-25 22:54:33 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096918643, 8.2830636855 ]
  },
  "id_str" : "459827334246596608",
  "text" : "Immer mehr Piraten von Leseschw\u00E4che betroffen. Gemeint war mal \u2018wer macht hat recht\u2019, nicht \u2018Wehrmacht hat recht\u2019.",
  "id" : 459827334246596608,
  "created_at" : "2014-04-25 22:52:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gegengewalt",
      "screen_name" : "ekelias",
      "indices" : [ 0, 8 ],
      "id_str" : "15890805",
      "id" : 15890805
    }, {
      "name" : "J. B. Borbillo Kroketto-Dolm",
      "screen_name" : "FR31H31T",
      "indices" : [ 9, 18 ],
      "id_str" : "73747798",
      "id" : 73747798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459825983588401153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096918643, 8.2830636855 ]
  },
  "id_str" : "459826062483283968",
  "in_reply_to_user_id" : 15890805,
  "text" : "@ekelias @FR31H31T dirty minds think alike\u2026",
  "id" : 459826062483283968,
  "in_reply_to_status_id" : 459825983588401153,
  "created_at" : "2014-04-25 22:47:31 +0000",
  "in_reply_to_screen_name" : "ekelias",
  "in_reply_to_user_id_str" : "15890805",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "der LUSTIGE Wellensittich",
      "screen_name" : "FR31H31T",
      "indices" : [ 0, 9 ],
      "id_str" : "73747798",
      "id" : 73747798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459825647440113664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096859688, 8.2830446302 ]
  },
  "id_str" : "459825848120803330",
  "in_reply_to_user_id" : 73747798,
  "text" : "@FR31H31T ist das dein Weltraumaufzug in deiner Hosentasche oder freust du dich mich zu sehen?",
  "id" : 459825848120803330,
  "in_reply_to_status_id" : 459825647440113664,
  "created_at" : "2014-04-25 22:46:40 +0000",
  "in_reply_to_screen_name" : "FR31H31T",
  "in_reply_to_user_id_str" : "73747798",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 3, 11 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459820644407193600",
  "text" : "RT @heyaudy: To improve perception of reality, enable wifi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 29.6524097065, -82.3255318453 ]
    },
    "id_str" : "459820525410611201",
    "text" : "To improve perception of reality, enable wifi",
    "id" : 459820525410611201,
    "created_at" : "2014-04-25 22:25:30 +0000",
    "user" : {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "protected" : false,
      "id_str" : "14534523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923034147777474561\/zZvXWmSQ_normal.jpg",
      "id" : 14534523,
      "verified" : false
    }
  },
  "id" : 459820644407193600,
  "created_at" : "2014-04-25 22:25:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tina Saey",
      "screen_name" : "thsaey",
      "indices" : [ 3, 10 ],
      "id_str" : "19920464",
      "id" : 19920464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459796333822750721",
  "text" : "RT @thsaey: Watson, Crick and Wilkins won Nobel for DNA, but NEVER could have done it w\/out Rosalind Franklin. Nobel should consider posthu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "459789866507583488",
    "text" : "Watson, Crick and Wilkins won Nobel for DNA, but NEVER could have done it w\/out Rosalind Franklin. Nobel should consider posthumous award",
    "id" : 459789866507583488,
    "created_at" : "2014-04-25 20:23:41 +0000",
    "user" : {
      "name" : "Tina Saey",
      "screen_name" : "thsaey",
      "protected" : false,
      "id_str" : "19920464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000469664209\/e25bf5aa2a7d143beadd0f5d91d67d75_normal.jpeg",
      "id" : 19920464,
      "verified" : false
    }
  },
  "id" : 459796333822750721,
  "created_at" : "2014-04-25 20:49:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tina Saey",
      "screen_name" : "thsaey",
      "indices" : [ 3, 10 ],
      "id_str" : "19920464",
      "id" : 19920464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459796314541551616",
  "text" : "RT @thsaey: Don't forget Erwin Chargaff on this DNA Day. His discovery that C=G and A=T helped W&amp;C figure out helix structure.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "459789291195883520",
    "text" : "Don't forget Erwin Chargaff on this DNA Day. His discovery that C=G and A=T helped W&amp;C figure out helix structure.",
    "id" : 459789291195883520,
    "created_at" : "2014-04-25 20:21:24 +0000",
    "user" : {
      "name" : "Tina Saey",
      "screen_name" : "thsaey",
      "protected" : false,
      "id_str" : "19920464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000469664209\/e25bf5aa2a7d143beadd0f5d91d67d75_normal.jpeg",
      "id" : 19920464,
      "verified" : false
    }
  },
  "id" : 459796314541551616,
  "created_at" : "2014-04-25 20:49:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 3, 12 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459769763011760128",
  "text" : "RT @kbradnam: New ACGT post: Has every possible DNA-based initialism been used by the bioinformatics\/genomics community? http:\/\/t.co\/tpq14o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/tpq14oxj94",
        "expanded_url" : "http:\/\/buff.ly\/QFuzuF",
        "display_url" : "buff.ly\/QFuzuF"
      } ]
    },
    "geo" : { },
    "id_str" : "459721687748313088",
    "text" : "New ACGT post: Has every possible DNA-based initialism been used by the bioinformatics\/genomics community? http:\/\/t.co\/tpq14oxj94",
    "id" : 459721687748313088,
    "created_at" : "2014-04-25 15:52:46 +0000",
    "user" : {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "protected" : false,
      "id_str" : "17061155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583756306919489538\/D2fFCYq4_normal.jpg",
      "id" : 17061155,
      "verified" : false
    }
  },
  "id" : 459769763011760128,
  "created_at" : "2014-04-25 19:03:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/8lary5jZjX",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0094842",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964012, 8.2830300863 ]
  },
  "id_str" : "459764444357468160",
  "text" : "Your Morals Depend on Language http:\/\/t.co\/8lary5jZjX",
  "id" : 459764444357468160,
  "created_at" : "2014-04-25 18:42:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459757771907674112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.008088592, 8.2821719456 ]
  },
  "id_str" : "459758195981180928",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon freut mich. Da f\u00E4ngt der Tag ja auch gleich gut an: Reis and shine!",
  "id" : 459758195981180928,
  "in_reply_to_status_id" : 459757771907674112,
  "created_at" : "2014-04-25 18:17:50 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459755458677325824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0044353633, 8.3500661887 ]
  },
  "id_str" : "459756346146295808",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon Reis Again(st)",
  "id" : 459756346146295808,
  "in_reply_to_status_id" : 459755458677325824,
  "created_at" : "2014-04-25 18:10:29 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/ZoI6li7lD3",
      "expanded_url" : "http:\/\/rss.sciam.com\/~r\/all-blogs\/feed\/~3\/eE22wrPglIQ\/",
      "display_url" : "rss.sciam.com\/~r\/all-blogs\/f\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.043055, 8.460975 ]
  },
  "id_str" : "459754464036265984",
  "text" : "It\u2019s life, Charlie, but not as we know it \u2013 Charles Darwin and the search of early (Extraterrestrial) Life http:\/\/t.co\/ZoI6li7lD3",
  "id" : 459754464036265984,
  "created_at" : "2014-04-25 18:03:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/WFQ1HLPgCl",
      "expanded_url" : "http:\/\/www.texasobserver.org\/to-kill-or-not-to-kill\/",
      "display_url" : "texasobserver.org\/to-kill-or-not\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.067453, 8.489118 ]
  },
  "id_str" : "459753974955245568",
  "text" : "To Kill? Or Not To Kill? http:\/\/t.co\/WFQ1HLPgCl",
  "id" : 459753974955245568,
  "created_at" : "2014-04-25 18:01:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1521180055, 8.6621413092 ]
  },
  "id_str" : "459741227186126848",
  "text" : "\u00ABToday\u2019s DNA day, how will we celebrate?\u00BB \u2014 \u00ABDance the double helix.\u00BB \u2014 \u00ABWatch out that you\u2019re not accidentally doing a left-handed one!\u00BB",
  "id" : 459741227186126848,
  "created_at" : "2014-04-25 17:10:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 7, 14 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459729764555964416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723313309, 8.6276220478 ]
  },
  "id_str" : "459730548811124736",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @lsanoj and you were distracted by the lack of a beard. But I actually was taught driving by a rally driver.",
  "id" : 459730548811124736,
  "in_reply_to_status_id" : 459729764555964416,
  "created_at" : "2014-04-25 16:27:58 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 7, 14 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459728370100895744",
  "geo" : { },
  "id_str" : "459729557105704960",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @lsanoj fun fact: do you know how easy it is to fake a drivers license?",
  "id" : 459729557105704960,
  "in_reply_to_status_id" : 459728370100895744,
  "created_at" : "2014-04-25 16:24:02 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/YIs5WBhLhp",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=FQ-8xj8CUZw",
      "display_url" : "youtube.com\/watch?v=FQ-8xj\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "459725977699254272",
  "geo" : { },
  "id_str" : "459726481610911744",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Lobot https:\/\/t.co\/YIs5WBhLhp",
  "id" : 459726481610911744,
  "in_reply_to_status_id" : 459725977699254272,
  "created_at" : "2014-04-25 16:11:49 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Martini",
      "screen_name" : "rejectedbanana",
      "indices" : [ 3, 18 ],
      "id_str" : "48494794",
      "id" : 48494794
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rejectedbanana\/status\/459723684647690240\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/L9aqSkcoxa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmFEQTaCMAEdpfo.png",
      "id_str" : "459723683846565889",
      "id" : 459723683846565889,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmFEQTaCMAEdpfo.png",
      "sizes" : [ {
        "h" : 431,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 837
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 837
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 837
      } ],
      "display_url" : "pic.twitter.com\/L9aqSkcoxa"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/cbzOic24h1",
      "expanded_url" : "http:\/\/www.nashturley.org\/2012\/09\/27\/pinguin-poop-paper\/",
      "display_url" : "nashturley.org\/2012\/09\/27\/pin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459725884178837504",
  "text" : "RT @rejectedbanana: It wouldn't be World Penguin Day without the Penguin Projectile Poop Paper http:\/\/t.co\/cbzOic24h1 http:\/\/t.co\/L9aqSkcoxa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rejectedbanana\/status\/459723684647690240\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/L9aqSkcoxa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmFEQTaCMAEdpfo.png",
        "id_str" : "459723683846565889",
        "id" : 459723683846565889,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmFEQTaCMAEdpfo.png",
        "sizes" : [ {
          "h" : 431,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 531,
          "resize" : "fit",
          "w" : 837
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 531,
          "resize" : "fit",
          "w" : 837
        }, {
          "h" : 531,
          "resize" : "fit",
          "w" : 837
        } ],
        "display_url" : "pic.twitter.com\/L9aqSkcoxa"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/cbzOic24h1",
        "expanded_url" : "http:\/\/www.nashturley.org\/2012\/09\/27\/pinguin-poop-paper\/",
        "display_url" : "nashturley.org\/2012\/09\/27\/pin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "459723684647690240",
    "text" : "It wouldn't be World Penguin Day without the Penguin Projectile Poop Paper http:\/\/t.co\/cbzOic24h1 http:\/\/t.co\/L9aqSkcoxa",
    "id" : 459723684647690240,
    "created_at" : "2014-04-25 16:00:42 +0000",
    "user" : {
      "name" : "Kim Martini",
      "screen_name" : "rejectedbanana",
      "protected" : false,
      "id_str" : "48494794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923569471498813440\/gndgbHUY_normal.jpg",
      "id" : 48494794,
      "verified" : false
    }
  },
  "id" : 459725884178837504,
  "created_at" : "2014-04-25 16:09:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/uNgnRSBWMV",
      "expanded_url" : "http:\/\/youtu.be\/LPM7ugLeXhY?t=1m15s",
      "display_url" : "youtu.be\/LPM7ugLeXhY?t=\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "459718625503760384",
  "geo" : { },
  "id_str" : "459724952711999489",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot YouTube bietet schon How-Tos an! http:\/\/t.co\/uNgnRSBWMV",
  "id" : 459724952711999489,
  "in_reply_to_status_id" : 459718625503760384,
  "created_at" : "2014-04-25 16:05:44 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/jTdEI10qsY",
      "expanded_url" : "https:\/\/dl.dropboxusercontent.com\/u\/15210538\/Falkvinge2nd.gif",
      "display_url" : "dl.dropboxusercontent.com\/u\/15210538\/Fal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459713556947410945",
  "text" : "Aus unzuverl\u00E4ssigen Quellen erfahren: Der Weltraumaufzug wird mit den Tr\u00E4nen sozialliberaler Piraten betrieben. https:\/\/t.co\/jTdEI10qsY",
  "id" : 459713556947410945,
  "created_at" : "2014-04-25 15:20:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723266286, 8.6276235151 ]
  },
  "id_str" : "459693429333962752",
  "text" : "\u00ABIch muss noch dieses Motivationsschreiben machen, aber ich bin einfach zu unmotiviert.\u00BB",
  "id" : 459693429333962752,
  "created_at" : "2014-04-25 14:00:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459688895006126080",
  "geo" : { },
  "id_str" : "459692564804009984",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon did i ever have a choice?",
  "id" : 459692564804009984,
  "in_reply_to_status_id" : 459688895006126080,
  "created_at" : "2014-04-25 13:57:02 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 69, 78 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/knqBSnOQmW",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=tEK3WbF8c-U",
      "display_url" : "youtube.com\/watch?v=tEK3Wb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459688023954055168",
  "text" : "\u00ABIch will das Europa in 20 Jahren den ersten Weltraumaufzug baut.\u00BB \u2013 @Senficon. You go girl! https:\/\/t.co\/knqBSnOQmW",
  "id" : 459688023954055168,
  "created_at" : "2014-04-25 13:39:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/wzLljJA8OZ",
      "expanded_url" : "http:\/\/de.wikipedia.org\/wiki\/Gro%C3%9Fer_Sand",
      "display_url" : "de.wikipedia.org\/wiki\/Gro%C3%9F\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "459678276135682049",
  "geo" : { },
  "id_str" : "459680804822863872",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara it could be both, the reserve was used by US troops after WW2 as well. http:\/\/t.co\/wzLljJA8OZ (sorry, only in de.)",
  "id" : 459680804822863872,
  "in_reply_to_status_id" : 459678276135682049,
  "created_at" : "2014-04-25 13:10:18 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 76, 89 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/dTShATKtcG",
      "expanded_url" : "http:\/\/www.eucomap.net\/",
      "display_url" : "eucomap.net"
    } ]
  },
  "geo" : { },
  "id_str" : "459676990967394306",
  "text" : "Which reminds me: http:\/\/t.co\/dTShATKtcG is still up and running. Well done @PhilippBayer",
  "id" : 459676990967394306,
  "created_at" : "2014-04-25 12:55:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/3H5ao9d3oJ",
      "expanded_url" : "http:\/\/instagram.com\/p\/nNqb8jBwlC\/",
      "display_url" : "instagram.com\/p\/nNqb8jBwlC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "459676359452033024",
  "text" : "Nature-sanctuary in Mainz. 'Yanks keep out!' http:\/\/t.co\/3H5ao9d3oJ",
  "id" : 459676359452033024,
  "created_at" : "2014-04-25 12:52:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1698059854, 8.6354472575 ]
  },
  "id_str" : "459668443009409025",
  "text" : "\u00ABHave a look at my code. The output files are not created. Oh, now they are there. How did you do that?!\u00BB\u2014\u00ABF5 refreshes your file browser\u2026\u00BB",
  "id" : 459668443009409025,
  "created_at" : "2014-04-25 12:21:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/ZBOXe7DRmY",
      "expanded_url" : "http:\/\/instagram.com\/p\/nNlBZNhwuW\/",
      "display_url" : "instagram.com\/p\/nNlBZNhwuW\/"
    } ]
  },
  "geo" : { },
  "id_str" : "459664378007416832",
  "text" : "Voff http:\/\/t.co\/ZBOXe7DRmY",
  "id" : 459664378007416832,
  "created_at" : "2014-04-25 12:05:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "_quoth_",
      "screen_name" : "ibews",
      "indices" : [ 0, 6 ],
      "id_str" : "2913051689",
      "id" : 2913051689
    }, {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 7, 14 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459660379774517249",
  "geo" : { },
  "id_str" : "459660963403563008",
  "in_reply_to_user_id" : 57908725,
  "text" : "@ibews @Bediko ich glaube ich habe auch alle meine Professoren geduzt.",
  "id" : 459660963403563008,
  "in_reply_to_status_id" : 459660379774517249,
  "created_at" : "2014-04-25 11:51:28 +0000",
  "in_reply_to_screen_name" : "_quoth_",
  "in_reply_to_user_id_str" : "57908725",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459659421044707328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723507001, 8.6275510211 ]
  },
  "id_str" : "459659674758172673",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko nat\u00FCrlich, was sollten sie sonst tun?",
  "id" : 459659674758172673,
  "in_reply_to_status_id" : 459659421044707328,
  "created_at" : "2014-04-25 11:46:21 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1775908514, 8.6153751444 ]
  },
  "id_str" : "459659085861097473",
  "text" : "\u00ABDu siehst m\u00FCde aus. Ich w\u00FCrd dich am liebsten ins Bett bringen und dir einen Orangensaft reichen.\u00BB Beste Studenten ever!",
  "id" : 459659085861097473,
  "created_at" : "2014-04-25 11:44:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/ECCxDeLBIz",
      "expanded_url" : "http:\/\/instagram.com\/p\/nNLezgBwnD\/",
      "display_url" : "instagram.com\/p\/nNLezgBwnD\/"
    } ]
  },
  "geo" : { },
  "id_str" : "459608214364237825",
  "text" : "\u00AByou only got it for the title, didn't you?\u00BB http:\/\/t.co\/ECCxDeLBIz",
  "id" : 459608214364237825,
  "created_at" : "2014-04-25 08:21:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096510474, 8.2831413503 ]
  },
  "id_str" : "459603717202137088",
  "text" : "\u00ABI\u2019ve got this weird feeling\u2026\u00BB \u2014 \u00ABLet me help, the general concept is called empathy\u2026\u00BB",
  "id" : 459603717202137088,
  "created_at" : "2014-04-25 08:03:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096827515, 8.2830124274 ]
  },
  "id_str" : "459413143278850048",
  "text" : "Schlussendlich habe ich ihn gefunden. Daf\u00FCr bei der Suche nach dem Impfpass irgendwo verloren: Meine Abschlusszeugnisse.",
  "id" : 459413143278850048,
  "created_at" : "2014-04-24 19:26:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097483164, 8.2833720557 ]
  },
  "id_str" : "459412928824111104",
  "text" : "Ich wei\u00DF besser wo die Impfp\u00E4sse der Katzen sind als wo mein eigener sein k\u00F6nnte.",
  "id" : 459412928824111104,
  "created_at" : "2014-04-24 19:25:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/YkLx9Tw3o2",
      "expanded_url" : "http:\/\/instagram.com\/p\/nLq4rfBwv1\/",
      "display_url" : "instagram.com\/p\/nLq4rfBwv1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "459395809000558592",
  "text" : "Artsy dogs http:\/\/t.co\/YkLx9Tw3o2",
  "id" : 459395809000558592,
  "created_at" : "2014-04-24 18:17:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lfas",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1272794118, 8.6772763377 ]
  },
  "id_str" : "459370790300180481",
  "text" : "\u00ABI come home more greedy, more ambitious, more voluptuous, and even more cruel and inhuman, because I have been among human beings.\u00BB #lfas",
  "id" : 459370790300180481,
  "created_at" : "2014-04-24 16:38:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lfas",
      "indices" : [ 78, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1485174447, 8.6656626574 ]
  },
  "id_str" : "459369381274075136",
  "text" : "\u00ABWhat progress, you ask, have I made? I have begun to be a friend to myself.\u00BB #lfas",
  "id" : 459369381274075136,
  "created_at" : "2014-04-24 16:32:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/5iEaI98EcA",
      "expanded_url" : "http:\/\/www.newyorker.com\/online\/blogs\/newsdesk\/2014\/04\/everest-sherpas-death-and-anger.html?mobify=0",
      "display_url" : "newyorker.com\/online\/blogs\/n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459308976199729154",
  "text" : "Death and Anger on Everest http:\/\/t.co\/5iEaI98EcA",
  "id" : 459308976199729154,
  "created_at" : "2014-04-24 12:32:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723413511, 8.6275970764 ]
  },
  "id_str" : "459305805997944833",
  "text" : "\u00ABBut we are discussing bioinformatics\u2026\u00BB \u2014 \u00ABYou\u2019re talking about Goat Simulator!\u00BB",
  "id" : 459305805997944833,
  "created_at" : "2014-04-24 12:20:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459297861914873856",
  "text" : "\u00ABPoisonous or venomous, what's the difference?\u00BB \u2014 \u00ABIt's 'shall I not eat it' or 'shall I not get eaten by it'.\u00BB",
  "id" : 459297861914873856,
  "created_at" : "2014-04-24 11:48:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/yrcmM2nYNV",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1092",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172352, 8.62761 ]
  },
  "id_str" : "459280649044885504",
  "text" : "when I look at you\u2026 http:\/\/t.co\/yrcmM2nYNV",
  "id" : 459280649044885504,
  "created_at" : "2014-04-24 10:40:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/sAMPEP3vKK",
      "expanded_url" : "http:\/\/instagram.com\/p\/nKveAJBwiG\/",
      "display_url" : "instagram.com\/p\/nKveAJBwiG\/"
    } ]
  },
  "geo" : { },
  "id_str" : "459265150739288064",
  "text" : "Graveyard http:\/\/t.co\/sAMPEP3vKK",
  "id" : 459265150739288064,
  "created_at" : "2014-04-24 09:38:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459252091652165632",
  "geo" : { },
  "id_str" : "459252950469443584",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot was halt passiert wenn man ein Spitz wie Nachbars Lumpi ist.",
  "id" : 459252950469443584,
  "in_reply_to_status_id" : 459252091652165632,
  "created_at" : "2014-04-24 08:50:10 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459250736527048704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.185674659, 8.6234935488 ]
  },
  "id_str" : "459251408618127360",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot lieber einen Freund als einen Spitz verlieren?",
  "id" : 459251408618127360,
  "in_reply_to_status_id" : 459250736527048704,
  "created_at" : "2014-04-24 08:44:02 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723299864, 8.6276015996 ]
  },
  "id_str" : "459250471388332032",
  "text" : "\u00ABEr ist ein Mittelspitz. Es gibt auch noch \u2018sehr Spitz\u2019 und \u2018eher flach\u2019.\u00BB",
  "id" : 459250471388332032,
  "created_at" : "2014-04-24 08:40:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 3, 10 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/BRnB6k3p9L",
      "expanded_url" : "http:\/\/www.denofgeek.com\/tv\/in-the-flesh\/30228\/in-the-flesh-series-2-start-date",
      "display_url" : "denofgeek.com\/tv\/in-the-fles\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459225246265278464",
  "text" : "RT @Evo2Me: In The Flesh series 2 start date | Den of Geek: http:\/\/t.co\/BRnB6k3p9L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/BRnB6k3p9L",
        "expanded_url" : "http:\/\/www.denofgeek.com\/tv\/in-the-flesh\/30228\/in-the-flesh-series-2-start-date",
        "display_url" : "denofgeek.com\/tv\/in-the-fles\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "459223140799741953",
    "text" : "In The Flesh series 2 start date | Den of Geek: http:\/\/t.co\/BRnB6k3p9L",
    "id" : 459223140799741953,
    "created_at" : "2014-04-24 06:51:43 +0000",
    "user" : {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "protected" : false,
      "id_str" : "22910316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/850012114496499712\/f7JQyj8P_normal.jpg",
      "id" : 22910316,
      "verified" : false
    }
  },
  "id" : 459225246265278464,
  "created_at" : "2014-04-24 07:00:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/pOfOjIIWGy",
      "expanded_url" : "http:\/\/instagram.com\/p\/nKbUn2Bwl1\/",
      "display_url" : "instagram.com\/p\/nKbUn2Bwl1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "459220837221273600",
  "text" : "Lieber Hundefreund http:\/\/t.co\/pOfOjIIWGy",
  "id" : 459220837221273600,
  "created_at" : "2014-04-24 06:42:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0035751619, 8.2592990171 ]
  },
  "id_str" : "459069504568688640",
  "text" : "\u00ABDas war ein sch\u00F6ner Abend. Mein Hass auf die Menschheit ist wieder entflammt. Ich wusste gar nicht wie sehr er mir gefehlt hat.\u00BB",
  "id" : 459069504568688640,
  "created_at" : "2014-04-23 20:41:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0045062742, 8.2526527997 ]
  },
  "id_str" : "459063952534937601",
  "text" : "\u00ABSetzen sie jetzt Masken auf? Sind wir hier bei Eyes Wide Shut?\u00BB \u2014 \u00ABMehr Brain-Wide Shutdown\u2026\u00BB",
  "id" : 459063952534937601,
  "created_at" : "2014-04-23 20:19:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459061922588295168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00461197, 8.2526662946 ]
  },
  "id_str" : "459062880370188288",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich cool :)",
  "id" : 459062880370188288,
  "in_reply_to_status_id" : 459061922588295168,
  "created_at" : "2014-04-23 20:14:54 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459060045997932544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0045802909, 8.252639717 ]
  },
  "id_str" : "459060708559568897",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Sonntag Vormittag w\u00FCrd gehen.",
  "id" : 459060708559568897,
  "in_reply_to_status_id" : 459060045997932544,
  "created_at" : "2014-04-23 20:06:16 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 50, 59 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459060045997932544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0045874377, 8.2526034641 ]
  },
  "id_str" : "459060584848564224",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ah, hatte Samstag im Kopf. Sonntag sind @Senficon &amp; ich zum Kindergeburtstag eingeladen (ausnahmsweise kein Code f\u00FCr Parteitag)",
  "id" : 459060584848564224,
  "in_reply_to_status_id" : 459060045997932544,
  "created_at" : "2014-04-23 20:05:47 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459051878085836800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0046214074, 8.2527360081 ]
  },
  "id_str" : "459059044477861888",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich steht unser Date f\u00FCr Samstag eigentlich noch? :)",
  "id" : 459059044477861888,
  "in_reply_to_status_id" : 459051878085836800,
  "created_at" : "2014-04-23 19:59:39 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459055623834198016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0044678251, 8.2526912847 ]
  },
  "id_str" : "459056357506052096",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot schlimmer, bei normalen Menschen\u2026 Aber ein guter dry run f\u00FCr die Esoterikmesse. np: Tim Minchin - Storm",
  "id" : 459056357506052096,
  "in_reply_to_status_id" : 459055623834198016,
  "created_at" : "2014-04-23 19:48:59 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0044257452, 8.2527632528 ]
  },
  "id_str" : "459053302081404928",
  "text" : "\u00ABHase, iss schneller auf damit wir gehen k\u00F6nnen. Sonst werd ich gleich zum Sch\u00FCtzen.\u00BB",
  "id" : 459053302081404928,
  "created_at" : "2014-04-23 19:36:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459051878085836800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0045671551, 8.2528321892 ]
  },
  "id_str" : "459052294366318593",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich na gut, dann werde ich mal was auf meine setzen und schauen ob ich es vorher schaffe.",
  "id" : 459052294366318593,
  "in_reply_to_status_id" : 459051878085836800,
  "created_at" : "2014-04-23 19:32:50 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 3, 10 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459051082560577536",
  "text" : "RT @TnaKng: OH: \"Pfadfinder sind super. Sie k\u00F6nnen Knoten machen und Gitarre spielen. Und bei einer Zombieapokalypse sind sie sicher auch h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "459028659127734272",
    "text" : "OH: \"Pfadfinder sind super. Sie k\u00F6nnen Knoten machen und Gitarre spielen. Und bei einer Zombieapokalypse sind sie sicher auch hilfreich.\"",
    "id" : 459028659127734272,
    "created_at" : "2014-04-23 17:58:55 +0000",
    "user" : {
      "name" : "Tina",
      "screen_name" : "trotzdemda",
      "protected" : false,
      "id_str" : "339564605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430349867920015360\/MEsO92es_normal.png",
      "id" : 339564605,
      "verified" : false
    }
  },
  "id" : 459051082560577536,
  "created_at" : "2014-04-23 19:28:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459048092525158401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0046946956, 8.2527524143 ]
  },
  "id_str" : "459049848894144512",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich der klingt ja schon sehr cool. Lohnt sich da was zu lesen? :)",
  "id" : 459049848894144512,
  "in_reply_to_status_id" : 459048092525158401,
  "created_at" : "2014-04-23 19:23:07 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0046750962, 8.2528916205 ]
  },
  "id_str" : "459049330838867968",
  "text" : "\u00ABIch bin ja mehr so der Kopfmensch als Jungfrau.\u00BB oh, the irony\u2026",
  "id" : 459049330838867968,
  "created_at" : "2014-04-23 19:21:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/dw3Go6JnHs",
      "expanded_url" : "http:\/\/instagram.com\/p\/nJMgWbhwlu\/",
      "display_url" : "instagram.com\/p\/nJMgWbhwlu\/"
    } ]
  },
  "geo" : { },
  "id_str" : "459047514206126080",
  "text" : "for those about to rock http:\/\/t.co\/dw3Go6JnHs",
  "id" : 459047514206126080,
  "created_at" : "2014-04-23 19:13:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0044993942, 8.2528829557 ]
  },
  "id_str" : "459047086798147584",
  "text" : "\u00ABAch, der ist Waage. Deshalb ist der so sympathisch!\u00BB \u2014 \u00ABAh, du bist Esoteriker und deshalb so unsympathisch\u2026\u00BB",
  "id" : 459047086798147584,
  "created_at" : "2014-04-23 19:12:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/sBczhJ1NY0",
      "expanded_url" : "http:\/\/instagram.com\/p\/nJBhC5BwkR\/",
      "display_url" : "instagram.com\/p\/nJBhC5BwkR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "459023370513047552",
  "text" : "Clustering http:\/\/t.co\/sBczhJ1NY0",
  "id" : 459023370513047552,
  "created_at" : "2014-04-23 17:37:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459020894082707456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096152217, 8.2829950218 ]
  },
  "id_str" : "459021893740531712",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon isoprop &amp; sterilium &lt;3",
  "id" : 459021893740531712,
  "in_reply_to_status_id" : 459020894082707456,
  "created_at" : "2014-04-23 17:32:02 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lessig",
      "screen_name" : "lessig",
      "indices" : [ 3, 10 ],
      "id_str" : "11388132",
      "id" : 11388132
    }, {
      "name" : "Minecade - Legendary",
      "screen_name" : "Minecade",
      "indices" : [ 111, 120 ],
      "id_str" : "343857022",
      "id" : 343857022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459021765403230208",
  "text" : "RT @lessig: A short post about the norms of online sovereigns: not yet beyond feudalism (or avoid the likes of @Minecade): http:\/\/t.co\/Jllr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Minecade - Legendary",
        "screen_name" : "Minecade",
        "indices" : [ 99, 108 ],
        "id_str" : "343857022",
        "id" : 343857022
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/JllrGLkb1W",
        "expanded_url" : "http:\/\/lessig.tumblr.com\/post\/83626351547\/the-justice-in-coders",
        "display_url" : "lessig.tumblr.com\/post\/836263515\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "459002312351289344",
    "text" : "A short post about the norms of online sovereigns: not yet beyond feudalism (or avoid the likes of @Minecade): http:\/\/t.co\/JllrGLkb1W",
    "id" : 459002312351289344,
    "created_at" : "2014-04-23 16:14:13 +0000",
    "user" : {
      "name" : "Lessig",
      "screen_name" : "lessig",
      "protected" : false,
      "id_str" : "11388132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689571338332327949\/N_fQy389_normal.jpg",
      "id" : 11388132,
      "verified" : true
    }
  },
  "id" : 459021765403230208,
  "created_at" : "2014-04-23 17:31:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/ibrpBHCyeK",
      "expanded_url" : "http:\/\/instagram.com\/p\/nI8jZNBwsi\/",
      "display_url" : "instagram.com\/p\/nI8jZNBwsi\/"
    } ]
  },
  "geo" : { },
  "id_str" : "459012439557013504",
  "text" : "By now horse masks are going out of fashion http:\/\/t.co\/ibrpBHCyeK",
  "id" : 459012439557013504,
  "created_at" : "2014-04-23 16:54:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/xIS8O7vveL",
      "expanded_url" : "http:\/\/themagnifyingglass.typepad.com\/weblog\/2010\/04\/teeth-of-a-different-color.html",
      "display_url" : "themagnifyingglass.typepad.com\/weblog\/2010\/04\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098016832, 8.2835037902 ]
  },
  "id_str" : "459004598863527936",
  "text" : "\u00ABHow long do you wanna keep the skulls in acetone? Their teeth are going orange!\u00BB\u2014\u00ABOh, let me tell you about rodents\u00BB http:\/\/t.co\/xIS8O7vveL",
  "id" : 459004598863527936,
  "created_at" : "2014-04-23 16:23:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Campus Mainz",
      "screen_name" : "campusmainz",
      "indices" : [ 10, 22 ],
      "id_str" : "257975518",
      "id" : 257975518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458991986616598529",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096309672, 8.282985509 ]
  },
  "id_str" : "459002517029142528",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @campusmainz soso, sie Katze. Wei\u00DFt du wer sich noch freuen w\u00FCrde wenn du mal nach Hause kommst? Nevermind\u2026",
  "id" : 459002517029142528,
  "in_reply_to_status_id" : 458991986616598529,
  "created_at" : "2014-04-23 16:15:02 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/4p4im4Nyfo",
      "expanded_url" : "http:\/\/read.bi\/1fpujFV",
      "display_url" : "read.bi\/1fpujFV"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095675726, 8.2830809676 ]
  },
  "id_str" : "459001725681410049",
  "text" : "\u00ABjournalists really need a course in statistical inference and evaluating evidence\u00BB As do MDs, scientists, everyone\u2026 http:\/\/t.co\/4p4im4Nyfo",
  "id" : 459001725681410049,
  "created_at" : "2014-04-23 16:11:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458957965899624448",
  "text" : "\u00ABThe upgraded nodes are awesome! It means I can fail much faster!\u00BB",
  "id" : 458957965899624448,
  "created_at" : "2014-04-23 13:18:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458942989793230848",
  "text" : "TIL: if you google for 'Gifsy' prophages aren't the only kind of results you will get\u2026",
  "id" : 458942989793230848,
  "created_at" : "2014-04-23 12:18:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lolnope",
      "indices" : [ 20, 28 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458939089912598528",
  "geo" : { },
  "id_str" : "458939674044956672",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju that's the #lolnope part for me.",
  "id" : 458939674044956672,
  "in_reply_to_status_id" : 458939089912598528,
  "created_at" : "2014-04-23 12:05:19 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458938813101142017",
  "geo" : { },
  "id_str" : "458939056093945856",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju the one that requires unity?",
  "id" : 458939056093945856,
  "in_reply_to_status_id" : 458938813101142017,
  "created_at" : "2014-04-23 12:02:52 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/yhEFElPKL4",
      "expanded_url" : "http:\/\/itis.ga\/Flappy-2048\/",
      "display_url" : "itis.ga\/Flappy-2048\/"
    }, {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/W5BeuZE9Vc",
      "expanded_url" : "https:\/\/github.com\/hczhcz\/Flappy-2048",
      "display_url" : "github.com\/hczhcz\/Flappy-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "458937190878572544",
  "geo" : { },
  "id_str" : "458938408388534272",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju you're close: http:\/\/t.co\/yhEFElPKL4 here's the code to replace the images https:\/\/t.co\/W5BeuZE9Vc",
  "id" : 458938408388534272,
  "in_reply_to_status_id" : 458937190878572544,
  "created_at" : "2014-04-23 12:00:17 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/eeQ2ie2sOh",
      "expanded_url" : "http:\/\/i19.photobucket.com\/albums\/b157\/scapegoat13\/trib6.gif",
      "display_url" : "i19.photobucket.com\/albums\/b157\/sc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "458932282603339776",
  "text" : "I really should start to write my own evolutionary psychology papers. Instead of Trivers I will cite Tribbles http:\/\/t.co\/eeQ2ie2sOh",
  "id" : 458932282603339776,
  "created_at" : "2014-04-23 11:35:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 3, 14 ],
      "id_str" : "191004758",
      "id" : 191004758
    }, {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 26, 36 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/37uS2qG36q",
      "expanded_url" : "http:\/\/bit.ly\/1l0W1Or",
      "display_url" : "bit.ly\/1l0W1Or"
    } ]
  },
  "geo" : { },
  "id_str" : "458927357433483264",
  "text" : "RT @PygmyLoris: SRSLY? RT @edyong209 Is there a Tumblr called LOLWUTEvolutionaryPsychology? &lt;buries face in hands&gt;  http:\/\/t.co\/37uS2qG36q \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ed Yong",
        "screen_name" : "edyong209",
        "indices" : [ 10, 20 ],
        "id_str" : "19767193",
        "id" : 19767193
      }, {
        "name" : "Mel TannenbaumHepler",
        "screen_name" : "melanietbaum",
        "indices" : [ 132, 145 ],
        "id_str" : "267788953",
        "id" : 267788953
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/37uS2qG36q",
        "expanded_url" : "http:\/\/bit.ly\/1l0W1Or",
        "display_url" : "bit.ly\/1l0W1Or"
      } ]
    },
    "geo" : { },
    "id_str" : "458925481069654016",
    "text" : "SRSLY? RT @edyong209 Is there a Tumblr called LOLWUTEvolutionaryPsychology? &lt;buries face in hands&gt;  http:\/\/t.co\/37uS2qG36q HT @melanietbaum",
    "id" : 458925481069654016,
    "created_at" : "2014-04-23 11:08:55 +0000",
    "user" : {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "protected" : false,
      "id_str" : "191004758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920667159386316801\/BVsCzUy9_normal.jpg",
      "id" : 191004758,
      "verified" : false
    }
  },
  "id" : 458927357433483264,
  "created_at" : "2014-04-23 11:16:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458925693917999104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723623928, 8.6275231931 ]
  },
  "id_str" : "458926976263143424",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a I wouldn\u2019t necessarily call them that. ;)",
  "id" : 458926976263143424,
  "in_reply_to_status_id" : 458925693917999104,
  "created_at" : "2014-04-23 11:14:52 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457966900879044609",
  "geo" : { },
  "id_str" : "458920899643998208",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a If you can wait a week I can give you a good summary. One of my students volunteered to present that paper in our journal club :)",
  "id" : 458920899643998208,
  "in_reply_to_status_id" : 457966900879044609,
  "created_at" : "2014-04-23 10:50:43 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458913950047145984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722647436, 8.6275942717 ]
  },
  "id_str" : "458918916673536000",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83D\uDC39",
  "id" : 458918916673536000,
  "in_reply_to_status_id" : 458913950047145984,
  "created_at" : "2014-04-23 10:42:50 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 7, 17 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    }, {
      "name" : "Roman Stilling",
      "screen_name" : "NeuRoman_cer",
      "indices" : [ 18, 31 ],
      "id_str" : "113617256",
      "id" : 113617256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458913700737744899",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722523803, 8.6276171543 ]
  },
  "id_str" : "458918778450243584",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @fbnzimmer @NeuRoman_cer thx my dear! \uD83D\uDC28",
  "id" : 458918778450243584,
  "in_reply_to_status_id" : 458913700737744899,
  "created_at" : "2014-04-23 10:42:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/f96JF9NHet",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/04\/22\/bruno-the-bears-tragic-demis.html",
      "display_url" : "boingboing.net\/2014\/04\/22\/bru\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "458909231417401344",
  "text" : "Nearly as good as the Tauntaun sleeping bag http:\/\/t.co\/f96JF9NHet",
  "id" : 458909231417401344,
  "created_at" : "2014-04-23 10:04:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458903652695277568",
  "geo" : { },
  "id_str" : "458904531838205952",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng dunno, hab noch nichts gelesen dazu.",
  "id" : 458904531838205952,
  "in_reply_to_status_id" : 458903652695277568,
  "created_at" : "2014-04-23 09:45:41 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    }, {
      "name" : "Roman Stilling",
      "screen_name" : "NeuRoman_cer",
      "indices" : [ 11, 24 ],
      "id_str" : "113617256",
      "id" : 113617256
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 75, 81 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458903585699672064",
  "geo" : { },
  "id_str" : "458904207844966400",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer @NeuRoman_cer I lost a bit track on that issue tbh, but I think @lobot wanted to check some things first.",
  "id" : 458904207844966400,
  "in_reply_to_status_id" : 458903585699672064,
  "created_at" : "2014-04-23 09:44:23 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    }, {
      "name" : "Roman Stilling",
      "screen_name" : "NeuRoman_cer",
      "indices" : [ 11, 24 ],
      "id_str" : "113617256",
      "id" : 113617256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458903585699672064",
  "geo" : { },
  "id_str" : "458904096242954240",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer @NeuRoman_cer working on, the formal stuff needs to be taken care of first (it's Germany after all\u2026)",
  "id" : 458904096242954240,
  "in_reply_to_status_id" : 458903585699672064,
  "created_at" : "2014-04-23 09:43:57 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458901987795681280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1750426196, 8.6217021794 ]
  },
  "id_str" : "458903419940777984",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng nope, meine S1 heute morgen hatte auch mindestens eins.",
  "id" : 458903419940777984,
  "in_reply_to_status_id" : 458901987795681280,
  "created_at" : "2014-04-23 09:41:15 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    }, {
      "name" : "Roman Stilling",
      "screen_name" : "NeuRoman_cer",
      "indices" : [ 11, 24 ],
      "id_str" : "113617256",
      "id" : 113617256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458902751284842497",
  "geo" : { },
  "id_str" : "458903049151721473",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer @NeuRoman_cer our machine is already running close to its limit, so w\/o ext. funding for a better setup it will matter to us ;)",
  "id" : 458903049151721473,
  "in_reply_to_status_id" : 458902751284842497,
  "created_at" : "2014-04-23 09:39:47 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458898502043836416",
  "geo" : { },
  "id_str" : "458901664616169472",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng Ich glaube wir sind heute mit der gleichen Bahn gefahren :D",
  "id" : 458901664616169472,
  "in_reply_to_status_id" : 458898502043836416,
  "created_at" : "2014-04-23 09:34:17 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458901552854736896",
  "text" : "\u00ABDu sammelst doch Paper, also wissenschaftliche\u2026\u00BB",
  "id" : 458901552854736896,
  "created_at" : "2014-04-23 09:33:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roman Stilling",
      "screen_name" : "NeuRoman_cer",
      "indices" : [ 0, 13 ],
      "id_str" : "113617256",
      "id" : 113617256
    }, {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 14, 24 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458899781839233024",
  "geo" : { },
  "id_str" : "458900007958351872",
  "in_reply_to_user_id" : 113617256,
  "text" : "@NeuRoman_cer @fbnzimmer yeah, for BAM files we don't have the server capabilities, although that would be the coolest thing in the end.",
  "id" : 458900007958351872,
  "in_reply_to_status_id" : 458899781839233024,
  "created_at" : "2014-04-23 09:27:42 +0000",
  "in_reply_to_screen_name" : "NeuRoman_cer",
  "in_reply_to_user_id_str" : "113617256",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roman Stilling",
      "screen_name" : "NeuRoman_cer",
      "indices" : [ 0, 13 ],
      "id_str" : "113617256",
      "id" : 113617256
    }, {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 14, 24 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 25, 36 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458898853086126080",
  "geo" : { },
  "id_str" : "458899459414712320",
  "in_reply_to_user_id" : 113617256,
  "text" : "@NeuRoman_cer @fbnzimmer @openSNPorg you can already upload VCFs if you have WGS\/Exome variant calls. Microbiome data is on our todo. :p",
  "id" : 458899459414712320,
  "in_reply_to_status_id" : 458898853086126080,
  "created_at" : "2014-04-23 09:25:31 +0000",
  "in_reply_to_screen_name" : "NeuRoman_cer",
  "in_reply_to_user_id_str" : "113617256",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    }, {
      "name" : "Roman Stilling",
      "screen_name" : "NeuRoman_cer",
      "indices" : [ 11, 24 ],
      "id_str" : "113617256",
      "id" : 113617256
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 25, 36 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 37, 50 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 51, 63 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458891141677867008",
  "geo" : { },
  "id_str" : "458891439767060480",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer @NeuRoman_cer @openSNPorg @PhilippBayer @helgerausch and let us know if you need any help, we're glad to help. :)",
  "id" : 458891439767060480,
  "in_reply_to_status_id" : 458891141677867008,
  "created_at" : "2014-04-23 08:53:39 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1610234504, 8.6280251877 ]
  },
  "id_str" : "458883993883385856",
  "text" : "\u00ABWait, it\u2019s called Labor Day but no one is working? You Germans sure are crazy\u2026\u00BB",
  "id" : 458883993883385856,
  "created_at" : "2014-04-23 08:24:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458875849337733120",
  "text" : "\u00ABHave fun guys, I'll be off to get some science done.\u00BB \u2013 \u00ABAs if German immigration law wasn't a really hard science in itself\u2026\u00BB",
  "id" : 458875849337733120,
  "created_at" : "2014-04-23 07:51:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458740399553937409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009655229, 8.2830661276 ]
  },
  "id_str" : "458740554428612609",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC too bad, I like that so much! :p",
  "id" : 458740554428612609,
  "in_reply_to_status_id" : 458740399553937409,
  "created_at" : "2014-04-22 22:54:05 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458736579184693249",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097018275, 8.283039795 ]
  },
  "id_str" : "458737542234669056",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC it\u2019s much appreciated, even if it sounds like a just invented intervention technique (that may even make it more appealing). ;)",
  "id" : 458737542234669056,
  "in_reply_to_status_id" : 458736579184693249,
  "created_at" : "2014-04-22 22:42:07 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/K3t9QVHvKU",
      "expanded_url" : "http:\/\/nymag.com\/news\/features\/23andme-2014-4\/#",
      "display_url" : "nymag.com\/news\/features\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097018275, 8.283039795 ]
  },
  "id_str" : "458737048363728897",
  "text" : "The Google of Spit: on the past and future of 23andMe http:\/\/t.co\/K3t9QVHvKU",
  "id" : 458737048363728897,
  "created_at" : "2014-04-22 22:40:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/E8dZa44KVo",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/Parenting\/comments\/23lc43\/i_think_id_be_a_good_parent_except_for_the_infant\/cgy65ng",
      "display_url" : "reddit.com\/r\/Parenting\/co\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097018275, 8.283039795 ]
  },
  "id_str" : "458734774010793984",
  "text" : "\u00ABInfants are the drill sergeants of parenting bootcamp.\u00BB http:\/\/t.co\/E8dZa44KVo",
  "id" : 458734774010793984,
  "created_at" : "2014-04-22 22:31:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458731922592894976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097018275, 8.283039795 ]
  },
  "id_str" : "458733762311102464",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC you sure have ways of cheering one up ;)",
  "id" : 458733762311102464,
  "in_reply_to_status_id" : 458731922592894976,
  "created_at" : "2014-04-22 22:27:06 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458729922148958208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097018275, 8.283039795 ]
  },
  "id_str" : "458730153657765888",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC i\u2019m not sure whether this is how work-life balance is supposed to work :p",
  "id" : 458730153657765888,
  "in_reply_to_status_id" : 458729922148958208,
  "created_at" : "2014-04-22 22:12:46 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/458725314869608448\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/AFHAmKfR2v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl24PknIYAApe7a.png",
      "id_str" : "458725314727010304",
      "id" : 458725314727010304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl24PknIYAApe7a.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 1794
      }, {
        "h" : 761,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 1794
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/AFHAmKfR2v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096516529, 8.28299505 ]
  },
  "id_str" : "458725314869608448",
  "text" : "Just played around a bit with ggplot2 to visualize\/annotate the growth of openSNP over time. No stationary phase yet. http:\/\/t.co\/AFHAmKfR2v",
  "id" : 458725314869608448,
  "created_at" : "2014-04-22 21:53:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458722525971628033",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096516529, 8.28299505 ]
  },
  "id_str" : "458723187279544320",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer indeed!",
  "id" : 458723187279544320,
  "in_reply_to_status_id" : 458722525971628033,
  "created_at" : "2014-04-22 21:45:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096516529, 8.28299505 ]
  },
  "id_str" : "458707371229863936",
  "text" : "\u00ABWie richtet man instant Chaos an? Gleitgel auf den Boden sch\u00FCtten, Katze durchlaufen lassen\u2026\u00BB \u2013 \u00ABThat\u2019s a slippery slope\u2026\u00BB",
  "id" : 458707371229863936,
  "created_at" : "2014-04-22 20:42:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458706061998837760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096734573, 8.2831065442 ]
  },
  "id_str" : "458706909407621120",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC for compensation I today spend virtually all day in front of a screen, hunting virtual bugs instead.",
  "id" : 458706909407621120,
  "in_reply_to_status_id" : 458706061998837760,
  "created_at" : "2014-04-22 20:40:24 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ferrara",
      "screen_name" : "jabawack",
      "indices" : [ 3, 12 ],
      "id_str" : "17354555",
      "id" : 17354555
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/24aZ83qCJf",
      "expanded_url" : "http:\/\/buff.ly\/1muP6Ni",
      "display_url" : "buff.ly\/1muP6Ni"
    } ]
  },
  "geo" : { },
  "id_str" : "458668551080275968",
  "text" : "RT @jabawack: 10 reasons to switch to ggplot | Mandy Mejia http:\/\/t.co\/24aZ83qCJf #rstats",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rstats",
        "indices" : [ 68, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/24aZ83qCJf",
        "expanded_url" : "http:\/\/buff.ly\/1muP6Ni",
        "display_url" : "buff.ly\/1muP6Ni"
      } ]
    },
    "geo" : { },
    "id_str" : "458652961649213440",
    "text" : "10 reasons to switch to ggplot | Mandy Mejia http:\/\/t.co\/24aZ83qCJf #rstats",
    "id" : 458652961649213440,
    "created_at" : "2014-04-22 17:06:02 +0000",
    "user" : {
      "name" : "Emilio Ferrara",
      "screen_name" : "jabawack",
      "protected" : false,
      "id_str" : "17354555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669388577248153601\/aB5vhnqL_normal.jpg",
      "id" : 17354555,
      "verified" : false
    }
  },
  "id" : 458668551080275968,
  "created_at" : "2014-04-22 18:07:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 21, 34 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096612704, 8.2830030006 ]
  },
  "id_str" : "458650863243112448",
  "text" : "Books recommended by @PhilippBayer. The easiest way to go from hating humans in general to loving them. And vice versa.",
  "id" : 458650863243112448,
  "created_at" : "2014-04-22 16:57:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/MUwWuJK1w9",
      "expanded_url" : "http:\/\/instagram.com\/p\/nGPhtRhwrf\/",
      "display_url" : "instagram.com\/p\/nGPhtRhwrf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "458631944948178944",
  "text" : "WWJW http:\/\/t.co\/MUwWuJK1w9",
  "id" : 458631944948178944,
  "created_at" : "2014-04-22 15:42:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458622871116718081",
  "geo" : { },
  "id_str" : "458625145658040320",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Du meintest wohl: Die Hiebe in Zeiten der Social Media\u2026",
  "id" : 458625145658040320,
  "in_reply_to_status_id" : 458622871116718081,
  "created_at" : "2014-04-22 15:15:30 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458615354223517696",
  "text" : "\u00ABWieso betrinkt ihr euch denn so?\u00BB \u2013 \u00ABStell dir vor du bist R\u00F6mer. Und Jesus ist tot!\u00BB",
  "id" : 458615354223517696,
  "created_at" : "2014-04-22 14:36:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/zvOxend4Ii",
      "expanded_url" : "http:\/\/instagram.com\/p\/nF0LgGBwmd\/",
      "display_url" : "instagram.com\/p\/nF0LgGBwmd\/"
    } ]
  },
  "geo" : { },
  "id_str" : "458571810905546752",
  "text" : "open your heart http:\/\/t.co\/zvOxend4Ii",
  "id" : 458571810905546752,
  "created_at" : "2014-04-22 11:43:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/RA2V11crDr",
      "expanded_url" : "http:\/\/blog.tjll.net\/please-stop-hashing-passwords\/",
      "display_url" : "blog.tjll.net\/please-stop-ha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "458567486800412674",
  "text" : "I guess this will have to be repeated ad nauseam: Hashing and You http:\/\/t.co\/RA2V11crDr",
  "id" : 458567486800412674,
  "created_at" : "2014-04-22 11:26:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458546035355566081",
  "text" : "Routing for NCBI and Ensembl on our floor is broken (and _only_ on our floor)\u2026 Nomadic bioinformaticians migrating from subnet to subnet\u2026",
  "id" : 458546035355566081,
  "created_at" : "2014-04-22 10:01:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/dsRH6bccMD",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/enhanced\/doi\/10.1002\/hup.1150",
      "display_url" : "onlinelibrary.wiley.com\/enhanced\/doi\/1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "458540518314881024",
  "geo" : { },
  "id_str" : "458542253171306496",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Der wahre Profi kippt ja seinen Zuckerbedarf gleich in den Kaffee f\u00FCr den maximalen Effekt http:\/\/t.co\/dsRH6bccMD",
  "id" : 458542253171306496,
  "in_reply_to_status_id" : 458540518314881024,
  "created_at" : "2014-04-22 09:46:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 0, 12 ],
      "id_str" : "48357885",
      "id" : 48357885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458527670138339328",
  "geo" : { },
  "id_str" : "458528915871772672",
  "in_reply_to_user_id" : 48357885,
  "text" : "@Whitey_chan cute, isn't it? :D",
  "id" : 458528915871772672,
  "in_reply_to_status_id" : 458527670138339328,
  "created_at" : "2014-04-22 08:53:07 +0000",
  "in_reply_to_screen_name" : "Whitey_chan",
  "in_reply_to_user_id_str" : "48357885",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/mCLnQ1Em6V",
      "expanded_url" : "http:\/\/egtheory.wordpress.com\/2014\/04\/20\/cross-validation-in-finance-psychology-and-political-science\/",
      "display_url" : "egtheory.wordpress.com\/2014\/04\/20\/cro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "458524777880506368",
  "text" : "Cross-validation in finance, psychology, and political science http:\/\/t.co\/mCLnQ1Em6V",
  "id" : 458524777880506368,
  "created_at" : "2014-04-22 08:36:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/bkZJf7Y1rQ",
      "expanded_url" : "http:\/\/www.vox.com\/a\/porn",
      "display_url" : "vox.com\/a\/porn"
    } ]
  },
  "geo" : { },
  "id_str" : "458522484367949824",
  "text" : "Coming out as a Porn Star http:\/\/t.co\/bkZJf7Y1rQ",
  "id" : 458522484367949824,
  "created_at" : "2014-04-22 08:27:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458514123236839424",
  "geo" : { },
  "id_str" : "458514570030903297",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC sure, but didn't take into account that walking around might qualify as such. But it's ok. Had coffee and went off to work anyway.",
  "id" : 458514570030903297,
  "in_reply_to_status_id" : 458514123236839424,
  "created_at" : "2014-04-22 07:56:06 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "relapse",
      "indices" : [ 85, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0068292781, 8.28329798 ]
  },
  "id_str" : "458480063328305152",
  "text" : "Hiking ~25 km yesterday probably wasn\u2019t the best method of getting rid of my cold m) #relapse",
  "id" : 458480063328305152,
  "created_at" : "2014-04-22 05:38:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 38, 49 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/d4RZYGjfCJ",
      "expanded_url" : "https:\/\/opensnp.org\/genotypes",
      "display_url" : "opensnp.org\/genotypes"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096516529, 8.28299505 ]
  },
  "id_str" : "458361621661114368",
  "text" : "I never thought this would happen: MT @openSNPorg: genotyping file #900 was uploaded. Thx to all our sharing users https:\/\/t.co\/d4RZYGjfCJ",
  "id" : 458361621661114368,
  "created_at" : "2014-04-21 21:48:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/CYXGESKnz9",
      "expanded_url" : "http:\/\/www.ronorp.net\/zuerich\/stadtleben\/inspiration.983\/lesen.992\/kolumnen.240\/herr-meyer-zuerich.831\/15-zitate-aus-der-untergang-die-sich-prima-beim-liebesspiel.267784",
      "display_url" : "ronorp.net\/zuerich\/stadtl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "458355258931314688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096516529, 8.28299505 ]
  },
  "id_str" : "458356445575413760",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot und zumindest manchmal, wirklich nur manchmal, hast du auch recht damit. http:\/\/t.co\/CYXGESKnz9",
  "id" : 458356445575413760,
  "in_reply_to_status_id" : 458355258931314688,
  "created_at" : "2014-04-21 21:27:47 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/XWNi8zfSiv",
      "expanded_url" : "http:\/\/instagram.com\/p\/nEOjjcBwoS\/",
      "display_url" : "instagram.com\/p\/nEOjjcBwoS\/"
    } ]
  },
  "geo" : { },
  "id_str" : "458348335406280704",
  "text" : "Brainwash http:\/\/t.co\/XWNi8zfSiv",
  "id" : 458348335406280704,
  "created_at" : "2014-04-21 20:55:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Torsten Sommer",
      "screen_name" : "tosopiratas",
      "indices" : [ 10, 22 ],
      "id_str" : "99694646",
      "id" : 99694646
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/458324478863618048\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/fSwSRoulMd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlxLr1UIUAEakfq.jpg",
      "id_str" : "458324478502916097",
      "id" : 458324478502916097,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlxLr1UIUAEakfq.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/fSwSRoulMd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458317659038564352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096457468, 8.2830063852 ]
  },
  "id_str" : "458324478863618048",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @tosopiratas Wenn das Micro ist will ich Macro nicht sehen. ;) http:\/\/t.co\/fSwSRoulMd",
  "id" : 458324478863618048,
  "in_reply_to_status_id" : 458317659038564352,
  "created_at" : "2014-04-21 19:20:45 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458323647116353536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096773217, 8.2829736639 ]
  },
  "id_str" : "458323845565677568",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich but in this case it\u2019s \u2018lost over time\u2019 ;)",
  "id" : 458323845565677568,
  "in_reply_to_status_id" : 458323647116353536,
  "created_at" : "2014-04-21 19:18:14 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458322696561246208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096548163, 8.2827087119 ]
  },
  "id_str" : "458323295885344768",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich all this me will be lost, like tears in the rain.",
  "id" : 458323295885344768,
  "in_reply_to_status_id" : 458322696561246208,
  "created_at" : "2014-04-21 19:16:03 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458322570148708352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096548163, 8.2827087119 ]
  },
  "id_str" : "458323066993795072",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy do you know their fitting method?",
  "id" : 458323066993795072,
  "in_reply_to_status_id" : 458322570148708352,
  "created_at" : "2014-04-21 19:15:09 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458322447822245889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096439386, 8.2829554314 ]
  },
  "id_str" : "458322895857803264",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara yes, but somehow the ggplot2 on my machine didn\u2019t like gam for stat_smooth.",
  "id" : 458322895857803264,
  "in_reply_to_status_id" : 458322447822245889,
  "created_at" : "2014-04-21 19:14:28 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/458321850557558784\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/N3KwtpiFPZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlxJS2tIcAEaWSU.png",
      "id_str" : "458321850356232193",
      "id" : 458321850356232193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlxJS2tIcAEaWSU.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 1794
      }, {
        "h" : 761,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 1794
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/N3KwtpiFPZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096516529, 8.28299505 ]
  },
  "id_str" : "458321850557558784",
  "text" : "\u00ABWhat are you plotting?\u00BB \u2013 \u00ABMy weight over time, including a simple LOESS. And now for some pasta.\u00BB http:\/\/t.co\/N3KwtpiFPZ",
  "id" : 458321850557558784,
  "created_at" : "2014-04-21 19:10:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/07wrQcg1Vs",
      "expanded_url" : "http:\/\/instagram.com\/p\/nD13cEBwv4\/",
      "display_url" : "instagram.com\/p\/nD13cEBwv4\/"
    } ]
  },
  "geo" : { },
  "id_str" : "458294042179432449",
  "text" : "Monkey-Bird http:\/\/t.co\/07wrQcg1Vs",
  "id" : 458294042179432449,
  "created_at" : "2014-04-21 17:19:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0223927808, 8.2020821611 ]
  },
  "id_str" : "458252175249244160",
  "text" : "\u00ABSteht da \u2018Greenpeace\u2019 auf deinem Schl\u00FCsselband?!\u00BB \u2014 \u00ABSchlimmer\u2026\u00BB \u2014 \u00ABOh, \u2018Wuppertal\u2019\u2026\u00BB",
  "id" : 458252175249244160,
  "created_at" : "2014-04-21 14:33:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 21, 30 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/Durj96Jofd",
      "expanded_url" : "http:\/\/instagram.com\/p\/nDczPLhwmS\/",
      "display_url" : "instagram.com\/p\/nDczPLhwmS\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0155666145, 8.1979790703 ]
  },
  "id_str" : "458239093819060225",
  "text" : "Stra\u00DFenwahlkampf mit @senficon in Rheinland-Pfalz http:\/\/t.co\/Durj96Jofd",
  "id" : 458239093819060225,
  "created_at" : "2014-04-21 13:41:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095469831, 8.283140799 ]
  },
  "id_str" : "458190644125896704",
  "text" : "\u00ABWell, it\u2019s no harder to be nice than it is to be creepy. And it\u2019s much more fun.\u00BB &lt;3",
  "id" : 458190644125896704,
  "created_at" : "2014-04-21 10:28:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/LczK2BqPwi",
      "expanded_url" : "http:\/\/instagram.com\/p\/nDFxl4hwrq\/",
      "display_url" : "instagram.com\/p\/nDFxl4hwrq\/"
    } ]
  },
  "geo" : { },
  "id_str" : "458188291972816896",
  "text" : "If you die in Amsterdam your headstone might feature Comic Sans. http:\/\/t.co\/LczK2BqPwi",
  "id" : 458188291972816896,
  "created_at" : "2014-04-21 10:19:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/9ZCP228kSS",
      "expanded_url" : "http:\/\/instagram.com\/p\/nC_zMkhwmj\/",
      "display_url" : "instagram.com\/p\/nC_zMkhwmj\/"
    } ]
  },
  "geo" : { },
  "id_str" : "458175149293187072",
  "text" : "Don't push too hard http:\/\/t.co\/9ZCP228kSS",
  "id" : 458175149293187072,
  "created_at" : "2014-04-21 09:27:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "indices" : [ 3, 18 ],
      "id_str" : "19416598",
      "id" : 19416598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458026964222488576",
  "text" : "RT @leonidkruglyak: \u201CThe careers office at my college suggested that I think about becoming an embittered academic flop. How do I do it? ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/wasaguzZCR",
        "expanded_url" : "http:\/\/www.whitecoatblackhat.com\/academicfailure\/#sthash.9cs2K7ID.dpuf",
        "display_url" : "whitecoatblackhat.com\/academicfailur\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "458025666273746945",
    "text" : "\u201CThe careers office at my college suggested that I think about becoming an embittered academic flop. How do I do it? http:\/\/t.co\/wasaguzZCR",
    "id" : 458025666273746945,
    "created_at" : "2014-04-20 23:33:23 +0000",
    "user" : {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "protected" : false,
      "id_str" : "19416598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1095542276\/MyRecentPhoto_normal.jpg",
      "id" : 19416598,
      "verified" : false
    }
  },
  "id" : 458026964222488576,
  "created_at" : "2014-04-20 23:38:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thepaintedbird",
      "indices" : [ 131, 146 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0113948763, 8.2834262343 ]
  },
  "id_str" : "458025728001720321",
  "text" : "From \u201CI\u2019ll just finish the book &amp; go to sleep\u201D to \u201CI\u2019ll just finish the book, curse humans &amp; will fall asleep eventually\u201D\u2026 #thepaintedbird",
  "id" : 458025728001720321,
  "created_at" : "2014-04-20 23:33:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457966900879044609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096804697, 8.2830372883 ]
  },
  "id_str" : "457970525340708864",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a sure, will send him an email. :)",
  "id" : 457970525340708864,
  "in_reply_to_status_id" : 457966900879044609,
  "created_at" : "2014-04-20 19:54:16 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/nzJtv3JOcC",
      "expanded_url" : "http:\/\/instagram.com\/p\/nBdNcrhwii\/",
      "display_url" : "instagram.com\/p\/nBdNcrhwii\/"
    } ]
  },
  "geo" : { },
  "id_str" : "457958350140235776",
  "text" : "Ohai http:\/\/t.co\/nzJtv3JOcC",
  "id" : 457958350140235776,
  "created_at" : "2014-04-20 19:05:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457955397316644864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678023, 8.283078652 ]
  },
  "id_str" : "457956279810785281",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a a colleague of mine is working on HGT a lot, I can ask him about his opinion if you like.",
  "id" : 457956279810785281,
  "in_reply_to_status_id" : 457955397316644864,
  "created_at" : "2014-04-20 18:57:40 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0131848129, 8.2760196179 ]
  },
  "id_str" : "457939430083682304",
  "text" : "\u00ABIn unserem Alter ist man eigentlich kein \u2018romantisches Paar\u2019 mehr. Da hat man Kinder und droht damit ihnen durchs Gesicht zu lecken!\u00BB",
  "id" : 457939430083682304,
  "created_at" : "2014-04-20 17:50:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457933856675758081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0233027759, 8.2651387341 ]
  },
  "id_str" : "457934396717563904",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot started to wonder whether you wore a fake beard again!",
  "id" : 457934396717563904,
  "in_reply_to_status_id" : 457933856675758081,
  "created_at" : "2014-04-20 17:30:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poly Horror",
      "screen_name" : "polyhorror",
      "indices" : [ 11, 22 ],
      "id_str" : "2276885364",
      "id" : 2276885364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009653188, 8.2829785964 ]
  },
  "id_str" : "457926010647109632",
  "text" : "my kind of @polyhorror: \u00ABShe trimmed your beard?! But you\u2019re not finished with your PhD yet!\u00BB",
  "id" : 457926010647109632,
  "created_at" : "2014-04-20 16:57:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457925517321465856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009653188, 8.2829785964 ]
  },
  "id_str" : "457925660439482369",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot now you\u2019re only risking your life?",
  "id" : 457925660439482369,
  "in_reply_to_status_id" : 457925517321465856,
  "created_at" : "2014-04-20 16:55:59 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/MSuUyX8slO",
      "expanded_url" : "http:\/\/instagram.com\/p\/nBNeEDhwrn\/",
      "display_url" : "instagram.com\/p\/nBNeEDhwrn\/"
    } ]
  },
  "geo" : { },
  "id_str" : "457923735908282369",
  "text" : "I somehow missed the crocodiles http:\/\/t.co\/MSuUyX8slO",
  "id" : 457923735908282369,
  "created_at" : "2014-04-20 16:48:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 7, 16 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lifehacks",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457878605373378560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.1593076867, 6.9609397464 ]
  },
  "id_str" : "457881040896688129",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @SuicideC don\u2019t worry, I again used the soy milk as cruise control. #lifehacks",
  "id" : 457881040896688129,
  "in_reply_to_status_id" : 457878605373378560,
  "created_at" : "2014-04-20 13:58:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457845886203494400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.1593076867, 6.9609397464 ]
  },
  "id_str" : "457880738042761218",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC so either we can strip down the overall weight or I will end up with 20+ kg? :p",
  "id" : 457880738042761218,
  "in_reply_to_status_id" : 457845886203494400,
  "created_at" : "2014-04-20 13:57:29 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457872902315335680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.1593076867, 6.9609397464 ]
  },
  "id_str" : "457880411142897664",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC no matter, try again, fail with less weight. ;)",
  "id" : 457880411142897664,
  "in_reply_to_status_id" : 457872902315335680,
  "created_at" : "2014-04-20 13:56:11 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 7, 16 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457879201648246784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.1682104259, 6.9554057083 ]
  },
  "id_str" : "457880283531190272",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @SuicideC and it\u2019s so much better to be called an alpaca than make an ass of yourself.",
  "id" : 457880283531190272,
  "in_reply_to_status_id" : 457879201648246784,
  "created_at" : "2014-04-20 13:55:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 7, 16 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457873072033660928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5201503091, 6.8140909338 ]
  },
  "id_str" : "457873697299521536",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @SuicideC did you just volunteer?",
  "id" : 457873697299521536,
  "in_reply_to_status_id" : 457873072033660928,
  "created_at" : "2014-04-20 13:29:30 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457844696992468992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3688814417, 4.9706606101 ]
  },
  "id_str" : "457845200640299008",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC and I guess in doubt we will just have to shift who carries how much a bit around. :)",
  "id" : 457845200640299008,
  "in_reply_to_status_id" : 457844696992468992,
  "created_at" : "2014-04-20 11:36:16 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3651410174, 4.9610893149 ]
  },
  "id_str" : "457825979390783489",
  "text" : "\u00ABWas denkst du?\u00BB \u2014 \u00ABIch h\u00F6re dem weinenden Kind zu.\u00BB \u2014 \u00ABAh, du sahst auch ganz gl\u00FCcklich aus.\u00BB",
  "id" : 457825979390783489,
  "created_at" : "2014-04-20 10:19:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457683483075567617",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3651923985, 4.9609288853 ]
  },
  "id_str" : "457785136638349312",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I just happen to meet an expert on ultra-light traveling this afternoon. Will ask about recommendations.",
  "id" : 457785136638349312,
  "in_reply_to_status_id" : 457683483075567617,
  "created_at" : "2014-04-20 07:37:36 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457683046666620928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3651469686, 4.9609790929 ]
  },
  "id_str" : "457784814608068608",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC averaged 15.6 km\/day over the last week (min 4.5, max 25.2) but w\/o heavy equipment on my back.",
  "id" : 457784814608068608,
  "in_reply_to_status_id" : 457683046666620928,
  "created_at" : "2014-04-20 07:36:19 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457683046666620928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3670084472, 4.9696185039 ]
  },
  "id_str" : "457784359618351104",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC ouch, that doesn\u2019t sound like too much fun. Feeling better now?",
  "id" : 457784359618351104,
  "in_reply_to_status_id" : 457683046666620928,
  "created_at" : "2014-04-20 07:34:31 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3652108387, 4.960908182 ]
  },
  "id_str" : "457784091946287104",
  "text" : "\u00ABMagst du ein Hipster-Fr\u00FChst\u00FCck mit Hipster-Kaffee?\u00BB \u2014 \u00ABGern, aber vorher geh ich ganz unironisch aufs Klo.\u00BB",
  "id" : 457784091946287104,
  "created_at" : "2014-04-20 07:33:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 0, 11 ],
      "id_str" : "3782931",
      "id" : 3782931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457633354486386688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3654570712, 4.9593407527 ]
  },
  "id_str" : "457638542639104000",
  "in_reply_to_user_id" : 3782931,
  "text" : "@spreeblick gerne. :)",
  "id" : 457638542639104000,
  "in_reply_to_status_id" : 457633354486386688,
  "created_at" : "2014-04-19 21:55:05 +0000",
  "in_reply_to_screen_name" : "spreeblick",
  "in_reply_to_user_id_str" : "3782931",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 0, 11 ],
      "id_str" : "3782931",
      "id" : 3782931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/OEMkRQFdRn",
      "expanded_url" : "http:\/\/www.hudsonarc.com\/",
      "display_url" : "hudsonarc.com"
    } ]
  },
  "in_reply_to_status_id_str" : "457632269684211712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3654456473, 4.9593199842 ]
  },
  "id_str" : "457632855690985472",
  "in_reply_to_user_id" : 3782931,
  "text" : "@spreeblick dieses nette Quartett. http:\/\/t.co\/OEMkRQFdRn",
  "id" : 457632855690985472,
  "in_reply_to_status_id" : 457632269684211712,
  "created_at" : "2014-04-19 21:32:29 +0000",
  "in_reply_to_screen_name" : "spreeblick",
  "in_reply_to_user_id_str" : "3782931",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3654407439, 4.9593702633 ]
  },
  "id_str" : "457631963474841601",
  "text" : "\u00ABThe next song is a cover of a small indie band that\u2019s also from Australia. \u2018Midnight Oil\u2019, you probably never heard of them.\u00BB",
  "id" : 457631963474841601,
  "created_at" : "2014-04-19 21:28:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/GCqCFLbhRU",
      "expanded_url" : "http:\/\/instagram.com\/p\/m--bqOhwrc\/",
      "display_url" : "instagram.com\/p\/m--bqOhwrc\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.365328563, 4.959793867 ]
  },
  "id_str" : "457609272634134528",
  "text" : "Duckface @ Camping Zeeburg http:\/\/t.co\/GCqCFLbhRU",
  "id" : 457609272634134528,
  "created_at" : "2014-04-19 19:58:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3652156877, 4.9596268525 ]
  },
  "id_str" : "457559257509269505",
  "text" : "\u00ABGeh mir mal aus dem Internet! Wenn ich hinter dir sitze hab ich kein Netz. Go figure.\u00BB",
  "id" : 457559257509269505,
  "created_at" : "2014-04-19 16:40:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457464346139168768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.365363515, 4.9598635454 ]
  },
  "id_str" : "457557370680664064",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC time to call the lack of equipment a life hack and start a philosophy around it. (Sounds like it will get interesting indeed!)",
  "id" : 457557370680664064,
  "in_reply_to_status_id" : 457464346139168768,
  "created_at" : "2014-04-19 16:32:32 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.365363515, 4.9598635454 ]
  },
  "id_str" : "457557019361542145",
  "text" : "Best way to spend the Easter weekend: roam the gay sex shops of Amsterdam.",
  "id" : 457557019361542145,
  "created_at" : "2014-04-19 16:31:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/fdlmk1MPDO",
      "expanded_url" : "http:\/\/instagram.com\/p\/m-mUYvhwqo\/",
      "display_url" : "instagram.com\/p\/m-mUYvhwqo\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.383700575, 4.902149125 ]
  },
  "id_str" : "457556168668635136",
  "text" : "The Crane @ Toren http:\/\/t.co\/fdlmk1MPDO",
  "id" : 457556168668635136,
  "created_at" : "2014-04-19 16:27:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3667503408, 4.9340231568 ]
  },
  "id_str" : "457257368565604353",
  "text" : "\u00ABWollte der uns Pappen als Isomattenersatz andrehen?\u00BB \u2014 \u00ABHobo approved.\u00BB \u2014 \u00ABAh, dann wei\u00DF ich jetzt wieso er uns gefragt hat.\u00BB",
  "id" : 457257368565604353,
  "created_at" : "2014-04-18 20:40:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3663808895, 4.9342836884 ]
  },
  "id_str" : "457187244462596096",
  "text" : "\u00ABIch finde man kann nicht einen auf Leuchtturm der Toleranz machen und dann emp\u00F6rt sein wenn Leute sich den Leuchtturm einf\u00FChren wollen.\u00BB",
  "id" : 457187244462596096,
  "created_at" : "2014-04-18 16:01:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/ktiarddfiN",
      "expanded_url" : "http:\/\/mag.newsweek.com\/2014\/04\/25\/tourism-construction-ongoing-nuclear-crisis-chernobyl.html",
      "display_url" : "mag.newsweek.com\/2014\/04\/25\/tou\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36521562, 4.95962632 ]
  },
  "id_str" : "457150064461619200",
  "text" : "Tourism, Construction and an Ongoing Nuclear Crisis at Chernobyl http:\/\/t.co\/ktiarddfiN",
  "id" : 457150064461619200,
  "created_at" : "2014-04-18 13:34:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/23IRfA2Bvt",
      "expanded_url" : "http:\/\/animalnewyork.com\/2014\/art-war-coby-kennedy-turns-brooklyn-street-signs-post-apocalyptic-weapons\/",
      "display_url" : "animalnewyork.com\/2014\/art-war-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "457139452352032770",
  "text" : "Art of War: Coby Kennedy Turns Brooklyn Street Signs Into Post-Apocalyptic Weapons http:\/\/t.co\/23IRfA2Bvt",
  "id" : 457139452352032770,
  "created_at" : "2014-04-18 12:51:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/vh0YSJYBBV",
      "expanded_url" : "http:\/\/blogs.plos.org\/everyone\/2014\/04\/17\/beating-odds-goats-better-gamers-sheep\/",
      "display_url" : "blogs.plos.org\/everyone\/2014\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36521562, 4.95962632 ]
  },
  "id_str" : "457138874951958528",
  "text" : "Beating the Odds: Are Goats Better Gamers than Sheep? http:\/\/t.co\/vh0YSJYBBV",
  "id" : 457138874951958528,
  "created_at" : "2014-04-18 12:49:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/oAacRz9PaX",
      "expanded_url" : "http:\/\/i.imgur.com\/hEQot1k.gif",
      "display_url" : "i.imgur.com\/hEQot1k.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36521562, 4.95962632 ]
  },
  "id_str" : "457137769157238784",
  "text" : "\u00ABSo sehen wir bestimmt auch manchmal aus: \u2018Wah, geh von mir runter!\u2019\u00BB http:\/\/t.co\/oAacRz9PaX",
  "id" : 457137769157238784,
  "created_at" : "2014-04-18 12:45:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 97, 110 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/c7zjG1exXV",
      "expanded_url" : "http:\/\/www.plosgenetics.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pgen.1004301",
      "display_url" : "plosgenetics.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3654592, 4.95933517 ]
  },
  "id_str" : "456912921747263488",
  "text" : "Diverged Regulation of X-chromosomal Genes as a Primal Event in Mouse Reproductive Isolation \/cc @PhilippBayer http:\/\/t.co\/c7zjG1exXV",
  "id" : 456912921747263488,
  "created_at" : "2014-04-17 21:51:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/WVFeP1xXcc",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/83016406774\/its-all-about-the-journey",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/830164067\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3654592, 4.95933517 ]
  },
  "id_str" : "456908404444106752",
  "text" : "probably how @Lobot and I look like while trying to get into our tent http:\/\/t.co\/WVFeP1xXcc",
  "id" : 456908404444106752,
  "created_at" : "2014-04-17 21:33:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3654592, 4.95933517 ]
  },
  "id_str" : "456897549962870784",
  "text" : "\u00ABIch glaube wir haben was falsch gemacht: Mein Penis qualmt!\u00BB \u2013 \u00ABWei\u00DFer Rauch? Wir haben einen neuen Poly-Papst!\u00BB",
  "id" : 456897549962870784,
  "created_at" : "2014-04-17 20:50:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3654879079, 4.9592749011 ]
  },
  "id_str" : "456879434851954688",
  "text" : "\u00ABSt\u00F6rt es dich wenn ich Fleisch esse?\u00BB \u2014 \u00ABNein nein, deine moralischen Entscheidungen sind deine ganz allein\u2026\u00BB",
  "id" : 456879434851954688,
  "created_at" : "2014-04-17 19:38:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Walk off the Earth",
      "screen_name" : "WalkOffTheEarth",
      "indices" : [ 0, 16 ],
      "id_str" : "34027831",
      "id" : 34027831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/hI6H0vxQvE",
      "expanded_url" : "http:\/\/instagram.com\/p\/m3GXUDhwnO\/",
      "display_url" : "instagram.com\/p\/m3GXUDhwnO\/"
    } ]
  },
  "in_reply_to_status_id_str" : "456497399964254209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3620599545, 4.8837757644 ]
  },
  "id_str" : "456501205707915264",
  "in_reply_to_user_id" : 34027831,
  "text" : "@WalkOffTheEarth Amazing, you\u2019re there as well?! @ Paradiso Amsterdam http:\/\/t.co\/hI6H0vxQvE",
  "id" : 456501205707915264,
  "in_reply_to_status_id" : 456497399964254209,
  "created_at" : "2014-04-16 18:35:43 +0000",
  "in_reply_to_screen_name" : "WalkOffTheEarth",
  "in_reply_to_user_id_str" : "34027831",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3593209644, 4.871943566 ]
  },
  "id_str" : "456475852977360896",
  "text" : "\u00ABNat\u00FCrlich sende ich Pers\u00F6nliches nicht per copy\/paste rum. Daf\u00FCr gibt es Textbausteine: \u2018Schlaf gut $spitzname, ich liebe dich auch sehr\u2019.\u00BB",
  "id" : 456475852977360896,
  "created_at" : "2014-04-16 16:54:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3684408455, 4.8965714308 ]
  },
  "id_str" : "456429776887373824",
  "text" : "Am Nebentisch: \u2018Und ein Waschbecken, so gro\u00DF wie eine Faust!\u2019 Sch\u00F6n das auch andere Menschen das als Unit of Measurement nutzen.",
  "id" : 456429776887373824,
  "created_at" : "2014-04-16 13:51:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456289000970407936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3661086652, 4.9772682454 ]
  },
  "id_str" : "456350094904655872",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thx!",
  "id" : 456350094904655872,
  "in_reply_to_status_id" : 456289000970407936,
  "created_at" : "2014-04-16 08:35:15 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3646467366, 4.961583009 ]
  },
  "id_str" : "456177546338766848",
  "text" : "\u00ABGlobuli mit Bier runtersp\u00FClen?! Da kannste es ja gleich sein lassen!\u00BB",
  "id" : 456177546338766848,
  "created_at" : "2014-04-15 21:09:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095442688, 8.2830044379 ]
  },
  "id_str" : "456040574349770752",
  "text" : "Off to do some fieldwork. Sounds much nicer than \u2018we fucked up booking the rooms, so I\u2019ll do my writing in a tent\u2019, doesn\u2019t it?",
  "id" : 456040574349770752,
  "created_at" : "2014-04-15 12:05:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456030902439927808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096542241, 8.282953291 ]
  },
  "id_str" : "456032754829119489",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente I made a habit out of at least joining my group for lunch, so that\u2019s 5 meals a week, besides that it really depends.",
  "id" : 456032754829119489,
  "in_reply_to_status_id" : 456030902439927808,
  "created_at" : "2014-04-15 11:34:16 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096532525, 8.2830738413 ]
  },
  "id_str" : "456029924126896128",
  "text" : "I really should measure my stress levels somehow and look for a correlation to weight (loss). Dropped below 60 kg again.",
  "id" : 456029924126896128,
  "created_at" : "2014-04-15 11:23:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096939069, 8.2831450674 ]
  },
  "id_str" : "455860377109417985",
  "text" : "Approaching the point where my relationship lab notebook is in a better shape than my actual lab notebook. Not due to neglect of the latter.",
  "id" : 455860377109417985,
  "created_at" : "2014-04-15 00:09:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455852523274780672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096376753, 8.283099141 ]
  },
  "id_str" : "455852609652686848",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer awesome, thanks! :)",
  "id" : 455852609652686848,
  "in_reply_to_status_id" : 455852523274780672,
  "created_at" : "2014-04-14 23:38:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455851306670780416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096710127, 8.2829837111 ]
  },
  "id_str" : "455851425881665537",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer pls drop if it\u2019s not there already. :)",
  "id" : 455851425881665537,
  "in_reply_to_status_id" : 455851306670780416,
  "created_at" : "2014-04-14 23:33:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 92, 104 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/HnYdinMEyi",
      "expanded_url" : "https:\/\/theconversation.com\/invasive-species-if-we-cant-beat-them-maybe-we-should-eat-them-25244",
      "display_url" : "theconversation.com\/invasive-speci\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096360774, 8.28298841 ]
  },
  "id_str" : "455824107511508992",
  "text" : "Eating invasive species. That\u2019s just my brand of vegetarianism. https:\/\/t.co\/HnYdinMEyi \/HT @AkshatRathi",
  "id" : 455824107511508992,
  "created_at" : "2014-04-14 21:45:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096814547, 8.2831232187 ]
  },
  "id_str" : "455818850685452289",
  "text" : "\u00ABI always thought those bioinformaticians wouldn\u2019t work. Coming at 10am, leaving at 5pm.\u00BB \u2014 \u00ABAnd so you decided to become one as well?\u00BB",
  "id" : 455818850685452289,
  "created_at" : "2014-04-14 21:24:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455805236985487360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.101396762, 8.6443819269 ]
  },
  "id_str" : "455806309188001792",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC good thing the \u2018dirty hippie\u2019 look is also some kind of uniform. :p",
  "id" : 455806309188001792,
  "in_reply_to_status_id" : 455805236985487360,
  "created_at" : "2014-04-14 20:34:27 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455777598141136896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1058477583, 8.6643847078 ]
  },
  "id_str" : "455801394206101506",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC that\u2019s too obvious ;)",
  "id" : 455801394206101506,
  "in_reply_to_status_id" : 455777598141136896,
  "created_at" : "2014-04-14 20:14:55 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455718998869835776",
  "text" : "\u00ABDie Packliste f\u00FCr dich: Kondome, Lube, Minipenis, Gitarre, Schlafsack (just in case), keine B\u00FCrste\u00BB \u2013 \u00ABRockstar-Packliste!\u00BB",
  "id" : 455718998869835776,
  "created_at" : "2014-04-14 14:47:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alison Atkin",
      "screen_name" : "alisonatkin",
      "indices" : [ 3, 15 ],
      "id_str" : "21301376",
      "id" : 21301376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/W4CjNFq9iY",
      "expanded_url" : "http:\/\/youtu.be\/sZMaheZ_Iy0",
      "display_url" : "youtu.be\/sZMaheZ_Iy0"
    } ]
  },
  "geo" : { },
  "id_str" : "455712154168348672",
  "text" : "RT @alisonatkin: The Final Member: http:\/\/t.co\/W4CjNFq9iY A documentary about the first human penis to be donated to the only penis museum.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr Ben Garrod",
        "screen_name" : "Ben_garrod",
        "indices" : [ 127, 138 ],
        "id_str" : "415472140",
        "id" : 415472140
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/W4CjNFq9iY",
        "expanded_url" : "http:\/\/youtu.be\/sZMaheZ_Iy0",
        "display_url" : "youtu.be\/sZMaheZ_Iy0"
      } ]
    },
    "geo" : { },
    "id_str" : "455695445965037568",
    "text" : "The Final Member: http:\/\/t.co\/W4CjNFq9iY A documentary about the first human penis to be donated to the only penis museum. cc: @Ben_garrod",
    "id" : 455695445965037568,
    "created_at" : "2014-04-14 13:13:55 +0000",
    "user" : {
      "name" : "Alison Atkin",
      "screen_name" : "alisonatkin",
      "protected" : false,
      "id_str" : "21301376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895261979425820672\/tuG5Cs3h_normal.jpg",
      "id" : 21301376,
      "verified" : false
    }
  },
  "id" : 455712154168348672,
  "created_at" : "2014-04-14 14:20:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastien Chevreux",
      "screen_name" : "BaCh_mira",
      "indices" : [ 45, 55 ],
      "id_str" : "360258516",
      "id" : 360258516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455661744405635073",
  "text" : "By now we reference our assembler bible, the @BaCh_mira manual, in style: \u00ABIn Chevreux 3:14 it is written: 'Thou shall not use NFS mounts'.\u00BB",
  "id" : 455661744405635073,
  "created_at" : "2014-04-14 11:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455659938669686784",
  "text" : "\u00ABDu magst deinen Kaffee ja wie deine Seele.\u00BB \u2013 \u00ABSchwarz UND s\u00FC\u00DF?!\u00BB",
  "id" : 455659938669686784,
  "created_at" : "2014-04-14 10:52:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 121, 134 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455635507872296960",
  "text" : "\u00ABNot recommended for: [\u2026] The squeamish. Those who believe in humans.\u00BB (5 stars) Oh, how I like the goodreads reviews by @PhilippBayer!",
  "id" : 455635507872296960,
  "created_at" : "2014-04-14 09:15:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455627768852910080",
  "geo" : { },
  "id_str" : "455633916955594752",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC you're more into a crown of thorns? ;)",
  "id" : 455633916955594752,
  "in_reply_to_status_id" : 455627768852910080,
  "created_at" : "2014-04-14 09:09:25 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455627256912957440",
  "geo" : { },
  "id_str" : "455629788489998337",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot so far it's more like crash ALL THE nodes.",
  "id" : 455629788489998337,
  "in_reply_to_status_id" : 455627256912957440,
  "created_at" : "2014-04-14 08:53:01 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455623873602801664",
  "geo" : { },
  "id_str" : "455625374232485888",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC and I guess flowers in your hair are okay as long as they are black roses.",
  "id" : 455625374232485888,
  "in_reply_to_status_id" : 455623873602801664,
  "created_at" : "2014-04-14 08:35:28 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455625129838792704",
  "text" : "\u00ABRestarting jobs, okay, but also use your holidays as such!\u00BB \u2013 \u00ABHolidays are used to work on the science projects you're not paying me for.\u00BB",
  "id" : 455625129838792704,
  "created_at" : "2014-04-14 08:34:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455619034072248320",
  "text" : "\u00ABDone. Done all filtering. Failure, process aborted.\u00BB Debugging, such a fun job with verbose log files like this!",
  "id" : 455619034072248320,
  "created_at" : "2014-04-14 08:10:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455613041221312512",
  "geo" : { },
  "id_str" : "455618779939360768",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC that's fine, why shouldn't you turn tables with respect to confrontation therapy. (doesn't liking that song hurt your cred? ;))",
  "id" : 455618779939360768,
  "in_reply_to_status_id" : 455613041221312512,
  "created_at" : "2014-04-14 08:09:16 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172336961, 8.6276106107 ]
  },
  "id_str" : "455609751628705792",
  "text" : "\u00ABIhr wurdet angemeckert weil ihr einem Obdachlosen Eis gegeben habt? Weil er das Eis nur f\u00FCr Schnaps ausgibt oder wie?\u00BB",
  "id" : 455609751628705792,
  "created_at" : "2014-04-14 07:33:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thehorror",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455491798925070336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0071017276, 8.2830833005 ]
  },
  "id_str" : "455589693917495296",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I really liked that song. Until my parents used it as the only bckgrnd song 4 their 500+ picture California slide show\u2026 #thehorror",
  "id" : 455589693917495296,
  "in_reply_to_status_id" : 455491798925070336,
  "created_at" : "2014-04-14 06:13:42 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455443206751404032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096206231, 8.2829150819 ]
  },
  "id_str" : "455444970724687872",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon immerhin: ich hatte mit Briefbombe gerechnet und den Umschlag deshalb einfach auf deinen Schreibtisch gelegt.",
  "id" : 455444970724687872,
  "in_reply_to_status_id" : 455443206751404032,
  "created_at" : "2014-04-13 20:38:37 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AP English Problems",
      "screen_name" : "APEnglish_Probs",
      "indices" : [ 3, 19 ],
      "id_str" : "1892210064",
      "id" : 1892210064
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/APEnglish_Probs\/status\/446789864147517440\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/tsguF9slhs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjNRA5eCQAAfZTB.jpg",
      "id_str" : "446789863908458496",
      "id" : 446789863908458496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjNRA5eCQAAfZTB.jpg",
      "sizes" : [ {
        "h" : 879,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 879,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 584,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 879,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tsguF9slhs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455396546381901824",
  "text" : "RT @APEnglish_Probs: I shit you not. http:\/\/t.co\/tsguF9slhs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/APEnglish_Probs\/status\/446789864147517440\/photo\/1",
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/tsguF9slhs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjNRA5eCQAAfZTB.jpg",
        "id_str" : "446789863908458496",
        "id" : 446789863908458496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjNRA5eCQAAfZTB.jpg",
        "sizes" : [ {
          "h" : 879,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 879,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 584,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 879,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/tsguF9slhs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "446789864147517440",
    "text" : "I shit you not. http:\/\/t.co\/tsguF9slhs",
    "id" : 446789864147517440,
    "created_at" : "2014-03-20 23:26:19 +0000",
    "user" : {
      "name" : "AP English Problems",
      "screen_name" : "APEnglish_Probs",
      "protected" : false,
      "id_str" : "1892210064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000704387626\/813610de25cb88260e09d740e3d76e79_normal.jpeg",
      "id" : 1892210064,
      "verified" : false
    }
  },
  "id" : 455396546381901824,
  "created_at" : "2014-04-13 17:26:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096548351, 8.2829705981 ]
  },
  "id_str" : "455389414429323264",
  "text" : "Nice way of sobering up: walking home 15 km the next day.",
  "id" : 455389414429323264,
  "created_at" : "2014-04-13 16:57:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/Zy0kxfqqek",
      "expanded_url" : "http:\/\/instagram.com\/p\/mvMulzBwiC\/",
      "display_url" : "instagram.com\/p\/mvMulzBwiC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "455388829592334336",
  "text" : "Kastel\/Am\u00F6neburg http:\/\/t.co\/Zy0kxfqqek",
  "id" : 455388829592334336,
  "created_at" : "2014-04-13 16:55:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455351592402046976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.082304451, 8.2465121429 ]
  },
  "id_str" : "455351770613837825",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 das steht da nicht. Vielleicht ist die Milchkuh auch kopf\u00FCber halb verbuddelt?",
  "id" : 455351770613837825,
  "in_reply_to_status_id" : 455351592402046976,
  "created_at" : "2014-04-13 14:28:16 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Discordiale",
      "screen_name" : "TeeJaneS",
      "indices" : [ 0, 9 ],
      "id_str" : "54601848",
      "id" : 54601848
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 10, 17 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/TWh5xWGG4A",
      "expanded_url" : "http:\/\/www.hofzurhellen.de\/praeparate.html",
      "display_url" : "hofzurhellen.de\/praeparate.html"
    } ]
  },
  "in_reply_to_status_id_str" : "455332112829542402",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1003204485, 8.2649212207 ]
  },
  "id_str" : "455332438819237890",
  "in_reply_to_user_id" : 54601848,
  "text" : "@TeeJaneS @Seb666 ich meine wegen http:\/\/t.co\/TWh5xWGG4A",
  "id" : 455332438819237890,
  "in_reply_to_status_id" : 455332112829542402,
  "created_at" : "2014-04-13 13:11:27 +0000",
  "in_reply_to_screen_name" : "TeeJaneS",
  "in_reply_to_user_id_str" : "54601848",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 44, 51 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/455330407484243968\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/WPwDLmGCji",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlGol78IMAEYCuc.jpg",
      "id_str" : "455330407039643649",
      "id" : 455330407039643649,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlGol78IMAEYCuc.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/WPwDLmGCji"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1003204485, 8.2649212207 ]
  },
  "id_str" : "455330407484243968",
  "text" : "Woher kommt eigentlich dieser Horn-Fetisch? @seb666 hilf! http:\/\/t.co\/WPwDLmGCji",
  "id" : 455330407484243968,
  "created_at" : "2014-04-13 13:03:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1003290942, 8.2649588924 ]
  },
  "id_str" : "455324336917069824",
  "text" : "\u00ABVorsicht, die k\u00F6nnen deine Hirnstr\u00F6me lesen!\u00BB \u2014 \u00ABKeine Sorge, da passiert heute nicht viel\u2026\u00BB",
  "id" : 455324336917069824,
  "created_at" : "2014-04-13 12:39:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lara",
      "screen_name" : "alibi_ranch",
      "indices" : [ 0, 12 ],
      "id_str" : "265371167",
      "id" : 265371167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455311685889556481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1003668488, 8.2648722184 ]
  },
  "id_str" : "455312487546912769",
  "in_reply_to_user_id" : 265371167,
  "text" : "@alibi_ranch thanks &lt;3",
  "id" : 455312487546912769,
  "in_reply_to_status_id" : 455311685889556481,
  "created_at" : "2014-04-13 11:52:10 +0000",
  "in_reply_to_screen_name" : "alibi_ranch",
  "in_reply_to_user_id_str" : "265371167",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/BHZSoqE0Zi",
      "expanded_url" : "http:\/\/instagram.com\/p\/mug-Trhwt6\/",
      "display_url" : "instagram.com\/p\/mug-Trhwt6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "455292612061446144",
  "text" : "Homo sapiens pumilionis (and my botany skills fail me for the flowers) http:\/\/t.co\/BHZSoqE0Zi",
  "id" : 455292612061446144,
  "created_at" : "2014-04-13 10:33:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/DaXqQJkmkA",
      "expanded_url" : "http:\/\/instagram.com\/p\/muc6fgBwph\/",
      "display_url" : "instagram.com\/p\/muc6fgBwph\/"
    } ]
  },
  "geo" : { },
  "id_str" : "455283685504610304",
  "text" : "Salamandra salamandra http:\/\/t.co\/DaXqQJkmkA",
  "id" : 455283685504610304,
  "created_at" : "2014-04-13 09:57:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 0, 14 ],
      "id_str" : "16066596",
      "id" : 16066596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455272243845931008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10037832, 8.2648656264 ]
  },
  "id_str" : "455272505276891136",
  "in_reply_to_user_id" : 16066596,
  "text" : "@onetruecathal I have to disappoint you, it\u2019s not me in the tree, I\u2019m more a fan of the aquatic ape theory. ;)",
  "id" : 455272505276891136,
  "in_reply_to_status_id" : 455272243845931008,
  "created_at" : "2014-04-13 09:13:18 +0000",
  "in_reply_to_screen_name" : "onetruecathal",
  "in_reply_to_user_id_str" : "16066596",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/R3wZ6YQi4o",
      "expanded_url" : "http:\/\/instagram.com\/p\/muWZfIBwji\/",
      "display_url" : "instagram.com\/p\/muWZfIBwji\/"
    } ]
  },
  "geo" : { },
  "id_str" : "455269356000530432",
  "text" : "Treehugging http:\/\/t.co\/R3wZ6YQi4o",
  "id" : 455269356000530432,
  "created_at" : "2014-04-13 09:00:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1003857127, 8.2647455226 ]
  },
  "id_str" : "455156165706780672",
  "text" : "\u00ABWir brauchen noch einen Namen f\u00FCr unsere Bezugsgruppe.\u00BB \u2014 \u00ABWir w\u00E4re \u2018Menschenhasser die den Abend nicht allein verbringen wollen\u2019?\u00BB",
  "id" : 455156165706780672,
  "created_at" : "2014-04-13 01:31:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/yGZ51A0vm3",
      "expanded_url" : "http:\/\/instagram.com\/p\/ms-fyXBwkq\/",
      "display_url" : "instagram.com\/p\/ms-fyXBwkq\/"
    } ]
  },
  "geo" : { },
  "id_str" : "455076074683383808",
  "text" : "Penis! http:\/\/t.co\/yGZ51A0vm3",
  "id" : 455076074683383808,
  "created_at" : "2014-04-12 20:12:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 70, 79 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1004974358, 8.264611594 ]
  },
  "id_str" : "455071085823000576",
  "text" : "By now \u2018Raining Blood\u2019 works on a right handed 12-string. Though luck @Senficon!",
  "id" : 455071085823000576,
  "created_at" : "2014-04-12 19:52:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1054558205, 8.2506238762 ]
  },
  "id_str" : "455008341660803073",
  "text" : "\u00ABEigent\u00FCmer sind b\u00FCrgerliche Kategorien. Aber das ist mein Stockbrot-Stock!\u00BB",
  "id" : 455008341660803073,
  "created_at" : "2014-04-12 15:43:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454991367379632128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1050921716, 8.2508770935 ]
  },
  "id_str" : "454993877817360384",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC do enough insertions and you\u2019re bound to do significant damage by chance.",
  "id" : 454993877817360384,
  "in_reply_to_status_id" : 454991367379632128,
  "created_at" : "2014-04-12 14:46:08 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454989649317224450",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1050727256, 8.2506724913 ]
  },
  "id_str" : "454990969583435776",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC that sounds like it\u2019s due to a multiple testing problem.",
  "id" : 454990969583435776,
  "in_reply_to_status_id" : 454989649317224450,
  "created_at" : "2014-04-12 14:34:35 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1049971628, 8.2507849764 ]
  },
  "id_str" : "454988661596368896",
  "text" : "\u00ABPromisk sein ist ja nicht schlimm. Aber wie Berlin sein schon!\u00BB",
  "id" : 454988661596368896,
  "created_at" : "2014-04-12 14:25:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sofakante",
      "screen_name" : "sofakante",
      "indices" : [ 0, 10 ],
      "id_str" : "473809383",
      "id" : 473809383
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 11, 18 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 19, 28 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454903771429367808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096147097, 8.282977109 ]
  },
  "id_str" : "454940219868209152",
  "in_reply_to_user_id" : 473809383,
  "text" : "@sofakante @Seb666 @Senficon was macht das Greinerwasser eigentlich?",
  "id" : 454940219868209152,
  "in_reply_to_status_id" : 454903771429367808,
  "created_at" : "2014-04-12 11:12:55 +0000",
  "in_reply_to_screen_name" : "sofakante",
  "in_reply_to_user_id_str" : "473809383",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/wLTYON99f4",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/roots-of-unity\/2014\/04\/11\/measure-yourself-by-the-standard-of-the-capybara\/",
      "display_url" : "blogs.scientificamerican.com\/roots-of-unity\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096532525, 8.2830738413 ]
  },
  "id_str" : "454728462327357440",
  "text" : "\u00ABMeasure Yourself by the Standard of the Capybara\u00BB I wouldn\u2019t be too surprised if this were indeed an imperial unit\u2026 http:\/\/t.co\/wLTYON99f4",
  "id" : 454728462327357440,
  "created_at" : "2014-04-11 21:11:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454721596755046401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096532525, 8.2830738413 ]
  },
  "id_str" : "454724027442294784",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC after that S01E07 will most likely be \u2018Day of the Dead\u2019. Idea for S01E08: \u2018Running Bayesian Interference\u2019.",
  "id" : 454724027442294784,
  "in_reply_to_status_id" : 454721596755046401,
  "created_at" : "2014-04-11 20:53:51 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454710192417292288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0882177495, 8.5130477535 ]
  },
  "id_str" : "454710672606375937",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC S01E02: \u2018From Dusk Till Dawn\u2019, S01E03: \u2018Lapse of Judgement Day\u2019.",
  "id" : 454710672606375937,
  "in_reply_to_status_id" : 454710192417292288,
  "created_at" : "2014-04-11 20:00:47 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1030343749, 8.560321544 ]
  },
  "id_str" : "454708675459166209",
  "text" : "Now for the final challenge of today: not falling asleep on the train home.",
  "id" : 454708675459166209,
  "created_at" : "2014-04-11 19:52:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/zhVR1071E6",
      "expanded_url" : "http:\/\/instagram.com\/p\/mqMKJshwt5\/",
      "display_url" : "instagram.com\/p\/mqMKJshwt5\/"
    } ]
  },
  "geo" : { },
  "id_str" : "454683889609736192",
  "text" : "Meta http:\/\/t.co\/zhVR1071E6",
  "id" : 454683889609736192,
  "created_at" : "2014-04-11 18:14:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felix Neumann",
      "screen_name" : "fxneumann",
      "indices" : [ 19, 29 ],
      "id_str" : "43292041",
      "id" : 43292041
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/youngvulgarian\/status\/454333502742204416\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/zQJiw1SWSG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk4d6eECEAAEugo.png",
      "id_str" : "454333502750593024",
      "id" : 454333502750593024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk4d6eECEAAEugo.png",
      "sizes" : [ {
        "h" : 589,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 592
      } ],
      "display_url" : "pic.twitter.com\/zQJiw1SWSG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1136604193, 8.6785906105 ]
  },
  "id_str" : "454654146235617280",
  "text" : "Lalalalalalama! MT @fxneumann: Tiere anziehen ist b\u00F6se. [\u2026] Aber bei Batman-Lamas werde ich schwach. http:\/\/t.co\/zQJiw1SWSG",
  "id" : 454654146235617280,
  "created_at" : "2014-04-11 16:16:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/AeWxY1Pt0T",
      "expanded_url" : "http:\/\/scripts.irssi.org\/html\/oops.pl.html",
      "display_url" : "scripts.irssi.org\/html\/oops.pl.h\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "454607004032458752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322856, 8.627628234 ]
  },
  "id_str" : "454607166381752320",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy use http:\/\/t.co\/AeWxY1Pt0T :D",
  "id" : 454607166381752320,
  "in_reply_to_status_id" : 454607004032458752,
  "created_at" : "2014-04-11 13:09:29 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/6SCR7F46Uo",
      "expanded_url" : "http:\/\/sebpearce.com\/bullshit\/",
      "display_url" : "sebpearce.com\/bullshit\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322856, 8.627628234 ]
  },
  "id_str" : "454600556620029952",
  "text" : "New Age Bullshit Generator: \u00ABThrough faith healing, our chakras are immersed in inspiration.\u00BB http:\/\/t.co\/6SCR7F46Uo",
  "id" : 454600556620029952,
  "created_at" : "2014-04-11 12:43:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 7, 19 ],
      "id_str" : "48357885",
      "id" : 48357885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454598557027540993",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322856, 8.627628234 ]
  },
  "id_str" : "454598848376496130",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Whitey_chan Schnell zum T\u00DCV damit.",
  "id" : 454598848376496130,
  "in_reply_to_status_id" : 454598557027540993,
  "created_at" : "2014-04-11 12:36:26 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322856, 8.627628234 ]
  },
  "id_str" : "454594874915184640",
  "text" : "\u00ABWhat\u2019s happening?!\u00BB \u2013 \u00ABOh, nothing, there\u2019s just a tornado across the street.\u00BB",
  "id" : 454594874915184640,
  "created_at" : "2014-04-11 12:20:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 0, 12 ],
      "id_str" : "48357885",
      "id" : 48357885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454593238889168896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322856, 8.627628234 ]
  },
  "id_str" : "454594541820313600",
  "in_reply_to_user_id" : 48357885,
  "text" : "@Whitey_chan okay, dann bin ich gespannt womit du aufwarten kannst.",
  "id" : 454594541820313600,
  "in_reply_to_status_id" : 454593238889168896,
  "created_at" : "2014-04-11 12:19:19 +0000",
  "in_reply_to_screen_name" : "Whitey_chan",
  "in_reply_to_user_id_str" : "48357885",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 0, 12 ],
      "id_str" : "48357885",
      "id" : 48357885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "damnautocorrect",
      "indices" : [ 25, 41 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454591981642350592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723247457, 8.6276182128 ]
  },
  "id_str" : "454593158434013184",
  "in_reply_to_user_id" : 48357885,
  "text" : "@Whitey_chan \u2018at first\u2019! #damnautocorrect",
  "id" : 454593158434013184,
  "in_reply_to_status_id" : 454591981642350592,
  "created_at" : "2014-04-11 12:13:49 +0000",
  "in_reply_to_screen_name" : "Whitey_chan",
  "in_reply_to_user_id_str" : "48357885",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 0, 12 ],
      "id_str" : "48357885",
      "id" : 48357885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454591981642350592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723535907, 8.6275394859 ]
  },
  "id_str" : "454593018759491584",
  "in_reply_to_user_id" : 48357885,
  "text" : "@Whitey_chan ah, at fist I thought of a tumblr about the expeditions.",
  "id" : 454593018759491584,
  "in_reply_to_status_id" : 454591981642350592,
  "created_at" : "2014-04-11 12:13:16 +0000",
  "in_reply_to_screen_name" : "Whitey_chan",
  "in_reply_to_user_id_str" : "48357885",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 0, 12 ],
      "id_str" : "48357885",
      "id" : 48357885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454591633435426816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322856, 8.627628234 ]
  },
  "id_str" : "454591782710673408",
  "in_reply_to_user_id" : 48357885,
  "text" : "@Whitey_chan jetzt bin ich vor allem puzzled was das Topic des Tumblrs sein w\u00FCrde. ;)",
  "id" : 454591782710673408,
  "in_reply_to_status_id" : 454591633435426816,
  "created_at" : "2014-04-11 12:08:21 +0000",
  "in_reply_to_screen_name" : "Whitey_chan",
  "in_reply_to_user_id_str" : "48357885",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454561161321910272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723409993, 8.6275843916 ]
  },
  "id_str" : "454561347582586880",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog das ist das beste: An der Uni haben sie ihre Propaganda ausgelegt :D",
  "id" : 454561347582586880,
  "in_reply_to_status_id" : 454561161321910272,
  "created_at" : "2014-04-11 10:07:25 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723420835, 8.6276009487 ]
  },
  "id_str" : "454560540984356864",
  "text" : "\u00ABEs werden belanglose Einzelheiten, wie z.B. die Methodik einer Studie, kritisiert.\u00BB Diese \u2018Milch-macht-Krebs\u2019-Spinner sind echte Experten\u2026",
  "id" : 454560540984356864,
  "created_at" : "2014-04-11 10:04:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/sr2UdpEC0R",
      "expanded_url" : "http:\/\/i.imgur.com\/gfOyOHS.gif",
      "display_url" : "i.imgur.com\/gfOyOHS.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322856, 8.627628234 ]
  },
  "id_str" : "454552124589113344",
  "text" : "So far the students brought me 5 espresso. My brain slowly starts to work again. What I probably should have done: http:\/\/t.co\/sr2UdpEC0R",
  "id" : 454552124589113344,
  "created_at" : "2014-04-11 09:30:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niels-Arne M\u00FCnck",
      "screen_name" : "Wernermuende",
      "indices" : [ 0, 13 ],
      "id_str" : "56502413",
      "id" : 56502413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454549696695250944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322856, 8.627628234 ]
  },
  "id_str" : "454550176800444416",
  "in_reply_to_user_id" : 56502413,
  "text" : "@Wernermuende das geht auch. Ich hab auch keine pers\u00F6nlichen Erfahrungen mit dem v4 Chip den 23andMe jetzt nutzt.",
  "id" : 454550176800444416,
  "in_reply_to_status_id" : 454549696695250944,
  "created_at" : "2014-04-11 09:23:01 +0000",
  "in_reply_to_screen_name" : "Wernermuende",
  "in_reply_to_user_id_str" : "56502413",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niels-Arne M\u00FCnck",
      "screen_name" : "Wernermuende",
      "indices" : [ 0, 13 ],
      "id_str" : "56502413",
      "id" : 56502413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454547795597590528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172324656, 8.6276188039 ]
  },
  "id_str" : "454548065459142656",
  "in_reply_to_user_id" : 56502413,
  "text" : "@Wernermuende ja, die sind tats\u00E4chlich abschreckend. Aber daf\u00FCr geht es fix. 3 -4 Tage f\u00FCr turnaround CA -&gt; DE -&gt; CA",
  "id" : 454548065459142656,
  "in_reply_to_status_id" : 454547795597590528,
  "created_at" : "2014-04-11 09:14:38 +0000",
  "in_reply_to_screen_name" : "Wernermuende",
  "in_reply_to_user_id_str" : "56502413",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niels-Arne M\u00FCnck",
      "screen_name" : "Wernermuende",
      "indices" : [ 0, 13 ],
      "id_str" : "56502413",
      "id" : 56502413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454545931300777984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172324656, 8.6276188039 ]
  },
  "id_str" : "454546215129329664",
  "in_reply_to_user_id" : 56502413,
  "text" : "@Wernermuende genau, oder z.B. Promethease von der SNPedia nutzen (oder bei openSNP hochladen ;))",
  "id" : 454546215129329664,
  "in_reply_to_status_id" : 454545931300777984,
  "created_at" : "2014-04-11 09:07:17 +0000",
  "in_reply_to_screen_name" : "Wernermuende",
  "in_reply_to_user_id_str" : "56502413",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niels-Arne M\u00FCnck",
      "screen_name" : "Wernermuende",
      "indices" : [ 0, 13 ],
      "id_str" : "56502413",
      "id" : 56502413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454544737828352000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723153134, 8.6276191033 ]
  },
  "id_str" : "454545648474656768",
  "in_reply_to_user_id" : 56502413,
  "text" : "@Wernermuende 23andMe bieten noch Kits an. iirc gibt es nur keine medizinische Auswertung mehr sondern nur ancestry.",
  "id" : 454545648474656768,
  "in_reply_to_status_id" : 454544737828352000,
  "created_at" : "2014-04-11 09:05:02 +0000",
  "in_reply_to_screen_name" : "Wernermuende",
  "in_reply_to_user_id_str" : "56502413",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niels-Arne M\u00FCnck",
      "screen_name" : "Wernermuende",
      "indices" : [ 0, 13 ],
      "id_str" : "56502413",
      "id" : 56502413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454543947369820160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322856, 8.627628234 ]
  },
  "id_str" : "454544241608642561",
  "in_reply_to_user_id" : 56502413,
  "text" : "@Wernermuende nope, but yet another phenotype idea we could add to openSNP ;)",
  "id" : 454544241608642561,
  "in_reply_to_status_id" : 454543947369820160,
  "created_at" : "2014-04-11 08:59:26 +0000",
  "in_reply_to_screen_name" : "Wernermuende",
  "in_reply_to_user_id_str" : "56502413",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454536002976350208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723325938, 8.6276137474 ]
  },
  "id_str" : "454537616122466304",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich \u2018so, today we have a nifty example for small hamming distances\u2019.",
  "id" : 454537616122466304,
  "in_reply_to_status_id" : 454536002976350208,
  "created_at" : "2014-04-11 08:33:07 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454536727743696896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723325938, 8.6276137474 ]
  },
  "id_str" : "454536874905055233",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon the left the details pretty open\u2026",
  "id" : 454536874905055233,
  "in_reply_to_status_id" : 454536727743696896,
  "created_at" : "2014-04-11 08:30:10 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454535330130313216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723325938, 8.6276137474 ]
  },
  "id_str" : "454536164360601601",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon that wasn\u2019t even part of the job description!",
  "id" : 454536164360601601,
  "in_reply_to_status_id" : 454535330130313216,
  "created_at" : "2014-04-11 08:27:21 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "autocorrect",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095556012, 8.2829635339 ]
  },
  "id_str" : "454534479022145536",
  "text" : "\u00ABGiven the raw data we probably will have to go for a fisting expedition\u2026\u00BB I shouldn\u2019t answer work emails from my smartphone\u2026 #autocorrect",
  "id" : 454534479022145536,
  "created_at" : "2014-04-11 08:20:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454449292498186240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0026723647, 8.3036800858 ]
  },
  "id_str" : "454496308876050433",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC \u2018Stranger in a Strange Land: The Series\u2019, S01E01: \u2018Shibboleth\u2019",
  "id" : 454496308876050433,
  "in_reply_to_status_id" : 454449292498186240,
  "created_at" : "2014-04-11 05:48:58 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/FnJ2GYrFwC",
      "expanded_url" : "http:\/\/www.memegags.com\/wp-content\/uploads\/2013\/10\/funny-image-2330.jpg",
      "display_url" : "memegags.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096390825, 8.2830315775 ]
  },
  "id_str" : "454402523831746560",
  "text" : "\u2018Where do you see yourself five years from now?\u2019 Well, I now do have a rough idea\u2026 http:\/\/t.co\/FnJ2GYrFwC",
  "id" : 454402523831746560,
  "created_at" : "2014-04-10 23:36:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/xb9scyea79",
      "expanded_url" : "http:\/\/the-science-llama.tumblr.com\/post\/47285210966\/which-house-do-you-belong-to",
      "display_url" : "the-science-llama.tumblr.com\/post\/472852109\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096390825, 8.2830315775 ]
  },
  "id_str" : "454378523067940865",
  "text" : "House LHC \u2013 Brothers Collide http:\/\/t.co\/xb9scyea79",
  "id" : 454378523067940865,
  "created_at" : "2014-04-10 22:00:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454373388157734912",
  "text" : "RT @pathogenomenick: Enjoy copying files? Love the sensation of clearing hard drive space? Thrill to conversion of file formats?! Become a \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "454244608177094656",
    "text" : "Enjoy copying files? Love the sensation of clearing hard drive space? Thrill to conversion of file formats?! Become a bioinformatician!",
    "id" : 454244608177094656,
    "created_at" : "2014-04-10 13:08:48 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 454373388157734912,
  "created_at" : "2014-04-10 21:40:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Hankins",
      "screen_name" : "mc_hankins",
      "indices" : [ 3, 14 ],
      "id_str" : "298729878",
      "id" : 298729878
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stillnotsignificant",
      "indices" : [ 112, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454362811716882433",
  "text" : "RT @mc_hankins: It has a certain, how you say, je ne l'aime pas: \"\u00E9tait proche de la signi\uFB01cativit\u00E9 (p = 0,07)\" #stillnotsignificant http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mc_hankins\/status\/454358299744296960\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/gq4A3YQNC3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk40d1nCMAAIOqP.png",
        "id_str" : "454358299622649856",
        "id" : 454358299622649856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk40d1nCMAAIOqP.png",
        "sizes" : [ {
          "h" : 54,
          "resize" : "fit",
          "w" : 1188
        }, {
          "h" : 54,
          "resize" : "fit",
          "w" : 1188
        }, {
          "h" : 31,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 54,
          "resize" : "crop",
          "w" : 54
        }, {
          "h" : 54,
          "resize" : "fit",
          "w" : 1188
        } ],
        "display_url" : "pic.twitter.com\/gq4A3YQNC3"
      } ],
      "hashtags" : [ {
        "text" : "stillnotsignificant",
        "indices" : [ 96, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "454358299744296960",
    "text" : "It has a certain, how you say, je ne l'aime pas: \"\u00E9tait proche de la signi\uFB01cativit\u00E9 (p = 0,07)\" #stillnotsignificant http:\/\/t.co\/gq4A3YQNC3",
    "id" : 454358299744296960,
    "created_at" : "2014-04-10 20:40:34 +0000",
    "user" : {
      "name" : "Matthew Hankins",
      "screen_name" : "mc_hankins",
      "protected" : false,
      "id_str" : "298729878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925822514126884865\/ShLktwti_normal.jpg",
      "id" : 298729878,
      "verified" : false
    }
  },
  "id" : 454362811716882433,
  "created_at" : "2014-04-10 20:58:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454352947129090048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096390825, 8.2830315775 ]
  },
  "id_str" : "454353025239617536",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich gerne. :)",
  "id" : 454353025239617536,
  "in_reply_to_status_id" : 454352947129090048,
  "created_at" : "2014-04-10 20:19:37 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454352681709371392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096390825, 8.2830315775 ]
  },
  "id_str" : "454352820469497856",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich 26\/27?",
  "id" : 454352820469497856,
  "in_reply_to_status_id" : 454352681709371392,
  "created_at" : "2014-04-10 20:18:48 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 0, 13 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454350106062753792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096390825, 8.2830315775 ]
  },
  "id_str" : "454350291279036417",
  "in_reply_to_user_id" : 1421360166,
  "text" : "@ToxXInFlames because we\u2019re a clever bunch that usually doesn\u2019t get caught!",
  "id" : 454350291279036417,
  "in_reply_to_status_id" : 454350106062753792,
  "created_at" : "2014-04-10 20:08:45 +0000",
  "in_reply_to_screen_name" : "ToxXInFlames",
  "in_reply_to_user_id_str" : "1421360166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454305513917149184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096202914, 8.2830717823 ]
  },
  "id_str" : "454308638895923200",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC the best wishes I sent like, uh, yesterday? ;)",
  "id" : 454308638895923200,
  "in_reply_to_status_id" : 454305513917149184,
  "created_at" : "2014-04-10 17:23:14 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454277059028992000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1084780708, 8.6548821857 ]
  },
  "id_str" : "454292175787151360",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I guess it\u2019s too late to use that as an excuse for my wishes gone wrong?",
  "id" : 454292175787151360,
  "in_reply_to_status_id" : 454277059028992000,
  "created_at" : "2014-04-10 16:17:49 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/fHDcvgI0Pk",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=itvvFfeLh84",
      "display_url" : "youtube.com\/watch?v=itvvFf\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322856, 8.627628234 ]
  },
  "id_str" : "454258368824475648",
  "text" : "reinforcing my opinions about social media experts https:\/\/t.co\/fHDcvgI0Pk",
  "id" : 454258368824475648,
  "created_at" : "2014-04-10 14:03:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454213664489619457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322856, 8.627628234 ]
  },
  "id_str" : "454215891870560257",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon as much as I like hating on Gibson: even I can\u2019t make a convincing case that they wouldn\u2019t be rock\u2019n\u2019roll\u2026",
  "id" : 454215891870560257,
  "in_reply_to_status_id" : 454213664489619457,
  "created_at" : "2014-04-10 11:14:42 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454214906381086720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322856, 8.627628234 ]
  },
  "id_str" : "454215143048900608",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon well, as far as I\u2019m concerned \u2018Alive\u2019 also only consists of \u2018wohoohohoa, i\u2019m still alive\u2019",
  "id" : 454215143048900608,
  "in_reply_to_status_id" : 454214906381086720,
  "created_at" : "2014-04-10 11:11:43 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454213840608460800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322856, 8.627628234 ]
  },
  "id_str" : "454214854061350912",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon I think I might even have to pass on Alive\u2026 But then: I also never shot a Pantera fan!",
  "id" : 454214854061350912,
  "in_reply_to_status_id" : 454213840608460800,
  "created_at" : "2014-04-10 11:10:34 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454213024321372161",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723342436, 8.627612453 ]
  },
  "id_str" : "454213443751772160",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon but I\u2019m neither more Beatles than the Stones nor did I learn piano instead of guitar!",
  "id" : 454213443751772160,
  "in_reply_to_status_id" : 454213024321372161,
  "created_at" : "2014-04-10 11:04:58 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/U7zSwLe7xE",
      "expanded_url" : "http:\/\/instagram.com\/p\/mm1vOEBwnl\/",
      "display_url" : "instagram.com\/p\/mm1vOEBwnl\/"
    } ]
  },
  "geo" : { },
  "id_str" : "454212373801603072",
  "text" : "The art collection on our whiteboard is growing: Rockstar Bioinformatician http:\/\/t.co\/U7zSwLe7xE",
  "id" : 454212373801603072,
  "created_at" : "2014-04-10 11:00:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Evan Harris",
      "screen_name" : "DrEvanHarris",
      "indices" : [ 3, 16 ],
      "id_str" : "88722311",
      "id" : 88722311
    }, {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "indices" : [ 46, 58 ],
      "id_str" : "6705042",
      "id" : 6705042
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tamiflu",
      "indices" : [ 66, 74 ]
    }, {
      "text" : "cochrane",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454176875016122368",
  "text" : "RT @DrEvanHarris: A *masterful* exposition by @bengoldacre on the #tamiflu #cochrane review &amp; the campaign for open data on medicines http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ben goldacre",
        "screen_name" : "bengoldacre",
        "indices" : [ 28, 40 ],
        "id_str" : "6705042",
        "id" : 6705042
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tamiflu",
        "indices" : [ 48, 56 ]
      }, {
        "text" : "cochrane",
        "indices" : [ 57, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/P9ZTtjk5fo",
        "expanded_url" : "http:\/\/gu.com\/p\/3zat8",
        "display_url" : "gu.com\/p\/3zat8"
      } ]
    },
    "geo" : { },
    "id_str" : "454173913535508480",
    "text" : "A *masterful* exposition by @bengoldacre on the #tamiflu #cochrane review &amp; the campaign for open data on medicines http:\/\/t.co\/P9ZTtjk5fo",
    "id" : 454173913535508480,
    "created_at" : "2014-04-10 08:27:53 +0000",
    "user" : {
      "name" : "Dr Evan Harris",
      "screen_name" : "DrEvanHarris",
      "protected" : false,
      "id_str" : "88722311",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756301761\/1_EH_low_res_normal.JPG",
      "id" : 88722311,
      "verified" : false
    }
  },
  "id" : 454176875016122368,
  "created_at" : "2014-04-10 08:39:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/kGZSHzBfOK",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0092302#s2",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322856, 8.627628234 ]
  },
  "id_str" : "454165271218229248",
  "text" : "Everything Is Permitted? People Intuitively Judge Immorality as Representative of Atheists http:\/\/t.co\/kGZSHzBfOK",
  "id" : 454165271218229248,
  "created_at" : "2014-04-10 07:53:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/Gr87eXFgPd",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1086",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322856, 8.627628234 ]
  },
  "id_str" : "454163211584294912",
  "text" : "the Hawthorne effect meets the impostor syndrome http:\/\/t.co\/Gr87eXFgPd",
  "id" : 454163211584294912,
  "created_at" : "2014-04-10 07:45:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454142821222875136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1041569771, 8.6499150628 ]
  },
  "id_str" : "454143143882280960",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon don\u2019t think so. He was pretty hungry and tired when he came home. Apart from that he\u2019s fine.",
  "id" : 454143143882280960,
  "in_reply_to_status_id" : 454142821222875136,
  "created_at" : "2014-04-10 06:25:37 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/QoxOrcZDBm",
      "expanded_url" : "http:\/\/instagram.com\/p\/mmQ8Sxhwu_\/",
      "display_url" : "instagram.com\/p\/mmQ8Sxhwu_\/"
    } ]
  },
  "geo" : { },
  "id_str" : "454131457892814849",
  "text" : "Nom http:\/\/t.co\/QoxOrcZDBm",
  "id" : 454131457892814849,
  "created_at" : "2014-04-10 05:39:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454054572026101760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096549838, 8.28305375 ]
  },
  "id_str" : "454057770833412096",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer someone should perform that analysis for the forums of the german pirateparty ;)",
  "id" : 454057770833412096,
  "in_reply_to_status_id" : 454054572026101760,
  "created_at" : "2014-04-10 00:46:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 108, 121 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/35cVzDbtuy",
      "expanded_url" : "http:\/\/socialinsilico.wordpress.com\/2014\/04\/09\/closing-time-predicting-when-users-will-leave-an-online-community-based-on-their-language-use\/",
      "display_url" : "socialinsilico.wordpress.com\/2014\/04\/09\/clo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096549838, 8.28305375 ]
  },
  "id_str" : "454052418511462401",
  "text" : "Predicting when users will leave an online community based on their language\u00A0use http:\/\/t.co\/35cVzDbtuy \/cc @PhilippBayer",
  "id" : 454052418511462401,
  "created_at" : "2014-04-10 00:25:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096742069, 8.2832998175 ]
  },
  "id_str" : "454042889241526272",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon guess who just came home!",
  "id" : 454042889241526272,
  "created_at" : "2014-04-09 23:47:15 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453987610114142208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097017655, 8.2831120799 ]
  },
  "id_str" : "453987932660322304",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon das herauszufinden \u00FCberlasse ich dir, Sherlock. :)",
  "id" : 453987932660322304,
  "in_reply_to_status_id" : 453987610114142208,
  "created_at" : "2014-04-09 20:08:52 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ToxX",
      "screen_name" : "ToxXInFlames",
      "indices" : [ 0, 13 ],
      "id_str" : "1421360166",
      "id" : 1421360166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453974650016759808",
  "geo" : { },
  "id_str" : "453987708768382979",
  "in_reply_to_user_id" : 1421360166,
  "text" : "@ToxXInFlames Aber der Installateur hat doch das Safeword: \u233D",
  "id" : 453987708768382979,
  "in_reply_to_status_id" : 453974650016759808,
  "created_at" : "2014-04-09 20:07:59 +0000",
  "in_reply_to_screen_name" : "ToxXInFlames",
  "in_reply_to_user_id_str" : "1421360166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 5, 14 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/62JADMt3Zw",
      "expanded_url" : "http:\/\/instagram.com\/p\/mlO6tVhwsx\/",
      "display_url" : "instagram.com\/p\/mlO6tVhwsx\/"
    } ]
  },
  "geo" : { },
  "id_str" : "453986268998012928",
  "text" : "Hey, @senficon, du hast da was aufs Whiteboard bekommen. http:\/\/t.co\/62JADMt3Zw",
  "id" : 453986268998012928,
  "created_at" : "2014-04-09 20:02:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453928836343025664",
  "geo" : { },
  "id_str" : "453929790199066624",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot it would have been such a cool hipsteresk band name if not for those actual slippers.",
  "id" : 453929790199066624,
  "in_reply_to_status_id" : 453928836343025664,
  "created_at" : "2014-04-09 16:17:50 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/4WhxmQgKz8",
      "expanded_url" : "http:\/\/store.mentalfloss.com\/GSLIP_375_1.jpg",
      "display_url" : "store.mentalfloss.com\/GSLIP_375_1.jpg"
    } ]
  },
  "in_reply_to_status_id_str" : "453927934525722624",
  "geo" : { },
  "id_str" : "453928530485981184",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot speaking of marketing: http:\/\/t.co\/4WhxmQgKz8",
  "id" : 453928530485981184,
  "in_reply_to_status_id" : 453927934525722624,
  "created_at" : "2014-04-09 16:12:49 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/nLYiCERcpS",
      "expanded_url" : "http:\/\/www.wiesbadener-kurier.de\/lokales\/wiesbaden\/nachrichten-wiesbaden\/darmkrebsvorsorge-1000-mutige-maenner-gesucht_12901702.htm",
      "display_url" : "wiesbadener-kurier.de\/lokales\/wiesba\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "453922531968569344",
  "geo" : { },
  "id_str" : "453923957839003648",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot yep, Freud only slipped on a pool of blood. http:\/\/t.co\/nLYiCERcpS",
  "id" : 453923957839003648,
  "in_reply_to_status_id" : 453922531968569344,
  "created_at" : "2014-04-09 15:54:39 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453921938386477056",
  "text" : "Verleser: \u00ABDarm-T\u00DCV: 1000 blutige M\u00E4nner gesucht.\u00BB",
  "id" : 453921938386477056,
  "created_at" : "2014-04-09 15:46:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sci Curious",
      "screen_name" : "scicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "31443503",
      "id" : 31443503
    }, {
      "name" : "Gwen Pearson\uD83D\uDC1C\uD83D\uDC1E\uD83D\uDC1B",
      "screen_name" : "bug_gwen",
      "indices" : [ 47, 56 ],
      "id_str" : "19563103",
      "id" : 19563103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453898911397474304",
  "text" : "RT @scicurious: If you liked \"Colon rectum\" MT @bug_gwen: You may also enjoy the slightly terrifyingly named \"Colon dentatum\" http:\/\/t.co\/6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gwen Pearson\uD83D\uDC1C\uD83D\uDC1E\uD83D\uDC1B",
        "screen_name" : "bug_gwen",
        "indices" : [ 31, 40 ],
        "id_str" : "19563103",
        "id" : 19563103
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/6f3W33HWDM",
        "expanded_url" : "http:\/\/www.itis.gov\/servlet\/SingleRpt\/SingleRpt?search_topic=TSN&search_value=933619",
        "display_url" : "itis.gov\/servlet\/Single\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "453898820007776256",
    "text" : "If you liked \"Colon rectum\" MT @bug_gwen: You may also enjoy the slightly terrifyingly named \"Colon dentatum\" http:\/\/t.co\/6f3W33HWDM",
    "id" : 453898820007776256,
    "created_at" : "2014-04-09 14:14:46 +0000",
    "user" : {
      "name" : "Sci Curious",
      "screen_name" : "scicurious",
      "protected" : false,
      "id_str" : "31443503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905120517052620800\/uq2q-fjc_normal.jpg",
      "id" : 31443503,
      "verified" : true
    }
  },
  "id" : 453898911397474304,
  "created_at" : "2014-04-09 14:15:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/p8eQ4DRZVX",
      "expanded_url" : "http:\/\/www.iggypop.org\/stoogesrider.html",
      "display_url" : "iggypop.org\/stoogesrider.h\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "453873314285772801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453875485500772352",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju plus: Bob Hope OR(!) The Seven Dwarves http:\/\/t.co\/p8eQ4DRZVX",
  "id" : 453875485500772352,
  "in_reply_to_status_id" : 453873314285772801,
  "created_at" : "2014-04-09 12:42:02 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/YTJiXItK2o",
      "expanded_url" : "http:\/\/www.ohdios.net\/img\/t\/l-251755.gif",
      "display_url" : "ohdios.net\/img\/t\/l-251755\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453870764304138240",
  "text" : "\u00ABWe\u2019re doing big data here. Our dog will not drink from a lazy garden hose. Get out the fire hose!\u00BB http:\/\/t.co\/YTJiXItK2o",
  "id" : 453870764304138240,
  "created_at" : "2014-04-09 12:23:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453869020195065857",
  "text" : "\u00ABWenn die B\u00FCrot\u00FCr zu ist wollen wir nicht gest\u00F6rt werden.\u00BB \u2013 \u00ABMittagsschlaf?\u00BB \u2013 \u00ABSerien schauen\u2026\u00BB",
  "id" : 453869020195065857,
  "created_at" : "2014-04-09 12:16:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453864544633643008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453867409724936192",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a \u2018have you tried turning him off and on again?\u2019",
  "id" : 453867409724936192,
  "in_reply_to_status_id" : 453864544633643008,
  "created_at" : "2014-04-09 12:09:57 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/dM2rgxPjfI",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3321",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453865582912602113",
  "text" : "sociology 101 for extraterrestrials http:\/\/t.co\/dM2rgxPjfI",
  "id" : 453865582912602113,
  "created_at" : "2014-04-09 12:02:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/2Eygn9s3OC",
      "expanded_url" : "http:\/\/xkcd.com\/1353\/",
      "display_url" : "xkcd.com\/1353\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453864922573975552",
  "text" : "\u00ABthe worst security lapse ever\u00BB \u2013 \u00ABworst so far. give us time.\u00BB http:\/\/t.co\/2Eygn9s3OC",
  "id" : 453864922573975552,
  "created_at" : "2014-04-09 12:00:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453842726480801792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1784164631, 8.6136871346 ]
  },
  "id_str" : "453843188965728257",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot The Big Bang Theory one wasn\u2019t too bad actually!",
  "id" : 453843188965728257,
  "in_reply_to_status_id" : 453842726480801792,
  "created_at" : "2014-04-09 10:33:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453823622176833536",
  "text" : "\u00ABDu hattest auf dem Gruppenfoto keine Schuhe an! Musst du mir immer Arbeit machen?\u00BB \u2013 \u00ABPhotoshoppe mir doch einfach ein Paar Betonschuhe.\u00BB",
  "id" : 453823622176833536,
  "created_at" : "2014-04-09 09:15:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1779248234, 8.6140648147 ]
  },
  "id_str" : "453807531320942592",
  "text" : "\u00ABHab ich dir jetzt genug Gr\u00FCnde genannt wieso du mich verlassen solltest oder soll ich weitermachen?\u00BB",
  "id" : 453807531320942592,
  "created_at" : "2014-04-09 08:12:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuuji",
      "screen_name" : "dasYuuji",
      "indices" : [ 0, 9 ],
      "id_str" : "19127017",
      "id" : 19127017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453802611431702528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1725887042, 8.6275231931 ]
  },
  "id_str" : "453804774191038464",
  "in_reply_to_user_id" : 19127017,
  "text" : "@dasYuuji und schon gar nicht sane.",
  "id" : 453804774191038464,
  "in_reply_to_status_id" : 453802611431702528,
  "created_at" : "2014-04-09 08:01:04 +0000",
  "in_reply_to_screen_name" : "dasYuuji",
  "in_reply_to_user_id_str" : "19127017",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723095611, 8.6275775946 ]
  },
  "id_str" : "453801437785759744",
  "text" : "\u00ABEr hat \u00FCberhaupt kein BDSM betrieben w\u00E4hrend ich da war!\u00BB \u2014 \u00ABIch dachte er h\u00E4tte Windows installiert?\u00BB",
  "id" : 453801437785759744,
  "created_at" : "2014-04-09 07:47:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/vLPXgDyRpp",
      "expanded_url" : "http:\/\/www.plospathogens.org\/article\/info%3Adoi%2F10.1371%2Fjournal.ppat.1003967",
      "display_url" : "plospathogens.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453534879930925056",
  "text" : "The 2010 Cholera Outbreak in Haiti: How Science Solved a Controversy http:\/\/t.co\/vLPXgDyRpp",
  "id" : 453534879930925056,
  "created_at" : "2014-04-08 14:08:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 84, 97 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453532977075875840",
  "text" : "TIL: looks like qstat manages the rollover to 7-digit numbers w\/o any problems. \/cc @PhilippBayer",
  "id" : 453532977075875840,
  "created_at" : "2014-04-08 14:01:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453517222179123200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453517458109132801",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot weil du sonst keine neuen Alf-Folgen torrenten kannst? :P",
  "id" : 453517458109132801,
  "in_reply_to_status_id" : 453517222179123200,
  "created_at" : "2014-04-08 12:59:22 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/DCBUcoR3sj",
      "expanded_url" : "http:\/\/www.nature.com\/scitable\/blog\/accumulating-glitches\/speciation_in_reverse",
      "display_url" : "nature.com\/scitable\/blog\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453490518899843072",
  "text" : "Darwin\u2019s finches &amp; Hybridisation: Speciation in Reverse http:\/\/t.co\/DCBUcoR3sj",
  "id" : 453490518899843072,
  "created_at" : "2014-04-08 11:12:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453474514333335552",
  "text" : "\u00ABOrr! Immer diese Menschen die nicht in sich ruhen, die Schweine!\u00BB",
  "id" : 453474514333335552,
  "created_at" : "2014-04-08 10:08:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/HnszoFOFj8",
      "expanded_url" : "http:\/\/legacy.python.org\/dev\/peps\/pep-0465\/#choice-of-operator",
      "display_url" : "legacy.python.org\/dev\/peps\/pep-0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453462785356468225",
  "text" : "An operator for matrix multiplication in Python: \u00AB+.\u00D7, ranks somewhere below U+2603 SNOWMAN on our candidate list.\u00BB http:\/\/t.co\/HnszoFOFj8",
  "id" : 453462785356468225,
  "created_at" : "2014-04-08 09:22:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/EoJwIujbFU",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/compound-eye\/2014\/04\/07\/the-worlds-most-viewed-landscape-a-decade-later\/",
      "display_url" : "blogs.scientificamerican.com\/compound-eye\/2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453453840332124161",
  "text" : "The World\u2019s Most Viewed Landscape, A Decade Later http:\/\/t.co\/EoJwIujbFU",
  "id" : 453453840332124161,
  "created_at" : "2014-04-08 08:46:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453450468409491456",
  "text" : "\u00ABWas tust du da?!\u00BB \u2013 \u00ABIch \u00FCbe k\u00FCssen. Offenbar schaffe ich es nicht immer, ohne zwischendurch Enter zu dr\u00FCcken.\u00BB",
  "id" : 453450468409491456,
  "created_at" : "2014-04-08 08:33:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/VEBlNgcPPH",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3320",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453449309896589313",
  "text" : "wait, other people don\u2019t find that comforting? http:\/\/t.co\/VEBlNgcPPH",
  "id" : 453449309896589313,
  "created_at" : "2014-04-08 08:28:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/Zjl5ThZUFv",
      "expanded_url" : "http:\/\/thescienceweb.wordpress.com\/2014\/04\/08\/satirical-news-site-genomeweb-set-to-close\/",
      "display_url" : "thescienceweb.wordpress.com\/2014\/04\/08\/sat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453442402024693760",
  "text" : "Satirical news site Genomeweb set to\u00A0close http:\/\/t.co\/Zjl5ThZUFv",
  "id" : 453442402024693760,
  "created_at" : "2014-04-08 08:01:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "453440464692465664",
  "text" : "In the category \u2018cheap workarounds to silly problems\u2019: on wakeup my Mac now automatically performs a \u2018killall KILL Dock\u2019\u2026",
  "id" : 453440464692465664,
  "created_at" : "2014-04-08 07:53:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453408508642226176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1099999123, 8.6605048612 ]
  },
  "id_str" : "453417671292649473",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch we should at that as a tag line to openSNP.",
  "id" : 453417671292649473,
  "in_reply_to_status_id" : 453408508642226176,
  "created_at" : "2014-04-08 06:22:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453331030070808577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.109974897, 8.660420543 ]
  },
  "id_str" : "453417654473465856",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC on academia it is\u2026",
  "id" : 453417654473465856,
  "in_reply_to_status_id" : 453331030070808577,
  "created_at" : "2014-04-08 06:22:47 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453306523507507200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096426718, 8.2830141592 ]
  },
  "id_str" : "453307672037580802",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot i guess that\u2019s what I deserve for doing compliments that are borderline insults. Sometimes it goes wrong vice versa.",
  "id" : 453307672037580802,
  "in_reply_to_status_id" : 453306523507507200,
  "created_at" : "2014-04-07 23:05:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096887211, 8.2831601612 ]
  },
  "id_str" : "453305558674993152",
  "text" : "\u00ABDas ist so b\u00F6se, dass sogar du ein Zwinker-Emoticon machst\u2026\u00BB",
  "id" : 453305558674993152,
  "created_at" : "2014-04-07 22:57:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453304627573030913",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096715276, 8.2831244352 ]
  },
  "id_str" : "453305053320065025",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot not even your hair has aged as badly as the banjo strings ;)",
  "id" : 453305053320065025,
  "in_reply_to_status_id" : 453304627573030913,
  "created_at" : "2014-04-07 22:55:21 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453301206551920640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096478693, 8.2830814102 ]
  },
  "id_str" : "453303106991050752",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot don\u2019t be mad only because in a week staying at my place it got more attention than in a decade with you!",
  "id" : 453303106991050752,
  "in_reply_to_status_id" : 453301206551920640,
  "created_at" : "2014-04-07 22:47:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096478693, 8.2830814102 ]
  },
  "id_str" : "453301329361133568",
  "text" : "\u00ABIch f\u00E4rbe dir nur die Haare wenn du dabei nicht Raining Blood singst!\u00BB \u2014 \u00ABViolette Wildseite, From a lacerated sky. Bleeding it\u2019s horror!\u00BB",
  "id" : 453301329361133568,
  "created_at" : "2014-04-07 22:40:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/E4xbcJDerR",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=fs-yqbBfMBY",
      "display_url" : "m.youtube.com\/watch?v=fs-yqb\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "453299525651021824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097033562, 8.2831185987 ]
  },
  "id_str" : "453300515200589824",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon http:\/\/t.co\/E4xbcJDerR",
  "id" : 453300515200589824,
  "in_reply_to_status_id" : 453299525651021824,
  "created_at" : "2014-04-07 22:37:19 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096028663, 8.2829572612 ]
  },
  "id_str" : "453299307312316416",
  "text" : "For now the banjo might only have 3 strings but luckily those are all that are needed to play Raining Blood. \\o\/",
  "id" : 453299307312316416,
  "created_at" : "2014-04-07 22:32:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graveley Lab",
      "screen_name" : "GraveleyLab",
      "indices" : [ 0, 12 ],
      "id_str" : "456361953",
      "id" : 456361953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453292566264696833",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097026451, 8.2831600242 ]
  },
  "id_str" : "453297147598094336",
  "in_reply_to_user_id" : 456361953,
  "text" : "@GraveleyLab isn\u2019t this a case of the \u2018No true .sman fallacy\u2019?",
  "id" : 453297147598094336,
  "in_reply_to_status_id" : 453292566264696833,
  "created_at" : "2014-04-07 22:23:56 +0000",
  "in_reply_to_screen_name" : "GraveleyLab",
  "in_reply_to_user_id_str" : "456361953",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0080820117, 8.2801831061 ]
  },
  "id_str" : "453232549796782081",
  "text" : "\u00AB\u2018\u00D6konuttis\u2019? Not sure ob der Typo sagt du w\u00E4rest k\u00E4uflich oder verr\u00FCckt.\u00BB",
  "id" : 453232549796782081,
  "created_at" : "2014-04-07 18:07:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0010501001, 8.4016454826 ]
  },
  "id_str" : "453217909461225472",
  "text" : "\u00ABKinder, ich geh nach Hause. Tut nichts was ich nicht auch tun w\u00FCrde.\u00BB \u2014 \u00ABAber du tust manchmal ganz schreckliche Dinge!\u00BB \u2014 \u00ABViel Spass!\u00BB",
  "id" : 453217909461225472,
  "created_at" : "2014-04-07 17:09:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1619162875, 8.6487498828 ]
  },
  "id_str" : "453202550331023361",
  "text" : "\u00ABYou influence us, showing us the true meaning of love!\u00BB  Uh, no pressure there\u2026",
  "id" : 453202550331023361,
  "created_at" : "2014-04-07 16:08:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/kU2arLI8W9",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/psi-vid\/2014\/04\/06\/zombie-apocalypse-survival-chemistry-death-cologne\/",
      "display_url" : "blogs.scientificamerican.com\/psi-vid\/2014\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453186584301821952",
  "text" : "Zombie Apocalypse Survival Chemistry: Death Cologne http:\/\/t.co\/kU2arLI8W9",
  "id" : 453186584301821952,
  "created_at" : "2014-04-07 15:04:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453105938036441088",
  "text" : "\u00ABAu\u00DFerdem waren auf dem Cheatsheet noch Motivationals. Z.B.: 'Es k\u00F6nnte schlimmer sein, Immerhin hab ich nicht meine Tante geschw\u00E4ngert'.\u00BB",
  "id" : 453105938036441088,
  "created_at" : "2014-04-07 09:44:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723542936, 8.627574266 ]
  },
  "id_str" : "453103911709454336",
  "text" : "\u00ABMein Cheatsheet f\u00FCr die Klausur war ein Tempo. Darauf ein Bild von uns an einer Klippe im Sonnenuntergang. Dr\u00FCber stand \u2018Mentorpower!\u2019.\u00BB",
  "id" : 453103911709454336,
  "created_at" : "2014-04-07 09:36:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John S. Wilkins",
      "screen_name" : "john_s_wilkins",
      "indices" : [ 3, 18 ],
      "id_str" : "76013938",
      "id" : 76013938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/8gxPTWeUdi",
      "expanded_url" : "http:\/\/Edge.org",
      "display_url" : "Edge.org"
    }, {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/AymVUUY6O5",
      "expanded_url" : "http:\/\/edge.org\/conversation\/on-kahneman",
      "display_url" : "edge.org\/conversation\/o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453052496672743424",
  "text" : "RT @john_s_wilkins: ON KAHNEMAN | http:\/\/t.co\/8gxPTWeUdi http:\/\/t.co\/AymVUUY6O5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/8gxPTWeUdi",
        "expanded_url" : "http:\/\/Edge.org",
        "display_url" : "Edge.org"
      }, {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/AymVUUY6O5",
        "expanded_url" : "http:\/\/edge.org\/conversation\/on-kahneman",
        "display_url" : "edge.org\/conversation\/o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "452973556066816000",
    "text" : "ON KAHNEMAN | http:\/\/t.co\/8gxPTWeUdi http:\/\/t.co\/AymVUUY6O5",
    "id" : 452973556066816000,
    "created_at" : "2014-04-07 00:58:06 +0000",
    "user" : {
      "name" : "John S. Wilkins",
      "screen_name" : "john_s_wilkins",
      "protected" : false,
      "id_str" : "76013938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852294288838807552\/FZpeLbxA_normal.jpg",
      "id" : 76013938,
      "verified" : false
    }
  },
  "id" : 453052496672743424,
  "created_at" : "2014-04-07 06:11:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Birgitt",
      "screen_name" : "hekate15",
      "indices" : [ 0, 9 ],
      "id_str" : "88686990",
      "id" : 88686990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452888313045975043",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096654148, 8.2829535434 ]
  },
  "id_str" : "452890450702385152",
  "in_reply_to_user_id" : 88686990,
  "text" : "@hekate15 danke :)",
  "id" : 452890450702385152,
  "in_reply_to_status_id" : 452888313045975043,
  "created_at" : "2014-04-06 19:27:52 +0000",
  "in_reply_to_screen_name" : "hekate15",
  "in_reply_to_user_id_str" : "88686990",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Birgitt",
      "screen_name" : "hekate15",
      "indices" : [ 0, 9 ],
      "id_str" : "88686990",
      "id" : 88686990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452882573782679553",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096455573, 8.2831594399 ]
  },
  "id_str" : "452886990493872128",
  "in_reply_to_user_id" : 88686990,
  "text" : "@hekate15 weil ich ein totaler Falter-Laie bin. Aber ich lasse mich gern in meiner Annahme best\u00E4tigen :)",
  "id" : 452886990493872128,
  "in_reply_to_status_id" : 452882573782679553,
  "created_at" : "2014-04-06 19:14:07 +0000",
  "in_reply_to_screen_name" : "hekate15",
  "in_reply_to_user_id_str" : "88686990",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/50ZayA86Li",
      "expanded_url" : "http:\/\/instagram.com\/p\/mdWoYFBwkv\/",
      "display_url" : "instagram.com\/p\/mdWoYFBwkv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "452877331770929152",
  "text" : "Pararge cf. aegeria http:\/\/t.co\/50ZayA86Li",
  "id" : 452877331770929152,
  "created_at" : "2014-04-06 18:35:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel D\u00FCngel \uD83C\uDF1E",
      "screen_name" : "rwolupo",
      "indices" : [ 0, 8 ],
      "id_str" : "21428050",
      "id" : 21428050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452836535981719552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096563523, 8.2831319649 ]
  },
  "id_str" : "452837064636395521",
  "in_reply_to_user_id" : 21428050,
  "text" : "@rwolupo nichts pers\u00F6nliches, ich hab nur den Piratenanteil meiner Timeline weiter minimiert.",
  "id" : 452837064636395521,
  "in_reply_to_status_id" : 452836535981719552,
  "created_at" : "2014-04-06 15:55:44 +0000",
  "in_reply_to_screen_name" : "rwolupo",
  "in_reply_to_user_id_str" : "21428050",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452810422547390464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0106908393, 8.2764601732 ]
  },
  "id_str" : "452811492044595200",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC sure, and by now you should be able to judge how risk averse I am! ;)",
  "id" : 452811492044595200,
  "in_reply_to_status_id" : 452810422547390464,
  "created_at" : "2014-04-06 14:14:07 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452805560686374912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0122040041, 8.2783181558 ]
  },
  "id_str" : "452806343817428992",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I have a weak spot for self-experimentation. And after all he did spare his eyes!",
  "id" : 452806343817428992,
  "in_reply_to_status_id" : 452805560686374912,
  "created_at" : "2014-04-06 13:53:39 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1244682696, 8.6261507391 ]
  },
  "id_str" : "452716112544018432",
  "text" : "\u00ABIch freu mich so langsam auf Zuhause.\u00BB \u2014 \u00ABDas wird sich schon \u00E4ndern wenn du siehst wie gut ich aufger\u00E4umt habe.\u00BB",
  "id" : 452716112544018432,
  "created_at" : "2014-04-06 07:55:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1246969077, 8.6262175492 ]
  },
  "id_str" : "452547197352300544",
  "text" : "\u00ABBist du jetzt das Panzerwesen was alles platt macht?!\u00BB",
  "id" : 452547197352300544,
  "created_at" : "2014-04-05 20:43:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1240623805, 8.6256225566 ]
  },
  "id_str" : "452530112567975937",
  "text" : "\u00ABIch bin einfach so nett zu dir. Was h\u00E4tte ich denn davon?\u00BB\u2014\u00ABB\u00E4rlauchpesto?\u00BB\u2014\u00ABDann w\u00E4re ich schon viel fr\u00FCher nett zu dir gewesen!\u00BB",
  "id" : 452530112567975937,
  "created_at" : "2014-04-05 19:36:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1246910285, 8.6264186046 ]
  },
  "id_str" : "452506433540857856",
  "text" : "\u00ABDu kennst meinen Bruder schon, oder?\u00BB \u2014 \u00ABIch bin schon hinter ihm hergerannt als er halbnackt war. Ich w\u00FCrde sagen das ist ein \u2018ja\u2019.\u00BB",
  "id" : 452506433540857856,
  "created_at" : "2014-04-05 18:01:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/uQmMPumn4B",
      "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2014\/04\/03\/the-worst-places-to-get-stung-by-a-bee-nostril-lip-penis\/",
      "display_url" : "phenomena.nationalgeographic.com\/2014\/04\/03\/the\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "452489005712818176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1243200631, 8.6265026144 ]
  },
  "id_str" : "452489659843903488",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC this one, it sounds like so much fun! http:\/\/t.co\/uQmMPumn4B",
  "id" : 452489659843903488,
  "in_reply_to_status_id" : 452489005712818176,
  "created_at" : "2014-04-05 16:55:16 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452485908168982528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.128871858, 8.6289193645 ]
  },
  "id_str" : "452486944124329985",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC mine is probably sensing that it\u2019s getting 24 months old soon and thus can be replaced.",
  "id" : 452486944124329985,
  "in_reply_to_status_id" : 452485908168982528,
  "created_at" : "2014-04-05 16:44:28 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114776652, 8.682513908 ]
  },
  "id_str" : "452484072057880576",
  "text" : "n+1, thanks Sandman.",
  "id" : 452484072057880576,
  "created_at" : "2014-04-05 16:33:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452481756617531393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1011784534, 8.6448894844 ]
  },
  "id_str" : "452482483221987328",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC you professors really are living a life full of luxury. ;)",
  "id" : 452482483221987328,
  "in_reply_to_status_id" : 452481756617531393,
  "created_at" : "2014-04-05 16:26:45 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452470335494180864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0072788949, 8.2828488222 ]
  },
  "id_str" : "452470935254482944",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC is the warning at least somewhat reliable? Mine went 80% -&gt; 35% -&gt; 1% -&gt; 40% -&gt; dead over a period of 45 mins.",
  "id" : 452470935254482944,
  "in_reply_to_status_id" : 452470335494180864,
  "created_at" : "2014-04-05 15:40:52 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452469731820568576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0073629453, 8.2828907015 ]
  },
  "id_str" : "452470626994102272",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC but first I will have to replicate this bee sting study. The bee guys already offered me their hives. ;)",
  "id" : 452470626994102272,
  "in_reply_to_status_id" : 452469731820568576,
  "created_at" : "2014-04-05 15:39:38 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452468791679922176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0073347967, 8.28292766 ]
  },
  "id_str" : "452469983478837248",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC that sounds a lot like my current situation. Can\u2019t confirm on how great it is though. ;)",
  "id" : 452469983478837248,
  "in_reply_to_status_id" : 452468791679922176,
  "created_at" : "2014-04-05 15:37:05 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096171219, 8.2829669095 ]
  },
  "id_str" : "452466714215972865",
  "text" : "Next manuscript idea: \u2018An Emperical Study: On Using the iPhone Battery Meter as a Random Number Generator",
  "id" : 452466714215972865,
  "created_at" : "2014-04-05 15:24:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/tRXzsJPwti",
      "expanded_url" : "http:\/\/instagram.com\/p\/maYCvfhwi8\/",
      "display_url" : "instagram.com\/p\/maYCvfhwi8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "452458223254372352",
  "text" : "apparently this is what happens if there is a need for removing trees thanks to Phytophthora\u2026 http:\/\/t.co\/tRXzsJPwti",
  "id" : 452458223254372352,
  "created_at" : "2014-04-05 14:50:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452429288608776192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0101121748, 8.2826981507 ]
  },
  "id_str" : "452431083725148161",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC go for cat-sitting then. That will also leave plenty of time to get a second job. ;)",
  "id" : 452431083725148161,
  "in_reply_to_status_id" : 452429288608776192,
  "created_at" : "2014-04-05 13:02:30 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095668766, 8.2828781008 ]
  },
  "id_str" : "452421135700090880",
  "text" : "\u00ABSo, waren wir jetzt genug bl\u00F6d?\u00BB \u2014 \u00ABJa, darf Ich dich jetzt wieder in den Arm nehmen?\u00BB",
  "id" : 452421135700090880,
  "created_at" : "2014-04-05 12:22:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452211912550678528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096141135, 8.2829447311 ]
  },
  "id_str" : "452355753240961024",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I\u2019m still thinking of starting a career as dog-sitter. ~ equal pay while working less hours, less stress, more fun.",
  "id" : 452355753240961024,
  "in_reply_to_status_id" : 452211912550678528,
  "created_at" : "2014-04-05 08:03:10 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452115036836990976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "452115482297262080",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer yep, that should work as well. :)",
  "id" : 452115482297262080,
  "in_reply_to_status_id" : 452115036836990976,
  "created_at" : "2014-04-04 16:08:25 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452114132742176768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "452114882994143232",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer otherwise people just open their emails after two days and the dump they requested was deleted already.",
  "id" : 452114882994143232,
  "in_reply_to_status_id" : 452114132742176768,
  "created_at" : "2014-04-04 16:06:02 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452114132742176768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "452114806125125632",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer strictly speaking: No. But the URLs are sent out via email as DL-Links. So keeping recent ones might be good.",
  "id" : 452114806125125632,
  "in_reply_to_status_id" : 452114132742176768,
  "created_at" : "2014-04-04 16:05:44 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/BOzKmKZkBn",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/04\/02\/magician-makes-dogs-treats-v.html",
      "display_url" : "boingboing.net\/2014\/04\/02\/mag\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "452041575095619584",
  "text" : "Where\u2019s your object permanence now? Magician makes dogs' treats\u00A0vanish http:\/\/t.co\/BOzKmKZkBn",
  "id" : 452041575095619584,
  "created_at" : "2014-04-04 11:14:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/7T3GJev1CE",
      "expanded_url" : "http:\/\/chapmangamo.tumblr.com\/post\/81603668265\/i-drew-this-yesterday-because-i-had-to-get-the",
      "display_url" : "chapmangamo.tumblr.com\/post\/816036682\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "452038611815641088",
  "text" : "Word! http:\/\/t.co\/7T3GJev1CE",
  "id" : 452038611815641088,
  "created_at" : "2014-04-04 11:02:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffa",
      "screen_name" : "rei_in_der_tube",
      "indices" : [ 0, 16 ],
      "id_str" : "19707954",
      "id" : 19707954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452025669640540160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "452033964732342272",
  "in_reply_to_user_id" : 19707954,
  "text" : "@rei_in_der_tube das kommt auf die z\u00E4hlweise an ;)",
  "id" : 452033964732342272,
  "in_reply_to_status_id" : 452025669640540160,
  "created_at" : "2014-04-04 10:44:30 +0000",
  "in_reply_to_screen_name" : "rei_in_der_tube",
  "in_reply_to_user_id_str" : "19707954",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452016719469768704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "452020157700141056",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot once you stop to belate me.",
  "id" : 452020157700141056,
  "in_reply_to_status_id" : 452016719469768704,
  "created_at" : "2014-04-04 09:49:38 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "452019480903045120",
  "text" : "Somehow I can\u2019t find the shell which I used to start my assembly. Guess I installed The Velvet Underground extension by accident\u2026",
  "id" : 452019480903045120,
  "created_at" : "2014-04-04 09:46:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452014868183269376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "452017061834018816",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch oh, and btw: I renewed our privacy policy for another year. :)",
  "id" : 452017061834018816,
  "in_reply_to_status_id" : 452014868183269376,
  "created_at" : "2014-04-04 09:37:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452014771353960448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "452015385047740416",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer speaking off: I\u2019m still on the topic of getting our funds\u2026",
  "id" : 452015385047740416,
  "in_reply_to_status_id" : 452014771353960448,
  "created_at" : "2014-04-04 09:30:40 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beatrice Lugger",
      "screen_name" : "BLugger",
      "indices" : [ 100, 108 ],
      "id_str" : "14699615",
      "id" : 14699615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/BMPOiBG3aJ",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2014\/04\/i-had-my-dna-analyzed-and-all-i-got-was-this-lousy-story\/",
      "display_url" : "arstechnica.com\/science\/2014\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "452012396849410048",
  "text" : "The caveats of DTC genetic testing: \u00ABI had my DNA analyzed, and all I got was this lousy story\u00BB \/HT @BLugger http:\/\/t.co\/BMPOiBG3aJ",
  "id" : 452012396849410048,
  "created_at" : "2014-04-04 09:18:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turtlesallthewaydown",
      "indices" : [ 36, 57 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452008325480058881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "452010623443161089",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Social-Media-Berater-Berater #turtlesallthewaydown",
  "id" : 452010623443161089,
  "in_reply_to_status_id" : 452008325480058881,
  "created_at" : "2014-04-04 09:11:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/k2hsnMXU2u",
      "expanded_url" : "http:\/\/31.media.tumblr.com\/7286f25a293534fce0310761bbef83d9\/tumblr_mzvq0d0E1b1tr11rio1_500.gif",
      "display_url" : "31.media.tumblr.com\/7286f25a293534\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "452005025720848384",
  "text" : "three academics trying to figure out how general liability insurance policies work http:\/\/t.co\/k2hsnMXU2u",
  "id" : 452005025720848384,
  "created_at" : "2014-04-04 08:49:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451889063868375040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723341216, 8.6276195695 ]
  },
  "id_str" : "452000944897916929",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer well done, sir!",
  "id" : 452000944897916929,
  "in_reply_to_status_id" : 451889063868375040,
  "created_at" : "2014-04-04 08:33:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096436264, 8.2832352631 ]
  },
  "id_str" : "451999722195406848",
  "text" : "\u00ABDu k\u00F6nntest dir die Namen deiner PartnerInnen auf den Penis t\u00E4towieren lassen.\u00BB \u2014 \u00ABAch bitte, so gro\u00DF ist er auch nicht.\u00BB",
  "id" : 451999722195406848,
  "created_at" : "2014-04-04 08:28:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096535528, 8.2829997884 ]
  },
  "id_str" : "451982621548216320",
  "text" : "\u00ABUnd wie l\u00F6st ihr eure Beziehungsprobleme?\u00BB \u2014 \u00ABMit Hitlervergleichen.\u00BB",
  "id" : 451982621548216320,
  "created_at" : "2014-04-04 07:20:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451821023810551808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0137394961, 8.2756870622 ]
  },
  "id_str" : "451821329604681728",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr that sounds so easy to reproduce. It would be a shame if no one tried!",
  "id" : 451821329604681728,
  "in_reply_to_status_id" : 451821023810551808,
  "created_at" : "2014-04-03 20:39:34 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0082757651, 8.2704814524 ]
  },
  "id_str" : "451820726920953857",
  "text" : "And all of a sudden there is this urge to visit the guys at our local bee institute.",
  "id" : 451820726920953857,
  "created_at" : "2014-04-03 20:37:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/aEXb9K89r2",
      "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2014\/04\/03\/the-worst-places-to-get-stung-by-a-bee-nostril-lip-penis\/",
      "display_url" : "phenomena.nationalgeographic.com\/2014\/04\/03\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "451820482929889280",
  "text" : "RT @edyong209: \"You\u2019re going to want more stings to the penis over the nose, if you\u2019re forced to choose\" http:\/\/t.co\/aEXb9K89r2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/aEXb9K89r2",
        "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2014\/04\/03\/the-worst-places-to-get-stung-by-a-bee-nostril-lip-penis\/",
        "display_url" : "phenomena.nationalgeographic.com\/2014\/04\/03\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "451770719253561344",
    "text" : "\"You\u2019re going to want more stings to the penis over the nose, if you\u2019re forced to choose\" http:\/\/t.co\/aEXb9K89r2",
    "id" : 451770719253561344,
    "created_at" : "2014-04-03 17:18:27 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 451820482929889280,
  "created_at" : "2014-04-03 20:36:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "indices" : [ 0, 15 ],
      "id_str" : "1040758742",
      "id" : 1040758742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451750881214472192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "451751322325630977",
  "in_reply_to_user_id" : 1040758742,
  "text" : "@BioDataGanache lovely done. I also like the plains of more pain along with the plains of still more pain. ;)",
  "id" : 451751322325630977,
  "in_reply_to_status_id" : 451750881214472192,
  "created_at" : "2014-04-03 16:01:23 +0000",
  "in_reply_to_screen_name" : "BioDataGanache",
  "in_reply_to_user_id_str" : "1040758742",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "indices" : [ 58, 73 ],
      "id_str" : "1040758742",
      "id" : 1040758742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/9MOzH1wU0K",
      "expanded_url" : "http:\/\/jasonya.com\/wp\/the-map-of-manuscript-earth\/",
      "display_url" : "jasonya.com\/wp\/the-map-of-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "451750357610545153",
  "text" : "\u00ABHere be statisticians\u00BB \u2013 The Map of Manuscript-earth by  @BioDataGanache http:\/\/t.co\/9MOzH1wU0K",
  "id" : 451750357610545153,
  "created_at" : "2014-04-03 15:57:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liron Tocker",
      "screen_name" : "lirontocker",
      "indices" : [ 60, 72 ],
      "id_str" : "7612412",
      "id" : 7612412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/X2jDNOy9M3",
      "expanded_url" : "http:\/\/s3-ec.buzzfed.com\/static\/2014-04\/enhanced\/webdr06\/1\/12\/anigif_original-5392-1396370817-3.gif",
      "display_url" : "s3-ec.buzzfed.com\/static\/2014-04\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "451743435901632512",
  "text" : "can confirm: that\u2019s actually how bioinformaticians work. RT @lirontocker: Oops, my brain melted. http:\/\/t.co\/X2jDNOy9M3",
  "id" : 451743435901632512,
  "created_at" : "2014-04-03 15:30:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/w2YtiPUOOF",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2014\/04\/computers-used-to-teach-other-computers-to-play-pac-man-starcraft\/",
      "display_url" : "arstechnica.com\/science\/2014\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "451736150638874626",
  "text" : "Computers used to teach other computers to play computer games http:\/\/t.co\/w2YtiPUOOF",
  "id" : 451736150638874626,
  "created_at" : "2014-04-03 15:01:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/GWyGRwbQ1M",
      "expanded_url" : "http:\/\/cultureoverdose.com\/wp-content\/uploads\/2013\/12\/drno-radiation-.jpg",
      "display_url" : "cultureoverdose.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "451716679794708480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "451718564190650368",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot no! http:\/\/t.co\/GWyGRwbQ1M",
  "id" : 451718564190650368,
  "in_reply_to_status_id" : 451716679794708480,
  "created_at" : "2014-04-03 13:51:12 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "451713218998964224",
  "text" : "Working hard on my Dr. (Dolittle): the pufferfish are now fine with eating out of my hand &amp; the dog is fine with playing my pillow.",
  "id" : 451713218998964224,
  "created_at" : "2014-04-03 13:29:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "451692569400213505",
  "text" : "Wenn das Volk zu sp\u00E4t zum Mittagessen erscheint, dann gibt es Kuchen zu essen. \\o\/",
  "id" : 451692569400213505,
  "created_at" : "2014-04-03 12:07:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340414, 8.62761571 ]
  },
  "id_str" : "451681863611195392",
  "text" : "\u00ABWe always could go for another project: estimating genome complexity via assembly run time.\u00BB",
  "id" : 451681863611195392,
  "created_at" : "2014-04-03 11:25:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 9, 15 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451477854455595008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964488, 8.2831005056 ]
  },
  "id_str" : "451489668929175552",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule @Lobot Let\u2019s say that didn\u2019t work out either &amp; I\u2019ll now have to lie in a set of broken banjo strings, playing \u2018Americana Beauty\u2019.",
  "id" : 451489668929175552,
  "in_reply_to_status_id" : 451477854455595008,
  "created_at" : "2014-04-02 22:41:40 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 9, 15 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451477854455595008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964488, 8.2831005056 ]
  },
  "id_str" : "451478226205167617",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule @Lobot good idea, let me check whether I have some around!",
  "id" : 451478226205167617,
  "in_reply_to_status_id" : 451477854455595008,
  "created_at" : "2014-04-02 21:56:11 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 7, 15 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451475773325844481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964488, 8.2831005056 ]
  },
  "id_str" : "451476383462875136",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @euleule nah, the problem is re-using the old, curly strings along with the weird loops used to tie them down below the bridge.",
  "id" : 451476383462875136,
  "in_reply_to_status_id" : 451475773325844481,
  "created_at" : "2014-04-02 21:48:52 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964488, 8.2831005056 ]
  },
  "id_str" : "451472914664423424",
  "text" : "Changing strings of a banjo guitar taught me 2 things: how to turn it into a 5-string banjo &amp; why banjo players always look slightly mad\u2026",
  "id" : 451472914664423424,
  "created_at" : "2014-04-02 21:35:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451460178672893952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0052597234, 8.281933805 ]
  },
  "id_str" : "451460877045465089",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I\u2019m not that unobservant, so I noticed that much. ;)",
  "id" : 451460877045465089,
  "in_reply_to_status_id" : 451460178672893952,
  "created_at" : "2014-04-02 20:47:15 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451457773336027136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095874383, 8.2828653233 ]
  },
  "id_str" : "451458262119231490",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I guess you\u2019re just more observant than me. But by now I\u2019m slowly waking up\u2026",
  "id" : 451458262119231490,
  "in_reply_to_status_id" : 451457773336027136,
  "created_at" : "2014-04-02 20:36:52 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172317722, 8.6276262895 ]
  },
  "id_str" : "451385324846202880",
  "text" : "\u00ABIch gebe dir gerne eine zweite Chance, aber bitte sei nicht wie diese Plastikt\u00FCte.\u00BB \u2014 \u00ABRei\u00DFen wenn man zuviel reinsteckt?\u00BB",
  "id" : 451385324846202880,
  "created_at" : "2014-04-02 15:47:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723479437, 8.6275855497 ]
  },
  "id_str" : "451351644853501953",
  "text" : "\u00ABIch wusste nicht ob ich englisch reden soll\u2026\u00BB \u2014 \u00ABWenn du mit mir flirten willst geht das nat\u00FCrlich in der Sprache der Liebe: Auf Deutsch!\u00BB",
  "id" : 451351644853501953,
  "created_at" : "2014-04-02 13:33:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 10, 19 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 20, 26 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451346389046685697",
  "geo" : { },
  "id_str" : "451347086282600448",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @JP_Stich @Lobot In [9]: random.randint(1,20) Out[9]: 2",
  "id" : 451347086282600448,
  "in_reply_to_status_id" : 451346389046685697,
  "created_at" : "2014-04-02 13:15:05 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 17, 26 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/fDcEu7A6oH",
      "expanded_url" : "http:\/\/media-cache-ak0.pinimg.com\/originals\/e1\/8b\/aa\/e18baa359a0bc8fb53891ac94f3bf93e.jpg",
      "display_url" : "media-cache-ak0.pinimg.com\/originals\/e1\/8\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "451346038339960832",
  "geo" : { },
  "id_str" : "451346486954311680",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich @thorgnyr http:\/\/t.co\/fDcEu7A6oH (somehow I suspect that you just want to accompany me again and have some cheap laughs)",
  "id" : 451346486954311680,
  "in_reply_to_status_id" : 451346038339960832,
  "created_at" : "2014-04-02 13:12:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 10, 19 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 20, 26 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451345145884340224",
  "geo" : { },
  "id_str" : "451345728271810561",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @thorgnyr @Lobot by now I really want a date with my tattoo artist. :p",
  "id" : 451345728271810561,
  "in_reply_to_status_id" : 451345145884340224,
  "created_at" : "2014-04-02 13:09:41 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 17, 26 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451343904106115072",
  "geo" : { },
  "id_str" : "451344696947011585",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @Lobot @JP_Stich \u00ABYou stumble over the invisible deceased turtle and bang your head on the wall. Ow!\u00BB",
  "id" : 451344696947011585,
  "in_reply_to_status_id" : 451343904106115072,
  "created_at" : "2014-04-02 13:05:35 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451343668759523328",
  "geo" : { },
  "id_str" : "451344046297219072",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich that reminds me that I still haven't looked up how they solved that in the german sync!",
  "id" : 451344046297219072,
  "in_reply_to_status_id" : 451343668759523328,
  "created_at" : "2014-04-02 13:03:00 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 30, 39 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451338145960050689",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724095829, 8.627597373 ]
  },
  "id_str" : "451339518294372352",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot more human than human! @JP_Stich",
  "id" : 451339518294372352,
  "in_reply_to_status_id" : 451338145960050689,
  "created_at" : "2014-04-02 12:45:01 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451335034579222528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723539345, 8.6275822194 ]
  },
  "id_str" : "451335696784318464",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC nearly made it to the train station before noticing my mistake\u2026 zombified describes it perfectly.",
  "id" : 451335696784318464,
  "in_reply_to_status_id" : 451335034579222528,
  "created_at" : "2014-04-02 12:29:50 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451332294708826112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1847991943, 8.6228790283 ]
  },
  "id_str" : "451333467562074112",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich &lt;3 Aber auch als still auf den rechten Handr\u00FCcken finde ich eine sexy Idee.",
  "id" : 451333467562074112,
  "in_reply_to_status_id" : 451332294708826112,
  "created_at" : "2014-04-02 12:20:58 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 14, 23 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322661, 8.6276133336 ]
  },
  "id_str" : "451296149316829184",
  "text" : "The avatar of @JP_Stich makes me think that I should get the unicorn as my next tattoo as it\u2019s such a beautiful memento mori.",
  "id" : 451296149316829184,
  "created_at" : "2014-04-02 09:52:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1609167722, 8.6499707054 ]
  },
  "id_str" : "451278354113921024",
  "text" : "Level of tiredness: nearly went off to work without putting on shoes and glasses.",
  "id" : 451278354113921024,
  "created_at" : "2014-04-02 08:41:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/JZ7o1QeSkt",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=BKorP55Aqvg",
      "display_url" : "youtube.com\/watch?v=BKorP5\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096311633, 8.2829939117 ]
  },
  "id_str" : "451138499060981760",
  "text" : "I can do absolutely anything. I\u2019m an expert! http:\/\/t.co\/JZ7o1QeSkt",
  "id" : 451138499060981760,
  "created_at" : "2014-04-01 23:26:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 99, 112 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/x87zvrdGIg",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0090375",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096311633, 8.2829939117 ]
  },
  "id_str" : "451128167424860160",
  "text" : "Scientists@Home: What Drives the Quantity and Quality of Online Citizen Science Participation? \/cc @PhilippBayer http:\/\/t.co\/x87zvrdGIg",
  "id" : 451128167424860160,
  "created_at" : "2014-04-01 22:45:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Gourneau",
      "screen_name" : "gourneau",
      "indices" : [ 3, 12 ],
      "id_str" : "9552572",
      "id" : 9552572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BitBand",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/mk4QRd7fl7",
      "expanded_url" : "https:\/\/www.atlassian.com\/bitband",
      "display_url" : "atlassian.com\/bitband"
    } ]
  },
  "geo" : { },
  "id_str" : "451109470459142144",
  "text" : "RT @gourneau: Quantified self meets the internet of things specifically for developers https:\/\/t.co\/mk4QRd7fl7 #BitBand",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BitBand",
        "indices" : [ 97, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/mk4QRd7fl7",
        "expanded_url" : "https:\/\/www.atlassian.com\/bitband",
        "display_url" : "atlassian.com\/bitband"
      } ]
    },
    "geo" : { },
    "id_str" : "451108840327897090",
    "text" : "Quantified self meets the internet of things specifically for developers https:\/\/t.co\/mk4QRd7fl7 #BitBand",
    "id" : 451108840327897090,
    "created_at" : "2014-04-01 21:28:23 +0000",
    "user" : {
      "name" : "Joshua Gourneau",
      "screen_name" : "gourneau",
      "protected" : false,
      "id_str" : "9552572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1244673486\/face_normal.jpg",
      "id" : 9552572,
      "verified" : false
    }
  },
  "id" : 451109470459142144,
  "created_at" : "2014-04-01 21:30:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/FMcW38MzUN",
      "expanded_url" : "http:\/\/www.euppublishing.com\/doi\/abs\/10.3366\/cor.2012.0018",
      "display_url" : "euppublishing.com\/doi\/abs\/10.336\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095405886, 8.283002 ]
  },
  "id_str" : "451108191582294016",
  "text" : "thorough lit research \u00ABUsing corpora in depth psychology: a trigram-based analysis of a corpus of fetish fantasies\u00BB http:\/\/t.co\/FMcW38MzUN",
  "id" : 451108191582294016,
  "created_at" : "2014-04-01 21:25:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451074309260591104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095405886, 8.283002 ]
  },
  "id_str" : "451078118904578048",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon I\u2019ll take asking that as an insult\u2026",
  "id" : 451078118904578048,
  "in_reply_to_status_id" : 451074309260591104,
  "created_at" : "2014-04-01 19:26:18 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0065629439, 8.2887656474 ]
  },
  "id_str" : "451068225678508032",
  "text" : "Oh, science. Getting the first positive results after 6 months of constant failure: impromptu dance performance at the office!",
  "id" : 451068225678508032,
  "created_at" : "2014-04-01 18:47:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel",
      "screen_name" : "sleeksorrow",
      "indices" : [ 0, 12 ],
      "id_str" : "59806323",
      "id" : 59806323
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451005895296974848",
  "geo" : { },
  "id_str" : "451006716931739649",
  "in_reply_to_user_id" : 59806323,
  "text" : "@sleeksorrow @Lobot dressed to kill -9",
  "id" : 451006716931739649,
  "in_reply_to_status_id" : 451005895296974848,
  "created_at" : "2014-04-01 14:42:35 +0000",
  "in_reply_to_screen_name" : "sleeksorrow",
  "in_reply_to_user_id_str" : "59806323",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723517115, 8.6275781132 ]
  },
  "id_str" : "451004844422463488",
  "text" : "\u00ABNein, keine Verdauungsprobleme. Ich verstecke mich hier vor den Studenten die Hilfe beim erstellen von Heatmaps in R wollen.\u00BB",
  "id" : 451004844422463488,
  "created_at" : "2014-04-01 14:35:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/z8FwnHZvQP",
      "expanded_url" : "http:\/\/www.rollingstone.com\/feature\/millennial-sexual-revolution-relationships-marriage",
      "display_url" : "rollingstone.com\/feature\/millen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "450995736680095744",
  "text" : "\u00ABThe current sexual revolution resides as firmly in code as in the bedroom\u00BB Tales From the Millennials' Sex. Revol. http:\/\/t.co\/z8FwnHZvQP",
  "id" : 450995736680095744,
  "created_at" : "2014-04-01 13:58:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450983629712539649",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1769734942, 8.6240277354 ]
  },
  "id_str" : "450984415267934208",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ich vermute vor lauter gaffen das Essen kaltwerden lassen. ;)",
  "id" : 450984415267934208,
  "in_reply_to_status_id" : 450983629712539649,
  "created_at" : "2014-04-01 13:13:58 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/xHKGwhv7WA",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1693",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "450981375232180224",
  "text" : "scientific software development http:\/\/t.co\/xHKGwhv7WA",
  "id" : 450981375232180224,
  "created_at" : "2014-04-01 13:01:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450976989839900673",
  "geo" : { },
  "id_str" : "450979023259451392",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot das kommt davon wenn man keine gut beh\u00FCtete Kindheit hatte.",
  "id" : 450979023259451392,
  "in_reply_to_status_id" : 450976989839900673,
  "created_at" : "2014-04-01 12:52:32 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723541082, 8.627611017 ]
  },
  "id_str" : "450970039823638528",
  "text" : "\u00ABJa, ich hab euch gesehen. Eigentlich sa\u00DF ich in der Mensa und wollte essen und ihr habt ca. 3 Stunden lang davor gestanden &amp; geknutscht.\u00BB",
  "id" : 450970039823638528,
  "created_at" : "2014-04-01 12:16:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097459276, 8.2830980513 ]
  },
  "id_str" : "450961209131810816",
  "text" : "\u00ABDie anderen Nachbarn reden schlecht \u00FCber deine Frauen, dein Aussehen &amp; deinen Kleidungsstil. Und ich sag: Lasst ihn, der Mann ist Musiker!\u00BB",
  "id" : 450961209131810816,
  "created_at" : "2014-04-01 11:41:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]