Grailbird.data.tweets_2012_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openaccess",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/Csk0KHaI",
      "expanded_url" : "http:\/\/svpow.wordpress.com\/2012\/02\/29\/five-people-every-second-are-denied-access-to-jstor\/",
      "display_url" : "svpow.wordpress.com\/2012\/02\/29\/fiv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "174992110100025344",
  "text" : "Every second five people are forced to stay uneducated http:\/\/t.co\/Csk0KHaI #openaccess",
  "id" : 174992110100025344,
  "created_at" : "2012-02-29 22:59:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/XOUl5dW7",
      "expanded_url" : "http:\/\/j.mp\/xTuX4n",
      "display_url" : "j.mp\/xTuX4n"
    } ]
  },
  "geo" : { },
  "id_str" : "174984922841362433",
  "text" : "Atom Bomber: Practice Bombing. Improve Your Score! http:\/\/t.co\/XOUl5dW7",
  "id" : 174984922841362433,
  "created_at" : "2012-02-29 22:30:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174975120106991616",
  "geo" : { },
  "id_str" : "174975253083197440",
  "in_reply_to_user_id" : 44625441,
  "text" : "@tuxwurf Ich komme ja morgen Nacht schon zur\u00FCck. Hab hier lustig einen Workshop besucht",
  "id" : 174975253083197440,
  "in_reply_to_status_id" : 174975120106991616,
  "created_at" : "2012-02-29 21:52:05 +0000",
  "in_reply_to_screen_name" : "juriroemer",
  "in_reply_to_user_id_str" : "44625441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174974546296840192",
  "geo" : { },
  "id_str" : "174974656682541056",
  "in_reply_to_user_id" : 44625441,
  "text" : "@tuxwurf Jo, und hier auf dem Lande fahren die Busse auch nur alle Stunde. Wenn sie \u00FCberhaupt kommen :D",
  "id" : 174974656682541056,
  "in_reply_to_status_id" : 174974546296840192,
  "created_at" : "2012-02-29 21:49:43 +0000",
  "in_reply_to_screen_name" : "juriroemer",
  "in_reply_to_user_id_str" : "44625441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/N0hAoOP4",
      "expanded_url" : "http:\/\/maps.google.co.uk\/maps?q=Fulbourn&hl=en&ll=52.182774,0.218697&spn=0.087255,0.162048&sll=53.800651,-4.064941&sspn=21.613333,41.484375&oq=fulbourn&hnear=Fulbourn,+Cambridgeshire,+United+Kingdom&t=m&z=13",
      "display_url" : "maps.google.co.uk\/maps?q=Fulbour\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "174973805767303168",
  "geo" : { },
  "id_str" : "174974153760313344",
  "in_reply_to_user_id" : 44625441,
  "text" : "@tuxwurf Naja, wenn man ohne Datenverbindung ungef\u00E4hr da steht wo man vorher noch nie war ;) http:\/\/t.co\/N0hAoOP4",
  "id" : 174974153760313344,
  "in_reply_to_status_id" : 174973805767303168,
  "created_at" : "2012-02-29 21:47:43 +0000",
  "in_reply_to_screen_name" : "juriroemer",
  "in_reply_to_user_id_str" : "44625441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174973346734284800",
  "geo" : { },
  "id_str" : "174973430754590721",
  "in_reply_to_user_id" : 44625441,
  "text" : "@tuxwurf Ne, aber eine Bushaltestelle zu fr\u00FCh ausgestiegen. :D",
  "id" : 174973430754590721,
  "in_reply_to_status_id" : 174973346734284800,
  "created_at" : "2012-02-29 21:44:51 +0000",
  "in_reply_to_screen_name" : "juriroemer",
  "in_reply_to_user_id_str" : "44625441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174971918154334210",
  "text" : "Downloading the OpenStreetMap-information for the area using ForeverMap just saved my life.",
  "id" : 174971918154334210,
  "created_at" : "2012-02-29 21:38:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KT Pickard",
      "screen_name" : "kthomaspickard",
      "indices" : [ 0, 15 ],
      "id_str" : "267282720",
      "id" : 267282720
    }, {
      "name" : "Leonard Kish",
      "screen_name" : "leonardkish",
      "indices" : [ 16, 28 ],
      "id_str" : "18089164",
      "id" : 18089164
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openself",
      "indices" : [ 36, 45 ]
    }, {
      "text" : "openmeddata",
      "indices" : [ 50, 62 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174915314440609794",
  "geo" : { },
  "id_str" : "174969974165737473",
  "in_reply_to_user_id" : 267282720,
  "text" : "@kthomaspickard @leonardkish I like #openself but #openmeddata would be a good start for this :)",
  "id" : 174969974165737473,
  "in_reply_to_status_id" : 174915314440609794,
  "created_at" : "2012-02-29 21:31:07 +0000",
  "in_reply_to_screen_name" : "kthomaspickard",
  "in_reply_to_user_id_str" : "267282720",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hartmut Semken",
      "screen_name" : "hase_berlin",
      "indices" : [ 0, 12 ],
      "id_str" : "72919301",
      "id" : 72919301
    }, {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 22, 33 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174909238609592320",
  "geo" : { },
  "id_str" : "174969442739027968",
  "in_reply_to_user_id" : 72919301,
  "text" : "@hase_berlin 77 waren @plaetzchen und ich aber noch nicht geboren ;)",
  "id" : 174969442739027968,
  "in_reply_to_status_id" : 174909238609592320,
  "created_at" : "2012-02-29 21:29:00 +0000",
  "in_reply_to_screen_name" : "hase_berlin",
  "in_reply_to_user_id_str" : "72919301",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffa",
      "screen_name" : "rei_in_der_tube",
      "indices" : [ 0, 16 ],
      "id_str" : "19707954",
      "id" : 19707954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174893587111227393",
  "geo" : { },
  "id_str" : "174893766065393666",
  "in_reply_to_user_id" : 19707954,
  "text" : "@rei_in_der_tube Ah, cool. Das hatte ich aufgrund der zeitlichen N\u00E4he fast vermutet. ;)",
  "id" : 174893766065393666,
  "in_reply_to_status_id" : 174893587111227393,
  "created_at" : "2012-02-29 16:28:17 +0000",
  "in_reply_to_screen_name" : "rei_in_der_tube",
  "in_reply_to_user_id_str" : "19707954",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffa",
      "screen_name" : "rei_in_der_tube",
      "indices" : [ 0, 16 ],
      "id_str" : "19707954",
      "id" : 19707954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174892215410229250",
  "geo" : { },
  "id_str" : "174892382192541696",
  "in_reply_to_user_id" : 19707954,
  "text" : "@rei_in_der_tube Nice, was wirst du machen?",
  "id" : 174892382192541696,
  "in_reply_to_status_id" : 174892215410229250,
  "created_at" : "2012-02-29 16:22:47 +0000",
  "in_reply_to_screen_name" : "rei_in_der_tube",
  "in_reply_to_user_id_str" : "19707954",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/e76tUuJy",
      "expanded_url" : "http:\/\/patshaughnessy.net\/2012\/2\/29\/the-joke-is-on-us-how-ruby-1-9-supports-the-goto-statement",
      "display_url" : "patshaughnessy.net\/2012\/2\/29\/the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "174889848598044672",
  "text" : "This is just how we work at openSNP http:\/\/t.co\/e76tUuJy",
  "id" : 174889848598044672,
  "created_at" : "2012-02-29 16:12:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174878661575573504",
  "geo" : { },
  "id_str" : "174878703455715328",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher :D",
  "id" : 174878703455715328,
  "in_reply_to_status_id" : 174878661575573504,
  "created_at" : "2012-02-29 15:28:26 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174877927505276928",
  "geo" : { },
  "id_str" : "174878461578579969",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher Ja, aber kannst du deinen Torrent-Client auf Uni-Interne Peers beschr\u00E4nken? :P",
  "id" : 174878461578579969,
  "in_reply_to_status_id" : 174877927505276928,
  "created_at" : "2012-02-29 15:27:28 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 0, 11 ],
      "id_str" : "16084074",
      "id" : 16084074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174877877433679876",
  "geo" : { },
  "id_str" : "174878374106370048",
  "in_reply_to_user_id" : 16084074,
  "text" : "@sofakissen Ich bin bis Freitag aus der Planung raus. Komme erst dann wieder in .de an.",
  "id" : 174878374106370048,
  "in_reply_to_status_id" : 174877877433679876,
  "created_at" : "2012-02-29 15:27:08 +0000",
  "in_reply_to_screen_name" : "sofakissen",
  "in_reply_to_user_id_str" : "16084074",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174876957358555137",
  "geo" : { },
  "id_str" : "174877545114775553",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher 30 GB? Das ist doch in maximal 14 Tagen verbraucht",
  "id" : 174877545114775553,
  "in_reply_to_status_id" : 174876957358555137,
  "created_at" : "2012-02-29 15:23:50 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tarzun",
      "screen_name" : "tarzun",
      "indices" : [ 0, 7 ],
      "id_str" : "1632280560",
      "id" : 1632280560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174869716328910848",
  "geo" : { },
  "id_str" : "174870108223709185",
  "in_reply_to_user_id" : 45513907,
  "text" : "@tarzun Nicht? Ich dachte ich w\u00E4re die l\u00E4stigen Moderationen endlich los",
  "id" : 174870108223709185,
  "in_reply_to_status_id" : 174869716328910848,
  "created_at" : "2012-02-29 14:54:17 +0000",
  "in_reply_to_screen_name" : "klauspeukert",
  "in_reply_to_user_id_str" : "45513907",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 7, 15 ],
      "id_str" : "621716753",
      "id" : 621716753
    }, {
      "name" : "antiprodukt",
      "screen_name" : "antiprodukt",
      "indices" : [ 16, 28 ],
      "id_str" : "149089037",
      "id" : 149089037
    }, {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 29, 42 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    }, {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 43, 54 ],
      "id_str" : "16084074",
      "id" : 16084074
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 60, 69 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174852119290060800",
  "geo" : { },
  "id_str" : "174852435641249793",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ @Scytale @antiprodukt @Naturalismus @sofakissen Also @Senficon und ich haben ein vergleichsweise (ref. Hotel) gro\u00DFes Wohnzimmer ;)",
  "id" : 174852435641249793,
  "in_reply_to_status_id" : 174852119290060800,
  "created_at" : "2012-02-29 13:44:03 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/xKYoH2S3",
      "expanded_url" : "http:\/\/gedankenstuecke.github.com",
      "display_url" : "gedankenstuecke.github.com"
    } ]
  },
  "in_reply_to_status_id_str" : "174795182254989313",
  "geo" : { },
  "id_str" : "174795312345526272",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 ist schnell aufgesetzt und markdown-writing+git = super. spiele gerade selbst damit rum: http:\/\/t.co\/xKYoH2S3",
  "id" : 174795312345526272,
  "in_reply_to_status_id" : 174795182254989313,
  "created_at" : "2012-02-29 09:57:04 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174794129300140032",
  "geo" : { },
  "id_str" : "174794254235877376",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 l\u00E4sst sich auf github-pages betreiben :D",
  "id" : 174794254235877376,
  "in_reply_to_status_id" : 174794129300140032,
  "created_at" : "2012-02-29 09:52:52 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174790900067733504",
  "geo" : { },
  "id_str" : "174793451769044992",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 Octopress!",
  "id" : 174793451769044992,
  "in_reply_to_status_id" : 174790900067733504,
  "created_at" : "2012-02-29 09:49:41 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174769525361868800",
  "text" : "RT @PhilippBayer: Tweeting science-news from a car in a dingy side-road! \u00D6tzi genome released, was related to Sardinians, had brown eyes ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/E6xVzZBx",
        "expanded_url" : "http:\/\/medicaldaily.com\/news\/20120228\/9194\/%C3%96tzi-iceman-alps-mummy-lactose-intolerant-type-o-blood-brown-eyes.htm",
        "display_url" : "medicaldaily.com\/news\/20120228\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "174766066881409024",
    "text" : "Tweeting science-news from a car in a dingy side-road! \u00D6tzi genome released, was related to Sardinians, had brown eyes http:\/\/t.co\/E6xVzZBx",
    "id" : 174766066881409024,
    "created_at" : "2012-02-29 08:00:51 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 174769525361868800,
  "created_at" : "2012-02-29 08:14:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bora Zivkovic",
      "screen_name" : "BoraZ",
      "indices" : [ 3, 9 ],
      "id_str" : "17567533",
      "id" : 17567533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SciFund",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/fAoHlsEf",
      "expanded_url" : "http:\/\/bit.ly\/z6P8cy",
      "display_url" : "bit.ly\/z6P8cy"
    } ]
  },
  "geo" : { },
  "id_str" : "174641699006595073",
  "text" : "RT @BoraZ: Does Going Big Mean Going Home? Target Goal and Funding Success in #SciFund  http:\/\/t.co\/fAoHlsEf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SciFund",
        "indices" : [ 67, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/fAoHlsEf",
        "expanded_url" : "http:\/\/bit.ly\/z6P8cy",
        "display_url" : "bit.ly\/z6P8cy"
      } ]
    },
    "geo" : { },
    "id_str" : "174639886421340162",
    "text" : "Does Going Big Mean Going Home? Target Goal and Funding Success in #SciFund  http:\/\/t.co\/fAoHlsEf",
    "id" : 174639886421340162,
    "created_at" : "2012-02-28 23:39:28 +0000",
    "user" : {
      "name" : "Bora Zivkovic",
      "screen_name" : "BoraZ",
      "protected" : false,
      "id_str" : "17567533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3651779136\/b927bab618cdf46063f9c265817f3a8a_normal.jpeg",
      "id" : 17567533,
      "verified" : false
    }
  },
  "id" : 174641699006595073,
  "created_at" : "2012-02-28 23:46:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/PNEu3bf5",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plosone\/Neuroscience\/~3\/XEDKMSeY7Q4\/info%3Adoi%2F10.1371%2Fjournal.pone.0032132",
      "display_url" : "feeds.plos.org\/~r\/plosone\/Neu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.17851454, 0.25579154 ]
  },
  "id_str" : "174628677697552384",
  "text" : "Impairment of Vowel Articulation as a Possible Marker of Disease Progression in Parkinson's Disease http:\/\/t.co\/PNEu3bf5",
  "id" : 174628677697552384,
  "created_at" : "2012-02-28 22:54:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/QSzcStTJ",
      "expanded_url" : "http:\/\/google.com",
      "display_url" : "google.com"
    } ]
  },
  "geo" : { },
  "id_str" : "174610496702513152",
  "text" : "8.8.8.8 fails at resolving http:\/\/t.co\/QSzcStTJ...",
  "id" : 174610496702513152,
  "created_at" : "2012-02-28 21:42:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174497023599452161",
  "text" : "\u00C4hm: Irgendwo cached Chrome JavaScript-Zeugs und f\u00FChrt es beim wiederholten Seitenbesuch neu aus?! Meh..",
  "id" : 174497023599452161,
  "created_at" : "2012-02-28 14:11:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174496545683673088",
  "geo" : { },
  "id_str" : "174496833471643649",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Juhu, ich muss also bald nach Hause kommen :P",
  "id" : 174496833471643649,
  "in_reply_to_status_id" : 174496545683673088,
  "created_at" : "2012-02-28 14:11:01 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nciksf",
      "screen_name" : "nciksf",
      "indices" : [ 0, 7 ],
      "id_str" : "970518667",
      "id" : 970518667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174428024475881472",
  "geo" : { },
  "id_str" : "174428457080586240",
  "in_reply_to_user_id" : 418772257,
  "text" : "@nciksf Ne, ich glaube es wird mehr. Weil Dinge die jetzt als Verboten deklariert sind dann versucht werden als Fair Use zu managen.",
  "id" : 174428457080586240,
  "in_reply_to_status_id" : 174428024475881472,
  "created_at" : "2012-02-28 09:39:19 +0000",
  "in_reply_to_screen_name" : "ncikf",
  "in_reply_to_user_id_str" : "418772257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nciksf",
      "screen_name" : "nciksf",
      "indices" : [ 0, 7 ],
      "id_str" : "970518667",
      "id" : 970518667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174424808979832832",
  "geo" : { },
  "id_str" : "174424907747311616",
  "in_reply_to_user_id" : 418772257,
  "text" : "@nciksf Fair Use erzeugt halt einfach keine rechtliche Sicherheit.",
  "id" : 174424907747311616,
  "in_reply_to_status_id" : 174424808979832832,
  "created_at" : "2012-02-28 09:25:13 +0000",
  "in_reply_to_screen_name" : "ncikf",
  "in_reply_to_user_id_str" : "418772257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nciksf",
      "screen_name" : "nciksf",
      "indices" : [ 0, 7 ],
      "id_str" : "970518667",
      "id" : 970518667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174412891678703616",
  "geo" : { },
  "id_str" : "174423683551604737",
  "in_reply_to_user_id" : 418772257,
  "text" : "@nciksf Auch Auseinandersetzungen wie diese w\u00FCrde dann einfach vor Gericht gef\u00FChrt oder damit gedroht.",
  "id" : 174423683551604737,
  "in_reply_to_status_id" : 174412891678703616,
  "created_at" : "2012-02-28 09:20:21 +0000",
  "in_reply_to_screen_name" : "ncikf",
  "in_reply_to_user_id_str" : "418772257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/5cBx76Wj",
      "expanded_url" : "http:\/\/j.mp\/xwOp2Z",
      "display_url" : "j.mp\/xwOp2Z"
    } ]
  },
  "geo" : { },
  "id_str" : "174399750748123137",
  "text" : "Bwahaha, als ob: \u00ABEine \u201CFair-Use\u201D-Regelung nach US-Vorbild w\u00FCrde rechtliche Unklarheiten von vornherein verhindern\u00BB http:\/\/t.co\/5cBx76Wj",
  "id" : 174399750748123137,
  "created_at" : "2012-02-28 07:45:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/Gr2yUDWE",
      "expanded_url" : "http:\/\/j.mp\/z1wDda",
      "display_url" : "j.mp\/z1wDda"
    } ]
  },
  "geo" : { },
  "id_str" : "174396795848372224",
  "text" : "WTF?! The Badgermin http:\/\/t.co\/Gr2yUDWE",
  "id" : 174396795848372224,
  "created_at" : "2012-02-28 07:33:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 3, 16 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/Fe8ECzUg",
      "expanded_url" : "http:\/\/slate.me\/zAfWo7",
      "display_url" : "slate.me\/zAfWo7"
    } ]
  },
  "geo" : { },
  "id_str" : "174390223243980800",
  "text" : "RT @MishaAngrist: Why Don't You Have the Right To Access Your Own Biometric Data? http:\/\/t.co\/Fe8ECzUg  Um, because the world is insane.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/Fe8ECzUg",
        "expanded_url" : "http:\/\/slate.me\/zAfWo7",
        "display_url" : "slate.me\/zAfWo7"
      } ]
    },
    "geo" : { },
    "id_str" : "174326512965779457",
    "text" : "Why Don't You Have the Right To Access Your Own Biometric Data? http:\/\/t.co\/Fe8ECzUg  Um, because the world is insane.",
    "id" : 174326512965779457,
    "created_at" : "2012-02-28 02:54:14 +0000",
    "user" : {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "protected" : false,
      "id_str" : "116877838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747461459974717441\/GIrZkLT-_normal.jpg",
      "id" : 116877838,
      "verified" : false
    }
  },
  "id" : 174390223243980800,
  "created_at" : "2012-02-28 07:07:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/vQT0Fx07",
      "expanded_url" : "http:\/\/j.mp\/xPX9Eo",
      "display_url" : "j.mp\/xPX9Eo"
    } ]
  },
  "geo" : { },
  "id_str" : "174276696168599554",
  "text" : "Signatures of Selection in the Genomes of Commercial and Non-Commercial Chicken Breeds http:\/\/t.co\/vQT0Fx07",
  "id" : 174276696168599554,
  "created_at" : "2012-02-27 23:36:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 3, 11 ],
      "id_str" : "621716753",
      "id" : 621716753
    }, {
      "name" : "Matthias L\u00FCbken",
      "screen_name" : "luebken",
      "indices" : [ 96, 104 ],
      "id_str" : "14146629",
      "id" : 14146629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/Kf6bYh7L",
      "expanded_url" : "http:\/\/is.gd\/xm2IAN",
      "display_url" : "is.gd\/xm2IAN"
    } ]
  },
  "geo" : { },
  "id_str" : "174044956892213249",
  "text" : "RT @Scytale: Spannend: Wie Martin Varsavsky seine Zeit optimal nutzt. http:\/\/t.co\/Kf6bYh7L (via @luebken)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthias L\u00FCbken",
        "screen_name" : "luebken",
        "indices" : [ 83, 91 ],
        "id_str" : "14146629",
        "id" : 14146629
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/Kf6bYh7L",
        "expanded_url" : "http:\/\/is.gd\/xm2IAN",
        "display_url" : "is.gd\/xm2IAN"
      } ]
    },
    "geo" : { },
    "id_str" : "174042461281337344",
    "text" : "Spannend: Wie Martin Varsavsky seine Zeit optimal nutzt. http:\/\/t.co\/Kf6bYh7L (via @luebken)",
    "id" : 174042461281337344,
    "created_at" : "2012-02-27 08:05:30 +0000",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640094846196150272\/6X7gF8lF_normal.png",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 174044956892213249,
  "created_at" : "2012-02-27 08:15:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 3, 18 ],
      "id_str" : "73134122",
      "id" : 73134122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/ouXGaYkE",
      "expanded_url" : "http:\/\/goodcomics.comicbookresources.com\/2012\/02\/21\/she-has-no-head-no-its-not-equal\/",
      "display_url" : "goodcomics.comicbookresources.com\/2012\/02\/21\/she\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "174043123360600065",
  "text" : "RT @astefanowitsch: Damit euch nicht langweilig wird, lest diesen spannenden Text \u00FCber Comics und Diskriminierung: http:\/\/t.co\/ouXGaYkE  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "kegelklub",
        "screen_name" : "kegelklub",
        "indices" : [ 121, 131 ],
        "id_str" : "260979523",
        "id" : 260979523
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/ouXGaYkE",
        "expanded_url" : "http:\/\/goodcomics.comicbookresources.com\/2012\/02\/21\/she-has-no-head-no-its-not-equal\/",
        "display_url" : "goodcomics.comicbookresources.com\/2012\/02\/21\/she\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "174041121931005952",
    "text" : "Damit euch nicht langweilig wird, lest diesen spannenden Text \u00FCber Comics und Diskriminierung: http:\/\/t.co\/ouXGaYkE (via @kegelklub)",
    "id" : 174041121931005952,
    "created_at" : "2012-02-27 08:00:11 +0000",
    "user" : {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "protected" : false,
      "id_str" : "73134122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711229669404766208\/lqYXKwzM_normal.jpg",
      "id" : 73134122,
      "verified" : true
    }
  },
  "id" : 174043123360600065,
  "created_at" : "2012-02-27 08:08:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerrit",
      "screen_name" : "GerritEicker",
      "indices" : [ 0, 13 ],
      "id_str" : "45082501",
      "id" : 45082501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174031581588111360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1806056187, 0.2171237241 ]
  },
  "id_str" : "174035883350179841",
  "in_reply_to_user_id" : 45082501,
  "text" : "@GerritEicker also ich f\u00E4nde Exorcism auch ganz ok :)",
  "id" : 174035883350179841,
  "in_reply_to_status_id" : 174031581588111360,
  "created_at" : "2012-02-27 07:39:22 +0000",
  "in_reply_to_screen_name" : "GerritEicker",
  "in_reply_to_user_id_str" : "45082501",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/UvmdQHWk",
      "expanded_url" : "http:\/\/j.mp\/x02cqn",
      "display_url" : "j.mp\/x02cqn"
    } ]
  },
  "geo" : { },
  "id_str" : "174035190795079680",
  "text" : "Five suggestions for Open Science evangelists http:\/\/t.co\/UvmdQHWk",
  "id" : 174035190795079680,
  "created_at" : "2012-02-27 07:36:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 4, 17 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/W8UfzKdX",
      "expanded_url" : "http:\/\/j.mp\/yt3R7a",
      "display_url" : "j.mp\/yt3R7a"
    } ]
  },
  "geo" : { },
  "id_str" : "174034080374079488",
  "text" : "Oh, @PhilippBayer hat mal erkl\u00E4rt wieso Wissenschaftler ihren Code nicht ver\u00F6ffentlichen http:\/\/t.co\/W8UfzKdX",
  "id" : 174034080374079488,
  "created_at" : "2012-02-27 07:32:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/IzCb4WKQ",
      "expanded_url" : "http:\/\/j.mp\/x3NqEC",
      "display_url" : "j.mp\/x3NqEC"
    } ]
  },
  "geo" : { },
  "id_str" : "174033313919537152",
  "text" : "The neuroscience of magic http:\/\/t.co\/IzCb4WKQ",
  "id" : 174033313919537152,
  "created_at" : "2012-02-27 07:29:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 3, 12 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/xCNDyl01",
      "expanded_url" : "http:\/\/www.groupon.de\/deals\/online-deal\/doktortitel-kaufende\/3616628?nlp=&CID=DE_CRM_1_0_0_58&a=1655",
      "display_url" : "groupon.de\/deals\/online-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "174030523704950784",
  "text" : "RT @Argent23: Doktortitel sind heute auch billiger zu haben als zu meiner Zeit... http:\/\/t.co\/xCNDyl01 die Fachbereiche sprechen allerdi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/xCNDyl01",
        "expanded_url" : "http:\/\/www.groupon.de\/deals\/online-deal\/doktortitel-kaufende\/3616628?nlp=&CID=DE_CRM_1_0_0_58&a=1655",
        "display_url" : "groupon.de\/deals\/online-d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "174029503784423425",
    "text" : "Doktortitel sind heute auch billiger zu haben als zu meiner Zeit... http:\/\/t.co\/xCNDyl01 die Fachbereiche sprechen allerdings f\u00FCr sich.",
    "id" : 174029503784423425,
    "created_at" : "2012-02-27 07:14:01 +0000",
    "user" : {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "protected" : false,
      "id_str" : "22828618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1118469929\/13410001_bearbeitet_klein_normal.jpg",
      "id" : 22828618,
      "verified" : false
    }
  },
  "id" : 174030523704950784,
  "created_at" : "2012-02-27 07:18:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.1805591542, 0.217140178 ]
  },
  "id_str" : "174029414382841856",
  "text" : "Moin moin.",
  "id" : 174029414382841856,
  "created_at" : "2012-02-27 07:13:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/HRKMaCSV",
      "expanded_url" : "http:\/\/j.mp\/z84rXc",
      "display_url" : "j.mp\/z84rXc"
    } ]
  },
  "geo" : { },
  "id_str" : "173889535736950784",
  "text" : "Surprise: If you want reproducible science, the software needs to be open source http:\/\/t.co\/HRKMaCSV",
  "id" : 173889535736950784,
  "created_at" : "2012-02-26 21:57:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173888783283007488",
  "text" : "Angekommen.",
  "id" : 173888783283007488,
  "created_at" : "2012-02-26 21:54:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173825001361899520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9470225112, 7.2704771904 ]
  },
  "id_str" : "173825993386102784",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju okay, ich w\u00FCrde mir immer noch etwas vergleichbares zu TabKit w\u00FCnschen.",
  "id" : 173825993386102784,
  "in_reply_to_status_id" : 173825001361899520,
  "created_at" : "2012-02-26 17:45:21 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173820769283997696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9469108474, 7.2704986527 ]
  },
  "id_str" : "173824846705344512",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju nutzt du irgendeine Extension zur Verwaltung davon?",
  "id" : 173824846705344512,
  "in_reply_to_status_id" : 173820769283997696,
  "created_at" : "2012-02-26 17:40:47 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    }, {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 12, 19 ],
      "id_str" : "41419667",
      "id" : 41419667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173816348923789315",
  "geo" : { },
  "id_str" : "173816570903134211",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach @lutoma Dann bin ich ja beruhigt :)",
  "id" : 173816570903134211,
  "in_reply_to_status_id" : 173816348923789315,
  "created_at" : "2012-02-26 17:07:54 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173816154194849792",
  "text" : "Cool, openSNP has its first users who've got data from more than one DTC provider.",
  "id" : 173816154194849792,
  "created_at" : "2012-02-26 17:06:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/csOavRMT",
      "expanded_url" : "http:\/\/imgur.com\/r\/biology\/HZXIH",
      "display_url" : "imgur.com\/r\/biology\/HZXIH"
    } ]
  },
  "geo" : { },
  "id_str" : "173813763634495490",
  "text" : "\u00ABAstronauts. Because everybody doesn't get to be a marine biologist when they grow up\u00BB http:\/\/t.co\/csOavRMT",
  "id" : 173813763634495490,
  "created_at" : "2012-02-26 16:56:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 0, 7 ],
      "id_str" : "41419667",
      "id" : 41419667
    }, {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 21, 32 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173809683545587712",
  "geo" : { },
  "id_str" : "173813382514872320",
  "in_reply_to_user_id" : 41419667,
  "text" : "@lutoma Oh, hat sich @HerrUrbach aus der Kette entfernt? Der m\u00FCsste da auch noch drinh\u00E4ngen ;)",
  "id" : 173813382514872320,
  "in_reply_to_status_id" : 173809683545587712,
  "created_at" : "2012-02-26 16:55:14 +0000",
  "in_reply_to_screen_name" : "lutoma",
  "in_reply_to_user_id_str" : "41419667",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 0, 7 ],
      "id_str" : "41419667",
      "id" : 41419667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173794278793945088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9468784875, 7.270635862 ]
  },
  "id_str" : "173808567772643329",
  "in_reply_to_user_id" : 41419667,
  "text" : "@lutoma das hei\u00DFt ich muss das jetzt wieder regelm\u00E4\u00DFig nutzen? ;)",
  "id" : 173808567772643329,
  "in_reply_to_status_id" : 173794278793945088,
  "created_at" : "2012-02-26 16:36:06 +0000",
  "in_reply_to_screen_name" : "lutoma",
  "in_reply_to_user_id_str" : "41419667",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Padraig Reidy",
      "screen_name" : "mePadraigReidy",
      "indices" : [ 3, 18 ],
      "id_str" : "61451642",
      "id" : 61451642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173778740315303937",
  "text" : "RT @mePadraigReidy: \"A copy of safety info in Braille is available on request. Please ask train manager if you see him passing trough th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173777920467279872",
    "text" : "\"A copy of safety info in Braille is available on request. Please ask train manager if you see him passing trough the train\"",
    "id" : 173777920467279872,
    "created_at" : "2012-02-26 14:34:19 +0000",
    "user" : {
      "name" : "Padraig Reidy",
      "screen_name" : "mePadraigReidy",
      "protected" : false,
      "id_str" : "61451642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816668518578061312\/dr2BQlIv_normal.jpg",
      "id" : 61451642,
      "verified" : false
    }
  },
  "id" : 173778740315303937,
  "created_at" : "2012-02-26 14:37:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0022610346, 8.2593559787 ]
  },
  "id_str" : "173769292888809472",
  "text" : "Auf zum Flughafen.",
  "id" : 173769292888809472,
  "created_at" : "2012-02-26 14:00:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/We1BKhKP",
      "expanded_url" : "http:\/\/j.mp\/zvIK7I",
      "display_url" : "j.mp\/zvIK7I"
    } ]
  },
  "geo" : { },
  "id_str" : "173706821800955904",
  "text" : "rs9325113: A Genome-Wide Linkage and Association Scan Reveals Novel Loci for Hypertension and Blood Pressure Traits http:\/\/t.co\/We1BKhKP",
  "id" : 173706821800955904,
  "created_at" : "2012-02-26 09:51:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/8aiCFG2V",
      "expanded_url" : "http:\/\/j.mp\/xgNoh5",
      "display_url" : "j.mp\/xgNoh5"
    } ]
  },
  "geo" : { },
  "id_str" : "173328720340324352",
  "text" : "+\/- was ich im letzten Praktikum gemacht hab: Primer Design for Analysis of Pop. Genetics in Non-Sequenced Organisms http:\/\/t.co\/8aiCFG2V",
  "id" : 173328720340324352,
  "created_at" : "2012-02-25 08:49:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/82ZKZDj0",
      "expanded_url" : "http:\/\/j.mp\/xKTUO8",
      "display_url" : "j.mp\/xKTUO8"
    } ]
  },
  "geo" : { },
  "id_str" : "173327232784281601",
  "text" : "A Putative Risk Factor for Gastric Cancer http:\/\/t.co\/82ZKZDj0",
  "id" : 173327232784281601,
  "created_at" : "2012-02-25 08:43:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Rosenau",
      "screen_name" : "JoshRosenau",
      "indices" : [ 3, 15 ],
      "id_str" : "88290488",
      "id" : 88290488
    }, {
      "name" : "John S. Wilkins",
      "screen_name" : "john_s_wilkins",
      "indices" : [ 57, 72 ],
      "id_str" : "76013938",
      "id" : 76013938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/byMZtTyM",
      "expanded_url" : "http:\/\/bit.ly\/yAnT4Q",
      "display_url" : "bit.ly\/yAnT4Q"
    } ]
  },
  "geo" : { },
  "id_str" : "173324004889862144",
  "text" : "RT @JoshRosenau: Hire this man! I need his blog back. RT @john_s_wilkins: Evolving Thoughts may shut down for a while http:\/\/t.co\/byMZtTyM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John S. Wilkins",
        "screen_name" : "john_s_wilkins",
        "indices" : [ 40, 55 ],
        "id_str" : "76013938",
        "id" : 76013938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/byMZtTyM",
        "expanded_url" : "http:\/\/bit.ly\/yAnT4Q",
        "display_url" : "bit.ly\/yAnT4Q"
      } ]
    },
    "geo" : { },
    "id_str" : "173289562435633152",
    "text" : "Hire this man! I need his blog back. RT @john_s_wilkins: Evolving Thoughts may shut down for a while http:\/\/t.co\/byMZtTyM",
    "id" : 173289562435633152,
    "created_at" : "2012-02-25 06:13:45 +0000",
    "user" : {
      "name" : "Josh Rosenau",
      "screen_name" : "JoshRosenau",
      "protected" : false,
      "id_str" : "88290488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623587296542109696\/k32eU-yR_normal.jpg",
      "id" : 88290488,
      "verified" : false
    }
  },
  "id" : 173324004889862144,
  "created_at" : "2012-02-25 08:30:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/snxz8Q6p",
      "expanded_url" : "http:\/\/j.mp\/xXh1Y7",
      "display_url" : "j.mp\/xXh1Y7"
    } ]
  },
  "geo" : { },
  "id_str" : "173161870310641666",
  "text" : "The myth of the eight-hour sleep http:\/\/t.co\/snxz8Q6p",
  "id" : 173161870310641666,
  "created_at" : "2012-02-24 21:46:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173161209753911296",
  "text" : "Work of the day: openSNP finally passes all tests again.",
  "id" : 173161209753911296,
  "created_at" : "2012-02-24 21:43:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "indices" : [ 3, 18 ],
      "id_str" : "19416598",
      "id" : 19416598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/eYfgiCcX",
      "expanded_url" : "http:\/\/nyti.ms\/xWHbFw",
      "display_url" : "nyti.ms\/xWHbFw"
    } ]
  },
  "geo" : { },
  "id_str" : "173156602982043648",
  "text" : "RT @leonidkruglyak: Mining company and the EPA say selenium levels just fine, despite MUTANT TWO-HEADED TROUT http:\/\/t.co\/eYfgiCcX and h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/eYfgiCcX",
        "expanded_url" : "http:\/\/nyti.ms\/xWHbFw",
        "display_url" : "nyti.ms\/xWHbFw"
      }, {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/0x8fhp6q",
        "expanded_url" : "http:\/\/nyti.ms\/Almm8H",
        "display_url" : "nyti.ms\/Almm8H"
      } ]
    },
    "geo" : { },
    "id_str" : "172889970858663938",
    "text" : "Mining company and the EPA say selenium levels just fine, despite MUTANT TWO-HEADED TROUT http:\/\/t.co\/eYfgiCcX and http:\/\/t.co\/0x8fhp6q",
    "id" : 172889970858663938,
    "created_at" : "2012-02-24 03:45:55 +0000",
    "user" : {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "protected" : false,
      "id_str" : "19416598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1095542276\/MyRecentPhoto_normal.jpg",
      "id" : 19416598,
      "verified" : false
    }
  },
  "id" : 173156602982043648,
  "created_at" : "2012-02-24 21:25:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/rTOezC1s",
      "expanded_url" : "http:\/\/theatln.tc\/xtgNA5",
      "display_url" : "theatln.tc\/xtgNA5"
    } ]
  },
  "geo" : { },
  "id_str" : "173155786535612416",
  "text" : "RT @TheAtlanticTECH: Kickstarter expects to provide more funding than the National Endowment for the Arts this year http:\/\/t.co\/rTOezC1s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/rTOezC1s",
        "expanded_url" : "http:\/\/theatln.tc\/xtgNA5",
        "display_url" : "theatln.tc\/xtgNA5"
      } ]
    },
    "geo" : { },
    "id_str" : "173085728350289920",
    "text" : "Kickstarter expects to provide more funding than the National Endowment for the Arts this year http:\/\/t.co\/rTOezC1s",
    "id" : 173085728350289920,
    "created_at" : "2012-02-24 16:43:48 +0000",
    "user" : {
      "name" : "The Atlantic Tech",
      "screen_name" : "TheAtlTech",
      "protected" : false,
      "id_str" : "141335663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2624579126\/l2f3ixgtu7j2hxm9sq07_normal.png",
      "id" : 141335663,
      "verified" : true
    }
  },
  "id" : 173155786535612416,
  "created_at" : "2012-02-24 21:22:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 24, 33 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0084765493, 8.2826024735 ]
  },
  "id_str" : "173123471214256128",
  "text" : "Nerfguns bestellt damit @Senficon und ich Konflikte angemessen austragen k\u00F6nnen.",
  "id" : 173123471214256128,
  "created_at" : "2012-02-24 19:13:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/UNoa0UXb",
      "expanded_url" : "http:\/\/news.open-bio.org\/news\/2012\/02\/biopython-1-59-released",
      "display_url" : "news.open-bio.org\/news\/2012\/02\/b\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0099303927, 8.2832902101 ]
  },
  "id_str" : "173103256413806592",
  "text" : "Great Job! BioPython 1.59 has been released! http:\/\/t.co\/UNoa0UXb",
  "id" : 173103256413806592,
  "created_at" : "2012-02-24 17:53:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Reinboth",
      "screen_name" : "reinboth",
      "indices" : [ 0, 9 ],
      "id_str" : "17187345",
      "id" : 17187345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173052298367471616",
  "geo" : { },
  "id_str" : "173052546716401664",
  "in_reply_to_user_id" : 17187345,
  "text" : "@reinboth Na gut, das ist doch relativ eindeutig w\u00FCrde ich sagen: Artgrenzen sind im Auge der Evolution immer k\u00FCnstlich",
  "id" : 173052546716401664,
  "in_reply_to_status_id" : 173052298367471616,
  "created_at" : "2012-02-24 14:31:56 +0000",
  "in_reply_to_screen_name" : "reinboth",
  "in_reply_to_user_id_str" : "17187345",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Reinboth",
      "screen_name" : "reinboth",
      "indices" : [ 0, 9 ],
      "id_str" : "17187345",
      "id" : 17187345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173051444688199681",
  "geo" : { },
  "id_str" : "173051771311226881",
  "in_reply_to_user_id" : 17187345,
  "text" : "@reinboth Mit welcher Artdefinition versuchen sie es denn? ;)",
  "id" : 173051771311226881,
  "in_reply_to_status_id" : 173051444688199681,
  "created_at" : "2012-02-24 14:28:52 +0000",
  "in_reply_to_screen_name" : "reinboth",
  "in_reply_to_user_id_str" : "17187345",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/zAEK9L2E",
      "expanded_url" : "http:\/\/fakeelsevier.wordpress.com\/2012\/02\/19\/dear-elsevier-employees-with-love-from-fakeelsevier\/#comment-86",
      "display_url" : "fakeelsevier.wordpress.com\/2012\/02\/19\/dea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "173024639252054017",
  "text" : "\u00ABBut still, you know, credit where credit\u2019s due. Elsevier doesn\u2019t kill babies. Directly. Any longer.\u00BB http:\/\/t.co\/zAEK9L2E",
  "id" : 173024639252054017,
  "created_at" : "2012-02-24 12:41:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172991371358117888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0121843476, 8.283899141 ]
  },
  "id_str" : "172992509910331393",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus und was ist das Thema? :)",
  "id" : 172992509910331393,
  "in_reply_to_status_id" : 172991371358117888,
  "created_at" : "2012-02-24 10:33:23 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172972205645365248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096661914, 8.2830044346 ]
  },
  "id_str" : "172975543422156800",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall manche m\u00FCssen halt nicht mal 70 werden um Anzeichen von Verwirrtheit zu zeigen ;)",
  "id" : 172975543422156800,
  "in_reply_to_status_id" : 172972205645365248,
  "created_at" : "2012-02-24 09:25:57 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 3, 12 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/qflp8Hyl",
      "expanded_url" : "http:\/\/m.techcrunch.com\/2012\/02\/23\/and-now-theres-a-kickstarter-for-porn\/",
      "display_url" : "m.techcrunch.com\/2012\/02\/23\/and\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "172972967179988993",
  "text" : "RT @snooze82: Warum bin ich nich darauf gekommen?? Kickstarter For Porn  http:\/\/t.co\/qflp8Hyl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.flipboard.com\" rel=\"nofollow\"\u003EFlipboard\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/qflp8Hyl",
        "expanded_url" : "http:\/\/m.techcrunch.com\/2012\/02\/23\/and-now-theres-a-kickstarter-for-porn\/",
        "display_url" : "m.techcrunch.com\/2012\/02\/23\/and\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "172970623931387904",
    "text" : "Warum bin ich nich darauf gekommen?? Kickstarter For Porn  http:\/\/t.co\/qflp8Hyl",
    "id" : 172970623931387904,
    "created_at" : "2012-02-24 09:06:25 +0000",
    "user" : {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "protected" : false,
      "id_str" : "14094265",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731789117483327488\/rs5L1Qbu_normal.jpg",
      "id" : 14094265,
      "verified" : false
    }
  },
  "id" : 172972967179988993,
  "created_at" : "2012-02-24 09:15:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/K1G4a6VT",
      "expanded_url" : "http:\/\/www.scienceblogs.de\/frischer-wind\/2012\/02\/gentechnikfreies-sachsenanhalt.php",
      "display_url" : "scienceblogs.de\/frischer-wind\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097261129, 8.2831752706 ]
  },
  "id_str" : "172968559675322368",
  "text" : "Ach Gr\u00FCne, warum so dumm? http:\/\/t.co\/K1G4a6VT",
  "id" : 172968559675322368,
  "created_at" : "2012-02-24 08:58:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    }, {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 7, 18 ],
      "id_str" : "16084074",
      "id" : 16084074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/JIqWWPSf",
      "expanded_url" : "http:\/\/rebellmarkt.blogger.de\/static\/antville\/rebellmarkt\/images\/reformrebell3.jpg",
      "display_url" : "rebellmarkt.blogger.de\/static\/antvill\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "172961989713338368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097987549, 8.2830632977 ]
  },
  "id_str" : "172966952145391616",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante @sofakissen hast das falsche Foto genommen. Der Don ist doch schon eh ein Meme: http:\/\/t.co\/JIqWWPSf",
  "id" : 172966952145391616,
  "in_reply_to_status_id" : 172961989713338368,
  "created_at" : "2012-02-24 08:51:49 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172817601242742784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097271627, 8.2832211193 ]
  },
  "id_str" : "172818628486512640",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon dann hast du halt gelitten. Das ist alt die archetypische Eso-Ethno-Veganerschiene.",
  "id" : 172818628486512640,
  "in_reply_to_status_id" : 172817601242742784,
  "created_at" : "2012-02-23 23:02:26 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172817144189427712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097584011, 8.2833353209 ]
  },
  "id_str" : "172817338234699777",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon klemm dir \u201C\u00ABDie Naturheilkunde\u00BB unter den Arm, dann bist du Undercover.",
  "id" : 172817338234699777,
  "in_reply_to_status_id" : 172817144189427712,
  "created_at" : "2012-02-23 22:57:18 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172792892287488000",
  "geo" : { },
  "id_str" : "172793308479893504",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus kaputte Kabel nicht vergessen ;)",
  "id" : 172793308479893504,
  "in_reply_to_status_id" : 172792892287488000,
  "created_at" : "2012-02-23 21:21:49 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172792398366248960",
  "geo" : { },
  "id_str" : "172792546899144705",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus Total bescheuert, gerade die miesen Messwerte sind das was man will. Das macht die Diskussion so einfach :D",
  "id" : 172792546899144705,
  "in_reply_to_status_id" : 172792398366248960,
  "created_at" : "2012-02-23 21:18:48 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/AU85Clro",
      "expanded_url" : "http:\/\/j.mp\/wd4Vzt",
      "display_url" : "j.mp\/wd4Vzt"
    } ]
  },
  "geo" : { },
  "id_str" : "172767701750661120",
  "text" : "Awesome Visuals: Radiation-eating Fungi-Tentacles in a post-nuclear World http:\/\/t.co\/AU85Clro",
  "id" : 172767701750661120,
  "created_at" : "2012-02-23 19:40:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/FQCsPlMr",
      "expanded_url" : "http:\/\/j.mp\/zGn6xF",
      "display_url" : "j.mp\/zGn6xF"
    } ]
  },
  "geo" : { },
  "id_str" : "172753077231824896",
  "text" : "Astrologers who claimed copyright on timezones apologize, drop lawsuit -- EFF declares victory! http:\/\/t.co\/FQCsPlMr",
  "id" : 172753077231824896,
  "created_at" : "2012-02-23 18:41:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 0, 15 ],
      "id_str" : "73134122",
      "id" : 73134122
    }, {
      "name" : "Quantenwelt",
      "screen_name" : "quantenwelt",
      "indices" : [ 16, 28 ],
      "id_str" : "38418484",
      "id" : 38418484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/qa2c1mE8",
      "expanded_url" : "http:\/\/octopress.org\/",
      "display_url" : "octopress.org"
    } ]
  },
  "in_reply_to_status_id_str" : "172691718657949696",
  "geo" : { },
  "id_str" : "172692190164828160",
  "in_reply_to_user_id" : 73134122,
  "text" : "@astefanowitsch @quantenwelt Genau das probiere ich gerade mal mit Octopress aus ;) http:\/\/t.co\/qa2c1mE8",
  "id" : 172692190164828160,
  "in_reply_to_status_id" : 172691718657949696,
  "created_at" : "2012-02-23 14:40:01 +0000",
  "in_reply_to_screen_name" : "astefanowitsch",
  "in_reply_to_user_id_str" : "73134122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/hF38zp5W",
      "expanded_url" : "http:\/\/instagr.am\/p\/HWXqICBwpT\/",
      "display_url" : "instagr.am\/p\/HWXqICBwpT\/"
    } ]
  },
  "geo" : { },
  "id_str" : "172671338308308992",
  "text" : "Cat Love http:\/\/t.co\/hF38zp5W",
  "id" : 172671338308308992,
  "created_at" : "2012-02-23 13:17:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universit\u00E4t M\u00FCnster",
      "screen_name" : "WWU_Muenster",
      "indices" : [ 79, 92 ],
      "id_str" : "24677217",
      "id" : 24677217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172624596099538944",
  "text" : "Not sure if win: Das Magazin \u00ABDie Naturheilkunde\u00BB hat die Pressemitteilung der @WWU_Muenster zu openSNP auch aufgegriffen.",
  "id" : 172624596099538944,
  "created_at" : "2012-02-23 10:11:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manfred Holl",
      "screen_name" : "Astroholl",
      "indices" : [ 84, 94 ],
      "id_str" : "59099100",
      "id" : 59099100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/88rNwinW",
      "expanded_url" : "http:\/\/de.arxiv.org\/abs\/1202.4792",
      "display_url" : "de.arxiv.org\/abs\/1202.4792"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0456639671, 8.4638733266 ]
  },
  "id_str" : "172615138539610112",
  "text" : "\u00ABIncorrect understanding of science, math & probability at an elementary level.\u00BB RT @Astroholl: Problems with Popper: http:\/\/t.co\/88rNwinW",
  "id" : 172615138539610112,
  "created_at" : "2012-02-23 09:33:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/MDseVrI2",
      "expanded_url" : "http:\/\/j.mp\/AaZ7FE",
      "display_url" : "j.mp\/AaZ7FE"
    } ]
  },
  "geo" : { },
  "id_str" : "172609610274963456",
  "text" : "Beware Reverse Publication Bias http:\/\/t.co\/MDseVrI2",
  "id" : 172609610274963456,
  "created_at" : "2012-02-23 09:11:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/YDA0qYEw",
      "expanded_url" : "http:\/\/j.mp\/AAUouY",
      "display_url" : "j.mp\/AAUouY"
    } ]
  },
  "geo" : { },
  "id_str" : "172587602459897857",
  "text" : "Kin Selection and the Evolution of Social Information Use in Animal Conflict http:\/\/t.co\/YDA0qYEw",
  "id" : 172587602459897857,
  "created_at" : "2012-02-23 07:44:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Shapiro",
      "screen_name" : "jashapiro",
      "indices" : [ 3, 13 ],
      "id_str" : "12286942",
      "id" : 12286942
    }, {
      "name" : "John Gruber",
      "screen_name" : "gruber",
      "indices" : [ 104, 111 ],
      "id_str" : "33423",
      "id" : 33423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172585282275774464",
  "text" : "RT @jashapiro: 'If they\u2019re planning to sell them for \u201C$250 to $600\u201D, isn\u2019t that a good business model?'-@gruber My thoughts exactly. htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Gruber",
        "screen_name" : "gruber",
        "indices" : [ 89, 96 ],
        "id_str" : "33423",
        "id" : 33423
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/4AF4lSjN",
        "expanded_url" : "http:\/\/daringfireball.net\/linked\/2012\/02\/22\/google-hud",
        "display_url" : "daringfireball.net\/linked\/2012\/02\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "172508306043187200",
    "text" : "'If they\u2019re planning to sell them for \u201C$250 to $600\u201D, isn\u2019t that a good business model?'-@gruber My thoughts exactly. http:\/\/t.co\/4AF4lSjN",
    "id" : 172508306043187200,
    "created_at" : "2012-02-23 02:29:19 +0000",
    "user" : {
      "name" : "Joshua Shapiro",
      "screen_name" : "jashapiro",
      "protected" : false,
      "id_str" : "12286942",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741309453459300352\/vt-tLqJL_normal.jpg",
      "id" : 12286942,
      "verified" : false
    }
  },
  "id" : 172585282275774464,
  "created_at" : "2012-02-23 07:35:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172505994415456257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0870441027, 8.5109102244 ]
  },
  "id_str" : "172585001790095360",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas have a good time!",
  "id" : 172585001790095360,
  "in_reply_to_status_id" : 172505994415456257,
  "created_at" : "2012-02-23 07:34:05 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Singh",
      "screen_name" : "mndoci",
      "indices" : [ 3, 10 ],
      "id_str" : "605643",
      "id" : 605643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/7XOWSyAy",
      "expanded_url" : "http:\/\/www.science.uva.nl\/math\/#item1329781416",
      "display_url" : "science.uva.nl\/math\/#item1329\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "172387375916384256",
  "text" : "RT @mndoci: Oh .. de Bruijn passed away last week :( http:\/\/t.co\/7XOWSyAy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/7XOWSyAy",
        "expanded_url" : "http:\/\/www.science.uva.nl\/math\/#item1329781416",
        "display_url" : "science.uva.nl\/math\/#item1329\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "172100024568782850",
    "text" : "Oh .. de Bruijn passed away last week :( http:\/\/t.co\/7XOWSyAy",
    "id" : 172100024568782850,
    "created_at" : "2012-02-21 23:26:57 +0000",
    "user" : {
      "name" : "Deepak Singh",
      "screen_name" : "mndoci",
      "protected" : false,
      "id_str" : "605643",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/858777767927853056\/0y8_mclc_normal.jpg",
      "id" : 605643,
      "verified" : false
    }
  },
  "id" : 172387375916384256,
  "created_at" : "2012-02-22 18:28:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 3, 13 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172372389940830208",
  "text" : "RT @kaythaney: \"Science Nation Army\" - cover of the White Stripes using lab equipment from Imperial College. Wicked. http:\/\/t.co\/n7EnL9F ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "geektunes",
        "indices" : [ 123, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/n7EnL9Fu",
        "expanded_url" : "http:\/\/bit.ly\/xHeGO7",
        "display_url" : "bit.ly\/xHeGO7"
      } ]
    },
    "geo" : { },
    "id_str" : "172372010964484096",
    "text" : "\"Science Nation Army\" - cover of the White Stripes using lab equipment from Imperial College. Wicked. http:\/\/t.co\/n7EnL9Fu #geektunes",
    "id" : 172372010964484096,
    "created_at" : "2012-02-22 17:27:44 +0000",
    "user" : {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "protected" : false,
      "id_str" : "22839233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932288468029509632\/_I0e0wgc_normal.jpg",
      "id" : 22839233,
      "verified" : false
    }
  },
  "id" : 172372389940830208,
  "created_at" : "2012-02-22 17:29:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/wwxhuPB4",
      "expanded_url" : "http:\/\/j.mp\/z2QSe5",
      "display_url" : "j.mp\/z2QSe5"
    } ]
  },
  "geo" : { },
  "id_str" : "172346284462702592",
  "text" : "Oh, do want: DIY \"Internet of Things\" printer http:\/\/t.co\/wwxhuPB4",
  "id" : 172346284462702592,
  "created_at" : "2012-02-22 15:45:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janice Loffreda-Wren",
      "screen_name" : "JLoffredaWren",
      "indices" : [ 0, 14 ],
      "id_str" : "115189249",
      "id" : 115189249
    }, {
      "name" : "Chris Lindsay",
      "screen_name" : "ChrisLindsay9",
      "indices" : [ 15, 29 ],
      "id_str" : "893758240114319371",
      "id" : 893758240114319371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172333051014160385",
  "geo" : { },
  "id_str" : "172333222934482945",
  "in_reply_to_user_id" : 115189249,
  "text" : "@JLoffredaWren @ChrisLindsay9 That's nice to hear. I think we should apply for additional funding to enable this for more people :)",
  "id" : 172333222934482945,
  "in_reply_to_status_id" : 172333051014160385,
  "created_at" : "2012-02-22 14:53:36 +0000",
  "in_reply_to_screen_name" : "JLoffredaWren",
  "in_reply_to_user_id_str" : "115189249",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Lindsay",
      "screen_name" : "ChrisLindsay9",
      "indices" : [ 0, 14 ],
      "id_str" : "893758240114319371",
      "id" : 893758240114319371
    }, {
      "name" : "Janice Loffreda-Wren",
      "screen_name" : "JLoffredaWren",
      "indices" : [ 15, 29 ],
      "id_str" : "115189249",
      "id" : 115189249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172328499447730176",
  "text" : "@ChrisLindsay9 @JLoffredaWren It's not that being WEIRD is a no-go, but if we have to choose we would like to balance it out. :)",
  "id" : 172328499447730176,
  "created_at" : "2012-02-22 14:34:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/ZZckRiU6",
      "expanded_url" : "http:\/\/j.mp\/AziJNF",
      "display_url" : "j.mp\/AziJNF"
    } ]
  },
  "geo" : { },
  "id_str" : "172292904340045824",
  "text" : "Nonparametric Evaluation of Quantitative Traits in Population-Based Association Studies when Genetic Model is Unknown http:\/\/t.co\/ZZckRiU6",
  "id" : 172292904340045824,
  "created_at" : "2012-02-22 12:13:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/igR3wpzY",
      "expanded_url" : "http:\/\/j.mp\/x0Hm8E",
      "display_url" : "j.mp\/x0Hm8E"
    } ]
  },
  "geo" : { },
  "id_str" : "172290967121035264",
  "text" : "Wow: Limbless amphibian family discovered in India http:\/\/t.co\/igR3wpzY",
  "id" : 172290967121035264,
  "created_at" : "2012-02-22 12:05:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tarzun",
      "screen_name" : "tarzun",
      "indices" : [ 0, 7 ],
      "id_str" : "1632280560",
      "id" : 1632280560
    }, {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 12, 21 ],
      "id_str" : "81582697",
      "id" : 81582697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172280087146795009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098120804, 8.2833582157 ]
  },
  "id_str" : "172280377732374528",
  "in_reply_to_user_id" : 45513907,
  "text" : "@tarzun der @viirus42 war nur 3 Sekunden zu sp\u00E4t ;)",
  "id" : 172280377732374528,
  "in_reply_to_status_id" : 172280087146795009,
  "created_at" : "2012-02-22 11:23:37 +0000",
  "in_reply_to_screen_name" : "klauspeukert",
  "in_reply_to_user_id_str" : "45513907",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tarzun",
      "screen_name" : "tarzun",
      "indices" : [ 0, 7 ],
      "id_str" : "1632280560",
      "id" : 1632280560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172279458491932672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0099278224, 8.2829659647 ]
  },
  "id_str" : "172279914140143617",
  "in_reply_to_user_id" : 45513907,
  "text" : "@tarzun sie k\u00F6nnten Fefe hochschie\u00DFen!",
  "id" : 172279914140143617,
  "in_reply_to_status_id" : 172279458491932672,
  "created_at" : "2012-02-22 11:21:46 +0000",
  "in_reply_to_screen_name" : "klauspeukert",
  "in_reply_to_user_id_str" : "45513907",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172266596679684096",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Are you still around and have time for a small jabber\/skype-conv.?",
  "id" : 172266596679684096,
  "created_at" : "2012-02-22 10:28:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC2ALa_Loupina \uD83D\uDC2A",
      "screen_name" : "La_Loupina",
      "indices" : [ 0, 11 ],
      "id_str" : "20928889",
      "id" : 20928889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172249365073756160",
  "geo" : { },
  "id_str" : "172254606091501568",
  "in_reply_to_user_id" : 20928889,
  "text" : "@La_Loupina unten links :D",
  "id" : 172254606091501568,
  "in_reply_to_status_id" : 172249365073756160,
  "created_at" : "2012-02-22 09:41:13 +0000",
  "in_reply_to_screen_name" : "La_Loupina",
  "in_reply_to_user_id_str" : "20928889",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guardian Science",
      "screen_name" : "guardianscience",
      "indices" : [ 3, 19 ],
      "id_str" : "21581503",
      "id" : 21581503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/uKvp9gfi",
      "expanded_url" : "http:\/\/gu.com\/p\/35jek\/tf",
      "display_url" : "gu.com\/p\/35jek\/tf"
    } ]
  },
  "geo" : { },
  "id_str" : "172242232932446208",
  "text" : "RT @guardianscience: Why we sued Simon Singh: the British Chiropractic Association speaks | Edzard Ernst http:\/\/t.co\/uKvp9gfi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/uKvp9gfi",
        "expanded_url" : "http:\/\/gu.com\/p\/35jek\/tf",
        "display_url" : "gu.com\/p\/35jek\/tf"
      } ]
    },
    "geo" : { },
    "id_str" : "172223013540995072",
    "text" : "Why we sued Simon Singh: the British Chiropractic Association speaks | Edzard Ernst http:\/\/t.co\/uKvp9gfi",
    "id" : 172223013540995072,
    "created_at" : "2012-02-22 07:35:40 +0000",
    "user" : {
      "name" : "Guardian Science",
      "screen_name" : "guardianscience",
      "protected" : false,
      "id_str" : "21581503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564801928849137664\/3P3eeDqB_normal.png",
      "id" : 21581503,
      "verified" : true
    }
  },
  "id" : 172242232932446208,
  "created_at" : "2012-02-22 08:52:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Zelnio",
      "screen_name" : "kzelnio",
      "indices" : [ 35, 43 ],
      "id_str" : "19202541",
      "id" : 19202541
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IAMSCIENCE",
      "indices" : [ 65, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/Wu8adxiP",
      "expanded_url" : "http:\/\/kck.st\/xkGfjF",
      "display_url" : "kck.st\/xkGfjF"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097124155, 8.28321617 ]
  },
  "id_str" : "172100693522518016",
  "text" : "First thing I'll do tomorrow: Give @kzelnio some funding for his #IAMSCIENCE project on Kickstarter http:\/\/t.co\/Wu8adxiP",
  "id" : 172100693522518016,
  "created_at" : "2012-02-21 23:29:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172087603208798208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097418335, 8.2833467244 ]
  },
  "id_str" : "172098015656554497",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn good luck!",
  "id" : 172098015656554497,
  "in_reply_to_status_id" : 172087603208798208,
  "created_at" : "2012-02-21 23:18:59 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Dennis",
      "screen_name" : "subcide",
      "indices" : [ 3, 11 ],
      "id_str" : "13502742",
      "id" : 13502742
    }, {
      "name" : "Matthew Inman",
      "screen_name" : "Oatmeal",
      "indices" : [ 23, 31 ],
      "id_str" : "4519121",
      "id" : 4519121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futurebb",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/fXwODtRY",
      "expanded_url" : "http:\/\/dl.dropbox.com\/u\/7491380\/nz-internet.png",
      "display_url" : "dl.dropbox.com\/u\/7491380\/nz-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "172069863647477760",
  "text" : "RT @subcide: I remixed @oatmeal's latest comic to better represent the NZ experience. Buy his merch. http:\/\/t.co\/fXwODtRY  #futurebb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthew Inman",
        "screen_name" : "Oatmeal",
        "indices" : [ 10, 18 ],
        "id_str" : "4519121",
        "id" : 4519121
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "futurebb",
        "indices" : [ 110, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/fXwODtRY",
        "expanded_url" : "http:\/\/dl.dropbox.com\/u\/7491380\/nz-internet.png",
        "display_url" : "dl.dropbox.com\/u\/7491380\/nz-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "172031473640161281",
    "text" : "I remixed @oatmeal's latest comic to better represent the NZ experience. Buy his merch. http:\/\/t.co\/fXwODtRY  #futurebb",
    "id" : 172031473640161281,
    "created_at" : "2012-02-21 18:54:34 +0000",
    "user" : {
      "name" : "Steve Dennis",
      "screen_name" : "subcide",
      "protected" : false,
      "id_str" : "13502742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640863092549652480\/QtdQfZ9-_normal.jpg",
      "id" : 13502742,
      "verified" : false
    }
  },
  "id" : 172069863647477760,
  "created_at" : "2012-02-21 21:27:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philaeus",
      "screen_name" : "Philaeus",
      "indices" : [ 0, 9 ],
      "id_str" : "226574221",
      "id" : 226574221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172034740759695361",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096946209, 8.2832660209 ]
  },
  "id_str" : "172035290192560128",
  "in_reply_to_user_id" : 226574221,
  "text" : "@Philaeus schauen wir mal, dank Homeoffice hab ich den Garten ja aus dem Augenwinkel im Blick ;)",
  "id" : 172035290192560128,
  "in_reply_to_status_id" : 172034740759695361,
  "created_at" : "2012-02-21 19:09:44 +0000",
  "in_reply_to_screen_name" : "Philaeus",
  "in_reply_to_user_id_str" : "226574221",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opendata",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/H5aNPm57",
      "expanded_url" : "http:\/\/j.mp\/zvYxCq",
      "display_url" : "j.mp\/zvYxCq"
    } ]
  },
  "geo" : { },
  "id_str" : "172034802193670144",
  "text" : "How to run a successful research lab without having a lab http:\/\/t.co\/H5aNPm57 #opendata",
  "id" : 172034802193670144,
  "created_at" : "2012-02-21 19:07:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/UAGIYhVh",
      "expanded_url" : "http:\/\/j.mp\/wPoHoW",
      "display_url" : "j.mp\/wPoHoW"
    } ]
  },
  "geo" : { },
  "id_str" : "172034113904189443",
  "text" : "Awesome: Seeds from 30,000-Year-Old Squirrel Cache Flower Again http:\/\/t.co\/UAGIYhVh",
  "id" : 172034113904189443,
  "created_at" : "2012-02-21 19:05:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philaeus",
      "screen_name" : "Philaeus",
      "indices" : [ 0, 9 ],
      "id_str" : "226574221",
      "id" : 226574221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172032063095046144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098548479, 8.2831647084 ]
  },
  "id_str" : "172033466765029376",
  "in_reply_to_user_id" : 226574221,
  "text" : "@Philaeus n\u00F6, meinetwegen h\u00E4tte er den Sack sogar haben k\u00F6nnen wenn er einfach geklingelt und gefragt h\u00E4tte.",
  "id" : 172033466765029376,
  "in_reply_to_status_id" : 172032063095046144,
  "created_at" : "2012-02-21 19:02:29 +0000",
  "in_reply_to_screen_name" : "Philaeus",
  "in_reply_to_user_id_str" : "226574221",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philaeus",
      "screen_name" : "Philaeus",
      "indices" : [ 0, 9 ],
      "id_str" : "226574221",
      "id" : 226574221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172030029105086465",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097616252, 8.2831378476 ]
  },
  "id_str" : "172031166340280322",
  "in_reply_to_user_id" : 226574221,
  "text" : "@Philaeus ne, Dreist war dann noch zu fragen ob er den Sack jetzt haben kann oder nicht. ;)",
  "id" : 172031166340280322,
  "in_reply_to_status_id" : 172030029105086465,
  "created_at" : "2012-02-21 18:53:20 +0000",
  "in_reply_to_screen_name" : "Philaeus",
  "in_reply_to_user_id_str" : "226574221",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philaeus",
      "screen_name" : "Philaeus",
      "indices" : [ 0, 9 ],
      "id_str" : "226574221",
      "id" : 226574221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172029154001297408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00800227, 8.282433951 ]
  },
  "id_str" : "172029755682598912",
  "in_reply_to_user_id" : 226574221,
  "text" : "@Philaeus ja. \u00ABEntschuldigung, was machen sie da?\u00BB \u2014 \u00ABIch wollte mir nur etwas Erde leihen\u00BB mit dem Sack im Arm o_O",
  "id" : 172029755682598912,
  "in_reply_to_status_id" : 172029154001297408,
  "created_at" : "2012-02-21 18:47:44 +0000",
  "in_reply_to_screen_name" : "Philaeus",
  "in_reply_to_user_id_str" : "226574221",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.008860572, 8.282956566 ]
  },
  "id_str" : "172028700899016705",
  "text" : "Da wollte doch ernsthaft jemand einen Sack Blumenerde aus unserem Garten mitgehen lassen...",
  "id" : 172028700899016705,
  "created_at" : "2012-02-21 18:43:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Things",
      "screen_name" : "culturedcode",
      "indices" : [ 3, 16 ],
      "id_str" : "12652542",
      "id" : 12652542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/3dbSwUOo",
      "expanded_url" : "http:\/\/culturedcode.com\/things\/blog\/2012\/02\/things-cloud-public-beta.html",
      "display_url" : "culturedcode.com\/things\/blog\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "171993249584648192",
  "text" : "RT @culturedcode: Things Cloud is now in public beta: http:\/\/t.co\/3dbSwUOo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/3dbSwUOo",
        "expanded_url" : "http:\/\/culturedcode.com\/things\/blog\/2012\/02\/things-cloud-public-beta.html",
        "display_url" : "culturedcode.com\/things\/blog\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "171983210404773888",
    "text" : "Things Cloud is now in public beta: http:\/\/t.co\/3dbSwUOo",
    "id" : 171983210404773888,
    "created_at" : "2012-02-21 15:42:47 +0000",
    "user" : {
      "name" : "Things",
      "screen_name" : "culturedcode",
      "protected" : false,
      "id_str" : "12652542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/864543964761735168\/286ToFn4_normal.jpg",
      "id" : 12652542,
      "verified" : false
    }
  },
  "id" : 171993249584648192,
  "created_at" : "2012-02-21 16:22:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098230809, 8.2831364693 ]
  },
  "id_str" : "171992750571520000",
  "text" : "Looks like we really should try to acquire more funding for this free genotyping project. But whom to bug about it?",
  "id" : 171992750571520000,
  "created_at" : "2012-02-21 16:20:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blaine T. Bettinger",
      "screen_name" : "blaine_5",
      "indices" : [ 3, 12 ],
      "id_str" : "1450531",
      "id" : 1450531
    }, {
      "name" : "MIT Tech Review",
      "screen_name" : "techreview",
      "indices" : [ 42, 53 ],
      "id_str" : "15808647",
      "id" : 15808647
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 111, 119 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PGP",
      "indices" : [ 121, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/vcdWUw5c",
      "expanded_url" : "http:\/\/ow.ly\/9c1i0",
      "display_url" : "ow.ly\/9c1i0"
    } ]
  },
  "geo" : { },
  "id_str" : "171941963589881857",
  "text" : "RT @blaine_5: \"The Patient of the Future\" @techreview - http:\/\/t.co\/vcdWUw5c - improving health yourself using @23andMe, #PGP, @quantifi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MIT Tech Review",
        "screen_name" : "techreview",
        "indices" : [ 28, 39 ],
        "id_str" : "15808647",
        "id" : 15808647
      }, {
        "name" : "23andMe",
        "screen_name" : "23andMe",
        "indices" : [ 97, 105 ],
        "id_str" : "14738561",
        "id" : 14738561
      }, {
        "name" : "quantifiedself",
        "screen_name" : "quantifiedself",
        "indices" : [ 113, 128 ],
        "id_str" : "35056570",
        "id" : 35056570
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PGP",
        "indices" : [ 107, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 62 ],
        "url" : "http:\/\/t.co\/vcdWUw5c",
        "expanded_url" : "http:\/\/ow.ly\/9c1i0",
        "display_url" : "ow.ly\/9c1i0"
      } ]
    },
    "geo" : { },
    "id_str" : "171941501218193408",
    "text" : "\"The Patient of the Future\" @techreview - http:\/\/t.co\/vcdWUw5c - improving health yourself using @23andMe, #PGP, @quantifiedself,...",
    "id" : 171941501218193408,
    "created_at" : "2012-02-21 12:57:03 +0000",
    "user" : {
      "name" : "Blaine T. Bettinger",
      "screen_name" : "blaine_5",
      "protected" : false,
      "id_str" : "1450531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000858573644\/Hbfs8Zur_normal.jpeg",
      "id" : 1450531,
      "verified" : false
    }
  },
  "id" : 171941963589881857,
  "created_at" : "2012-02-21 12:58:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171935060990242816",
  "geo" : { },
  "id_str" : "171935200413102080",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai Naja, so kann man zumindest das illegale Jagen eind\u00E4mmen, finde ich nicht ganz dumm.",
  "id" : 171935200413102080,
  "in_reply_to_status_id" : 171935060990242816,
  "created_at" : "2012-02-21 12:32:00 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171912158844694528",
  "geo" : { },
  "id_str" : "171929331608715264",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai Naja, die Leute w\u00FCrden abergl\u00E4ubischen Mist doch so oder so kaufen, oder meinste nicht?",
  "id" : 171929331608715264,
  "in_reply_to_status_id" : 171912158844694528,
  "created_at" : "2012-02-21 12:08:41 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171901362597134336",
  "geo" : { },
  "id_str" : "171902784101294081",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Passiert mir t\u00E4glich :D",
  "id" : 171902784101294081,
  "in_reply_to_status_id" : 171901362597134336,
  "created_at" : "2012-02-21 10:23:12 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/BEnb3uVB",
      "expanded_url" : "http:\/\/j.mp\/zAnE46",
      "display_url" : "j.mp\/zAnE46"
    } ]
  },
  "geo" : { },
  "id_str" : "171885283636281345",
  "text" : "A Genome-Wide Study in Colorectal Cancer Using SNP Microarrays: Opportunities for Future Personalized Treatment http:\/\/t.co\/BEnb3uVB",
  "id" : 171885283636281345,
  "created_at" : "2012-02-21 09:13:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Ewing",
      "screen_name" : "raewing",
      "indices" : [ 3, 11 ],
      "id_str" : "18837385",
      "id" : 18837385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171745820444602368",
  "text" : "RT @raewing: Technology in paleontology is \"shovels and pickaxes and burlap and plaster. It hasn't changed - until right now.\" http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/OWVmGgOO",
        "expanded_url" : "http:\/\/bit.ly\/zpZLdE",
        "display_url" : "bit.ly\/zpZLdE"
      } ]
    },
    "geo" : { },
    "id_str" : "171640248051310592",
    "text" : "Technology in paleontology is \"shovels and pickaxes and burlap and plaster. It hasn't changed - until right now.\" http:\/\/t.co\/OWVmGgOO",
    "id" : 171640248051310592,
    "created_at" : "2012-02-20 16:59:58 +0000",
    "user" : {
      "name" : "Rachel Ewing",
      "screen_name" : "raewing",
      "protected" : false,
      "id_str" : "18837385",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708075271509970945\/Lycl_gfo_normal.jpg",
      "id" : 18837385,
      "verified" : false
    }
  },
  "id" : 171745820444602368,
  "created_at" : "2012-02-20 23:59:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/ZA0Coso1",
      "expanded_url" : "http:\/\/j.mp\/yd2JmM",
      "display_url" : "j.mp\/yd2JmM"
    } ]
  },
  "geo" : { },
  "id_str" : "171744325171019776",
  "text" : "The Forgetting Pill Erases Painful Memories Forever http:\/\/t.co\/ZA0Coso1",
  "id" : 171744325171019776,
  "created_at" : "2012-02-20 23:53:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 127, 136 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/2WLx8BmQ",
      "expanded_url" : "http:\/\/j.mp\/yztmJv",
      "display_url" : "j.mp\/yztmJv"
    } ]
  },
  "geo" : { },
  "id_str" : "171741664887586816",
  "text" : "\u00ABThere is a never ending supply of rhino horn if we're smart enough to keep the bloody animals alive\u00BB http:\/\/t.co\/2WLx8BmQ \/cc @RoterHai",
  "id" : 171741664887586816,
  "created_at" : "2012-02-20 23:42:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/3XAiXmD9",
      "expanded_url" : "http:\/\/j.mp\/zsA73I",
      "display_url" : "j.mp\/zsA73I"
    } ]
  },
  "geo" : { },
  "id_str" : "171734927786774529",
  "text" : "Just like our cats http:\/\/t.co\/3XAiXmD9",
  "id" : 171734927786774529,
  "created_at" : "2012-02-20 23:16:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Bobe",
      "screen_name" : "jasonbobe",
      "indices" : [ 0, 10 ],
      "id_str" : "820582",
      "id" : 820582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0119887592, 8.2835311585 ]
  },
  "id_str" : "171727954055921666",
  "in_reply_to_user_id" : 820582,
  "text" : "@jasonbobe thanks for retweeting :)",
  "id" : 171727954055921666,
  "created_at" : "2012-02-20 22:48:29 +0000",
  "in_reply_to_screen_name" : "jasonbobe",
  "in_reply_to_user_id_str" : "820582",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171722904092938240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097371021, 8.2831185711 ]
  },
  "id_str" : "171723807541825536",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn great, send me the link if you have done it. :)",
  "id" : 171723807541825536,
  "in_reply_to_status_id" : 171722904092938240,
  "created_at" : "2012-02-20 22:32:00 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171721888056360961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0122139015, 8.2837771986 ]
  },
  "id_str" : "171722670029811713",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn Thanks :)",
  "id" : 171722670029811713,
  "in_reply_to_status_id" : 171721888056360961,
  "created_at" : "2012-02-20 22:27:29 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "indices" : [ 0, 6 ],
      "id_str" : "5751892",
      "id" : 5751892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171714432576135169",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097759374, 8.2830883245 ]
  },
  "id_str" : "171715729396219904",
  "in_reply_to_user_id" : 5751892,
  "text" : "@mspro ja, bin gespannt auf den ersten Output von den Ger\u00E4ten. :)",
  "id" : 171715729396219904,
  "in_reply_to_status_id" : 171714432576135169,
  "created_at" : "2012-02-20 21:59:54 +0000",
  "in_reply_to_screen_name" : "mspro",
  "in_reply_to_user_id_str" : "5751892",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 0, 11 ],
      "id_str" : "191004758",
      "id" : 191004758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171689045699735552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097339274, 8.2831977992 ]
  },
  "id_str" : "171689324021166081",
  "in_reply_to_user_id" : 191004758,
  "text" : "@PygmyLoris yeah, I missed it. Looks great! :)",
  "id" : 171689324021166081,
  "in_reply_to_status_id" : 171689045699735552,
  "created_at" : "2012-02-20 20:14:59 +0000",
  "in_reply_to_screen_name" : "PygmyLoris",
  "in_reply_to_user_id_str" : "191004758",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 0, 11 ],
      "id_str" : "191004758",
      "id" : 191004758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171685096783495169",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.01151722, 8.28247034 ]
  },
  "id_str" : "171688806112706560",
  "in_reply_to_user_id" : 191004758,
  "text" : "@PygmyLoris btw. any news on your tattoo? :)",
  "id" : 171688806112706560,
  "in_reply_to_status_id" : 171685096783495169,
  "created_at" : "2012-02-20 20:12:55 +0000",
  "in_reply_to_screen_name" : "PygmyLoris",
  "in_reply_to_user_id_str" : "191004758",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 0, 11 ],
      "id_str" : "191004758",
      "id" : 191004758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171682650535366656",
  "geo" : { },
  "id_str" : "171683599039475712",
  "in_reply_to_user_id" : 191004758,
  "text" : "@PygmyLoris absolutely necessary! I've never seen this before :)",
  "id" : 171683599039475712,
  "in_reply_to_status_id" : 171682650535366656,
  "created_at" : "2012-02-20 19:52:14 +0000",
  "in_reply_to_screen_name" : "PygmyLoris",
  "in_reply_to_user_id_str" : "191004758",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 12, 23 ],
      "id_str" : "191004758",
      "id" : 191004758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/lWS0J8UV",
      "expanded_url" : "http:\/\/pygmylorisreid.wordpress.com\/2012\/02\/20\/how-do-birds-have-sex\/",
      "display_url" : "pygmylorisreid.wordpress.com\/2012\/02\/20\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "171681943933562882",
  "text" : "The awesome @PygmyLoris covers how birds have sex. Includes graphic video evidence! http:\/\/t.co\/lWS0J8UV",
  "id" : 171681943933562882,
  "created_at" : "2012-02-20 19:45:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 0, 15 ],
      "id_str" : "73134122",
      "id" : 73134122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171680505157271553",
  "geo" : { },
  "id_str" : "171681352561852416",
  "in_reply_to_user_id" : 73134122,
  "text" : "@astefanowitsch Du hast dir also schon ausgesucht \u00FCber was du dieses Jahr als Referent reden willst? :)",
  "id" : 171681352561852416,
  "in_reply_to_status_id" : 171680505157271553,
  "created_at" : "2012-02-20 19:43:18 +0000",
  "in_reply_to_screen_name" : "astefanowitsch",
  "in_reply_to_user_id_str" : "73134122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171677646512590848",
  "geo" : { },
  "id_str" : "171677737545764864",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus Bei Piraten wohl mehr um Liquid Feedback ;)",
  "id" : 171677737545764864,
  "in_reply_to_status_id" : 171677646512590848,
  "created_at" : "2012-02-20 19:28:56 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johannes Rieder",
      "screen_name" : "Punky260",
      "indices" : [ 0, 9 ],
      "id_str" : "29306871",
      "id" : 29306871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171677504803848192",
  "geo" : { },
  "id_str" : "171677604385005571",
  "in_reply_to_user_id" : 29306871,
  "text" : "@Punky260 Wir \u00FCben ja noch. Alle guten Dinge sind drei. ;)",
  "id" : 171677604385005571,
  "in_reply_to_status_id" : 171677504803848192,
  "created_at" : "2012-02-20 19:28:25 +0000",
  "in_reply_to_screen_name" : "Punky260",
  "in_reply_to_user_id_str" : "29306871",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om12",
      "indices" : [ 35, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171675209621966848",
  "text" : "\u00ABDie Liebe in Zeiten der Tool-\u00C4ra\u00BB #om12",
  "id" : 171675209621966848,
  "created_at" : "2012-02-20 19:18:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 66, 75 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "om12",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171673237778993152",
  "text" : "Mein Vorschlag \u00ABWieso K\u00E4tzchen niedlich sind\u00BB wurde abgelehnt! RT @Senficon: Twitter, wir brauchen ein Motto f\u00FCr die #om12 - helft uns!",
  "id" : 171673237778993152,
  "created_at" : "2012-02-20 19:11:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u043Enasterium",
      "screen_name" : "monasterium",
      "indices" : [ 0, 12 ],
      "id_str" : "15126396",
      "id" : 15126396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171638107286929408",
  "geo" : { },
  "id_str" : "171638148567281665",
  "in_reply_to_user_id" : 15126396,
  "text" : "@monasterium danke :)",
  "id" : 171638148567281665,
  "in_reply_to_status_id" : 171638107286929408,
  "created_at" : "2012-02-20 16:51:38 +0000",
  "in_reply_to_screen_name" : "monasterium",
  "in_reply_to_user_id_str" : "15126396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torben Friedrich\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Fritten",
      "indices" : [ 0, 8 ],
      "id_str" : "11299302",
      "id" : 11299302
    }, {
      "name" : "fasel",
      "screen_name" : "fasel",
      "indices" : [ 9, 15 ],
      "id_str" : "21739255",
      "id" : 21739255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171635552603471874",
  "geo" : { },
  "id_str" : "171635618777010178",
  "in_reply_to_user_id" : 11299302,
  "text" : "@Fritten @fasel Manche Dinge sind einfach zu vorhersehbar ;)",
  "id" : 171635618777010178,
  "in_reply_to_status_id" : 171635552603471874,
  "created_at" : "2012-02-20 16:41:35 +0000",
  "in_reply_to_screen_name" : "Fritten",
  "in_reply_to_user_id_str" : "11299302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 3, 14 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/XMmJIXDA",
      "expanded_url" : "http:\/\/opensnp.wordpress.com\/2012\/02\/20\/apply-now-for-a-free-genotyping\/",
      "display_url" : "opensnp.wordpress.com\/2012\/02\/20\/app\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "171634307746639872",
  "text" : "RT @openSNPorg: You can now apply for a free genotyping. Find more details and the planned schedule here: http:\/\/t.co\/XMmJIXDA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/XMmJIXDA",
        "expanded_url" : "http:\/\/opensnp.wordpress.com\/2012\/02\/20\/apply-now-for-a-free-genotyping\/",
        "display_url" : "opensnp.wordpress.com\/2012\/02\/20\/app\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "171634269867884546",
    "text" : "You can now apply for a free genotyping. Find more details and the planned schedule here: http:\/\/t.co\/XMmJIXDA",
    "id" : 171634269867884546,
    "created_at" : "2012-02-20 16:36:13 +0000",
    "user" : {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "protected" : false,
      "id_str" : "380205172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735374825187909632\/wJEJW1zW_normal.jpg",
      "id" : 380205172,
      "verified" : false
    }
  },
  "id" : 171634307746639872,
  "created_at" : "2012-02-20 16:36:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "indices" : [ 3, 10 ],
      "id_str" : "47876842",
      "id" : 47876842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/8wr7Gm7k",
      "expanded_url" : "http:\/\/wp.me\/P2dxRj-4",
      "display_url" : "wp.me\/P2dxRj-4"
    } ]
  },
  "geo" : { },
  "id_str" : "171632211777437696",
  "text" : "RT @brembs: Stories on how Open Access saves lives and Toll Access risks lives http:\/\/t.co\/8wr7Gm7k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/8wr7Gm7k",
        "expanded_url" : "http:\/\/wp.me\/P2dxRj-4",
        "display_url" : "wp.me\/P2dxRj-4"
      } ]
    },
    "geo" : { },
    "id_str" : "171503148828073985",
    "text" : "Stories on how Open Access saves lives and Toll Access risks lives http:\/\/t.co\/8wr7Gm7k",
    "id" : 171503148828073985,
    "created_at" : "2012-02-20 07:55:11 +0000",
    "user" : {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "protected" : false,
      "id_str" : "47876842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524937570984013824\/uPSUsTcU_normal.png",
      "id" : 47876842,
      "verified" : false
    }
  },
  "id" : 171632211777437696,
  "created_at" : "2012-02-20 16:28:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerrit",
      "screen_name" : "GerritEicker",
      "indices" : [ 0, 13 ],
      "id_str" : "45082501",
      "id" : 45082501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171597699601272833",
  "geo" : { },
  "id_str" : "171597874386305024",
  "in_reply_to_user_id" : 45082501,
  "text" : "@GerritEicker Ist ja auch nicht mehr zeitgem\u00E4\u00DF dank Google und Wikipedia ;)",
  "id" : 171597874386305024,
  "in_reply_to_status_id" : 171597699601272833,
  "created_at" : "2012-02-20 14:11:36 +0000",
  "in_reply_to_screen_name" : "GerritEicker",
  "in_reply_to_user_id_str" : "45082501",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerrit",
      "screen_name" : "GerritEicker",
      "indices" : [ 0, 13 ],
      "id_str" : "45082501",
      "id" : 45082501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171597094807810048",
  "geo" : { },
  "id_str" : "171597232267739137",
  "in_reply_to_user_id" : 45082501,
  "text" : "@GerritEicker Bei Klausuren die auswendig lernen von Fakten statt verstehen von Zusammenh\u00E4ngen fordern versage ich :D",
  "id" : 171597232267739137,
  "in_reply_to_status_id" : 171597094807810048,
  "created_at" : "2012-02-20 14:09:02 +0000",
  "in_reply_to_screen_name" : "GerritEicker",
  "in_reply_to_user_id_str" : "45082501",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Una Mullally",
      "screen_name" : "UnaMullally",
      "indices" : [ 3, 15 ],
      "id_str" : "20980592",
      "id" : 20980592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/2rcuPl2C",
      "expanded_url" : "http:\/\/bit.ly\/zh1teQ",
      "display_url" : "bit.ly\/zh1teQ"
    } ]
  },
  "geo" : { },
  "id_str" : "171595845081366528",
  "text" : "RT @UnaMullally: Interesting blog post on Dublin nightclubs advertising sex, in particular Alchemy: http:\/\/t.co\/2rcuPl2C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/2rcuPl2C",
        "expanded_url" : "http:\/\/bit.ly\/zh1teQ",
        "display_url" : "bit.ly\/zh1teQ"
      } ]
    },
    "geo" : { },
    "id_str" : "171567104129105920",
    "text" : "Interesting blog post on Dublin nightclubs advertising sex, in particular Alchemy: http:\/\/t.co\/2rcuPl2C",
    "id" : 171567104129105920,
    "created_at" : "2012-02-20 12:09:19 +0000",
    "user" : {
      "name" : "Una Mullally",
      "screen_name" : "UnaMullally",
      "protected" : false,
      "id_str" : "20980592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/862980687154094080\/C1wDAI9w_normal.jpg",
      "id" : 20980592,
      "verified" : true
    }
  },
  "id" : 171595845081366528,
  "created_at" : "2012-02-20 14:03:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171594586890838016",
  "geo" : { },
  "id_str" : "171595434370928641",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a Thanks! :)",
  "id" : 171595434370928641,
  "in_reply_to_status_id" : 171594586890838016,
  "created_at" : "2012-02-20 14:01:54 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerrit",
      "screen_name" : "GerritEicker",
      "indices" : [ 0, 13 ],
      "id_str" : "45082501",
      "id" : 45082501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171585474744422400",
  "geo" : { },
  "id_str" : "171595361461346304",
  "in_reply_to_user_id" : 45082501,
  "text" : "@GerritEicker Auf jeden Fall leichter als Klausuren. ;)",
  "id" : 171595361461346304,
  "in_reply_to_status_id" : 171585474744422400,
  "created_at" : "2012-02-20 14:01:36 +0000",
  "in_reply_to_screen_name" : "GerritEicker",
  "in_reply_to_user_id_str" : "45082501",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "viola vo\u00DF",
      "screen_name" : "v_i_o_l_a",
      "indices" : [ 0, 10 ],
      "id_str" : "14937469",
      "id" : 14937469
    }, {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 11, 17 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171582009586626560",
  "geo" : { },
  "id_str" : "171583317043458049",
  "in_reply_to_user_id" : 14937469,
  "text" : "@v_i_o_l_a @_Rya_ Danke :)",
  "id" : 171583317043458049,
  "in_reply_to_status_id" : 171582009586626560,
  "created_at" : "2012-02-20 13:13:45 +0000",
  "in_reply_to_screen_name" : "v_i_o_l_a",
  "in_reply_to_user_id_str" : "14937469",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 3, 17 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    }, {
      "name" : "Ion Torrent",
      "screen_name" : "iontorrent",
      "indices" : [ 49, 60 ],
      "id_str" : "117064656",
      "id" : 117064656
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/genetics_blog\/status\/171579247780036608\/photo\/1",
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/gyyeTgsN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AmGSarMCAAAI0Qb.jpg",
      "id_str" : "171579247784230912",
      "id" : 171579247784230912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AmGSarMCAAAI0Qb.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/gyyeTgsN"
    } ],
    "hashtags" : [ {
      "text" : "notAGBT",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171579329820635137",
  "text" : "RT @genetics_blog: Leaked at #notAGBT !  3rd gen @iontorrent ion proton successor http:\/\/t.co\/gyyeTgsN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ion Torrent",
        "screen_name" : "iontorrent",
        "indices" : [ 30, 41 ],
        "id_str" : "117064656",
        "id" : 117064656
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/genetics_blog\/status\/171579247780036608\/photo\/1",
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/gyyeTgsN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AmGSarMCAAAI0Qb.jpg",
        "id_str" : "171579247784230912",
        "id" : 171579247784230912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AmGSarMCAAAI0Qb.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/gyyeTgsN"
      } ],
      "hashtags" : [ {
        "text" : "notAGBT",
        "indices" : [ 10, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171579247780036608",
    "text" : "Leaked at #notAGBT !  3rd gen @iontorrent ion proton successor http:\/\/t.co\/gyyeTgsN",
    "id" : 171579247780036608,
    "created_at" : "2012-02-20 12:57:35 +0000",
    "user" : {
      "name" : "Stephen Turner",
      "screen_name" : "strnr",
      "protected" : false,
      "id_str" : "20444825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660439762856230913\/ARYE5YB6_normal.jpg",
      "id" : 20444825,
      "verified" : false
    }
  },
  "id" : 171579329820635137,
  "created_at" : "2012-02-20 12:57:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerrit",
      "screen_name" : "GerritEicker",
      "indices" : [ 0, 13 ],
      "id_str" : "45082501",
      "id" : 45082501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171578704307298306",
  "geo" : { },
  "id_str" : "171578836247515137",
  "in_reply_to_user_id" : 45082501,
  "text" : "@GerritEicker Zumindest mit Vorlesungen und Klausuren. Jetzt geht\u2019s noch in 6 Wochen Betriebspraktikum und danach in die Masterarbeit",
  "id" : 171578836247515137,
  "in_reply_to_status_id" : 171578704307298306,
  "created_at" : "2012-02-20 12:55:57 +0000",
  "in_reply_to_screen_name" : "GerritEicker",
  "in_reply_to_user_id_str" : "45082501",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerrit",
      "screen_name" : "GerritEicker",
      "indices" : [ 0, 13 ],
      "id_str" : "45082501",
      "id" : 45082501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171577876817256448",
  "geo" : { },
  "id_str" : "171578082296209409",
  "in_reply_to_user_id" : 45082501,
  "text" : "@GerritEicker Ja, mit dem Klausurergebnis ist jetzt schon mal egal wie mies mein Protokoll geworden ist. Das Modul ist bestanden ;)",
  "id" : 171578082296209409,
  "in_reply_to_status_id" : 171577876817256448,
  "created_at" : "2012-02-20 12:52:57 +0000",
  "in_reply_to_screen_name" : "GerritEicker",
  "in_reply_to_user_id_str" : "45082501",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097296192, 8.2832438038 ]
  },
  "id_str" : "171575052414894082",
  "text" : "Yeah, 1.0 in Evolutionary Genomics!",
  "id" : 171575052414894082,
  "created_at" : "2012-02-20 12:40:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171572333318901761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0092802569, 8.2823828775 ]
  },
  "id_str" : "171572822538321920",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen deine Leihen sollen glaube ich Laien sein. ;)",
  "id" : 171572822538321920,
  "in_reply_to_status_id" : 171572333318901761,
  "created_at" : "2012-02-20 12:32:03 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fasel",
      "screen_name" : "fasel",
      "indices" : [ 0, 6 ],
      "id_str" : "21739255",
      "id" : 21739255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171563333781176320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097753775, 8.2833311626 ]
  },
  "id_str" : "171570170668650496",
  "in_reply_to_user_id" : 21739255,
  "text" : "@fasel da hat die Presse mich falsch zitiert.",
  "id" : 171570170668650496,
  "in_reply_to_status_id" : 171563333781176320,
  "created_at" : "2012-02-20 12:21:30 +0000",
  "in_reply_to_screen_name" : "fasel",
  "in_reply_to_user_id_str" : "21739255",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Knowledge Intl",
      "screen_name" : "OKFN",
      "indices" : [ 3, 8 ],
      "id_str" : "16143105",
      "id" : 16143105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opendata",
      "indices" : [ 86, 95 ]
    }, {
      "text" : "openscience",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/wCOFIuH8",
      "expanded_url" : "http:\/\/pantonprinciples.org\/panton-fellowships\/",
      "display_url" : "pantonprinciples.org\/panton-fellows\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "171565019694243840",
  "text" : "RT @OKFN: **Panton Fellowships: Apply by Friday!** \u00A38,000 for UK scientists promoting #opendata and #openscience. http:\/\/t.co\/wCOFIuH8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opendata",
        "indices" : [ 76, 85 ]
      }, {
        "text" : "openscience",
        "indices" : [ 90, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/wCOFIuH8",
        "expanded_url" : "http:\/\/pantonprinciples.org\/panton-fellowships\/",
        "display_url" : "pantonprinciples.org\/panton-fellows\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "171564014835474432",
    "text" : "**Panton Fellowships: Apply by Friday!** \u00A38,000 for UK scientists promoting #opendata and #openscience. http:\/\/t.co\/wCOFIuH8",
    "id" : 171564014835474432,
    "created_at" : "2012-02-20 11:57:03 +0000",
    "user" : {
      "name" : "Open Knowledge Intl",
      "screen_name" : "OKFN",
      "protected" : false,
      "id_str" : "16143105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880395925562298369\/0PJz69Ov_normal.jpg",
      "id" : 16143105,
      "verified" : true
    }
  },
  "id" : 171565019694243840,
  "created_at" : "2012-02-20 12:01:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenan Malik",
      "screen_name" : "kenanmalik",
      "indices" : [ 3, 14 ],
      "id_str" : "18696855",
      "id" : 18696855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171563275916541952",
  "text" : "RT @kenanmalik: 'Dawkins hit by fresh scandal after it emerged his ancestors were single-celled organisms who metabolised sulphur': http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/rvbcQhDW",
        "expanded_url" : "http:\/\/bit.ly\/yHTmFo",
        "display_url" : "bit.ly\/yHTmFo"
      } ]
    },
    "geo" : { },
    "id_str" : "171559747990978560",
    "text" : "'Dawkins hit by fresh scandal after it emerged his ancestors were single-celled organisms who metabolised sulphur': http:\/\/t.co\/rvbcQhDW",
    "id" : 171559747990978560,
    "created_at" : "2012-02-20 11:40:06 +0000",
    "user" : {
      "name" : "Kenan Malik",
      "screen_name" : "kenanmalik",
      "protected" : false,
      "id_str" : "18696855",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1132274399\/km11_normal.jpg",
      "id" : 18696855,
      "verified" : false
    }
  },
  "id" : 171563275916541952,
  "created_at" : "2012-02-20 11:54:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 3, 11 ],
      "id_str" : "621716753",
      "id" : 621716753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/QzvLTOyX",
      "expanded_url" : "http:\/\/www.lvl1.org\/2012\/02\/15\/mother\/",
      "display_url" : "lvl1.org\/2012\/02\/15\/mot\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "171560688664322048",
  "text" : "RT @Scytale: Ein Hackerspace, dessen Zentralcomputer MOTHER hei\u00DFt. Der Alien-Fan in mir ejakuliert. http:\/\/t.co\/QzvLTOyX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/QzvLTOyX",
        "expanded_url" : "http:\/\/www.lvl1.org\/2012\/02\/15\/mother\/",
        "display_url" : "lvl1.org\/2012\/02\/15\/mot\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "171559320784351233",
    "text" : "Ein Hackerspace, dessen Zentralcomputer MOTHER hei\u00DFt. Der Alien-Fan in mir ejakuliert. http:\/\/t.co\/QzvLTOyX",
    "id" : 171559320784351233,
    "created_at" : "2012-02-20 11:38:24 +0000",
    "user" : {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "protected" : false,
      "id_str" : "8308632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640094846196150272\/6X7gF8lF_normal.png",
      "id" : 8308632,
      "verified" : false
    }
  },
  "id" : 171560688664322048,
  "created_at" : "2012-02-20 11:43:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/BxdAqCTq",
      "expanded_url" : "http:\/\/j.mp\/zZ5zdS",
      "display_url" : "j.mp\/zZ5zdS"
    } ]
  },
  "geo" : { },
  "id_str" : "171555266100334592",
  "text" : "Kilogram conundrum on the road to resolution http:\/\/t.co\/BxdAqCTq",
  "id" : 171555266100334592,
  "created_at" : "2012-02-20 11:22:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171394156248305664",
  "text" : "Jetzt aber wirklich gute Nacht.",
  "id" : 171394156248305664,
  "created_at" : "2012-02-20 00:42:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/yJ3s42C5",
      "expanded_url" : "http:\/\/opensnp.wordpress.com\/2012\/02\/20\/videos-on-opensnp-das-support\/",
      "display_url" : "opensnp.wordpress.com\/2012\/02\/20\/vid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "171392058483941376",
  "text" : "openSNP now with basic DAS-support, RSS on latest publications and \"How-To screencasts\" http:\/\/t.co\/yJ3s42C5",
  "id" : 171392058483941376,
  "created_at" : "2012-02-20 00:33:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171376949195841536",
  "geo" : { },
  "id_str" : "171379604651646976",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer see jabber, seems weird :D",
  "id" : 171379604651646976,
  "in_reply_to_status_id" : 171376949195841536,
  "created_at" : "2012-02-19 23:44:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alvar Freude",
      "screen_name" : "alvar_f",
      "indices" : [ 0, 8 ],
      "id_str" : "17290634",
      "id" : 17290634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171370162593873920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.01151722, 8.28247034 ]
  },
  "id_str" : "171371750024683520",
  "in_reply_to_user_id" : 17290634,
  "text" : "@alvar_f Quicktime kann direkt den Screen grabben.",
  "id" : 171371750024683520,
  "in_reply_to_status_id" : 171370162593873920,
  "created_at" : "2012-02-19 23:13:03 +0000",
  "in_reply_to_screen_name" : "alvar_f",
  "in_reply_to_user_id_str" : "17290634",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mish",
      "screen_name" : "mish",
      "indices" : [ 3, 8 ],
      "id_str" : "30983",
      "id" : 30983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171340997744275456",
  "text" : "RT @mish: 14 yr old stepson just slammed his bedroom door in my face. So I redirected all http:\/\/ requests from his computer to pampers. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EvilStep",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171294504366780416",
    "text" : "14 yr old stepson just slammed his bedroom door in my face. So I redirected all http:\/\/ requests from his computer to pampers.com #EvilStep",
    "id" : 171294504366780416,
    "created_at" : "2012-02-19 18:06:06 +0000",
    "user" : {
      "name" : "mish",
      "screen_name" : "mish",
      "protected" : false,
      "id_str" : "30983",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/913126632944259072\/HGpo3W9o_normal.jpg",
      "id" : 30983,
      "verified" : false
    }
  },
  "id" : 171340997744275456,
  "created_at" : "2012-02-19 21:10:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "anthchirp",
      "screen_name" : "anthchirp",
      "indices" : [ 0, 10 ],
      "id_str" : "3432790726",
      "id" : 3432790726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171327692703137792",
  "text" : "@AnthChirp neu gez\u00E4hlt, you have my chelae.",
  "id" : 171327692703137792,
  "created_at" : "2012-02-19 20:17:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "anthchirp",
      "screen_name" : "anthchirp",
      "indices" : [ 0, 10 ],
      "id_str" : "3432790726",
      "id" : 3432790726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171325961965543424",
  "text" : "@AnthChirp All Glory To The Hypnotoad! (V)(\u00B0,,\u00B0)(V)",
  "id" : 171325961965543424,
  "created_at" : "2012-02-19 20:11:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171287803689320448",
  "geo" : { },
  "id_str" : "171288623306641408",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus fr\u00FCher war alles besser, sogar das SimSinn ;)",
  "id" : 171288623306641408,
  "in_reply_to_status_id" : 171287803689320448,
  "created_at" : "2012-02-19 17:42:44 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171287260677935105",
  "geo" : { },
  "id_str" : "171287328118161408",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus Immer dieser neumodische Quatsch ;)",
  "id" : 171287328118161408,
  "in_reply_to_status_id" : 171287260677935105,
  "created_at" : "2012-02-19 17:37:36 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171284973024837632",
  "geo" : { },
  "id_str" : "171286149703286785",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus Shadowrun, aber nur wenn es 2.01D ist :P",
  "id" : 171286149703286785,
  "in_reply_to_status_id" : 171284973024837632,
  "created_at" : "2012-02-19 17:32:55 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171277879718580224",
  "geo" : { },
  "id_str" : "171283134950813696",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ So cool finde ich es bislang gar nicht. ;)",
  "id" : 171283134950813696,
  "in_reply_to_status_id" : 171277879718580224,
  "created_at" : "2012-02-19 17:20:56 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/p2f8SZVI",
      "expanded_url" : "http:\/\/www.engage-project.eu\/engage\/wp\/?page_id=193",
      "display_url" : "engage-project.eu\/engage\/wp\/?pag\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "171277410967367681",
  "geo" : { },
  "id_str" : "171277534284087297",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ http:\/\/t.co\/p2f8SZVI",
  "id" : 171277534284087297,
  "in_reply_to_status_id" : 171277410967367681,
  "created_at" : "2012-02-19 16:58:41 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u043Enasterium",
      "screen_name" : "monasterium",
      "indices" : [ 0, 12 ],
      "id_str" : "15126396",
      "id" : 15126396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171277312929697792",
  "geo" : { },
  "id_str" : "171277493528047617",
  "in_reply_to_user_id" : 15126396,
  "text" : "@monasterium \"Flanders muss sterben\"",
  "id" : 171277493528047617,
  "in_reply_to_status_id" : 171277312929697792,
  "created_at" : "2012-02-19 16:58:31 +0000",
  "in_reply_to_screen_name" : "monasterium",
  "in_reply_to_user_id_str" : "15126396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171277080275845121",
  "text" : "Meh, das waren erst 1200 W\u00F6rter? Damn!",
  "id" : 171277080275845121,
  "created_at" : "2012-02-19 16:56:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097388446, 8.2831391276 ]
  },
  "id_str" : "171267500229656576",
  "text" : "Schreibt sich dieser Artikel z\u00E4h...",
  "id" : 171267500229656576,
  "created_at" : "2012-02-19 16:18:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171248005180178432",
  "geo" : { },
  "id_str" : "171248063069945856",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Meinst der \"Sport\" ist denen zu schnell? ;)",
  "id" : 171248063069945856,
  "in_reply_to_status_id" : 171248005180178432,
  "created_at" : "2012-02-19 15:01:34 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171246084587405312",
  "geo" : { },
  "id_str" : "171246787842146304",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Foxy Boxing, Homer Simpson approves!",
  "id" : 171246787842146304,
  "in_reply_to_status_id" : 171246084587405312,
  "created_at" : "2012-02-19 14:56:30 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inhale exhale repeat",
      "screen_name" : "C_Holler",
      "indices" : [ 0, 9 ],
      "id_str" : "65671142",
      "id" : 65671142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171244387911737345",
  "geo" : { },
  "id_str" : "171245505869910016",
  "in_reply_to_user_id" : 65671142,
  "text" : "@C_Holler Watson, der kann auch die richtigen Fragen stellen ;)",
  "id" : 171245505869910016,
  "in_reply_to_status_id" : 171244387911737345,
  "created_at" : "2012-02-19 14:51:24 +0000",
  "in_reply_to_screen_name" : "C_Holler",
  "in_reply_to_user_id_str" : "65671142",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171216080746987520",
  "geo" : { },
  "id_str" : "171219022271098880",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw. got a sec for jabber\/skype?",
  "id" : 171219022271098880,
  "in_reply_to_status_id" : 171216080746987520,
  "created_at" : "2012-02-19 13:06:10 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171216080746987520",
  "geo" : { },
  "id_str" : "171216192147685376",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Yeah, we should start to work on this. I'm currently drafting this EU-stuff",
  "id" : 171216192147685376,
  "in_reply_to_status_id" : 171216080746987520,
  "created_at" : "2012-02-19 12:54:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171211909004140544",
  "geo" : { },
  "id_str" : "171215756745388034",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Lets do this for genotypes :P",
  "id" : 171215756745388034,
  "in_reply_to_status_id" : 171211909004140544,
  "created_at" : "2012-02-19 12:53:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 3, 16 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/Gqq0HOcx",
      "expanded_url" : "http:\/\/slate.me\/xW7YDi",
      "display_url" : "slate.me\/xW7YDi"
    } ]
  },
  "geo" : { },
  "id_str" : "170991291214209024",
  "text" : "RT @MishaAngrist: More on the AJOB train wreck. http:\/\/t.co\/Gqq0HOcx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http:\/\/t.co\/Gqq0HOcx",
        "expanded_url" : "http:\/\/slate.me\/xW7YDi",
        "display_url" : "slate.me\/xW7YDi"
      } ]
    },
    "geo" : { },
    "id_str" : "170988406871040000",
    "text" : "More on the AJOB train wreck. http:\/\/t.co\/Gqq0HOcx",
    "id" : 170988406871040000,
    "created_at" : "2012-02-18 21:49:47 +0000",
    "user" : {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "protected" : false,
      "id_str" : "116877838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747461459974717441\/GIrZkLT-_normal.jpg",
      "id" : 116877838,
      "verified" : false
    }
  },
  "id" : 170991291214209024,
  "created_at" : "2012-02-18 22:01:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1176271402, 8.5567111588 ]
  },
  "id_str" : "170983141857705984",
  "text" : "\u00ABGlaubst du nicht das ein K\u00E4nguru als Bundespr\u00E4sident das Amt besch\u00E4digen w\u00FCrde?\u00BB \u2014 \u00ABWohl mehr die Spezies...\u00BB",
  "id" : 170983141857705984,
  "created_at" : "2012-02-18 21:28:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pornogesicht",
      "screen_name" : "pornogesicht",
      "indices" : [ 3, 16 ],
      "id_str" : "496310827",
      "id" : 496310827
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gruppe42",
      "indices" : [ 44, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170974783318671360",
  "text" : "RT @pornogesicht: Donde esta la biblioteca? #gruppe42",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gruppe42",
        "indices" : [ 26, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170974017912709120",
    "text" : "Donde esta la biblioteca? #gruppe42",
    "id" : 170974017912709120,
    "created_at" : "2012-02-18 20:52:37 +0000",
    "user" : {
      "name" : "pornogesicht",
      "screen_name" : "pornogesicht",
      "protected" : false,
      "id_str" : "496310827",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1836754605\/gOOS_normal.jpeg",
      "id" : 496310827,
      "verified" : false
    }
  },
  "id" : 170974783318671360,
  "created_at" : "2012-02-18 20:55:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gruppe42",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1176559485, 8.5566744064 ]
  },
  "id_str" : "170974001231970304",
  "text" : "Um sich besser auf die Kernthemen konzentrieren zu k\u00F6nnen schlie\u00DFen wir uns sofort der Nukularia an. #Gruppe42",
  "id" : 170974001231970304,
  "created_at" : "2012-02-18 20:52:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens-Wolfhard",
      "screen_name" : "Drahflow",
      "indices" : [ 0, 9 ],
      "id_str" : "92904426",
      "id" : 92904426
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gruppe42",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170967925803597824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1176324995, 8.556610244 ]
  },
  "id_str" : "170968404902162432",
  "in_reply_to_user_id" : 92904426,
  "text" : "@Drahflow unser Chapter hier hat einen eigenen Transparenzbeauftragten. Immer nach dem mit der Fawkes-Maske Ausschau halten. #Gruppe42",
  "id" : 170968404902162432,
  "in_reply_to_status_id" : 170967925803597824,
  "created_at" : "2012-02-18 20:30:18 +0000",
  "in_reply_to_screen_name" : "Drahflow",
  "in_reply_to_user_id_str" : "92904426",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Haflinger",
      "screen_name" : "Nick_Haflinger",
      "indices" : [ 0, 15 ],
      "id_str" : "94528608",
      "id" : 94528608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170967887832547328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1176791337, 8.5567026509 ]
  },
  "id_str" : "170968121841168384",
  "in_reply_to_user_id" : 94528608,
  "text" : "@Nick_Haflinger keine Ahnung um was es da geht. Wir haben das Ding f\u00FCrs gemeinschaftliche Kochen \u00FCbernommen ;)",
  "id" : 170968121841168384,
  "in_reply_to_status_id" : 170967887832547328,
  "created_at" : "2012-02-18 20:29:11 +0000",
  "in_reply_to_screen_name" : "Nick_Haflinger",
  "in_reply_to_user_id_str" : "94528608",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gruppe42",
      "indices" : [ 4, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1176890202, 8.5565991918 ]
  },
  "id_str" : "170967010329628672",
  "text" : "Die #Gruppe42 bespricht gerade die n\u00E4chste Muffin-Party mit anschlie\u00DFender Grundgesetz- und UrhG-Verbrennung.",
  "id" : 170967010329628672,
  "created_at" : "2012-02-18 20:24:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beatrice Lugger",
      "screen_name" : "BLugger",
      "indices" : [ 0, 8 ],
      "id_str" : "14699615",
      "id" : 14699615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170961747686068225",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1176609336, 8.5564542876 ]
  },
  "id_str" : "170965218896252928",
  "in_reply_to_user_id" : 14699615,
  "text" : "@BLugger und jetzt funktionieren die Links f\u00FCr die PLoS-Paper auch. Aber danke f\u00FCr die Idee. :)",
  "id" : 170965218896252928,
  "in_reply_to_status_id" : 170961747686068225,
  "created_at" : "2012-02-18 20:17:39 +0000",
  "in_reply_to_screen_name" : "BLugger",
  "in_reply_to_user_id_str" : "14699615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Voll dufter Typ",
      "screen_name" : "supaheld",
      "indices" : [ 0, 9 ],
      "id_str" : "52670399",
      "id" : 52670399
    }, {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 37, 45 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gruppe42",
      "indices" : [ 10, 19 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170957514278572032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1176870028, 8.5566656963 ]
  },
  "id_str" : "170957900494290944",
  "in_reply_to_user_id" : 52670399,
  "text" : "@supaheld #Gruppe42 ist das Tag. Der @insideX hat schon seine Zeremonialrobe an.",
  "id" : 170957900494290944,
  "in_reply_to_status_id" : 170957514278572032,
  "created_at" : "2012-02-18 19:48:34 +0000",
  "in_reply_to_screen_name" : "supaheld",
  "in_reply_to_user_id_str" : "52670399",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Vaughan Bell",
      "screen_name" : "vaughanbell",
      "indices" : [ 91, 103 ],
      "id_str" : "20542737",
      "id" : 20542737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/jyoSSLFh",
      "expanded_url" : "http:\/\/bit.ly\/xx0qVA",
      "display_url" : "bit.ly\/xx0qVA"
    } ]
  },
  "geo" : { },
  "id_str" : "170950636333047809",
  "text" : "RT @edyong209: Delusional pregnancy - as common among men as women http:\/\/t.co\/jyoSSLFh by @vaughanbell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vaughan Bell",
        "screen_name" : "vaughanbell",
        "indices" : [ 76, 88 ],
        "id_str" : "20542737",
        "id" : 20542737
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/jyoSSLFh",
        "expanded_url" : "http:\/\/bit.ly\/xx0qVA",
        "display_url" : "bit.ly\/xx0qVA"
      } ]
    },
    "geo" : { },
    "id_str" : "170945684290281473",
    "text" : "Delusional pregnancy - as common among men as women http:\/\/t.co\/jyoSSLFh by @vaughanbell",
    "id" : 170945684290281473,
    "created_at" : "2012-02-18 19:00:01 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 170950636333047809,
  "created_at" : "2012-02-18 19:19:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Clarke",
      "screen_name" : "canislatrans",
      "indices" : [ 3, 16 ],
      "id_str" : "11696382",
      "id" : 11696382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170940796466507778",
  "text" : "RT @canislatrans: Skepticism as video game: Religion is End Boss of Level 1. Then come Sexism and Libertarianism, but most declare victo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170932808766853121",
    "text" : "Skepticism as video game: Religion is End Boss of Level 1. Then come Sexism and Libertarianism, but most declare victory & quit after 1.",
    "id" : 170932808766853121,
    "created_at" : "2012-02-18 18:08:52 +0000",
    "user" : {
      "name" : "Chris Clarke",
      "screen_name" : "canislatrans",
      "protected" : false,
      "id_str" : "11696382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837863350016983040\/a8zH7920_normal.jpg",
      "id" : 11696382,
      "verified" : false
    }
  },
  "id" : 170940796466507778,
  "created_at" : "2012-02-18 18:40:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/I62YZC74",
      "expanded_url" : "http:\/\/j.mp\/xtqMJ5",
      "display_url" : "j.mp\/xtqMJ5"
    } ]
  },
  "geo" : { },
  "id_str" : "170937875137957888",
  "text" : "Birth control is safer than pregnancy http:\/\/t.co\/I62YZC74",
  "id" : 170937875137957888,
  "created_at" : "2012-02-18 18:28:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 5, 14 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/Prk9DAQ8",
      "expanded_url" : "http:\/\/instagr.am\/p\/HJ_9VjBwsL\/",
      "display_url" : "instagr.am\/p\/HJ_9VjBwsL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "170930568291287040",
  "text" : "Dank @snooze82 hab ich jetzt einen Companion! http:\/\/t.co\/Prk9DAQ8",
  "id" : 170930568291287040,
  "created_at" : "2012-02-18 17:59:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 19, 30 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Beatrice Lugger",
      "screen_name" : "BLugger",
      "indices" : [ 99, 107 ],
      "id_str" : "14699615",
      "id" : 14699615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/6JqJHf0Z",
      "expanded_url" : "http:\/\/opensnp.org\/news#publications",
      "display_url" : "opensnp.org\/news#publicati\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170919179371806722",
  "text" : "Jetzt kann man bei @openSNPorg auch die neusten Paper per RSS abonnieren. http:\/\/t.co\/6JqJHf0Z \/cc @BLugger",
  "id" : 170919179371806722,
  "created_at" : "2012-02-18 17:14:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralf Praschak",
      "screen_name" : "nowrap",
      "indices" : [ 0, 7 ],
      "id_str" : "45787408",
      "id" : 45787408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170864524105232384",
  "geo" : { },
  "id_str" : "170867806986964992",
  "in_reply_to_user_id" : 45787408,
  "text" : "@nowrap W\u00E4ren wir doch nur mal zur DPA gerannt :D",
  "id" : 170867806986964992,
  "in_reply_to_status_id" : 170864524105232384,
  "created_at" : "2012-02-18 13:50:34 +0000",
  "in_reply_to_screen_name" : "nowrap",
  "in_reply_to_user_id_str" : "45787408",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas",
      "screen_name" : "AndreasSchepers",
      "indices" : [ 0, 16 ],
      "id_str" : "12321512",
      "id" : 12321512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170841375598845952",
  "geo" : { },
  "id_str" : "170841503596425216",
  "in_reply_to_user_id" : 12321512,
  "text" : "@AndreasSchepers Gern doch :)",
  "id" : 170841503596425216,
  "in_reply_to_status_id" : 170841375598845952,
  "created_at" : "2012-02-18 12:06:03 +0000",
  "in_reply_to_screen_name" : "AndreasSchepers",
  "in_reply_to_user_id_str" : "12321512",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas",
      "screen_name" : "AndreasSchepers",
      "indices" : [ 0, 16 ],
      "id_str" : "12321512",
      "id" : 12321512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/DoMGVsK0",
      "expanded_url" : "http:\/\/buyersguide.macrumors.com\/",
      "display_url" : "buyersguide.macrumors.com"
    } ]
  },
  "in_reply_to_status_id_str" : "170840493863878656",
  "geo" : { },
  "id_str" : "170841014465069056",
  "in_reply_to_user_id" : 12321512,
  "text" : "@AndreasSchepers Schau mal hier: http:\/\/t.co\/DoMGVsK0",
  "id" : 170841014465069056,
  "in_reply_to_status_id" : 170840493863878656,
  "created_at" : "2012-02-18 12:04:06 +0000",
  "in_reply_to_screen_name" : "AndreasSchepers",
  "in_reply_to_user_id_str" : "12321512",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openaccess",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/vCpFvGLV",
      "expanded_url" : "http:\/\/svpow.wordpress.com\/2012\/02\/15\/infographic-contribution-and-revenue-for-a-typical-scholarly-paper\/",
      "display_url" : "svpow.wordpress.com\/2012\/02\/15\/inf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170625799114850305",
  "text" : "Why we are angry http:\/\/t.co\/vCpFvGLV #openaccess",
  "id" : 170625799114850305,
  "created_at" : "2012-02-17 21:48:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Werthwein",
      "screen_name" : "Schlipsnerd",
      "indices" : [ 0, 12 ],
      "id_str" : "48845652",
      "id" : 48845652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170613111668215809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097445286, 8.2831113067 ]
  },
  "id_str" : "170613537914363906",
  "in_reply_to_user_id" : 48845652,
  "text" : "@Schlipsnerd denke das geht mehr in die Cloud und \u00FCberspringt die Heimatsph\u00E4re. ;)",
  "id" : 170613537914363906,
  "in_reply_to_status_id" : 170613111668215809,
  "created_at" : "2012-02-17 21:00:11 +0000",
  "in_reply_to_screen_name" : "Schlipsnerd",
  "in_reply_to_user_id_str" : "48845652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Werthwein",
      "screen_name" : "Schlipsnerd",
      "indices" : [ 0, 12 ],
      "id_str" : "48845652",
      "id" : 48845652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170613111668215809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097512688, 8.283135675 ]
  },
  "id_str" : "170613380682481664",
  "in_reply_to_user_id" : 48845652,
  "text" : "@Schlipsnerd in den meisten Laboren geht der Trend auch zum Outsourcing des Sequencings.",
  "id" : 170613380682481664,
  "in_reply_to_status_id" : 170613111668215809,
  "created_at" : "2012-02-17 20:59:34 +0000",
  "in_reply_to_screen_name" : "Schlipsnerd",
  "in_reply_to_user_id_str" : "48845652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Werthwein",
      "screen_name" : "Schlipsnerd",
      "indices" : [ 0, 12 ],
      "id_str" : "48845652",
      "id" : 48845652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170611117444435968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097293064, 8.283206493 ]
  },
  "id_str" : "170611610178691072",
  "in_reply_to_user_id" : 48845652,
  "text" : "@Schlipsnerd aber es braucht ja auch nicht jeder seinen eigenen Sequenzer.",
  "id" : 170611610178691072,
  "in_reply_to_status_id" : 170611117444435968,
  "created_at" : "2012-02-17 20:52:32 +0000",
  "in_reply_to_screen_name" : "Schlipsnerd",
  "in_reply_to_user_id_str" : "48845652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Werthwein",
      "screen_name" : "Schlipsnerd",
      "indices" : [ 0, 12 ],
      "id_str" : "48845652",
      "id" : 48845652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170611117444435968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096755242, 8.2831584741 ]
  },
  "id_str" : "170611434370240512",
  "in_reply_to_user_id" : 48845652,
  "text" : "@Schlipsnerd das bezweifle ich. So schnell wird der Preis f\u00FCr die Maschine nicht sinken. Nur f\u00FCr einzelne Sequenzierungen.",
  "id" : 170611434370240512,
  "in_reply_to_status_id" : 170611117444435968,
  "created_at" : "2012-02-17 20:51:50 +0000",
  "in_reply_to_screen_name" : "Schlipsnerd",
  "in_reply_to_user_id_str" : "48845652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Werthwein",
      "screen_name" : "Schlipsnerd",
      "indices" : [ 0, 12 ],
      "id_str" : "48845652",
      "id" : 48845652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170608881561649152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097310516, 8.2831583206 ]
  },
  "id_str" : "170609976111415297",
  "in_reply_to_user_id" : 48845652,
  "text" : "@Schlipsnerd sehr Werbewirksam, auch wenn die Gr\u00F6\u00DFe ja keine so gro\u00DFe Rolle spielt. :)",
  "id" : 170609976111415297,
  "in_reply_to_status_id" : 170608881561649152,
  "created_at" : "2012-02-17 20:46:02 +0000",
  "in_reply_to_screen_name" : "Schlipsnerd",
  "in_reply_to_user_id_str" : "48845652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Hubbard",
      "screen_name" : "timjph",
      "indices" : [ 3, 10 ],
      "id_str" : "7973282",
      "id" : 7973282
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 80, 96 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AGBT",
      "indices" : [ 40, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170609766790463490",
  "text" : "RT @timjph: New sequencers announced at #AGBT by Oxford Nanopore; one USB sized @pathogenomenick: full press release here http:\/\/t.co\/fY ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Loman",
        "screen_name" : "pathogenomenick",
        "indices" : [ 68, 84 ],
        "id_str" : "85906238",
        "id" : 85906238
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AGBT",
        "indices" : [ 28, 33 ]
      }, {
        "text" : "AGBT",
        "indices" : [ 131, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/fYNWJYEf",
        "expanded_url" : "http:\/\/pathogenomics.bham.ac.uk\/blog\/2012\/02\/oxford-nanopore-introduces-dna-strand-sequencing-on-the-high-throughput-gridion-platform-and-presents-minion-a-sequencer-the-size-of-a-usb-memory-stick\/",
        "display_url" : "pathogenomics.bham.ac.uk\/blog\/2012\/02\/o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "170558815207555072",
    "text" : "New sequencers announced at #AGBT by Oxford Nanopore; one USB sized @pathogenomenick: full press release here http:\/\/t.co\/fYNWJYEf #AGBT",
    "id" : 170558815207555072,
    "created_at" : "2012-02-17 17:22:45 +0000",
    "user" : {
      "name" : "Tim Hubbard",
      "screen_name" : "timjph",
      "protected" : false,
      "id_str" : "7973282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/495005879675019265\/TWKalIUW_normal.jpeg",
      "id" : 7973282,
      "verified" : false
    }
  },
  "id" : 170609766790463490,
  "created_at" : "2012-02-17 20:45:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens-Wolfhard",
      "screen_name" : "Drahflow",
      "indices" : [ 0, 9 ],
      "id_str" : "92904426",
      "id" : 92904426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170588047254106112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097284079, 8.2832393781 ]
  },
  "id_str" : "170608524869632000",
  "in_reply_to_user_id" : 92904426,
  "text" : "@Drahflow aber nicht jeder will in der Piratenfraktion arbeiten. ;)",
  "id" : 170608524869632000,
  "in_reply_to_status_id" : 170588047254106112,
  "created_at" : "2012-02-17 20:40:16 +0000",
  "in_reply_to_screen_name" : "Drahflow",
  "in_reply_to_user_id_str" : "92904426",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Bayer",
      "screen_name" : "diaeter",
      "indices" : [ 0, 8 ],
      "id_str" : "76908623",
      "id" : 76908623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170573889531944960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097323283, 8.2832601664 ]
  },
  "id_str" : "170608327288565760",
  "in_reply_to_user_id" : 76908623,
  "text" : "@diaeter das war auch das schwierigste ;)",
  "id" : 170608327288565760,
  "in_reply_to_status_id" : 170573889531944960,
  "created_at" : "2012-02-17 20:39:29 +0000",
  "in_reply_to_screen_name" : "diaeter",
  "in_reply_to_user_id_str" : "76908623",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/vNL8uXkc",
      "expanded_url" : "http:\/\/j.mp\/w47Yg0",
      "display_url" : "j.mp\/w47Yg0"
    } ]
  },
  "geo" : { },
  "id_str" : "170572192352960513",
  "text" : "Halbe Stellen in der Wissenschaft und andere halbe Sachen http:\/\/t.co\/vNL8uXkc",
  "id" : 170572192352960513,
  "created_at" : "2012-02-17 18:15:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/4VVUQpYn",
      "expanded_url" : "http:\/\/j.mp\/A2ocxB",
      "display_url" : "j.mp\/A2ocxB"
    } ]
  },
  "geo" : { },
  "id_str" : "170569984475537408",
  "text" : "John Cleese carefully considers your futile Youtube-Comments http:\/\/t.co\/4VVUQpYn",
  "id" : 170569984475537408,
  "created_at" : "2012-02-17 18:07:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/pH2J8jk7",
      "expanded_url" : "http:\/\/j.mp\/AnI48y",
      "display_url" : "j.mp\/AnI48y"
    } ]
  },
  "geo" : { },
  "id_str" : "170568331403857922",
  "text" : "Fallout shelter ads http:\/\/t.co\/pH2J8jk7",
  "id" : 170568331403857922,
  "created_at" : "2012-02-17 18:00:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 0, 7 ],
      "id_str" : "34880281",
      "id" : 34880281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170565397727281152",
  "geo" : { },
  "id_str" : "170565464227971073",
  "in_reply_to_user_id" : 34880281,
  "text" : "@otacke Okay, schauen wir mal was passiert ;)",
  "id" : 170565464227971073,
  "in_reply_to_status_id" : 170565397727281152,
  "created_at" : "2012-02-17 17:49:10 +0000",
  "in_reply_to_screen_name" : "otacke",
  "in_reply_to_user_id_str" : "34880281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 0, 7 ],
      "id_str" : "34880281",
      "id" : 34880281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170563584227672064",
  "geo" : { },
  "id_str" : "170565119321964544",
  "in_reply_to_user_id" : 34880281,
  "text" : "@otacke Naja im akademischen Betrieb hat man mit dem \"Unternehmen\" ja weniger zu tun ;)",
  "id" : 170565119321964544,
  "in_reply_to_status_id" : 170563584227672064,
  "created_at" : "2012-02-17 17:47:48 +0000",
  "in_reply_to_screen_name" : "otacke",
  "in_reply_to_user_id_str" : "34880281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 0, 7 ],
      "id_str" : "34880281",
      "id" : 34880281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170562940687220736",
  "geo" : { },
  "id_str" : "170563032517324802",
  "in_reply_to_user_id" : 34880281,
  "text" : "@otacke Danke, ich denk das mit den Gl\u00FCckw\u00FCnschen passt schon :)",
  "id" : 170563032517324802,
  "in_reply_to_status_id" : 170562940687220736,
  "created_at" : "2012-02-17 17:39:30 +0000",
  "in_reply_to_screen_name" : "otacke",
  "in_reply_to_user_id_str" : "34880281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerrit",
      "screen_name" : "GerritEicker",
      "indices" : [ 0, 13 ],
      "id_str" : "45082501",
      "id" : 45082501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170561475805593600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097478497, 8.2830720176 ]
  },
  "id_str" : "170562373306945536",
  "in_reply_to_user_id" : 45082501,
  "text" : "@GerritEicker das MPI f\u00FCr Machine Learning. :)",
  "id" : 170562373306945536,
  "in_reply_to_status_id" : 170561475805593600,
  "created_at" : "2012-02-17 17:36:53 +0000",
  "in_reply_to_screen_name" : "GerritEicker",
  "in_reply_to_user_id_str" : "45082501",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/BQZolc10",
      "expanded_url" : "http:\/\/instagr.am\/p\/HHXe1Ghwhf\/",
      "display_url" : "instagr.am\/p\/HHXe1Ghwhf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "170559881076678656",
  "text" : "Arbeitsvertrag unterschieben und losgeschickt.  http:\/\/t.co\/BQZolc10",
  "id" : 170559881076678656,
  "created_at" : "2012-02-17 17:26:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170510393544937473",
  "geo" : { },
  "id_str" : "170556765883207680",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ Naja, bestanden sein wird es schon :D",
  "id" : 170556765883207680,
  "in_reply_to_status_id" : 170510393544937473,
  "created_at" : "2012-02-17 17:14:36 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sir Beef-A-Lot \uD83C\uDDE9\uD83C\uDDEA\uD83D\uDD1C\uD83C\uDDEF\uD83C\uDDF5",
      "screen_name" : "FreXxX",
      "indices" : [ 24, 31 ],
      "id_str" : "22941893",
      "id" : 22941893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170483482185842688",
  "text" : "Einfach mal spontan dem @FreXxX \u00FCber den Weg laufen: check",
  "id" : 170483482185842688,
  "created_at" : "2012-02-17 12:23:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1728407432, 8.6278504132 ]
  },
  "id_str" : "170457038546157568",
  "text" : "Wenn das jetzt nicht v\u00F6llig daneben war, dann war das gerade die letzte Klausur \\o\/",
  "id" : 170457038546157568,
  "created_at" : "2012-02-17 10:38:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170396663041634304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0072607236, 8.2819052365 ]
  },
  "id_str" : "170397599466135553",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Daucus carota and Silene dioica are the ones that are left in my mind. :P",
  "id" : 170397599466135553,
  "in_reply_to_status_id" : 170396663041634304,
  "created_at" : "2012-02-17 06:42:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170395948860702720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0072958398, 8.2820257884 ]
  },
  "id_str" : "170397182736875520",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn but you should! The kind of exam influences how students will learn for it.",
  "id" : 170397182736875520,
  "in_reply_to_status_id" : 170395948860702720,
  "created_at" : "2012-02-17 06:40:28 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170394680117297152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0072677314, 8.2830120058 ]
  },
  "id_str" : "170395662247141377",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn I just memorised the 70 names without any concepts and forgot 68 of them 2 days after the exam. :P",
  "id" : 170395662247141377,
  "in_reply_to_status_id" : 170394680117297152,
  "created_at" : "2012-02-17 06:34:26 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 14, 27 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170393504273534976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097266938, 8.2832121532 ]
  },
  "id_str" : "170394098216337409",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @iameltonjohn ..of knowing 70 random plants by name ;)",
  "id" : 170394098216337409,
  "in_reply_to_status_id" : 170393504273534976,
  "created_at" : "2012-02-17 06:28:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 14, 27 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170393504273534976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097426667, 8.2830437807 ]
  },
  "id_str" : "170393964631961600",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @iameltonjohn sure, but I think even for botanists it would be more important to grasp the basic systematic concepts instead..",
  "id" : 170393964631961600,
  "in_reply_to_status_id" : 170393504273534976,
  "created_at" : "2012-02-17 06:27:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 14, 27 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170391854469222401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098241994, 8.2832348344 ]
  },
  "id_str" : "170393116354940928",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @iameltonjohn just think of this oral exam about our herbarium we did in M\u00FCnster. I learned next to nothing by doing it. :P",
  "id" : 170393116354940928,
  "in_reply_to_status_id" : 170391854469222401,
  "created_at" : "2012-02-17 06:24:19 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 14, 27 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170391854469222401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097264797, 8.2832133674 ]
  },
  "id_str" : "170392355109744640",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @iameltonjohn same here. The concept of rote learning shouldn't be something that will makes grades in university.",
  "id" : 170392355109744640,
  "in_reply_to_status_id" : 170391854469222401,
  "created_at" : "2012-02-17 06:21:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 14, 27 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170383864567566337",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095454016, 8.2834236026 ]
  },
  "id_str" : "170391062949543937",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn @PhilippBayer no multiple choice please, in 99.99% it is used for asking about stupid facts instead of greater concepts",
  "id" : 170391062949543937,
  "in_reply_to_status_id" : 170383864567566337,
  "created_at" : "2012-02-17 06:16:09 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "indices" : [ 3, 17 ],
      "id_str" : "19575586",
      "id" : 19575586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/bfrvPXjQ",
      "expanded_url" : "http:\/\/kennethreitz.com\/xcode-gcc-and-homebrew.html",
      "display_url" : "kennethreitz.com\/xcode-gcc-and-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170281134662488065",
  "text" : "RT @hackernewsbot: Xcode, GCC, and Homebrew... http:\/\/t.co\/bfrvPXjQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/news.ycombinator.com\/\" rel=\"nofollow\"\u003EHacker News Bot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/bfrvPXjQ",
        "expanded_url" : "http:\/\/kennethreitz.com\/xcode-gcc-and-homebrew.html",
        "display_url" : "kennethreitz.com\/xcode-gcc-and-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "170276787111211009",
    "text" : "Xcode, GCC, and Homebrew... http:\/\/t.co\/bfrvPXjQ",
    "id" : 170276787111211009,
    "created_at" : "2012-02-16 22:42:04 +0000",
    "user" : {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "protected" : false,
      "id_str" : "19575586",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/73596050\/yc500_normal.jpg",
      "id" : 19575586,
      "verified" : false
    }
  },
  "id" : 170281134662488065,
  "created_at" : "2012-02-16 22:59:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pam Spaulding",
      "screen_name" : "pamspaulding",
      "indices" : [ 3, 16 ],
      "id_str" : "7793902",
      "id" : 7793902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lgbt",
      "indices" : [ 86, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/hzmdTXlf",
      "expanded_url" : "http:\/\/ow.ly\/97pkE",
      "display_url" : "ow.ly\/97pkE"
    } ]
  },
  "geo" : { },
  "id_str" : "170278701739675649",
  "text" : "RT @pamspaulding: When Your 7-Year-Old Son Announces, 'I'm Gay'. http:\/\/t.co\/hzmdTXlf #lgbt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lgbt",
        "indices" : [ 68, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/hzmdTXlf",
        "expanded_url" : "http:\/\/ow.ly\/97pkE",
        "display_url" : "ow.ly\/97pkE"
      } ]
    },
    "geo" : { },
    "id_str" : "170260013141598208",
    "text" : "When Your 7-Year-Old Son Announces, 'I'm Gay'. http:\/\/t.co\/hzmdTXlf #lgbt",
    "id" : 170260013141598208,
    "created_at" : "2012-02-16 21:35:25 +0000",
    "user" : {
      "name" : "Pam Spaulding",
      "screen_name" : "pamspaulding",
      "protected" : false,
      "id_str" : "7793902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/803818651661074432\/EOcEGwP__normal.jpg",
      "id" : 7793902,
      "verified" : false
    }
  },
  "id" : 170278701739675649,
  "created_at" : "2012-02-16 22:49:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/ql7JICwC",
      "expanded_url" : "http:\/\/j.mp\/xu3Bs4",
      "display_url" : "j.mp\/xu3Bs4"
    } ]
  },
  "geo" : { },
  "id_str" : "170246563476676608",
  "text" : "All genomes are dysfunctional: broken genes in healthy individuals http:\/\/t.co\/ql7JICwC",
  "id" : 170246563476676608,
  "created_at" : "2012-02-16 20:41:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/WpBTLidM",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=gbUVIZi9aLo",
      "display_url" : "youtube.com\/watch?v=gbUVIZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170221102734385152",
  "text" : "A headband which senses your pulse http:\/\/t.co\/WpBTLidM",
  "id" : 170221102734385152,
  "created_at" : "2012-02-16 19:00:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/ift5JtQm",
      "expanded_url" : "http:\/\/j.mp\/zSM93W",
      "display_url" : "j.mp\/zSM93W"
    } ]
  },
  "geo" : { },
  "id_str" : "170202367197851648",
  "text" : "Genetics & Applied Medicine: Time to bring human genome sequencing into the clinic http:\/\/t.co\/ift5JtQm",
  "id" : 170202367197851648,
  "created_at" : "2012-02-16 17:46:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/BHV7jBLA",
      "expanded_url" : "http:\/\/j.mp\/zpn62a",
      "display_url" : "j.mp\/zpn62a"
    } ]
  },
  "geo" : { },
  "id_str" : "170199356065062912",
  "text" : "Anarchistic and self-trained, are street medics the future of first aid? http:\/\/t.co\/BHV7jBLA",
  "id" : 170199356065062912,
  "created_at" : "2012-02-16 17:34:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/tWTgkOiQ",
      "expanded_url" : "http:\/\/j.mp\/w6ljJ7",
      "display_url" : "j.mp\/w6ljJ7"
    } ]
  },
  "geo" : { },
  "id_str" : "170194572511690752",
  "text" : "\u00ABHOWTO fight cheating\u00BB by making students believe grades are not important http:\/\/t.co\/tWTgkOiQ",
  "id" : 170194572511690752,
  "created_at" : "2012-02-16 17:15:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/koMi3gpb",
      "expanded_url" : "http:\/\/www.outsideonline.com\/outdoor-adventure\/water-activities\/open-your-mouth-and-youre-dead.html?page=all",
      "display_url" : "outsideonline.com\/outdoor-advent\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170188743683215360",
  "text" : "Diving: Open your mouth and your're dead. http:\/\/t.co\/koMi3gpb",
  "id" : 170188743683215360,
  "created_at" : "2012-02-16 16:52:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/nxsZ393x",
      "expanded_url" : "http:\/\/j.mp\/zt0U4n",
      "display_url" : "j.mp\/zt0U4n"
    } ]
  },
  "geo" : { },
  "id_str" : "170124277461422080",
  "text" : "Everything is a Remix: System Failure & Social Evolution http:\/\/t.co\/nxsZ393x",
  "id" : 170124277461422080,
  "created_at" : "2012-02-16 12:36:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170120200233025536",
  "text" : "Hipster Evolutionary Biologists: I had this phenotype before it was adaptive.",
  "id" : 170120200233025536,
  "created_at" : "2012-02-16 12:19:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170118938724806656",
  "geo" : { },
  "id_str" : "170119404774887425",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Larmarckism? Giraffes are carrying their necks ironically!",
  "id" : 170119404774887425,
  "in_reply_to_status_id" : 170118938724806656,
  "created_at" : "2012-02-16 12:16:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 96, 109 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170117773521989632",
  "text" : "Hipster Evolutionary Biologist: Darwin? I liked the first edition of the Origin of Species. \/cc @PhilippBayer",
  "id" : 170117773521989632,
  "created_at" : "2012-02-16 12:10:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170114955763396608",
  "geo" : { },
  "id_str" : "170115745043324928",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Is it the 1st edition? :D",
  "id" : 170115745043324928,
  "in_reply_to_status_id" : 170114955763396608,
  "created_at" : "2012-02-16 12:02:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffa",
      "screen_name" : "rei_in_der_tube",
      "indices" : [ 0, 16 ],
      "id_str" : "19707954",
      "id" : 19707954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170114961090162689",
  "geo" : { },
  "id_str" : "170115016488525824",
  "in_reply_to_user_id" : 19707954,
  "text" : "@rei_in_der_tube N\u00F6, der war einfach auf einmal wieder da.",
  "id" : 170115016488525824,
  "in_reply_to_status_id" : 170114961090162689,
  "created_at" : "2012-02-16 11:59:15 +0000",
  "in_reply_to_screen_name" : "rei_in_der_tube",
  "in_reply_to_user_id_str" : "19707954",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170112353231323136",
  "text" : "RT @PhilippBayer: YouPorn now runs 100% on Redis - had to add nodes because network-cards couldn't keep up with Redis, 300K queries\/sec! ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 140 ],
        "url" : "https:\/\/t.co\/xpm40uN8",
        "expanded_url" : "https:\/\/groups.google.com\/forum\/?fromgroups#!topic\/redis-db\/d4QcWV0p-YM",
        "display_url" : "groups.google.com\/forum\/?fromgro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "170111944534142976",
    "text" : "YouPorn now runs 100% on Redis - had to add nodes because network-cards couldn't keep up with Redis, 300K queries\/sec! https:\/\/t.co\/xpm40uN8",
    "id" : 170111944534142976,
    "created_at" : "2012-02-16 11:47:02 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 170112353231323136,
  "created_at" : "2012-02-16 11:48:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170109640678445056",
  "geo" : { },
  "id_str" : "170111099323162625",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX Pornodreh?",
  "id" : 170111099323162625,
  "in_reply_to_status_id" : 170109640678445056,
  "created_at" : "2012-02-16 11:43:41 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@xAndy",
      "screen_name" : "xAndy",
      "indices" : [ 3, 9 ],
      "id_str" : "15198735",
      "id" : 15198735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/5Rl63Jwk",
      "expanded_url" : "http:\/\/bit.ly\/ycAXuN",
      "display_url" : "bit.ly\/ycAXuN"
    } ]
  },
  "geo" : { },
  "id_str" : "170085589444603904",
  "text" : "RT @xAndy: Game Developer Gives 7-Year-Old Best Birthday Present Ever http:\/\/t.co\/5Rl63Jwk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/5Rl63Jwk",
        "expanded_url" : "http:\/\/bit.ly\/ycAXuN",
        "display_url" : "bit.ly\/ycAXuN"
      } ]
    },
    "geo" : { },
    "id_str" : "170081996830277632",
    "text" : "Game Developer Gives 7-Year-Old Best Birthday Present Ever http:\/\/t.co\/5Rl63Jwk",
    "id" : 170081996830277632,
    "created_at" : "2012-02-16 09:48:02 +0000",
    "user" : {
      "name" : "@xAndy",
      "screen_name" : "xAndy",
      "protected" : false,
      "id_str" : "15198735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/429957019957608448\/mLROG-GJ_normal.jpeg",
      "id" : 15198735,
      "verified" : false
    }
  },
  "id" : 170085589444603904,
  "created_at" : "2012-02-16 10:02:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098171012, 8.2832326044 ]
  },
  "id_str" : "170069656927862785",
  "text" : "Kater sitzt vor der angelehnten Gartent\u00FCr und maunzt weil er \"aufschieben\" nicht versteht. Kein Wunder das er 2 Wochen \"eingesperrt\" war.",
  "id" : 170069656927862785,
  "created_at" : "2012-02-16 08:59:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel MacArthur",
      "screen_name" : "dgmacarthur",
      "indices" : [ 0, 12 ],
      "id_str" : "16629477",
      "id" : 16629477
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 13, 22 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169939823996567554",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0103002127, 8.2833187765 ]
  },
  "id_str" : "169941589194575872",
  "in_reply_to_user_id" : 16629477,
  "text" : "@dgmacarthur @wilbanks thanks, looking forward to read the blogpost!",
  "id" : 169941589194575872,
  "in_reply_to_status_id" : 169939823996567554,
  "created_at" : "2012-02-16 00:30:06 +0000",
  "in_reply_to_screen_name" : "dgmacarthur",
  "in_reply_to_user_id_str" : "16629477",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/tnf6rvaK",
      "expanded_url" : "http:\/\/j.mp\/wzmyYX",
      "display_url" : "j.mp\/wzmyYX"
    } ]
  },
  "geo" : { },
  "id_str" : "169935200434917376",
  "text" : "The Plagiarist's Tale http:\/\/t.co\/tnf6rvaK",
  "id" : 169935200434917376,
  "created_at" : "2012-02-16 00:04:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/V1y2n0O4",
      "expanded_url" : "http:\/\/j.mp\/AbMQd6",
      "display_url" : "j.mp\/AbMQd6"
    } ]
  },
  "geo" : { },
  "id_str" : "169932805302792192",
  "text" : "Sexual conflicts: Female burying beetles benefit from experimentally simulated male desertion http:\/\/t.co\/V1y2n0O4",
  "id" : 169932805302792192,
  "created_at" : "2012-02-15 23:55:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel MacArthur",
      "screen_name" : "dgmacarthur",
      "indices" : [ 0, 12 ],
      "id_str" : "16629477",
      "id" : 16629477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169931306187243520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097818246, 8.2831983285 ]
  },
  "id_str" : "169931764318470144",
  "in_reply_to_user_id" : 16629477,
  "text" : "@dgmacarthur could you help me out as well? bgreshake@googlemail.com",
  "id" : 169931764318470144,
  "in_reply_to_status_id" : 169931306187243520,
  "created_at" : "2012-02-15 23:51:04 +0000",
  "in_reply_to_screen_name" : "dgmacarthur",
  "in_reply_to_user_id_str" : "16629477",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 3, 14 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169927935682281473",
  "text" : "RT @openSNPorg: Longitudinal GWAS on obesity: The gene effects can vary with age and be modified by prenatal development http:\/\/t.co\/TLa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/TLauACkR",
        "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plosone\/GeneticsandGenomics\/~3\/u9epAekgsFA\/info%3Adoi%2F10.1371%2Fjournal.pone.0031470",
        "display_url" : "feeds.plos.org\/~r\/plosone\/Gen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "169927831235735552",
    "text" : "Longitudinal GWAS on obesity: The gene effects can vary with age and be modified by prenatal development http:\/\/t.co\/TLauACkR",
    "id" : 169927831235735552,
    "created_at" : "2012-02-15 23:35:26 +0000",
    "user" : {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "protected" : false,
      "id_str" : "380205172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735374825187909632\/wJEJW1zW_normal.jpg",
      "id" : 380205172,
      "verified" : false
    }
  },
  "id" : 169927935682281473,
  "created_at" : "2012-02-15 23:35:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097605427, 8.2831462541 ]
  },
  "id_str" : "169927233824231425",
  "text" : "Bestimmt werde ich Hausmann damit meine Verlobte f\u00FCr einen Haufen Spinner umsonst arbeitet.",
  "id" : 169927233824231425,
  "created_at" : "2012-02-15 23:33:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/le74dfHs",
      "expanded_url" : "http:\/\/j.mp\/zR5FRF",
      "display_url" : "j.mp\/zR5FRF"
    } ]
  },
  "geo" : { },
  "id_str" : "169926581819670528",
  "text" : "No Snail Left Behind (I know, Army != Marines...) http:\/\/t.co\/le74dfHs",
  "id" : 169926581819670528,
  "created_at" : "2012-02-15 23:30:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/beu3wSkI",
      "expanded_url" : "http:\/\/j.mp\/yfhZRA",
      "display_url" : "j.mp\/yfhZRA"
    } ]
  },
  "geo" : { },
  "id_str" : "169925824521310208",
  "text" : "NIH tightening access to \u2018random source\u2019 dogs and cats http:\/\/t.co\/beu3wSkI",
  "id" : 169925824521310208,
  "created_at" : "2012-02-15 23:27:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/cWj9ca5H",
      "expanded_url" : "http:\/\/is.gd\/OZDKqN",
      "display_url" : "is.gd\/OZDKqN"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097676131, 8.2830574964 ]
  },
  "id_str" : "169925143521542144",
  "text" : "Too much of a \"good\" thing: \"This whole bureaucracy to support women in the military who are now being raped too much\" http:\/\/t.co\/cWj9ca5H",
  "id" : 169925143521542144,
  "created_at" : "2012-02-15 23:24:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/gphz9avZ",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/NerdcoreRSS2\/~3\/Sb91OtRlQvk\/",
      "display_url" : "feedproxy.google.com\/~r\/NerdcoreRSS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169917876977938432",
  "text" : "Barbara Nitkis Behind-The-Scenes-Shots of Porn from the 80s http:\/\/t.co\/gphz9avZ",
  "id" : 169917876977938432,
  "created_at" : "2012-02-15 22:55:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169914772517687296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0112189623, 8.2825430327 ]
  },
  "id_str" : "169914903140900864",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ich hab dir einen Roomba gekauft, das muss reichen.",
  "id" : 169914903140900864,
  "in_reply_to_status_id" : 169914772517687296,
  "created_at" : "2012-02-15 22:44:04 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169913318184718336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.01151722, 8.28247034 ]
  },
  "id_str" : "169913948999659520",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon du machst doch jetzt schon nix f\u00FCr die Uni ;)",
  "id" : 169913948999659520,
  "in_reply_to_status_id" : 169913318184718336,
  "created_at" : "2012-02-15 22:40:16 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169530329281998850",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097448531, 8.2831273587 ]
  },
  "id_str" : "169828985797222400",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks reads like a thoughtful assembly. Are there news on the API-ideas? :)",
  "id" : 169828985797222400,
  "in_reply_to_status_id" : 169530329281998850,
  "created_at" : "2012-02-15 17:02:40 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 8, 16 ],
      "id_str" : "621716753",
      "id" : 621716753
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 17, 23 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Dedalus Root",
      "screen_name" : "DedalusRoot",
      "indices" : [ 24, 36 ],
      "id_str" : "112733212",
      "id" : 112733212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/sePJgYgx",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=r0-LGPj2CLQ",
      "display_url" : "youtube.com\/watch?v=r0-LGP\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "169814399970844673",
  "geo" : { },
  "id_str" : "169814681110851584",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 @Scytale @Lobot @DedalusRoot http:\/\/t.co\/sePJgYgx",
  "id" : 169814681110851584,
  "in_reply_to_status_id" : 169814399970844673,
  "created_at" : "2012-02-15 16:05:49 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/Q4gqlEli",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plosone\/GeneticsandGenomics\/~3\/f5PvG4PjB2Y\/info%3Adoi%2F10.1371%2Fjournal.pone.0030953",
      "display_url" : "feeds.plos.org\/~r\/plosone\/Gen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169813128706666496",
  "text" : "Nice: Rapid Microsatellite Identification from Illumina Paired-End Genomic Sequencing in Two Birds and a Snake http:\/\/t.co\/Q4gqlEli",
  "id" : 169813128706666496,
  "created_at" : "2012-02-15 15:59:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/ffLSzIn3",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/scienceblogs\/pharyngula\/~3\/AURENE-9x0g\/biology_teaches_that_sexual_de.php",
      "display_url" : "feedproxy.google.com\/~r\/scienceblog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169811646376710144",
  "text" : "Lizards: Doing the homoerotic bulldyke carpet munch humping http:\/\/t.co\/ffLSzIn3",
  "id" : 169811646376710144,
  "created_at" : "2012-02-15 15:53:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169811081986969601",
  "geo" : { },
  "id_str" : "169811278267813889",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn I request Pet-Mini-Chameleons, NOW! :D",
  "id" : 169811278267813889,
  "in_reply_to_status_id" : 169811081986969601,
  "created_at" : "2012-02-15 15:52:18 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/XcPh0rko",
      "expanded_url" : "http:\/\/j.mp\/xdRled",
      "display_url" : "j.mp\/xdRled"
    } ]
  },
  "geo" : { },
  "id_str" : "169810915930279936",
  "text" : "Wasteful and unethical: why we hate crippled products http:\/\/t.co\/XcPh0rko",
  "id" : 169810915930279936,
  "created_at" : "2012-02-15 15:50:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/rLU3zDyL",
      "expanded_url" : "http:\/\/j.mp\/xwSSxj",
      "display_url" : "j.mp\/xwSSxj"
    } ]
  },
  "geo" : { },
  "id_str" : "169809456840978432",
  "text" : "Young German profs underpaid, court says http:\/\/t.co\/rLU3zDyL",
  "id" : 169809456840978432,
  "created_at" : "2012-02-15 15:45:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/6hzkhm95",
      "expanded_url" : "http:\/\/j.mp\/y0TpaS",
      "display_url" : "j.mp\/y0TpaS"
    } ]
  },
  "geo" : { },
  "id_str" : "169809084265136129",
  "text" : "Awwww &lt;3 A new miniature chameleon has been found! http:\/\/t.co\/6hzkhm95",
  "id" : 169809084265136129,
  "created_at" : "2012-02-15 15:43:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/wioKGlpR",
      "expanded_url" : "http:\/\/j.mp\/zxJ9DI",
      "display_url" : "j.mp\/zxJ9DI"
    } ]
  },
  "geo" : { },
  "id_str" : "169808590121615361",
  "text" : "The Open Access Irony Awards: Naming and shaming http:\/\/t.co\/wioKGlpR",
  "id" : 169808590121615361,
  "created_at" : "2012-02-15 15:41:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 3, 15 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/febfNfV4",
      "expanded_url" : "http:\/\/jonfwilkins.blogspot.com\/2012\/02\/infringing-on-fallopitarian-religious.html",
      "display_url" : "jonfwilkins.blogspot.com\/2012\/02\/infrin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169807460545204224",
  "text" : "RT @jonfwilkins: Prostate exams infringing on Fallopitarian religious freedom!! http:\/\/t.co\/febfNfV4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/febfNfV4",
        "expanded_url" : "http:\/\/jonfwilkins.blogspot.com\/2012\/02\/infringing-on-fallopitarian-religious.html",
        "display_url" : "jonfwilkins.blogspot.com\/2012\/02\/infrin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "169805275186999297",
    "text" : "Prostate exams infringing on Fallopitarian religious freedom!! http:\/\/t.co\/febfNfV4",
    "id" : 169805275186999297,
    "created_at" : "2012-02-15 15:28:27 +0000",
    "user" : {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "protected" : false,
      "id_str" : "214099847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1279449740\/Dev2DEC_normal.jpg",
      "id" : 214099847,
      "verified" : false
    }
  },
  "id" : 169807460545204224,
  "created_at" : "2012-02-15 15:37:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 0, 11 ],
      "id_str" : "3782931",
      "id" : 3782931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169777229608394752",
  "geo" : { },
  "id_str" : "169777469342232576",
  "in_reply_to_user_id" : 3782931,
  "text" : "@spreeblick Ist Chrome schon ewig und 3 Tage lang offen? Manchmal schliesst es die alten Tab-Prozesse nicht richtig.",
  "id" : 169777469342232576,
  "in_reply_to_status_id" : 169777229608394752,
  "created_at" : "2012-02-15 13:37:57 +0000",
  "in_reply_to_screen_name" : "spreeblick",
  "in_reply_to_user_id_str" : "3782931",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/Vgc2IJBd",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/jru9apraUDw\/will-you-be-ours-valentines.html",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169767840575004673",
  "text" : "Valentine's Day for the polyamorous http:\/\/t.co\/Vgc2IJBd",
  "id" : 169767840575004673,
  "created_at" : "2012-02-15 12:59:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/PcfrxgzT",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/6RJiTMR6wM0\/lessons-from-prop-8-why-we-s.html",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169767274679513089",
  "text" : "Lessons from Prop. 8: why we shouldn't put our civil rights up for a popular vote http:\/\/t.co\/PcfrxgzT",
  "id" : 169767274679513089,
  "created_at" : "2012-02-15 12:57:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097427022, 8.2831498192 ]
  },
  "id_str" : "169530393383550977",
  "text" : "Meh, sie h\u00E4tten Highlander in W\u00FCrde mit der 5. Staffel sterben lassen sollen.",
  "id" : 169530393383550977,
  "created_at" : "2012-02-14 21:16:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffa",
      "screen_name" : "rei_in_der_tube",
      "indices" : [ 0, 16 ],
      "id_str" : "19707954",
      "id" : 19707954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169375769318006784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0127256265, 8.2843740626 ]
  },
  "id_str" : "169375944132395008",
  "in_reply_to_user_id" : 19707954,
  "text" : "@rei_in_der_tube siesmayer",
  "id" : 169375944132395008,
  "in_reply_to_status_id" : 169375769318006784,
  "created_at" : "2012-02-14 11:02:26 +0000",
  "in_reply_to_screen_name" : "rei_in_der_tube",
  "in_reply_to_user_id_str" : "19707954",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.113877841, 8.6788095799 ]
  },
  "id_str" : "169346723884433408",
  "text" : "The heating for the whole building broke down. 10 deg C and dropping. So no exam today.",
  "id" : 169346723884433408,
  "created_at" : "2012-02-14 09:06:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/2VmLvBLh",
      "expanded_url" : "http:\/\/j.mp\/yutBUd",
      "display_url" : "j.mp\/yutBUd"
    } ]
  },
  "geo" : { },
  "id_str" : "169320205762314240",
  "text" : "Epigenomics and Privacy http:\/\/t.co\/2VmLvBLh",
  "id" : 169320205762314240,
  "created_at" : "2012-02-14 07:20:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169204020911685632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.01192736, 8.28353118 ]
  },
  "id_str" : "169206974720905216",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn thanks! :)",
  "id" : 169206974720905216,
  "in_reply_to_status_id" : 169204020911685632,
  "created_at" : "2012-02-13 23:51:01 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169203040639909888",
  "geo" : { },
  "id_str" : "169203629809606657",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn But now I'll need some sleep. ~5 hours until I have to get up to write my last exam. :D",
  "id" : 169203629809606657,
  "in_reply_to_status_id" : 169203040639909888,
  "created_at" : "2012-02-13 23:37:43 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    }, {
      "name" : "cariaso",
      "screen_name" : "cariaso",
      "indices" : [ 74, 82 ],
      "id_str" : "14151263",
      "id" : 14151263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169203040639909888",
  "geo" : { },
  "id_str" : "169203285415313408",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn or this is just how the raw-data looks like, but I'll write @cariaso an email about this tomorrow. :)",
  "id" : 169203285415313408,
  "in_reply_to_status_id" : 169203040639909888,
  "created_at" : "2012-02-13 23:36:21 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169203040639909888",
  "geo" : { },
  "id_str" : "169203190389145601",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn Yeah, so it's not that it just fills up the second column with the same allele but somehow mixes things up",
  "id" : 169203190389145601,
  "in_reply_to_status_id" : 169203040639909888,
  "created_at" : "2012-02-13 23:35:58 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169201595748319232",
  "geo" : { },
  "id_str" : "169202048808665088",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn and Y and MT are heterozygotous for some sites :D",
  "id" : 169202048808665088,
  "in_reply_to_status_id" : 169201595748319232,
  "created_at" : "2012-02-13 23:31:26 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169201595748319232",
  "geo" : { },
  "id_str" : "169201948757721090",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn That this female has SNPs called for the Y-chromosome: Fine. But Y chromosome and MT genome are diploid o_O",
  "id" : 169201948757721090,
  "in_reply_to_status_id" : 169201595748319232,
  "created_at" : "2012-02-13 23:31:02 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169201595748319232",
  "geo" : { },
  "id_str" : "169201797532098560",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn Some 40 lines of Python to compare the files. But I found some strange things within the Denisova VCF from SNPedia",
  "id" : 169201797532098560,
  "in_reply_to_status_id" : 169201595748319232,
  "created_at" : "2012-02-13 23:30:26 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 30, 43 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 122, 130 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169201150481022976",
  "text" : "To put this into perspective: @iameltonjohn and I have the same genotype at ~56 % of the 966983 SNPs which were tested by @23andMe",
  "id" : 169201150481022976,
  "created_at" : "2012-02-13 23:27:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169200601404674049",
  "text" : "The Denisova hominin and I share the same genotype for ~31 % of the 338450 SNPs which I can find in both genomes.",
  "id" : 169200601404674049,
  "created_at" : "2012-02-13 23:25:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169186693323296768",
  "geo" : { },
  "id_str" : "169187105162010624",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Die Wiki-Seite liest sich auch ganz interessant.",
  "id" : 169187105162010624,
  "in_reply_to_status_id" : 169186693323296768,
  "created_at" : "2012-02-13 22:32:03 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169186430457880576",
  "geo" : { },
  "id_str" : "169186498690826240",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Ne, lohnt sich?",
  "id" : 169186498690826240,
  "in_reply_to_status_id" : 169186430457880576,
  "created_at" : "2012-02-13 22:29:39 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169185720462884864",
  "geo" : { },
  "id_str" : "169185909999280128",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Ja, vor allem weil die Frage ist was ich danach dann schauen werde. ;)",
  "id" : 169185909999280128,
  "in_reply_to_status_id" : 169185720462884864,
  "created_at" : "2012-02-13 22:27:18 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169185363103973376",
  "geo" : { },
  "id_str" : "169185660333330432",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Ne, bin gerade bei den letzten Folgen der letzten Staffel (bei denen der Lead-Charakter AWOL ist...)",
  "id" : 169185660333330432,
  "in_reply_to_status_id" : 169185363103973376,
  "created_at" : "2012-02-13 22:26:19 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169185039526002691",
  "text" : "Oh dear, was ist die letzte Staffel der Highlander-Series mies.",
  "id" : 169185039526002691,
  "created_at" : "2012-02-13 22:23:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 3, 14 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/IbyvXwmP",
      "expanded_url" : "http:\/\/opensnp.org\/users\/278",
      "display_url" : "opensnp.org\/users\/278"
    } ]
  },
  "geo" : { },
  "id_str" : "169042975870029824",
  "text" : "RT @openSNPorg: If you are interested in ancestry: We've got a new user which is thought to be around 41,000 years old http:\/\/t.co\/IbyvXwmP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/IbyvXwmP",
        "expanded_url" : "http:\/\/opensnp.org\/users\/278",
        "display_url" : "opensnp.org\/users\/278"
      } ]
    },
    "geo" : { },
    "id_str" : "169042459232444419",
    "text" : "If you are interested in ancestry: We've got a new user which is thought to be around 41,000 years old http:\/\/t.co\/IbyvXwmP",
    "id" : 169042459232444419,
    "created_at" : "2012-02-13 12:57:17 +0000",
    "user" : {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "protected" : false,
      "id_str" : "380205172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735374825187909632\/wJEJW1zW_normal.jpg",
      "id" : 380205172,
      "verified" : false
    }
  },
  "id" : 169042975870029824,
  "created_at" : "2012-02-13 12:59:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cheatha",
      "screen_name" : "Cheatha",
      "indices" : [ 3, 11 ],
      "id_str" : "6712152",
      "id" : 6712152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/i0773xdY",
      "expanded_url" : "http:\/\/j.mp\/wdyYGz",
      "display_url" : "j.mp\/wdyYGz"
    } ]
  },
  "geo" : { },
  "id_str" : "169016421127438337",
  "text" : "RT @Cheatha: \u00BBPinguin treibt auf Eisscholle im Neckar\u00AB http:\/\/t.co\/i0773xdY Trolllevel: Batman",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 62 ],
        "url" : "http:\/\/t.co\/i0773xdY",
        "expanded_url" : "http:\/\/j.mp\/wdyYGz",
        "display_url" : "j.mp\/wdyYGz"
      } ]
    },
    "geo" : { },
    "id_str" : "169015198110322688",
    "text" : "\u00BBPinguin treibt auf Eisscholle im Neckar\u00AB http:\/\/t.co\/i0773xdY Trolllevel: Batman",
    "id" : 169015198110322688,
    "created_at" : "2012-02-13 11:08:58 +0000",
    "user" : {
      "name" : "Cheatha",
      "screen_name" : "Cheatha",
      "protected" : false,
      "id_str" : "6712152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709343020324360192\/dRbdttOX_normal.jpg",
      "id" : 6712152,
      "verified" : false
    }
  },
  "id" : 169016421127438337,
  "created_at" : "2012-02-13 11:13:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gunnar Lott",
      "screen_name" : "HerrKaliban",
      "indices" : [ 3, 15 ],
      "id_str" : "16945253",
      "id" : 16945253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/XS5n8fbz",
      "expanded_url" : "http:\/\/www.superlevel.de\/spielkram\/lehrgeld",
      "display_url" : "superlevel.de\/spielkram\/lehr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169007716491202560",
  "text" : "RT @HerrKaliban: Superlevel attackiert die Praktika-Praktiken von Gamersglobal: http:\/\/t.co\/XS5n8fbz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/XS5n8fbz",
        "expanded_url" : "http:\/\/www.superlevel.de\/spielkram\/lehrgeld",
        "display_url" : "superlevel.de\/spielkram\/lehr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "169007348889825280",
    "text" : "Superlevel attackiert die Praktika-Praktiken von Gamersglobal: http:\/\/t.co\/XS5n8fbz",
    "id" : 169007348889825280,
    "created_at" : "2012-02-13 10:37:46 +0000",
    "user" : {
      "name" : "Gunnar Lott",
      "screen_name" : "HerrKaliban",
      "protected" : false,
      "id_str" : "16945253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/888401398064459777\/FaKgniYG_normal.jpg",
      "id" : 16945253,
      "verified" : true
    }
  },
  "id" : 169007716491202560,
  "created_at" : "2012-02-13 10:39:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/Mfy1BfyO",
      "expanded_url" : "http:\/\/j.mp\/zFPBPW",
      "display_url" : "j.mp\/zFPBPW"
    } ]
  },
  "geo" : { },
  "id_str" : "168816343351701504",
  "text" : "SNPedia looks what the SNPs of the Denisova hominin genome can tell us http:\/\/t.co\/Mfy1BfyO",
  "id" : 168816343351701504,
  "created_at" : "2012-02-12 21:58:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/y3r56IBf",
      "expanded_url" : "http:\/\/j.mp\/Af2k9Y",
      "display_url" : "j.mp\/Af2k9Y"
    } ]
  },
  "geo" : { },
  "id_str" : "168815416062386176",
  "text" : "On introducing elephants to Australia... http:\/\/t.co\/y3r56IBf",
  "id" : 168815416062386176,
  "created_at" : "2012-02-12 21:55:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Elsevier",
      "screen_name" : "FakeElsevier",
      "indices" : [ 3, 16 ],
      "id_str" : "486169804",
      "id" : 486169804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/QoWFu7nK",
      "expanded_url" : "http:\/\/scholarlykitchen.sspnet.org\/2012\/02\/12\/revisiting-a-little-known-rwa-of-the-past-the-restaurant-welfare-act-of-1958\/",
      "display_url" : "scholarlykitchen.sspnet.org\/2012\/02\/12\/rev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "168811194214383616",
  "text" : "RT @FakeElsevier: All your produce are belong to us.  We add the REAL value.  Don't ever forget that. http:\/\/t.co\/QoWFu7nK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/QoWFu7nK",
        "expanded_url" : "http:\/\/scholarlykitchen.sspnet.org\/2012\/02\/12\/revisiting-a-little-known-rwa-of-the-past-the-restaurant-welfare-act-of-1958\/",
        "display_url" : "scholarlykitchen.sspnet.org\/2012\/02\/12\/rev\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "168776983956828160",
    "text" : "All your produce are belong to us.  We add the REAL value.  Don't ever forget that. http:\/\/t.co\/QoWFu7nK",
    "id" : 168776983956828160,
    "created_at" : "2012-02-12 19:22:23 +0000",
    "user" : {
      "name" : "Fake Elsevier",
      "screen_name" : "FakeElsevier",
      "protected" : false,
      "id_str" : "486169804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1812182734\/6799831691_84690009a5_normal.jpg",
      "id" : 486169804,
      "verified" : false
    }
  },
  "id" : 168811194214383616,
  "created_at" : "2012-02-12 21:38:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1150089138, 8.6793721761 ]
  },
  "id_str" : "168405872941346816",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 magst du n\u00E4chstes Wochenende auch zum Falafelessen kommen?",
  "id" : 168405872941346816,
  "created_at" : "2012-02-11 18:47:43 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "621716753",
      "id" : 621716753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168389780252524544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1148460447, 8.6769829521 ]
  },
  "id_str" : "168405378130907137",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale wir sind nu auch wieder weg aus dem CV",
  "id" : 168405378130907137,
  "in_reply_to_status_id" : 168389780252524544,
  "created_at" : "2012-02-11 18:45:45 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "621716753",
      "id" : 621716753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168389780252524544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1150779368, 8.6738312257 ]
  },
  "id_str" : "168390715670405120",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale okay, keine Ahnung wie lang wir noch hier sind. :)",
  "id" : 168390715670405120,
  "in_reply_to_status_id" : 168389780252524544,
  "created_at" : "2012-02-11 17:47:29 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "621716753",
      "id" : 621716753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1116711454, 8.6790945255 ]
  },
  "id_str" : "168383304662396929",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale Wo treibt ihr euch rum? :)",
  "id" : 168383304662396929,
  "created_at" : "2012-02-11 17:18:02 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/iAykfJES",
      "expanded_url" : "http:\/\/j.mp\/w1yl0g",
      "display_url" : "j.mp\/w1yl0g"
    } ]
  },
  "geo" : { },
  "id_str" : "168355556019535872",
  "text" : "Katholische Kirche darf \u201CKinderficker-Sekte\u201D genannt werden http:\/\/t.co\/iAykfJES",
  "id" : 168355556019535872,
  "created_at" : "2012-02-11 15:27:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antje Findeklee (Unkraut vergeht nicht)",
      "screen_name" : "tre_bol",
      "indices" : [ 0, 8 ],
      "id_str" : "80123679",
      "id" : 80123679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168345631474204673",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095462991, 8.2833469646 ]
  },
  "id_str" : "168345816354918401",
  "in_reply_to_user_id" : 80123679,
  "text" : "@tre_bol Wird er. Auf anraten des Tierarztes bekommt er nun 3 statt 2 Mahlzeiten ;)",
  "id" : 168345816354918401,
  "in_reply_to_status_id" : 168345631474204673,
  "created_at" : "2012-02-11 14:49:04 +0000",
  "in_reply_to_screen_name" : "tre_bol",
  "in_reply_to_user_id_str" : "80123679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antje Findeklee (Unkraut vergeht nicht)",
      "screen_name" : "tre_bol",
      "indices" : [ 0, 8 ],
      "id_str" : "80123679",
      "id" : 80123679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168342015900262400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097752269, 8.2831116049 ]
  },
  "id_str" : "168342199937933314",
  "in_reply_to_user_id" : 80123679,
  "text" : "@tre_bol ja, deshalb ist er wohl so hungrig. :)",
  "id" : 168342199937933314,
  "in_reply_to_status_id" : 168342015900262400,
  "created_at" : "2012-02-11 14:34:42 +0000",
  "in_reply_to_screen_name" : "tre_bol",
  "in_reply_to_user_id_str" : "80123679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antje Findeklee (Unkraut vergeht nicht)",
      "screen_name" : "tre_bol",
      "indices" : [ 0, 8 ],
      "id_str" : "80123679",
      "id" : 80123679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168340874114244608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009816743, 8.2830476973 ]
  },
  "id_str" : "168341553528578049",
  "in_reply_to_user_id" : 80123679,
  "text" : "@tre_bol das war nachdem er mir Puddingreste aus dem Bart geschleckt hat ;)",
  "id" : 168341553528578049,
  "in_reply_to_status_id" : 168340874114244608,
  "created_at" : "2012-02-11 14:32:08 +0000",
  "in_reply_to_screen_name" : "tre_bol",
  "in_reply_to_user_id_str" : "80123679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 36, 45 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/CBfkqloj",
      "expanded_url" : "http:\/\/instagr.am\/p\/G3mGBIhwiU\/",
      "display_url" : "instagr.am\/p\/G3mGBIhwiU\/"
    } ]
  },
  "geo" : { },
  "id_str" : "168340247694934016",
  "text" : "Ich glaube er will mich fressen \/cc @Senficon http:\/\/t.co\/CBfkqloj",
  "id" : 168340247694934016,
  "created_at" : "2012-02-11 14:26:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mendenhall",
      "screen_name" : "e__mendenhall",
      "indices" : [ 3, 17 ],
      "id_str" : "386521020",
      "id" : 386521020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PIsbeware",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/gWWBDrvY",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=FXaOqwanWnU",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "168331604131983361",
  "text" : "RT @e__mendenhall: Why are western blots always the one to be faked and caught? http:\/\/t.co\/gWWBDrvY #PIsbeware",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PIsbeware",
        "indices" : [ 82, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/gWWBDrvY",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=FXaOqwanWnU",
        "display_url" : "youtube.com\/watch?feature=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "167269773288288256",
    "text" : "Why are western blots always the one to be faked and caught? http:\/\/t.co\/gWWBDrvY #PIsbeware",
    "id" : 167269773288288256,
    "created_at" : "2012-02-08 15:33:16 +0000",
    "user" : {
      "name" : "Eric Mendenhall",
      "screen_name" : "e__mendenhall",
      "protected" : false,
      "id_str" : "386521020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419293065052819457\/6npbIFMv_normal.jpeg",
      "id" : 386521020,
      "verified" : false
    }
  },
  "id" : 168331604131983361,
  "created_at" : "2012-02-11 13:52:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/FxXyohOM",
      "expanded_url" : "http:\/\/instagr.am\/p\/G3c6IuBwgs\/",
      "display_url" : "instagr.am\/p\/G3c6IuBwgs\/"
    } ]
  },
  "geo" : { },
  "id_str" : "168320047855566848",
  "text" : "Vielen Dank f\u00FCr die gute Arbeit... http:\/\/t.co\/FxXyohOM",
  "id" : 168320047855566848,
  "created_at" : "2012-02-11 13:06:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168273258683174912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097441048, 8.2833309885 ]
  },
  "id_str" : "168273648766042112",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ ne, also keine Ahnung wo es ist. Zumindest nicht bei mir ;)",
  "id" : 168273648766042112,
  "in_reply_to_status_id" : 168273258683174912,
  "created_at" : "2012-02-11 10:02:18 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168272793740382209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.01151722, 8.28247034 ]
  },
  "id_str" : "168272920311894017",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ ist es das Gitarrenshirt?",
  "id" : 168272920311894017,
  "in_reply_to_status_id" : 168272793740382209,
  "created_at" : "2012-02-11 09:59:25 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/akBcLwk6",
      "expanded_url" : "http:\/\/j.mp\/wtZm2m",
      "display_url" : "j.mp\/wtZm2m"
    } ]
  },
  "geo" : { },
  "id_str" : "168270299903700992",
  "text" : "Sequencing My Exome: Why? http:\/\/t.co\/akBcLwk6",
  "id" : 168270299903700992,
  "created_at" : "2012-02-11 09:49:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IAmUninsured",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "IAmScience",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/8dj0iLHE",
      "expanded_url" : "http:\/\/j.mp\/z1ohCj",
      "display_url" : "j.mp\/z1ohCj"
    } ]
  },
  "geo" : { },
  "id_str" : "168269481334943745",
  "text" : "#IAmUninsured: An #IAmScience Story http:\/\/t.co\/8dj0iLHE",
  "id" : 168269481334943745,
  "created_at" : "2012-02-11 09:45:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168098974786519040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095363997, 8.2835658631 ]
  },
  "id_str" : "168099271307046912",
  "in_reply_to_user_id" : 30868098,
  "text" : "@davezerave it totally can be, but afaik not in the last ~200k years. :)",
  "id" : 168099271307046912,
  "in_reply_to_status_id" : 168098974786519040,
  "created_at" : "2012-02-10 22:29:24 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168096945053765632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097517272, 8.2832512557 ]
  },
  "id_str" : "168097612757598210",
  "in_reply_to_user_id" : 30868098,
  "text" : "@davezerave LOL, what an awesome \"source\" :P",
  "id" : 168097612757598210,
  "in_reply_to_status_id" : 168096945053765632,
  "created_at" : "2012-02-10 22:22:48 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACTA",
      "indices" : [ 31, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/Sx3rRGU7",
      "expanded_url" : "http:\/\/contracta.info\/?page_id=17",
      "display_url" : "contracta.info\/?page_id=17"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097920391, 8.283133143 ]
  },
  "id_str" : "168097275774644224",
  "text" : "Let us replace lawyer-readable #ACTA with a much nicer & human-readable alternative: http:\/\/t.co\/Sx3rRGU7",
  "id" : 168097275774644224,
  "created_at" : "2012-02-10 22:21:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/2ZzSBHna",
      "expanded_url" : "http:\/\/j.mp\/wdLjWt",
      "display_url" : "j.mp\/wdLjWt"
    } ]
  },
  "geo" : { },
  "id_str" : "168092568377241601",
  "text" : "Learn about Toxoplasma and How Your Cat Is Making You Crazy http:\/\/t.co\/2ZzSBHna",
  "id" : 168092568377241601,
  "created_at" : "2012-02-10 22:02:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168089184660230145",
  "geo" : { },
  "id_str" : "168090241368981505",
  "in_reply_to_user_id" : 30868098,
  "text" : "@davezerave iirc this desertification didn't take place throughout the whole sea, or did it?",
  "id" : 168090241368981505,
  "in_reply_to_status_id" : 168089184660230145,
  "created_at" : "2012-02-10 21:53:31 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "antiprodukt",
      "screen_name" : "antiprodukt",
      "indices" : [ 0, 12 ],
      "id_str" : "149089037",
      "id" : 149089037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168088626574536704",
  "geo" : { },
  "id_str" : "168089136513822720",
  "in_reply_to_user_id" : 149089037,
  "text" : "@antiprodukt So f\u00E4ngt es an. Und auf einmal wohnt man da fast...",
  "id" : 168089136513822720,
  "in_reply_to_status_id" : 168088626574536704,
  "created_at" : "2012-02-10 21:49:07 +0000",
  "in_reply_to_screen_name" : "antiprodukt",
  "in_reply_to_user_id_str" : "149089037",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/21T6RsOc",
      "expanded_url" : "http:\/\/j.mp\/yQtFKO",
      "display_url" : "j.mp\/yQtFKO"
    } ]
  },
  "geo" : { },
  "id_str" : "168089047753957376",
  "text" : "Domain knowledge is important for good design. Otherwise you might shoot yourself straight in the face. http:\/\/t.co\/21T6RsOc",
  "id" : 168089047753957376,
  "created_at" : "2012-02-10 21:48:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/4xg9lMv3",
      "expanded_url" : "http:\/\/j.mp\/xocgfY",
      "display_url" : "j.mp\/xocgfY"
    } ]
  },
  "geo" : { },
  "id_str" : "168088363079958528",
  "text" : "The oldest thing in the world http:\/\/t.co\/4xg9lMv3",
  "id" : 168088363079958528,
  "created_at" : "2012-02-10 21:46:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian",
      "screen_name" : "sebaso",
      "indices" : [ 0, 7 ],
      "id_str" : "10462602",
      "id" : 10462602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168070699112611840",
  "geo" : { },
  "id_str" : "168081634665566210",
  "in_reply_to_user_id" : 10462602,
  "text" : "@sebaso Wir haben das Thema Mainstream gemacht ;)",
  "id" : 168081634665566210,
  "in_reply_to_status_id" : 168070699112611840,
  "created_at" : "2012-02-10 21:19:19 +0000",
  "in_reply_to_screen_name" : "sebaso",
  "in_reply_to_user_id_str" : "10462602",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Udo Vetter",
      "screen_name" : "udovetter",
      "indices" : [ 3, 13 ],
      "id_str" : "15998669",
      "id" : 15998669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/b6UDHk2u",
      "expanded_url" : "http:\/\/youtu.be\/kl1ujzRidmU",
      "display_url" : "youtu.be\/kl1ujzRidmU"
    } ]
  },
  "geo" : { },
  "id_str" : "168081459540803586",
  "text" : "RT @udovetter: Vater erschie\u00DFt den Laptop seiner 15-j\u00E4hrigen Tochter.  Der Typ erkl\u00E4rt den Zustand Amerikas. http:\/\/t.co\/b6UDHk2u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/b6UDHk2u",
        "expanded_url" : "http:\/\/youtu.be\/kl1ujzRidmU",
        "display_url" : "youtu.be\/kl1ujzRidmU"
      } ]
    },
    "geo" : { },
    "id_str" : "168067456932384768",
    "text" : "Vater erschie\u00DFt den Laptop seiner 15-j\u00E4hrigen Tochter.  Der Typ erkl\u00E4rt den Zustand Amerikas. http:\/\/t.co\/b6UDHk2u",
    "id" : 168067456932384768,
    "created_at" : "2012-02-10 20:22:58 +0000",
    "user" : {
      "name" : "Udo Vetter",
      "screen_name" : "udovetter",
      "protected" : false,
      "id_str" : "15998669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/827083598071205888\/2Ola4msn_normal.jpg",
      "id" : 15998669,
      "verified" : true
    }
  },
  "id" : 168081459540803586,
  "created_at" : "2012-02-10 21:18:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "appendTo",
      "screen_name" : "appendTo",
      "indices" : [ 3, 12 ],
      "id_str" : "19742171",
      "id" : 19742171
    }, {
      "name" : "Elijah Manor",
      "screen_name" : "elijahmanor",
      "indices" : [ 17, 29 ],
      "id_str" : "9453872",
      "id" : 9453872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/Q4vZggoX",
      "expanded_url" : "http:\/\/j.mp\/wQGwi9",
      "display_url" : "j.mp\/wQGwi9"
    } ]
  },
  "geo" : { },
  "id_str" : "168061647922016256",
  "text" : "RT @appendTo: RT @elijahmanor: Nice chart of programming language popularity on GitHub by # of projects http:\/\/t.co\/Q4vZggoX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Elijah Manor",
        "screen_name" : "elijahmanor",
        "indices" : [ 3, 15 ],
        "id_str" : "9453872",
        "id" : 9453872
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/Q4vZggoX",
        "expanded_url" : "http:\/\/j.mp\/wQGwi9",
        "display_url" : "j.mp\/wQGwi9"
      } ]
    },
    "geo" : { },
    "id_str" : "167983956250202112",
    "text" : "RT @elijahmanor: Nice chart of programming language popularity on GitHub by # of projects http:\/\/t.co\/Q4vZggoX",
    "id" : 167983956250202112,
    "created_at" : "2012-02-10 14:51:10 +0000",
    "user" : {
      "name" : "appendTo",
      "screen_name" : "appendTo",
      "protected" : false,
      "id_str" : "19742171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497536789251244032\/mC6n_Y8E_normal.jpeg",
      "id" : 19742171,
      "verified" : false
    }
  },
  "id" : 168061647922016256,
  "created_at" : "2012-02-10 19:59:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "\u03BB",
      "screen_name" : "Lambda_",
      "indices" : [ 10, 18 ],
      "id_str" : "21659638",
      "id" : 21659638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168012571977322496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097433261, 8.283142945 ]
  },
  "id_str" : "168013350968623105",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Lambda_ zu gar keiner, einfach nur Suppe schnorren ;)",
  "id" : 168013350968623105,
  "in_reply_to_status_id" : 168012571977322496,
  "created_at" : "2012-02-10 16:47:59 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 21, 30 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 35, 43 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168011426735210496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097433261, 8.283142945 ]
  },
  "id_str" : "168012025123966976",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 ich glaube @Senficon und @insideX hatten da irgendwelche Pl\u00E4ne.",
  "id" : 168012025123966976,
  "in_reply_to_status_id" : 168011426735210496,
  "created_at" : "2012-02-10 16:42:42 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    }, {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 19, 31 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168010772323106820",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097528236, 8.2831857997 ]
  },
  "id_str" : "168010959443607553",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 wenn der @herr_schrat jetzt nicht kommt, dann komme ich danach auf ein bisschen Suppe nach Frankfurt.",
  "id" : 168010959443607553,
  "in_reply_to_status_id" : 168010772323106820,
  "created_at" : "2012-02-10 16:38:28 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168004827358568448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097378259, 8.2834433979 ]
  },
  "id_str" : "168010213511798787",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat ok, dann sag mal bescheid :)",
  "id" : 168010213511798787,
  "in_reply_to_status_id" : 168004827358568448,
  "created_at" : "2012-02-10 16:35:31 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168009224314564608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097691508, 8.2830648347 ]
  },
  "id_str" : "168010149871616000",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 denk nicht. Muss noch f\u00FCr eine Klausur lernen, komme also nicht zur Demo.",
  "id" : 168010149871616000,
  "in_reply_to_status_id" : 168009224314564608,
  "created_at" : "2012-02-10 16:35:15 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/OPYOB8Ha",
      "expanded_url" : "http:\/\/j.mp\/w0yn3D",
      "display_url" : "j.mp\/w0yn3D"
    } ]
  },
  "geo" : { },
  "id_str" : "168009736602660864",
  "text" : "Statistics Misuse: One Researcher's P-Curve Analysis http:\/\/t.co\/OPYOB8Ha",
  "id" : 168009736602660864,
  "created_at" : "2012-02-10 16:33:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167999257138315265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0118264289, 8.283478079 ]
  },
  "id_str" : "168004685586903041",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat schade!",
  "id" : 168004685586903041,
  "in_reply_to_status_id" : 167999257138315265,
  "created_at" : "2012-02-10 16:13:33 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/uLZ8rZFj",
      "expanded_url" : "http:\/\/www.awesome-robo.com\/2012\/02\/farewell-adam-adamowicz-visual-mind.html",
      "display_url" : "awesome-robo.com\/2012\/02\/farewe\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097533596, 8.2830831707 ]
  },
  "id_str" : "167985922741239808",
  "text" : "Noooo! :( http:\/\/t.co\/uLZ8rZFj",
  "id" : 167985922741239808,
  "created_at" : "2012-02-10 14:58:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Science",
      "screen_name" : "openscience",
      "indices" : [ 3, 15 ],
      "id_str" : "53560219",
      "id" : 53560219
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FRPAA",
      "indices" : [ 39, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167977941605679104",
  "text" : "RT @openscience: Let's make it happen. #FRPAA now introduced into both the US Senate and the House, with bipartisan support http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FRPAA",
        "indices" : [ 22, 28 ]
      }, {
        "text" : "openaccess",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/0opElMWm",
        "expanded_url" : "http:\/\/bit.ly\/xUGWcr",
        "display_url" : "bit.ly\/xUGWcr"
      } ]
    },
    "geo" : { },
    "id_str" : "167752670642323456",
    "text" : "Let's make it happen. #FRPAA now introduced into both the US Senate and the House, with bipartisan support http:\/\/t.co\/0opElMWm #openaccess!",
    "id" : 167752670642323456,
    "created_at" : "2012-02-09 23:32:08 +0000",
    "user" : {
      "name" : "Open Science",
      "screen_name" : "openscience",
      "protected" : false,
      "id_str" : "53560219",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459933268746317825\/wrEyqxhT_normal.png",
      "id" : 53560219,
      "verified" : false
    }
  },
  "id" : 167977941605679104,
  "created_at" : "2012-02-10 14:27:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Coyne",
      "screen_name" : "Evolutionistrue",
      "indices" : [ 3, 19 ],
      "id_str" : "127305588",
      "id" : 127305588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/jcPhX3YA",
      "expanded_url" : "http:\/\/wp.me\/ppUXF-esQ",
      "display_url" : "wp.me\/ppUXF-esQ"
    } ]
  },
  "geo" : { },
  "id_str" : "167967163066490880",
  "text" : "RT @Evolutionistrue: Proof of ceiling cat http:\/\/t.co\/jcPhX3YA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http:\/\/t.co\/jcPhX3YA",
        "expanded_url" : "http:\/\/wp.me\/ppUXF-esQ",
        "display_url" : "wp.me\/ppUXF-esQ"
      } ]
    },
    "geo" : { },
    "id_str" : "167966582407049216",
    "text" : "Proof of ceiling cat http:\/\/t.co\/jcPhX3YA",
    "id" : 167966582407049216,
    "created_at" : "2012-02-10 13:42:08 +0000",
    "user" : {
      "name" : "Jerry Coyne",
      "screen_name" : "Evolutionistrue",
      "protected" : false,
      "id_str" : "127305588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768814617837596673\/BIuC-_yL_normal.jpg",
      "id" : 127305588,
      "verified" : false
    }
  },
  "id" : 167967163066490880,
  "created_at" : "2012-02-10 13:44:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Daniel Lingenh\u00F6hl",
      "screen_name" : "lingenhoehl",
      "indices" : [ 11, 23 ],
      "id_str" : "202098194",
      "id" : 202098194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167965888182620161",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097686344, 8.2832536231 ]
  },
  "id_str" : "167966930400055296",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @lingenhoehl die F\u00FCsse werden ja schon von den Katzen gew\u00E4rmt ;)",
  "id" : 167966930400055296,
  "in_reply_to_status_id" : 167965888182620161,
  "created_at" : "2012-02-10 13:43:31 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167965263361347587",
  "geo" : { },
  "id_str" : "167965327676805121",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog ja, sonst muss ich bei dem Wetter ja zum Supermarkt ;)",
  "id" : 167965327676805121,
  "in_reply_to_status_id" : 167965263361347587,
  "created_at" : "2012-02-10 13:37:09 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167961134551412736",
  "geo" : { },
  "id_str" : "167965056661856256",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog tauschen wir?",
  "id" : 167965056661856256,
  "in_reply_to_status_id" : 167961134551412736,
  "created_at" : "2012-02-10 13:36:04 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/xi06pyFv",
      "expanded_url" : "http:\/\/j.mp\/y98Cms",
      "display_url" : "j.mp\/y98Cms"
    } ]
  },
  "geo" : { },
  "id_str" : "167947275300118528",
  "text" : "Horror Stories for Programmers http:\/\/t.co\/xi06pyFv",
  "id" : 167947275300118528,
  "created_at" : "2012-02-10 12:25:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/ugOtVDAb",
      "expanded_url" : "http:\/\/j.mp\/xEf35Y",
      "display_url" : "j.mp\/xEf35Y"
    } ]
  },
  "geo" : { },
  "id_str" : "167946323037913089",
  "text" : "Breathless: Murder-GIF-Montage http:\/\/t.co\/ugOtVDAb",
  "id" : 167946323037913089,
  "created_at" : "2012-02-10 12:21:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 3, 12 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167942708357373952",
  "text" : "RT @BobOHara: Wooo! My h-index is up to 19! An almost meaningless number has increased by 1.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167928092134871040",
    "text" : "Wooo! My h-index is up to 19! An almost meaningless number has increased by 1.",
    "id" : 167928092134871040,
    "created_at" : "2012-02-10 11:09:11 +0000",
    "user" : {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "protected" : false,
      "id_str" : "19146944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/624292977\/twitterProfilePhoto_normal.jpg",
      "id" : 19146944,
      "verified" : false
    }
  },
  "id" : 167942708357373952,
  "created_at" : "2012-02-10 12:07:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167912533708124160",
  "geo" : { },
  "id_str" : "167912815116566528",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon Ich ehrlich gesagt auch, fand ihn aber trotzdem interessant. Hab gerade eine \u00E4hnliche DTC-\"Offenbarung\" \u00FCber mal bloggen muss",
  "id" : 167912815116566528,
  "in_reply_to_status_id" : 167912533708124160,
  "created_at" : "2012-02-10 10:08:29 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167911999961964544",
  "geo" : { },
  "id_str" : "167912242224967680",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon Wie das mit so popkulturellen Anspielungen halt manchmal ist ;)",
  "id" : 167912242224967680,
  "in_reply_to_status_id" : 167911999961964544,
  "created_at" : "2012-02-10 10:06:12 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/qm3iqLXe",
      "expanded_url" : "http:\/\/blog.personalgenomes.org\/2012\/02\/08\/its-a-boy-or-how-i-learned-to-stop-worrying-and-love-direct-to-consumer-genomics",
      "display_url" : "blog.personalgenomes.org\/2012\/02\/08\/its\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095384686, 8.2830796894 ]
  },
  "id_str" : "167909917066412032",
  "text" : "How I Learned to Stop Worrying and Love Direct to Consumer Genomics http:\/\/t.co\/qm3iqLXe",
  "id" : 167909917066412032,
  "created_at" : "2012-02-10 09:56:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACTA",
      "indices" : [ 86, 91 ]
    }, {
      "text" : "followerpower",
      "indices" : [ 93, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167901839453470720",
  "text" : "RT @Senficon: Could a native speaker please help me proofread a short english text on #ACTA? #followerpower",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/launchpad.net\/polly\" rel=\"nofollow\"\u003EPolly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACTA",
        "indices" : [ 72, 77 ]
      }, {
        "text" : "followerpower",
        "indices" : [ 79, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167899087302176769",
    "text" : "Could a native speaker please help me proofread a short english text on #ACTA? #followerpower",
    "id" : 167899087302176769,
    "created_at" : "2012-02-10 09:13:56 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 167901839453470720,
  "created_at" : "2012-02-10 09:24:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167895710396710912",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Kommst du jetzt eigentlich am Samstag vorbei? :)",
  "id" : 167895710396710912,
  "created_at" : "2012-02-10 09:00:31 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Elsevier",
      "screen_name" : "FakeElsevier",
      "indices" : [ 3, 16 ],
      "id_str" : "486169804",
      "id" : 486169804
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FRPAA",
      "indices" : [ 52, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167894608557256704",
  "text" : "RT @FakeElsevier: Pls note that passage of reckless #FRPAA bill will ruin pub. industry, and we will be forced to harvest and sell puppy ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FRPAA",
        "indices" : [ 34, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167819981654994944",
    "text" : "Pls note that passage of reckless #FRPAA bill will ruin pub. industry, and we will be forced to harvest and sell puppy kidneys for profit.",
    "id" : 167819981654994944,
    "created_at" : "2012-02-10 03:59:36 +0000",
    "user" : {
      "name" : "Fake Elsevier",
      "screen_name" : "FakeElsevier",
      "protected" : false,
      "id_str" : "486169804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1812182734\/6799831691_84690009a5_normal.jpg",
      "id" : 486169804,
      "verified" : false
    }
  },
  "id" : 167894608557256704,
  "created_at" : "2012-02-10 08:56:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167876654193057792",
  "geo" : { },
  "id_str" : "167876692801617921",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer hehe, ok :D",
  "id" : 167876692801617921,
  "in_reply_to_status_id" : 167876654193057792,
  "created_at" : "2012-02-10 07:44:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167868764933726208",
  "geo" : { },
  "id_str" : "167876400659955712",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer the build is broken! :D",
  "id" : 167876400659955712,
  "in_reply_to_status_id" : 167868764933726208,
  "created_at" : "2012-02-10 07:43:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "N J Clarke",
      "screen_name" : "compay",
      "indices" : [ 36, 43 ],
      "id_str" : "9793782",
      "id" : 9793782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/aNVD6TUk",
      "expanded_url" : "http:\/\/love.travis-ci.org",
      "display_url" : "love.travis-ci.org"
    } ]
  },
  "geo" : { },
  "id_str" : "167754602408714240",
  "text" : "I totally agree. They are great! RT @compay: Travis CI is an awesome project. Very much worth using and supporting: http:\/\/t.co\/aNVD6TUk",
  "id" : 167754602408714240,
  "created_at" : "2012-02-09 23:39:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 3, 8 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/GMYnJ9R4",
      "expanded_url" : "http:\/\/techcrunch.com\/2012\/02\/09\/awwwwwwwwwwwwwwwwww\/",
      "display_url" : "techcrunch.com\/2012\/02\/09\/aww\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "167750036820738048",
  "text" : "RT @johl: Awwwwwwwwwwwwwwwwww! http:\/\/t.co\/GMYnJ9R4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http:\/\/t.co\/GMYnJ9R4",
        "expanded_url" : "http:\/\/techcrunch.com\/2012\/02\/09\/awwwwwwwwwwwwwwwwww\/",
        "display_url" : "techcrunch.com\/2012\/02\/09\/aww\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "167748260260352000",
    "text" : "Awwwwwwwwwwwwwwwwww! http:\/\/t.co\/GMYnJ9R4",
    "id" : 167748260260352000,
    "created_at" : "2012-02-09 23:14:36 +0000",
    "user" : {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "protected" : false,
      "id_str" : "1147751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/876909912185597952\/E61jm8M3_normal.jpg",
      "id" : 1147751,
      "verified" : false
    }
  },
  "id" : 167750036820738048,
  "created_at" : "2012-02-09 23:21:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/DPAC0h6R",
      "expanded_url" : "http:\/\/j.mp\/wqVmoh",
      "display_url" : "j.mp\/wqVmoh"
    } ]
  },
  "geo" : { },
  "id_str" : "167748806799142912",
  "text" : "How to name your lab computers (mine is PhiX174) http:\/\/t.co\/DPAC0h6R",
  "id" : 167748806799142912,
  "created_at" : "2012-02-09 23:16:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/dIwrigwC",
      "expanded_url" : "http:\/\/j.mp\/waoKb8",
      "display_url" : "j.mp\/waoKb8"
    } ]
  },
  "geo" : { },
  "id_str" : "167746125254758400",
  "text" : "New Nuclear Reactors Approved http:\/\/t.co\/dIwrigwC",
  "id" : 167746125254758400,
  "created_at" : "2012-02-09 23:06:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Muffin",
      "screen_name" : "SvenueMordue",
      "indices" : [ 0, 13 ],
      "id_str" : "52464907",
      "id" : 52464907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167690017915944961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0106344105, 8.2827648033 ]
  },
  "id_str" : "167690305464840192",
  "in_reply_to_user_id" : 52464907,
  "text" : "@SvenueMordue viel Gl\u00FCck!",
  "id" : 167690305464840192,
  "in_reply_to_status_id" : 167690017915944961,
  "created_at" : "2012-02-09 19:24:19 +0000",
  "in_reply_to_screen_name" : "SvenueMordue",
  "in_reply_to_user_id_str" : "52464907",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096959442, 8.2830911466 ]
  },
  "id_str" : "167684154106974208",
  "text" : "Festnetz-Telefon angeschlossen. Achievement \u00ABDude, it's 2012\u00BB unlocked.",
  "id" : 167684154106974208,
  "created_at" : "2012-02-09 18:59:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167651057982386176",
  "text" : "Kennt sich wer mit Biopsie-Tumordiagnostik bei Prostatakrebs aus?",
  "id" : 167651057982386176,
  "created_at" : "2012-02-09 16:48:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Stevenson",
      "screen_name" : "Optimistontour",
      "indices" : [ 3, 18 ],
      "id_str" : "45839847",
      "id" : 45839847
    }, {
      "name" : "Caroline Smith",
      "screen_name" : "caroliney76",
      "indices" : [ 23, 35 ],
      "id_str" : "30453386",
      "id" : 30453386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/NTAqrmng",
      "expanded_url" : "http:\/\/ht.ly\/8XSOl",
      "display_url" : "ht.ly\/8XSOl"
    } ]
  },
  "geo" : { },
  "id_str" : "167641694773321728",
  "text" : "RT @Optimistontour: RT @caroliney76: It's National Sweater Day! Don a hand-knitted jumper,  http:\/\/t.co\/NTAqrmng &lt;- I'm wearing mine! ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Caroline Smith",
        "screen_name" : "caroliney76",
        "indices" : [ 3, 15 ],
        "id_str" : "30453386",
        "id" : 30453386
      }, {
        "name" : "Caroline Smith",
        "screen_name" : "caroliney76",
        "indices" : [ 126, 138 ],
        "id_str" : "30453386",
        "id" : 30453386
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 140, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/NTAqrmng",
        "expanded_url" : "http:\/\/ht.ly\/8XSOl",
        "display_url" : "ht.ly\/8XSOl"
      } ]
    },
    "geo" : { },
    "id_str" : "167641061798322177",
    "text" : "RT @caroliney76: It's National Sweater Day! Don a hand-knitted jumper,  http:\/\/t.co\/NTAqrmng &lt;- I'm wearing mine! (made by @caroliney76) #fb",
    "id" : 167641061798322177,
    "created_at" : "2012-02-09 16:08:38 +0000",
    "user" : {
      "name" : "Mark Stevenson",
      "screen_name" : "Optimistontour",
      "protected" : false,
      "id_str" : "45839847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1787141292\/Me_2012_normal.jpg",
      "id" : 45839847,
      "verified" : false
    }
  },
  "id" : 167641694773321728,
  "created_at" : "2012-02-09 16:11:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/kvSvydvx",
      "expanded_url" : "http:\/\/instagr.am\/p\/GynUPwhwi4\/",
      "display_url" : "instagr.am\/p\/GynUPwhwi4\/"
    } ]
  },
  "geo" : { },
  "id_str" : "167639296604520449",
  "text" : "Ein passendes Fanboy-iPad-Cover ist angekommen  http:\/\/t.co\/kvSvydvx",
  "id" : 167639296604520449,
  "created_at" : "2012-02-09 16:01:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chai Guy",
      "screen_name" : "yaccin",
      "indices" : [ 0, 7 ],
      "id_str" : "23505101",
      "id" : 23505101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167626543730933760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0115171534, 8.282470369 ]
  },
  "id_str" : "167627812239441920",
  "in_reply_to_user_id" : 23505101,
  "text" : "@yaccin gern doch :)",
  "id" : 167627812239441920,
  "in_reply_to_status_id" : 167626543730933760,
  "created_at" : "2012-02-09 15:15:59 +0000",
  "in_reply_to_screen_name" : "yaccin",
  "in_reply_to_user_id_str" : "23505101",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chai Guy",
      "screen_name" : "yaccin",
      "indices" : [ 0, 7 ],
      "id_str" : "23505101",
      "id" : 23505101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167615914706075648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097299803, 8.2833476145 ]
  },
  "id_str" : "167624791635935232",
  "in_reply_to_user_id" : 23505101,
  "text" : "@yaccin okay, dann mach ich mir die M\u00FChe nicht ;)",
  "id" : 167624791635935232,
  "in_reply_to_status_id" : 167615914706075648,
  "created_at" : "2012-02-09 15:03:59 +0000",
  "in_reply_to_screen_name" : "yaccin",
  "in_reply_to_user_id_str" : "23505101",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chai Guy",
      "screen_name" : "yaccin",
      "indices" : [ 0, 7 ],
      "id_str" : "23505101",
      "id" : 23505101
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 44, 53 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167615446927949825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0984261913, 8.5276941285 ]
  },
  "id_str" : "167615695910223872",
  "in_reply_to_user_id" : 23505101,
  "text" : "@yaccin kann es aber auch mal am einser von @Senficon testen wenn das hilft.",
  "id" : 167615695910223872,
  "in_reply_to_status_id" : 167615446927949825,
  "created_at" : "2012-02-09 14:27:50 +0000",
  "in_reply_to_screen_name" : "yaccin",
  "in_reply_to_user_id_str" : "23505101",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chai Guy",
      "screen_name" : "yaccin",
      "indices" : [ 0, 7 ],
      "id_str" : "23505101",
      "id" : 23505101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167615446927949825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0984294921, 8.5294922523 ]
  },
  "id_str" : "167615537151606785",
  "in_reply_to_user_id" : 23505101,
  "text" : "@yaccin das 2er.",
  "id" : 167615537151606785,
  "in_reply_to_status_id" : 167615446927949825,
  "created_at" : "2012-02-09 14:27:12 +0000",
  "in_reply_to_screen_name" : "yaccin",
  "in_reply_to_user_id_str" : "23505101",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chai Guy",
      "screen_name" : "yaccin",
      "indices" : [ 0, 7 ],
      "id_str" : "23505101",
      "id" : 23505101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167615157239951361",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1059468139, 8.5445691146 ]
  },
  "id_str" : "167615341336330242",
  "in_reply_to_user_id" : 23505101,
  "text" : "@yaccin mh ne, das ist mir nicht aufgefallen.",
  "id" : 167615341336330242,
  "in_reply_to_status_id" : 167615157239951361,
  "created_at" : "2012-02-09 14:26:26 +0000",
  "in_reply_to_screen_name" : "yaccin",
  "in_reply_to_user_id_str" : "23505101",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chai Guy",
      "screen_name" : "yaccin",
      "indices" : [ 0, 7 ],
      "id_str" : "23505101",
      "id" : 23505101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167614772450308096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1036220577, 8.5491403177 ]
  },
  "id_str" : "167614951744212992",
  "in_reply_to_user_id" : 23505101,
  "text" : "@yaccin jap. Funktioniert gut zum schreiben von l\u00E4ngeren Texten.",
  "id" : 167614951744212992,
  "in_reply_to_status_id" : 167614772450308096,
  "created_at" : "2012-02-09 14:24:53 +0000",
  "in_reply_to_screen_name" : "yaccin",
  "in_reply_to_user_id_str" : "23505101",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 7, 16 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167614417511526401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1036690128, 8.5501450918 ]
  },
  "id_str" : "167614777160503296",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ @Senficon mal abgesehen davon wie sinnvoll das Ding im ernstfall ist wenn er es andauernd verliert ;)",
  "id" : 167614777160503296,
  "in_reply_to_status_id" : 167614417511526401,
  "created_at" : "2012-02-09 14:24:11 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 7, 16 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167614417511526401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.105731383, 8.5528958229 ]
  },
  "id_str" : "167614636508708865",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ @Senficon ja, aber ich will auch nicht jeden 2. tag den abgefallenen Tracker suchen m\u00FCssen.",
  "id" : 167614636508708865,
  "in_reply_to_status_id" : 167614417511526401,
  "created_at" : "2012-02-09 14:23:38 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 7, 16 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167613241286078465",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.104148084, 8.5684207479 ]
  },
  "id_str" : "167614040133206016",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ @Senficon da ist die Frage wie oft der Kater das Ding verliert und man einen neuen Tracker braucht ;)",
  "id" : 167614040133206016,
  "in_reply_to_status_id" : 167613241286078465,
  "created_at" : "2012-02-09 14:21:15 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167610990060511232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1173619759, 8.6674087209 ]
  },
  "id_str" : "167611172940562433",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon okay :)",
  "id" : 167611172940562433,
  "in_reply_to_status_id" : 167610990060511232,
  "created_at" : "2012-02-09 14:09:52 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 7, 16 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167606882868002817",
  "geo" : { },
  "id_str" : "167609308283027456",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ @Senficon hast du ihn schon aus den Datenbanken zwecks neuem Prior entfernen lassen?",
  "id" : 167609308283027456,
  "in_reply_to_status_id" : 167606882868002817,
  "created_at" : "2012-02-09 14:02:27 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 44, 53 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1169711378, 8.6674785211 ]
  },
  "id_str" : "167608222319001600",
  "text" : "Die Statistik l\u00FCgt halt nicht! p&lt;0.05 RT @Senficon: OMFG der Kater ist wieder da! \\o\/",
  "id" : 167608222319001600,
  "created_at" : "2012-02-09 13:58:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167608064252444672",
  "text" : "RT @Senficon: OMFG der Kater ist wieder da! \\o\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167605866772692992",
    "text" : "OMFG der Kater ist wieder da! \\o\/",
    "id" : 167605866772692992,
    "created_at" : "2012-02-09 13:48:47 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 167608064252444672,
  "created_at" : "2012-02-09 13:57:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/vl536DyS",
      "expanded_url" : "http:\/\/j.mp\/wc7dr9",
      "display_url" : "j.mp\/wc7dr9"
    } ]
  },
  "geo" : { },
  "id_str" : "167530299071266816",
  "text" : "Friends with (Food) Benefits http:\/\/t.co\/vl536DyS",
  "id" : 167530299071266816,
  "created_at" : "2012-02-09 08:48:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167391527809728512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097082198, 8.2830795132 ]
  },
  "id_str" : "167391780768190464",
  "in_reply_to_user_id" : 30868098,
  "text" : "@davezerave okay, I'll find the time to answer the stuff around noon tomorrow. :)",
  "id" : 167391780768190464,
  "in_reply_to_status_id" : 167391527809728512,
  "created_at" : "2012-02-08 23:38:05 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 70, 83 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167390532014850048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097386373, 8.2830001155 ]
  },
  "id_str" : "167390893656129536",
  "in_reply_to_user_id" : 30868098,
  "text" : "@davezerave send me an email to bgreshake@googlemail.com and maybe cc @PhilippBayer as I will go to bed now, so maybe he will answer faster",
  "id" : 167390893656129536,
  "in_reply_to_status_id" : 167390532014850048,
  "created_at" : "2012-02-08 23:34:33 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167384945961082881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.01151722, 8.28247034 ]
  },
  "id_str" : "167389987254452225",
  "in_reply_to_user_id" : 30868098,
  "text" : "@davezerave maybe I can also be of any help? ;)",
  "id" : 167389987254452225,
  "in_reply_to_status_id" : 167384945961082881,
  "created_at" : "2012-02-08 23:30:57 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Kasper",
      "screen_name" : "A_Kasper",
      "indices" : [ 0, 9 ],
      "id_str" : "51425853",
      "id" : 51425853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167385281211793408",
  "geo" : { },
  "id_str" : "167385498724220928",
  "in_reply_to_user_id" : 51425853,
  "text" : "@A_Kasper ne, das wurd eingestellt.",
  "id" : 167385498724220928,
  "in_reply_to_status_id" : 167385281211793408,
  "created_at" : "2012-02-08 23:13:07 +0000",
  "in_reply_to_screen_name" : "A_Kasper",
  "in_reply_to_user_id_str" : "51425853",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Haflinger",
      "screen_name" : "Nick_Haflinger",
      "indices" : [ 0, 15 ],
      "id_str" : "94528608",
      "id" : 94528608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167370172414427137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097289359, 8.2829683849 ]
  },
  "id_str" : "167370413045846016",
  "in_reply_to_user_id" : 94528608,
  "text" : "@Nick_Haflinger Season 06, Episode 09 m\u00FCsste das sein ;)",
  "id" : 167370413045846016,
  "in_reply_to_status_id" : 167370172414427137,
  "created_at" : "2012-02-08 22:13:10 +0000",
  "in_reply_to_screen_name" : "Nick_Haflinger",
  "in_reply_to_user_id_str" : "94528608",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167369525757612032",
  "text" : "Highlander!",
  "id" : 167369525757612032,
  "created_at" : "2012-02-08 22:09:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167363503496245249",
  "geo" : { },
  "id_str" : "167364836412493825",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn okay :)",
  "id" : 167364836412493825,
  "in_reply_to_status_id" : 167363503496245249,
  "created_at" : "2012-02-08 21:51:01 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167354203671511041",
  "geo" : { },
  "id_str" : "167360477805027329",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn haha, sure. You found my Skype-ID-mail? ;)",
  "id" : 167360477805027329,
  "in_reply_to_status_id" : 167354203671511041,
  "created_at" : "2012-02-08 21:33:41 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas",
      "screen_name" : "AndreasSchepers",
      "indices" : [ 0, 16 ],
      "id_str" : "12321512",
      "id" : 12321512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/IlfLysiy",
      "expanded_url" : "http:\/\/www.beyondweird.com\/ufos\/branton_the_omega_file_part_2_nazi_bases_in_antarctica.html",
      "display_url" : "beyondweird.com\/ufos\/branton_t\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "167294775454744576",
  "geo" : { },
  "id_str" : "167300533382688768",
  "in_reply_to_user_id" : 12321512,
  "text" : "@AndreasSchepers deshalb: http:\/\/t.co\/IlfLysiy :)",
  "id" : 167300533382688768,
  "in_reply_to_status_id" : 167294775454744576,
  "created_at" : "2012-02-08 17:35:30 +0000",
  "in_reply_to_screen_name" : "AndreasSchepers",
  "in_reply_to_user_id_str" : "12321512",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/DEKjoFtc",
      "expanded_url" : "http:\/\/j.mp\/z7Kar6",
      "display_url" : "j.mp\/z7Kar6"
    } ]
  },
  "geo" : { },
  "id_str" : "167300343779176448",
  "text" : "Piltdown Man: British Archaeology's Greatest Hoax http:\/\/t.co\/DEKjoFtc",
  "id" : 167300343779176448,
  "created_at" : "2012-02-08 17:34:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/tdHwK5Dv",
      "expanded_url" : "http:\/\/j.mp\/wz9j1h",
      "display_url" : "j.mp\/wz9j1h"
    } ]
  },
  "geo" : { },
  "id_str" : "167293208118833153",
  "text" : "Lake Vostok drilling success confirmed. Nazi conspiracies in 3...2...1... http:\/\/t.co\/tdHwK5Dv",
  "id" : 167293208118833153,
  "created_at" : "2012-02-08 17:06:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/QMLwDnDw",
      "expanded_url" : "http:\/\/j.mp\/xdpbw1",
      "display_url" : "j.mp\/xdpbw1"
    } ]
  },
  "geo" : { },
  "id_str" : "167292306842583040",
  "text" : "Map-Nerd Fan Fiction http:\/\/t.co\/QMLwDnDw",
  "id" : 167292306842583040,
  "created_at" : "2012-02-08 17:02:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis Leary",
      "screen_name" : "denisleary",
      "indices" : [ 3, 14 ],
      "id_str" : "131351549",
      "id" : 131351549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167287290832498688",
  "text" : "RT @denisleary: Elenn Degeneres-hating anti-gay group OneMillionMoms.com only has 40,000 members.  Which proves that bigots are really b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167285779947724800",
    "text" : "Elenn Degeneres-hating anti-gay group OneMillionMoms.com only has 40,000 members.  Which proves that bigots are really bad at math.",
    "id" : 167285779947724800,
    "created_at" : "2012-02-08 16:36:52 +0000",
    "user" : {
      "name" : "Denis Leary",
      "screen_name" : "denisleary",
      "protected" : false,
      "id_str" : "131351549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/845878709\/denis_dress2_normal.jpg",
      "id" : 131351549,
      "verified" : true
    }
  },
  "id" : 167287290832498688,
  "created_at" : "2012-02-08 16:42:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viktor S. Poor",
      "screen_name" : "strippedscience",
      "indices" : [ 0, 16 ],
      "id_str" : "211298903",
      "id" : 211298903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167285991386791940",
  "geo" : { },
  "id_str" : "167286358061236224",
  "in_reply_to_user_id" : 211298903,
  "text" : "@strippedscience where can i order one? ;)",
  "id" : 167286358061236224,
  "in_reply_to_status_id" : 167285991386791940,
  "created_at" : "2012-02-08 16:39:10 +0000",
  "in_reply_to_screen_name" : "strippedscience",
  "in_reply_to_user_id_str" : "211298903",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew A. Farke",
      "screen_name" : "AndyFarke",
      "indices" : [ 3, 13 ],
      "id_str" : "104068477",
      "id" : 104068477
    }, {
      "name" : "FakePLoS",
      "screen_name" : "FakePLoS",
      "indices" : [ 74, 83 ],
      "id_str" : "486404205",
      "id" : 486404205
    }, {
      "name" : "Fake Elsevier",
      "screen_name" : "FakeElsevier",
      "indices" : [ 84, 97 ],
      "id_str" : "486169804",
      "id" : 486169804
    }, {
      "name" : "Real Elsevier",
      "screen_name" : "RealElsevier",
      "indices" : [ 98, 111 ],
      "id_str" : "486433833",
      "id" : 486433833
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenAccess",
      "indices" : [ 39, 50 ]
    }, {
      "text" : "RWA",
      "indices" : [ 51, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167285859413008385",
  "text" : "RT @andyfarke: For those interested in #OpenAccess #RWA etc., must follow @FakePLoS @FakeElsevier @RealElsevier It will add real value t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/hotot.org\" rel=\"nofollow\"\u003EHotot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FakePLoS",
        "screen_name" : "FakePLoS",
        "indices" : [ 59, 68 ],
        "id_str" : "486404205",
        "id" : 486404205
      }, {
        "name" : "Fake Elsevier",
        "screen_name" : "FakeElsevier",
        "indices" : [ 69, 82 ],
        "id_str" : "486169804",
        "id" : 486169804
      }, {
        "name" : "Real Elsevier",
        "screen_name" : "RealElsevier",
        "indices" : [ 83, 96 ],
        "id_str" : "486433833",
        "id" : 486433833
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenAccess",
        "indices" : [ 24, 35 ]
      }, {
        "text" : "RWA",
        "indices" : [ 36, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167280262441484288",
    "text" : "For those interested in #OpenAccess #RWA etc., must follow @FakePLoS @FakeElsevier @RealElsevier It will add real value to your day.",
    "id" : 167280262441484288,
    "created_at" : "2012-02-08 16:14:57 +0000",
    "user" : {
      "name" : "Andrew A. Farke",
      "screen_name" : "AndyFarke",
      "protected" : false,
      "id_str" : "104068477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1268991571\/farke_normal.jpg",
      "id" : 104068477,
      "verified" : false
    }
  },
  "id" : 167285859413008385,
  "created_at" : "2012-02-08 16:37:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/167269871414030336\/photo\/1",
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/e35yKPwo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AlJDD9OCMAMfkbn.jpg",
      "id_str" : "167269871418224643",
      "id" : 167269871418224643,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlJDD9OCMAMfkbn.jpg",
      "sizes" : [ {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 484
      } ],
      "display_url" : "pic.twitter.com\/e35yKPwo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.125563, 8.658347 ]
  },
  "id_str" : "167269871414030336",
  "text" : "Erkl\u00E4rungsversuch scheitert. http:\/\/t.co\/e35yKPwo",
  "id" : 167269871414030336,
  "created_at" : "2012-02-08 15:33:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/8wGJCwES",
      "expanded_url" : "http:\/\/j.mp\/wgYX9E",
      "display_url" : "j.mp\/wgYX9E"
    } ]
  },
  "geo" : { },
  "id_str" : "167257378880880640",
  "text" : "English plainclothes police officer follows himself for 20 minutes http:\/\/t.co\/8wGJCwES",
  "id" : 167257378880880640,
  "created_at" : "2012-02-08 14:44:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167241561506185216",
  "geo" : { },
  "id_str" : "167248405511409664",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall jo, bei 23andMe und es waren glaube ich 108 (Subscription 12 Monate a 9 USD) USD + 65 USD Shipping.",
  "id" : 167248405511409664,
  "in_reply_to_status_id" : 167241561506185216,
  "created_at" : "2012-02-08 14:08:21 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spackeria",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/wwELPmFH",
      "expanded_url" : "http:\/\/www.etsy.com\/listing\/70774240\/set-of-5-statistics-propaganda-posters",
      "display_url" : "etsy.com\/listing\/707742\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "167215969431846912",
  "text" : "Kann mich mal jemand \u00FCber Geb\u00FChr flattern? Ich br\u00E4uchte neue Poster: http:\/\/t.co\/wwELPmFH \/Link via #spackeria",
  "id" : 167215969431846912,
  "created_at" : "2012-02-08 11:59:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167212284366700544",
  "geo" : { },
  "id_str" : "167212360438779904",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX Ist alles eine Frage der Arbeitsdisziplin w\u00FCrde ich sagen. ;)",
  "id" : 167212360438779904,
  "in_reply_to_status_id" : 167212284366700544,
  "created_at" : "2012-02-08 11:45:08 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167210045048758272",
  "geo" : { },
  "id_str" : "167210201550819329",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX Mimimi, 5 Wochen reichen ja wohl um so ein Ding zu schreiben.",
  "id" : 167210201550819329,
  "in_reply_to_status_id" : 167210045048758272,
  "created_at" : "2012-02-08 11:36:33 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/p2f8SZVI",
      "expanded_url" : "http:\/\/www.engage-project.eu\/engage\/wp\/?page_id=193",
      "display_url" : "engage-project.eu\/engage\/wp\/?pag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "167208579357622272",
  "text" : "If you are working on Open Data this EU funded project might be of interest: http:\/\/t.co\/p2f8SZVI",
  "id" : 167208579357622272,
  "created_at" : "2012-02-08 11:30:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167197292628156416",
  "geo" : { },
  "id_str" : "167201486298816512",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Bekommst gleich Post.",
  "id" : 167201486298816512,
  "in_reply_to_status_id" : 167197292628156416,
  "created_at" : "2012-02-08 11:01:55 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iA Inc.",
      "screen_name" : "iA",
      "indices" : [ 3, 6 ],
      "id_str" : "2087371",
      "id" : 2087371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167009003711373313",
  "text" : "RT @iA: Tech hipsters turn against the hottest boy on the schoolyard after finding out that he used his looks to get into girls' pants.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "path",
        "indices" : [ 128, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166989034504200192",
    "text" : "Tech hipsters turn against the hottest boy on the schoolyard after finding out that he used his looks to get into girls' pants. #path",
    "id" : 166989034504200192,
    "created_at" : "2012-02-07 20:57:42 +0000",
    "user" : {
      "name" : "iA Inc.",
      "screen_name" : "iA",
      "protected" : false,
      "id_str" : "2087371",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/612988926047985664\/TvJw7c-B_normal.jpg",
      "id" : 2087371,
      "verified" : true
    }
  },
  "id" : 167009003711373313,
  "created_at" : "2012-02-07 22:17:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spackeria",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/wPbOiDcW",
      "expanded_url" : "http:\/\/www.genomicslawreport.com\/index.php\/2012\/02\/06\/big-changes-coming-in-eu-privacy-law\/",
      "display_url" : "genomicslawreport.com\/index.php\/2012\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166997414929104896",
  "text" : "Big Changes Coming in EU Privacy Law http:\/\/t.co\/wPbOiDcW #spackeria",
  "id" : 166997414929104896,
  "created_at" : "2012-02-07 21:31:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/DpNcv8CM",
      "expanded_url" : "http:\/\/j.mp\/zYsRQj",
      "display_url" : "j.mp\/zYsRQj"
    } ]
  },
  "geo" : { },
  "id_str" : "166969215918682112",
  "text" : "A Case Study: Exome Sequencing in Diagnostics http:\/\/t.co\/DpNcv8CM",
  "id" : 166969215918682112,
  "created_at" : "2012-02-07 19:38:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Sever",
      "screen_name" : "cshperspectives",
      "indices" : [ 3, 19 ],
      "id_str" : "21242028",
      "id" : 21242028
    }, {
      "name" : "Matthew Hirschey",
      "screen_name" : "hirscheylab",
      "indices" : [ 72, 84 ],
      "id_str" : "15448732",
      "id" : 15448732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/Ywn0BaRy",
      "expanded_url" : "http:\/\/bit.ly\/zGTfQZ",
      "display_url" : "bit.ly\/zGTfQZ"
    } ]
  },
  "geo" : { },
  "id_str" : "166967482270224384",
  "text" : "RT @cshperspectives: How to give a chalk talk http:\/\/t.co\/Ywn0BaRy (via @hirscheylab)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthew Hirschey",
        "screen_name" : "hirscheylab",
        "indices" : [ 51, 63 ],
        "id_str" : "15448732",
        "id" : 15448732
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/Ywn0BaRy",
        "expanded_url" : "http:\/\/bit.ly\/zGTfQZ",
        "display_url" : "bit.ly\/zGTfQZ"
      } ]
    },
    "geo" : { },
    "id_str" : "166966617232777216",
    "text" : "How to give a chalk talk http:\/\/t.co\/Ywn0BaRy (via @hirscheylab)",
    "id" : 166966617232777216,
    "created_at" : "2012-02-07 19:28:38 +0000",
    "user" : {
      "name" : "Richard Sever",
      "screen_name" : "cshperspectives",
      "protected" : false,
      "id_str" : "21242028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628105717\/a5918a036506247b9140e0b2ed543234_normal.png",
      "id" : 21242028,
      "verified" : false
    }
  },
  "id" : 166967482270224384,
  "created_at" : "2012-02-07 19:32:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/CFJp6T6R",
      "expanded_url" : "http:\/\/j.mp\/wpVOp2",
      "display_url" : "j.mp\/wpVOp2"
    } ]
  },
  "geo" : { },
  "id_str" : "166966501117661184",
  "text" : "Ocean Acidification: Damselfish exposed to elevated CO2 failed to learn to respond appropriately to a common predator http:\/\/t.co\/CFJp6T6R",
  "id" : 166966501117661184,
  "created_at" : "2012-02-07 19:28:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/sdD9VXxg",
      "expanded_url" : "http:\/\/j.mp\/y3EyMR",
      "display_url" : "j.mp\/y3EyMR"
    } ]
  },
  "geo" : { },
  "id_str" : "166964961011183618",
  "text" : "Ready for the Zombie Apocalypse? http:\/\/t.co\/sdD9VXxg",
  "id" : 166964961011183618,
  "created_at" : "2012-02-07 19:22:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fasel",
      "screen_name" : "fasel",
      "indices" : [ 0, 6 ],
      "id_str" : "21739255",
      "id" : 21739255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166916641219809281",
  "geo" : { },
  "id_str" : "166916793665986560",
  "in_reply_to_user_id" : 21739255,
  "text" : "@fasel Ne, du siehst wo meine Variationen liegen. Alle anderen Tracks sind andere Annotationen zum Referenzgenom.",
  "id" : 166916793665986560,
  "in_reply_to_status_id" : 166916641219809281,
  "created_at" : "2012-02-07 16:10:39 +0000",
  "in_reply_to_screen_name" : "fasel",
  "in_reply_to_user_id_str" : "21739255",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fasel",
      "screen_name" : "fasel",
      "indices" : [ 0, 6 ],
      "id_str" : "21739255",
      "id" : 21739255
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/166916102268518401\/photo\/1",
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/oSnwnLFh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AlEBT4dCAAAE-Z5.png",
      "id_str" : "166916102272712704",
      "id" : 166916102272712704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AlEBT4dCAAAE-Z5.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 1348
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 1348
      }, {
        "h" : 1013,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/oSnwnLFh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166914898599747584",
  "geo" : { },
  "id_str" : "166916102268518401",
  "in_reply_to_user_id" : 21739255,
  "text" : "@fasel Meh, dann hier: http:\/\/t.co\/oSnwnLFh",
  "id" : 166916102268518401,
  "in_reply_to_status_id" : 166914898599747584,
  "created_at" : "2012-02-07 16:07:58 +0000",
  "in_reply_to_screen_name" : "fasel",
  "in_reply_to_user_id_str" : "21739255",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 33, 46 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/mf6MkQ4a",
      "expanded_url" : "http:\/\/lockerz.com\/s\/181575740",
      "display_url" : "lockerz.com\/s\/181575740"
    } ]
  },
  "geo" : { },
  "id_str" : "166912205294534656",
  "text" : "Great, the first DAS-stuff which @PhilippBayer and I are working on can already be used in MyKaryoView! http:\/\/t.co\/mf6MkQ4a",
  "id" : 166912205294534656,
  "created_at" : "2012-02-07 15:52:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universit\u00E4t M\u00FCnster",
      "screen_name" : "WWU_Muenster",
      "indices" : [ 13, 26 ],
      "id_str" : "24677217",
      "id" : 24677217
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 59, 70 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/24WaiZ5J",
      "expanded_url" : "http:\/\/lockerz.com\/s\/181569504",
      "display_url" : "lockerz.com\/s\/181569504"
    } ]
  },
  "geo" : { },
  "id_str" : "166905405472112640",
  "text" : "Danke an die @WWU_Muenster. Die Ausgabe der Unizeitung mit @openSNPorg auf der Titelseite ist angekommen.  http:\/\/t.co\/24WaiZ5J",
  "id" : 166905405472112640,
  "created_at" : "2012-02-07 15:25:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/LGm7dzR1",
      "expanded_url" : "http:\/\/j.mp\/Az7H2V",
      "display_url" : "j.mp\/Az7H2V"
    } ]
  },
  "geo" : { },
  "id_str" : "166872165650665476",
  "text" : "In Tune with Nature http:\/\/t.co\/LGm7dzR1",
  "id" : 166872165650665476,
  "created_at" : "2012-02-07 13:13:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "indices" : [ 3, 18 ],
      "id_str" : "18655567",
      "id" : 18655567
    }, {
      "name" : "Brian Mossop",
      "screen_name" : "bmossop",
      "indices" : [ 121, 129 ],
      "id_str" : "20806880",
      "id" : 20806880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166669083662753793",
  "text" : "RT @stevesilberman: DIY scientist arrested last year for trying to split atoms in his kitchen has Asperger syndrome [via @bmossop] http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brian Mossop",
        "screen_name" : "bmossop",
        "indices" : [ 101, 109 ],
        "id_str" : "20806880",
        "id" : 20806880
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/ffA1V4gg",
        "expanded_url" : "http:\/\/bit.ly\/wlO3YV",
        "display_url" : "bit.ly\/wlO3YV"
      } ]
    },
    "geo" : { },
    "id_str" : "166652848745103360",
    "text" : "DIY scientist arrested last year for trying to split atoms in his kitchen has Asperger syndrome [via @bmossop] http:\/\/t.co\/ffA1V4gg",
    "id" : 166652848745103360,
    "created_at" : "2012-02-06 22:41:50 +0000",
    "user" : {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "protected" : false,
      "id_str" : "18655567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801317729978449920\/1ZDKwlMv_normal.jpg",
      "id" : 18655567,
      "verified" : true
    }
  },
  "id" : 166669083662753793,
  "created_at" : "2012-02-06 23:46:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Legro",
      "screen_name" : "michellelegro",
      "indices" : [ 3, 17 ],
      "id_str" : "141745416",
      "id" : 141745416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166616345578971137",
  "text" : "RT @michellelegro: It appears that \"Understanding Media\" is not available for Kindle or any e-book. Take THAT, irony.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166616093304168448",
    "text" : "It appears that \"Understanding Media\" is not available for Kindle or any e-book. Take THAT, irony.",
    "id" : 166616093304168448,
    "created_at" : "2012-02-06 20:15:46 +0000",
    "user" : {
      "name" : "Michelle Legro",
      "screen_name" : "michellelegro",
      "protected" : false,
      "id_str" : "141745416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441095710482526208\/MGcP0IVP_normal.jpeg",
      "id" : 141745416,
      "verified" : true
    }
  },
  "id" : 166616345578971137,
  "created_at" : "2012-02-06 20:16:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/oUxoBgv6",
      "expanded_url" : "http:\/\/skepchick.org\/2012\/02\/seeing-the-patriarchy\/",
      "display_url" : "skepchick.org\/2012\/02\/seeing\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166614659657498624",
  "text" : "Seeing the Patriarchy http:\/\/t.co\/oUxoBgv6",
  "id" : 166614659657498624,
  "created_at" : "2012-02-06 20:10:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/hIbgUDeY",
      "expanded_url" : "http:\/\/www.darwineatscake.com\/~darwin6\/?id=88",
      "display_url" : "darwineatscake.com\/~darwin6\/?id=88"
    } ]
  },
  "geo" : { },
  "id_str" : "166610338006056961",
  "text" : "The top five underutilized Watchmen references http:\/\/t.co\/hIbgUDeY",
  "id" : 166610338006056961,
  "created_at" : "2012-02-06 19:52:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/l5qqZiay",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/citizenscience\/help-us-print-csq-issues-03-04?ref=card",
      "display_url" : "kickstarter.com\/projects\/citiz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166594222621868032",
  "text" : "Please help funding the next two issues of the great Citizen Science Quarterly http:\/\/t.co\/l5qqZiay",
  "id" : 166594222621868032,
  "created_at" : "2012-02-06 18:48:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166587576705232896",
  "text" : "Neusten Erkenntnissen zufolge wurde die Kokosnuss geklaut. Die Primatenpartei ist emp\u00F6rt und verurteilt dies aufs sch\u00E4rfste.",
  "id" : 166587576705232896,
  "created_at" : "2012-02-06 18:22:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/8P1TXXI0",
      "expanded_url" : "http:\/\/j.mp\/xDOmEf",
      "display_url" : "j.mp\/xDOmEf"
    } ]
  },
  "geo" : { },
  "id_str" : "166572493535051777",
  "text" : "Some History on Phylogenetics: The first tree of life http:\/\/t.co\/8P1TXXI0",
  "id" : 166572493535051777,
  "created_at" : "2012-02-06 17:22:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/PT6LyJBi",
      "expanded_url" : "http:\/\/j.mp\/xHPDMz",
      "display_url" : "j.mp\/xHPDMz"
    } ]
  },
  "geo" : { },
  "id_str" : "166571822907793408",
  "text" : "Is it good to listen to music at work? http:\/\/t.co\/PT6LyJBi",
  "id" : 166571822907793408,
  "created_at" : "2012-02-06 17:19:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/U5lNc1de",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=RtLEPPgbNyM",
      "display_url" : "youtube.com\/watch?v=RtLEPP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166567237744996352",
  "text" : "\u00ABWhat Bush was thinking didn't matter. Cause he wasn't\u00BB http:\/\/t.co\/U5lNc1de",
  "id" : 166567237744996352,
  "created_at" : "2012-02-06 17:01:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 3, 13 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/IZpKChuo",
      "expanded_url" : "http:\/\/en.rian.ru\/science\/20120206\/171176587.html",
      "display_url" : "en.rian.ru\/science\/201202\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166540895083175936",
  "text" : "RT @Fischblog: Was f\u00FCr ein geiler Schluss! Geheime Nazi-Festung angebohrt! http:\/\/t.co\/IZpKChuo ROTFLMAO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/IZpKChuo",
        "expanded_url" : "http:\/\/en.rian.ru\/science\/20120206\/171176587.html",
        "display_url" : "en.rian.ru\/science\/201202\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "166535881086341120",
    "text" : "Was f\u00FCr ein geiler Schluss! Geheime Nazi-Festung angebohrt! http:\/\/t.co\/IZpKChuo ROTFLMAO",
    "id" : 166535881086341120,
    "created_at" : "2012-02-06 14:57:02 +0000",
    "user" : {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "protected" : false,
      "id_str" : "14700783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929627167125921792\/t5PPk1W-_normal.jpg",
      "id" : 14700783,
      "verified" : false
    }
  },
  "id" : 166540895083175936,
  "created_at" : "2012-02-06 15:16:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/flLnhBn8",
      "expanded_url" : "http:\/\/theaphidroom.wordpress.com\/2012\/02\/06\/stability-of-instability-when-karyotype-is-never-the-same\/?utm_source=feedburner&utm_medium=twitter&utm_campaign=Feed%3A+ResearchBloggingAllEnglish+%28Research+Blogging+-+English+-+All+Topics%29",
      "display_url" : "theaphidroom.wordpress.com\/2012\/02\/06\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166513894112763905",
  "text" : "Stability of instability\u2026 when karyotype is never the same http:\/\/t.co\/flLnhBn8",
  "id" : 166513894112763905,
  "created_at" : "2012-02-06 13:29:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 6, 19 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/GHFMWuWw",
      "expanded_url" : "http:\/\/j.mp\/xXU4CD",
      "display_url" : "j.mp\/xXU4CD"
    } ]
  },
  "geo" : { },
  "id_str" : "166484994229940224",
  "text" : "Cool, @manuelcorpas goes on to share findings of his open exome: My Personal Exome Analysis http:\/\/t.co\/GHFMWuWw",
  "id" : 166484994229940224,
  "created_at" : "2012-02-06 11:34:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/RIMQ0ifR",
      "expanded_url" : "http:\/\/j.mp\/A2QQ7b",
      "display_url" : "j.mp\/A2QQ7b"
    } ]
  },
  "geo" : { },
  "id_str" : "166439848478126080",
  "text" : "Socialized personal genomics? http:\/\/t.co\/RIMQ0ifR",
  "id" : 166439848478126080,
  "created_at" : "2012-02-06 08:35:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 5, 14 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166311956922384384",
  "text" : "Dank @Senficon hab ich nun Angst das die US Army den Kater nach Afghanistan geschickt hat.",
  "id" : 166311956922384384,
  "created_at" : "2012-02-06 00:07:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CATA",
      "indices" : [ 76, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166295432241233920",
  "text" : "RT @Senficon: Helfen alle unseren Kater suchen, wenn ich behaupte, er hie\u00DFe #CATA und es ginge um die Freiheit des Internets?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CATA",
        "indices" : [ 62, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166293765483544577",
    "text" : "Helfen alle unseren Kater suchen, wenn ich behaupte, er hie\u00DFe #CATA und es ginge um die Freiheit des Internets?",
    "id" : 166293765483544577,
    "created_at" : "2012-02-05 22:54:57 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 166295432241233920,
  "created_at" : "2012-02-05 23:01:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffa",
      "screen_name" : "rei_in_der_tube",
      "indices" : [ 0, 16 ],
      "id_str" : "19707954",
      "id" : 19707954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166267073226489857",
  "geo" : { },
  "id_str" : "166282049672593408",
  "in_reply_to_user_id" : 19707954,
  "text" : "@rei_in_der_tube War okay, aber auch wenn die 5. Staffel insgesamt ziemlich schwach war, fand ich.",
  "id" : 166282049672593408,
  "in_reply_to_status_id" : 166267073226489857,
  "created_at" : "2012-02-05 22:08:24 +0000",
  "in_reply_to_screen_name" : "rei_in_der_tube",
  "in_reply_to_user_id_str" : "19707954",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166263766311370752",
  "text" : "Das war also das Ende von Chuck...",
  "id" : 166263766311370752,
  "created_at" : "2012-02-05 20:55:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166150611681812480",
  "geo" : { },
  "id_str" : "166151446230863872",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon was ist denn so schrecklich an Hunden? ;)",
  "id" : 166151446230863872,
  "in_reply_to_status_id" : 166150611681812480,
  "created_at" : "2012-02-05 13:29:26 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166150636218499072",
  "geo" : { },
  "id_str" : "166151327628537856",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai Hundeshows ja, aber Hunde an sich sind cool :)",
  "id" : 166151327628537856,
  "in_reply_to_status_id" : 166150636218499072,
  "created_at" : "2012-02-05 13:28:58 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166150209037012993",
  "geo" : { },
  "id_str" : "166150431226081280",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon auch wenn wir nur K\u00E4tzchen haben bin ich eigentlich auch mehr der Hunde-Fan.",
  "id" : 166150431226081280,
  "in_reply_to_status_id" : 166150209037012993,
  "created_at" : "2012-02-05 13:25:24 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/lhn14Eh3",
      "expanded_url" : "http:\/\/j.mp\/ykMGG5",
      "display_url" : "j.mp\/ykMGG5"
    } ]
  },
  "geo" : { },
  "id_str" : "166149233039253505",
  "text" : "Tierzucht: Forscher erschaffen den idealen Hund http:\/\/t.co\/lhn14Eh3",
  "id" : 166149233039253505,
  "created_at" : "2012-02-05 13:20:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.flipboard.com\" rel=\"nofollow\"\u003EFlipboard\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/yKVm4y1D",
      "expanded_url" : "http:\/\/bit.ly\/yprpmg",
      "display_url" : "bit.ly\/yprpmg"
    } ]
  },
  "geo" : { },
  "id_str" : "166127535397146624",
  "text" : "10-yr-old girl discovers molecule by playing around with chem-modelling kit http:\/\/t.co\/yKVm4y1D",
  "id" : 166127535397146624,
  "created_at" : "2012-02-05 11:54:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Kliesch",
      "screen_name" : "antipattern",
      "indices" : [ 3, 15 ],
      "id_str" : "21827943",
      "id" : 21827943
    }, {
      "name" : "Edzard Ernst",
      "screen_name" : "EdzardErnst",
      "indices" : [ 74, 86 ],
      "id_str" : "26992475",
      "id" : 26992475
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tcm",
      "indices" : [ 65, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/Jw2uIbRO",
      "expanded_url" : "http:\/\/www.express.co.uk\/posts\/view\/300179",
      "display_url" : "express.co.uk\/posts\/view\/300\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166122872807505920",
  "text" : "RT @antipattern: Animal torture for traditional Chinese medicine #tcm Via @EdzardErnst http:\/\/t.co\/Jw2uIbRO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Edzard Ernst",
        "screen_name" : "EdzardErnst",
        "indices" : [ 57, 69 ],
        "id_str" : "26992475",
        "id" : 26992475
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tcm",
        "indices" : [ 48, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/Jw2uIbRO",
        "expanded_url" : "http:\/\/www.express.co.uk\/posts\/view\/300179",
        "display_url" : "express.co.uk\/posts\/view\/300\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "166114524259303426",
    "text" : "Animal torture for traditional Chinese medicine #tcm Via @EdzardErnst http:\/\/t.co\/Jw2uIbRO",
    "id" : 166114524259303426,
    "created_at" : "2012-02-05 11:02:43 +0000",
    "user" : {
      "name" : "Christian Kliesch",
      "screen_name" : "antipattern",
      "protected" : false,
      "id_str" : "21827943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567702934016651265\/0V9Gjuhr_normal.jpeg",
      "id" : 21827943,
      "verified" : false
    }
  },
  "id" : 166122872807505920,
  "created_at" : "2012-02-05 11:35:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Bellersen",
      "screen_name" : "nichimtakt",
      "indices" : [ 0, 11 ],
      "id_str" : "48065959",
      "id" : 48065959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166121771903365121",
  "geo" : { },
  "id_str" : "166121878052802560",
  "in_reply_to_user_id" : 48065959,
  "text" : "@nichimtakt ok, dann sag mal bescheid wenn ich auslachen darf ;)",
  "id" : 166121878052802560,
  "in_reply_to_status_id" : 166121771903365121,
  "created_at" : "2012-02-05 11:31:56 +0000",
  "in_reply_to_screen_name" : "nichimtakt",
  "in_reply_to_user_id_str" : "48065959",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/VZ6G1a3v",
      "expanded_url" : "http:\/\/j.mp\/yQSq5q",
      "display_url" : "j.mp\/yQSq5q"
    } ]
  },
  "geo" : { },
  "id_str" : "166121795248861184",
  "text" : "School of Ants: Crowdsourced Biogeography http:\/\/t.co\/VZ6G1a3v",
  "id" : 166121795248861184,
  "created_at" : "2012-02-05 11:31:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Bellersen",
      "screen_name" : "nichimtakt",
      "indices" : [ 0, 11 ],
      "id_str" : "48065959",
      "id" : 48065959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166097752521052160",
  "geo" : { },
  "id_str" : "166121302648823808",
  "in_reply_to_user_id" : 48065959,
  "text" : "@nichimtakt wurde der Unfug schon angenommen? :P",
  "id" : 166121302648823808,
  "in_reply_to_status_id" : 166097752521052160,
  "created_at" : "2012-02-05 11:29:39 +0000",
  "in_reply_to_screen_name" : "nichimtakt",
  "in_reply_to_user_id_str" : "48065959",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/YHbAtQhN",
      "expanded_url" : "http:\/\/j.mp\/AAhsBG",
      "display_url" : "j.mp\/AAhsBG"
    } ]
  },
  "geo" : { },
  "id_str" : "166097966577356800",
  "text" : "The Common Origins of Homosexuality and Mental Illness http:\/\/t.co\/YHbAtQhN",
  "id" : 166097966577356800,
  "created_at" : "2012-02-05 09:56:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/noAe6WEU",
      "expanded_url" : "http:\/\/j.mp\/yVIed7",
      "display_url" : "j.mp\/yVIed7"
    } ]
  },
  "geo" : { },
  "id_str" : "166092961199820800",
  "text" : "3D printed Titanium Jaws! http:\/\/t.co\/noAe6WEU",
  "id" : 166092961199820800,
  "created_at" : "2012-02-05 09:37:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/TRqyyobw",
      "expanded_url" : "http:\/\/j.mp\/wvNmnY",
      "display_url" : "j.mp\/wvNmnY"
    } ]
  },
  "geo" : { },
  "id_str" : "166092632852930560",
  "text" : "Fine art reimagined with science fiction themes http:\/\/t.co\/TRqyyobw",
  "id" : 166092632852930560,
  "created_at" : "2012-02-05 09:35:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165940987384958977",
  "text" : "\u00ABZero connection to Bioethics (in a professional sense)\u00BB :D",
  "id" : 165940987384958977,
  "created_at" : "2012-02-04 23:33:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 3, 14 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 26, 35 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165940684375851008",
  "text" : "RT @openSNPorg: Listen to @wilbanks at the President. Commission for the Study of Bioethical Issues (includes a mention of us @ 23 min)  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Wilbanks",
        "screen_name" : "wilbanks",
        "indices" : [ 10, 19 ],
        "id_str" : "14245811",
        "id" : 14245811
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/mmp1YbKt",
        "expanded_url" : "http:\/\/www.tvworldwide.com\/events\/bioethics\/120202\/globe_show\/default_go_archive.cfm?gsid=1954&type=flv&test=0&live=0",
        "display_url" : "tvworldwide.com\/events\/bioethi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "165940627115229184",
    "text" : "Listen to @wilbanks at the President. Commission for the Study of Bioethical Issues (includes a mention of us @ 23 min) http:\/\/t.co\/mmp1YbKt",
    "id" : 165940627115229184,
    "created_at" : "2012-02-04 23:31:43 +0000",
    "user" : {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "protected" : false,
      "id_str" : "380205172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735374825187909632\/wJEJW1zW_normal.jpg",
      "id" : 380205172,
      "verified" : false
    }
  },
  "id" : 165940684375851008,
  "created_at" : "2012-02-04 23:31:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165928776222523393",
  "geo" : { },
  "id_str" : "165929261125992448",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ Ja, ich hoffe auch das er nach Hause kommt oder gefunden wird :(",
  "id" : 165929261125992448,
  "in_reply_to_status_id" : 165928776222523393,
  "created_at" : "2012-02-04 22:46:33 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165927736081256450",
  "geo" : { },
  "id_str" : "165928517907922944",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ Ja, haben wir gemacht.",
  "id" : 165928517907922944,
  "in_reply_to_status_id" : 165927736081256450,
  "created_at" : "2012-02-04 22:43:36 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165925370707718145",
  "text" : "Vermisstenanzeige f\u00FCr den Kater in der Lokalzeitung aufzugeben kostet so viel wie ein neues Tier... Kein Wunder das Print stirbt...",
  "id" : 165925370707718145,
  "created_at" : "2012-02-04 22:31:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Leutert",
      "screen_name" : "pyth2_0",
      "indices" : [ 0, 8 ],
      "id_str" : "65875890",
      "id" : 65875890
    }, {
      "name" : "Piratenpartei",
      "screen_name" : "Piratenpartei",
      "indices" : [ 67, 81 ],
      "id_str" : "14341194",
      "id" : 14341194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165881743310716928",
  "geo" : { },
  "id_str" : "165881942103965696",
  "in_reply_to_user_id" : 65875890,
  "text" : "@pyth2_0 Aber wenn das noch h\u00E4ufiger passiert dann sind die DMs an @Piratenpartei bei der Spackeria in guten H\u00E4nden :P",
  "id" : 165881942103965696,
  "in_reply_to_status_id" : 165881743310716928,
  "created_at" : "2012-02-04 19:38:31 +0000",
  "in_reply_to_screen_name" : "pyth2_0",
  "in_reply_to_user_id_str" : "65875890",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Leutert",
      "screen_name" : "pyth2_0",
      "indices" : [ 0, 8 ],
      "id_str" : "65875890",
      "id" : 65875890
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 23, 32 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165881743310716928",
  "geo" : { },
  "id_str" : "165881798629396480",
  "in_reply_to_user_id" : 65875890,
  "text" : "@pyth2_0 F\u00FCr jetzt hat @Senficon es mal wieder rausgenommen",
  "id" : 165881798629396480,
  "in_reply_to_status_id" : 165881743310716928,
  "created_at" : "2012-02-04 19:37:57 +0000",
  "in_reply_to_screen_name" : "pyth2_0",
  "in_reply_to_user_id_str" : "65875890",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Leutert",
      "screen_name" : "pyth2_0",
      "indices" : [ 0, 8 ],
      "id_str" : "65875890",
      "id" : 65875890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165881558979452928",
  "geo" : { },
  "id_str" : "165881688658939904",
  "in_reply_to_user_id" : 65875890,
  "text" : "@pyth2_0 Sorg mal daf\u00FCr das bei ALLEN Leuten mit dem Passwort ankommt das man Echofon kein OAuth geben darf",
  "id" : 165881688658939904,
  "in_reply_to_status_id" : 165881558979452928,
  "created_at" : "2012-02-04 19:37:31 +0000",
  "in_reply_to_screen_name" : "pyth2_0",
  "in_reply_to_user_id_str" : "65875890",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Leutert",
      "screen_name" : "pyth2_0",
      "indices" : [ 0, 8 ],
      "id_str" : "65875890",
      "id" : 65875890
    }, {
      "name" : "Piratenpartei",
      "screen_name" : "Piratenpartei",
      "indices" : [ 13, 27 ],
      "id_str" : "14341194",
      "id" : 14341194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165881245962739712",
  "geo" : { },
  "id_str" : "165881482903158784",
  "in_reply_to_user_id" : 65875890,
  "text" : "@pyth2_0 Der @Piratenpartei Bediener. Wenn man PNS f\u00FCr Echofon einstellt dann bekommt jeder der irgendwann\u2122 mal Zugriff hatte die PNS...",
  "id" : 165881482903158784,
  "in_reply_to_status_id" : 165881245962739712,
  "created_at" : "2012-02-04 19:36:42 +0000",
  "in_reply_to_screen_name" : "pyth2_0",
  "in_reply_to_user_id_str" : "65875890",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tarzun",
      "screen_name" : "tarzun",
      "indices" : [ 0, 7 ],
      "id_str" : "1632280560",
      "id" : 1632280560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165880948188135424",
  "geo" : { },
  "id_str" : "165880994673606657",
  "in_reply_to_user_id" : 45513907,
  "text" : "@tarzun Ich schreib mal an den Vorstand...",
  "id" : 165880994673606657,
  "in_reply_to_status_id" : 165880948188135424,
  "created_at" : "2012-02-04 19:34:45 +0000",
  "in_reply_to_screen_name" : "klauspeukert",
  "in_reply_to_user_id_str" : "45513907",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165874190451347458",
  "geo" : { },
  "id_str" : "165874633478909954",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai total :P",
  "id" : 165874633478909954,
  "in_reply_to_status_id" : 165874190451347458,
  "created_at" : "2012-02-04 19:09:29 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165873844811333633",
  "geo" : { },
  "id_str" : "165874123157946368",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai mittlerweile bin ich mir sicher das die meisten es nicht sind.",
  "id" : 165874123157946368,
  "in_reply_to_status_id" : 165873844811333633,
  "created_at" : "2012-02-04 19:07:27 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piratenpartei",
      "screen_name" : "Piratenpartei",
      "indices" : [ 59, 73 ],
      "id_str" : "14341194",
      "id" : 14341194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165873613264789505",
  "text" : "Und schon wieder kann ich wegen Anwenderfails alle DMs von @piratenpartei mitlesen...",
  "id" : 165873613264789505,
  "created_at" : "2012-02-04 19:05:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simone Brand",
      "screen_name" : "piratringwraith",
      "indices" : [ 0, 16 ],
      "id_str" : "102697458",
      "id" : 102697458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165835629198983168",
  "geo" : { },
  "id_str" : "165835806202802178",
  "in_reply_to_user_id" : 102697458,
  "text" : "@piratringwraith naja, ist ja ein Satz der schon treffend sein kann. ;)",
  "id" : 165835806202802178,
  "in_reply_to_status_id" : 165835629198983168,
  "created_at" : "2012-02-04 16:35:11 +0000",
  "in_reply_to_screen_name" : "piratringwraith",
  "in_reply_to_user_id_str" : "102697458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simone Brand",
      "screen_name" : "piratringwraith",
      "indices" : [ 0, 16 ],
      "id_str" : "102697458",
      "id" : 102697458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165835027396046848",
  "geo" : { },
  "id_str" : "165835223613972482",
  "in_reply_to_user_id" : 102697458,
  "text" : "@piratringwraith bin beim CCC, nicht bei den Piraten ;)",
  "id" : 165835223613972482,
  "in_reply_to_status_id" : 165835027396046848,
  "created_at" : "2012-02-04 16:32:53 +0000",
  "in_reply_to_screen_name" : "piratringwraith",
  "in_reply_to_user_id_str" : "102697458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165834878733139969",
  "text" : "Es wurden schon alle getrollt. Nur noch nicht von jedem.",
  "id" : 165834878733139969,
  "created_at" : "2012-02-04 16:31:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165784473546399746",
  "geo" : { },
  "id_str" : "165784650898358273",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante wie das so ist: Wer am n\u00E4chsten dran wohnt kommt als letztes ;)",
  "id" : 165784650898358273,
  "in_reply_to_status_id" : 165784473546399746,
  "created_at" : "2012-02-04 13:11:55 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "schusselhexe",
      "screen_name" : "christorolo",
      "indices" : [ 0, 12 ],
      "id_str" : "292924620",
      "id" : 292924620
    }, {
      "name" : "Richard",
      "screen_name" : "zinken",
      "indices" : [ 13, 20 ],
      "id_str" : "15353398",
      "id" : 15353398
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 21, 31 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165772495570485249",
  "geo" : { },
  "id_str" : "165784478210473987",
  "in_reply_to_user_id" : 292924620,
  "text" : "@christorolo @zinken @Fischblog davon h\u00E4tte ich auch gern ein Redaktionsvideo. ;)",
  "id" : 165784478210473987,
  "in_reply_to_status_id" : 165772495570485249,
  "created_at" : "2012-02-04 13:11:14 +0000",
  "in_reply_to_screen_name" : "christorolo",
  "in_reply_to_user_id_str" : "292924620",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165784165676093440",
  "geo" : { },
  "id_str" : "165784292465713152",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante okay :)",
  "id" : 165784292465713152,
  "in_reply_to_status_id" : 165784165676093440,
  "created_at" : "2012-02-04 13:10:30 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165539841415712768",
  "geo" : { },
  "id_str" : "165784095731888128",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante schau mal auf 9 Uhr",
  "id" : 165784095731888128,
  "in_reply_to_status_id" : 165539841415712768,
  "created_at" : "2012-02-04 13:09:43 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Richard",
      "screen_name" : "zinken",
      "indices" : [ 11, 18 ],
      "id_str" : "15353398",
      "id" : 15353398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165770926644924416",
  "geo" : { },
  "id_str" : "165771346293424129",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @zinken ich dachte er kommt so auch immer ins B\u00FCro? :)",
  "id" : 165771346293424129,
  "in_reply_to_status_id" : 165770926644924416,
  "created_at" : "2012-02-04 12:19:03 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 45, 55 ],
      "id_str" : "7207642",
      "id" : 7207642
    }, {
      "name" : "Rin Raeuber",
      "screen_name" : "rinpaku",
      "indices" : [ 126, 134 ],
      "id_str" : "195489657",
      "id" : 195489657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/lwnZTMRO",
      "expanded_url" : "http:\/\/cooksuck.com\/",
      "display_url" : "cooksuck.com"
    } ]
  },
  "geo" : { },
  "id_str" : "165768050178670594",
  "text" : "Sehr heiteres Blog wenn man b\u00F6sartig ist: RT @fragmente: Hier nat\u00FCrlich ein c statt einem o gelesen: http:\/\/t.co\/lwnZTMRO via @rinpaku",
  "id" : 165768050178670594,
  "created_at" : "2012-02-04 12:05:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165746530022731776",
  "geo" : { },
  "id_str" : "165748224055984129",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon kannst ja mal umrechnen wie lange wir dann warten m\u00FCssen um p&lt;0.05 sicher zu sein das der Kater nicht wiederkommt.",
  "id" : 165748224055984129,
  "in_reply_to_status_id" : 165746530022731776,
  "created_at" : "2012-02-04 10:47:10 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165746221997236224",
  "text" : "\u00AB95% aller vermissten Katzen werden in den ersten 6 Wochen gefunden. Danach gibt's einen neuen, das ist ein ordentliches Konfidenzintervall\u00BB",
  "id" : 165746221997236224,
  "created_at" : "2012-02-04 10:39:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/EnLwPOXE",
      "expanded_url" : "http:\/\/j.mp\/yYOQ1e",
      "display_url" : "j.mp\/yYOQ1e"
    } ]
  },
  "geo" : { },
  "id_str" : "165731041699561472",
  "text" : "ArcAttack performs a Tesla Coil version of Iron Man by Black Sabbath with a Faraday Guitar http:\/\/t.co\/EnLwPOXE",
  "id" : 165731041699561472,
  "created_at" : "2012-02-04 09:38:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/5v3iNZ3b",
      "expanded_url" : "http:\/\/j.mp\/yqX7J3",
      "display_url" : "j.mp\/yqX7J3"
    } ]
  },
  "geo" : { },
  "id_str" : "165551969858101248",
  "text" : "Review of the Lumigenix \u201CComprehensive\u201D personal genome service http:\/\/t.co\/5v3iNZ3b",
  "id" : 165551969858101248,
  "created_at" : "2012-02-03 21:47:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165466146043207681",
  "geo" : { },
  "id_str" : "165539748839047168",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante sieht so aus als w\u00E4ren wir morgen auch da :)",
  "id" : 165539748839047168,
  "in_reply_to_status_id" : 165466146043207681,
  "created_at" : "2012-02-03 20:58:46 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fukami",
      "screen_name" : "fukami",
      "indices" : [ 0, 7 ],
      "id_str" : "1209301",
      "id" : 1209301
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "c3amv",
      "indices" : [ 60, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165459216692293632",
  "geo" : { },
  "id_str" : "165461949369421825",
  "in_reply_to_user_id" : 1209301,
  "text" : "@fukami Jo, wobei ich noch nicht sicher bin ob auch bei der #c3amv",
  "id" : 165461949369421825,
  "in_reply_to_status_id" : 165459216692293632,
  "created_at" : "2012-02-03 15:49:37 +0000",
  "in_reply_to_screen_name" : "fukami",
  "in_reply_to_user_id_str" : "1209301",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165457807175462912",
  "geo" : { },
  "id_str" : "165461665104670720",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante Ich wohne hier ;)",
  "id" : 165461665104670720,
  "in_reply_to_status_id" : 165457807175462912,
  "created_at" : "2012-02-03 15:48:29 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fukami",
      "screen_name" : "fukami",
      "indices" : [ 0, 7 ],
      "id_str" : "1209301",
      "id" : 1209301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165456312916905984",
  "geo" : { },
  "id_str" : "165456727414812673",
  "in_reply_to_user_id" : 1209301,
  "text" : "@fukami Kaffee? ;)",
  "id" : 165456727414812673,
  "in_reply_to_status_id" : 165456312916905984,
  "created_at" : "2012-02-03 15:28:52 +0000",
  "in_reply_to_screen_name" : "fukami",
  "in_reply_to_user_id_str" : "1209301",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/QShlKTYH",
      "expanded_url" : "http:\/\/lookslikescience.tumblr.com\/",
      "display_url" : "lookslikescience.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "165405662099148800",
  "text" : "Looks like Science http:\/\/t.co\/QShlKTYH",
  "id" : 165405662099148800,
  "created_at" : "2012-02-03 12:05:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/aCJ4OQ7N",
      "expanded_url" : "http:\/\/j.mp\/ysQnvN",
      "display_url" : "j.mp\/ysQnvN"
    } ]
  },
  "geo" : { },
  "id_str" : "165384504549183488",
  "text" : "Egypt http:\/\/t.co\/aCJ4OQ7N",
  "id" : 165384504549183488,
  "created_at" : "2012-02-03 10:41:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/Ur4R4PSh",
      "expanded_url" : "http:\/\/j.mp\/yzLfrW",
      "display_url" : "j.mp\/yzLfrW"
    } ]
  },
  "geo" : { },
  "id_str" : "165380527195557888",
  "text" : "WTF? UNC-Charlotte gets its own SWAT team http:\/\/t.co\/Ur4R4PSh",
  "id" : 165380527195557888,
  "created_at" : "2012-02-03 10:26:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/CNzo31En",
      "expanded_url" : "http:\/\/j.mp\/wztj7l",
      "display_url" : "j.mp\/wztj7l"
    } ]
  },
  "geo" : { },
  "id_str" : "165380362153885696",
  "text" : "Soviet pistol door handle http:\/\/t.co\/CNzo31En",
  "id" : 165380362153885696,
  "created_at" : "2012-02-03 10:25:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/8GtCzOGq",
      "expanded_url" : "http:\/\/j.mp\/xHo41i",
      "display_url" : "j.mp\/xHo41i"
    } ]
  },
  "geo" : { },
  "id_str" : "165377368708481024",
  "text" : "The Earliest Post-Paleozoic Freshwater Bivalves Preserved in Coprolites from the Karoo Basin http:\/\/t.co\/8GtCzOGq",
  "id" : 165377368708481024,
  "created_at" : "2012-02-03 10:13:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Boegel",
      "screen_name" : "sebboeg",
      "indices" : [ 0, 8 ],
      "id_str" : "296476788",
      "id" : 296476788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165356461529108480",
  "geo" : { },
  "id_str" : "165374056114307072",
  "in_reply_to_user_id" : 296476788,
  "text" : "@sebboeg Ne, der Kater ist leider immer noch weg :(",
  "id" : 165374056114307072,
  "in_reply_to_status_id" : 165356461529108480,
  "created_at" : "2012-02-03 10:00:22 +0000",
  "in_reply_to_screen_name" : "sebboeg",
  "in_reply_to_user_id_str" : "296476788",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165208951472914432",
  "geo" : { },
  "id_str" : "165213016466530304",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I'm wondering: Do we need anything besides the \/features method? :D",
  "id" : 165213016466530304,
  "in_reply_to_status_id" : 165208951472914432,
  "created_at" : "2012-02-02 23:20:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165208951472914432",
  "geo" : { },
  "id_str" : "165209092384751618",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Dunno, I'm currently reading the docs you sent me and test all the stuff on the UCSC servers in parallel.",
  "id" : 165209092384751618,
  "in_reply_to_status_id" : 165208951472914432,
  "created_at" : "2012-02-02 23:04:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165208737244643329",
  "text" : "Started further reading on the DAS specifications. Head -&gt; Explode",
  "id" : 165208737244643329,
  "created_at" : "2012-02-02 23:03:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/1ILcAMCo",
      "expanded_url" : "http:\/\/j.mp\/zqAxA3",
      "display_url" : "j.mp\/zqAxA3"
    } ]
  },
  "geo" : { },
  "id_str" : "165187767377215489",
  "text" : "Awesome: The Bachelor: A modern-day replication of the Stanford Prison Experiment? http:\/\/t.co\/1ILcAMCo",
  "id" : 165187767377215489,
  "created_at" : "2012-02-02 21:40:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/O5d4KjAD",
      "expanded_url" : "http:\/\/j.mp\/yGzqsg",
      "display_url" : "j.mp\/yGzqsg"
    } ]
  },
  "geo" : { },
  "id_str" : "165187472672817152",
  "text" : "\u00ABWe want to find risk alleles to predict common diseases, but [...] we can't\u00BB http:\/\/t.co\/O5d4KjAD",
  "id" : 165187472672817152,
  "created_at" : "2012-02-02 21:38:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/9afegPXb",
      "expanded_url" : "http:\/\/j.mp\/wQx3ne",
      "display_url" : "j.mp\/wQx3ne"
    } ]
  },
  "geo" : { },
  "id_str" : "165186691517259776",
  "text" : "Improving healthy food & beverage choices through choice architecture http:\/\/t.co\/9afegPXb",
  "id" : 165186691517259776,
  "created_at" : "2012-02-02 21:35:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/Ov9G4vUl",
      "expanded_url" : "http:\/\/j.mp\/xPZYUz",
      "display_url" : "j.mp\/xPZYUz"
    } ]
  },
  "geo" : { },
  "id_str" : "165185808121331712",
  "text" : "Sweet 24-hour comic about a dangerously moody roommate http:\/\/t.co\/Ov9G4vUl",
  "id" : 165185808121331712,
  "created_at" : "2012-02-02 21:32:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "indices" : [ 3, 14 ],
      "id_str" : "135316691",
      "id" : 135316691
    }, {
      "name" : "Jason Kottke",
      "screen_name" : "jkottke",
      "indices" : [ 32, 40 ],
      "id_str" : "1305941",
      "id" : 1305941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165153442489319424",
  "text" : "RT @JadAbumrad: nice sleuthing \u201C@jkottke: Did some research on ex-slave who wrote his former master a letter. died free at 79. http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Kottke",
        "screen_name" : "jkottke",
        "indices" : [ 16, 24 ],
        "id_str" : "1305941",
        "id" : 1305941
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/zyYCbRYs",
        "expanded_url" : "http:\/\/kottke.org\/12\/02\/what-happened-to-the-former-slave-that-wrote-his-old-master",
        "display_url" : "kottke.org\/12\/02\/what-hap\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "165149258813673472",
    "text" : "nice sleuthing \u201C@jkottke: Did some research on ex-slave who wrote his former master a letter. died free at 79. http:\/\/t.co\/zyYCbRYs\u201D",
    "id" : 165149258813673472,
    "created_at" : "2012-02-02 19:07:06 +0000",
    "user" : {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "protected" : false,
      "id_str" : "135316691",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1529014082\/Jad-Pic2_normal.jpg",
      "id" : 135316691,
      "verified" : true
    }
  },
  "id" : 165153442489319424,
  "created_at" : "2012-02-02 19:23:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/yiTsDFH5",
      "expanded_url" : "http:\/\/j.mp\/xt6moX",
      "display_url" : "j.mp\/xt6moX"
    } ]
  },
  "geo" : { },
  "id_str" : "165110922283728896",
  "text" : "Citizens on the Internet http:\/\/t.co\/yiTsDFH5",
  "id" : 165110922283728896,
  "created_at" : "2012-02-02 16:34:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scibernia",
      "screen_name" : "Scibernia",
      "indices" : [ 3, 13 ],
      "id_str" : "249612796",
      "id" : 249612796
    }, {
      "name" : "Dr Eoin Lettice",
      "screen_name" : "blogscience",
      "indices" : [ 39, 51 ],
      "id_str" : "133659160",
      "id" : 133659160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/wEZikrgq",
      "expanded_url" : "http:\/\/bit.ly\/x5Qi7d",
      "display_url" : "bit.ly\/x5Qi7d"
    } ]
  },
  "geo" : { },
  "id_str" : "165042384692973568",
  "text" : "RT @Scibernia: Worrying stats here. RT @blogscience: (Dis)honest science: new bad science infographic    http:\/\/t.co\/wEZikrgq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr Eoin Lettice",
        "screen_name" : "blogscience",
        "indices" : [ 24, 36 ],
        "id_str" : "133659160",
        "id" : 133659160
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/wEZikrgq",
        "expanded_url" : "http:\/\/bit.ly\/x5Qi7d",
        "display_url" : "bit.ly\/x5Qi7d"
      } ]
    },
    "geo" : { },
    "id_str" : "165040353622241280",
    "text" : "Worrying stats here. RT @blogscience: (Dis)honest science: new bad science infographic    http:\/\/t.co\/wEZikrgq",
    "id" : 165040353622241280,
    "created_at" : "2012-02-02 11:54:21 +0000",
    "user" : {
      "name" : "Scibernia",
      "screen_name" : "Scibernia",
      "protected" : false,
      "id_str" : "249612796",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1511175215\/microscope3_normal.jpeg",
      "id" : 249612796,
      "verified" : false
    }
  },
  "id" : 165042384692973568,
  "created_at" : "2012-02-02 12:02:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/yX6zjcEf",
      "expanded_url" : "http:\/\/j.mp\/y4niBi",
      "display_url" : "j.mp\/y4niBi"
    } ]
  },
  "geo" : { },
  "id_str" : "165025856962564096",
  "text" : "Science Majors are from Mars... http:\/\/t.co\/yX6zjcEf",
  "id" : 165025856962564096,
  "created_at" : "2012-02-02 10:56:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/Pqu8ZUna",
      "expanded_url" : "http:\/\/j.mp\/xBWncW",
      "display_url" : "j.mp\/xBWncW"
    } ]
  },
  "geo" : { },
  "id_str" : "165005107031846912",
  "text" : "Tyler Clementi\u2019s Suicide and Dharun Ravi\u2019s Trial http:\/\/t.co\/Pqu8ZUna",
  "id" : 165005107031846912,
  "created_at" : "2012-02-02 09:34:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/FXNprbdb",
      "expanded_url" : "http:\/\/j.mp\/yKRD3m",
      "display_url" : "j.mp\/yKRD3m"
    } ]
  },
  "geo" : { },
  "id_str" : "164847893159751682",
  "text" : "Terrorist Hunt: The Hunter Becomes the Hunted http:\/\/t.co\/FXNprbdb",
  "id" : 164847893159751682,
  "created_at" : "2012-02-01 23:09:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/JLpGt5un",
      "expanded_url" : "http:\/\/j.mp\/AftwG4",
      "display_url" : "j.mp\/AftwG4"
    } ]
  },
  "geo" : { },
  "id_str" : "164846437568479236",
  "text" : "Yet another NGS data quality filtering pipeline http:\/\/t.co\/JLpGt5un",
  "id" : 164846437568479236,
  "created_at" : "2012-02-01 23:03:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/nIhkgLEt",
      "expanded_url" : "http:\/\/j.mp\/yUikVf",
      "display_url" : "j.mp\/yUikVf"
    } ]
  },
  "geo" : { },
  "id_str" : "164845922956738562",
  "text" : "Season of Sampling and Season of Birth Influence Serotonin Metabolite Levels in Human Cerebrospinal Fluid http:\/\/t.co\/nIhkgLEt",
  "id" : 164845922956738562,
  "created_at" : "2012-02-01 23:01:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/pzb1XhMk",
      "expanded_url" : "http:\/\/j.mp\/y3OUIE",
      "display_url" : "j.mp\/y3OUIE"
    } ]
  },
  "geo" : { },
  "id_str" : "164827605655224321",
  "text" : "Are Ecologists too Credulous? http:\/\/t.co\/pzb1XhMk",
  "id" : 164827605655224321,
  "created_at" : "2012-02-01 21:48:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M. Zimmer",
      "screen_name" : "mauri712",
      "indices" : [ 0, 9 ],
      "id_str" : "97192638",
      "id" : 97192638
    }, {
      "name" : "Dotti B.",
      "screen_name" : "dottilini",
      "indices" : [ 10, 20 ],
      "id_str" : "133042093",
      "id" : 133042093
    }, {
      "name" : "D. Saster-Bakel",
      "screen_name" : "Oberranger",
      "indices" : [ 21, 32 ],
      "id_str" : "189091509",
      "id" : 189091509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164684058960461824",
  "geo" : { },
  "id_str" : "164691958265151489",
  "in_reply_to_user_id" : 97192638,
  "text" : "@mauri712 @dottilini @Oberranger Danke!",
  "id" : 164691958265151489,
  "in_reply_to_status_id" : 164684058960461824,
  "created_at" : "2012-02-01 12:49:57 +0000",
  "in_reply_to_screen_name" : "mauri712",
  "in_reply_to_user_id_str" : "97192638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerrit van Aaken",
      "screen_name" : "gerritvanaaken",
      "indices" : [ 3, 18 ],
      "id_str" : "1002981",
      "id" : 1002981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 106 ],
      "url" : "https:\/\/t.co\/R2dPHybc",
      "expanded_url" : "https:\/\/github.com\/id-Software",
      "display_url" : "github.com\/id-Software"
    } ]
  },
  "geo" : { },
  "id_str" : "164675277388132352",
  "text" : "RT @gerritvanaaken: Abgefahren: DOOM, Quake und Konsorten ganz offiziell bei github: https:\/\/t.co\/R2dPHybc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 86 ],
        "url" : "https:\/\/t.co\/R2dPHybc",
        "expanded_url" : "https:\/\/github.com\/id-Software",
        "display_url" : "github.com\/id-Software"
      } ]
    },
    "geo" : { },
    "id_str" : "164674673337057280",
    "text" : "Abgefahren: DOOM, Quake und Konsorten ganz offiziell bei github: https:\/\/t.co\/R2dPHybc",
    "id" : 164674673337057280,
    "created_at" : "2012-02-01 11:41:16 +0000",
    "user" : {
      "name" : "Gerrit van Aaken",
      "screen_name" : "gerritvanaaken",
      "protected" : false,
      "id_str" : "1002981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1667590551\/sonic_normal.png",
      "id" : 1002981,
      "verified" : false
    }
  },
  "id" : 164675277388132352,
  "created_at" : "2012-02-01 11:43:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164638848113057792",
  "geo" : { },
  "id_str" : "164643334374170624",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Macht ja nix :)",
  "id" : 164643334374170624,
  "in_reply_to_status_id" : 164638848113057792,
  "created_at" : "2012-02-01 09:36:44 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164638473486221312",
  "geo" : { },
  "id_str" : "164638551521239040",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Die Couch ist f\u00FCr den 11.02. reserviert :)",
  "id" : 164638551521239040,
  "in_reply_to_status_id" : 164638473486221312,
  "created_at" : "2012-02-01 09:17:44 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164638015510159360",
  "geo" : { },
  "id_str" : "164638369199030272",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Okay, also ich bin nur vom 26.02. bis 01.03. in Cambridge. Sonst vermutlich zuhause :)",
  "id" : 164638369199030272,
  "in_reply_to_status_id" : 164638015510159360,
  "created_at" : "2012-02-01 09:17:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164637670880980992",
  "geo" : { },
  "id_str" : "164637711209201664",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Jo, geht klar",
  "id" : 164637711209201664,
  "in_reply_to_status_id" : 164637670880980992,
  "created_at" : "2012-02-01 09:14:23 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164636890618793984",
  "geo" : { },
  "id_str" : "164637480476360704",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Dann h\u00E4tte ich gern eine Hose :D",
  "id" : 164637480476360704,
  "in_reply_to_status_id" : 164636890618793984,
  "created_at" : "2012-02-01 09:13:28 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/0tIF6mjl",
      "expanded_url" : "http:\/\/j.mp\/wU7pla",
      "display_url" : "j.mp\/wU7pla"
    } ]
  },
  "geo" : { },
  "id_str" : "164623693333540865",
  "text" : "Consistent Pattern of Local Adaptation during an Experimental Heat Wave in a Pipefish-Trematode Host-Parasite System http:\/\/t.co\/0tIF6mjl",
  "id" : 164623693333540865,
  "created_at" : "2012-02-01 08:18:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/55Agz51P",
      "expanded_url" : "http:\/\/j.mp\/xKTPOY",
      "display_url" : "j.mp\/xKTPOY"
    } ]
  },
  "geo" : { },
  "id_str" : "164623279204741120",
  "text" : "The (very little) evolution of chimps http:\/\/t.co\/55Agz51P",
  "id" : 164623279204741120,
  "created_at" : "2012-02-01 08:17:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]