Grailbird.data.tweets_2017_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara C. Smith",
      "screen_name" : "aetiology",
      "indices" : [ 3, 13 ],
      "id_str" : "35315865",
      "id" : 35315865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "870030832852971521",
  "text" : "RT @aetiology: Researchers, stop saying this. Hate to paraphrase Jurassic Park, but bacteria will find a way. (From this article: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/aetiology\/status\/869720843689046016\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/Lqbx7N7yZf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DBHeY0eXkAIJKNu.jpg",
        "id_str" : "869720721043460098",
        "id" : 869720721043460098,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBHeY0eXkAIJKNu.jpg",
        "sizes" : [ {
          "h" : 90,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 123,
          "resize" : "crop",
          "w" : 123
        }, {
          "h" : 123,
          "resize" : "fit",
          "w" : 928
        }, {
          "h" : 123,
          "resize" : "fit",
          "w" : 928
        }, {
          "h" : 123,
          "resize" : "fit",
          "w" : 928
        } ],
        "display_url" : "pic.twitter.com\/Lqbx7N7yZf"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/GHZuFjnObS",
        "expanded_url" : "https:\/\/www.theguardian.com\/society\/2017\/may\/29\/modified-antibiotic-brings-fresh-hope-to-battle-against-drug-resistance",
        "display_url" : "theguardian.com\/society\/2017\/m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "869720843689046016",
    "text" : "Researchers, stop saying this. Hate to paraphrase Jurassic Park, but bacteria will find a way. (From this article: https:\/\/t.co\/GHZuFjnObS). https:\/\/t.co\/Lqbx7N7yZf",
    "id" : 869720843689046016,
    "created_at" : "2017-05-31 01:03:02 +0000",
    "user" : {
      "name" : "Tara C. Smith",
      "screen_name" : "aetiology",
      "protected" : false,
      "id_str" : "35315865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846164960363364357\/e2s2GLwZ_normal.jpg",
      "id" : 35315865,
      "verified" : true
    }
  },
  "id" : 870030832852971521,
  "created_at" : "2017-05-31 21:34:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shady El Damaty",
      "screen_name" : "Neurallegory",
      "indices" : [ 0, 13 ],
      "id_str" : "326969838",
      "id" : 326969838
    }, {
      "name" : "Whitaker Lab",
      "screen_name" : "Whitaker_Lab",
      "indices" : [ 39, 52 ],
      "id_str" : "816578659603648512",
      "id" : 816578659603648512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/Iz5y81r7mv",
      "expanded_url" : "https:\/\/github.com\/WhitakerLab\/Onboarding\/blob\/master\/LICENSE",
      "display_url" : "github.com\/WhitakerLab\/On\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "870024863926431745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401363814636, 8.7533885389322 ]
  },
  "id_str" : "870025206299021313",
  "in_reply_to_user_id" : 326969838,
  "text" : "@Neurallegory you totally can, because @Whitaker_Lab licensed it with the MIT license! \uD83D\uDC96 https:\/\/t.co\/Iz5y81r7mv",
  "id" : 870025206299021313,
  "in_reply_to_status_id" : 870024863926431745,
  "created_at" : "2017-05-31 21:12:28 +0000",
  "in_reply_to_screen_name" : "Neurallegory",
  "in_reply_to_user_id_str" : "326969838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "870014288991105024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139036172187, 8.75320173054443 ]
  },
  "id_str" : "870015270210781184",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim Thanks, that\u2019s cool!",
  "id" : 870015270210781184,
  "in_reply_to_status_id" : 870014288991105024,
  "created_at" : "2017-05-31 20:32:59 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 3, 18 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "869985832077099008",
  "text" : "RT @MozOpenLeaders: Interested in #mozsprint but not sure where to start? We put together this overview of projects for you!\n\nhttps:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mozsprint",
        "indices" : [ 14, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/78kA7htE8n",
        "expanded_url" : "https:\/\/medium.com\/@MozOpenLeaders\/what-to-work-on-at-mozsprint-d88e1b9f3799",
        "display_url" : "medium.com\/@MozOpenLeader\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "869966262222323712",
    "text" : "Interested in #mozsprint but not sure where to start? We put together this overview of projects for you!\n\nhttps:\/\/t.co\/78kA7htE8n",
    "id" : 869966262222323712,
    "created_at" : "2017-05-31 17:18:14 +0000",
    "user" : {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "protected" : false,
      "id_str" : "791070237949034496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/842142191032123392\/GS5Ptjrs_normal.jpg",
      "id" : 791070237949034496,
      "verified" : false
    }
  },
  "id" : 869985832077099008,
  "created_at" : "2017-05-31 18:36:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Pascal Arimont",
      "screen_name" : "pascal_arimont",
      "indices" : [ 88, 103 ],
      "id_str" : "3393988786",
      "id" : 3393988786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "869894981305200642",
  "text" : "RT @Senficon: Just 9 days left to reject the worst version of EU \u00A9 expansion plans yet: @pascal_arimont's \"alternative compromise\" https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pascal Arimont",
        "screen_name" : "pascal_arimont",
        "indices" : [ 74, 89 ],
        "id_str" : "3393988786",
        "id" : 3393988786
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/869887739654701056\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/KNDqxtfO3W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DBJ16K4WAAARRQ_.png",
        "id_str" : "869887320249466880",
        "id" : 869887320249466880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBJ16K4WAAARRQ_.png",
        "sizes" : [ {
          "h" : 425,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/KNDqxtfO3W"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/0J5sQNnNFb",
        "expanded_url" : "https:\/\/juliareda.eu\/2017\/05\/alternative-compromise\/",
        "display_url" : "juliareda.eu\/2017\/05\/altern\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "869887739654701056",
    "text" : "Just 9 days left to reject the worst version of EU \u00A9 expansion plans yet: @pascal_arimont's \"alternative compromise\" https:\/\/t.co\/0J5sQNnNFb https:\/\/t.co\/KNDqxtfO3W",
    "id" : 869887739654701056,
    "created_at" : "2017-05-31 12:06:13 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 869894981305200642,
  "created_at" : "2017-05-31 12:35:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/FnsS6Tn1I0",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/lRZnAw9OuQxGg\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/lRZnAw9O\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229504782976, 8.62752964625693 ]
  },
  "id_str" : "869876329210155008",
  "text" : "Being forced to nest 4 SSH connections into each other for \u201Esecurity\u201C reasons\u2026 Feels like\u2026 https:\/\/t.co\/FnsS6Tn1I0",
  "id" : 869876329210155008,
  "created_at" : "2017-05-31 11:20:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869875811863613440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229504782976, 8.62752964625693 ]
  },
  "id_str" : "869876020727480320",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann I wonder how many random [ATGC] my laptop can churn out in 12 hours.",
  "id" : 869876020727480320,
  "in_reply_to_status_id" : 869875811863613440,
  "created_at" : "2017-05-31 11:19:39 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/rlVdDEZeyg",
      "expanded_url" : "https:\/\/twitter.com\/Whitey_chan\/status\/869856129463013376",
      "display_url" : "twitter.com\/Whitey_chan\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230744954384, 8.62754085185734 ]
  },
  "id_str" : "869870421830774784",
  "text" : "Also: What the hell is a DNA scan? https:\/\/t.co\/rlVdDEZeyg",
  "id" : 869870421830774784,
  "created_at" : "2017-05-31 10:57:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/kRUA9ax7RS",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/869766263110750208",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230744954384, 8.62754085185734 ]
  },
  "id_str" : "869870051578585089",
  "text" : "That seriously improves my quality of life! https:\/\/t.co\/kRUA9ax7RS",
  "id" : 869870051578585089,
  "created_at" : "2017-05-31 10:55:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "869821793711927297",
  "text" : "RT @gedankenstuecke: Guess who spent 5 minutes searching for his glasses during a video call. Only then the other party helpfully said \u201Cyou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.1138633124546, 8.753334608371505 ]
    },
    "id_str" : "869685466446127104",
    "text" : "Guess who spent 5 minutes searching for his glasses during a video call. Only then the other party helpfully said \u201Cyou are wearing them\u201D. \uD83E\uDD13\uD83D\uDE02",
    "id" : 869685466446127104,
    "created_at" : "2017-05-30 22:42:27 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 869821793711927297,
  "created_at" : "2017-05-31 07:44:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Xu",
      "screen_name" : "annathehybrid",
      "indices" : [ 0, 14 ],
      "id_str" : "2997606122",
      "id" : 2997606122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869756916112687104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233093358624, 8.627518129838874 ]
  },
  "id_str" : "869821776775307265",
  "in_reply_to_user_id" : 2997606122,
  "text" : "@annathehybrid I\u2019m amazed that it doesn\u2019t happen to me more often! \uD83D\uDE02",
  "id" : 869821776775307265,
  "in_reply_to_status_id" : 869756916112687104,
  "created_at" : "2017-05-31 07:44:06 +0000",
  "in_reply_to_screen_name" : "annathehybrid",
  "in_reply_to_user_id_str" : "2997606122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1138633124546, 8.753334608371505 ]
  },
  "id_str" : "869685466446127104",
  "text" : "Guess who spent 5 minutes searching for his glasses during a video call. Only then the other party helpfully said \u201Cyou are wearing them\u201D. \uD83E\uDD13\uD83D\uDE02",
  "id" : 869685466446127104,
  "created_at" : "2017-05-30 22:42:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 3, 12 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenCon",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/wqLimEyWin",
      "expanded_url" : "http:\/\/www.opencon2017.org\/opencon_2017_latam",
      "display_url" : "opencon2017.org\/opencon_2017_l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "869628157506322433",
  "text" : "RT @open_con: The first ever #OpenCon Latin America will happen in Mexico City, October 12-13, 2017! More details: https:\/\/t.co\/wqLimEyWin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/open_con\/status\/869572696744624128\/photo\/1",
        "indices" : [ 125, 148 ],
        "url" : "https:\/\/t.co\/OeSLVveCtx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DBFW3zfXkAAQz_Z.jpg",
        "id_str" : "869571719773786112",
        "id" : 869571719773786112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBFW3zfXkAAQz_Z.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2133,
          "resize" : "fit",
          "w" : 4267
        } ],
        "display_url" : "pic.twitter.com\/OeSLVveCtx"
      } ],
      "hashtags" : [ {
        "text" : "OpenCon",
        "indices" : [ 15, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/wqLimEyWin",
        "expanded_url" : "http:\/\/www.opencon2017.org\/opencon_2017_latam",
        "display_url" : "opencon2017.org\/opencon_2017_l\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "869572696744624128",
    "text" : "The first ever #OpenCon Latin America will happen in Mexico City, October 12-13, 2017! More details: https:\/\/t.co\/wqLimEyWin https:\/\/t.co\/OeSLVveCtx",
    "id" : 869572696744624128,
    "created_at" : "2017-05-30 15:14:21 +0000",
    "user" : {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "protected" : false,
      "id_str" : "2452073258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843937071534424064\/e-PdQw9V_normal.jpg",
      "id" : 2452073258,
      "verified" : false
    }
  },
  "id" : 869628157506322433,
  "created_at" : "2017-05-30 18:54:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whitaker Lab",
      "screen_name" : "Whitaker_Lab",
      "indices" : [ 0, 13 ],
      "id_str" : "816578659603648512",
      "id" : 816578659603648512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869624706227240960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401552168885, 8.753389586806525 ]
  },
  "id_str" : "869624921248477184",
  "in_reply_to_user_id" : 816578659603648512,
  "text" : "@Whitaker_Lab thank you! You make me wish I was doing neuroscience! \uD83D\uDE02",
  "id" : 869624921248477184,
  "in_reply_to_status_id" : 869624706227240960,
  "created_at" : "2017-05-30 18:41:52 +0000",
  "in_reply_to_screen_name" : "Whitaker_Lab",
  "in_reply_to_user_id_str" : "816578659603648512",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whitaker Lab",
      "screen_name" : "Whitaker_Lab",
      "indices" : [ 77, 90 ],
      "id_str" : "816578659603648512",
      "id" : 816578659603648512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/CPfLjbmIFG",
      "expanded_url" : "https:\/\/github.com\/WhitakerLab\/Onboarding\/blob\/master\/Setting-up-your-weekly-meetings.md",
      "display_url" : "github.com\/WhitakerLab\/On\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "868049261472215040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401742114871, 8.753391824209906 ]
  },
  "id_str" : "869624332678553602",
  "in_reply_to_user_id" : 14286491,
  "text" : "A meeting template w\/ first question being \u201EWho did you help this week?\u201C The @Whitaker_Lab\u2019s docs are \uD83D\uDC96\uD83D\uDC96\uD83D\uDC96 https:\/\/t.co\/CPfLjbmIFG",
  "id" : 869624332678553602,
  "in_reply_to_status_id" : 868049261472215040,
  "created_at" : "2017-05-30 18:39:32 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 14, 23 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/vJ5PNHGomf",
      "expanded_url" : "https:\/\/twitter.com\/OpenHumansOrg\/status\/869549736734449665",
      "display_url" : "twitter.com\/OpenHumansOrg\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234681707058, 8.627506095669201 ]
  },
  "id_str" : "869563386580938756",
  "text" : "Well deserved @madprime, all the best for you and Open Humans! \uD83C\uDF89 https:\/\/t.co\/vJ5PNHGomf",
  "id" : 869563386580938756,
  "created_at" : "2017-05-30 14:37:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AmericanHoarderStory",
      "screen_name" : "urchin13",
      "indices" : [ 0, 9 ],
      "id_str" : "16099524",
      "id" : 16099524
    }, {
      "name" : "Gay Panda Ring",
      "screen_name" : "jephjacques",
      "indices" : [ 10, 22 ],
      "id_str" : "7670202",
      "id" : 7670202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869558476703375360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234681707058, 8.627506095669201 ]
  },
  "id_str" : "869562856357986306",
  "in_reply_to_user_id" : 16099524,
  "text" : "@urchin13 @jephjacques at the same time one needs to be clear that a) only projects that appear sexy enough have a chance and b) often money comes from scientists.",
  "id" : 869562856357986306,
  "in_reply_to_status_id" : 869558476703375360,
  "created_at" : "2017-05-30 14:35:15 +0000",
  "in_reply_to_screen_name" : "urchin13",
  "in_reply_to_user_id_str" : "16099524",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AmericanHoarderStory",
      "screen_name" : "urchin13",
      "indices" : [ 0, 9 ],
      "id_str" : "16099524",
      "id" : 16099524
    }, {
      "name" : "Gay Panda Ring",
      "screen_name" : "jephjacques",
      "indices" : [ 10, 22 ],
      "id_str" : "7670202",
      "id" : 7670202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869558476703375360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723364681603, 8.627511791396667 ]
  },
  "id_str" : "869562683024183296",
  "in_reply_to_user_id" : 16099524,
  "text" : "@urchin13 @jephjacques The open science project I co-run is getting funding exclusive through Patreon contributions, so I\u2019m biased towards it.",
  "id" : 869562683024183296,
  "in_reply_to_status_id" : 869558476703375360,
  "created_at" : "2017-05-30 14:34:33 +0000",
  "in_reply_to_screen_name" : "urchin13",
  "in_reply_to_user_id_str" : "16099524",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/ZhS7cAd9DY",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/187",
      "display_url" : "existentialcomics.com\/comic\/187"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231182576532, 8.62752102145434 ]
  },
  "id_str" : "869493020646920192",
  "text" : "what do people generally do when they fall into nihilist despair? https:\/\/t.co\/ZhS7cAd9DY",
  "id" : 869493020646920192,
  "created_at" : "2017-05-30 09:57:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bevan",
      "screen_name" : "katebevan",
      "indices" : [ 0, 10 ],
      "id_str" : "1097161",
      "id" : 1097161
    }, {
      "name" : "harpistkat",
      "screen_name" : "harpistkat",
      "indices" : [ 11, 22 ],
      "id_str" : "921330518737739776",
      "id" : 921330518737739776
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 23, 30 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869477527571623936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232545417835, 8.627502476720947 ]
  },
  "id_str" : "869478591783981056",
  "in_reply_to_user_id" : 1097161,
  "text" : "@katebevan @harpistkat @nature and as far as I can see none of these \u201Eclueless\u201C people including me installed any malware but complained about the attempts to trick ppl.",
  "id" : 869478591783981056,
  "in_reply_to_status_id" : 869477527571623936,
  "created_at" : "2017-05-30 09:00:25 +0000",
  "in_reply_to_screen_name" : "katebevan",
  "in_reply_to_user_id_str" : "1097161",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bevan",
      "screen_name" : "katebevan",
      "indices" : [ 0, 10 ],
      "id_str" : "1097161",
      "id" : 1097161
    }, {
      "name" : "harpistkat",
      "screen_name" : "harpistkat",
      "indices" : [ 11, 22 ],
      "id_str" : "921330518737739776",
      "id" : 921330518737739776
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 23, 30 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869477246372917249",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229039483368, 8.627517284068864 ]
  },
  "id_str" : "869478365698437124",
  "in_reply_to_user_id" : 1097161,
  "text" : "@katebevan @harpistkat @nature I guess \u201Elobbyist for security products\u201C is the word you\u2019re looking for in that case.  \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 869478365698437124,
  "in_reply_to_status_id" : 869477246372917249,
  "created_at" : "2017-05-30 08:59:31 +0000",
  "in_reply_to_screen_name" : "katebevan",
  "in_reply_to_user_id_str" : "1097161",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bevan",
      "screen_name" : "katebevan",
      "indices" : [ 0, 10 ],
      "id_str" : "1097161",
      "id" : 1097161
    }, {
      "name" : "harpistkat",
      "screen_name" : "harpistkat",
      "indices" : [ 11, 22 ],
      "id_str" : "921330518737739776",
      "id" : 921330518737739776
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 23, 30 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869476541700468736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227219190696, 8.627532440682037 ]
  },
  "id_str" : "869476705135710208",
  "in_reply_to_user_id" : 1097161,
  "text" : "@katebevan @harpistkat @nature that COI at least explains the fetishization of anti virus software  \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 869476705135710208,
  "in_reply_to_status_id" : 869476541700468736,
  "created_at" : "2017-05-30 08:52:55 +0000",
  "in_reply_to_screen_name" : "katebevan",
  "in_reply_to_user_id_str" : "1097161",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bevan",
      "screen_name" : "katebevan",
      "indices" : [ 0, 10 ],
      "id_str" : "1097161",
      "id" : 1097161
    }, {
      "name" : "harpistkat",
      "screen_name" : "harpistkat",
      "indices" : [ 11, 22 ],
      "id_str" : "921330518737739776",
      "id" : 921330518737739776
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 23, 30 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869475821760770050",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233845320723, 8.627498139076952 ]
  },
  "id_str" : "869476438809997312",
  "in_reply_to_user_id" : 1097161,
  "text" : "@katebevan @harpistkat @nature and maybe people are reluctant to pay because they\u2019re asked to do all the heavy lifting in scholarly publishing for free\u2026",
  "id" : 869476438809997312,
  "in_reply_to_status_id" : 869475821760770050,
  "created_at" : "2017-05-30 08:51:51 +0000",
  "in_reply_to_screen_name" : "katebevan",
  "in_reply_to_user_id_str" : "1097161",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bevan",
      "screen_name" : "katebevan",
      "indices" : [ 0, 10 ],
      "id_str" : "1097161",
      "id" : 1097161
    }, {
      "name" : "harpistkat",
      "screen_name" : "harpistkat",
      "indices" : [ 11, 22 ],
      "id_str" : "921330518737739776",
      "id" : 921330518737739776
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 23, 30 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869475924676399104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233845320723, 8.627498139076952 ]
  },
  "id_str" : "869476163504177152",
  "in_reply_to_user_id" : 1097161,
  "text" : "@katebevan @harpistkat @nature iOS, Ubuntu, MacOS, \u2026 don\u2019t see how having antivirus or not absolves the not caring about delivering malware.",
  "id" : 869476163504177152,
  "in_reply_to_status_id" : 869475924676399104,
  "created_at" : "2017-05-30 08:50:46 +0000",
  "in_reply_to_screen_name" : "katebevan",
  "in_reply_to_user_id_str" : "1097161",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bevan",
      "screen_name" : "katebevan",
      "indices" : [ 0, 10 ],
      "id_str" : "1097161",
      "id" : 1097161
    }, {
      "name" : "harpistkat",
      "screen_name" : "harpistkat",
      "indices" : [ 11, 22 ],
      "id_str" : "921330518737739776",
      "id" : 921330518737739776
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 23, 30 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869475077527654404",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233845320723, 8.627498139076952 ]
  },
  "id_str" : "869475815024721921",
  "in_reply_to_user_id" : 1097161,
  "text" : "@katebevan @harpistkat @nature what\u2019s your \u201Eantivirus\u201C-tip for cross-platform avoiding fishy chrome extensions?",
  "id" : 869475815024721921,
  "in_reply_to_status_id" : 869475077527654404,
  "created_at" : "2017-05-30 08:49:23 +0000",
  "in_reply_to_screen_name" : "katebevan",
  "in_reply_to_user_id_str" : "1097161",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bevan",
      "screen_name" : "katebevan",
      "indices" : [ 0, 10 ],
      "id_str" : "1097161",
      "id" : 1097161
    }, {
      "name" : "harpistkat",
      "screen_name" : "harpistkat",
      "indices" : [ 11, 22 ],
      "id_str" : "921330518737739776",
      "id" : 921330518737739776
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 23, 30 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869474998624374784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233845320723, 8.627498139076952 ]
  },
  "id_str" : "869475400677720064",
  "in_reply_to_user_id" : 1097161,
  "text" : "@katebevan @harpistkat @nature which would be fine, if scholarly publishing was journalism, which it isn\u2019t.",
  "id" : 869475400677720064,
  "in_reply_to_status_id" : 869474998624374784,
  "created_at" : "2017-05-30 08:47:44 +0000",
  "in_reply_to_screen_name" : "katebevan",
  "in_reply_to_user_id_str" : "1097161",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bevan",
      "screen_name" : "katebevan",
      "indices" : [ 0, 10 ],
      "id_str" : "1097161",
      "id" : 1097161
    }, {
      "name" : "harpistkat",
      "screen_name" : "harpistkat",
      "indices" : [ 11, 22 ],
      "id_str" : "921330518737739776",
      "id" : 921330518737739776
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 23, 30 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869473608548192256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233845320723, 8.627498139076952 ]
  },
  "id_str" : "869474702145855488",
  "in_reply_to_user_id" : 1097161,
  "text" : "@katebevan @harpistkat @nature I blame them for not caring enough about their customers (who\u2019re paying ridiculous prices for getting access)  \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 869474702145855488,
  "in_reply_to_status_id" : 869473608548192256,
  "created_at" : "2017-05-30 08:44:57 +0000",
  "in_reply_to_screen_name" : "katebevan",
  "in_reply_to_user_id_str" : "1097161",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harpistkat",
      "screen_name" : "harpistkat",
      "indices" : [ 0, 11 ],
      "id_str" : "921330518737739776",
      "id" : 921330518737739776
    }, {
      "name" : "Kate Bevan",
      "screen_name" : "katebevan",
      "indices" : [ 12, 22 ],
      "id_str" : "1097161",
      "id" : 1097161
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 60, 67 ],
      "id_str" : "487833518",
      "id" : 487833518
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 108, 115 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869472507467890688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232200602691, 8.627511729005413 ]
  },
  "id_str" : "869473115520323584",
  "in_reply_to_user_id" : 32588979,
  "text" : "@harpistkat @katebevan thx, point is: ppl have been telling @nature for days &amp; they don\u2019t react. Unless @nature is a soulless bot with no1 reading.",
  "id" : 869473115520323584,
  "in_reply_to_status_id" : 869472507467890688,
  "created_at" : "2017-05-30 08:38:39 +0000",
  "in_reply_to_screen_name" : "Kat_Arney",
  "in_reply_to_user_id_str" : "32588979",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harpistkat",
      "screen_name" : "harpistkat",
      "indices" : [ 3, 14 ],
      "id_str" : "921330518737739776",
      "id" : 921330518737739776
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 62, 69 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "869469967263158272",
  "text" : "RT @harpistkat: This happened to me while I was investigating @nature Reviews V\nCancer sub. V distressing, full virus scan time... https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "nature",
        "screen_name" : "nature",
        "indices" : [ 46, 53 ],
        "id_str" : "487833518",
        "id" : 487833518
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/xdauBO9EzL",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/869463981743906816",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "869468049241452544",
    "text" : "This happened to me while I was investigating @nature Reviews V\nCancer sub. V distressing, full virus scan time... https:\/\/t.co\/xdauBO9EzL",
    "id" : 869468049241452544,
    "created_at" : "2017-05-30 08:18:31 +0000",
    "user" : {
      "name" : "Kat Arney",
      "screen_name" : "Kat_Arney",
      "protected" : false,
      "id_str" : "32588979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875377578529488896\/p1zR7IWI_normal.jpg",
      "id" : 32588979,
      "verified" : true
    }
  },
  "id" : 869469967263158272,
  "created_at" : "2017-05-30 08:26:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harpistkat",
      "screen_name" : "harpistkat",
      "indices" : [ 0, 11 ],
      "id_str" : "921330518737739776",
      "id" : 921330518737739776
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 12, 19 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869468049241452544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232897180302, 8.627510938504704 ]
  },
  "id_str" : "869468554336366592",
  "in_reply_to_user_id" : 32588979,
  "text" : "@harpistkat @nature I can imagine! Had a stressful afternoon with that myself!",
  "id" : 869468554336366592,
  "in_reply_to_status_id" : 869468049241452544,
  "created_at" : "2017-05-30 08:20:31 +0000",
  "in_reply_to_screen_name" : "Kat_Arney",
  "in_reply_to_user_id_str" : "32588979",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Lubetzki",
      "screen_name" : "MLubetzki",
      "indices" : [ 0, 10 ],
      "id_str" : "812252469296300034",
      "id" : 812252469296300034
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 11, 18 ],
      "id_str" : "487833518",
      "id" : 487833518
    }, {
      "name" : "Roy Moger-Reischer",
      "screen_name" : "RoyBoy432",
      "indices" : [ 19, 29 ],
      "id_str" : "2892117213",
      "id" : 2892117213
    }, {
      "name" : "Chad Niederhuth",
      "screen_name" : "niederhuth",
      "indices" : [ 45, 56 ],
      "id_str" : "234847288",
      "id" : 234847288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/yMNklTg8Hm",
      "expanded_url" : "http:\/\/ruleofthirds.de\/nature-malvertising\/",
      "display_url" : "ruleofthirds.de\/nature-malvert\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "868059983493156864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232497226679, 8.627513841517358 ]
  },
  "id_str" : "869463991910846464",
  "in_reply_to_user_id" : 812252469296300034,
  "text" : "@MLubetzki @nature @RoyBoy432 @ResearchDepos @niederhuth still true, see https:\/\/t.co\/yMNklTg8Hm",
  "id" : 869463991910846464,
  "in_reply_to_status_id" : 868059983493156864,
  "created_at" : "2017-05-30 08:02:24 +0000",
  "in_reply_to_screen_name" : "MLubetzki",
  "in_reply_to_user_id_str" : "812252469296300034",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 5, 12 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/yMNklTg8Hm",
      "expanded_url" : "http:\/\/ruleofthirds.de\/nature-malvertising\/",
      "display_url" : "ruleofthirds.de\/nature-malvert\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233556202303, 8.627506374505874 ]
  },
  "id_str" : "869463981743906816",
  "text" : "When @nature pushes Malvertising https:\/\/t.co\/yMNklTg8Hm",
  "id" : 869463981743906816,
  "created_at" : "2017-05-30 08:02:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869437930506395648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17543000173771, 8.628299525015642 ]
  },
  "id_str" : "869438518275313664",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy That. Plus practically it would only apply for new data and would require handrolling some license.",
  "id" : 869438518275313664,
  "in_reply_to_status_id" : 869437930506395648,
  "created_at" : "2017-05-30 06:21:10 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869436016293064704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16608543698691, 8.63228595816403 ]
  },
  "id_str" : "869437396168978432",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy low-key suggestion to do the same for openSNP? ;)",
  "id" : 869437396168978432,
  "in_reply_to_status_id" : 869436016293064704,
  "created_at" : "2017-05-30 06:16:43 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/XKyHr4AIgt",
      "expanded_url" : "http:\/\/search.proquest.com\/openview\/0844cd6a7e6744cba63b4c140f3b5cd0\/1?pq-origsite=gscholar&cbl=18750&diss=y",
      "display_url" : "search.proquest.com\/openview\/0844c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10205485178508, 8.746669804750077 ]
  },
  "id_str" : "869428910022430720",
  "text" : "Apparently someone wrote their Master thesis using openSNP data \uD83C\uDF89 unfortunately it\u2019s not open access. \uD83D\uDE1E https:\/\/t.co\/XKyHr4AIgt",
  "id" : 869428910022430720,
  "created_at" : "2017-05-30 05:43:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/869308069699887105\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/LmjUBoc4a1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DBBnFOVXgAICYQe.jpg",
      "id_str" : "869308067527229442",
      "id" : 869308067527229442,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBBnFOVXgAICYQe.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 265
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 265
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 265
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 265
      } ],
      "display_url" : "pic.twitter.com\/LmjUBoc4a1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/l1AWP2c1gh",
      "expanded_url" : "http:\/\/amzn.eu\/0142eC3",
      "display_url" : "amzn.eu\/0142eC3"
    } ]
  },
  "geo" : { },
  "id_str" : "869308069699887105",
  "text" : "Those made up words! \uD83D\uDC96 https:\/\/t.co\/l1AWP2c1gh https:\/\/t.co\/LmjUBoc4a1",
  "id" : 869308069699887105,
  "created_at" : "2017-05-29 21:42:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11387510831361, 8.75360935468347 ]
  },
  "id_str" : "869303936506884096",
  "text" : "I love Jupyter notebooks as much as the next person, but releasing one on GitHub, doing an \u201Cimport * from XYZ\u201D and calling it pipeline? \uD83E\uDD14",
  "id" : 869303936506884096,
  "created_at" : "2017-05-29 21:26:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/MqYPuefkZ4",
      "expanded_url" : "https:\/\/twitter.com\/NatureNews\/status\/869176570291912705",
      "display_url" : "twitter.com\/NatureNews\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "869286843891757056",
  "text" : "RT @gedankenstuecke: \u00ABIs science only for the rich?\u00BB *charges ~200\u20AC for a yearly, personal subscription*  \u00AF\\_(\u30C4)_\/\u00AF https:\/\/t.co\/MqYPuefkZ4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/MqYPuefkZ4",
        "expanded_url" : "https:\/\/twitter.com\/NatureNews\/status\/869176570291912705",
        "display_url" : "twitter.com\/NatureNews\/sta\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.17226779397712, 8.627538331361034 ]
    },
    "id_str" : "869180878198591489",
    "text" : "\u00ABIs science only for the rich?\u00BB *charges ~200\u20AC for a yearly, personal subscription*  \u00AF\\_(\u30C4)_\/\u00AF https:\/\/t.co\/MqYPuefkZ4",
    "id" : 869180878198591489,
    "created_at" : "2017-05-29 13:17:24 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 869286843891757056,
  "created_at" : "2017-05-29 20:18:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/vyCEBXgmOz",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BUsHD5rFKer\/",
      "display_url" : "instagram.com\/p\/BUsHD5rFKer\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.111926605779, 8.7542334820657 ]
  },
  "id_str" : "869285335376826370",
  "text" : "\u2693\uFE0F\uD83C\uDF03 @ Offenbach Hafeninsel https:\/\/t.co\/vyCEBXgmOz",
  "id" : 869285335376826370,
  "created_at" : "2017-05-29 20:12:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "infinome",
      "screen_name" : "InfinoMe",
      "indices" : [ 0, 9 ],
      "id_str" : "2362226100",
      "id" : 2362226100
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 10, 19 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/10q5ALk2kc",
      "expanded_url" : "https:\/\/thewinnower.com\/papers\/4715-correlating-the-sci-hub-data-with-world-bank-indicators-and-identifying-academic-use",
      "display_url" : "thewinnower.com\/papers\/4715-co\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "869243951697375232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10190288171472, 8.748815173174751 ]
  },
  "id_str" : "869245971733065728",
  "in_reply_to_user_id" : 2362226100,
  "text" : "@InfinoMe @madprime I\u2019ve done that in the past. This started as blog posts and transformed https:\/\/t.co\/10q5ALk2kc",
  "id" : 869245971733065728,
  "in_reply_to_status_id" : 869243951697375232,
  "created_at" : "2017-05-29 17:36:04 +0000",
  "in_reply_to_screen_name" : "InfinoMe",
  "in_reply_to_user_id_str" : "2362226100",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 2, 25 ],
      "url" : "https:\/\/t.co\/YwE82ogALQ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BUrwi6vFhFJ\/",
      "display_url" : "instagram.com\/p\/BUrwi6vFhFJ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "869235817419603968",
  "text" : "\uD83E\uDD8B https:\/\/t.co\/YwE82ogALQ",
  "id" : 869235817419603968,
  "created_at" : "2017-05-29 16:55:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 9, 16 ],
      "id_str" : "487833518",
      "id" : 487833518
    }, {
      "name" : "Chad Niederhuth",
      "screen_name" : "niederhuth",
      "indices" : [ 37, 48 ],
      "id_str" : "234847288",
      "id" : 234847288
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/869224415615123456\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/7LA91XVoRY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DBAa_wlW0AEj3zG.jpg",
      "id_str" : "869224410758172673",
      "id" : 869224410758172673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBAa_wlW0AEj3zG.jpg",
      "sizes" : [ {
        "h" : 254,
        "resize" : "fit",
        "w" : 1637
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 1637
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 106,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/7LA91XVoRY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/cnGv2mhPQf",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/869211573604241412",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "869211573604241412",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723191840199, 8.627516177540635 ]
  },
  "id_str" : "869224415615123456",
  "in_reply_to_user_id" : 14286491,
  "text" : "Visiting @nature.com this afternoon. @niederhuth https:\/\/t.co\/cnGv2mhPQf https:\/\/t.co\/7LA91XVoRY",
  "id" : 869224415615123456,
  "in_reply_to_status_id" : 869211573604241412,
  "created_at" : "2017-05-29 16:10:24 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 3, 13 ],
      "id_str" : "11385492",
      "id" : 11385492
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 15, 31 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "869221266120638466",
  "text" : "RT @jillemery: @gedankenstuecke The history of science in Western culture has been that as a pursuit by men of privilege &amp; means.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "869180878198591489",
    "geo" : { },
    "id_str" : "869221055960727552",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke The history of science in Western culture has been that as a pursuit by men of privilege &amp; means.",
    "id" : 869221055960727552,
    "in_reply_to_status_id" : 869180878198591489,
    "created_at" : "2017-05-29 15:57:03 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "protected" : false,
      "id_str" : "11385492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721430293668704256\/uuScw2u1_normal.jpg",
      "id" : 11385492,
      "verified" : false
    }
  },
  "id" : 869221266120638466,
  "created_at" : "2017-05-29 15:57:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Niederhuth",
      "screen_name" : "niederhuth",
      "indices" : [ 33, 44 ],
      "id_str" : "234847288",
      "id" : 234847288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/k8RZDW3KiB",
      "expanded_url" : "https:\/\/blog.malwarebytes.com\/cybercrime\/2017\/05\/roughted-the-anti-ad-blocker-malvertiser\/",
      "display_url" : "blog.malwarebytes.com\/cybercrime\/201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "869211573604241412",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229786697993, 8.627518174299414 ]
  },
  "id_str" : "869212197792210944",
  "in_reply_to_user_id" : 14286491,
  "text" : "c.f. https:\/\/t.co\/k8RZDW3KiB \/cc @niederhuth",
  "id" : 869212197792210944,
  "in_reply_to_status_id" : 869211573604241412,
  "created_at" : "2017-05-29 15:21:51 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 12, 19 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/VhVMgSd396",
      "expanded_url" : "https:\/\/twitter.com\/niederhuth\/status\/869188314255032320",
      "display_url" : "twitter.com\/niederhuth\/sta\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "869180878198591489",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227824221153, 8.627537884037643 ]
  },
  "id_str" : "869211573604241412",
  "in_reply_to_user_id" : 14286491,
  "text" : "Also: Seems @nature is suffering from malvertising these days\u2026 https:\/\/t.co\/VhVMgSd396",
  "id" : 869211573604241412,
  "in_reply_to_status_id" : 869180878198591489,
  "created_at" : "2017-05-29 15:19:22 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    }, {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 23, 31 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869193319892611072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231369192444, 8.627523173379439 ]
  },
  "id_str" : "869193559588646912",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski paging @punkish who\u2019ll have to say a lot about that by now I guess. :)",
  "id" : 869193559588646912,
  "in_reply_to_status_id" : 869193319892611072,
  "created_at" : "2017-05-29 14:07:48 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Arvestad",
      "screen_name" : "arvestad",
      "indices" : [ 0, 9 ],
      "id_str" : "403987115",
      "id" : 403987115
    }, {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 10, 25 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869186948036014080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229186788789, 8.627528902407091 ]
  },
  "id_str" : "869187782983528448",
  "in_reply_to_user_id" : 403987115,
  "text" : "@arvestad @torstenseemann \u201EWelcome to the first meeting of Coffeeholics Pseudonymous.\u201C",
  "id" : 869187782983528448,
  "in_reply_to_status_id" : 869186948036014080,
  "created_at" : "2017-05-29 13:44:50 +0000",
  "in_reply_to_screen_name" : "arvestad",
  "in_reply_to_user_id_str" : "403987115",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/MqYPuefkZ4",
      "expanded_url" : "https:\/\/twitter.com\/NatureNews\/status\/869176570291912705",
      "display_url" : "twitter.com\/NatureNews\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226779397712, 8.627538331361034 ]
  },
  "id_str" : "869180878198591489",
  "text" : "\u00ABIs science only for the rich?\u00BB *charges ~200\u20AC for a yearly, personal subscription*  \u00AF\\_(\u30C4)_\/\u00AF https:\/\/t.co\/MqYPuefkZ4",
  "id" : 869180878198591489,
  "created_at" : "2017-05-29 13:17:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Arvestad",
      "screen_name" : "arvestad",
      "indices" : [ 0, 9 ],
      "id_str" : "403987115",
      "id" : 403987115
    }, {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 10, 25 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869122993003401216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226532892916, 8.627525627302978 ]
  },
  "id_str" : "869156054348836864",
  "in_reply_to_user_id" : 403987115,
  "text" : "@arvestad @torstenseemann nice to meet you, I\u2019m Bob!",
  "id" : 869156054348836864,
  "in_reply_to_status_id" : 869122993003401216,
  "created_at" : "2017-05-29 11:38:46 +0000",
  "in_reply_to_screen_name" : "arvestad",
  "in_reply_to_user_id_str" : "403987115",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 10, 25 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "869121476712071168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233280269072, 8.627505757881536 ]
  },
  "id_str" : "869123838596050944",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @TheLabAndField fair enough :)",
  "id" : 869123838596050944,
  "in_reply_to_status_id" : 869121476712071168,
  "created_at" : "2017-05-29 09:30:45 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 3, 18 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 20, 36 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "869120035142414337",
  "text" : "RT @TheLabAndField: @gedankenstuecke and other measures of central tendency of production",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "869119404826656768",
    "geo" : { },
    "id_str" : "869119649518149729",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke and other measures of central tendency of production",
    "id" : 869119649518149729,
    "in_reply_to_status_id" : 869119404826656768,
    "created_at" : "2017-05-29 09:14:06 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "protected" : false,
      "id_str" : "1060545835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851184072890167297\/jIBXYvtR_normal.jpg",
      "id" : 1060545835,
      "verified" : false
    }
  },
  "id" : 869120035142414337,
  "created_at" : "2017-05-29 09:15:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/ZbLir8B16N",
      "expanded_url" : "https:\/\/twitter.com\/drugmonkeyblog\/status\/868641593384869888",
      "display_url" : "twitter.com\/drugmonkeyblog\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228855111908, 8.627546705823374 ]
  },
  "id_str" : "869119404826656768",
  "text" : "missing answer: seizing the means of production. https:\/\/t.co\/ZbLir8B16N",
  "id" : 869119404826656768,
  "created_at" : "2017-05-29 09:13:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDDE0 Grant R. Vousden-Dishington",
      "screen_name" : "usethespacebar",
      "indices" : [ 0, 15 ],
      "id_str" : "1244777868",
      "id" : 1244777868
    }, {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "indices" : [ 16, 27 ],
      "id_str" : "1218100328",
      "id" : 1218100328
    }, {
      "name" : "Chris Madan \uD83E\uDDE0",
      "screen_name" : "cMadan",
      "indices" : [ 28, 35 ],
      "id_str" : "11383092",
      "id" : 11383092
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 36, 47 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868949296263057408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401363228072, 8.753383942503712 ]
  },
  "id_str" : "868949561561284608",
  "in_reply_to_user_id" : 1244777868,
  "text" : "@usethespacebar @ChrisFiloG @cMadan @openSNPorg Thanks, good night for now, it\u2019s lateish in Europe. \uD83D\uDE34",
  "id" : 868949561561284608,
  "in_reply_to_status_id" : 868949296263057408,
  "created_at" : "2017-05-28 21:58:14 +0000",
  "in_reply_to_screen_name" : "usethespacebar",
  "in_reply_to_user_id_str" : "1244777868",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDDE0 Grant R. Vousden-Dishington",
      "screen_name" : "usethespacebar",
      "indices" : [ 0, 15 ],
      "id_str" : "1244777868",
      "id" : 1244777868
    }, {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "indices" : [ 16, 27 ],
      "id_str" : "1218100328",
      "id" : 1218100328
    }, {
      "name" : "Chris Madan \uD83E\uDDE0",
      "screen_name" : "cMadan",
      "indices" : [ 28, 35 ],
      "id_str" : "11383092",
      "id" : 11383092
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 36, 47 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 138, 148 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868944361060421632",
  "geo" : { },
  "id_str" : "868947688112496641",
  "in_reply_to_user_id" : 1244777868,
  "text" : "@usethespacebar @ChrisFiloG @cMadan @openSNPorg Good point on the \u201Cwho\u2019s behind this\u201D, should link to that directly from sign-up. Another #mozsprint item appears \uD83D\uDC4D\u263A\uFE0F",
  "id" : 868947688112496641,
  "in_reply_to_status_id" : 868944361060421632,
  "created_at" : "2017-05-28 21:50:47 +0000",
  "in_reply_to_screen_name" : "usethespacebar",
  "in_reply_to_user_id_str" : "1244777868",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDDE0 Grant R. Vousden-Dishington",
      "screen_name" : "usethespacebar",
      "indices" : [ 0, 15 ],
      "id_str" : "1244777868",
      "id" : 1244777868
    }, {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "indices" : [ 16, 27 ],
      "id_str" : "1218100328",
      "id" : 1218100328
    }, {
      "name" : "Chris Madan \uD83E\uDDE0",
      "screen_name" : "cMadan",
      "indices" : [ 28, 35 ],
      "id_str" : "11383092",
      "id" : 11383092
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 36, 47 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868946612705402880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401372752569, 8.753386137001122 ]
  },
  "id_str" : "868946956474880000",
  "in_reply_to_user_id" : 1244777868,
  "text" : "@usethespacebar @ChrisFiloG @cMadan @openSNPorg It\u2019s the first thing if you decide to click \u201Csign up\u201D, brevity makes it more likely ppl read it, compared to Facebook ToS.",
  "id" : 868946956474880000,
  "in_reply_to_status_id" : 868946612705402880,
  "created_at" : "2017-05-28 21:47:53 +0000",
  "in_reply_to_screen_name" : "usethespacebar",
  "in_reply_to_user_id_str" : "1244777868",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDDE0 Grant R. Vousden-Dishington",
      "screen_name" : "usethespacebar",
      "indices" : [ 0, 15 ],
      "id_str" : "1244777868",
      "id" : 1244777868
    }, {
      "name" : "Justin Kiggins",
      "screen_name" : "neuromusic",
      "indices" : [ 16, 27 ],
      "id_str" : "8932272",
      "id" : 8932272
    }, {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "indices" : [ 28, 39 ],
      "id_str" : "1218100328",
      "id" : 1218100328
    }, {
      "name" : "Chris Madan \uD83E\uDDE0",
      "screen_name" : "cMadan",
      "indices" : [ 40, 47 ],
      "id_str" : "11383092",
      "id" : 11383092
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 48, 59 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868945432373633024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401369256516, 8.753384654648713 ]
  },
  "id_str" : "868946335373942786",
  "in_reply_to_user_id" : 1244777868,
  "text" : "@usethespacebar @neuromusic @ChrisFiloG @cMadan @openSNPorg \u2026wanna do it? Cool! Otherwise: we feel you, that\u2019s fine.",
  "id" : 868946335373942786,
  "in_reply_to_status_id" : 868945432373633024,
  "created_at" : "2017-05-28 21:45:25 +0000",
  "in_reply_to_screen_name" : "usethespacebar",
  "in_reply_to_user_id_str" : "1244777868",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDDE0 Grant R. Vousden-Dishington",
      "screen_name" : "usethespacebar",
      "indices" : [ 0, 15 ],
      "id_str" : "1244777868",
      "id" : 1244777868
    }, {
      "name" : "Justin Kiggins",
      "screen_name" : "neuromusic",
      "indices" : [ 16, 27 ],
      "id_str" : "8932272",
      "id" : 8932272
    }, {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "indices" : [ 28, 39 ],
      "id_str" : "1218100328",
      "id" : 1218100328
    }, {
      "name" : "Chris Madan \uD83E\uDDE0",
      "screen_name" : "cMadan",
      "indices" : [ 40, 47 ],
      "id_str" : "11383092",
      "id" : 11383092
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 48, 59 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868945432373633024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401369256516, 8.753384654648713 ]
  },
  "id_str" : "868946252658094080",
  "in_reply_to_user_id" : 1244777868,
  "text" : "@usethespacebar @neuromusic @ChrisFiloG @cMadan @openSNPorg \u2026probability that someone will abuse this, including but not limited to insurance companies, employers, law enforcement, younameit. Still\u2026",
  "id" : 868946252658094080,
  "in_reply_to_status_id" : 868945432373633024,
  "created_at" : "2017-05-28 21:45:05 +0000",
  "in_reply_to_screen_name" : "usethespacebar",
  "in_reply_to_user_id_str" : "1244777868",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDDE0 Grant R. Vousden-Dishington",
      "screen_name" : "usethespacebar",
      "indices" : [ 0, 15 ],
      "id_str" : "1244777868",
      "id" : 1244777868
    }, {
      "name" : "Justin Kiggins",
      "screen_name" : "neuromusic",
      "indices" : [ 16, 27 ],
      "id_str" : "8932272",
      "id" : 8932272
    }, {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "indices" : [ 28, 39 ],
      "id_str" : "1218100328",
      "id" : 1218100328
    }, {
      "name" : "Chris Madan \uD83E\uDDE0",
      "screen_name" : "cMadan",
      "indices" : [ 40, 47 ],
      "id_str" : "11383092",
      "id" : 11383092
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 48, 59 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868945432373633024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401369256516, 8.753384654648713 ]
  },
  "id_str" : "868946029105881088",
  "in_reply_to_user_id" : 1244777868,
  "text" : "@usethespacebar @neuromusic @ChrisFiloG @cMadan @openSNPorg Imho an honest disclaimer on public domain genetic data needs the tl;dr that equals: you lose all control over the data, there\u2019s a non-zero\u2026",
  "id" : 868946029105881088,
  "in_reply_to_status_id" : 868945432373633024,
  "created_at" : "2017-05-28 21:44:12 +0000",
  "in_reply_to_screen_name" : "usethespacebar",
  "in_reply_to_user_id_str" : "1244777868",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDDE0 Grant R. Vousden-Dishington",
      "screen_name" : "usethespacebar",
      "indices" : [ 0, 15 ],
      "id_str" : "1244777868",
      "id" : 1244777868
    }, {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "indices" : [ 16, 27 ],
      "id_str" : "1218100328",
      "id" : 1218100328
    }, {
      "name" : "Chris Madan \uD83E\uDDE0",
      "screen_name" : "cMadan",
      "indices" : [ 28, 35 ],
      "id_str" : "11383092",
      "id" : 11383092
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 36, 47 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/rf7OGc4UiP",
      "expanded_url" : "https:\/\/opensnp.org\/faq",
      "display_url" : "opensnp.org\/faq"
    } ]
  },
  "in_reply_to_status_id_str" : "868944361060421632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401369256516, 8.753384654648713 ]
  },
  "id_str" : "868945645301792768",
  "in_reply_to_user_id" : 1244777868,
  "text" : "@usethespacebar @ChrisFiloG @cMadan @openSNPorg There\u2019s a FAQ https:\/\/t.co\/rf7OGc4UiP",
  "id" : 868945645301792768,
  "in_reply_to_status_id" : 868944361060421632,
  "created_at" : "2017-05-28 21:42:40 +0000",
  "in_reply_to_screen_name" : "usethespacebar",
  "in_reply_to_user_id_str" : "1244777868",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDDE0 Grant R. Vousden-Dishington",
      "screen_name" : "usethespacebar",
      "indices" : [ 0, 15 ],
      "id_str" : "1244777868",
      "id" : 1244777868
    }, {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "indices" : [ 16, 27 ],
      "id_str" : "1218100328",
      "id" : 1218100328
    }, {
      "name" : "Chris Madan \uD83E\uDDE0",
      "screen_name" : "cMadan",
      "indices" : [ 28, 35 ],
      "id_str" : "11383092",
      "id" : 11383092
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 36, 47 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868943918896889860",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401369256516, 8.753384654648713 ]
  },
  "id_str" : "868945237753856001",
  "in_reply_to_user_id" : 1244777868,
  "text" : "@usethespacebar @ChrisFiloG @cMadan @openSNPorg Personally I feel the \u201Cwho knows, this is probably a bad idea\u201D-vibe is the most honest given current knowledge.",
  "id" : 868945237753856001,
  "in_reply_to_status_id" : 868943918896889860,
  "created_at" : "2017-05-28 21:41:03 +0000",
  "in_reply_to_screen_name" : "usethespacebar",
  "in_reply_to_user_id_str" : "1244777868",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "indices" : [ 0, 11 ],
      "id_str" : "1218100328",
      "id" : 1218100328
    }, {
      "name" : "\uD83E\uDDE0 Grant R. Vousden-Dishington",
      "screen_name" : "usethespacebar",
      "indices" : [ 12, 27 ],
      "id_str" : "1244777868",
      "id" : 1244777868
    }, {
      "name" : "Chris Madan \uD83E\uDDE0",
      "screen_name" : "cMadan",
      "indices" : [ 28, 35 ],
      "id_str" : "11383092",
      "id" : 11383092
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 36, 47 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868934711569035264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402320756656, 8.753404791920012 ]
  },
  "id_str" : "868935427901751296",
  "in_reply_to_user_id" : 1218100328,
  "text" : "@ChrisFiloG @usethespacebar @cMadan @openSNPorg And any recommendations on making it more human readable are appreciated a lot!",
  "id" : 868935427901751296,
  "in_reply_to_status_id" : 868934711569035264,
  "created_at" : "2017-05-28 21:02:04 +0000",
  "in_reply_to_screen_name" : "ChrisFiloG",
  "in_reply_to_user_id_str" : "1218100328",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Eckmeier, not that kind of Dr.",
      "screen_name" : "DennisEckmeier",
      "indices" : [ 0, 15 ],
      "id_str" : "595982444",
      "id" : 595982444
    }, {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "indices" : [ 16, 27 ],
      "id_str" : "1218100328",
      "id" : 1218100328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868929568958291968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402246667457, 8.753397289253341 ]
  },
  "id_str" : "868931188324433921",
  "in_reply_to_user_id" : 595982444,
  "text" : "@DennisEckmeier @ChrisFiloG It\u2019s half for your parents as well. And \u201Conly\u201D on average half of your siblings :p",
  "id" : 868931188324433921,
  "in_reply_to_status_id" : 868929568958291968,
  "created_at" : "2017-05-28 20:45:13 +0000",
  "in_reply_to_screen_name" : "DennisEckmeier",
  "in_reply_to_user_id_str" : "595982444",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "indices" : [ 3, 14 ],
      "id_str" : "1218100328",
      "id" : 1218100328
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 48, 59 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/6Kq3DooFee",
      "expanded_url" : "https:\/\/opensnp.org",
      "display_url" : "opensnp.org"
    } ]
  },
  "geo" : { },
  "id_str" : "868928477902364674",
  "text" : "RT @ChrisFiloG: I've donated my genetic data to @openSNPorg. You should too it's a great project! https:\/\/t.co\/6Kq3DooFee",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 32, 43 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/6Kq3DooFee",
        "expanded_url" : "https:\/\/opensnp.org",
        "display_url" : "opensnp.org"
      } ]
    },
    "geo" : { },
    "id_str" : "868920312695357440",
    "text" : "I've donated my genetic data to @openSNPorg. You should too it's a great project! https:\/\/t.co\/6Kq3DooFee",
    "id" : 868920312695357440,
    "created_at" : "2017-05-28 20:02:00 +0000",
    "user" : {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "protected" : false,
      "id_str" : "1218100328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428604938995109888\/FDYSkfdz_normal.jpeg",
      "id" : 1218100328,
      "verified" : false
    }
  },
  "id" : 868928477902364674,
  "created_at" : "2017-05-28 20:34:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868925343947792384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401883204431, 8.753390177014722 ]
  },
  "id_str" : "868926751166132224",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich \uD83D\uDE0D\uD83D\uDE0D\uD83D\uDE0D",
  "id" : 868926751166132224,
  "in_reply_to_status_id" : 868925343947792384,
  "created_at" : "2017-05-28 20:27:36 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "indices" : [ 0, 11 ],
      "id_str" : "1218100328",
      "id" : 1218100328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868920312695357440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392762405057, 8.753530131073568 ]
  },
  "id_str" : "868924311658262532",
  "in_reply_to_user_id" : 1218100328,
  "text" : "@ChrisFiloG Thanks so much!",
  "id" : 868924311658262532,
  "in_reply_to_status_id" : 868920312695357440,
  "created_at" : "2017-05-28 20:17:54 +0000",
  "in_reply_to_screen_name" : "ChrisFiloG",
  "in_reply_to_user_id_str" : "1218100328",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/868851966851641346\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/IB3vJ2mQsV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DA7IQh1XYAAVdx2.jpg",
      "id_str" : "868851964414746624",
      "id" : 868851964414746624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DA7IQh1XYAAVdx2.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/IB3vJ2mQsV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "868851966851641346",
  "text" : "I've seen a lot of pronunciations and spellings. But that's a first. https:\/\/t.co\/IB3vJ2mQsV",
  "id" : 868851966851641346,
  "created_at" : "2017-05-28 15:30:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868851222387806210",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402410881134, 8.753398539267355 ]
  },
  "id_str" : "868851301765054464",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime That must have been hard!",
  "id" : 868851301765054464,
  "in_reply_to_status_id" : 868851222387806210,
  "created_at" : "2017-05-28 15:27:47 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868850147266093056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11386743751365, 8.753385012977526 ]
  },
  "id_str" : "868850565014581249",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime Did you stick to that?",
  "id" : 868850565014581249,
  "in_reply_to_status_id" : 868850147266093056,
  "created_at" : "2017-05-28 15:24:51 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/MnXIYqrOr9",
      "expanded_url" : "http:\/\/dogswithtonguestickingoutalittle.tumblr.com\/post\/161109869944",
      "display_url" : "\u2026thtonguestickingoutalittle.tumblr.com\/post\/161109869\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "868849559967019012",
  "text" : "Me given the current temperature. https:\/\/t.co\/MnXIYqrOr9",
  "id" : 868849559967019012,
  "created_at" : "2017-05-28 15:20:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KnitYak",
      "screen_name" : "KnitYak",
      "indices" : [ 3, 11 ],
      "id_str" : "3189400520",
      "id" : 3189400520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "868846967438356482",
  "text" : "RT @KnitYak: here are some of the first scarves off the production line! they will get their ends sewn in and get lightly steamed before sh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KnitYak\/status\/868843207810981888\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/KTkWlfSqHV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DA7AQZ9VYAEN2ep.jpg",
        "id_str" : "868843166207664129",
        "id" : 868843166207664129,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DA7AQZ9VYAEN2ep.jpg",
        "sizes" : [ {
          "h" : 421,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 742,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1267,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1267,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/KTkWlfSqHV"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/KnitYak\/status\/868843207810981888\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/KTkWlfSqHV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DA7AOS5UwAAO6s7.jpg",
        "id_str" : "868843129952059392",
        "id" : 868843129952059392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DA7AOS5UwAAO6s7.jpg",
        "sizes" : [ {
          "h" : 3024,
          "resize" : "fit",
          "w" : 4032
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/KTkWlfSqHV"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/KnitYak\/status\/868843207810981888\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/KTkWlfSqHV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DA7AQbSUMAAukv4.jpg",
        "id_str" : "868843166564102144",
        "id" : 868843166564102144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DA7AQbSUMAAukv4.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/KTkWlfSqHV"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/KnitYak\/status\/868843207810981888\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/KTkWlfSqHV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DA7AOTxVwAAZPuY.jpg",
        "id_str" : "868843130187005952",
        "id" : 868843130187005952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DA7AOTxVwAAZPuY.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 3024,
          "resize" : "fit",
          "w" : 3024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/KTkWlfSqHV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "868841132410548225",
    "geo" : { },
    "id_str" : "868843207810981888",
    "in_reply_to_user_id" : 3189400520,
    "text" : "here are some of the first scarves off the production line! they will get their ends sewn in and get lightly steamed before shipping :) \u2702\uFE0F\uD83C\uDF81\uD83D\uDCEC https:\/\/t.co\/KTkWlfSqHV",
    "id" : 868843207810981888,
    "in_reply_to_status_id" : 868841132410548225,
    "created_at" : "2017-05-28 14:55:37 +0000",
    "in_reply_to_screen_name" : "KnitYak",
    "in_reply_to_user_id_str" : "3189400520",
    "user" : {
      "name" : "KnitYak",
      "screen_name" : "KnitYak",
      "protected" : false,
      "id_str" : "3189400520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/878324473140609025\/O8JDs8Yu_normal.jpg",
      "id" : 3189400520,
      "verified" : false
    }
  },
  "id" : 868846967438356482,
  "created_at" : "2017-05-28 15:10:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KnitYak",
      "screen_name" : "KnitYak",
      "indices" : [ 3, 11 ],
      "id_str" : "3189400520",
      "id" : 3189400520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "868846945095307264",
  "text" : "RT @KnitYak: production has started! here\u2019s one of your scarves being knit on the machine! highest funding amount backers\u2019 items will ship\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KnitYak\/status\/868841132410548225\/video\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/DRQj4btUuu",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/868840881138184192\/pu\/img\/U2s49zWFuAblnvDK.jpg",
        "id_str" : "868840881138184192",
        "id" : 868840881138184192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/868840881138184192\/pu\/img\/U2s49zWFuAblnvDK.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/DRQj4btUuu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "868841132410548225",
    "text" : "production has started! here\u2019s one of your scarves being knit on the machine! highest funding amount backers\u2019 items will ship first. \u2728\uD83D\uDEA8\uD83D\uDCE6\u2728 https:\/\/t.co\/DRQj4btUuu",
    "id" : 868841132410548225,
    "created_at" : "2017-05-28 14:47:22 +0000",
    "user" : {
      "name" : "KnitYak",
      "screen_name" : "KnitYak",
      "protected" : false,
      "id_str" : "3189400520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/878324473140609025\/O8JDs8Yu_normal.jpg",
      "id" : 3189400520,
      "verified" : false
    }
  },
  "id" : 868846945095307264,
  "created_at" : "2017-05-28 15:10:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/IF3pMrXSD5",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BUowos3lNDa\/",
      "display_url" : "instagram.com\/p\/BUowos3lNDa\/"
    } ]
  },
  "geo" : { },
  "id_str" : "868814371132248065",
  "text" : "Fiery the angels fell. Deep thunder rolled around their shoulders\u2026 https:\/\/t.co\/IF3pMrXSD5",
  "id" : 868814371132248065,
  "created_at" : "2017-05-28 13:01:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/678w8lSb7W",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BUoi3nQljT5\/",
      "display_url" : "instagram.com\/p\/BUoi3nQljT5\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11372, 8.78222 ]
  },
  "id_str" : "868783531136339969",
  "text" : "Sunny \u2600\uFE0F @ Mainpromenade https:\/\/t.co\/678w8lSb7W",
  "id" : 868783531136339969,
  "created_at" : "2017-05-28 10:58:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Durags & Dialectics",
      "screen_name" : "Hood_Biologist",
      "indices" : [ 3, 18 ],
      "id_str" : "255545898",
      "id" : 255545898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "868779568970301440",
  "text" : "RT @Hood_Biologist: Jim Watson is a eugenicist. Eugenicists are supposed get censored, its a moral + political responsibility. Either that\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/vioJPzlSew",
        "expanded_url" : "https:\/\/twitter.com\/nccomfort\/status\/868550822375952384",
        "display_url" : "twitter.com\/nccomfort\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "868723704221532161",
    "text" : "Jim Watson is a eugenicist. Eugenicists are supposed get censored, its a moral + political responsibility. Either that or catch these hands. https:\/\/t.co\/vioJPzlSew",
    "id" : 868723704221532161,
    "created_at" : "2017-05-28 07:00:45 +0000",
    "user" : {
      "name" : "Durags & Dialectics",
      "screen_name" : "Hood_Biologist",
      "protected" : false,
      "id_str" : "255545898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929821052414431232\/0XxiWp06_normal.jpg",
      "id" : 255545898,
      "verified" : false
    }
  },
  "id" : 868779568970301440,
  "created_at" : "2017-05-28 10:42:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868692283037757441",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393877881616, 8.752974175364516 ]
  },
  "id_str" : "868732481511489541",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg \uD83D\uDE4F\uD83D\uDC4D",
  "id" : 868732481511489541,
  "in_reply_to_status_id" : 868692283037757441,
  "created_at" : "2017-05-28 07:35:38 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/FQaB2WGW69",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/genotype_relatedness",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "868667724070780928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11395164715733, 8.753109528693928 ]
  },
  "id_str" : "868731280179032064",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime I played around with it a bit. The code\u2019s here: https:\/\/t.co\/FQaB2WGW69",
  "id" : 868731280179032064,
  "in_reply_to_status_id" : 868667724070780928,
  "created_at" : "2017-05-28 07:30:52 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim van der Zee",
      "screen_name" : "Research_Tim",
      "indices" : [ 3, 16 ],
      "id_str" : "996020192",
      "id" : 996020192
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Research_Tim\/status\/868563495012446208\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/h9A5c03p2q",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DA3Bt7GW0AAtixI.jpg",
      "id_str" : "868563297855000576",
      "id" : 868563297855000576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DA3Bt7GW0AAtixI.jpg",
      "sizes" : [ {
        "h" : 204,
        "resize" : "fit",
        "w" : 356
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 356
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 356
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 356
      } ],
      "display_url" : "pic.twitter.com\/h9A5c03p2q"
    } ],
    "hashtags" : [ {
      "text" : "aps17bos",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "868583794995073026",
  "text" : "RT @Research_Tim: \"My precious\", psychologist panda mumbles as he massages his data. #aps17bos https:\/\/t.co\/h9A5c03p2q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Research_Tim\/status\/868563495012446208\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/h9A5c03p2q",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DA3Bt7GW0AAtixI.jpg",
        "id_str" : "868563297855000576",
        "id" : 868563297855000576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DA3Bt7GW0AAtixI.jpg",
        "sizes" : [ {
          "h" : 204,
          "resize" : "fit",
          "w" : 356
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 356
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 356
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 356
        } ],
        "display_url" : "pic.twitter.com\/h9A5c03p2q"
      } ],
      "hashtags" : [ {
        "text" : "aps17bos",
        "indices" : [ 67, 76 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "868560371602391041",
    "geo" : { },
    "id_str" : "868563495012446208",
    "in_reply_to_user_id" : 996020192,
    "text" : "\"My precious\", psychologist panda mumbles as he massages his data. #aps17bos https:\/\/t.co\/h9A5c03p2q",
    "id" : 868563495012446208,
    "in_reply_to_status_id" : 868560371602391041,
    "created_at" : "2017-05-27 20:24:08 +0000",
    "in_reply_to_screen_name" : "Research_Tim",
    "in_reply_to_user_id_str" : "996020192",
    "user" : {
      "name" : "Tim van der Zee",
      "screen_name" : "Research_Tim",
      "protected" : false,
      "id_str" : "996020192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/856183017039175680\/38u_WIGX_normal.jpg",
      "id" : 996020192,
      "verified" : false
    }
  },
  "id" : 868583794995073026,
  "created_at" : "2017-05-27 21:44:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/868499949004214272\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/1YysN0ZWe5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DA2IGcPXgAA_V89.jpg",
      "id_str" : "868499947393613824",
      "id" : 868499947393613824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DA2IGcPXgAA_V89.jpg",
      "sizes" : [ {
        "h" : 520,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/1YysN0ZWe5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "868499949004214272",
  "text" : "Weekend reading on post-truth, from The Origins of Totalitarianism. https:\/\/t.co\/1YysN0ZWe5",
  "id" : 868499949004214272,
  "created_at" : "2017-05-27 16:11:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868497823783804929",
  "geo" : { },
  "id_str" : "868499538398597120",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez crispier!",
  "id" : 868499538398597120,
  "in_reply_to_status_id" : 868497823783804929,
  "created_at" : "2017-05-27 16:10:00 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/tDdNmCanRV",
      "expanded_url" : "https:\/\/twitter.com\/reaIbaes\/status\/868150018796126208",
      "display_url" : "twitter.com\/reaIbaes\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11378248062582, 8.75322951178268 ]
  },
  "id_str" : "868490617457922049",
  "text" : "What bioinformaticians really do: https:\/\/t.co\/tDdNmCanRV",
  "id" : 868490617457922049,
  "created_at" : "2017-05-27 15:34:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11380316870325, 8.75323861929461 ]
  },
  "id_str" : "868464287509032962",
  "text" : "\u00ABIf it wasn\u2019t for Stallman\u2019s talk this wedding wouldn\u2019t happen. Do you think we should get the GNU logos engraved in the rings?\u00BB \uD83D\uDC8D\uD83D\uDC03",
  "id" : 868464287509032962,
  "created_at" : "2017-05-27 13:49:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VALIUM",
      "screen_name" : "alibi_rage",
      "indices" : [ 0, 11 ],
      "id_str" : "971867420",
      "id" : 971867420
    }, {
      "name" : "Ranting @branleb",
      "screen_name" : "rantleb",
      "indices" : [ 12, 20 ],
      "id_str" : "748130881",
      "id" : 748130881
    }, {
      "name" : "Ragetina",
      "screen_name" : "Ragetina",
      "indices" : [ 21, 30 ],
      "id_str" : "819601236",
      "id" : 819601236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868414111608078337",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11378523283886, 8.753262200948653 ]
  },
  "id_str" : "868427861392326657",
  "in_reply_to_user_id" : 971867420,
  "text" : "@alibi_rage @rantleb @Ragetina Yay!",
  "id" : 868427861392326657,
  "in_reply_to_status_id" : 868414111608078337,
  "created_at" : "2017-05-27 11:25:11 +0000",
  "in_reply_to_screen_name" : "alibi_rage",
  "in_reply_to_user_id_str" : "971867420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "Tristan Bekinschtein",
      "screen_name" : "TrikBek",
      "indices" : [ 11, 19 ],
      "id_str" : "566777918",
      "id" : 566777918
    }, {
      "name" : "Whitaker Lab",
      "screen_name" : "Whitaker_Lab",
      "indices" : [ 20, 33 ],
      "id_str" : "816578659603648512",
      "id" : 816578659603648512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868427536316993536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11378523283886, 8.753262200948653 ]
  },
  "id_str" : "868427835970605056",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j @TrikBek @Whitaker_Lab Same here! And fear that I become the same kind of person that makes others feel that need. Thus the footer.",
  "id" : 868427835970605056,
  "in_reply_to_status_id" : 868427536316993536,
  "created_at" : "2017-05-27 11:25:05 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Haendel",
      "screen_name" : "ontowonka",
      "indices" : [ 0, 10 ],
      "id_str" : "777135943",
      "id" : 777135943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868283044322394112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402300770109, 8.753389057254077 ]
  },
  "id_str" : "868370571368779777",
  "in_reply_to_user_id" : 777135943,
  "text" : "@ontowonka That too!",
  "id" : 868370571368779777,
  "in_reply_to_status_id" : 868283044322394112,
  "created_at" : "2017-05-27 07:37:32 +0000",
  "in_reply_to_screen_name" : "ontowonka",
  "in_reply_to_user_id_str" : "777135943",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868201707888664576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402322365326, 8.753388621892702 ]
  },
  "id_str" : "868202313344856064",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j Yes, especially with people who\u2019re traveling a lot and you never even know which TZ they are in.",
  "id" : 868202313344856064,
  "in_reply_to_status_id" : 868201707888664576,
  "created_at" : "2017-05-26 20:28:56 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868201523544825856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402030986485, 8.753389467159467 ]
  },
  "id_str" : "868202138366865410",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j I did the PR from my phone after having dinner and sitting outside in the garden! \uD83C\uDF3B\uD83E\uDD57",
  "id" : 868202138366865410,
  "in_reply_to_status_id" : 868201523544825856,
  "created_at" : "2017-05-26 20:28:14 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868199180929576961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11414270634523, 8.753295114177215 ]
  },
  "id_str" : "868200704430788608",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j And can\u2019t escape the irony of all of this happening well after working hours on a Friday night. \uD83D\uDE02",
  "id" : 868200704430788608,
  "in_reply_to_status_id" : 868199180929576961,
  "created_at" : "2017-05-26 20:22:32 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868199180929576961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393576605968, 8.753411055660099 ]
  },
  "id_str" : "868199761215664128",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j Too bad there aren\u2019t PRs on Twitter ;)",
  "id" : 868199761215664128,
  "in_reply_to_status_id" : 868199180929576961,
  "created_at" : "2017-05-26 20:18:48 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/kw0nDvNT8V",
      "expanded_url" : "https:\/\/twitter.com\/kirstie_j\/status\/868198911911100416",
      "display_url" : "twitter.com\/kirstie_j\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393470117763, 8.753412756560737 ]
  },
  "id_str" : "868199712003948545",
  "text" : "Working on this, every day! \uD83C\uDF89\uD83D\uDC96 https:\/\/t.co\/kw0nDvNT8V",
  "id" : 868199712003948545,
  "created_at" : "2017-05-26 20:18:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "Mark Kunitomi",
      "screen_name" : "MarkKunitomi",
      "indices" : [ 11, 24 ],
      "id_str" : "2834586230",
      "id" : 2834586230
    }, {
      "name" : "Whitaker Lab",
      "screen_name" : "Whitaker_Lab",
      "indices" : [ 25, 38 ],
      "id_str" : "816578659603648512",
      "id" : 816578659603648512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868187611940126721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11384008939363, 8.75332711203711 ]
  },
  "id_str" : "868187840378744832",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j @MarkKunitomi @Whitaker_Lab That\u2019s why we\u2019re doing open! \u263A\uFE0F",
  "id" : 868187840378744832,
  "in_reply_to_status_id" : 868187611940126721,
  "created_at" : "2017-05-26 19:31:25 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Kunitomi",
      "screen_name" : "MarkKunitomi",
      "indices" : [ 0, 13 ],
      "id_str" : "2834586230",
      "id" : 2834586230
    }, {
      "name" : "Whitaker Lab",
      "screen_name" : "Whitaker_Lab",
      "indices" : [ 14, 27 ],
      "id_str" : "816578659603648512",
      "id" : 816578659603648512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/jPzjZtHZPR",
      "expanded_url" : "https:\/\/github.com\/WhitakerLab\/Onboarding\/pull\/1",
      "display_url" : "github.com\/WhitakerLab\/On\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "868186014879055872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11384750996471, 8.753279027398364 ]
  },
  "id_str" : "868186983495065600",
  "in_reply_to_user_id" : 2834586230,
  "text" : "@MarkKunitomi @Whitaker_Lab I took the liberty of doing a PR for it. :) https:\/\/t.co\/jPzjZtHZPR",
  "id" : 868186983495065600,
  "in_reply_to_status_id" : 868186014879055872,
  "created_at" : "2017-05-26 19:28:01 +0000",
  "in_reply_to_screen_name" : "MarkKunitomi",
  "in_reply_to_user_id_str" : "2834586230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/868183282277646338\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/GYzca0GWAQ",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DAxoFTNW0AEcZ6X.jpg",
      "id_str" : "868183268440592385",
      "id" : 868183268440592385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DAxoFTNW0AEcZ6X.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/GYzca0GWAQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "868183282277646338",
  "text" : "When you buy an \uD83E\uDD51 that's not ripe &amp; it dawns on you that you'll now be without any home and without tasty food. https:\/\/t.co\/GYzca0GWAQ",
  "id" : 868183282277646338,
  "created_at" : "2017-05-26 19:13:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 49, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/69GDNras9I",
      "expanded_url" : "https:\/\/gitter.im\/openSNP\/snpr",
      "display_url" : "gitter.im\/openSNP\/snpr"
    }, {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/28RVdawT9c",
      "expanded_url" : "https:\/\/twitter.com\/MozOpenLeaders\/status\/868164333049700353",
      "display_url" : "twitter.com\/MozOpenLeaders\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139390733727, 8.753525757628703 ]
  },
  "id_str" : "868169345540730883",
  "text" : "We\u2019re fun. Talk to us at https:\/\/t.co\/69GDNras9I #mozsprint https:\/\/t.co\/28RVdawT9c",
  "id" : 868169345540730883,
  "created_at" : "2017-05-26 18:17:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/2Xod5l5XoZ",
      "expanded_url" : "https:\/\/twitter.com\/Whitaker_Lab\/status\/867990107516583938",
      "display_url" : "twitter.com\/Whitaker_Lab\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "868161202928660480",
  "text" : "RT @gedankenstuecke: I wish all labs would have a code of conduct that includes expectation setting! https:\/\/t.co\/2Xod5l5XoZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/2Xod5l5XoZ",
        "expanded_url" : "https:\/\/twitter.com\/Whitaker_Lab\/status\/867990107516583938",
        "display_url" : "twitter.com\/Whitaker_Lab\/s\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.11406629402237, 8.753462398536803 ]
    },
    "id_str" : "868049261472215040",
    "text" : "I wish all labs would have a code of conduct that includes expectation setting! https:\/\/t.co\/2Xod5l5XoZ",
    "id" : 868049261472215040,
    "created_at" : "2017-05-26 10:20:46 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 868161202928660480,
  "created_at" : "2017-05-26 17:45:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 0, 5 ],
      "id_str" : "9377892",
      "id" : 9377892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/uCkQzRvuzO",
      "expanded_url" : "https:\/\/giphy.com\/gifs\/magic-nWnZFJvKPlhjq",
      "display_url" : "giphy.com\/gifs\/magic-nWn\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "868119907199832065",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05115901360709, 8.57191451768804 ]
  },
  "id_str" : "868121458140172288",
  "in_reply_to_user_id" : 9377892,
  "text" : "@tpoi https:\/\/t.co\/uCkQzRvuzO",
  "id" : 868121458140172288,
  "in_reply_to_status_id" : 868119907199832065,
  "created_at" : "2017-05-26 15:07:39 +0000",
  "in_reply_to_screen_name" : "tpoi",
  "in_reply_to_user_id_str" : "9377892",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 0, 5 ],
      "id_str" : "9377892",
      "id" : 9377892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868116378619957249",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05103182983589, 8.571546077736254 ]
  },
  "id_str" : "868119532224876544",
  "in_reply_to_user_id" : 9377892,
  "text" : "@tpoi There\u2019s also \u201Csave as draft\u201D",
  "id" : 868119532224876544,
  "in_reply_to_status_id" : 868116378619957249,
  "created_at" : "2017-05-26 15:00:00 +0000",
  "in_reply_to_screen_name" : "tpoi",
  "in_reply_to_user_id_str" : "9377892",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 3, 13 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/fSMvewh55l",
      "expanded_url" : "http:\/\/bit.ly\/2rmuvqd",
      "display_url" : "bit.ly\/2rmuvqd"
    } ]
  },
  "geo" : { },
  "id_str" : "868117873373454337",
  "text" : "RT @kaythaney: I'm just going to leave this here. https:\/\/t.co\/fSMvewh55l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/fSMvewh55l",
        "expanded_url" : "http:\/\/bit.ly\/2rmuvqd",
        "display_url" : "bit.ly\/2rmuvqd"
      } ]
    },
    "geo" : { },
    "id_str" : "868112759350800384",
    "text" : "I'm just going to leave this here. https:\/\/t.co\/fSMvewh55l",
    "id" : 868112759350800384,
    "created_at" : "2017-05-26 14:33:05 +0000",
    "user" : {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "protected" : false,
      "id_str" : "22839233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932288468029509632\/_I0e0wgc_normal.jpg",
      "id" : 22839233,
      "verified" : false
    }
  },
  "id" : 868117873373454337,
  "created_at" : "2017-05-26 14:53:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/JAildyVQkG",
      "expanded_url" : "https:\/\/twitter.com\/MATLAB\/status\/868090681448857600",
      "display_url" : "twitter.com\/MATLAB\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08761554047403, 8.631529001891868 ]
  },
  "id_str" : "868115635372511233",
  "text" : "28) Replace it with a free &amp; open source alternative. https:\/\/t.co\/JAildyVQkG",
  "id" : 868115635372511233,
  "created_at" : "2017-05-26 14:44:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 39, 47 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868095664563081217",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406509354372, 8.753454577269661 ]
  },
  "id_str" : "868096716335173632",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim don\u2019t tell me you\u2019re ditching #mozfest for PyCon!",
  "id" : 868096716335173632,
  "in_reply_to_status_id" : 868095664563081217,
  "created_at" : "2017-05-26 13:29:20 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868095664563081217",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403009871277, 8.753397590321152 ]
  },
  "id_str" : "868095768053374976",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim Well, it\u2019s not officially our home turf yet?",
  "id" : 868095768053374976,
  "in_reply_to_status_id" : 868095664563081217,
  "created_at" : "2017-05-26 13:25:34 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868087453990744064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10749811311262, 8.7708993349306 ]
  },
  "id_str" : "868087785416273920",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim I think we don\u2019t have to look further than #mozfest?",
  "id" : 868087785416273920,
  "in_reply_to_status_id" : 868087453990744064,
  "created_at" : "2017-05-26 12:53:50 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 11, 23 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 24, 34 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868084990084513792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11153408330875, 8.781330445789528 ]
  },
  "id_str" : "868085448345882624",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j @ctitusbrown @biocrusoe Fully agree to how that makes it easier.",
  "id" : 868085448345882624,
  "in_reply_to_status_id" : 868084990084513792,
  "created_at" : "2017-05-26 12:44:33 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 11, 23 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 24, 34 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868083893253156864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1163819665556, 8.781217290096713 ]
  },
  "id_str" : "868084074115719168",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j @ctitusbrown @biocrusoe Thanks for asking, confused as well :)",
  "id" : 868084074115719168,
  "in_reply_to_status_id" : 868083893253156864,
  "created_at" : "2017-05-26 12:39:06 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868073475273097216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10756487497138, 8.772762464367572 ]
  },
  "id_str" : "868073860872196096",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim Any conference plans? ;)",
  "id" : 868073860872196096,
  "in_reply_to_status_id" : 868073475273097216,
  "created_at" : "2017-05-26 11:58:31 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/2Xod5l5XoZ",
      "expanded_url" : "https:\/\/twitter.com\/Whitaker_Lab\/status\/867990107516583938",
      "display_url" : "twitter.com\/Whitaker_Lab\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406629402237, 8.753462398536803 ]
  },
  "id_str" : "868049261472215040",
  "text" : "I wish all labs would have a code of conduct that includes expectation setting! https:\/\/t.co\/2Xod5l5XoZ",
  "id" : 868049261472215040,
  "created_at" : "2017-05-26 10:20:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 3, 16 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 120, 131 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "data",
      "indices" : [ 31, 36 ]
    }, {
      "text" : "genomics",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "868047151645040640",
  "text" : "RT @repositiveio: ... 'an open #data sharing approach to #genomics feels like a breath of fresh air'. We agree! Do you? @openSNPorg: \n http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 102, 113 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "data",
        "indices" : [ 13, 18 ]
      }, {
        "text" : "genomics",
        "indices" : [ 39, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/OaNGgHZI7f",
        "expanded_url" : "http:\/\/buff.ly\/2q3HwzP",
        "display_url" : "buff.ly\/2q3HwzP"
      } ]
    },
    "geo" : { },
    "id_str" : "867772320475119616",
    "text" : "... 'an open #data sharing approach to #genomics feels like a breath of fresh air'. We agree! Do you? @openSNPorg: \n https:\/\/t.co\/OaNGgHZI7f",
    "id" : 867772320475119616,
    "created_at" : "2017-05-25 16:00:18 +0000",
    "user" : {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "protected" : false,
      "id_str" : "3059929578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661114195753230336\/N89yr0lj_normal.png",
      "id" : 3059929578,
      "verified" : false
    }
  },
  "id" : 868047151645040640,
  "created_at" : "2017-05-26 10:12:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "868045335079288832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406341020125, 8.75344574946315 ]
  },
  "id_str" : "868045776131416064",
  "in_reply_to_user_id" : 14286491,
  "text" : "And no worries if you\u2019re not a super technical person. We do have issues that require little\/no knowledge of such things. #mozsprint",
  "id" : 868045776131416064,
  "in_reply_to_status_id" : 868045335079288832,
  "created_at" : "2017-05-26 10:06:55 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 50, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/fuF76Ed7Vl",
      "expanded_url" : "https:\/\/github.com\/openSNP\/snpr\/issues?q=is%3Aissue+is%3Aopen+label%3Amozsprint",
      "display_url" : "github.com\/openSNP\/snpr\/i\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406343060609, 8.753445695037332 ]
  },
  "id_str" : "868045335079288832",
  "text" : "Interesting in contributing to openSNP during the #mozsprint on June 1st\/2nd? We got a curated list of issues. https:\/\/t.co\/fuF76Ed7Vl",
  "id" : 868045335079288832,
  "created_at" : "2017-05-26 10:05:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "Whitaker Lab",
      "screen_name" : "Whitaker_Lab",
      "indices" : [ 11, 24 ],
      "id_str" : "816578659603648512",
      "id" : 816578659603648512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867997077363724288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403304683439, 8.753401382896252 ]
  },
  "id_str" : "868010227052015616",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j @Whitaker_Lab Glad it has some impact!",
  "id" : 868010227052015616,
  "in_reply_to_status_id" : 867997077363724288,
  "created_at" : "2017-05-26 07:45:39 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "Whitaker Lab",
      "screen_name" : "Whitaker_Lab",
      "indices" : [ 11, 24 ],
      "id_str" : "816578659603648512",
      "id" : 816578659603648512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867995883249426432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11394718560124, 8.753518490074683 ]
  },
  "id_str" : "867996471001456640",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j @Whitaker_Lab Yes! And awesome to see you\u2019re  a) having the CoC and b) are citing my email footer \uD83D\uDE02",
  "id" : 867996471001456640,
  "in_reply_to_status_id" : 867995883249426432,
  "created_at" : "2017-05-26 06:50:59 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "Whitaker Lab",
      "screen_name" : "Whitaker_Lab",
      "indices" : [ 11, 24 ],
      "id_str" : "816578659603648512",
      "id" : 816578659603648512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867988876480008193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403283004899, 8.753402992371733 ]
  },
  "id_str" : "867995703615901696",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j @Whitaker_Lab Oh, that\u2019s great! Can\u2019t take the credit for coming up with it though. Saw the idea on twitter and put it in! :)",
  "id" : 867995703615901696,
  "in_reply_to_status_id" : 867988876480008193,
  "created_at" : "2017-05-26 06:47:56 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867720210618474497",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11167088001741, 8.755623740110384 ]
  },
  "id_str" : "867720518383935489",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim \uD83D\uDE22",
  "id" : 867720518383935489,
  "in_reply_to_status_id" : 867720210618474497,
  "created_at" : "2017-05-25 12:34:27 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nextgenseek",
      "screen_name" : "nextgenseek",
      "indices" : [ 3, 15 ],
      "id_str" : "466062053",
      "id" : 466062053
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 77, 85 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Lior Pachter",
      "screen_name" : "lpachter",
      "indices" : [ 92, 101 ],
      "id_str" : "31936449",
      "id" : 31936449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/k5bO6g9ytH",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2017\/05\/23\/141267",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "867708798898712576",
  "text" : "RT @nextgenseek: Association Mapping From Sequencing Reads Using K-mers from @mbeisen &amp; @lpachter lab https:\/\/t.co\/k5bO6g9ytH https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Eisen",
        "screen_name" : "mbeisen",
        "indices" : [ 60, 68 ],
        "id_str" : "19843630",
        "id" : 19843630
      }, {
        "name" : "Lior Pachter",
        "screen_name" : "lpachter",
        "indices" : [ 75, 84 ],
        "id_str" : "31936449",
        "id" : 31936449
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nextgenseek\/status\/867529508643123200\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/iEt1r8Zqh2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DAoVaeCXkAEjgJX.jpg",
        "id_str" : "867529422706020353",
        "id" : 867529422706020353,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAoVaeCXkAEjgJX.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 838,
          "resize" : "fit",
          "w" : 788
        }, {
          "h" : 838,
          "resize" : "fit",
          "w" : 788
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 838,
          "resize" : "fit",
          "w" : 788
        } ],
        "display_url" : "pic.twitter.com\/iEt1r8Zqh2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/k5bO6g9ytH",
        "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2017\/05\/23\/141267",
        "display_url" : "biorxiv.org\/content\/early\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "867529508643123200",
    "text" : "Association Mapping From Sequencing Reads Using K-mers from @mbeisen &amp; @lpachter lab https:\/\/t.co\/k5bO6g9ytH https:\/\/t.co\/iEt1r8Zqh2",
    "id" : 867529508643123200,
    "created_at" : "2017-05-24 23:55:27 +0000",
    "user" : {
      "name" : "nextgenseek",
      "screen_name" : "nextgenseek",
      "protected" : false,
      "id_str" : "466062053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484777870032502784\/NpvD2IrO_normal.jpeg",
      "id" : 466062053,
      "verified" : false
    }
  },
  "id" : 867708798898712576,
  "created_at" : "2017-05-25 11:47:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867676666738479108",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11369569231766, 8.751533534385963 ]
  },
  "id_str" : "867703415450763264",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim Staying here for a while?",
  "id" : 867703415450763264,
  "in_reply_to_status_id" : 867676666738479108,
  "created_at" : "2017-05-25 11:26:30 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 9, 16 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867606513354907648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403424751096, 8.753399680556926 ]
  },
  "id_str" : "867664611201478656",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy @sujaik In principle the larger the better, if you have the coverage to find all those kmers.",
  "id" : 867664611201478656,
  "in_reply_to_status_id" : 867606513354907648,
  "created_at" : "2017-05-25 08:52:18 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/9DgUvcxnxX",
      "expanded_url" : "http:\/\/www.righttoresearch.org\/blog\/young-researcher-cleared-by-colombian-court-for-sh.shtml",
      "display_url" : "righttoresearch.org\/blog\/young-res\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "867642092486578176",
  "text" : "RT @gedankenstuecke: Yes! Diego Gomez has been acquitted of all charges! \uD83C\uDF89 https:\/\/t.co\/9DgUvcxnxX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/9DgUvcxnxX",
        "expanded_url" : "http:\/\/www.righttoresearch.org\/blog\/young-researcher-cleared-by-colombian-court-for-sh.shtml",
        "display_url" : "righttoresearch.org\/blog\/young-res\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.11401800595797, 8.753528760171793 ]
    },
    "id_str" : "867514025055223808",
    "text" : "Yes! Diego Gomez has been acquitted of all charges! \uD83C\uDF89 https:\/\/t.co\/9DgUvcxnxX",
    "id" : 867514025055223808,
    "created_at" : "2017-05-24 22:53:55 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 867642092486578176,
  "created_at" : "2017-05-25 07:22:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Velterop \u24D0 \uD83C\uDDEA\uD83C\uDDFA\uD83D\uDD36",
      "screen_name" : "Villavelius",
      "indices" : [ 0, 12 ],
      "id_str" : "72249574",
      "id" : 72249574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/9ZE2LehPZI",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/867514025055223808",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "867493943117787136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403326704237, 8.753500349225046 ]
  },
  "id_str" : "867517091456397313",
  "in_reply_to_user_id" : 72249574,
  "text" : "@Villavelius now there is: https:\/\/t.co\/9ZE2LehPZI",
  "id" : 867517091456397313,
  "in_reply_to_status_id" : 867493943117787136,
  "created_at" : "2017-05-24 23:06:06 +0000",
  "in_reply_to_screen_name" : "Villavelius",
  "in_reply_to_user_id_str" : "72249574",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/9DgUvcxnxX",
      "expanded_url" : "http:\/\/www.righttoresearch.org\/blog\/young-researcher-cleared-by-colombian-court-for-sh.shtml",
      "display_url" : "righttoresearch.org\/blog\/young-res\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401800595797, 8.753528760171793 ]
  },
  "id_str" : "867514025055223808",
  "text" : "Yes! Diego Gomez has been acquitted of all charges! \uD83C\uDF89 https:\/\/t.co\/9DgUvcxnxX",
  "id" : 867514025055223808,
  "created_at" : "2017-05-24 22:53:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/rcdGohy16B",
      "expanded_url" : "https:\/\/twitter.com\/gatk_dev\/status\/867434715430760451",
      "display_url" : "twitter.com\/gatk_dev\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403425400955, 8.75340300161326 ]
  },
  "id_str" : "867511162925142016",
  "text" : "Look who\u2019s back from the dark side! https:\/\/t.co\/rcdGohy16B",
  "id" : 867511162925142016,
  "created_at" : "2017-05-24 22:42:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fran\u00E7ois Michonneau",
      "screen_name" : "fmic_",
      "indices" : [ 0, 6 ],
      "id_str" : "75694920",
      "id" : 75694920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867407174686965762",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11349922050732, 8.754362007611203 ]
  },
  "id_str" : "867435689784291328",
  "in_reply_to_user_id" : 75694920,
  "text" : "@fmic_ Thanks, will check that one out!",
  "id" : 867435689784291328,
  "in_reply_to_status_id" : 867407174686965762,
  "created_at" : "2017-05-24 17:42:39 +0000",
  "in_reply_to_screen_name" : "fmic_",
  "in_reply_to_user_id_str" : "75694920",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 45, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/jsT3tK0zD6",
      "expanded_url" : "https:\/\/twitter.com\/Neurosarda\/status\/867427371502010368",
      "display_url" : "twitter.com\/Neurosarda\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1089982759193, 8.753882041447529 ]
  },
  "id_str" : "867429595850715138",
  "text" : "That was so much fun! Looking forward to the #mozsprint! https:\/\/t.co\/jsT3tK0zD6",
  "id" : 867429595850715138,
  "created_at" : "2017-05-24 17:18:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867371356731658241",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237309007909, 8.627508620996249 ]
  },
  "id_str" : "867371606158581761",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch before sprint: 25 issues, after sprint: 50 completely new issues \uD83D\uDE02",
  "id" : 867371606158581761,
  "in_reply_to_status_id" : 867371356731658241,
  "created_at" : "2017-05-24 13:28:00 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867366207665647616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236495771839, 8.627515570732909 ]
  },
  "id_str" : "867370236680560640",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer and if everyone who starred the project just closes one issue during the #mozsprint we\u2019re bug free :P",
  "id" : 867370236680560640,
  "in_reply_to_status_id" : 867366207665647616,
  "created_at" : "2017-05-24 13:22:34 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 54, 67 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 68, 80 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234593935952, 8.627531339493 ]
  },
  "id_str" : "867363444714070016",
  "text" : "Just saw that the openSNP repo has a 100 \u2B50\uFE0F by now! \uD83C\uDF89 @PhilippBayer @helgerausch",
  "id" : 867363444714070016,
  "created_at" : "2017-05-24 12:55:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sven Gould",
      "screen_name" : "CellEvo",
      "indices" : [ 0, 8 ],
      "id_str" : "4030646297",
      "id" : 4030646297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/ahafvXdU25",
      "expanded_url" : "http:\/\/slittlefair.staff.shef.ac.uk\/teaching\/phy217\/lectures\/stats\/L19\/files\/small_5168.png",
      "display_url" : "slittlefair.staff.shef.ac.uk\/teaching\/phy21\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "867269057397092352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233439702274, 8.627535911289383 ]
  },
  "id_str" : "867270358998671360",
  "in_reply_to_user_id" : 4030646297,
  "text" : "@CellEvo what about https:\/\/t.co\/ahafvXdU25 ? \uD83D\uDE09",
  "id" : 867270358998671360,
  "in_reply_to_status_id" : 867269057397092352,
  "created_at" : "2017-05-24 06:45:41 +0000",
  "in_reply_to_screen_name" : "CellEvo",
  "in_reply_to_user_id_str" : "4030646297",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vennting",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/76xAIx2ypw",
      "expanded_url" : "https:\/\/twitter.com\/G_Devailly\/status\/867040126068764675",
      "display_url" : "twitter.com\/G_Devailly\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1427020497303, 8.668563157509594 ]
  },
  "id_str" : "867261273813245954",
  "text" : "#vennting https:\/\/t.co\/76xAIx2ypw",
  "id" : 867261273813245954,
  "created_at" : "2017-05-24 06:09:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alejandro D Buren",
      "screen_name" : "ADBuren",
      "indices" : [ 3, 11 ],
      "id_str" : "740897485695115268",
      "id" : 740897485695115268
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 13, 29 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 30, 35 ],
      "id_str" : "9377892",
      "id" : 9377892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "867246146380496896",
  "text" : "RT @ADBuren: @gedankenstuecke @tpoi way too often, and not carrying any weird stuff. Just for not looking anglo-saxon enough",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Timoth\u00E9e Poisot",
        "screen_name" : "tpoi",
        "indices" : [ 17, 22 ],
        "id_str" : "9377892",
        "id" : 9377892
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "867131950443745281",
    "geo" : { },
    "id_str" : "867175484945293312",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke @tpoi way too often, and not carrying any weird stuff. Just for not looking anglo-saxon enough",
    "id" : 867175484945293312,
    "in_reply_to_status_id" : 867131950443745281,
    "created_at" : "2017-05-24 00:28:41 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Alejandro D Buren",
      "screen_name" : "ADBuren",
      "protected" : false,
      "id_str" : "740897485695115268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740898471696179202\/ex3gZ0FO_normal.jpg",
      "id" : 740897485695115268,
      "verified" : false
    }
  },
  "id" : 867246146380496896,
  "created_at" : "2017-05-24 05:09:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 0, 9 ],
      "id_str" : "103004948",
      "id" : 103004948
    }, {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 10, 15 ],
      "id_str" : "9377892",
      "id" : 9377892
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 16, 25 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867155104604008448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402463885995, 8.753390135510157 ]
  },
  "id_str" : "867158861500874752",
  "in_reply_to_user_id" : 103004948,
  "text" : "@sckottie @tpoi @rOpenSci (And let\u2019s continue that tomorrow. It\u2019s well into \uD83D\uDE34 time in Europe \uD83D\uDE09)",
  "id" : 867158861500874752,
  "in_reply_to_status_id" : 867155104604008448,
  "created_at" : "2017-05-23 23:22:38 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 0, 9 ],
      "id_str" : "103004948",
      "id" : 103004948
    }, {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 10, 15 ],
      "id_str" : "9377892",
      "id" : 9377892
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 16, 25 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867155104604008448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406106999998, 8.753448339999997 ]
  },
  "id_str" : "867156540809248769",
  "in_reply_to_user_id" : 103004948,
  "text" : "@sckottie @tpoi @rOpenSci and the closer A &amp; B are taxonomically, the larger the intersection. Distance = (A \u222A B) - (A \u2229 B)",
  "id" : 867156540809248769,
  "in_reply_to_status_id" : 867155104604008448,
  "created_at" : "2017-05-23 23:13:24 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 0, 9 ],
      "id_str" : "103004948",
      "id" : 103004948
    }, {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 10, 15 ],
      "id_str" : "9377892",
      "id" : 9377892
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 16, 25 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867155104604008448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406106999998, 8.753448339999997 ]
  },
  "id_str" : "867155994824126464",
  "in_reply_to_user_id" : 103004948,
  "text" : "@sckottie @tpoi @rOpenSci no, but then you can compare the pairwise intersections of the unranked taxid lists of A &amp; B for all taxa to get your dist. matrix.",
  "id" : 867155994824126464,
  "in_reply_to_status_id" : 867155104604008448,
  "created_at" : "2017-05-23 23:11:14 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 0, 9 ],
      "id_str" : "103004948",
      "id" : 103004948
    }, {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 10, 15 ],
      "id_str" : "9377892",
      "id" : 9377892
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 16, 25 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867153882824286208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406106999998, 8.753448339999997 ]
  },
  "id_str" : "867154503312822274",
  "in_reply_to_user_id" : 103004948,
  "text" : "@sckottie @tpoi @rOpenSci rank position doesn\u2019t matter if you get them as NCBI tax-id as these are unique. Not sure whether all classification names would be.",
  "id" : 867154503312822274,
  "in_reply_to_status_id" : 867153882824286208,
  "created_at" : "2017-05-23 23:05:19 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 0, 9 ],
      "id_str" : "103004948",
      "id" : 103004948
    }, {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 10, 15 ],
      "id_str" : "9377892",
      "id" : 9377892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867153355281498113",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406106999998, 8.753448339999997 ]
  },
  "id_str" : "867153941926223873",
  "in_reply_to_user_id" : 103004948,
  "text" : "@sckottie @tpoi if you think that\u2019s a valid alternative I\u2019ll try to see whether he &amp; I can do a PR for extending class2tree.",
  "id" : 867153941926223873,
  "in_reply_to_status_id" : 867153355281498113,
  "created_at" : "2017-05-23 23:03:05 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 0, 9 ],
      "id_str" : "103004948",
      "id" : 103004948
    }, {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 10, 15 ],
      "id_str" : "9377892",
      "id" : 9377892
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 16, 25 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867149669859774464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406106999998, 8.753448339999997 ]
  },
  "id_str" : "867153218488459265",
  "in_reply_to_user_id" : 103004948,
  "text" : "@sckottie @tpoi @rOpenSci that seems to give the NCBI tax. as far as I could see.",
  "id" : 867153218488459265,
  "in_reply_to_status_id" : 867149669859774464,
  "created_at" : "2017-05-23 23:00:12 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 0, 9 ],
      "id_str" : "103004948",
      "id" : 103004948
    }, {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 10, 15 ],
      "id_str" : "9377892",
      "id" : 9377892
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 16, 25 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867149669859774464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406106999998, 8.753448339999997 ]
  },
  "id_str" : "867153091069698055",
  "in_reply_to_user_id" : 103004948,
  "text" : "@sckottie @tpoi @rOpenSci colleague, who had the Q, solved it for now by doing a distance matrix based on intersection of names in pairwise classification comparisons",
  "id" : 867153091069698055,
  "in_reply_to_status_id" : 867149669859774464,
  "created_at" : "2017-05-23 22:59:42 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucy Patterson",
      "screen_name" : "lu_cyP",
      "indices" : [ 0, 7 ],
      "id_str" : "99586343",
      "id" : 99586343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867150117853433857",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406106999996, 8.753448339999979 ]
  },
  "id_str" : "867151023055482881",
  "in_reply_to_user_id" : 99586343,
  "text" : "@lu_cyP any time!",
  "id" : 867151023055482881,
  "in_reply_to_status_id" : 867150117853433857,
  "created_at" : "2017-05-23 22:51:29 +0000",
  "in_reply_to_screen_name" : "lu_cyP",
  "in_reply_to_user_id_str" : "99586343",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 0, 9 ],
      "id_str" : "103004948",
      "id" : 103004948
    }, {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 10, 15 ],
      "id_str" : "9377892",
      "id" : 9377892
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 16, 25 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/5cF5l6RdqS",
      "expanded_url" : "https:\/\/github.com\/ropensci\/taxize\/blob\/master\/R\/class2tree.R#L82",
      "display_url" : "github.com\/ropensci\/taxiz\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "867149669859774464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406106999996, 8.753448339999979 ]
  },
  "id_str" : "867150932261433345",
  "in_reply_to_user_id" : 103004948,
  "text" : "@sckottie @tpoi @rOpenSci already found why: Common Tree also uses \u201Eno rank\u201C, while class2tree removes these, c.f.: https:\/\/t.co\/5cF5l6RdqS",
  "id" : 867150932261433345,
  "in_reply_to_status_id" : 867149669859774464,
  "created_at" : "2017-05-23 22:51:07 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucy Patterson",
      "screen_name" : "lu_cyP",
      "indices" : [ 0, 7 ],
      "id_str" : "99586343",
      "id" : 99586343
    }, {
      "name" : "Hackuarium",
      "screen_name" : "hackuarium",
      "indices" : [ 8, 19 ],
      "id_str" : "2418603105",
      "id" : 2418603105
    }, {
      "name" : "La Paillasse",
      "screen_name" : "LaPaillasse",
      "indices" : [ 20, 32 ],
      "id_str" : "280058345",
      "id" : 280058345
    }, {
      "name" : "Science Hack Day BLN",
      "screen_name" : "SHD_Berlin",
      "indices" : [ 33, 44 ],
      "id_str" : "1531582164",
      "id" : 1531582164
    }, {
      "name" : "DITOs",
      "screen_name" : "TogetherSci",
      "indices" : [ 45, 57 ],
      "id_str" : "4883090141",
      "id" : 4883090141
    }, {
      "name" : "Public Laboratory",
      "screen_name" : "PublicLab",
      "indices" : [ 58, 68 ],
      "id_str" : "296873851",
      "id" : 296873851
    }, {
      "name" : "ReaGent",
      "screen_name" : "ReaGentLab",
      "indices" : [ 69, 80 ],
      "id_str" : "4352300685",
      "id" : 4352300685
    }, {
      "name" : "Bento Lab",
      "screen_name" : "theBentoLab",
      "indices" : [ 81, 93 ],
      "id_str" : "1928272748",
      "id" : 1928272748
    }, {
      "name" : "Technarium",
      "screen_name" : "technarium",
      "indices" : [ 94, 105 ],
      "id_str" : "2936916419",
      "id" : 2936916419
    }, {
      "name" : "OK Lab Stuttgart",
      "screen_name" : "codeforS",
      "indices" : [ 106, 115 ],
      "id_str" : "3096852346",
      "id" : 3096852346
    }, {
      "name" : "GOSH",
      "screen_name" : "GOSHCommunity",
      "indices" : [ 116, 130 ],
      "id_str" : "4733914515",
      "id" : 4733914515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867148442916851712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406107000025, 8.753448340000412 ]
  },
  "id_str" : "867149639681802240",
  "in_reply_to_user_id" : 99586343,
  "text" : "@lu_cyP @hackuarium @LaPaillasse @SHD_Berlin @TogetherSci @PublicLab @ReaGentLab @theBentoLab @technarium @codeforS @GOSHCommunity that looks already really good! Great progress! \uD83D\uDC4D\uD83C\uDF89",
  "id" : 867149639681802240,
  "in_reply_to_status_id" : 867148442916851712,
  "created_at" : "2017-05-23 22:45:59 +0000",
  "in_reply_to_screen_name" : "lu_cyP",
  "in_reply_to_user_id_str" : "99586343",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 134, 157 ],
      "url" : "https:\/\/t.co\/lCCOkMGghz",
      "expanded_url" : "https:\/\/twitter.com\/lu_cyP\/status\/867148442916851712",
      "display_url" : "twitter.com\/lu_cyP\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406106970778, 8.75344833955435 ]
  },
  "id_str" : "867149450627698688",
  "text" : "Interested in running DIYScience projects or doing advocacy for it? Look at this great project that\u2019ll participate in the #mozsprint! https:\/\/t.co\/lCCOkMGghz",
  "id" : 867149450627698688,
  "created_at" : "2017-05-23 22:45:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 0, 9 ],
      "id_str" : "103004948",
      "id" : 103004948
    }, {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 10, 15 ],
      "id_str" : "9377892",
      "id" : 9377892
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 16, 25 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867141025340375040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406107039879, 8.753448340608239 ]
  },
  "id_str" : "867142167336235009",
  "in_reply_to_user_id" : 103004948,
  "text" : "@sckottie @tpoi @rOpenSci yes, but even the taxonomy should have more info, e.g. clustering rosids and asterids?",
  "id" : 867142167336235009,
  "in_reply_to_status_id" : 867141025340375040,
  "created_at" : "2017-05-23 22:16:18 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 0, 9 ],
      "id_str" : "103004948",
      "id" : 103004948
    }, {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 10, 15 ],
      "id_str" : "9377892",
      "id" : 9377892
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 16, 25 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/867138159058046977\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/1l2TWrDVto",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DAixjkiXkAEQTEK.jpg",
      "id_str" : "867138152930185217",
      "id" : 867138152930185217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAixjkiXkAEQTEK.jpg",
      "sizes" : [ {
        "h" : 366,
        "resize" : "fit",
        "w" : 587
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 366,
        "resize" : "fit",
        "w" : 587
      }, {
        "h" : 366,
        "resize" : "fit",
        "w" : 587
      }, {
        "h" : 366,
        "resize" : "fit",
        "w" : 587
      } ],
      "display_url" : "pic.twitter.com\/1l2TWrDVto"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867136890285117440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406107016857, 8.75344834025712 ]
  },
  "id_str" : "867138159058046977",
  "in_reply_to_user_id" : 103004948,
  "text" : "@sckottie @tpoi @rOpenSci same taxa as delivered by common tree. https:\/\/t.co\/1l2TWrDVto",
  "id" : 867138159058046977,
  "in_reply_to_status_id" : 867136890285117440,
  "created_at" : "2017-05-23 22:00:22 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 0, 5 ],
      "id_str" : "9377892",
      "id" : 9377892
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 6, 15 ],
      "id_str" : "342250615",
      "id" : 342250615
    }, {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 79, 88 ],
      "id_str" : "103004948",
      "id" : 103004948
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/867137179671306240\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/H4DoZ3va0J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DAiwqk6XgAAyIsn.jpg",
      "id_str" : "867137173778300928",
      "id" : 867137173778300928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAiwqk6XgAAyIsn.jpg",
      "sizes" : [ {
        "h" : 376,
        "resize" : "fit",
        "w" : 643
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 643
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 643
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 643
      } ],
      "display_url" : "pic.twitter.com\/H4DoZ3va0J"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/PflLHH9hsD",
      "expanded_url" : "https:\/\/rdrr.io\/github\/ropensci\/taxize\/man\/class2tree.html",
      "display_url" : "rdrr.io\/github\/ropensc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "867136603013230592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406106412218, 8.753448331036472 ]
  },
  "id_str" : "867137179671306240",
  "in_reply_to_user_id" : 9377892,
  "text" : "@tpoi @rOpenSci I tried the example at https:\/\/t.co\/PflLHH9hsD but this yields @sckottie strange results. https:\/\/t.co\/H4DoZ3va0J",
  "id" : 867137179671306240,
  "in_reply_to_status_id" : 867136603013230592,
  "created_at" : "2017-05-23 21:56:28 +0000",
  "in_reply_to_screen_name" : "tpoi",
  "in_reply_to_user_id_str" : "9377892",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 0, 5 ],
      "id_str" : "9377892",
      "id" : 9377892
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 6, 15 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867135174491992064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406494970672, 8.75345176740731 ]
  },
  "id_str" : "867135577203892224",
  "in_reply_to_user_id" : 9377892,
  "text" : "@tpoi @rOpenSci you mean class2tree? :)",
  "id" : 867135577203892224,
  "in_reply_to_status_id" : 867135174491992064,
  "created_at" : "2017-05-23 21:50:06 +0000",
  "in_reply_to_screen_name" : "tpoi",
  "in_reply_to_user_id_str" : "9377892",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Ross",
      "screen_name" : "sw1ayfe",
      "indices" : [ 0, 8 ],
      "id_str" : "585100333",
      "id" : 585100333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867131973910884352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11381260111033, 8.753276133617716 ]
  },
  "id_str" : "867132119495188481",
  "in_reply_to_user_id" : 585100333,
  "text" : "@sw1ayfe Best gif ever!",
  "id" : 867132119495188481,
  "in_reply_to_status_id" : 867131973910884352,
  "created_at" : "2017-05-23 21:36:22 +0000",
  "in_reply_to_screen_name" : "sw1ayfe",
  "in_reply_to_user_id_str" : "585100333",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/h4IX6ltyig",
      "expanded_url" : "https:\/\/twitter.com\/edyong209\/status\/867128398472249344",
      "display_url" : "twitter.com\/edyong209\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11381260111033, 8.753276133617716 ]
  },
  "id_str" : "867131950443745281",
  "text" : "And now the counter check: how many scientists have been detained for having the wrong looks while carrying weird stuff? https:\/\/t.co\/h4IX6ltyig",
  "id" : 867131950443745281,
  "created_at" : "2017-05-23 21:35:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Riordan\uD83D\uDD96",
      "screen_name" : "riordan",
      "indices" : [ 0, 8 ],
      "id_str" : "1281581",
      "id" : 1281581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867113353709309956",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397801571606, 8.753386350921048 ]
  },
  "id_str" : "867119422900756480",
  "in_reply_to_user_id" : 1281581,
  "text" : "@riordan Can we get you to contribute to the openSNP docs? \uD83D\uDE02",
  "id" : 867119422900756480,
  "in_reply_to_status_id" : 867113353709309956,
  "created_at" : "2017-05-23 20:45:55 +0000",
  "in_reply_to_screen_name" : "riordan",
  "in_reply_to_user_id_str" : "1281581",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "867000321351876609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723025877744, 8.627535178737192 ]
  },
  "id_str" : "867000761158336512",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin But you don\u2019t merge it into a \uD83C\uDF32 later, do you?",
  "id" : 867000761158336512,
  "in_reply_to_status_id" : 867000321351876609,
  "created_at" : "2017-05-23 12:54:24 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866997049123774464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232000118891, 8.627537274534129 ]
  },
  "id_str" : "866999825946091522",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin I really hoped for an easy solution via Entrez, alas no chance :(",
  "id" : 866999825946091522,
  "in_reply_to_status_id" : 866997049123774464,
  "created_at" : "2017-05-23 12:50:41 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Rainer Melzer",
      "screen_name" : "UCDflowerpower",
      "indices" : [ 19, 34 ],
      "id_str" : "19333674",
      "id" : 19333674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/w3oixUbTQJ",
      "expanded_url" : "https:\/\/github.com\/damiendevienne\/Lifemap\/blob\/master\/PIPELINE\/getTrees.py",
      "display_url" : "github.com\/damiendevienne\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "866997049123774464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232000118891, 8.627537274534129 ]
  },
  "id_str" : "866999597423525889",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin thanks to @UCDflowerpower I got an idea of how Lifemap does it with Python: https:\/\/t.co\/w3oixUbTQJ saves all of NCBI Taxonomy though.",
  "id" : 866999597423525889,
  "in_reply_to_status_id" : 866997049123774464,
  "created_at" : "2017-05-23 12:49:46 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastien Chevreux",
      "screen_name" : "BaCh_mira",
      "indices" : [ 0, 10 ],
      "id_str" : "360258516",
      "id" : 360258516
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 11, 21 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866994170724061184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233418889729, 8.627533091870077 ]
  },
  "id_str" : "866995374317338624",
  "in_reply_to_user_id" : 360258516,
  "text" : "@BaCh_mira @Julie_B92 aye, maybe the way to go. Just wanted to save the people from hosting a copy on their end.",
  "id" : 866995374317338624,
  "in_reply_to_status_id" : 866994170724061184,
  "created_at" : "2017-05-23 12:32:59 +0000",
  "in_reply_to_screen_name" : "BaCh_mira",
  "in_reply_to_user_id_str" : "360258516",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 0, 12 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Rainer Melzer",
      "screen_name" : "UCDflowerpower",
      "indices" : [ 13, 28 ],
      "id_str" : "19333674",
      "id" : 19333674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866994884850397185",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231546618222, 8.627536327420572 ]
  },
  "id_str" : "866995098785112064",
  "in_reply_to_user_id" : 439273539,
  "text" : "@chartgerink @UCDflowerpower nah, it seems there\u2019s no way to query the \u201Ecommon tree\u201C thing via Entrez. \uD83D\uDE22",
  "id" : 866995098785112064,
  "in_reply_to_status_id" : 866994884850397185,
  "created_at" : "2017-05-23 12:31:54 +0000",
  "in_reply_to_screen_name" : "chartgerink",
  "in_reply_to_user_id_str" : "439273539",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rainer Melzer",
      "screen_name" : "UCDflowerpower",
      "indices" : [ 0, 15 ],
      "id_str" : "19333674",
      "id" : 19333674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866965170446381056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17249125937129, 8.627553256167111 ]
  },
  "id_str" : "866965254634446848",
  "in_reply_to_user_id" : 19333674,
  "text" : "@UCDflowerpower Thanks, good idea!",
  "id" : 866965254634446848,
  "in_reply_to_status_id" : 866965170446381056,
  "created_at" : "2017-05-23 10:33:18 +0000",
  "in_reply_to_screen_name" : "UCDflowerpower",
  "in_reply_to_user_id_str" : "19333674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 92, 106 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    }, {
      "name" : "PersonalGenomes.org",
      "screen_name" : "PGorg",
      "indices" : [ 107, 113 ],
      "id_str" : "48160604",
      "id" : 48160604
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 114, 125 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "866965187718508544",
  "text" : "RT @madprime: This gets at the foundation of what we do, what we build, what we dream\n\nwith @OpenHumansOrg @PGorg @openSNPorg ...\n\nhttps:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHumansOrg",
        "screen_name" : "OpenHumansOrg",
        "indices" : [ 78, 92 ],
        "id_str" : "2282943410",
        "id" : 2282943410
      }, {
        "name" : "PersonalGenomes.org",
        "screen_name" : "PGorg",
        "indices" : [ 93, 99 ],
        "id_str" : "48160604",
        "id" : 48160604
      }, {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 100, 111 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/madprime\/status\/866964548884017152\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/BYtzJvsCOJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DAgTqF-XgAAUKfX.jpg",
        "id_str" : "866964542148018176",
        "id" : 866964542148018176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAgTqF-XgAAUKfX.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        } ],
        "display_url" : "pic.twitter.com\/BYtzJvsCOJ"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/madprime\/status\/866964548884017152\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/BYtzJvsCOJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DAgTqGCXcAAl33Q.jpg",
        "id_str" : "866964542164791296",
        "id" : 866964542164791296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAgTqGCXcAAl33Q.jpg",
        "sizes" : [ {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/BYtzJvsCOJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/p4ZCeiYmsY",
        "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/866639215051845632",
        "display_url" : "twitter.com\/wilbanks\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "866964548884017152",
    "text" : "This gets at the foundation of what we do, what we build, what we dream\n\nwith @OpenHumansOrg @PGorg @openSNPorg ...\n\nhttps:\/\/t.co\/p4ZCeiYmsY https:\/\/t.co\/BYtzJvsCOJ",
    "id" : 866964548884017152,
    "created_at" : "2017-05-23 10:30:30 +0000",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 866965187718508544,
  "created_at" : "2017-05-23 10:33:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866958711406907393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232736002314, 8.627539489240322 ]
  },
  "id_str" : "866958859067326466",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 sure, I do have the file somewhere in my ~ even. But would have loved an easier way for end users. :)",
  "id" : 866958859067326466,
  "in_reply_to_status_id" : 866958711406907393,
  "created_at" : "2017-05-23 10:07:53 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866958447241252864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232736002314, 8.627539489240322 ]
  },
  "id_str" : "866958647728930816",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 let me rephrase: it\u2019s too big to easily distribute it with software you want to share. ;)",
  "id" : 866958647728930816,
  "in_reply_to_status_id" : 866958447241252864,
  "created_at" : "2017-05-23 10:07:03 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866958272963768320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172349385427, 8.627521672275273 ]
  },
  "id_str" : "866958355453157376",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 but that one\u2019s huge, isn\u2019t it?",
  "id" : 866958355453157376,
  "in_reply_to_status_id" : 866958272963768320,
  "created_at" : "2017-05-23 10:05:53 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866957567892873216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172349385427, 8.627521672275273 ]
  },
  "id_str" : "866958031694770176",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 preferentially, if there\u2019s another scriptable tool that can do it (w\/o using the NCBI common tree website manually) it\u2019ll work as well.",
  "id" : 866958031694770176,
  "in_reply_to_status_id" : 866957567892873216,
  "created_at" : "2017-05-23 10:04:36 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236210214308, 8.62750681252648 ]
  },
  "id_str" : "866954181290205185",
  "text" : "R people: What\u2019s the easiest way to get the NCBI taxonomy tree for a given list of NCBI Taxonomy-IDs?",
  "id" : 866954181290205185,
  "created_at" : "2017-05-23 09:49:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866941275521642496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236440809437, 8.627504172761858 ]
  },
  "id_str" : "866943111737552897",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach aye",
  "id" : 866943111737552897,
  "in_reply_to_status_id" : 866941275521642496,
  "created_at" : "2017-05-23 09:05:19 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gottacatchthemall",
      "indices" : [ 42, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/4qTIHiQXmX",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/866933546979663873",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "866933546979663873",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234153324765, 8.627538955955112 ]
  },
  "id_str" : "866933781822877697",
  "in_reply_to_user_id" : 14286491,
  "text" : "See also: The worlds worst Pok\u00E9mon clone. #gottacatchthemall https:\/\/t.co\/4qTIHiQXmX",
  "id" : 866933781822877697,
  "in_reply_to_status_id" : 866933546979663873,
  "created_at" : "2017-05-23 08:28:15 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/866933546979663873\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/v2Mfci3UTs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DAf3cGMXcAALQ0W.jpg",
      "id_str" : "866933515362988032",
      "id" : 866933515362988032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAf3cGMXcAALQ0W.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/v2Mfci3UTs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "864212791661649920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231461443187, 8.62753128437208 ]
  },
  "id_str" : "866933546979663873",
  "in_reply_to_user_id" : 14286491,
  "text" : "And here\u2019s the last missing stamps. \uD83C\uDF89 For someone who hates bureaucracy I spent way too many hours hunting these things in the last 5 weeks. https:\/\/t.co\/v2Mfci3UTs",
  "id" : 866933546979663873,
  "in_reply_to_status_id" : 864212791661649920,
  "created_at" : "2017-05-23 08:27:19 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 3, 16 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 40, 51 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 65, 81 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Datasource",
      "indices" : [ 52, 63 ]
    }, {
      "text" : "Genomic",
      "indices" : [ 114, 122 ]
    }, {
      "text" : "Datasharing",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "866918984859439104",
  "text" : "RT @repositiveio: To compliment our new @openSNPorg #Datasource, @gedankenstuecke &amp; Haeusermann write on open #Genomic #Datasharing: \n http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 22, 33 ],
        "id_str" : "380205172",
        "id" : 380205172
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 47, 63 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Datasource",
        "indices" : [ 34, 45 ]
      }, {
        "text" : "Genomic",
        "indices" : [ 96, 104 ]
      }, {
        "text" : "Datasharing",
        "indices" : [ 105, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/OaNGgHZI7f",
        "expanded_url" : "http:\/\/buff.ly\/2q3HwzP",
        "display_url" : "buff.ly\/2q3HwzP"
      } ]
    },
    "geo" : { },
    "id_str" : "866918873945317377",
    "text" : "To compliment our new @openSNPorg #Datasource, @gedankenstuecke &amp; Haeusermann write on open #Genomic #Datasharing: \n https:\/\/t.co\/OaNGgHZI7f",
    "id" : 866918873945317377,
    "created_at" : "2017-05-23 07:29:00 +0000",
    "user" : {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "protected" : false,
      "id_str" : "3059929578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661114195753230336\/N89yr0lj_normal.png",
      "id" : 3059929578,
      "verified" : false
    }
  },
  "id" : 866918984859439104,
  "created_at" : "2017-05-23 07:29:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/866888132624621568\/photo\/1",
      "indices" : [ 134, 157 ],
      "url" : "https:\/\/t.co\/MgjK9fCmlp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DAfOITcWsAEhDxu.jpg",
      "id_str" : "866888095345586177",
      "id" : 866888095345586177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAfOITcWsAEhDxu.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      } ],
      "display_url" : "pic.twitter.com\/MgjK9fCmlp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866887058475802624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403452760519, 8.753403918639668 ]
  },
  "id_str" : "866888132624621568",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw Totally! For electronic devices I started building stratigraphic layers. Paper notebooks fortunately rotate every ~3 months. \uD83D\uDE02 https:\/\/t.co\/MgjK9fCmlp",
  "id" : 866888132624621568,
  "in_reply_to_status_id" : 866887058475802624,
  "created_at" : "2017-05-23 05:26:51 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/QI45d1nQsb",
      "expanded_url" : "https:\/\/twitter.com\/FemmesofStem\/status\/866761866424594432",
      "display_url" : "twitter.com\/FemmesofStem\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388759804331, 8.753300611073477 ]
  },
  "id_str" : "866793285586694145",
  "text" : "\u00ABDecolonial scientists have a particular kind of ethical vision that science should be practiced with humans in mind.\u00BB \uD83D\uDE0D\uD83D\uDC96\uD83D\uDC4D https:\/\/t.co\/QI45d1nQsb",
  "id" : 866793285586694145,
  "created_at" : "2017-05-22 23:09:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866752695507406848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11410720420803, 8.753513598359508 ]
  },
  "id_str" : "866756325400879104",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw These look awesome! \uD83D\uDE0D",
  "id" : 866756325400879104,
  "in_reply_to_status_id" : 866752695507406848,
  "created_at" : "2017-05-22 20:43:06 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 3, 9 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/iuH7jXNK5z",
      "expanded_url" : "http:\/\/bit.ly\/2q3O7PH",
      "display_url" : "bit.ly\/2q3O7PH"
    } ]
  },
  "geo" : { },
  "id_str" : "866756254223486977",
  "text" : "RT @shefw: Seattle peeps: I got Foxes, coffee, &amp; snacks for all who join me for #mozsprint June 1-2! Register now! https:\/\/t.co\/iuH7jXNK5z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/shefw\/status\/866752695507406848\/photo\/1",
        "indices" : [ 145, 168 ],
        "url" : "https:\/\/t.co\/NwjwalMFtM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DAdR-pVXoAIcgYs.jpg",
        "id_str" : "866751589981331458",
        "id" : 866751589981331458,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAdR-pVXoAIcgYs.jpg",
        "sizes" : [ {
          "h" : 4032,
          "resize" : "fit",
          "w" : 3024
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/NwjwalMFtM"
      } ],
      "hashtags" : [ {
        "text" : "mozsprint",
        "indices" : [ 73, 83 ]
      }, {
        "text" : "openscience",
        "indices" : [ 132, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/iuH7jXNK5z",
        "expanded_url" : "http:\/\/bit.ly\/2q3O7PH",
        "display_url" : "bit.ly\/2q3O7PH"
      } ]
    },
    "geo" : { },
    "id_str" : "866752695507406848",
    "text" : "Seattle peeps: I got Foxes, coffee, &amp; snacks for all who join me for #mozsprint June 1-2! Register now! https:\/\/t.co\/iuH7jXNK5z #openscience https:\/\/t.co\/NwjwalMFtM",
    "id" : 866752695507406848,
    "created_at" : "2017-05-22 20:28:40 +0000",
    "user" : {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "protected" : false,
      "id_str" : "48636190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677947392080019456\/CHnYz4aV_normal.jpg",
      "id" : 48636190,
      "verified" : false
    }
  },
  "id" : 866756254223486977,
  "created_at" : "2017-05-22 20:42:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866738920071069697",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139491107899, 8.753266180018269 ]
  },
  "id_str" : "866739391942856704",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg Deep seated beliefs on the natural order of proceedings? \uD83D\uDE02",
  "id" : 866739391942856704,
  "in_reply_to_status_id" : 866738920071069697,
  "created_at" : "2017-05-22 19:35:48 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yves Clement",
      "screen_name" : "TwelveSharp",
      "indices" : [ 0, 12 ],
      "id_str" : "519952673",
      "id" : 519952673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866737917510782976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403614389877, 8.753404550032377 ]
  },
  "id_str" : "866738291617533952",
  "in_reply_to_user_id" : 519952673,
  "text" : "@TwelveSharp Exactly what I had in mind when writing it \uD83D\uDE02",
  "id" : 866738291617533952,
  "in_reply_to_status_id" : 866737917510782976,
  "created_at" : "2017-05-22 19:31:26 +0000",
  "in_reply_to_screen_name" : "TwelveSharp",
  "in_reply_to_user_id_str" : "519952673",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866737233910407169",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404611162334, 8.753421428648375 ]
  },
  "id_str" : "866737574794100737",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski would love to see how the Star Wars people explain that misuse of a unit ;)",
  "id" : 866737574794100737,
  "in_reply_to_status_id" : 866737233910407169,
  "created_at" : "2017-05-22 19:28:35 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866736297620025344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404611162334, 8.753421428648375 ]
  },
  "id_str" : "866737135545724931",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski This data viz makes you confused in less than twelve parsecs!",
  "id" : 866737135545724931,
  "in_reply_to_status_id" : 866736297620025344,
  "created_at" : "2017-05-22 19:26:50 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/0pMgUgmYzr",
      "expanded_url" : "https:\/\/twitter.com\/BioMickWatson\/status\/866725799554109440",
      "display_url" : "twitter.com\/BioMickWatson\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404505978483, 8.753421519890713 ]
  },
  "id_str" : "866736019139440640",
  "text" : "Reviewer #3: \u201EFigure 2 needs more pie-charty feeling\u201C. https:\/\/t.co\/0pMgUgmYzr",
  "id" : 866736019139440640,
  "created_at" : "2017-05-22 19:22:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866703600239726600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11595213372216, 8.668832340532358 ]
  },
  "id_str" : "866704414601555968",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime I had to scroll down to figure out how to say it in German \uD83D\uDE02",
  "id" : 866704414601555968,
  "in_reply_to_status_id" : 866703600239726600,
  "created_at" : "2017-05-22 17:16:49 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11573320088711, 8.664371477022456 ]
  },
  "id_str" : "866703532724019201",
  "text" : "Who would have guessed that picking up the translation of my birth certificate would come with a free 30 min lecture on how to raise kids?",
  "id" : 866703532724019201,
  "created_at" : "2017-05-22 17:13:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866703084445106176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11574957010381, 8.664170301510637 ]
  },
  "id_str" : "866703225243807744",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime That\u2019s awesome!",
  "id" : 866703225243807744,
  "in_reply_to_status_id" : 866703084445106176,
  "created_at" : "2017-05-22 17:12:06 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/866685901610643456\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/0TBIOBhUtz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DAcWOVHXoAIx9W5.jpg",
      "id_str" : "866685888734142466",
      "id" : 866685888734142466,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAcWOVHXoAIx9W5.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/0TBIOBhUtz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16936294418542, 8.622502096560114 ]
  },
  "id_str" : "866685901610643456",
  "text" : "The replacement for the broken public transport arrives. https:\/\/t.co\/0TBIOBhUtz",
  "id" : 866685901610643456,
  "created_at" : "2017-05-22 16:03:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "James Chapman",
      "screen_name" : "chapmangamo",
      "indices" : [ 9, 21 ],
      "id_str" : "30633376",
      "id" : 30633376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866599667274051585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233021131426, 8.627534014282675 ]
  },
  "id_str" : "866600192929406976",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @chapmangamo Thanks for enlightening me! \uD83D\uDC4D\uD83D\uDE4F",
  "id" : 866600192929406976,
  "in_reply_to_status_id" : 866599667274051585,
  "created_at" : "2017-05-22 10:22:41 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "James Chapman",
      "screen_name" : "chapmangamo",
      "indices" : [ 9, 21 ],
      "id_str" : "30633376",
      "id" : 30633376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/gDQwydEm91",
      "expanded_url" : "http:\/\/www.omniglot.com\/language\/idioms\/incomprehensible.php",
      "display_url" : "omniglot.com\/language\/idiom\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "866598988849569793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723642804016, 8.627531544126477 ]
  },
  "id_str" : "866599318219874304",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @chapmangamo I assume it\u2019s from here and chosen so that the punch line works. https:\/\/t.co\/gDQwydEm91",
  "id" : 866599318219874304,
  "in_reply_to_status_id" : 866598988849569793,
  "created_at" : "2017-05-22 10:19:12 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Chapman",
      "screen_name" : "chapmangamo",
      "indices" : [ 0, 12 ],
      "id_str" : "30633376",
      "id" : 30633376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865587948544282624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235342355595, 8.627516440612233 ]
  },
  "id_str" : "866592604091277312",
  "in_reply_to_user_id" : 30633376,
  "text" : "@chapmangamo btw. whatever you use for drawing, it seems it doesn\u2019t like Right-To-Left text. At least the Hebrew\u2019s mirrored. \uD83D\uDE02",
  "id" : 866592604091277312,
  "in_reply_to_status_id" : 865587948544282624,
  "created_at" : "2017-05-22 09:52:31 +0000",
  "in_reply_to_screen_name" : "chapmangamo",
  "in_reply_to_user_id_str" : "30633376",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/E9MJZAc1DQ",
      "expanded_url" : "https:\/\/twitter.com\/chapmangamo\/status\/865587948544282624",
      "display_url" : "twitter.com\/chapmangamo\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234674769953, 8.627519277180992 ]
  },
  "id_str" : "866591419640754176",
  "text" : "And Twitter probably thinks I can speak all of them. \uD83D\uDE02 https:\/\/t.co\/E9MJZAc1DQ",
  "id" : 866591419640754176,
  "created_at" : "2017-05-22 09:47:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/A5vFE9eEsX",
      "expanded_url" : "http:\/\/justsomething.co\/wp-content\/uploads\/2014\/11\/20-hilarious-dog-who-have-no-idea-what-theyre-doing-5.jpg",
      "display_url" : "justsomething.co\/wp-content\/upl\u2026"
    }, {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/EqAqjGGKHC",
      "expanded_url" : "https:\/\/twitter.com\/RetractionWatch\/status\/866463191781474304",
      "display_url" : "twitter.com\/RetractionWatc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232707842364, 8.62753280920475 ]
  },
  "id_str" : "866588228538822656",
  "text" : "To be fair: he was well hidden with his costume! https:\/\/t.co\/A5vFE9eEsX https:\/\/t.co\/EqAqjGGKHC",
  "id" : 866588228538822656,
  "created_at" : "2017-05-22 09:35:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/866247660772216832\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/UcaxhdPkYA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DAWHp9fXcAAbDTO.jpg",
      "id_str" : "866247658289197056",
      "id" : 866247658289197056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAWHp9fXcAAbDTO.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/UcaxhdPkYA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "866562035072598017",
  "text" : "RT @gedankenstuecke: Stay Weird, Offenbach. https:\/\/t.co\/UcaxhdPkYA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/866247660772216832\/photo\/1",
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/UcaxhdPkYA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DAWHp9fXcAAbDTO.jpg",
        "id_str" : "866247658289197056",
        "id" : 866247658289197056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAWHp9fXcAAbDTO.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/UcaxhdPkYA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "866247660772216832",
    "text" : "Stay Weird, Offenbach. https:\/\/t.co\/UcaxhdPkYA",
    "id" : 866247660772216832,
    "created_at" : "2017-05-21 11:01:51 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 866562035072598017,
  "created_at" : "2017-05-22 07:51:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866540237534658560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233231124862, 8.627532316242057 ]
  },
  "id_str" : "866540617513537536",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics Praise, of course!",
  "id" : 866540617513537536,
  "in_reply_to_status_id" : 866540237534658560,
  "created_at" : "2017-05-22 06:25:57 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vince Buffalo",
      "screen_name" : "vsbuffalo",
      "indices" : [ 0, 10 ],
      "id_str" : "62183077",
      "id" : 62183077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/r2DMcfci13",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/856206078312300544",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "866479041775230976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233231124862, 8.627532316242057 ]
  },
  "id_str" : "866540522835501056",
  "in_reply_to_user_id" : 62183077,
  "text" : "@vsbuffalo Agree, found this one in Seattle last month! https:\/\/t.co\/r2DMcfci13",
  "id" : 866540522835501056,
  "in_reply_to_status_id" : 866479041775230976,
  "created_at" : "2017-05-22 06:25:34 +0000",
  "in_reply_to_screen_name" : "vsbuffalo",
  "in_reply_to_user_id_str" : "62183077",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 4, 17 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/WtLoMyAhEg",
      "expanded_url" : "https:\/\/twitter.com\/rudeboybert\/status\/866442948560531456",
      "display_url" : "twitter.com\/rudeboybert\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233868990224, 8.627525602904232 ]
  },
  "id_str" : "866539759732228097",
  "text" : "Hey @RaoOfPhysics, I think this describes you. \uD83D\uDE02 https:\/\/t.co\/WtLoMyAhEg",
  "id" : 866539759732228097,
  "created_at" : "2017-05-22 06:22:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasmin Yonis",
      "screen_name" : "YasminYonis",
      "indices" : [ 3, 15 ],
      "id_str" : "22591543",
      "id" : 22591543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/D0Tr3NItQ2",
      "expanded_url" : "http:\/\/Ancestry.com",
      "display_url" : "Ancestry.com"
    } ]
  },
  "geo" : { },
  "id_str" : "866539299243732992",
  "text" : "RT @YasminYonis: https:\/\/t.co\/D0Tr3NItQ2 owns &amp; profits off your DNA. Your DNA can be (&amp; has been) used against you by employers, insurers\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/D0Tr3NItQ2",
        "expanded_url" : "http:\/\/Ancestry.com",
        "display_url" : "Ancestry.com"
      }, {
        "indices" : [ 153, 176 ],
        "url" : "https:\/\/t.co\/SN7GwAFhHt",
        "expanded_url" : "https:\/\/twitter.com\/pegaita\/status\/865946519022817280",
        "display_url" : "twitter.com\/pegaita\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "865954895228227584",
    "text" : "https:\/\/t.co\/D0Tr3NItQ2 owns &amp; profits off your DNA. Your DNA can be (&amp; has been) used against you by employers, insurers &amp; law enforcement. https:\/\/t.co\/SN7GwAFhHt",
    "id" : 865954895228227584,
    "created_at" : "2017-05-20 15:38:30 +0000",
    "user" : {
      "name" : "Yasmin Yonis",
      "screen_name" : "YasminYonis",
      "protected" : false,
      "id_str" : "22591543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/901042243452235776\/YH_eUxTU_normal.jpg",
      "id" : 22591543,
      "verified" : false
    }
  },
  "id" : 866539299243732992,
  "created_at" : "2017-05-22 06:20:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "866440338067660800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233884510236, 8.627525520011716 ]
  },
  "id_str" : "866538315104833536",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski good to hear! \uD83D\uDC4B",
  "id" : 866538315104833536,
  "in_reply_to_status_id" : 866440338067660800,
  "created_at" : "2017-05-22 06:16:48 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((AndrewWMSmith)))",
      "screen_name" : "smidbob",
      "indices" : [ 3, 11 ],
      "id_str" : "26227666",
      "id" : 26227666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "866525070084251648",
  "text" : "RT @smidbob: If you're a man in a relationship, especially with children, it's worth reading this and reflecting on the realities of your o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/C3dUNKpUfG",
        "expanded_url" : "https:\/\/twitter.com\/smidbob\/status\/866251964358815744",
        "display_url" : "twitter.com\/smidbob\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "866252381230682113",
    "text" : "If you're a man in a relationship, especially with children, it's worth reading this and reflecting on the realities of your own home https:\/\/t.co\/C3dUNKpUfG",
    "id" : 866252381230682113,
    "created_at" : "2017-05-21 11:20:36 +0000",
    "user" : {
      "name" : "(((AndrewWMSmith)))",
      "screen_name" : "smidbob",
      "protected" : false,
      "id_str" : "26227666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/413672768597553152\/zn8dL1tC_normal.jpeg",
      "id" : 26227666,
      "verified" : false
    }
  },
  "id" : 866525070084251648,
  "created_at" : "2017-05-22 05:24:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404818574119, 8.753420943335499 ]
  },
  "id_str" : "866347838346862596",
  "text" : "Someone\u2019s asking the hard questions on buying citizenship: \u00ABDoes Malta's Citizenship Program Accept Bitcoins?\u00BB",
  "id" : 866347838346862596,
  "created_at" : "2017-05-21 17:39:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/866247660772216832\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/UcaxhdPkYA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DAWHp9fXcAAbDTO.jpg",
      "id_str" : "866247658289197056",
      "id" : 866247658289197056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAWHp9fXcAAbDTO.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/UcaxhdPkYA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "866247660772216832",
  "text" : "Stay Weird, Offenbach. https:\/\/t.co\/UcaxhdPkYA",
  "id" : 866247660772216832,
  "created_at" : "2017-05-21 11:01:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JONATHAN KEMP",
      "screen_name" : "JonathanMKemp",
      "indices" : [ 3, 17 ],
      "id_str" : "249190827",
      "id" : 249190827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/53bV4a8asx",
      "expanded_url" : "https:\/\/www.theguardian.com\/books\/2017\/may\/20\/peter-ackroyd-interview-2000-years-gay-life-london?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/books\/2017\/may\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "866209910954045440",
  "text" : "RT @JonathanMKemp: Peter Ackroyd: A secret history \u2013 2,000 years of gay life in London https:\/\/t.co\/53bV4a8asx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/53bV4a8asx",
        "expanded_url" : "https:\/\/www.theguardian.com\/books\/2017\/may\/20\/peter-ackroyd-interview-2000-years-gay-life-london?CMP=share_btn_tw",
        "display_url" : "theguardian.com\/books\/2017\/may\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "866039255008727042",
    "text" : "Peter Ackroyd: A secret history \u2013 2,000 years of gay life in London https:\/\/t.co\/53bV4a8asx",
    "id" : 866039255008727042,
    "created_at" : "2017-05-20 21:13:43 +0000",
    "user" : {
      "name" : "JONATHAN KEMP",
      "screen_name" : "JonathanMKemp",
      "protected" : false,
      "id_str" : "249190827",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/862642335842263040\/z_-W8gA9_normal.jpg",
      "id" : 249190827,
      "verified" : false
    }
  },
  "id" : 866209910954045440,
  "created_at" : "2017-05-21 08:31:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elisabeth Bik",
      "screen_name" : "MicrobiomDigest",
      "indices" : [ 3, 19 ],
      "id_str" : "2154127088",
      "id" : 2154127088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "865976737846505474",
  "text" : "RT @MicrobiomDigest: The Microbiome Medicine Summit is all about people first scaring the audience with false claims, then selling products\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "865974891635384320",
    "geo" : { },
    "id_str" : "865975285111377920",
    "in_reply_to_user_id" : 2154127088,
    "text" : "The Microbiome Medicine Summit is all about people first scaring the audience with false claims, then selling products fixing it.",
    "id" : 865975285111377920,
    "in_reply_to_status_id" : 865974891635384320,
    "created_at" : "2017-05-20 16:59:31 +0000",
    "in_reply_to_screen_name" : "MicrobiomDigest",
    "in_reply_to_user_id_str" : "2154127088",
    "user" : {
      "name" : "Elisabeth Bik",
      "screen_name" : "MicrobiomDigest",
      "protected" : false,
      "id_str" : "2154127088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/830281046994337793\/63nIgeB3_normal.jpg",
      "id" : 2154127088,
      "verified" : true
    }
  },
  "id" : 865976737846505474,
  "created_at" : "2017-05-20 17:05:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/865883636226285568\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/m2vVPNNDja",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DAQ8jwmXcAE3NKr.jpg",
      "id_str" : "865883613400887297",
      "id" : 865883613400887297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAQ8jwmXcAE3NKr.jpg",
      "sizes" : [ {
        "h" : 1622,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2348,
        "resize" : "fit",
        "w" : 2965
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 950,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/m2vVPNNDja"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "865972436872945666",
  "text" : "RT @gedankenstuecke: How the gay agenda learned to push all the right buttons. https:\/\/t.co\/m2vVPNNDja",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/865883636226285568\/photo\/1",
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/m2vVPNNDja",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DAQ8jwmXcAE3NKr.jpg",
        "id_str" : "865883613400887297",
        "id" : 865883613400887297,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAQ8jwmXcAE3NKr.jpg",
        "sizes" : [ {
          "h" : 1622,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2348,
          "resize" : "fit",
          "w" : 2965
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 950,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/m2vVPNNDja"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.11410405751327, 8.75336934045893 ]
    },
    "id_str" : "865883636226285568",
    "text" : "How the gay agenda learned to push all the right buttons. https:\/\/t.co\/m2vVPNNDja",
    "id" : 865883636226285568,
    "created_at" : "2017-05-20 10:55:20 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 865972436872945666,
  "created_at" : "2017-05-20 16:48:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865965779765911553",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11391433965903, 8.753543357447615 ]
  },
  "id_str" : "865966308210479104",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski Glad you\u2019re set, and I think we would find a way to meet your needs.",
  "id" : 865966308210479104,
  "in_reply_to_status_id" : 865965779765911553,
  "created_at" : "2017-05-20 16:23:51 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865877223831744512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403586530031, 8.753404980235938 ]
  },
  "id_str" : "865963951808491520",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski Need a place here for the night?",
  "id" : 865963951808491520,
  "in_reply_to_status_id" : 865877223831744512,
  "created_at" : "2017-05-20 16:14:29 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/865883636226285568\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/m2vVPNNDja",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DAQ8jwmXcAE3NKr.jpg",
      "id_str" : "865883613400887297",
      "id" : 865883613400887297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAQ8jwmXcAE3NKr.jpg",
      "sizes" : [ {
        "h" : 1622,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2348,
        "resize" : "fit",
        "w" : 2965
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 950,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/m2vVPNNDja"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11410405751327, 8.75336934045893 ]
  },
  "id_str" : "865883636226285568",
  "text" : "How the gay agenda learned to push all the right buttons. https:\/\/t.co\/m2vVPNNDja",
  "id" : 865883636226285568,
  "created_at" : "2017-05-20 10:55:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/YymBPthijx",
      "expanded_url" : "https:\/\/twitter.com\/PhdGeek\/status\/865570598696747008",
      "display_url" : "twitter.com\/PhdGeek\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234864898517, 8.627546303029662 ]
  },
  "id_str" : "865583650083131392",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon that\u2019s one for you! https:\/\/t.co\/YymBPthijx",
  "id" : 865583650083131392,
  "created_at" : "2017-05-19 15:03:18 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 3, 11 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "865583569623711745",
  "text" : "RT @PhdGeek: Over 18? Played a Civilization game? Like to help me with my research? For Phase 1 you don't need to be in Sheffield https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/laLqXwr9tv",
        "expanded_url" : "https:\/\/sites.google.com\/sheffield.ac.uk\/civilizationvi-research-study\/home",
        "display_url" : "sites.google.com\/sheffield.ac.u\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "865570598696747008",
    "text" : "Over 18? Played a Civilization game? Like to help me with my research? For Phase 1 you don't need to be in Sheffield https:\/\/t.co\/laLqXwr9tv",
    "id" : 865570598696747008,
    "created_at" : "2017-05-19 14:11:26 +0000",
    "user" : {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "protected" : false,
      "id_str" : "27841081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745191411327328256\/PI3LgJTF_normal.jpg",
      "id" : 27841081,
      "verified" : false
    }
  },
  "id" : 865583569623711745,
  "created_at" : "2017-05-19 15:02:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Saket Choudhary",
      "screen_name" : "saketkc",
      "indices" : [ 14, 22 ],
      "id_str" : "85301360",
      "id" : 85301360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865497265833562112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235022960306, 8.627538579117084 ]
  },
  "id_str" : "865497904668065792",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @saketkc same for me, my starred list is so huge and nevertheless i never look there :D",
  "id" : 865497904668065792,
  "in_reply_to_status_id" : 865497265833562112,
  "created_at" : "2017-05-19 09:22:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saket Choudhary",
      "screen_name" : "saketkc",
      "indices" : [ 0, 8 ],
      "id_str" : "85301360",
      "id" : 85301360
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 9, 22 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865474709978136577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234445156682, 8.627530004905543 ]
  },
  "id_str" : "865474818082168833",
  "in_reply_to_user_id" : 85301360,
  "text" : "@saketkc @PhilippBayer Oh, that\u2019s awesome!",
  "id" : 865474818082168833,
  "in_reply_to_status_id" : 865474709978136577,
  "created_at" : "2017-05-19 07:50:51 +0000",
  "in_reply_to_screen_name" : "saketkc",
  "in_reply_to_user_id_str" : "85301360",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865423554396905472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.13749799230148, 8.670684043326109 ]
  },
  "id_str" : "865467237712384001",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Is this how haplotype networks have been rebranded? :)",
  "id" : 865467237712384001,
  "in_reply_to_status_id" : 865423554396905472,
  "created_at" : "2017-05-19 07:20:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Bluth",
      "screen_name" : "RealGeorgeBluth",
      "indices" : [ 3, 19 ],
      "id_str" : "771043453367050242",
      "id" : 771043453367050242
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RealGeorgeBluth\/status\/865368664282812416\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/t7gkvydNu9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DAJoNAdV0AAKxga.jpg",
      "id_str" : "865368651079208960",
      "id" : 865368651079208960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAJoNAdV0AAKxga.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/t7gkvydNu9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "865464533892055044",
  "text" : "RT @RealGeorgeBluth: Someone sent me this https:\/\/t.co\/t7gkvydNu9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RealGeorgeBluth\/status\/865368664282812416\/photo\/1",
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/t7gkvydNu9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DAJoNAdV0AAKxga.jpg",
        "id_str" : "865368651079208960",
        "id" : 865368651079208960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAJoNAdV0AAKxga.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/t7gkvydNu9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "865368664282812416",
    "text" : "Someone sent me this https:\/\/t.co\/t7gkvydNu9",
    "id" : 865368664282812416,
    "created_at" : "2017-05-19 00:49:01 +0000",
    "user" : {
      "name" : "George Bluth",
      "screen_name" : "RealGeorgeBluth",
      "protected" : false,
      "id_str" : "771043453367050242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771044120710094848\/MAVGo7qo_normal.jpg",
      "id" : 771043453367050242,
      "verified" : false
    }
  },
  "id" : 865464533892055044,
  "created_at" : "2017-05-19 07:09:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/cpwzIUI59P",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BUOyz4sFHCC\/",
      "display_url" : "instagram.com\/p\/BUOyz4sFHCC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "865300357425115136",
  "text" : "RT @gedankenstuecke: Yes, we are training UNIX wizards here, why? https:\/\/t.co\/cpwzIUI59P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/cpwzIUI59P",
        "expanded_url" : "https:\/\/www.instagram.com\/p\/BUOyz4sFHCC\/",
        "display_url" : "instagram.com\/p\/BUOyz4sFHCC\/"
      } ]
    },
    "geo" : { },
    "id_str" : "865159410624204800",
    "text" : "Yes, we are training UNIX wizards here, why? https:\/\/t.co\/cpwzIUI59P",
    "id" : 865159410624204800,
    "created_at" : "2017-05-18 10:57:32 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 865300357425115136,
  "created_at" : "2017-05-18 20:17:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 3, 17 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/phylogenomics\/status\/865256390469832704\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/TgWy2niKWx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DAICGZ_VYAEjC9K.jpg",
      "id_str" : "865256387487555585",
      "id" : 865256387487555585,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAICGZ_VYAEjC9K.jpg",
      "sizes" : [ {
        "h" : 465,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/TgWy2niKWx"
    } ],
    "hashtags" : [ {
      "text" : "UCDavis",
      "indices" : [ 22, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/2RLDmctpnH",
      "expanded_url" : "http:\/\/phylogenomics.me\/2017\/05\/18\/at-ucdavis-525-526-an-open-digital-global-south-risks-and-rewards\/",
      "display_url" : "phylogenomics.me\/2017\/05\/18\/at-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "865259775986212864",
  "text" : "RT @phylogenomics: At #UCDavis 5\/25-5\/26: An open digital global South: risks and\u00A0rewards https:\/\/t.co\/2RLDmctpnH https:\/\/t.co\/TgWy2niKWx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/phylogenomics\/status\/865256390469832704\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/TgWy2niKWx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DAICGZ_VYAEjC9K.jpg",
        "id_str" : "865256387487555585",
        "id" : 865256387487555585,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DAICGZ_VYAEjC9K.jpg",
        "sizes" : [ {
          "h" : 465,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 684,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 684,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 684,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/TgWy2niKWx"
      } ],
      "hashtags" : [ {
        "text" : "UCDavis",
        "indices" : [ 3, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/2RLDmctpnH",
        "expanded_url" : "http:\/\/phylogenomics.me\/2017\/05\/18\/at-ucdavis-525-526-an-open-digital-global-south-risks-and-rewards\/",
        "display_url" : "phylogenomics.me\/2017\/05\/18\/at-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "865256390469832704",
    "text" : "At #UCDavis 5\/25-5\/26: An open digital global South: risks and\u00A0rewards https:\/\/t.co\/2RLDmctpnH https:\/\/t.co\/TgWy2niKWx",
    "id" : 865256390469832704,
    "created_at" : "2017-05-18 17:22:53 +0000",
    "user" : {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "protected" : false,
      "id_str" : "15154811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751288576403382273\/AKfTiFxx_normal.jpg",
      "id" : 15154811,
      "verified" : true
    }
  },
  "id" : 865259775986212864,
  "created_at" : "2017-05-18 17:36:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865238394934149120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16531027858161, 8.641699589796962 ]
  },
  "id_str" : "865238448764071937",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog \uD83D\uDE18\uD83D\uDC4D",
  "id" : 865238448764071937,
  "in_reply_to_status_id" : 865238394934149120,
  "created_at" : "2017-05-18 16:11:36 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865238025403486208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16613279473983, 8.633662518121891 ]
  },
  "id_str" : "865238144257597440",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog Please vote for it!",
  "id" : 865238144257597440,
  "in_reply_to_status_id" : 865238025403486208,
  "created_at" : "2017-05-18 16:10:23 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865234046409945088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230471797894, 8.627537547904218 ]
  },
  "id_str" : "865234929562652672",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg By now I even learned that part!",
  "id" : 865234929562652672,
  "in_reply_to_status_id" : 865234046409945088,
  "created_at" : "2017-05-18 15:57:37 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865214927010758656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236168773712, 8.62752181136187 ]
  },
  "id_str" : "865226439171473408",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer looking forward to get some work done! \uD83D\uDC4D",
  "id" : 865226439171473408,
  "in_reply_to_status_id" : 865214927010758656,
  "created_at" : "2017-05-18 15:23:52 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231843281507, 8.627547915603362 ]
  },
  "id_str" : "865225814916431873",
  "text" : "\u00ABOf course I know how to say no in Greek. I watched 2 seasons of Downton Abbey with Greek subtitles because I downloaded the wrong torrent!\u00BB",
  "id" : 865225814916431873,
  "created_at" : "2017-05-18 15:21:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    }, {
      "name" : "L3viathan",
      "screen_name" : "L3viathan2142",
      "indices" : [ 17, 31 ],
      "id_str" : "23305817",
      "id" : 23305817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865218704543543298",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234658916432, 8.627538747813421 ]
  },
  "id_str" : "865219911861379072",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess @L3viathan2142 wenn der Algorithmus halt eine bimodale Verteilung ausgibt, was soll eins machen? :D",
  "id" : 865219911861379072,
  "in_reply_to_status_id" : 865218704543543298,
  "created_at" : "2017-05-18 14:57:56 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 67, 83 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "genomes",
      "indices" : [ 45, 53 ]
    }, {
      "text" : "privacy",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/5hHD0C6Dhu",
      "expanded_url" : "https:\/\/twitter.com\/a_blasimme\/status\/865197970173698048",
      "display_url" : "twitter.com\/a_blasimme\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "865203861925089280",
  "text" : "RT @EffyVayena: Check out our recent blog on #genomes and #privacy @gedankenstuecke https:\/\/t.co\/5hHD0C6Dhu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 51, 67 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "genomes",
        "indices" : [ 29, 37 ]
      }, {
        "text" : "privacy",
        "indices" : [ 42, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/5hHD0C6Dhu",
        "expanded_url" : "https:\/\/twitter.com\/a_blasimme\/status\/865197970173698048",
        "display_url" : "twitter.com\/a_blasimme\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "865202947575222272",
    "text" : "Check out our recent blog on #genomes and #privacy @gedankenstuecke https:\/\/t.co\/5hHD0C6Dhu",
    "id" : 865202947575222272,
    "created_at" : "2017-05-18 13:50:32 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 865203861925089280,
  "created_at" : "2017-05-18 13:54:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Confuse",
      "screen_name" : "confuseret",
      "indices" : [ 0, 11 ],
      "id_str" : "356708991",
      "id" : 356708991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865198104500482048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232278897468, 8.627541398839538 ]
  },
  "id_str" : "865198348747321344",
  "in_reply_to_user_id" : 356708991,
  "text" : "@confuseret which would be weird, given that they have my exact date of birth linked to my profile :D",
  "id" : 865198348747321344,
  "in_reply_to_status_id" : 865198104500482048,
  "created_at" : "2017-05-18 13:32:15 +0000",
  "in_reply_to_screen_name" : "confuseret",
  "in_reply_to_user_id_str" : "356708991",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Schindler",
      "screen_name" : "presroi",
      "indices" : [ 0, 8 ],
      "id_str" : "20447568",
      "id" : 20447568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865190009736966144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233538769462, 8.627526500590195 ]
  },
  "id_str" : "865190210182754304",
  "in_reply_to_user_id" : 20447568,
  "text" : "@presroi now I feel very monolingual in comparison!",
  "id" : 865190210182754304,
  "in_reply_to_status_id" : 865190009736966144,
  "created_at" : "2017-05-18 12:59:55 +0000",
  "in_reply_to_screen_name" : "presroi",
  "in_reply_to_user_id_str" : "20447568",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Schindler",
      "screen_name" : "presroi",
      "indices" : [ 0, 8 ],
      "id_str" : "20447568",
      "id" : 20447568
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 9, 19 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865188937287032832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232240629298, 8.627547734555426 ]
  },
  "id_str" : "865189062809964544",
  "in_reply_to_user_id" : 20447568,
  "text" : "@presroi @Fischblog \u201Ebetween 0-2 legs.\u201C",
  "id" : 865189062809964544,
  "in_reply_to_status_id" : 865188937287032832,
  "created_at" : "2017-05-18 12:55:21 +0000",
  "in_reply_to_screen_name" : "presroi",
  "in_reply_to_user_id_str" : "20447568",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egon Willigh\u24D0gen",
      "screen_name" : "egonwillighagen",
      "indices" : [ 3, 19 ],
      "id_str" : "22911650",
      "id" : 22911650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "865188560323964928",
  "text" : "RT @egonwillighagen: nice! got no votes left, but when I figure out how to remove votes elsewhere, I'll give some upvotes https:\/\/t.co\/MeuM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/MeuM03BUSK",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/865184506378145792",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "865185950112116736",
    "text" : "nice! got no votes left, but when I figure out how to remove votes elsewhere, I'll give some upvotes https:\/\/t.co\/MeuM03BUSK",
    "id" : 865185950112116736,
    "created_at" : "2017-05-18 12:42:59 +0000",
    "user" : {
      "name" : "Egon Willigh\u24D0gen",
      "screen_name" : "egonwillighagen",
      "protected" : false,
      "id_str" : "22911650",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668462090655371264\/SBzaDNdf_normal.png",
      "id" : 22911650,
      "verified" : false
    }
  },
  "id" : 865188560323964928,
  "created_at" : "2017-05-18 12:53:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathias Schindler",
      "screen_name" : "presroi",
      "indices" : [ 0, 8 ],
      "id_str" : "20447568",
      "id" : 20447568
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 9, 19 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865187560154439681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237128153681, 8.627513361363661 ]
  },
  "id_str" : "865188504510320640",
  "in_reply_to_user_id" : 20447568,
  "text" : "@presroi @Fischblog yep, see how well 95% CI\u2019s work! 99% CI is probably \u201E0-120 years old\u201C",
  "id" : 865188504510320640,
  "in_reply_to_status_id" : 865187560154439681,
  "created_at" : "2017-05-18 12:53:08 +0000",
  "in_reply_to_screen_name" : "presroi",
  "in_reply_to_user_id_str" : "20447568",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 0, 9 ],
      "id_str" : "81582697",
      "id" : 81582697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865187990775226368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237128153681, 8.627513361363661 ]
  },
  "id_str" : "865188075290460160",
  "in_reply_to_user_id" : 81582697,
  "text" : "@viirus42 same for me. That\u2019s the funniest bit about it.",
  "id" : 865188075290460160,
  "in_reply_to_status_id" : 865187990775226368,
  "created_at" : "2017-05-18 12:51:26 +0000",
  "in_reply_to_screen_name" : "viirus42",
  "in_reply_to_user_id_str" : "81582697",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865186990232403968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234744946654, 8.627532430540215 ]
  },
  "id_str" : "865187314456252416",
  "in_reply_to_user_id" : 14286491,
  "text" : "It also thinks I speak Spanish, French, Indonesian, Danish, Swedish, Latvian, Hebrew, Polish, Italian, Persian &amp; German (besides English)",
  "id" : 865187314456252416,
  "in_reply_to_status_id" : 865186990232403968,
  "created_at" : "2017-05-18 12:48:24 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Ch5EudgxXe",
      "expanded_url" : "https:\/\/twitter.com\/lil_bruises\/status\/864971302528065536",
      "display_url" : "twitter.com\/lil_bruises\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234744946654, 8.627532430540215 ]
  },
  "id_str" : "865186990232403968",
  "text" : "It also tries to guess your age range. Mine is 13-54. If that isn\u2019t a useful guesstimate. https:\/\/t.co\/Ch5EudgxXe",
  "id" : 865186990232403968,
  "created_at" : "2017-05-18 12:47:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ORCID Organization",
      "screen_name" : "ORCID_Org",
      "indices" : [ 0, 10 ],
      "id_str" : "148815591",
      "id" : 148815591
    }, {
      "name" : "L",
      "screen_name" : "lina",
      "indices" : [ 11, 16 ],
      "id_str" : "1581861",
      "id" : 1581861
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 17, 31 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Egon Willigh\u24D0gen",
      "screen_name" : "egonwillighagen",
      "indices" : [ 70, 86 ],
      "id_str" : "22911650",
      "id" : 22911650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/MxVQpiTp0i",
      "expanded_url" : "https:\/\/support.orcid.org\/forums\/175591-orcid-ideas-forum\/suggestions\/19321798-allow-staying-logged-in",
      "display_url" : "support.orcid.org\/forums\/175591-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "865154024839852032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233855903224, 8.6275402221547 ]
  },
  "id_str" : "865184506378145792",
  "in_reply_to_user_id" : 148815591,
  "text" : "@ORCID_Org @lina @Protohedgehog https:\/\/t.co\/MxVQpiTp0i there you go. @egonwillighagen",
  "id" : 865184506378145792,
  "in_reply_to_status_id" : 865154024839852032,
  "created_at" : "2017-05-18 12:37:15 +0000",
  "in_reply_to_screen_name" : "ORCID_Org",
  "in_reply_to_user_id_str" : "148815591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Driscoll",
      "screen_name" : "caseydriscoll",
      "indices" : [ 0, 14 ],
      "id_str" : "218733347",
      "id" : 218733347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865164104050376705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232805418219, 8.627542662706258 ]
  },
  "id_str" : "865176411438534656",
  "in_reply_to_user_id" : 218733347,
  "text" : "@caseydriscoll there are tons of ninjas in that picture, they\u2019re just doing an excellent job!",
  "id" : 865176411438534656,
  "in_reply_to_status_id" : 865164104050376705,
  "created_at" : "2017-05-18 12:05:05 +0000",
  "in_reply_to_screen_name" : "caseydriscoll",
  "in_reply_to_user_id_str" : "218733347",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/cpwzIUI59P",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BUOyz4sFHCC\/",
      "display_url" : "instagram.com\/p\/BUOyz4sFHCC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "865159410624204800",
  "text" : "Yes, we are training UNIX wizards here, why? https:\/\/t.co\/cpwzIUI59P",
  "id" : 865159410624204800,
  "created_at" : "2017-05-18 10:57:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 16, 27 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/RUIAqC6RDK",
      "expanded_url" : "https:\/\/twitter.com\/ehafen\/status\/865143240097509377",
      "display_url" : "twitter.com\/ehafen\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723285191711, 8.627544569891874 ]
  },
  "id_str" : "865154956143230976",
  "text" : "Congratulations @EffyVayena \uD83C\uDF89 https:\/\/t.co\/RUIAqC6RDK",
  "id" : 865154956143230976,
  "created_at" : "2017-05-18 10:39:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 14, 24 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "865139014063472641",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231325037874, 8.627537379260648 ]
  },
  "id_str" : "865144373004058624",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Fischblog aye, same here. Nach 2+ Wochen in \uD83C\uDDFA\uD83C\uDDF8\/\uD83C\uDDE8\uD83C\uDDE6 vor ein paar Wochen war ich schon so froh \u00FCber richtiges Brot. \uD83D\uDE02",
  "id" : 865144373004058624,
  "in_reply_to_status_id" : 865139014063472641,
  "created_at" : "2017-05-18 09:57:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/0T7O5F9hoW",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/xTiTnuItjH9y5z4vNS\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/xTiTnuIt\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229831748161, 8.627543479346066 ]
  },
  "id_str" : "865110477499715586",
  "text" : "Colleague forwards email for a \u201ECareer Event\u201C at the European Central Bank. Can totally see me working there\u2026 https:\/\/t.co\/0T7O5F9hoW",
  "id" : 865110477499715586,
  "created_at" : "2017-05-18 07:43:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/1lb3SfjR3K",
      "expanded_url" : "https:\/\/twitter.com\/SteveMcLaugh\/status\/865018845219762177",
      "display_url" : "twitter.com\/SteveMcLaugh\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16650476813484, 8.63618541851351 ]
  },
  "id_str" : "865095065303212033",
  "text" : "1991 called and wants its terminology back. https:\/\/t.co\/1lb3SfjR3K",
  "id" : 865095065303212033,
  "created_at" : "2017-05-18 06:41:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve McLaughlin\uD83C\uDF3E\uD83D\uDCBE",
      "screen_name" : "SteveMcLaugh",
      "indices" : [ 3, 16 ],
      "id_str" : "7841792",
      "id" : 7841792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/sblsKX650v",
      "expanded_url" : "http:\/\/www.stephenmclaughlin.net\/Elsevier_v_Sci-Hub\/2017-05-16\/",
      "display_url" : "stephenmclaughlin.net\/Elsevier_v_Sci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "865094906389422080",
  "text" : "RT @SteveMcLaugh: All the docs from Elsevier's default judgment filing against Sci-Hub are here: https:\/\/t.co\/sblsKX650v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/sblsKX650v",
        "expanded_url" : "http:\/\/www.stephenmclaughlin.net\/Elsevier_v_Sci-Hub\/2017-05-16\/",
        "display_url" : "stephenmclaughlin.net\/Elsevier_v_Sci\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "865002008515719168",
    "geo" : { },
    "id_str" : "865005726426554372",
    "in_reply_to_user_id" : 7841792,
    "text" : "All the docs from Elsevier's default judgment filing against Sci-Hub are here: https:\/\/t.co\/sblsKX650v",
    "id" : 865005726426554372,
    "in_reply_to_status_id" : 865002008515719168,
    "created_at" : "2017-05-18 00:46:50 +0000",
    "in_reply_to_screen_name" : "SteveMcLaugh",
    "in_reply_to_user_id_str" : "7841792",
    "user" : {
      "name" : "Steve McLaughlin\uD83C\uDF3E\uD83D\uDCBE",
      "screen_name" : "SteveMcLaugh",
      "protected" : false,
      "id_str" : "7841792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776533899555909633\/MvNi9Ve5_normal.jpg",
      "id" : 7841792,
      "verified" : false
    }
  },
  "id" : 865094906389422080,
  "created_at" : "2017-05-18 06:41:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EffyVayena\/status\/864842298378649602\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/7pOEdORfP7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DACJNzwXgAMSuQf.jpg",
      "id_str" : "864841998779514883",
      "id" : 864841998779514883,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DACJNzwXgAMSuQf.jpg",
      "sizes" : [ {
        "h" : 579,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/7pOEdORfP7"
    } ],
    "hashtags" : [ {
      "text" : "privacy",
      "indices" : [ 29, 37 ]
    }, {
      "text" : "AllMalePanels",
      "indices" : [ 56, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/fFoDXD9Yoe",
      "expanded_url" : "http:\/\/www.news.uzh.ch\/de\/articles\/2017\/Rethink-Privacy.html",
      "display_url" : "news.uzh.ch\/de\/articles\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "864974182643322880",
  "text" : "RT @EffyVayena: Yes, rethink #privacy! And while at it, #AllMalePanels too. \nhttps:\/\/t.co\/fFoDXD9Yoe https:\/\/t.co\/7pOEdORfP7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EffyVayena\/status\/864842298378649602\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/7pOEdORfP7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DACJNzwXgAMSuQf.jpg",
        "id_str" : "864841998779514883",
        "id" : 864841998779514883,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DACJNzwXgAMSuQf.jpg",
        "sizes" : [ {
          "h" : 579,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/7pOEdORfP7"
      } ],
      "hashtags" : [ {
        "text" : "privacy",
        "indices" : [ 13, 21 ]
      }, {
        "text" : "AllMalePanels",
        "indices" : [ 40, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/fFoDXD9Yoe",
        "expanded_url" : "http:\/\/www.news.uzh.ch\/de\/articles\/2017\/Rethink-Privacy.html",
        "display_url" : "news.uzh.ch\/de\/articles\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "864842298378649602",
    "text" : "Yes, rethink #privacy! And while at it, #AllMalePanels too. \nhttps:\/\/t.co\/fFoDXD9Yoe https:\/\/t.co\/7pOEdORfP7",
    "id" : 864842298378649602,
    "created_at" : "2017-05-17 13:57:26 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 864974182643322880,
  "created_at" : "2017-05-17 22:41:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jarett Wieselman",
      "screen_name" : "JarettSays",
      "indices" : [ 3, 14 ],
      "id_str" : "17468528",
      "id" : 17468528
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JarettSays\/status\/864857355883880452\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/bXT0C31SEP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DACUmhMXsAEtPql.jpg",
      "id_str" : "864854517921329153",
      "id" : 864854517921329153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DACUmhMXsAEtPql.jpg",
      "sizes" : [ {
        "h" : 389,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 1014
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 1014
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 1014
      } ],
      "display_url" : "pic.twitter.com\/bXT0C31SEP"
    } ],
    "hashtags" : [ {
      "text" : "ArrestedDevelopment",
      "indices" : [ 16, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/yMHbTTbGTv",
      "expanded_url" : "https:\/\/www.buzzfeed.com\/scottybryan\/arrested-development-season-five-is-officially-happening",
      "display_url" : "buzzfeed.com\/scottybryan\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "864938429041324033",
  "text" : "RT @JarettSays: #ArrestedDevelopment creator on why they're coming back for a fifth season https:\/\/t.co\/yMHbTTbGTv https:\/\/t.co\/bXT0C31SEP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JarettSays\/status\/864857355883880452\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/bXT0C31SEP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DACUmhMXsAEtPql.jpg",
        "id_str" : "864854517921329153",
        "id" : 864854517921329153,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DACUmhMXsAEtPql.jpg",
        "sizes" : [ {
          "h" : 389,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 580,
          "resize" : "fit",
          "w" : 1014
        }, {
          "h" : 580,
          "resize" : "fit",
          "w" : 1014
        }, {
          "h" : 580,
          "resize" : "fit",
          "w" : 1014
        } ],
        "display_url" : "pic.twitter.com\/bXT0C31SEP"
      } ],
      "hashtags" : [ {
        "text" : "ArrestedDevelopment",
        "indices" : [ 0, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/yMHbTTbGTv",
        "expanded_url" : "https:\/\/www.buzzfeed.com\/scottybryan\/arrested-development-season-five-is-officially-happening",
        "display_url" : "buzzfeed.com\/scottybryan\/ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "864857355883880452",
    "text" : "#ArrestedDevelopment creator on why they're coming back for a fifth season https:\/\/t.co\/yMHbTTbGTv https:\/\/t.co\/bXT0C31SEP",
    "id" : 864857355883880452,
    "created_at" : "2017-05-17 14:57:16 +0000",
    "user" : {
      "name" : "Jarett Wieselman",
      "screen_name" : "JarettSays",
      "protected" : false,
      "id_str" : "17468528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846834744029413376\/dWubvTjb_normal.jpg",
      "id" : 17468528,
      "verified" : true
    }
  },
  "id" : 864938429041324033,
  "created_at" : "2017-05-17 20:19:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/l4ZV05Uxuz",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BUNAsuTFTAc\/",
      "display_url" : "instagram.com\/p\/BUNAsuTFTAc\/"
    } ]
  },
  "geo" : { },
  "id_str" : "864908476132319232",
  "text" : "so close https:\/\/t.co\/l4ZV05Uxuz",
  "id" : 864908476132319232,
  "created_at" : "2017-05-17 18:20:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anson W. Mackay",
      "screen_name" : "AnsonMackay",
      "indices" : [ 0, 12 ],
      "id_str" : "18426460",
      "id" : 18426460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "864889524446474240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.12978769992463, 8.672898591493894 ]
  },
  "id_str" : "864897667322830848",
  "in_reply_to_user_id" : 18426460,
  "text" : "@AnsonMackay a relic of colonialism and shared language?",
  "id" : 864897667322830848,
  "in_reply_to_status_id" : 864889524446474240,
  "created_at" : "2017-05-17 17:37:27 +0000",
  "in_reply_to_screen_name" : "AnsonMackay",
  "in_reply_to_user_id_str" : "18426460",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egon Willigh\u24D0gen",
      "screen_name" : "egonwillighagen",
      "indices" : [ 0, 16 ],
      "id_str" : "22911650",
      "id" : 22911650
    }, {
      "name" : "Konrad F\u00F6rstner",
      "screen_name" : "konradfoerstner",
      "indices" : [ 17, 33 ],
      "id_str" : "15150655",
      "id" : 15150655
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/864895446656970753\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/Yphbk1so36",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DAC50H7XYAAb1jY.jpg",
      "id_str" : "864895433587515392",
      "id" : 864895433587515392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DAC50H7XYAAb1jY.jpg",
      "sizes" : [ {
        "h" : 164,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 164,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 164,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 164,
        "resize" : "fit",
        "w" : 244
      } ],
      "display_url" : "pic.twitter.com\/Yphbk1so36"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "864886566082281472",
  "geo" : { },
  "id_str" : "864895446656970753",
  "in_reply_to_user_id" : 22911650,
  "text" : "@egonwillighagen @konradfoerstner Maybe like this? https:\/\/t.co\/Yphbk1so36",
  "id" : 864895446656970753,
  "in_reply_to_status_id" : 864886566082281472,
  "created_at" : "2017-05-17 17:28:38 +0000",
  "in_reply_to_screen_name" : "egonwillighagen",
  "in_reply_to_user_id_str" : "22911650",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L",
      "screen_name" : "lina",
      "indices" : [ 0, 5 ],
      "id_str" : "1581861",
      "id" : 1581861
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 6, 20 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "ORCID Organization",
      "screen_name" : "ORCID_Org",
      "indices" : [ 21, 31 ],
      "id_str" : "148815591",
      "id" : 148815591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "864880268619825152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231125249156, 8.627542933740576 ]
  },
  "id_str" : "864880969588801536",
  "in_reply_to_user_id" : 1581861,
  "text" : "@lina @Protohedgehog @ORCID_Org expect to remain logged in after leaving the website and returning some time later. Instead logs out. No logouts during usage.",
  "id" : 864880969588801536,
  "in_reply_to_status_id" : 864880268619825152,
  "created_at" : "2017-05-17 16:31:06 +0000",
  "in_reply_to_screen_name" : "lina",
  "in_reply_to_user_id_str" : "1581861",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L",
      "screen_name" : "lina",
      "indices" : [ 0, 5 ],
      "id_str" : "1581861",
      "id" : 1581861
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 6, 20 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "ORCID Organization",
      "screen_name" : "ORCID_Org",
      "indices" : [ 21, 31 ],
      "id_str" : "148815591",
      "id" : 148815591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "864869969162493953",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228439440211, 8.627531199514088 ]
  },
  "id_str" : "864870231696695296",
  "in_reply_to_user_id" : 1581861,
  "text" : "@lina @Protohedgehog @ORCID_Org The latter. Which is why every other website offers \u201Cstay logged in\u201D. \uD83D\uDE09 the former used to happen as well though.",
  "id" : 864870231696695296,
  "in_reply_to_status_id" : 864869969162493953,
  "created_at" : "2017-05-17 15:48:26 +0000",
  "in_reply_to_screen_name" : "lina",
  "in_reply_to_user_id_str" : "1581861",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "864868073664393218",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230718108052, 8.627529810523503 ]
  },
  "id_str" : "864868644400050176",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr \u201Ewe\u2019ll never forget your identity\u201C \u202615 min later\u2026 \u201Ewho\u2019re you again?\u201C",
  "id" : 864868644400050176,
  "in_reply_to_status_id" : 864868073664393218,
  "created_at" : "2017-05-17 15:42:07 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230461558047, 8.627530950676812 ]
  },
  "id_str" : "864867212552790020",
  "text" : "It\u2019s funny how ORCID is our persistent identifier, yet it logs me out (in what feels like) every 15 minutes.",
  "id" : 864867212552790020,
  "created_at" : "2017-05-17 15:36:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mika McKinnon",
      "screen_name" : "mikamckinnon",
      "indices" : [ 3, 16 ],
      "id_str" : "44562973",
      "id" : 44562973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "864721874785193984",
  "text" : "RT @mikamckinnon: Q: Why do we have whisper networks?\nA: Because it makes no difference when we identify harassers. Fuck this so much.\nhttp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/h4m0ITCAq3",
        "expanded_url" : "https:\/\/twitter.com\/stephevz43\/status\/864589658465779712",
        "display_url" : "twitter.com\/stephevz43\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "864662146742796289",
    "text" : "Q: Why do we have whisper networks?\nA: Because it makes no difference when we identify harassers. Fuck this so much.\nhttps:\/\/t.co\/h4m0ITCAq3",
    "id" : 864662146742796289,
    "created_at" : "2017-05-17 02:01:35 +0000",
    "user" : {
      "name" : "Mika McKinnon",
      "screen_name" : "mikamckinnon",
      "protected" : false,
      "id_str" : "44562973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746073510838050816\/v7nEdWx8_normal.jpg",
      "id" : 44562973,
      "verified" : true
    }
  },
  "id" : 864721874785193984,
  "created_at" : "2017-05-17 05:58:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "_katsel",
      "indices" : [ 0, 8 ],
      "id_str" : "892038837052076033",
      "id" : 892038837052076033
    }, {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 17, 28 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "864565758524887040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401801840412, 8.753388952472017 ]
  },
  "id_str" : "864595802345406468",
  "in_reply_to_user_id" : 730326143295959040,
  "text" : "@_katsel pinging @RaeKnowler!",
  "id" : 864595802345406468,
  "in_reply_to_status_id" : 864565758524887040,
  "created_at" : "2017-05-16 21:37:57 +0000",
  "in_reply_to_screen_name" : "katheyrina",
  "in_reply_to_user_id_str" : "730326143295959040",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/ONoPS9rpxB",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/N6hRSFXBTrP44\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/N6hRSFXB\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "864591351773573120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404780687053, 8.753420425797827 ]
  },
  "id_str" : "864593454319489024",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Grow stronger...fight another day\u2026 https:\/\/t.co\/ONoPS9rpxB :D",
  "id" : 864593454319489024,
  "in_reply_to_status_id" : 864591351773573120,
  "created_at" : "2017-05-16 21:28:37 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/864591462373183489\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/6QTgOnPLAr",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C_-lTySUAAADR_h.jpg",
      "id_str" : "864591412813103104",
      "id" : 864591412813103104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C_-lTySUAAADR_h.jpg",
      "sizes" : [ {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/6QTgOnPLAr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "864591028027875328",
  "geo" : { },
  "id_str" : "864591462373183489",
  "in_reply_to_user_id" : 14286491,
  "text" : "Guess I'll have to take a deeper look into the literature now. https:\/\/t.co\/6QTgOnPLAr",
  "id" : 864591462373183489,
  "in_reply_to_status_id" : 864591028027875328,
  "created_at" : "2017-05-16 21:20:42 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404933432861, 8.753420314945377 ]
  },
  "id_str" : "864591028027875328",
  "text" : "Last 13h: Going from \u2018none of this makes sense\u2019 to \u2018wow, that\u2019s a great result\u2019 to \u2018oh wait, it\u2019s a technical artefact\u2019\u2026  \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 864591028027875328,
  "created_at" : "2017-05-16 21:18:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "864550888324681730",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11264767808606, 8.755076049175992 ]
  },
  "id_str" : "864557324077289472",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick If you\u2019re a bioinformatics consultant it\u2019s a sure way to rack up lots of billable hours \uD83D\uDE02",
  "id" : 864557324077289472,
  "in_reply_to_status_id" : 864550888324681730,
  "created_at" : "2017-05-16 19:05:03 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "indices" : [ 3, 16 ],
      "id_str" : "228437800",
      "id" : 228437800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/TbZnUigzLk",
      "expanded_url" : "http:\/\/www.bbc.com\/culture\/story\/20170515-a-passport-from-a-country-that-doesnt-exist?ocid=ww.social.link.twitter",
      "display_url" : "bbc.com\/culture\/story\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "864554294082768898",
  "text" : "RT @atossaaraxia: A passport from a country that doesn\u2019t exist https:\/\/t.co\/TbZnUigzLk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/TbZnUigzLk",
        "expanded_url" : "http:\/\/www.bbc.com\/culture\/story\/20170515-a-passport-from-a-country-that-doesnt-exist?ocid=ww.social.link.twitter",
        "display_url" : "bbc.com\/culture\/story\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "864548105760509952",
    "text" : "A passport from a country that doesn\u2019t exist https:\/\/t.co\/TbZnUigzLk",
    "id" : 864548105760509952,
    "created_at" : "2017-05-16 18:28:25 +0000",
    "user" : {
      "name" : "Atossa Araxia Abrahamian",
      "screen_name" : "atossaaraxia",
      "protected" : false,
      "id_str" : "228437800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707884522738728960\/VqnZwF27_normal.jpg",
      "id" : 228437800,
      "verified" : true
    }
  },
  "id" : 864554294082768898,
  "created_at" : "2017-05-16 18:53:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 3, 9 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "UW eScience",
      "screen_name" : "uwescience",
      "indices" : [ 46, 57 ],
      "id_str" : "20826738",
      "id" : 20826738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "864545239922593793",
  "text" : "RT @shefw: We're hosting a site in Seattle at @uwescience! Register now so I know what snacks to bring (also taking requests). https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UW eScience",
        "screen_name" : "uwescience",
        "indices" : [ 35, 46 ],
        "id_str" : "20826738",
        "id" : 20826738
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/lj3Fo06v2d",
        "expanded_url" : "http:\/\/bit.ly\/2qoeDjG",
        "display_url" : "bit.ly\/2qoeDjG"
      }, {
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/vhb7FkKFNW",
        "expanded_url" : "https:\/\/twitter.com\/MozillaScience\/status\/864182650541555713",
        "display_url" : "twitter.com\/MozillaScience\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "864185285898256387",
    "text" : "We're hosting a site in Seattle at @uwescience! Register now so I know what snacks to bring (also taking requests). https:\/\/t.co\/lj3Fo06v2d https:\/\/t.co\/vhb7FkKFNW",
    "id" : 864185285898256387,
    "created_at" : "2017-05-15 18:26:42 +0000",
    "user" : {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "protected" : false,
      "id_str" : "48636190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677947392080019456\/CHnYz4aV_normal.jpg",
      "id" : 48636190,
      "verified" : false
    }
  },
  "id" : 864545239922593793,
  "created_at" : "2017-05-16 18:17:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "864472101285011456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234318151613, 8.627535312383014 ]
  },
  "id_str" : "864472252515049472",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy started editing the script a bit, made a WIP-PR on GH, feedback appreciated \uD83D\uDE0A",
  "id" : 864472252515049472,
  "in_reply_to_status_id" : 864472101285011456,
  "created_at" : "2017-05-16 13:27:00 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "864449475850493952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234806273748, 8.627536654010726 ]
  },
  "id_str" : "864466849647525888",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima let me know if there\u2019s one, happy to provide data for my group.",
  "id" : 864466849647525888,
  "in_reply_to_status_id" : 864449475850493952,
  "created_at" : "2017-05-16 13:05:32 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 3, 17 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "864466797629779968",
  "text" : "RT @NazeefaFatima: also looking for data wrt # of men &amp; women working\/studying in bioinfo\/genomics labs! Wasn't there a hashtag re M:W rati\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "864248082002833408",
    "geo" : { },
    "id_str" : "864449475850493952",
    "in_reply_to_user_id" : 37054704,
    "text" : "also looking for data wrt # of men &amp; women working\/studying in bioinfo\/genomics labs! Wasn't there a hashtag re M:W ratio in science labs?",
    "id" : 864449475850493952,
    "in_reply_to_status_id" : 864248082002833408,
    "created_at" : "2017-05-16 11:56:30 +0000",
    "in_reply_to_screen_name" : "NazeefaFatima",
    "in_reply_to_user_id_str" : "37054704",
    "user" : {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "protected" : false,
      "id_str" : "37054704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930210077885202432\/DY8D8hGM_normal.jpg",
      "id" : 37054704,
      "verified" : false
    }
  },
  "id" : 864466797629779968,
  "created_at" : "2017-05-16 13:05:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vadim Zaytsev",
      "screen_name" : "grammarware",
      "indices" : [ 0, 12 ],
      "id_str" : "29290365",
      "id" : 29290365
    }, {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 13, 18 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "864457336856993792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233309265159, 8.627555898730892 ]
  },
  "id_str" : "864458993531531264",
  "in_reply_to_user_id" : 29290365,
  "text" : "@grammarware @johl so it\u2019s \u00B1 from entomology to etymology, to confuse everyone even more. \uD83D\uDE02",
  "id" : 864458993531531264,
  "in_reply_to_status_id" : 864457336856993792,
  "created_at" : "2017-05-16 12:34:19 +0000",
  "in_reply_to_screen_name" : "grammarware",
  "in_reply_to_user_id_str" : "29290365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vadim Zaytsev",
      "screen_name" : "grammarware",
      "indices" : [ 0, 12 ],
      "id_str" : "29290365",
      "id" : 29290365
    }, {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 13, 18 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/UBd1SlzpeT",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Colorado_potato_beetle",
      "display_url" : "en.wikipedia.org\/wiki\/Colorado_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "864431702961270784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231988952371, 8.627545568415218 ]
  },
  "id_str" : "864453543763345408",
  "in_reply_to_user_id" : 29290365,
  "text" : "@grammarware @johl looks like a beetle to me :p https:\/\/t.co\/UBd1SlzpeT",
  "id" : 864453543763345408,
  "in_reply_to_status_id" : 864431702961270784,
  "created_at" : "2017-05-16 12:12:40 +0000",
  "in_reply_to_screen_name" : "grammarware",
  "in_reply_to_user_id_str" : "29290365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucy Patterson",
      "screen_name" : "lu_cyP",
      "indices" : [ 0, 7 ],
      "id_str" : "99586343",
      "id" : 99586343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "864421719372648448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1725123714234, 8.627260010470565 ]
  },
  "id_str" : "864427420010643456",
  "in_reply_to_user_id" : 99586343,
  "text" : "@lu_cyP Can\u2019t judge that. :-)",
  "id" : 864427420010643456,
  "in_reply_to_status_id" : 864421719372648448,
  "created_at" : "2017-05-16 10:28:51 +0000",
  "in_reply_to_screen_name" : "lu_cyP",
  "in_reply_to_user_id_str" : "99586343",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucy Patterson",
      "screen_name" : "lu_cyP",
      "indices" : [ 0, 7 ],
      "id_str" : "99586343",
      "id" : 99586343
    }, {
      "name" : "Mz Baltazars Lab",
      "screen_name" : "MzBaltazarsLab",
      "indices" : [ 8, 23 ],
      "id_str" : "273987817",
      "id" : 273987817
    }, {
      "name" : "Open Hardware Summit",
      "screen_name" : "ohsummit",
      "indices" : [ 24, 33 ],
      "id_str" : "189235485",
      "id" : 189235485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/FGWhoFp7lr",
      "expanded_url" : "https:\/\/www.mynfp.de\/ibutton\/",
      "display_url" : "mynfp.de\/ibutton\/"
    } ]
  },
  "in_reply_to_status_id_str" : "864402554121322496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232994179222, 8.627537821043965 ]
  },
  "id_str" : "864413590874443776",
  "in_reply_to_user_id" : 99586343,
  "text" : "@lu_cyP @MzBaltazarsLab @ohsummit seems there\u2019s some requests for it, pretty much DIY so far. (link in german) https:\/\/t.co\/FGWhoFp7lr",
  "id" : 864413590874443776,
  "in_reply_to_status_id" : 864402554121322496,
  "created_at" : "2017-05-16 09:33:54 +0000",
  "in_reply_to_screen_name" : "lu_cyP",
  "in_reply_to_user_id_str" : "99586343",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 7, 15 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/864411220442587136\/photo\/1",
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/kImrSoGV3J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C_8Ba4mUMAYB1jl.png",
      "id_str" : "864411214859743238",
      "id" : 864411214859743238,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_8Ba4mUMAYB1jl.png",
      "sizes" : [ {
        "h" : 90,
        "resize" : "crop",
        "w" : 90
      }, {
        "h" : 90,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 90,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 90,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 90,
        "resize" : "fit",
        "w" : 484
      } ],
      "display_url" : "pic.twitter.com\/kImrSoGV3J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232839648634, 8.627535364867885 ]
  },
  "id_str" : "864411220442587136",
  "text" : "Thanks @heyaudy! https:\/\/t.co\/kImrSoGV3J",
  "id" : 864411220442587136,
  "created_at" : "2017-05-16 09:24:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucy Patterson",
      "screen_name" : "lu_cyP",
      "indices" : [ 3, 10 ],
      "id_str" : "99586343",
      "id" : 99586343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openhardware",
      "indices" : [ 25, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "864387621677654016",
  "text" : "RT @lu_cyP: Only 1.5% in #openhardware are women. On hacking\/hardware as performance of masculinity - Stefanie Wuschitz\nhttps:\/\/t.co\/PHHolR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lu_cyP\/status\/864386395850366976\/photo\/1",
        "indices" : [ 132, 155 ],
        "url" : "https:\/\/t.co\/ikSM6oEEok",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C_7q16CXUAEa2qa.jpg",
        "id_str" : "864386390334853121",
        "id" : 864386390334853121,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_7q16CXUAEa2qa.jpg",
        "sizes" : [ {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/ikSM6oEEok"
      } ],
      "hashtags" : [ {
        "text" : "openhardware",
        "indices" : [ 13, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/PHHolRq22l",
        "expanded_url" : "https:\/\/youtu.be\/fuu-jrxLGzU",
        "display_url" : "youtu.be\/fuu-jrxLGzU"
      } ]
    },
    "geo" : { },
    "id_str" : "864386395850366976",
    "text" : "Only 1.5% in #openhardware are women. On hacking\/hardware as performance of masculinity - Stefanie Wuschitz\nhttps:\/\/t.co\/PHHolRq22l https:\/\/t.co\/ikSM6oEEok",
    "id" : 864386395850366976,
    "created_at" : "2017-05-16 07:45:50 +0000",
    "user" : {
      "name" : "Lucy Patterson",
      "screen_name" : "lu_cyP",
      "protected" : false,
      "id_str" : "99586343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000178318979\/04210a37d910f734cabe01698bb747f0_normal.jpeg",
      "id" : 99586343,
      "verified" : false
    }
  },
  "id" : 864387621677654016,
  "created_at" : "2017-05-16 07:50:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "864298118363348992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11038918711535, 8.695259526132494 ]
  },
  "id_str" : "864371683888693248",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime \u201C&amp;shrug;\u201D translates to that in my replacements config \uD83D\uDE02",
  "id" : 864371683888693248,
  "in_reply_to_status_id" : 864298118363348992,
  "created_at" : "2017-05-16 06:47:23 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 3, 13 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phd",
      "indices" : [ 38, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/h6YgOq93PP",
      "expanded_url" : "https:\/\/twitter.com\/biophysicalfrog\/status\/863941540099407872",
      "display_url" : "twitter.com\/biophysicalfro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "864370175851642880",
  "text" : "RT @Julie_B92: Excellent responses re #phd students' and supervisors' respective responsibilities and expectations https:\/\/t.co\/h6YgOq93PP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "phd",
        "indices" : [ 23, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/h6YgOq93PP",
        "expanded_url" : "https:\/\/twitter.com\/biophysicalfrog\/status\/863941540099407872",
        "display_url" : "twitter.com\/biophysicalfro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "864285275916124160",
    "text" : "Excellent responses re #phd students' and supervisors' respective responsibilities and expectations https:\/\/t.co\/h6YgOq93PP",
    "id" : 864285275916124160,
    "created_at" : "2017-05-16 01:04:02 +0000",
    "user" : {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "protected" : false,
      "id_str" : "1385861262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/813827716151644160\/JvmX-W-T_normal.jpg",
      "id" : 1385861262,
      "verified" : false
    }
  },
  "id" : 864370175851642880,
  "created_at" : "2017-05-16 06:41:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Granados",
      "screen_name" : "Monsauce",
      "indices" : [ 3, 12 ],
      "id_str" : "297073565",
      "id" : 297073565
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozillaGlobalSprint",
      "indices" : [ 106, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "864368015067889664",
  "text" : "RT @Monsauce: Help build a mobile app for vital fish consumption data! We are looking for app developers! #MozillaGlobalSprint https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Monsauce\/status\/864184473503584256\/photo\/1",
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/wEjCi0lZwP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C_4ywyJXkAEzSsy.jpg",
        "id_str" : "864183992177889281",
        "id" : 864183992177889281,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_4ywyJXkAEzSsy.jpg",
        "sizes" : [ {
          "h" : 909,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 909,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 909,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 561
        } ],
        "display_url" : "pic.twitter.com\/wEjCi0lZwP"
      } ],
      "hashtags" : [ {
        "text" : "MozillaGlobalSprint",
        "indices" : [ 92, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/6qJHNWyEiw",
        "expanded_url" : "https:\/\/github.com\/Monsauce\/Open-the-North",
        "display_url" : "github.com\/Monsauce\/Open-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "864184473503584256",
    "text" : "Help build a mobile app for vital fish consumption data! We are looking for app developers! #MozillaGlobalSprint https:\/\/t.co\/6qJHNWyEiw https:\/\/t.co\/wEjCi0lZwP",
    "id" : 864184473503584256,
    "created_at" : "2017-05-15 18:23:28 +0000",
    "user" : {
      "name" : "Monica Granados",
      "screen_name" : "Monsauce",
      "protected" : false,
      "id_str" : "297073565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923942258285703173\/YiCqvvhD_normal.jpg",
      "id" : 297073565,
      "verified" : false
    }
  },
  "id" : 864368015067889664,
  "created_at" : "2017-05-16 06:32:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 3, 17 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "864253317727301632",
  "text" : "RT @NazeefaFatima: Looking for gender balance\/diversity surveys (+ results) &amp;\/or observations wrt participation at bioinformatics\/genomics\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "864248082002833408",
    "text" : "Looking for gender balance\/diversity surveys (+ results) &amp;\/or observations wrt participation at bioinformatics\/genomics conferences.",
    "id" : 864248082002833408,
    "created_at" : "2017-05-15 22:36:14 +0000",
    "user" : {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "protected" : false,
      "id_str" : "37054704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930210077885202432\/DY8D8hGM_normal.jpg",
      "id" : 37054704,
      "verified" : false
    }
  },
  "id" : 864253317727301632,
  "created_at" : "2017-05-15 22:57:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathilde Cordellier",
      "screen_name" : "m_cordellier",
      "indices" : [ 0, 13 ],
      "id_str" : "3373710875",
      "id" : 3373710875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "864223016301023232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398993998941, 8.753427913410244 ]
  },
  "id_str" : "864223134236495873",
  "in_reply_to_user_id" : 3373710875,
  "text" : "@m_cordellier Yep, spot on.",
  "id" : 864223134236495873,
  "in_reply_to_status_id" : 864223016301023232,
  "created_at" : "2017-05-15 20:57:06 +0000",
  "in_reply_to_screen_name" : "m_cordellier",
  "in_reply_to_user_id_str" : "3373710875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/864212791661649920\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/QSDRi8dSRz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C_5M8_rXUAAB0C0.jpg",
      "id_str" : "864212789270892544",
      "id" : 864212789270892544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_5M8_rXUAAB0C0.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/QSDRi8dSRz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "864212791661649920",
  "text" : "Solved that Catch-22 and even filed my taxes today. Adulting level \uD83D\uDC54\uD83D\uDC74! https:\/\/t.co\/QSDRi8dSRz",
  "id" : 864212791661649920,
  "created_at" : "2017-05-15 20:16:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 130, 153 ],
      "url" : "https:\/\/t.co\/MBdQwaW292",
      "expanded_url" : "https:\/\/twitter.com\/sujaik\/status\/864151972160655360",
      "display_url" : "twitter.com\/sujaik\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1016516540886, 8.711894403342544 ]
  },
  "id_str" : "864152698417016833",
  "text" : "Shortly after: \u201Cwe need to charge ridiculous APCs to make sure we are sustainable and content will not just vanish one day!\u201D \uD83E\uDD37\u200D\u2640\uFE0F https:\/\/t.co\/MBdQwaW292",
  "id" : 864152698417016833,
  "created_at" : "2017-05-15 16:17:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 2, 25 ],
      "url" : "https:\/\/t.co\/Rlk9zlP60L",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BUG-aLtlqF7\/",
      "display_url" : "instagram.com\/p\/BUG-aLtlqF7\/"
    } ]
  },
  "geo" : { },
  "id_str" : "864059019736080385",
  "text" : "\uD83C\uDF44 https:\/\/t.co\/Rlk9zlP60L",
  "id" : 864059019736080385,
  "created_at" : "2017-05-15 10:04:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 14, 21 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "864021739910582273",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234372443674, 8.627536904565668 ]
  },
  "id_str" : "864022953465401344",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @sujaik yikes! I see!",
  "id" : 864022953465401344,
  "in_reply_to_status_id" : 864021739910582273,
  "created_at" : "2017-05-15 07:41:39 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 14, 21 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "864001373918044161",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11384083596167, 8.753737629373008 ]
  },
  "id_str" : "864012971843911680",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @sujaik There\u2019s `samtools merge`, isn\u2019t there?",
  "id" : 864012971843911680,
  "in_reply_to_status_id" : 864001373918044161,
  "created_at" : "2017-05-15 07:01:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/WqZQglzARq",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BUGgU8TFsz7\/",
      "display_url" : "instagram.com\/p\/BUGgU8TFsz7\/"
    } ]
  },
  "geo" : { },
  "id_str" : "863992865743130624",
  "text" : "out in the fog https:\/\/t.co\/WqZQglzARq",
  "id" : 863992865743130624,
  "created_at" : "2017-05-15 05:42:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VALIUM",
      "screen_name" : "alibi_rage",
      "indices" : [ 0, 11 ],
      "id_str" : "971867420",
      "id" : 971867420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "863705136006385664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11384677612233, 8.753211339943812 ]
  },
  "id_str" : "863705418601771009",
  "in_reply_to_user_id" : 971867420,
  "text" : "@alibi_rage wtf?! \uD83E\uDD22",
  "id" : 863705418601771009,
  "in_reply_to_status_id" : 863705136006385664,
  "created_at" : "2017-05-14 10:39:53 +0000",
  "in_reply_to_screen_name" : "alibi_rage",
  "in_reply_to_user_id_str" : "971867420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 12, 21 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "863433962127052801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11278592054742, 8.755592973910975 ]
  },
  "id_str" : "863437211685068802",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo @wilbanks Is there anything he can\u2019t do!? \uD83D\uDE0D",
  "id" : 863437211685068802,
  "in_reply_to_status_id" : 863433962127052801,
  "created_at" : "2017-05-13 16:54:07 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 38, 47 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "863395179549655040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11376262633607, 8.753396688878178 ]
  },
  "id_str" : "863433571662532609",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo \uD83D\uDC96 (and at first I thought @wilbanks was joking when he offered to officiate for me! \uD83D\uDE02)",
  "id" : 863433571662532609,
  "in_reply_to_status_id" : 863395179549655040,
  "created_at" : "2017-05-13 16:39:39 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/863164723558322177\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/OmUf5pfktK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C_qTvahXoAAi4Go.jpg",
      "id_str" : "863164721377288192",
      "id" : 863164721377288192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_qTvahXoAAi4Go.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/OmUf5pfktK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "863164723558322177",
  "text" : "I just got a pair of banned books socks! \uD83D\uDCDA\uD83D\uDE0D\uD83D\uDC96 https:\/\/t.co\/OmUf5pfktK",
  "id" : 863164723558322177,
  "created_at" : "2017-05-12 22:51:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11372058657008, 8.753958586611555 ]
  },
  "id_str" : "863088706479161344",
  "text" : "Sent out the last draft that I wanted to get done this week! \uD83C\uDF89",
  "id" : 863088706479161344,
  "created_at" : "2017-05-12 17:49:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "863071272179294208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11317404826823, 8.754370754291104 ]
  },
  "id_str" : "863088470281121794",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski I frequently end up being \u201CDr. Bastian B\u201D. \uD83E\uDD37\u200D\u2640\uFE0F",
  "id" : 863088470281121794,
  "in_reply_to_status_id" : 863071272179294208,
  "created_at" : "2017-05-12 17:48:21 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 3, 16 ],
      "id_str" : "478181304",
      "id" : 478181304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "863071159293808640",
  "text" : "RT @Mcarthur_Joe: Who do I know that 1) hates paywalls 2) likes repos 3) has time I can pay them for 4) can do dull but important stuff 5)\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "863070695961636864",
    "text" : "Who do I know that 1) hates paywalls 2) likes repos 3) has time I can pay them for 4) can do dull but important stuff 5) can \"view source\"",
    "id" : 863070695961636864,
    "created_at" : "2017-05-12 16:37:43 +0000",
    "user" : {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "protected" : false,
      "id_str" : "478181304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718826277923328001\/itMaougV_normal.jpg",
      "id" : 478181304,
      "verified" : false
    }
  },
  "id" : 863071159293808640,
  "created_at" : "2017-05-12 16:39:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/bBxMRtDBRn",
      "expanded_url" : "https:\/\/twitter.com\/ApfelCider\/status\/862793041228292097",
      "display_url" : "twitter.com\/ApfelCider\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234705742412, 8.627543078256119 ]
  },
  "id_str" : "862998817188261889",
  "text" : "I think this explains why i always preferred zoology over botany. https:\/\/t.co\/bBxMRtDBRn",
  "id" : 862998817188261889,
  "created_at" : "2017-05-12 11:52:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "862965843205947393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233801209115, 8.627546376717898 ]
  },
  "id_str" : "862968270340710405",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics any time :p",
  "id" : 862968270340710405,
  "in_reply_to_status_id" : 862965843205947393,
  "created_at" : "2017-05-12 09:50:43 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "862965209916375041",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233334591413, 8.627534993386298 ]
  },
  "id_str" : "862965437159673856",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics thanks for sharing! \uD83D\uDC96",
  "id" : 862965437159673856,
  "in_reply_to_status_id" : 862965209916375041,
  "created_at" : "2017-05-12 09:39:27 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/5odMTVpKQR",
      "expanded_url" : "https:\/\/s-media-cache-ak0.pinimg.com\/originals\/08\/99\/17\/0899177b000012371a8b59a0e54dbab4.jpg",
      "display_url" : "s-media-cache-ak0.pinimg.com\/originals\/08\/9\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "862963863045668866",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237640743252, 8.62752726119991 ]
  },
  "id_str" : "862964646252347392",
  "in_reply_to_user_id" : 14286491,
  "text" : "That pretty much fits a lot of my \u201Eadvanced\u201C git experiences. https:\/\/t.co\/5odMTVpKQR",
  "id" : 862964646252347392,
  "in_reply_to_status_id" : 862963863045668866,
  "created_at" : "2017-05-12 09:36:19 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 138, 161 ],
      "url" : "https:\/\/t.co\/UDfNct23YL",
      "expanded_url" : "https:\/\/twitter.com\/nikitonsky\/status\/862567109129367553",
      "display_url" : "twitter.com\/nikitonsky\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237640743252, 8.62752726119991 ]
  },
  "id_str" : "862963863045668866",
  "text" : "On Git: \u00AB\u2026the behaviour we observe is not one typically associated with mastery, it is much closer to [\u2026] learned ritualistic behaviour\u2026\u00BB https:\/\/t.co\/UDfNct23YL",
  "id" : 862963863045668866,
  "created_at" : "2017-05-12 09:33:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Pearce \uD83E\uDD85",
      "screen_name" : "mattdpearce",
      "indices" : [ 3, 15 ],
      "id_str" : "69004966",
      "id" : 69004966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/PkvNboaSiL",
      "expanded_url" : "https:\/\/www.mcsweeneys.net\/articles\/winners-and-losers-of-the-recent-nuclear-holocaust",
      "display_url" : "mcsweeneys.net\/articles\/winne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "862935581977923584",
  "text" : "RT @mattdpearce: oh my god https:\/\/t.co\/PkvNboaSiL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/PkvNboaSiL",
        "expanded_url" : "https:\/\/www.mcsweeneys.net\/articles\/winners-and-losers-of-the-recent-nuclear-holocaust",
        "display_url" : "mcsweeneys.net\/articles\/winne\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "862920435913998336",
    "text" : "oh my god https:\/\/t.co\/PkvNboaSiL",
    "id" : 862920435913998336,
    "created_at" : "2017-05-12 06:40:38 +0000",
    "user" : {
      "name" : "Matt Pearce \uD83E\uDD85",
      "screen_name" : "mattdpearce",
      "protected" : false,
      "id_str" : "69004966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819704914402082817\/3V5UvanD_normal.jpg",
      "id" : 69004966,
      "verified" : true
    }
  },
  "id" : 862935581977923584,
  "created_at" : "2017-05-12 07:40:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404924305248, 8.753420497391685 ]
  },
  "id_str" : "862816813075267586",
  "text" : "@kopshtik living the dream!",
  "id" : 862816813075267586,
  "created_at" : "2017-05-11 23:48:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/1XFaRljsQO",
      "expanded_url" : "https:\/\/twitter.com\/godtributes\/status\/862801739459821568",
      "display_url" : "twitter.com\/godtributes\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140475313387, 8.75342350908116 ]
  },
  "id_str" : "862802069476036608",
  "text" : "Legit description of the sciences\u2026 https:\/\/t.co\/1XFaRljsQO",
  "id" : 862802069476036608,
  "created_at" : "2017-05-11 22:50:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Polka",
      "screen_name" : "jessicapolka",
      "indices" : [ 3, 16 ],
      "id_str" : "252204344",
      "id" : 252204344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "862801712742109185",
  "text" : "RT @jessicapolka: This complacency is so depressing, but understandable given the precarious position of many early career researchers (thr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 126, 149 ],
        "url" : "https:\/\/t.co\/rhCHi6B6O7",
        "expanded_url" : "https:\/\/twitter.com\/AdrianaBankston\/status\/862766789704470531",
        "display_url" : "twitter.com\/AdrianaBanksto\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "862782856262713344",
    "text" : "This complacency is so depressing, but understandable given the precarious position of many early career researchers (thread) https:\/\/t.co\/rhCHi6B6O7",
    "id" : 862782856262713344,
    "created_at" : "2017-05-11 21:33:57 +0000",
    "user" : {
      "name" : "Jessica Polka",
      "screen_name" : "jessicapolka",
      "protected" : false,
      "id_str" : "252204344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/853464465307729921\/Co0F1lRI_normal.jpg",
      "id" : 252204344,
      "verified" : true
    }
  },
  "id" : 862801712742109185,
  "created_at" : "2017-05-11 22:48:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404945433097, 8.753422545382598 ]
  },
  "id_str" : "862745924707201024",
  "text" : "One more draft down, one more to go. \uD83C\uDF89",
  "id" : 862745924707201024,
  "created_at" : "2017-05-11 19:07:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Biopython Project",
      "screen_name" : "Biopython",
      "indices" : [ 9, 19 ],
      "id_str" : "26723969",
      "id" : 26723969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "862713030534197248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404865315664, 8.753423516755891 ]
  },
  "id_str" : "862730323351810048",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @Biopython Looks so good! \uD83D\uDC96",
  "id" : 862730323351810048,
  "in_reply_to_status_id" : 862713030534197248,
  "created_at" : "2017-05-11 18:05:12 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Biopython Project",
      "screen_name" : "Biopython",
      "indices" : [ 3, 13 ],
      "id_str" : "26723969",
      "id" : 26723969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "862723449525084164",
  "text" : "RT @Biopython: We'd like all our contributors &amp; interested users to vote on a potential new Biopython Logo - instructions at https:\/\/t.co\/f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/fMpRKeHH78",
        "expanded_url" : "https:\/\/github.com\/biopython\/biopython.github.io\/pull\/116#issuecomment-300630718",
        "display_url" : "github.com\/biopython\/biop\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "861705615130980353",
    "geo" : { },
    "id_str" : "862710099126747136",
    "in_reply_to_user_id" : 26723969,
    "text" : "We'd like all our contributors &amp; interested users to vote on a potential new Biopython Logo - instructions at https:\/\/t.co\/fMpRKeHH78",
    "id" : 862710099126747136,
    "in_reply_to_status_id" : 861705615130980353,
    "created_at" : "2017-05-11 16:44:50 +0000",
    "in_reply_to_screen_name" : "Biopython",
    "in_reply_to_user_id_str" : "26723969",
    "user" : {
      "name" : "Biopython Project",
      "screen_name" : "Biopython",
      "protected" : false,
      "id_str" : "26723969",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/873181729133142016\/bL8u1gY9_normal.jpg",
      "id" : 26723969,
      "verified" : false
    }
  },
  "id" : 862723449525084164,
  "created_at" : "2017-05-11 17:37:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 0, 13 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "862711411864092673",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404957655301, 8.753418811844387 ]
  },
  "id_str" : "862711609269026817",
  "in_reply_to_user_id" : 760870811494297600,
  "text" : "@blueyedgenes happy to help out with it! And yes, I\u2019m super stoked about the paper, so good to make this publicly available!",
  "id" : 862711609269026817,
  "in_reply_to_status_id" : 862711411864092673,
  "created_at" : "2017-05-11 16:50:50 +0000",
  "in_reply_to_screen_name" : "blueyedgenes",
  "in_reply_to_user_id_str" : "760870811494297600",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Van Noorden",
      "screen_name" : "Richvn",
      "indices" : [ 0, 7 ],
      "id_str" : "19766166",
      "id" : 19766166
    }, {
      "name" : "Michael Markie",
      "screen_name" : "MMMarksman",
      "indices" : [ 8, 19 ],
      "id_str" : "237650650",
      "id" : 237650650
    }, {
      "name" : "TimesHigherEducation",
      "screen_name" : "timeshighered",
      "indices" : [ 20, 34 ],
      "id_str" : "23602600",
      "id" : 23602600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "862662087582994438",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235089467462, 8.627560542057351 ]
  },
  "id_str" : "862692910147547140",
  "in_reply_to_user_id" : 19766166,
  "text" : "@Richvn @MMMarksman @timeshighered doesn\u2019t exactly hurt to have some data on that, does it? \uD83D\uDE0A",
  "id" : 862692910147547140,
  "in_reply_to_status_id" : 862662087582994438,
  "created_at" : "2017-05-11 15:36:32 +0000",
  "in_reply_to_screen_name" : "Richvn",
  "in_reply_to_user_id_str" : "19766166",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 19, 29 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/KNBeOFxMJ9",
      "expanded_url" : "http:\/\/bauhiniagenome.hk\/2017\/05\/bauhinia-x-goes-tedx\/",
      "display_url" : "bauhiniagenome.hk\/2017\/05\/bauhin\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235089467462, 8.627560542057351 ]
  },
  "id_str" : "862692631570243586",
  "text" : "Great TEDx-talk by @SCEdmunds on how the crowdfunded\/sourced sequencing of Bauhinia empowers students! https:\/\/t.co\/KNBeOFxMJ9",
  "id" : 862692631570243586,
  "created_at" : "2017-05-11 15:35:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Markie",
      "screen_name" : "MMMarksman",
      "indices" : [ 0, 11 ],
      "id_str" : "237650650",
      "id" : 237650650
    }, {
      "name" : "TimesHigherEducation",
      "screen_name" : "timeshighered",
      "indices" : [ 12, 26 ],
      "id_str" : "23602600",
      "id" : 23602600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "862597312320860160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233977568751, 8.627543197596319 ]
  },
  "id_str" : "862615705568653312",
  "in_reply_to_user_id" : 237650650,
  "text" : "@MMMarksman @timeshighered Hadn\u2019t seen that it\u2019s out. Thanks for the pointer!",
  "id" : 862615705568653312,
  "in_reply_to_status_id" : 862597312320860160,
  "created_at" : "2017-05-11 10:29:45 +0000",
  "in_reply_to_screen_name" : "MMMarksman",
  "in_reply_to_user_id_str" : "237650650",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Markie",
      "screen_name" : "MMMarksman",
      "indices" : [ 3, 14 ],
      "id_str" : "237650650",
      "id" : 237650650
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 33, 49 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "TimesHigherEducation",
      "screen_name" : "timeshighered",
      "indices" : [ 109, 123 ],
      "id_str" : "23602600",
      "id" : 23602600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "862615661436178432",
  "text" : "RT @MMMarksman: Nice coverage of @gedankenstuecke article on Sci-Hub (\"scholarly publishing\u2019s \u2018Napster\u2019\") in @timeshighered: https:\/\/t.co\/5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 17, 33 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "TimesHigherEducation",
        "screen_name" : "timeshighered",
        "indices" : [ 93, 107 ],
        "id_str" : "23602600",
        "id" : 23602600
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/5D84yDU2zJ",
        "expanded_url" : "https:\/\/www.timeshighereducation.com\/news\/sci-hub-study-suggests-publishers-embargoes-not-viable#survey-answer",
        "display_url" : "timeshighereducation.com\/news\/sci-hub-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "862597312320860160",
    "text" : "Nice coverage of @gedankenstuecke article on Sci-Hub (\"scholarly publishing\u2019s \u2018Napster\u2019\") in @timeshighered: https:\/\/t.co\/5D84yDU2zJ",
    "id" : 862597312320860160,
    "created_at" : "2017-05-11 09:16:40 +0000",
    "user" : {
      "name" : "Michael Markie",
      "screen_name" : "MMMarksman",
      "protected" : false,
      "id_str" : "237650650",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/909811703264800769\/3eUaFf-V_normal.jpg",
      "id" : 237650650,
      "verified" : false
    }
  },
  "id" : 862615661436178432,
  "created_at" : "2017-05-11 10:29:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 0, 13 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/B7wgXr5sla",
      "expanded_url" : "https:\/\/pbs.twimg.com\/profile_images\/735374825187909632\/wJEJW1zW.jpg",
      "display_url" : "pbs.twimg.com\/profile_images\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "862468907562541056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10254570514644, 8.737807596613616 ]
  },
  "id_str" : "862564511718547456",
  "in_reply_to_user_id" : 760870811494297600,
  "text" : "@blueyedgenes We\u2019re having a more recent logo if you\u2019d prefer that! :) https:\/\/t.co\/B7wgXr5sla",
  "id" : 862564511718547456,
  "in_reply_to_status_id" : 862468907562541056,
  "created_at" : "2017-05-11 07:06:19 +0000",
  "in_reply_to_screen_name" : "blueyedgenes",
  "in_reply_to_user_id_str" : "760870811494297600",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "indices" : [ 3, 19 ],
      "id_str" : "2163374389",
      "id" : 2163374389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "862438314091180032",
  "text" : "RT @existentialcoms: Maybe if in the next movie the rebels realize that they need to not only overthrow the emperor, but also the Bourgeois\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "862437014037118976",
    "geo" : { },
    "id_str" : "862438200983265280",
    "in_reply_to_user_id" : 2163374389,
    "text" : "Maybe if in the next movie the rebels realize that they need to not only overthrow the emperor, but also the Bourgeois mode of production...",
    "id" : 862438200983265280,
    "in_reply_to_status_id" : 862437014037118976,
    "created_at" : "2017-05-10 22:44:25 +0000",
    "in_reply_to_screen_name" : "existentialcoms",
    "in_reply_to_user_id_str" : "2163374389",
    "user" : {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "protected" : false,
      "id_str" : "2163374389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792916557403795456\/d-iEnfPD_normal.jpg",
      "id" : 2163374389,
      "verified" : false
    }
  },
  "id" : 862438314091180032,
  "created_at" : "2017-05-10 22:44:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "indices" : [ 3, 19 ],
      "id_str" : "2163374389",
      "id" : 2163374389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "862438299604054021",
  "text" : "RT @existentialcoms: LOL Disney issued a DMCA against my \"Class Wars\" t-shirt design. Don't you have better shit to do Disney? It's Rosa Lu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/existentialcoms\/status\/862437014037118976\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/fMYqn2Q5wT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C_f85qfUAAIUHvO.jpg",
        "id_str" : "862435921253105666",
        "id" : 862435921253105666,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_f85qfUAAIUHvO.jpg",
        "sizes" : [ {
          "h" : 846,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 602
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 846,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 846,
          "resize" : "fit",
          "w" : 749
        } ],
        "display_url" : "pic.twitter.com\/fMYqn2Q5wT"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/existentialcoms\/status\/862437014037118976\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/fMYqn2Q5wT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C_f86hCUwAARi1r.jpg",
        "id_str" : "862435935895470080",
        "id" : 862435935895470080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_f86hCUwAARi1r.jpg",
        "sizes" : [ {
          "h" : 1500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 1500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        } ],
        "display_url" : "pic.twitter.com\/fMYqn2Q5wT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "862437014037118976",
    "text" : "LOL Disney issued a DMCA against my \"Class Wars\" t-shirt design. Don't you have better shit to do Disney? It's Rosa Luxemburg in a costume. https:\/\/t.co\/fMYqn2Q5wT",
    "id" : 862437014037118976,
    "created_at" : "2017-05-10 22:39:42 +0000",
    "user" : {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "protected" : false,
      "id_str" : "2163374389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792916557403795456\/d-iEnfPD_normal.jpg",
      "id" : 2163374389,
      "verified" : false
    }
  },
  "id" : 862438299604054021,
  "created_at" : "2017-05-10 22:44:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 114, 125 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "genomic",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/H1DnsQlyL0",
      "expanded_url" : "http:\/\/dx.plos.org\/10.1371\/journal.pone.0177158",
      "display_url" : "dx.plos.org\/10.1371\/journa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "862416982456643586",
  "text" : "RT @EffyVayena: Why do people share their #genomic data? Results of our survey  https:\/\/t.co\/H1DnsQlyL0 Thank you @openSNPorg users for par\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 98, 109 ],
        "id_str" : "380205172",
        "id" : 380205172
      }, {
        "name" : "PLOS",
        "screen_name" : "PLOS",
        "indices" : [ 134, 139 ],
        "id_str" : "12819112",
        "id" : 12819112
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "genomic",
        "indices" : [ 26, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/H1DnsQlyL0",
        "expanded_url" : "http:\/\/dx.plos.org\/10.1371\/journal.pone.0177158",
        "display_url" : "dx.plos.org\/10.1371\/journa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "862239395071619072",
    "text" : "Why do people share their #genomic data? Results of our survey  https:\/\/t.co\/H1DnsQlyL0 Thank you @openSNPorg users for participating @PLOS",
    "id" : 862239395071619072,
    "created_at" : "2017-05-10 09:34:26 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 862416982456643586,
  "created_at" : "2017-05-10 21:20:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 0, 13 ],
      "id_str" : "9104202",
      "id" : 9104202
    }, {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 14, 23 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "862398610851475461",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11395056568605, 8.753544156843105 ]
  },
  "id_str" : "862399084375789568",
  "in_reply_to_user_id" : 9104202,
  "text" : "@jeroenbosman @MsPhelps \u201CBachelorstudierende\u201D would be the word I guess.",
  "id" : 862399084375789568,
  "in_reply_to_status_id" : 862398610851475461,
  "created_at" : "2017-05-10 20:08:58 +0000",
  "in_reply_to_screen_name" : "jeroenbosman",
  "in_reply_to_user_id_str" : "9104202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 10, 23 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "862397557812736001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400828557727, 8.753431319165895 ]
  },
  "id_str" : "862397677992112128",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @jeroenbosman Nah, it\u2019s fun. Just wish I could do in what feels more like the natural language for it by now.",
  "id" : 862397677992112128,
  "in_reply_to_status_id" : 862397557812736001,
  "created_at" : "2017-05-10 20:03:23 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 0, 13 ],
      "id_str" : "9104202",
      "id" : 9104202
    }, {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 14, 23 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "862395453769428992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404720839472, 8.753425040994323 ]
  },
  "id_str" : "862397279940038657",
  "in_reply_to_user_id" : 9104202,
  "text" : "@jeroenbosman @MsPhelps Yes, it is. And then I come back and get thrown into undergrad teaching. \uD83D\uDE02",
  "id" : 862397279940038657,
  "in_reply_to_status_id" : 862395453769428992,
  "created_at" : "2017-05-10 20:01:48 +0000",
  "in_reply_to_screen_name" : "jeroenbosman",
  "in_reply_to_user_id_str" : "9104202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Herterich",
      "screen_name" : "PHerterich",
      "indices" : [ 0, 11 ],
      "id_str" : "402180727",
      "id" : 402180727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "862390937930145792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404726326295, 8.753425093083653 ]
  },
  "id_str" : "862392693451890689",
  "in_reply_to_user_id" : 402180727,
  "text" : "@PHerterich Good to hear that! \uD83D\uDE02",
  "id" : 862392693451890689,
  "in_reply_to_status_id" : 862390937930145792,
  "created_at" : "2017-05-10 19:43:35 +0000",
  "in_reply_to_screen_name" : "PHerterich",
  "in_reply_to_user_id_str" : "402180727",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11396442933996, 8.753372371905007 ]
  },
  "id_str" : "862388026655346689",
  "text" : "Awkward: had to give a lecture in German and always subconsciously slipped back to English. \uD83D\uDE02",
  "id" : 862388026655346689,
  "created_at" : "2017-05-10 19:25:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "862363481064050689",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404605276895, 8.753424976184133 ]
  },
  "id_str" : "862374609240424463",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB The second step is getting rid of all the tempting items. Will email you my address to safely deposit your drugs. \uD83C\uDF6A\uD83C\uDF6B",
  "id" : 862374609240424463,
  "in_reply_to_status_id" : 862363481064050689,
  "created_at" : "2017-05-10 18:31:43 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Shockey",
      "screen_name" : "nshockey",
      "indices" : [ 0, 9 ],
      "id_str" : "16728620",
      "id" : 16728620
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/862372097569562624\/photo\/1",
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/RzoZZdwWSF",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C_fC2K0XgAAj0uQ.jpg",
      "id_str" : "862372089537462272",
      "id" : 862372089537462272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C_fC2K0XgAAj0uQ.jpg",
      "sizes" : [ {
        "h" : 316,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 316,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 316,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 316,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/RzoZZdwWSF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "862363252042469376",
  "geo" : { },
  "id_str" : "862372097569562624",
  "in_reply_to_user_id" : 16728620,
  "text" : "@nshockey More like this \uD83D\uDE09 https:\/\/t.co\/RzoZZdwWSF",
  "id" : 862372097569562624,
  "in_reply_to_status_id" : 862363252042469376,
  "created_at" : "2017-05-10 18:21:44 +0000",
  "in_reply_to_screen_name" : "nshockey",
  "in_reply_to_user_id_str" : "16728620",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "862355445113135108",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10417250921028, 8.725906703629276 ]
  },
  "id_str" : "862363387547791361",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks Don\u2019t remind me, I overcommited myself for writing stuff until next week! \uD83D\uDE31",
  "id" : 862363387547791361,
  "in_reply_to_status_id" : 862355445113135108,
  "created_at" : "2017-05-10 17:47:08 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 3, 12 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenCon",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "862361649591746561",
  "text" : "RT @open_con: Learn how the next generation is leading the way to open research &amp; education in our #OpenCon Community Report! https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/open_con\/status\/862314261623828481\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/Mjbo2fAx1a",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C_eNTK6XgAA1g6z.jpg",
        "id_str" : "862313214150934528",
        "id" : 862313214150934528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_eNTK6XgAA1g6z.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 790,
          "resize" : "fit",
          "w" : 611
        }, {
          "h" : 790,
          "resize" : "fit",
          "w" : 611
        }, {
          "h" : 790,
          "resize" : "fit",
          "w" : 611
        } ],
        "display_url" : "pic.twitter.com\/Mjbo2fAx1a"
      } ],
      "hashtags" : [ {
        "text" : "OpenCon",
        "indices" : [ 89, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/uwaArnhcfx",
        "expanded_url" : "https:\/\/sparcopen.org\/wp-content\/uploads\/2017\/05\/OpenCon-Community-Report_051017_Final.pdf",
        "display_url" : "sparcopen.org\/wp-content\/upl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "862314261623828481",
    "text" : "Learn how the next generation is leading the way to open research &amp; education in our #OpenCon Community Report! https:\/\/t.co\/uwaArnhcfx https:\/\/t.co\/Mjbo2fAx1a",
    "id" : 862314261623828481,
    "created_at" : "2017-05-10 14:31:55 +0000",
    "user" : {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "protected" : false,
      "id_str" : "2452073258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843937071534424064\/e-PdQw9V_normal.jpg",
      "id" : 2452073258,
      "verified" : false
    }
  },
  "id" : 862361649591746561,
  "created_at" : "2017-05-10 17:40:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/mWhI50fqzX",
      "expanded_url" : "https:\/\/twitter.com\/RomainBrette\/status\/862236702215196672",
      "display_url" : "twitter.com\/RomainBrette\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232711001162, 8.62755320723366 ]
  },
  "id_str" : "862343656539291648",
  "text" : "Happens to be the same 10 simple rules for how reviewers would actually love to review papers. https:\/\/t.co\/mWhI50fqzX",
  "id" : 862343656539291648,
  "created_at" : "2017-05-10 16:28:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/qL5SUiczWI",
      "expanded_url" : "https:\/\/twitter.com\/open_con\/status\/862294717383487488",
      "display_url" : "twitter.com\/open_con\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234325258386, 8.627543634148472 ]
  },
  "id_str" : "862341660994400256",
  "text" : "Join the global open* conspiracy. https:\/\/t.co\/qL5SUiczWI",
  "id" : 862341660994400256,
  "created_at" : "2017-05-10 16:20:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enrico Ferrero",
      "screen_name" : "enricoferrero",
      "indices" : [ 0, 14 ],
      "id_str" : "285852581",
      "id" : 285852581
    }, {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 95, 104 ],
      "id_str" : "495517322",
      "id" : 495517322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "862206329301159936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233128860304, 8.627573169519614 ]
  },
  "id_str" : "862206703374405632",
  "in_reply_to_user_id" : 285852581,
  "text" : "@enricoferrero we\u2019d very much like to see some collaboration to make the data more accessible. @erlichya we maybe should talk at some point about it. \uD83D\uDE0A",
  "id" : 862206703374405632,
  "in_reply_to_status_id" : 862206329301159936,
  "created_at" : "2017-05-10 07:24:31 +0000",
  "in_reply_to_screen_name" : "enricoferrero",
  "in_reply_to_user_id_str" : "285852581",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "862199848015155200",
  "text" : "RT @gedankenstuecke: Want to know from where people share their genomes on openSNP &amp; why they do it? The results of our survey are out: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/862023791937019904\/photo\/1",
        "indices" : [ 143, 166 ],
        "url" : "https:\/\/t.co\/dvDnoZyQfX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C_aGEMsW0AEVLL6.jpg",
        "id_str" : "862023785372897281",
        "id" : 862023785372897281,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_aGEMsW0AEVLL6.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1800
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/dvDnoZyQfX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/Q5LVb8VkLp",
        "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0177158",
        "display_url" : "journals.plos.org\/plosone\/articl\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.11403524652645, 8.75344023741531 ]
    },
    "id_str" : "862023791937019904",
    "text" : "Want to know from where people share their genomes on openSNP &amp; why they do it? The results of our survey are out: https:\/\/t.co\/Q5LVb8VkLp https:\/\/t.co\/dvDnoZyQfX",
    "id" : 862023791937019904,
    "created_at" : "2017-05-09 19:17:42 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 862199848015155200,
  "created_at" : "2017-05-10 06:57:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 0, 9 ],
      "id_str" : "495517322",
      "id" : 495517322
    }, {
      "name" : "bioRxiv",
      "screen_name" : "biorxivpreprint",
      "indices" : [ 10, 26 ],
      "id_str" : "1949132852",
      "id" : 1949132852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/Q5LVb8VkLp",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0177158",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "862066495676968961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140493534857, 8.753420110921219 ]
  },
  "id_str" : "862073886569107456",
  "in_reply_to_user_id" : 495517322,
  "text" : "@erlichya @biorxivpreprint congrats! Coincidentally just out today as well: https:\/\/t.co\/Q5LVb8VkLp",
  "id" : 862073886569107456,
  "in_reply_to_status_id" : 862066495676968961,
  "created_at" : "2017-05-09 22:36:45 +0000",
  "in_reply_to_screen_name" : "erlichya",
  "in_reply_to_user_id_str" : "495517322",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "862048042165440513",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11384673235037, 8.753240725414726 ]
  },
  "id_str" : "862059111873208321",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks train it to use scare quotes instead!",
  "id" : 862059111873208321,
  "in_reply_to_status_id" : 862048042165440513,
  "created_at" : "2017-05-09 21:38:03 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/KtyMyYWbc3",
      "expanded_url" : "http:\/\/www.the-scientist.com\/?articles.view\/articleNo\/49385\/title\/Opinion--Get-to-Know-Why-People-Openly-Share-Genomic-Data\/",
      "display_url" : "the-scientist.com\/?articles.view\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "862023791937019904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404812451814, 8.753421875935702 ]
  },
  "id_str" : "862053196189106178",
  "in_reply_to_user_id" : 14286491,
  "text" : "Just saw that Tobias wrote a short summary of our paper at The Scientist, if you don\u2019t feel like reading a lot: https:\/\/t.co\/KtyMyYWbc3",
  "id" : 862053196189106178,
  "in_reply_to_status_id" : 862023791937019904,
  "created_at" : "2017-05-09 21:14:32 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/ERixbCYN6i",
      "expanded_url" : "https:\/\/twitter.com\/kamal_hothi\/status\/862027677661777920",
      "display_url" : "twitter.com\/kamal_hothi\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11389804186705, 8.75308150270289 ]
  },
  "id_str" : "862031075094253568",
  "text" : "Was wearing my Anscombe\u2019s quartet shirt today and feel the urgent need to upgrade it now. https:\/\/t.co\/ERixbCYN6i",
  "id" : 862031075094253568,
  "created_at" : "2017-05-09 19:46:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "862023791937019904",
  "geo" : { },
  "id_str" : "862024505081958400",
  "in_reply_to_user_id" : 14286491,
  "text" : "Looking at the map, inclusivity in open science is definitely an issue that we\u2019ll have to address. Not only because Antarctica is missing.",
  "id" : 862024505081958400,
  "in_reply_to_status_id" : 862023791937019904,
  "created_at" : "2017-05-09 19:20:32 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/862023791937019904\/photo\/1",
      "indices" : [ 143, 166 ],
      "url" : "https:\/\/t.co\/dvDnoZyQfX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C_aGEMsW0AEVLL6.jpg",
      "id_str" : "862023785372897281",
      "id" : 862023785372897281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_aGEMsW0AEVLL6.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1800
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/dvDnoZyQfX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/Q5LVb8VkLp",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0177158",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403524652645, 8.75344023741531 ]
  },
  "id_str" : "862023791937019904",
  "text" : "Want to know from where people share their genomes on openSNP &amp; why they do it? The results of our survey are out: https:\/\/t.co\/Q5LVb8VkLp https:\/\/t.co\/dvDnoZyQfX",
  "id" : 862023791937019904,
  "created_at" : "2017-05-09 19:17:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 0, 10 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/Ze6o4FRvZF",
      "expanded_url" : "https:\/\/lovelace-media.imgix.net\/uploads\/638\/827506a0-c148-0133-7760-0e7c926a42af.gif?w=740&h=416&fit=max&auto=format",
      "display_url" : "lovelace-media.imgix.net\/uploads\/638\/82\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "862005482529185794",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405086502572, 8.75341941746435 ]
  },
  "id_str" : "862005658501173248",
  "in_reply_to_user_id" : 22839233,
  "text" : "@kaythaney https:\/\/t.co\/Ze6o4FRvZF",
  "id" : 862005658501173248,
  "in_reply_to_status_id" : 862005482529185794,
  "created_at" : "2017-05-09 18:05:38 +0000",
  "in_reply_to_screen_name" : "kaythaney",
  "in_reply_to_user_id_str" : "22839233",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 0, 10 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/C8KIlJsG0k",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/tNmk7lc4PhuAE\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/tNmk7lc4\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "862003962534350848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405086502572, 8.75341941746435 ]
  },
  "id_str" : "862005303054934017",
  "in_reply_to_user_id" : 22839233,
  "text" : "@kaythaney me, going through Instagram https:\/\/t.co\/C8KIlJsG0k",
  "id" : 862005303054934017,
  "in_reply_to_status_id" : 862003962534350848,
  "created_at" : "2017-05-09 18:04:14 +0000",
  "in_reply_to_screen_name" : "kaythaney",
  "in_reply_to_user_id_str" : "22839233",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 91, 101 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399149812175, 8.753446567449839 ]
  },
  "id_str" : "862003185979883521",
  "text" : "My Instagram ads now heavily feature collars &amp; leashes. I blame liking all of your \uD83D\uDC36\uD83D\uDCF7, @kaythaney. \uD83D\uDE02",
  "id" : 862003185979883521,
  "created_at" : "2017-05-09 17:55:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/862001448086892546\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/SfXqmQOUj3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C_Zxv14WAAE3l4Y.jpg",
      "id_str" : "862001445419220993",
      "id" : 862001445419220993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_Zxv14WAAE3l4Y.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/SfXqmQOUj3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "862001448086892546",
  "text" : "My kind of literature for the commute. https:\/\/t.co\/SfXqmQOUj3",
  "id" : 862001448086892546,
  "created_at" : "2017-05-09 17:48:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 3, 17 ],
      "id_str" : "257319757",
      "id" : 257319757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "861994113339723776",
  "text" : "RT @lorrainechu3n: This is a project initiated by my momma! Here's some background on how (and why) I'm learning to read\/write Chinese http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lorrainechu3n\/status\/861972436446834690\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/OCexQFnXhn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C_ZXWwWWsAAO7td.jpg",
        "id_str" : "861972427135430656",
        "id" : 861972427135430656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_ZXWwWWsAAO7td.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/OCexQFnXhn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/NR5OEMEVQw",
        "expanded_url" : "https:\/\/chinese-lessons-from-my-mother.tumblr.com\/about",
        "display_url" : "\u2026ese-lessons-from-my-mother.tumblr.com\/about"
      } ]
    },
    "geo" : { },
    "id_str" : "861972436446834690",
    "text" : "This is a project initiated by my momma! Here's some background on how (and why) I'm learning to read\/write Chinese https:\/\/t.co\/NR5OEMEVQw https:\/\/t.co\/OCexQFnXhn",
    "id" : 861972436446834690,
    "created_at" : "2017-05-09 15:53:38 +0000",
    "user" : {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "protected" : false,
      "id_str" : "257319757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926996461719621632\/aBq5xtJy_normal.jpg",
      "id" : 257319757,
      "verified" : false
    }
  },
  "id" : 861994113339723776,
  "created_at" : "2017-05-09 17:19:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/PRKvXrkzpM",
      "expanded_url" : "https:\/\/twitter.com\/SCEdmunds\/status\/861922480767684608",
      "display_url" : "twitter.com\/SCEdmunds\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234956865677, 8.627530648260613 ]
  },
  "id_str" : "861950582189416448",
  "text" : "The old issue: Open (data|access) is good, as long as it\u2019s other people\u2019s (data|papers) that\u2019s open\u2026 \uD83D\uDE12 https:\/\/t.co\/PRKvXrkzpM",
  "id" : 861950582189416448,
  "created_at" : "2017-05-09 14:26:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josmel Pacheco",
      "screen_name" : "josmel1",
      "indices" : [ 0, 8 ],
      "id_str" : "54002739",
      "id" : 54002739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "861935275915722754",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235893194766, 8.627537395328668 ]
  },
  "id_str" : "861935723519197184",
  "in_reply_to_user_id" : 54002739,
  "text" : "@josmel1 Thanks!",
  "id" : 861935723519197184,
  "in_reply_to_status_id" : 861935275915722754,
  "created_at" : "2017-05-09 13:27:45 +0000",
  "in_reply_to_screen_name" : "josmel1",
  "in_reply_to_user_id_str" : "54002739",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/qp1GNCruOO",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/rock-roll-hall-of-fame-librarian-job",
      "display_url" : "atlasobscura.com\/articles\/rock-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228540090309, 8.627563894500192 ]
  },
  "id_str" : "861850416627281924",
  "text" : "Now you can literally become a rock star librarian! https:\/\/t.co\/qp1GNCruOO",
  "id" : 861850416627281924,
  "created_at" : "2017-05-09 07:48:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceMediaCentreNZ",
      "screen_name" : "smcnz",
      "indices" : [ 3, 9 ],
      "id_str" : "47318212",
      "id" : 47318212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/aVdauh5RV4",
      "expanded_url" : "http:\/\/www.stuff.co.nz\/world\/australia\/92360044\/Australian-customs-destroys-unique-plant-specimens-after-quarantine-mix-up",
      "display_url" : "stuff.co.nz\/world\/australi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "861846360504532992",
  "text" : "RT @smcnz: Precious lichen specimens were destroyed by Australian customs officials after a quarantine mix-up\nhttps:\/\/t.co\/aVdauh5RV4 https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/smcnz\/status\/861706533259923458\/photo\/1",
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/WBec9Dg3wT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C_VcbfeU0AARSy7.jpg",
        "id_str" : "861696531086233600",
        "id" : 861696531086233600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_VcbfeU0AARSy7.jpg",
        "sizes" : [ {
          "h" : 349,
          "resize" : "fit",
          "w" : 619
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 619
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 619
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 619
        } ],
        "display_url" : "pic.twitter.com\/WBec9Dg3wT"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/aVdauh5RV4",
        "expanded_url" : "http:\/\/www.stuff.co.nz\/world\/australia\/92360044\/Australian-customs-destroys-unique-plant-specimens-after-quarantine-mix-up",
        "display_url" : "stuff.co.nz\/world\/australi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "861706533259923458",
    "text" : "Precious lichen specimens were destroyed by Australian customs officials after a quarantine mix-up\nhttps:\/\/t.co\/aVdauh5RV4 https:\/\/t.co\/WBec9Dg3wT",
    "id" : 861706533259923458,
    "created_at" : "2017-05-08 22:17:01 +0000",
    "user" : {
      "name" : "ScienceMediaCentreNZ",
      "screen_name" : "smcnz",
      "protected" : false,
      "id_str" : "47318212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474405828514951168\/hgKilLqf_normal.jpeg",
      "id" : 47318212,
      "verified" : false
    }
  },
  "id" : 861846360504532992,
  "created_at" : "2017-05-09 07:32:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arXiv.org",
      "screen_name" : "arxiv",
      "indices" : [ 3, 9 ],
      "id_str" : "808633423300624384",
      "id" : 808633423300624384
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "preprints",
      "indices" : [ 16, 26 ]
    }, {
      "text" : "openscience",
      "indices" : [ 31, 43 ]
    }, {
      "text" : "arxiv",
      "indices" : [ 101, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "861740883842150400",
  "text" : "RT @arxiv: Make #preprints and #openscience your job - 1 week till deadline to apply for position of #arxiv administrator: https:\/\/t.co\/JHk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "preprints",
        "indices" : [ 5, 15 ]
      }, {
        "text" : "openscience",
        "indices" : [ 20, 32 ]
      }, {
        "text" : "arxiv",
        "indices" : [ 90, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/JHkJO0zBtl",
        "expanded_url" : "https:\/\/cornell.wd1.myworkdayjobs.com\/en-US\/CornellCareerPage\/job\/Ithaca-Main-Campus\/arXiv-Administrator_WDR-00010685",
        "display_url" : "cornell.wd1.myworkdayjobs.com\/en-US\/CornellC\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "861721301806985216",
    "text" : "Make #preprints and #openscience your job - 1 week till deadline to apply for position of #arxiv administrator: https:\/\/t.co\/JHkJO0zBtl",
    "id" : 861721301806985216,
    "created_at" : "2017-05-08 23:15:43 +0000",
    "user" : {
      "name" : "arXiv.org",
      "screen_name" : "arxiv",
      "protected" : false,
      "id_str" : "808633423300624384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/808662703250108416\/FUFFnYF7_normal.jpg",
      "id" : 808633423300624384,
      "verified" : false
    }
  },
  "id" : 861740883842150400,
  "created_at" : "2017-05-09 00:33:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/861740124589219840\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/OguzbW7795",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C_WEEnTXUAALIpW.jpg",
      "id_str" : "861740118515863552",
      "id" : 861740118515863552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_WEEnTXUAALIpW.jpg",
      "sizes" : [ {
        "h" : 578,
        "resize" : "fit",
        "w" : 446
      }, {
        "h" : 578,
        "resize" : "fit",
        "w" : 446
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 578,
        "resize" : "fit",
        "w" : 446
      }, {
        "h" : 578,
        "resize" : "fit",
        "w" : 446
      } ],
      "display_url" : "pic.twitter.com\/OguzbW7795"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "861679878537703424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140501879155, 8.753419291877973 ]
  },
  "id_str" : "861740124589219840",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest Python hipster be like \uD83D\uDC0D  \u00AF\\_(\u30C4)_\/\u00AF https:\/\/t.co\/OguzbW7795",
  "id" : 861740124589219840,
  "in_reply_to_status_id" : 861679878537703424,
  "created_at" : "2017-05-09 00:30:30 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 0, 10 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "861680991181688837",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405025174277, 8.753419363569792 ]
  },
  "id_str" : "861685714785890305",
  "in_reply_to_user_id" : 186529934,
  "text" : "@auremoser mad freestyle skills! \uD83D\uDC4D",
  "id" : 861685714785890305,
  "in_reply_to_status_id" : 861680991181688837,
  "created_at" : "2017-05-08 20:54:18 +0000",
  "in_reply_to_screen_name" : "auremoser",
  "in_reply_to_user_id_str" : "186529934",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/861669366278098944\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/MsNUpRKz16",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C_VDtrOXkAEdPju.jpg",
      "id_str" : "861669355687481345",
      "id" : 861669355687481345,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_VDtrOXkAEdPju.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      } ],
      "display_url" : "pic.twitter.com\/MsNUpRKz16"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "861668768606543880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404789922606, 8.753420338154196 ]
  },
  "id_str" : "861669366278098944",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara I see your JPG and raise a screenshot instead. https:\/\/t.co\/MsNUpRKz16",
  "id" : 861669366278098944,
  "in_reply_to_status_id" : 861668768606543880,
  "created_at" : "2017-05-08 19:49:20 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/PRhvcQPZN6",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/861652580434407424",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "861652580434407424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405013590365, 8.753419233957484 ]
  },
  "id_str" : "861653087987126275",
  "in_reply_to_user_id" : 14286491,
  "text" : "Even more hilarious: With basic google-fu you can find the original XLS file. \uD83D\uDC4D https:\/\/t.co\/PRhvcQPZN6",
  "id" : 861653087987126275,
  "in_reply_to_status_id" : 861652580434407424,
  "created_at" : "2017-05-08 18:44:39 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405060833137, 8.753419709168812 ]
  },
  "id_str" : "861652580434407424",
  "text" : "When a consulate offers the list of sworn translators as a PDF which is actually a scan of a xerox of their own printed Excel spreadsheet. \uD83D\uDE02",
  "id" : 861652580434407424,
  "created_at" : "2017-05-08 18:42:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 3, 10 ],
      "id_str" : "6069772",
      "id" : 6069772
    }, {
      "name" : "Cathy O'Neil",
      "screen_name" : "mathbabedotorg",
      "indices" : [ 100, 115 ],
      "id_str" : "365145609",
      "id" : 365145609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/3x68ZZWhrn",
      "expanded_url" : "https:\/\/mathbabe.org\/2017\/05\/08\/anonymous-guest-post-mentorship-problems-for-women-in-tech\/",
      "display_url" : "mathbabe.org\/2017\/05\/08\/ano\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "861611616680521731",
  "text" : "RT @pennyb: Anonymous Guest Post: Mentorship Problems for Women in Tech https:\/\/t.co\/3x68ZZWhrn via @mathbabedotorg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cathy O'Neil",
        "screen_name" : "mathbabedotorg",
        "indices" : [ 88, 103 ],
        "id_str" : "365145609",
        "id" : 365145609
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/3x68ZZWhrn",
        "expanded_url" : "https:\/\/mathbabe.org\/2017\/05\/08\/anonymous-guest-post-mentorship-problems-for-women-in-tech\/",
        "display_url" : "mathbabe.org\/2017\/05\/08\/ano\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "861590987285696513",
    "text" : "Anonymous Guest Post: Mentorship Problems for Women in Tech https:\/\/t.co\/3x68ZZWhrn via @mathbabedotorg",
    "id" : 861590987285696513,
    "created_at" : "2017-05-08 14:37:53 +0000",
    "user" : {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "protected" : false,
      "id_str" : "6069772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/921360107505704960\/-c9C3uCY_normal.jpg",
      "id" : 6069772,
      "verified" : false
    }
  },
  "id" : 861611616680521731,
  "created_at" : "2017-05-08 15:59:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/f45y25Raw1",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BT1k1h-F1KJ\/",
      "display_url" : "instagram.com\/p\/BT1k1h-F1KJ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "861610248804630528",
  "text" : "Just \uD83E\uDD5Cs! \uD83C\uDDEE\uD83C\uDDF7 https:\/\/t.co\/f45y25Raw1",
  "id" : 861610248804630528,
  "created_at" : "2017-05-08 15:54:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 14, 24 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/861564690614407169\/photo\/1",
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/meKcDd04aw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C_TkhQBXsAALsDh.jpg",
      "id_str" : "861564688622137344",
      "id" : 861564688622137344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_TkhQBXsAALsDh.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/meKcDd04aw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "861564690614407169",
  "text" : "Found one for @Helena_LB! https:\/\/t.co\/meKcDd04aw",
  "id" : 861564690614407169,
  "created_at" : "2017-05-08 12:53:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua McClure",
      "screen_name" : "joshuamcclure",
      "indices" : [ 0, 14 ],
      "id_str" : "14209307",
      "id" : 14209307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/sEzAat3EfF",
      "expanded_url" : "https:\/\/twitter.com\/manimota\/status\/861555127806832640",
      "display_url" : "twitter.com\/manimota\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "861562474298036224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235109148763, 8.627541850041837 ]
  },
  "id_str" : "861563959031320580",
  "in_reply_to_user_id" : 14209307,
  "text" : "@joshuamcclure my bad, and seems I\u2019m rather well off still https:\/\/t.co\/sEzAat3EfF ;)",
  "id" : 861563959031320580,
  "in_reply_to_status_id" : 861562474298036224,
  "created_at" : "2017-05-08 12:50:29 +0000",
  "in_reply_to_screen_name" : "joshuamcclure",
  "in_reply_to_user_id_str" : "14209307",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723450284815, 8.627548564271805 ]
  },
  "id_str" : "861562051877097472",
  "text" : "Just my connection or is NCBI\u2019s Blast super keen on throwing 503\/502\u2019s all day long?",
  "id" : 861562051877097472,
  "created_at" : "2017-05-08 12:42:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey Comeau",
      "screen_name" : "joeycomeau",
      "indices" : [ 0, 11 ],
      "id_str" : "8858632",
      "id" : 8858632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "861552229597278209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235303350305, 8.627538323681565 ]
  },
  "id_str" : "861558369987022848",
  "in_reply_to_user_id" : 8858632,
  "text" : "@joeycomeau let\u2019s disappear together now :D",
  "id" : 861558369987022848,
  "in_reply_to_status_id" : 861552229597278209,
  "created_at" : "2017-05-08 12:28:17 +0000",
  "in_reply_to_screen_name" : "joeycomeau",
  "in_reply_to_user_id_str" : "8858632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/K9RASaWaIk",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/pascal39s-other-wager",
      "display_url" : "smbc-comics.com\/comic\/pascal39\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723395934776, 8.627540553886922 ]
  },
  "id_str" : "861520980245569536",
  "text" : "Who said you couldn\u2019t make some money with your philosophy degree? https:\/\/t.co\/K9RASaWaIk",
  "id" : 861520980245569536,
  "created_at" : "2017-05-08 09:59:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/1t7dijLLZU",
      "expanded_url" : "https:\/\/twitter.com\/DennisEckmeier\/status\/861510402311696384",
      "display_url" : "twitter.com\/DennisEckmeier\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233094109539, 8.627546434709954 ]
  },
  "id_str" : "861512208706097152",
  "text" : "Totally want to dial a 101 for \u201EDespair\u201C on my Penfield Mood Organ right now. https:\/\/t.co\/1t7dijLLZU",
  "id" : 861512208706097152,
  "created_at" : "2017-05-08 09:24:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 76, 86 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/861470472495669248\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/SsnD4WUdei",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C_SOyyKXcAIENVH.jpg",
      "id_str" : "861470431844462594",
      "id" : 861470431844462594,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_SOyyKXcAIENVH.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      } ],
      "display_url" : "pic.twitter.com\/SsnD4WUdei"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240832496442, 8.62753503942483 ]
  },
  "id_str" : "861470472495669248",
  "text" : "What was waiting for me in the office when I came back from my trip. Thanks @auremoser for the tip! \uD83D\uDE0D https:\/\/t.co\/SsnD4WUdei",
  "id" : 861470472495669248,
  "created_at" : "2017-05-08 06:39:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veday",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405006283946, 8.7534196689584 ]
  },
  "id_str" : "861359847316574209",
  "text" : "Hey Europe!\u270C\uFE0F\uD83D\uDC96 #veday",
  "id" : 861359847316574209,
  "created_at" : "2017-05-07 23:19:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Taylor",
      "screen_name" : "HelenTaylorCG",
      "indices" : [ 3, 17 ],
      "id_str" : "3058881006",
      "id" : 3058881006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "861356550870487041",
  "text" : "RT @HelenTaylorCG: Great thread. We all have our own unconscious, inherent biases and behaviours and we can't fix stuff till we start self-\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 130, 153 ],
        "url" : "https:\/\/t.co\/CLQn3RFMmU",
        "expanded_url" : "https:\/\/twitter.com\/JayFitzsy\/status\/861057567837093888",
        "display_url" : "twitter.com\/JayFitzsy\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "861324140279726080",
    "text" : "Great thread. We all have our own unconscious, inherent biases and behaviours and we can't fix stuff till we start self-policing. https:\/\/t.co\/CLQn3RFMmU",
    "id" : 861324140279726080,
    "created_at" : "2017-05-07 20:57:32 +0000",
    "user" : {
      "name" : "Helen Taylor",
      "screen_name" : "HelenTaylorCG",
      "protected" : false,
      "id_str" : "3058881006",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572569975928283136\/093KHYFq_normal.jpeg",
      "id" : 3058881006,
      "verified" : false
    }
  },
  "id" : 861356550870487041,
  "created_at" : "2017-05-07 23:06:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey Comeau",
      "screen_name" : "joeycomeau",
      "indices" : [ 0, 11 ],
      "id_str" : "8858632",
      "id" : 8858632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/36bxqL7mg2",
      "expanded_url" : "http:\/\/thisiscriminal.com\/episode-61-vanish-2-17-2017\/",
      "display_url" : "thisiscriminal.com\/episode-61-van\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "861295342066823169",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11386025753407, 8.753404836331889 ]
  },
  "id_str" : "861298010831060993",
  "in_reply_to_user_id" : 8858632,
  "text" : "@joeycomeau Hear all about it in this podcast https:\/\/t.co\/36bxqL7mg2",
  "id" : 861298010831060993,
  "in_reply_to_status_id" : 861295342066823169,
  "created_at" : "2017-05-07 19:13:42 +0000",
  "in_reply_to_screen_name" : "joeycomeau",
  "in_reply_to_user_id_str" : "8858632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 3, 9 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 69, 79 ]
    }, {
      "text" : "openscience",
      "indices" : [ 108, 120 ]
    }, {
      "text" : "opendata",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "861293928796041217",
  "text" : "RT @shefw: If you're trying to decide if you can host a site for the #mozsprint, here's a little incentive! #openscience #opendata #datalib\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mozsprint",
        "indices" : [ 58, 68 ]
      }, {
        "text" : "openscience",
        "indices" : [ 97, 109 ]
      }, {
        "text" : "opendata",
        "indices" : [ 110, 119 ]
      }, {
        "text" : "datalibs",
        "indices" : [ 120, 129 ]
      }, {
        "text" : "OER",
        "indices" : [ 130, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/QPZeZMtSlt",
        "expanded_url" : "https:\/\/twitter.com\/MozillaScience\/status\/861293502847737857",
        "display_url" : "twitter.com\/MozillaScience\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "861293789784285185",
    "text" : "If you're trying to decide if you can host a site for the #mozsprint, here's a little incentive! #openscience #opendata #datalibs #OER https:\/\/t.co\/QPZeZMtSlt",
    "id" : 861293789784285185,
    "created_at" : "2017-05-07 18:56:56 +0000",
    "user" : {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "protected" : false,
      "id_str" : "48636190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677947392080019456\/CHnYz4aV_normal.jpg",
      "id" : 48636190,
      "verified" : false
    }
  },
  "id" : 861293928796041217,
  "created_at" : "2017-05-07 18:57:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VALIUM",
      "screen_name" : "alibi_rage",
      "indices" : [ 0, 11 ],
      "id_str" : "971867420",
      "id" : 971867420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "861262355195449344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11391111067515, 8.753495210028378 ]
  },
  "id_str" : "861262529070338049",
  "in_reply_to_user_id" : 971867420,
  "text" : "@alibi_rage Ich auch! Ich bin erschreckt wie schlecht mein medizinisches Griechisch ist \uD83D\uDE02",
  "id" : 861262529070338049,
  "in_reply_to_status_id" : 861262355195449344,
  "created_at" : "2017-05-07 16:52:43 +0000",
  "in_reply_to_screen_name" : "alibi_rage",
  "in_reply_to_user_id_str" : "971867420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VALIUM",
      "screen_name" : "alibi_rage",
      "indices" : [ 0, 11 ],
      "id_str" : "971867420",
      "id" : 971867420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "861261616427433984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11391111067515, 8.753495210028378 ]
  },
  "id_str" : "861262265969979392",
  "in_reply_to_user_id" : 971867420,
  "text" : "@alibi_rage 7\/12! \uD83D\uDE31",
  "id" : 861262265969979392,
  "in_reply_to_status_id" : 861261616427433984,
  "created_at" : "2017-05-07 16:51:40 +0000",
  "in_reply_to_screen_name" : "alibi_rage",
  "in_reply_to_user_id_str" : "971867420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/5qXDwGIjRB",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTy8RuLl2vW\/",
      "display_url" : "instagram.com\/p\/BTy8RuLl2vW\/"
    } ]
  },
  "geo" : { },
  "id_str" : "861239577419427841",
  "text" : "The irony of being hit on the head by a falling emergency exit sign. https:\/\/t.co\/5qXDwGIjRB",
  "id" : 861239577419427841,
  "created_at" : "2017-05-07 15:21:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 103, 114 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/DyOEeJgnS8",
      "expanded_url" : "http:\/\/www.macleans.ca\/wp-content\/uploads\/2016\/03\/PANDAS_POST01.jpg",
      "display_url" : "macleans.ca\/wp-content\/upl\u2026"
    }, {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/YjsmjxNogA",
      "expanded_url" : "https:\/\/twitter.com\/camerongraham\/status\/860818547806785536",
      "display_url" : "twitter.com\/camerongraham\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404870294017, 8.753422683983453 ]
  },
  "id_str" : "861218224196784129",
  "text" : "\uD83C\uDDE8\uD83C\uDDE6\n\nWhat you hoped you\u2019d get: https:\/\/t.co\/DyOEeJgnS8\n\nWhat you actually got: https:\/\/t.co\/YjsmjxNogA\n\n@bella_velo",
  "id" : 861218224196784129,
  "created_at" : "2017-05-07 13:56:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 3, 13 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/LBBM5y3O2Q",
      "expanded_url" : "https:\/\/twitter.com\/OmnesResNetwork\/status\/860464294215000064",
      "display_url" : "twitter.com\/OmnesResNetwor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "861180413880012801",
  "text" : "RT @blahah404: Spot on \uD83D\uDC4C\uD83C\uDFFD\n\nhttps:\/\/t.co\/LBBM5y3O2Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 35 ],
        "url" : "https:\/\/t.co\/LBBM5y3O2Q",
        "expanded_url" : "https:\/\/twitter.com\/OmnesResNetwork\/status\/860464294215000064",
        "display_url" : "twitter.com\/OmnesResNetwor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "860791894917382144",
    "text" : "Spot on \uD83D\uDC4C\uD83C\uDFFD\n\nhttps:\/\/t.co\/LBBM5y3O2Q",
    "id" : 860791894917382144,
    "created_at" : "2017-05-06 09:42:35 +0000",
    "user" : {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "protected" : false,
      "id_str" : "99173786",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712249526577438720\/-dRs3Gg9_normal.jpg",
      "id" : 99173786,
      "verified" : false
    }
  },
  "id" : 861180413880012801,
  "created_at" : "2017-05-07 11:26:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Graslie \uD83C\uDF38\uD83D\uDC1D",
      "screen_name" : "Ehmee",
      "indices" : [ 3, 9 ],
      "id_str" : "16435797",
      "id" : 16435797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/frURYBImsL",
      "expanded_url" : "https:\/\/twitter.com\/findingada\/status\/859363861501272064",
      "display_url" : "twitter.com\/findingada\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "861178749622079488",
  "text" : "RT @Ehmee: ATTENTION \uD83D\uDC47\uD83C\uDFFB\uD83D\uDC47\uD83C\uDFFB\uD83D\uDC47\uD83C\uDFFB https:\/\/t.co\/frURYBImsL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/frURYBImsL",
        "expanded_url" : "https:\/\/twitter.com\/findingada\/status\/859363861501272064",
        "display_url" : "twitter.com\/findingada\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "859392580366327809",
    "text" : "ATTENTION \uD83D\uDC47\uD83C\uDFFB\uD83D\uDC47\uD83C\uDFFB\uD83D\uDC47\uD83C\uDFFB https:\/\/t.co\/frURYBImsL",
    "id" : 859392580366327809,
    "created_at" : "2017-05-02 13:02:12 +0000",
    "user" : {
      "name" : "Emily Graslie \uD83C\uDF38\uD83D\uDC1D",
      "screen_name" : "Ehmee",
      "protected" : false,
      "id_str" : "16435797",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/900709308421353472\/-qkrKty2_normal.jpg",
      "id" : 16435797,
      "verified" : true
    }
  },
  "id" : 861178749622079488,
  "created_at" : "2017-05-07 11:19:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/gHGOZRiwp0",
      "expanded_url" : "https:\/\/twitter.com\/bella_velo\/status\/860984595478700032",
      "display_url" : "twitter.com\/bella_velo\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139039645676, 8.753289326276352 ]
  },
  "id_str" : "861178329021526016",
  "text" : "Handing raccoons to everyone stuck there might be the only way to safe YYZ by now. https:\/\/t.co\/gHGOZRiwp0",
  "id" : 861178329021526016,
  "created_at" : "2017-05-07 11:18:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 48, 58 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/CFPZ0P2AXi",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTxCLf3lK2J\/",
      "display_url" : "instagram.com\/p\/BTxCLf3lK2J\/"
    } ]
  },
  "geo" : { },
  "id_str" : "860971081766764544",
  "text" : "And look who went all in with the \uD83C\uDDE9\uD83C\uDDEA-ess today, @eltonjohn! https:\/\/t.co\/CFPZ0P2AXi",
  "id" : 860971081766764544,
  "created_at" : "2017-05-06 21:34:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/7kh2a2tPja",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=rNUYdgIyaPM",
      "display_url" : "m.youtube.com\/watch?v=rNUYdg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "860967224101785600",
  "text" : "Managed to see 'I Am Not Your Negro' in the local cinema. \u2B50\uFE0F\u2B50\uFE0F\u2B50\uFE0F\u2B50\uFE0F\u2B50\uFE0F https:\/\/t.co\/7kh2a2tPja",
  "id" : 860967224101785600,
  "created_at" : "2017-05-06 21:19:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    }, {
      "name" : "Ranting @branleb",
      "screen_name" : "rantleb",
      "indices" : [ 9, 17 ],
      "id_str" : "748130881",
      "id" : 748130881
    }, {
      "name" : "Ragetina",
      "screen_name" : "Ragetina",
      "indices" : [ 18, 27 ],
      "id_str" : "819601236",
      "id" : 819601236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "860856082956259334",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10673712012368, 8.72423250228979 ]
  },
  "id_str" : "860856230742458372",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg @rantleb @Ragetina Sollten da sein :)",
  "id" : 860856230742458372,
  "in_reply_to_status_id" : 860856082956259334,
  "created_at" : "2017-05-06 13:58:14 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/860520721323307009\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/NuTj4BVZCN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C_EvB2QWAAAhXOB.jpg",
      "id_str" : "860520712594915328",
      "id" : 860520712594915328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C_EvB2QWAAAhXOB.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/NuTj4BVZCN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "860514243317186560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140452789401, 8.753422171680734 ]
  },
  "id_str" : "860520721323307009",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Happy birthday my friend! \uD83C\uDF89\uD83D\uDC96\uD83D\uDE18\uD83C\uDF7B https:\/\/t.co\/NuTj4BVZCN",
  "id" : 860520721323307009,
  "in_reply_to_status_id" : 860514243317186560,
  "created_at" : "2017-05-05 15:45:02 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Versluis",
      "screen_name" : "aliversluis",
      "indices" : [ 3, 15 ],
      "id_str" : "396000141",
      "id" : 396000141
    }, {
      "name" : "Jane Schmidt",
      "screen_name" : "janeschmidt",
      "indices" : [ 109, 121 ],
      "id_str" : "17768745",
      "id" : 17768745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "860516354499244032",
  "text" : "RT @aliversluis: \"I'm sorry that I've pissed a lot of people off. But I'm kind of just doing my job, right?\" @janeschmidt winning my heart,\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jane Schmidt",
        "screen_name" : "janeschmidt",
        "indices" : [ 92, 104 ],
        "id_str" : "17768745",
        "id" : 17768745
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/16G93Eaa6I",
        "expanded_url" : "https:\/\/twitter.com\/cbcasithappens\/status\/860256726284677120",
        "display_url" : "twitter.com\/cbcasithappens\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "860275839686119425",
    "text" : "\"I'm sorry that I've pissed a lot of people off. But I'm kind of just doing my job, right?\" @janeschmidt winning my heart, as always. https:\/\/t.co\/16G93Eaa6I",
    "id" : 860275839686119425,
    "created_at" : "2017-05-04 23:31:57 +0000",
    "user" : {
      "name" : "Ali Versluis",
      "screen_name" : "aliversluis",
      "protected" : false,
      "id_str" : "396000141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/919913248903913473\/4vSISd2k_normal.jpg",
      "id" : 396000141,
      "verified" : false
    }
  },
  "id" : 860516354499244032,
  "created_at" : "2017-05-05 15:27:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "860152061844967425",
  "geo" : { },
  "id_str" : "860173052339990528",
  "in_reply_to_user_id" : 14286491,
  "text" : "And how else would I be welcomed if not by commuter trains not running due to a storm. \uD83E\uDD37\u200D\u2640\uFE0F",
  "id" : 860173052339990528,
  "in_reply_to_status_id" : 860152061844967425,
  "created_at" : "2017-05-04 16:43:31 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "860152061844967425",
  "text" : "Welcome back, \uD83C\uDDEA\uD83C\uDDFA. \u2614\uFE0F",
  "id" : 860152061844967425,
  "created_at" : "2017-05-04 15:20:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.59154020160958, -122.597122108678 ]
  },
  "id_str" : "859985807586623488",
  "text" : "Goodbye North America. PDX \u2708\uFE0F FRA. \uD83D\uDE34",
  "id" : 859985807586623488,
  "created_at" : "2017-05-04 04:19:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Su Chen",
      "screen_name" : "Lim_SuChen",
      "indices" : [ 14, 25 ],
      "id_str" : "1132384434",
      "id" : 1132384434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859975708952502272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.59234037999585, -122.5967555680523 ]
  },
  "id_str" : "859976390690578432",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Lim_SuChen Did it this afternoon!",
  "id" : 859976390690578432,
  "in_reply_to_status_id" : 859975708952502272,
  "created_at" : "2017-05-04 03:42:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859954677848301568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.59142805174514, -122.5962301903615 ]
  },
  "id_str" : "859954978202320897",
  "in_reply_to_user_id" : 14286491,
  "text" : "Also: wanna guess which flight was delayed?",
  "id" : 859954978202320897,
  "in_reply_to_status_id" : 859954677848301568,
  "created_at" : "2017-05-04 02:16:58 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859870047459713024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.58763528223185, -122.5933619032131 ]
  },
  "id_str" : "859954677848301568",
  "in_reply_to_user_id" : 14286491,
  "text" : "Thanks so much to everyone making this a great conference. Can\u2019t wait for next year\u2019s! #csvconf",
  "id" : 859954677848301568,
  "in_reply_to_status_id" : 859870047459713024,
  "created_at" : "2017-05-04 02:15:47 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/rdBeYHPzwd",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTpjjwGl2sH\/",
      "display_url" : "instagram.com\/p\/BTpjjwGl2sH\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.518917157533, -122.67931008976 ]
  },
  "id_str" : "859918590732062720",
  "text" : "We gotta talk about your timing for the good weather, Portland. @ Pioneer Courthouse Square https:\/\/t.co\/rdBeYHPzwd",
  "id" : 859918590732062720,
  "created_at" : "2017-05-03 23:52:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/Eaz4I0ZMAi",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/859869329440899072",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "859869329440899072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51863988711906, -122.6855828620196 ]
  },
  "id_str" : "859870047459713024",
  "in_reply_to_user_id" : 14286491,
  "text" : "Secretly the intro for the Winamp talk that\u2019s to follow \uD83D\uDE02 #csvconf https:\/\/t.co\/Eaz4I0ZMAi",
  "id" : 859870047459713024,
  "in_reply_to_status_id" : 859869329440899072,
  "created_at" : "2017-05-03 20:39:29 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/859869329440899072\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/tG7RSX50Pg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-7ekqFXYAMPOrx.jpg",
      "id_str" : "859869300227792899",
      "id" : 859869300227792899,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-7ekqFXYAMPOrx.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 676
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 449
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 676
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 676
      } ],
      "display_url" : "pic.twitter.com\/tG7RSX50Pg"
    } ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859851846575247360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51864573263142, -122.6855892056016 ]
  },
  "id_str" : "859869329440899072",
  "in_reply_to_user_id" : 14286491,
  "text" : "We welcome our new alpacian overlords at #csvconf \uD83D\uDE4F\uD83D\uDC92 https:\/\/t.co\/tG7RSX50Pg",
  "id" : 859869329440899072,
  "in_reply_to_status_id" : 859851846575247360,
  "created_at" : "2017-05-03 20:36:38 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 10, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/RcDsl7KqsS",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTpJP7bl2q2\/",
      "display_url" : "instagram.com\/p\/BTpJP7bl2q2\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51858, -122.686 ]
  },
  "id_str" : "859860731096965121",
  "text" : "I went to #csvconf and all I got was a wet Comma Llama (alpaca) kiss. \uD83D\uDC96\uD83D\uDC8B @ The Eliot Center https:\/\/t.co\/RcDsl7KqsS",
  "id" : 859860731096965121,
  "created_at" : "2017-05-03 20:02:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasmina Anwar",
      "screen_name" : "yasmina_anwar",
      "indices" : [ 99, 113 ],
      "id_str" : "221460308",
      "id" : 221460308
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859835895981015040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51860012583948, -122.6856576373081 ]
  },
  "id_str" : "859851846575247360",
  "in_reply_to_user_id" : 14286491,
  "text" : "Awesome talk about automated digital storytelling, using the Egyptian revolution as an example, by @yasmina_anwar! #csvconf",
  "id" : 859851846575247360,
  "in_reply_to_status_id" : 859835895981015040,
  "created_at" : "2017-05-03 19:27:10 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 10, 23 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859750427662876672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51884043500341, -122.685591504092 ]
  },
  "id_str" : "859849452713947136",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @MishaAngrist Did you already read it? Has been on my to-read for a while!",
  "id" : 859849452713947136,
  "in_reply_to_status_id" : 859750427662876672,
  "created_at" : "2017-05-03 19:17:39 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rachel a",
      "screen_name" : "frecklewars",
      "indices" : [ 3, 15 ],
      "id_str" : "110043169",
      "id" : 110043169
    }, {
      "name" : "Yasmina Anwar",
      "screen_name" : "yasmina_anwar",
      "indices" : [ 18, 32 ],
      "id_str" : "221460308",
      "id" : 221460308
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "859847750879297536",
  "text" : "RT @frecklewars: .@yasmina_anwar hand freakin crafted stories to summarize the web archives egyptian revolution collection #csvconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yasmina Anwar",
        "screen_name" : "yasmina_anwar",
        "indices" : [ 1, 15 ],
        "id_str" : "221460308",
        "id" : 221460308
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "csvconf",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "859847482439745536",
    "text" : ".@yasmina_anwar hand freakin crafted stories to summarize the web archives egyptian revolution collection #csvconf",
    "id" : 859847482439745536,
    "created_at" : "2017-05-03 19:09:49 +0000",
    "user" : {
      "name" : "rachel a",
      "screen_name" : "frecklewars",
      "protected" : false,
      "id_str" : "110043169",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3499576855\/46e370aa44a8728dff0b40351e6c21be_normal.png",
      "id" : 110043169,
      "verified" : false
    }
  },
  "id" : 859847750879297536,
  "created_at" : "2017-05-03 19:10:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Williams",
      "screen_name" : "JasonWilliamsNY",
      "indices" : [ 3, 19 ],
      "id_str" : "1692248610",
      "id" : 1692248610
    }, {
      "name" : "Data Carpentry",
      "screen_name" : "datacarpentry",
      "indices" : [ 111, 125 ],
      "id_str" : "2493407430",
      "id" : 2493407430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "859846015368679424",
  "text" : "RT @JasonWilliamsNY: Want help make the world's best training materials for genomics? Sign up to contribute to @datacarpentry genomics http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Data Carpentry",
        "screen_name" : "datacarpentry",
        "indices" : [ 90, 104 ],
        "id_str" : "2493407430",
        "id" : 2493407430
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/dj7X6QZBTX",
        "expanded_url" : "http:\/\/www.datacarpentry.org\/blog\/genomics-lessons\/",
        "display_url" : "datacarpentry.org\/blog\/genomics-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "859819439633707008",
    "text" : "Want help make the world's best training materials for genomics? Sign up to contribute to @datacarpentry genomics https:\/\/t.co\/dj7X6QZBTX",
    "id" : 859819439633707008,
    "created_at" : "2017-05-03 17:18:23 +0000",
    "user" : {
      "name" : "Jason Williams",
      "screen_name" : "JasonWilliamsNY",
      "protected" : false,
      "id_str" : "1692248610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000457792547\/976107892eb908ea79dcb6e8a4c209f9_normal.jpeg",
      "id" : 1692248610,
      "verified" : false
    }
  },
  "id" : 859846015368679424,
  "created_at" : "2017-05-03 19:03:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hamdan Azhar",
      "screen_name" : "HamdanAzhar",
      "indices" : [ 0, 12 ],
      "id_str" : "64883319",
      "id" : 64883319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/T2JvdwUZWp",
      "expanded_url" : "http:\/\/ruleofthirds.de\/they-are-good-dogs-indeed\/",
      "display_url" : "ruleofthirds.de\/they-are-good-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "859841716982915072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51927881039634, -122.6861304367883 ]
  },
  "id_str" : "859842383071944704",
  "in_reply_to_user_id" : 64883319,
  "text" : "@HamdanAzhar And not exclusively emoji but in the same vein: https:\/\/t.co\/T2JvdwUZWp \uD83D\uDE02",
  "id" : 859842383071944704,
  "in_reply_to_status_id" : 859841716982915072,
  "created_at" : "2017-05-03 18:49:33 +0000",
  "in_reply_to_screen_name" : "HamdanAzhar",
  "in_reply_to_user_id_str" : "64883319",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hamdan Azhar",
      "screen_name" : "HamdanAzhar",
      "indices" : [ 0, 12 ],
      "id_str" : "64883319",
      "id" : 64883319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/2B3nwjxL8A",
      "expanded_url" : "http:\/\/ruleofthirds.de\/scienceisglobal\/",
      "display_url" : "ruleofthirds.de\/scienceisgloba\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "859841716982915072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52138534999999, -122.68309706 ]
  },
  "id_str" : "859842239488335872",
  "in_reply_to_user_id" : 64883319,
  "text" : "@HamdanAzhar https:\/\/t.co\/2B3nwjxL8A that\u2019s the thing we talked about just now!",
  "id" : 859842239488335872,
  "in_reply_to_status_id" : 859841716982915072,
  "created_at" : "2017-05-03 18:48:59 +0000",
  "in_reply_to_screen_name" : "HamdanAzhar",
  "in_reply_to_user_id_str" : "64883319",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hamdan Azhar",
      "screen_name" : "HamdanAzhar",
      "indices" : [ 44, 56 ],
      "id_str" : "64883319",
      "id" : 64883319
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muslimban",
      "indices" : [ 24, 34 ]
    }, {
      "text" : "csvconf",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859835310284259328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51923971501407, -122.6853046258894 ]
  },
  "id_str" : "859835895981015040",
  "in_reply_to_user_id" : 14286491,
  "text" : "Going to JFK during the #muslimban protests @HamdanAzhar introduced himself: \u00ABI\u2019m an emoji data scientist, how can I help?\u00BB #csvconf",
  "id" : 859835895981015040,
  "in_reply_to_status_id" : 859835310284259328,
  "created_at" : "2017-05-03 18:23:47 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 48, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/Qw16GLKTAS",
      "expanded_url" : "https:\/\/twitter.com\/iff_or\/status\/859834687287508992",
      "display_url" : "twitter.com\/iff_or\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "859833027014217728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52138535006439, -122.6830970599491 ]
  },
  "id_str" : "859835310284259328",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABMy first sighting of the \uD83D\uDD95 emoji in the wild.\u00BB #csvconf https:\/\/t.co\/Qw16GLKTAS",
  "id" : 859835310284259328,
  "in_reply_to_status_id" : 859833027014217728,
  "created_at" : "2017-05-03 18:21:27 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Lewis",
      "screen_name" : "iff_or",
      "indices" : [ 3, 10 ],
      "id_str" : "766863587088273408",
      "id" : 766863587088273408
    }, {
      "name" : "Hamdan Azhar",
      "screen_name" : "HamdanAzhar",
      "indices" : [ 73, 85 ],
      "id_str" : "64883319",
      "id" : 64883319
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/iff_or\/status\/859832482073464832\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/kUxiK5p5Wo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-69D1PXoAsZy7b.jpg",
      "id_str" : "859832452403142667",
      "id" : 859832452403142667,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-69D1PXoAsZy7b.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/kUxiK5p5Wo"
    } ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 86, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "859833062175023104",
  "text" : "RT @iff_or: The emojis over-indexed most heavily for Brexit, analyzed by @HamdanAzhar #csvconf https:\/\/t.co\/kUxiK5p5Wo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hamdan Azhar",
        "screen_name" : "HamdanAzhar",
        "indices" : [ 61, 73 ],
        "id_str" : "64883319",
        "id" : 64883319
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iff_or\/status\/859832482073464832\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/kUxiK5p5Wo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-69D1PXoAsZy7b.jpg",
        "id_str" : "859832452403142667",
        "id" : 859832452403142667,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-69D1PXoAsZy7b.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/kUxiK5p5Wo"
      } ],
      "hashtags" : [ {
        "text" : "csvconf",
        "indices" : [ 74, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "859832482073464832",
    "text" : "The emojis over-indexed most heavily for Brexit, analyzed by @HamdanAzhar #csvconf https:\/\/t.co\/kUxiK5p5Wo",
    "id" : 859832482073464832,
    "created_at" : "2017-05-03 18:10:13 +0000",
    "user" : {
      "name" : "Melissa Lewis",
      "screen_name" : "iff_or",
      "protected" : false,
      "id_str" : "766863587088273408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926602895096557568\/ZI_z0-D7_normal.jpg",
      "id" : 766863587088273408,
      "verified" : true
    }
  },
  "id" : 859833062175023104,
  "created_at" : "2017-05-03 18:12:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/859833027014217728\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/xKWPHSZBhV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-69jtrXoAAof6C.jpg",
      "id_str" : "859833000128913408",
      "id" : 859833000128913408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-69jtrXoAAof6C.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xKWPHSZBhV"
    } ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859831683171835904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52143106831362, -122.6830558531102 ]
  },
  "id_str" : "859833027014217728",
  "in_reply_to_user_id" : 14286491,
  "text" : "I\u2019d love to see how the emoji usage post-brexit differs when split up by geo location! #csvconf https:\/\/t.co\/xKWPHSZBhV",
  "id" : 859833027014217728,
  "in_reply_to_status_id" : 859831683171835904,
  "created_at" : "2017-05-03 18:12:23 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scienceisglobal",
      "indices" : [ 53, 69 ]
    }, {
      "text" : "csvconf",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/2B3nwjxL8A",
      "expanded_url" : "http:\/\/ruleofthirds.de\/scienceisglobal\/",
      "display_url" : "ruleofthirds.de\/scienceisgloba\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "859831097143603201",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51896163732327, -122.6855204255531 ]
  },
  "id_str" : "859831683171835904",
  "in_reply_to_user_id" : 14286491,
  "text" : "Given my own adventures into emoji data science with #scienceisglobal this is near and dear to my \uD83D\uDC96. https:\/\/t.co\/2B3nwjxL8A #csvconf",
  "id" : 859831683171835904,
  "in_reply_to_status_id" : 859831097143603201,
  "created_at" : "2017-05-03 18:07:02 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hamdan Azhar",
      "screen_name" : "HamdanAzhar",
      "indices" : [ 75, 87 ],
      "id_str" : "64883319",
      "id" : 64883319
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859565836666667011",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52014586344698, -122.6853385366051 ]
  },
  "id_str" : "859831097143603201",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABDid you always want to be an emoji data scientist?\u00BB looking so forward to @HamdanAzhar\u2019s talk! \uD83D\uDE0D\uD83C\uDF89\uD83D\uDC68\u200D\uD83D\uDCBB #csvconf",
  "id" : 859831097143603201,
  "in_reply_to_status_id" : 859565836666667011,
  "created_at" : "2017-05-03 18:04:43 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Lewis",
      "screen_name" : "iff_or",
      "indices" : [ 3, 10 ],
      "id_str" : "766863587088273408",
      "id" : 766863587088273408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/UWSWI05bY4",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Adelaide_Hasse",
      "display_url" : "en.m.wikipedia.org\/wiki\/Adelaide_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "859828000753201152",
  "text" : "RT @iff_or: TIL about Adelaide Hasse, who (among many things) founded program to make fed gov docs public, free\nhttps:\/\/t.co\/UWSWI05bY4 #cs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "csvconf",
        "indices" : [ 124, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/UWSWI05bY4",
        "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Adelaide_Hasse",
        "display_url" : "en.m.wikipedia.org\/wiki\/Adelaide_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "859826755866996736",
    "text" : "TIL about Adelaide Hasse, who (among many things) founded program to make fed gov docs public, free\nhttps:\/\/t.co\/UWSWI05bY4 #csvconf",
    "id" : 859826755866996736,
    "created_at" : "2017-05-03 17:47:28 +0000",
    "user" : {
      "name" : "Melissa Lewis",
      "screen_name" : "iff_or",
      "protected" : false,
      "id_str" : "766863587088273408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926602895096557568\/ZI_z0-D7_normal.jpg",
      "id" : 766863587088273408,
      "verified" : true
    }
  },
  "id" : 859828000753201152,
  "created_at" : "2017-05-03 17:52:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859820346630955009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52138534999999, -122.68309706 ]
  },
  "id_str" : "859820484988248065",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr Let\u2019s see whether I can squeeze in some time. :)",
  "id" : 859820484988248065,
  "in_reply_to_status_id" : 859820346630955009,
  "created_at" : "2017-05-03 17:22:32 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moiz Syed",
      "screen_name" : "MoizSyed",
      "indices" : [ 3, 12 ],
      "id_str" : "13304662",
      "id" : 13304662
    }, {
      "name" : "Laurie Allen",
      "screen_name" : "librlaurie",
      "indices" : [ 27, 38 ],
      "id_str" : "213793319",
      "id" : 213793319
    }, {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 76, 82 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MoizSyed\/status\/859818808730501121\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/eyjrtrDtg1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-6wpPIXoAEfqTA.jpg",
      "id_str" : "859818801357103105",
      "id" : 859818801357103105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-6wpPIXoAEfqTA.jpg",
      "sizes" : [ {
        "h" : 421,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/eyjrtrDtg1"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/MoizSyed\/status\/859818808730501121\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/eyjrtrDtg1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-6wpPPXgAELWY0.jpg",
      "id_str" : "859818801386455041",
      "id" : 859818801386455041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-6wpPPXgAELWY0.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/eyjrtrDtg1"
    } ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "859819310675410948",
  "text" : "RT @MoizSyed: The headline @librlaurie wanted about her data refuge work in @WIRED #csvconf https:\/\/t.co\/eyjrtrDtg1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laurie Allen",
        "screen_name" : "librlaurie",
        "indices" : [ 13, 24 ],
        "id_str" : "213793319",
        "id" : 213793319
      }, {
        "name" : "WIRED",
        "screen_name" : "WIRED",
        "indices" : [ 62, 68 ],
        "id_str" : "1344951",
        "id" : 1344951
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MoizSyed\/status\/859818808730501121\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/eyjrtrDtg1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-6wpPIXoAEfqTA.jpg",
        "id_str" : "859818801357103105",
        "id" : 859818801357103105,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-6wpPIXoAEfqTA.jpg",
        "sizes" : [ {
          "h" : 421,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/eyjrtrDtg1"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/MoizSyed\/status\/859818808730501121\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/eyjrtrDtg1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-6wpPPXgAELWY0.jpg",
        "id_str" : "859818801386455041",
        "id" : 859818801386455041,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-6wpPPXgAELWY0.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/eyjrtrDtg1"
      } ],
      "hashtags" : [ {
        "text" : "csvconf",
        "indices" : [ 69, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "859818808730501121",
    "text" : "The headline @librlaurie wanted about her data refuge work in @WIRED #csvconf https:\/\/t.co\/eyjrtrDtg1",
    "id" : 859818808730501121,
    "created_at" : "2017-05-03 17:15:53 +0000",
    "user" : {
      "name" : "Moiz Syed",
      "screen_name" : "MoizSyed",
      "protected" : false,
      "id_str" : "13304662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593124707949359104\/G8p4Cn0A_normal.jpg",
      "id" : 13304662,
      "verified" : false
    }
  },
  "id" : 859819310675410948,
  "created_at" : "2017-05-03 17:17:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859807618528882688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51859337840743, -122.6855233592192 ]
  },
  "id_str" : "859815580202934273",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr So maybe I better get back in there and grab some more :p",
  "id" : 859815580202934273,
  "in_reply_to_status_id" : 859807618528882688,
  "created_at" : "2017-05-03 17:03:03 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859807618528882688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51873308769195, -122.6855375352848 ]
  },
  "id_str" : "859815520224202752",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr I certainly improved over the last year with that. But: I\u2019ve been schlepping around a canvas bag all over North America now for that purpose",
  "id" : 859815520224202752,
  "in_reply_to_status_id" : 859807618528882688,
  "created_at" : "2017-05-03 17:02:49 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Minaal",
      "screen_name" : "minaal",
      "indices" : [ 76, 83 ],
      "id_str" : "246624621",
      "id" : 246624621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52393150999813, -122.6740777500018 ]
  },
  "id_str" : "859802825894670336",
  "text" : "I went to Powell\u2019s &amp; somehow still managed to get all my stuff into the @minaal. Either I\u2019m a genius at packing or I failed at buying books.",
  "id" : 859802825894670336,
  "created_at" : "2017-05-03 16:12:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/UTBN2QFzCG",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTndHBXFXNF\/",
      "display_url" : "instagram.com\/p\/BTndHBXFXNF\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5162315, -122.6302872 ]
  },
  "id_str" : "859622930640236546",
  "text" : "Burn @ Sweet Hereafter https:\/\/t.co\/UTBN2QFzCG",
  "id" : 859622930640236546,
  "created_at" : "2017-05-03 04:17:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Williams",
      "screen_name" : "JasonWilliamsNY",
      "indices" : [ 0, 16 ],
      "id_str" : "1692248610",
      "id" : 1692248610
    }, {
      "name" : "Erin Becker",
      "screen_name" : "ErinSBecker",
      "indices" : [ 17, 29 ],
      "id_str" : "3704290280",
      "id" : 3704290280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859569158027173889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52107189, -122.6833049799999 ]
  },
  "id_str" : "859576334648983552",
  "in_reply_to_user_id" : 1692248610,
  "text" : "@JasonWilliamsNY @ErinSBecker Yes, that\u2019s always my short cut if in doubt :)",
  "id" : 859576334648983552,
  "in_reply_to_status_id" : 859569158027173889,
  "created_at" : "2017-05-03 01:12:22 +0000",
  "in_reply_to_screen_name" : "JasonWilliamsNY",
  "in_reply_to_user_id_str" : "1692248610",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Becker",
      "screen_name" : "ErinSBecker",
      "indices" : [ 0, 12 ],
      "id_str" : "3704290280",
      "id" : 3704290280
    }, {
      "name" : "Jason Williams",
      "screen_name" : "JasonWilliamsNY",
      "indices" : [ 13, 29 ],
      "id_str" : "1692248610",
      "id" : 1692248610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 160, 168 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859567360478400513",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51818379670895, -122.685253126661 ]
  },
  "id_str" : "859568468127035393",
  "in_reply_to_user_id" : 3704290280,
  "text" : "@ErinSBecker @JasonWilliamsNY Arctic comes from Greek \u00E1rktos==bear (for the star constellation), polar bears are there. Anti-\u00E1rktos is where the penguins live. #csvconf",
  "id" : 859568468127035393,
  "in_reply_to_status_id" : 859567360478400513,
  "created_at" : "2017-05-03 00:41:07 +0000",
  "in_reply_to_screen_name" : "ErinSBecker",
  "in_reply_to_user_id_str" : "3704290280",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/SHhEiMAZaq",
      "expanded_url" : "https:\/\/twitter.com\/jillemery\/status\/859565675647336449",
      "display_url" : "twitter.com\/jillemery\/stat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "859560984289042432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52107188999999, -122.68330498 ]
  },
  "id_str" : "859565836666667011",
  "in_reply_to_user_id" : 14286491,
  "text" : "Aka: publish negative results. #csvconf https:\/\/t.co\/SHhEiMAZaq",
  "id" : 859565836666667011,
  "in_reply_to_status_id" : 859560984289042432,
  "created_at" : "2017-05-03 00:30:40 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Old acct Mx. Sasha",
      "screen_name" : "erikpub",
      "indices" : [ 3, 11 ],
      "id_str" : "909518971367542785",
      "id" : 909518971367542785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "859565290975223808",
  "text" : "RT @erikpub: 2-4 entire tech confs could be filled just with non-binary speakers, so if yours has all cis men, you kind of suck: https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/85IfScr0xf",
        "expanded_url" : "https:\/\/enbytech.github.io",
        "display_url" : "enbytech.github.io"
      } ]
    },
    "geo" : { },
    "id_str" : "859465667841589248",
    "text" : "2-4 entire tech confs could be filled just with non-binary speakers, so if yours has all cis men, you kind of suck: https:\/\/t.co\/85IfScr0xf",
    "id" : 859465667841589248,
    "created_at" : "2017-05-02 17:52:37 +0000",
    "user" : {
      "name" : "Mx. Sasha \uD83D\uDC3F\uD83E\uDD84\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "mxsash",
      "protected" : false,
      "id_str" : "147488908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757619173157662720\/rGBIb8_A_normal.jpg",
      "id" : 147488908,
      "verified" : false
    }
  },
  "id" : 859565290975223808,
  "created_at" : "2017-05-03 00:28:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hilary Parker",
      "screen_name" : "hspter",
      "indices" : [ 3, 10 ],
      "id_str" : "24228154",
      "id" : 24228154
    }, {
      "name" : "Angela Bassa",
      "screen_name" : "AngeBassa",
      "indices" : [ 91, 101 ],
      "id_str" : "937467860",
      "id" : 937467860
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/hspter\/status\/859564573996630016\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/byaFJpVRQT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-3JaUpWAAAD-Qa.jpg",
      "id_str" : "859564557953531904",
      "id" : 859564557953531904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-3JaUpWAAAD-Qa.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/byaFJpVRQT"
    } ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "859564742427295744",
  "text" : "RT @hspter: Good way of phrasing why data best practices are very often not followed, from @AngeBassa #csvconf https:\/\/t.co\/byaFJpVRQT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Angela Bassa",
        "screen_name" : "AngeBassa",
        "indices" : [ 79, 89 ],
        "id_str" : "937467860",
        "id" : 937467860
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hspter\/status\/859564573996630016\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/byaFJpVRQT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-3JaUpWAAAD-Qa.jpg",
        "id_str" : "859564557953531904",
        "id" : 859564557953531904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-3JaUpWAAAD-Qa.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/byaFJpVRQT"
      } ],
      "hashtags" : [ {
        "text" : "csvconf",
        "indices" : [ 90, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "859564573996630016",
    "text" : "Good way of phrasing why data best practices are very often not followed, from @AngeBassa #csvconf https:\/\/t.co\/byaFJpVRQT",
    "id" : 859564573996630016,
    "created_at" : "2017-05-03 00:25:39 +0000",
    "user" : {
      "name" : "Hilary Parker",
      "screen_name" : "hspter",
      "protected" : false,
      "id_str" : "24228154",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611535712710729728\/ZrqMrN21_normal.jpg",
      "id" : 24228154,
      "verified" : false
    }
  },
  "id" : 859564742427295744,
  "created_at" : "2017-05-03 00:26:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 3, 13 ],
      "id_str" : "11385492",
      "id" : 11385492
    }, {
      "name" : "Angela Bassa",
      "screen_name" : "AngeBassa",
      "indices" : [ 113, 123 ],
      "id_str" : "937467860",
      "id" : 937467860
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "859564467973087232",
  "text" : "RT @jillemery: Must develop a cultural of psychological safety &amp; low levels of anxiety for a team to succeed @AngeBassa #csvconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Angela Bassa",
        "screen_name" : "AngeBassa",
        "indices" : [ 98, 108 ],
        "id_str" : "937467860",
        "id" : 937467860
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "csvconf",
        "indices" : [ 109, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "859559948132339712",
    "text" : "Must develop a cultural of psychological safety &amp; low levels of anxiety for a team to succeed @AngeBassa #csvconf",
    "id" : 859559948132339712,
    "created_at" : "2017-05-03 00:07:16 +0000",
    "user" : {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "protected" : false,
      "id_str" : "11385492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721430293668704256\/uuScw2u1_normal.jpg",
      "id" : 11385492,
      "verified" : false
    }
  },
  "id" : 859564467973087232,
  "created_at" : "2017-05-03 00:25:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Santos",
      "screen_name" : "ansate",
      "indices" : [ 3, 10 ],
      "id_str" : "9723702",
      "id" : 9723702
    }, {
      "name" : "Angela Bassa",
      "screen_name" : "AngeBassa",
      "indices" : [ 17, 27 ],
      "id_str" : "937467860",
      "id" : 937467860
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 95, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "859563804832575488",
  "text" : "RT @ansate: \u2764\uFE0F\uD83D\uDC96\uD83D\uDC96 @AngeBassa gives a shoutout to ethnography and sociology for data ethics work #csvconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Angela Bassa",
        "screen_name" : "AngeBassa",
        "indices" : [ 5, 15 ],
        "id_str" : "937467860",
        "id" : 937467860
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "csvconf",
        "indices" : [ 83, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "859562728897232896",
    "text" : "\u2764\uFE0F\uD83D\uDC96\uD83D\uDC96 @AngeBassa gives a shoutout to ethnography and sociology for data ethics work #csvconf",
    "id" : 859562728897232896,
    "created_at" : "2017-05-03 00:18:19 +0000",
    "user" : {
      "name" : "Melissa Santos",
      "screen_name" : "ansate",
      "protected" : false,
      "id_str" : "9723702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/824368464752029696\/57f4hmhi_normal.jpg",
      "id" : 9723702,
      "verified" : false
    }
  },
  "id" : 859563804832575488,
  "created_at" : "2017-05-03 00:22:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Lewis",
      "screen_name" : "iff_or",
      "indices" : [ 3, 10 ],
      "id_str" : "766863587088273408",
      "id" : 766863587088273408
    }, {
      "name" : "Angela Bassa",
      "screen_name" : "AngeBassa",
      "indices" : [ 67, 77 ],
      "id_str" : "937467860",
      "id" : 937467860
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "859561382664060928",
  "text" : "RT @iff_or: \"PhDs don't have a 'ship-it' bone in their bodies.\" -- @AngeBassa eliciting some guilty, some knowing laughs at #csvconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Angela Bassa",
        "screen_name" : "AngeBassa",
        "indices" : [ 55, 65 ],
        "id_str" : "937467860",
        "id" : 937467860
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "csvconf",
        "indices" : [ 112, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "859561225507622912",
    "text" : "\"PhDs don't have a 'ship-it' bone in their bodies.\" -- @AngeBassa eliciting some guilty, some knowing laughs at #csvconf",
    "id" : 859561225507622912,
    "created_at" : "2017-05-03 00:12:20 +0000",
    "user" : {
      "name" : "Melissa Lewis",
      "screen_name" : "iff_or",
      "protected" : false,
      "id_str" : "766863587088273408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926602895096557568\/ZI_z0-D7_normal.jpg",
      "id" : 766863587088273408,
      "verified" : true
    }
  },
  "id" : 859561382664060928,
  "created_at" : "2017-05-03 00:12:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859560298365108224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51858625378973, -122.6856685337822 ]
  },
  "id_str" : "859560984289042432",
  "in_reply_to_user_id" : 14286491,
  "text" : "AI-sociologist sounds like a job title we\u2019ll need rather sooner than later. #csvconf",
  "id" : 859560984289042432,
  "in_reply_to_status_id" : 859560298365108224,
  "created_at" : "2017-05-03 00:11:23 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Bassa",
      "screen_name" : "AngeBassa",
      "indices" : [ 22, 32 ],
      "id_str" : "937467860",
      "id" : 937467860
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/859560298365108224\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/Iys5R3s32o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-3FhKfXcAUrK-_.jpg",
      "id_str" : "859560277439901701",
      "id" : 859560277439901701,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-3FhKfXcAUrK-_.jpg",
      "sizes" : [ {
        "h" : 302,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Iys5R3s32o"
    } ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 33, 41 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859557652220727296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52107189000002, -122.68330498 ]
  },
  "id_str" : "859560298365108224",
  "in_reply_to_user_id" : 14286491,
  "text" : "On building teams, by @AngeBassa #csvconf https:\/\/t.co\/Iys5R3s32o",
  "id" : 859560298365108224,
  "in_reply_to_status_id" : 859557652220727296,
  "created_at" : "2017-05-03 00:08:39 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859509563900350464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52107188999999, -122.68330498 ]
  },
  "id_str" : "859557652220727296",
  "in_reply_to_user_id" : 14286491,
  "text" : "I feel the animal metaphors at #csvconf are about to jump the \uD83E\uDD88.",
  "id" : 859557652220727296,
  "in_reply_to_status_id" : 859509563900350464,
  "created_at" : "2017-05-02 23:58:08 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Valen",
      "screen_name" : "dnvln",
      "indices" : [ 0, 6 ],
      "id_str" : "87795235",
      "id" : 87795235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/lc4CxEKelb",
      "expanded_url" : "https:\/\/www.google.de\/amp\/s\/simonleather.wordpress.com\/2013\/08\/07\/aphid-life-cycles-bizaare-complex-or-what\/amp\/",
      "display_url" : "google.de\/amp\/s\/simonlea\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "859554091147579392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52107189000003, -122.6833049799999 ]
  },
  "id_str" : "859555550534656000",
  "in_reply_to_user_id" : 87795235,
  "text" : "@dnvln That would be a rather simple one! https:\/\/t.co\/lc4CxEKelb ;)",
  "id" : 859555550534656000,
  "in_reply_to_status_id" : 859554091147579392,
  "created_at" : "2017-05-02 23:49:47 +0000",
  "in_reply_to_screen_name" : "dnvln",
  "in_reply_to_user_id_str" : "87795235",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rike MW",
      "screen_name" : "rike_mw",
      "indices" : [ 0, 8 ],
      "id_str" : "79192038",
      "id" : 79192038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859512323484110848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51846587907365, -122.6855525118867 ]
  },
  "id_str" : "859512493554548736",
  "in_reply_to_user_id" : 79192038,
  "text" : "@rike_mw No, was just on my way through or a conference.",
  "id" : 859512493554548736,
  "in_reply_to_status_id" : 859512323484110848,
  "created_at" : "2017-05-02 20:58:42 +0000",
  "in_reply_to_screen_name" : "rike_mw",
  "in_reply_to_user_id_str" : "79192038",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52105254999999, -122.68385957 ]
  },
  "id_str" : "859511206242992128",
  "text" : "\u00ABTwo Degrees of Joshua Kushner\u00BB sounds like a shitty TV movie. \uD83D\uDE02",
  "id" : 859511206242992128,
  "created_at" : "2017-05-02 20:53:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859504623400361984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52105254999999, -122.68385957 ]
  },
  "id_str" : "859509563900350464",
  "in_reply_to_user_id" : 14286491,
  "text" : "Hearing how graph databases are used for investigative journalism: \u201CThe information in this graph made Iceland\u2019s PM resign\u201D #csvconf",
  "id" : 859509563900350464,
  "in_reply_to_status_id" : 859504623400361984,
  "created_at" : "2017-05-02 20:47:03 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasmina Anwar",
      "screen_name" : "yasmina_anwar",
      "indices" : [ 3, 17 ],
      "id_str" : "221460308",
      "id" : 221460308
    }, {
      "name" : "hjoseph",
      "screen_name" : "hjoseph",
      "indices" : [ 93, 101 ],
      "id_str" : "17047046",
      "id" : 17047046
    }, {
      "name" : "CSVConf",
      "screen_name" : "CSVConference",
      "indices" : [ 102, 116 ],
      "id_str" : "2510333484",
      "id" : 2510333484
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "859504662671630336",
  "text" : "RT @yasmina_anwar: \"Speak out, step up, take actions\" Great ending for an amazing keynote by @hjoseph @CSVConference #csvconf https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "hjoseph",
        "screen_name" : "hjoseph",
        "indices" : [ 74, 82 ],
        "id_str" : "17047046",
        "id" : 17047046
      }, {
        "name" : "CSVConf",
        "screen_name" : "CSVConference",
        "indices" : [ 83, 97 ],
        "id_str" : "2510333484",
        "id" : 2510333484
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/yasmina_anwar\/status\/859504514272907264\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/O4Vogsfhe4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-2Sx3MWsAMFRow.jpg",
        "id_str" : "859504489224646659",
        "id" : 859504489224646659,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-2Sx3MWsAMFRow.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/O4Vogsfhe4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/yasmina_anwar\/status\/859504514272907264\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/O4Vogsfhe4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-2Sx3RW0AQVJ1t.jpg",
        "id_str" : "859504489245626372",
        "id" : 859504489245626372,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-2Sx3RW0AQVJ1t.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/O4Vogsfhe4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/yasmina_anwar\/status\/859504514272907264\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/O4Vogsfhe4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-2Sx4bXgAAiiER.jpg",
        "id_str" : "859504489556049920",
        "id" : 859504489556049920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-2Sx4bXgAAiiER.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/O4Vogsfhe4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/yasmina_anwar\/status\/859504514272907264\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/O4Vogsfhe4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-2Sx5LXcAYA0B7.jpg",
        "id_str" : "859504489757372422",
        "id" : 859504489757372422,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-2Sx5LXcAYA0B7.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/O4Vogsfhe4"
      } ],
      "hashtags" : [ {
        "text" : "csvconf",
        "indices" : [ 98, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "859504514272907264",
    "text" : "\"Speak out, step up, take actions\" Great ending for an amazing keynote by @hjoseph @CSVConference #csvconf https:\/\/t.co\/O4Vogsfhe4",
    "id" : 859504514272907264,
    "created_at" : "2017-05-02 20:26:59 +0000",
    "user" : {
      "name" : "Yasmina Anwar",
      "screen_name" : "yasmina_anwar",
      "protected" : false,
      "id_str" : "221460308",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681701447973470212\/27uSdDTM_normal.jpg",
      "id" : 221460308,
      "verified" : false
    }
  },
  "id" : 859504662671630336,
  "created_at" : "2017-05-02 20:27:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 9, 18 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    }, {
      "name" : "hjoseph",
      "screen_name" : "hjoseph",
      "indices" : [ 43, 51 ],
      "id_str" : "17047046",
      "id" : 17047046
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859503062347431936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51843026657171, -122.6853954513768 ]
  },
  "id_str" : "859504623400361984",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABCome to @open_con, you could get a cape.\u00BB @hjoseph #csvconf",
  "id" : 859504623400361984,
  "in_reply_to_status_id" : 859503062347431936,
  "created_at" : "2017-05-02 20:27:25 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859499382630043648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51877673253931, -122.6855521091471 ]
  },
  "id_str" : "859503062347431936",
  "in_reply_to_user_id" : 14286491,
  "text" : "Open data: it\u2019s not only about publicly funded data, foundations fund so much data production as well. #csvconf",
  "id" : 859503062347431936,
  "in_reply_to_status_id" : 859499382630043648,
  "created_at" : "2017-05-02 20:21:13 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Santos",
      "screen_name" : "ansate",
      "indices" : [ 0, 7 ],
      "id_str" : "9723702",
      "id" : 9723702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859502085741596672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51868809391327, -122.6856011432807 ]
  },
  "id_str" : "859502379569356800",
  "in_reply_to_user_id" : 9723702,
  "text" : "@ansate Happy to help!",
  "id" : 859502379569356800,
  "in_reply_to_status_id" : 859502085741596672,
  "created_at" : "2017-05-02 20:18:30 +0000",
  "in_reply_to_screen_name" : "ansate",
  "in_reply_to_user_id_str" : "9723702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 0, 11 ],
      "id_str" : "20653310",
      "id" : 20653310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859501385728933893",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52105237705594, -122.6838597111471 ]
  },
  "id_str" : "859501959404896256",
  "in_reply_to_user_id" : 20653310,
  "text" : "@rchampieux Reminder: Totally need to sneak out later today to make it to Powell\u2019s.",
  "id" : 859501959404896256,
  "in_reply_to_status_id" : 859501385728933893,
  "created_at" : "2017-05-02 20:16:50 +0000",
  "in_reply_to_screen_name" : "rchampieux",
  "in_reply_to_user_id_str" : "20653310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Santos",
      "screen_name" : "ansate",
      "indices" : [ 0, 7 ],
      "id_str" : "9723702",
      "id" : 9723702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/qsriSd14GO",
      "expanded_url" : "https:\/\/twitter.com\/jburnmurdoch\/status\/856864274370752512",
      "display_url" : "twitter.com\/jburnmurdoch\/s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "859500545777704960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5210509567298, -122.683860870337 ]
  },
  "id_str" : "859501730098167808",
  "in_reply_to_user_id" : 9723702,
  "text" : "@ansate This one? https:\/\/t.co\/qsriSd14GO",
  "id" : 859501730098167808,
  "in_reply_to_status_id" : 859500545777704960,
  "created_at" : "2017-05-02 20:15:55 +0000",
  "in_reply_to_screen_name" : "ansate",
  "in_reply_to_user_id_str" : "9723702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859495189265530880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52110275823328, -122.6838347228581 ]
  },
  "id_str" : "859499382630043648",
  "in_reply_to_user_id" : 14286491,
  "text" : "Shoutout to our heroes, all the librarians! #csvconf",
  "id" : 859499382630043648,
  "in_reply_to_status_id" : 859495189265530880,
  "created_at" : "2017-05-02 20:06:36 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 28, 40 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859494302723883008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5210530958094, -122.6838591705506 ]
  },
  "id_str" : "859495189265530880",
  "in_reply_to_user_id" : 14286491,
  "text" : "Open data in the \uD83C\uDDFA\uD83C\uDDF8? Thanks @BarackObama! #csvconf",
  "id" : 859495189265530880,
  "in_reply_to_status_id" : 859494302723883008,
  "created_at" : "2017-05-02 19:49:56 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hjoseph",
      "screen_name" : "hjoseph",
      "indices" : [ 53, 61 ],
      "id_str" : "17047046",
      "id" : 17047046
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859479414513336320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52105255007619, -122.6838595699535 ]
  },
  "id_str" : "859494302723883008",
  "in_reply_to_user_id" : 14286491,
  "text" : "Reason why astronomy data is open: it\u2019s worthless. \u2014 @hjoseph  #csvconf",
  "id" : 859494302723883008,
  "in_reply_to_status_id" : 859479414513336320,
  "created_at" : "2017-05-02 19:46:25 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/RdeObJp9qE",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTmiD9alZqU\/",
      "display_url" : "instagram.com\/p\/BTmiD9alZqU\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51821, -122.68618 ]
  },
  "id_str" : "859493082387148801",
  "text" : "Hearing about the state of \uD83C\uDDFA\uD83C\uDDF8 open data. #csvconf @ First Unitarian Portland https:\/\/t.co\/RdeObJp9qE",
  "id" : 859493082387148801,
  "created_at" : "2017-05-02 19:41:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Jockers",
      "screen_name" : "sjockers",
      "indices" : [ 0, 9 ],
      "id_str" : "37756965",
      "id" : 37756965
    }, {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 10, 26 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859482699051827200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51875254594725, -122.6859723052871 ]
  },
  "id_str" : "859483009061240832",
  "in_reply_to_user_id" : 37756965,
  "text" : "@sjockers @keyboardpipette Thanks!",
  "id" : 859483009061240832,
  "in_reply_to_status_id" : 859482699051827200,
  "created_at" : "2017-05-02 19:01:32 +0000",
  "in_reply_to_screen_name" : "sjockers",
  "in_reply_to_user_id_str" : "37756965",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/HfX58RObAT",
      "expanded_url" : "https:\/\/twitter.com\/mpoessel\/status\/859480139440304129",
      "display_url" : "twitter.com\/mpoessel\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51880927962075, -122.6856181138436 ]
  },
  "id_str" : "859482449968996352",
  "text" : "Probably of interest to the larger #csvconf community! https:\/\/t.co\/HfX58RObAT",
  "id" : 859482449968996352,
  "created_at" : "2017-05-02 18:59:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus P\u00F6ssel",
      "screen_name" : "mpoessel",
      "indices" : [ 0, 9 ],
      "id_str" : "276597679",
      "id" : 276597679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859481361257811968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51866361829578, -122.6854069140916 ]
  },
  "id_str" : "859481930449829888",
  "in_reply_to_user_id" : 276597679,
  "text" : "@mpoessel Seems fair to me, just didn\u2019t want to conflate the two directions :)",
  "id" : 859481930449829888,
  "in_reply_to_status_id" : 859481361257811968,
  "created_at" : "2017-05-02 18:57:15 +0000",
  "in_reply_to_screen_name" : "mpoessel",
  "in_reply_to_user_id_str" : "276597679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mouse Reeve",
      "screen_name" : "tripofmice",
      "indices" : [ 3, 14 ],
      "id_str" : "1304991110",
      "id" : 1304991110
    }, {
      "name" : "Daniel Orbach",
      "screen_name" : "Orbachdl",
      "indices" : [ 123, 132 ],
      "id_str" : "474536826",
      "id" : 474536826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "859480480269254656",
  "text" : "RT @tripofmice: \"1. Should this be visualized?\n 2. What assumptions did they make?\n 3. What are they trying to depict?\" -- @Orbachdl #csvco\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Orbach",
        "screen_name" : "Orbachdl",
        "indices" : [ 107, 116 ],
        "id_str" : "474536826",
        "id" : 474536826
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "csvconf",
        "indices" : [ 117, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "859479571208339456",
    "text" : "\"1. Should this be visualized?\n 2. What assumptions did they make?\n 3. What are they trying to depict?\" -- @Orbachdl #csvconf",
    "id" : 859479571208339456,
    "created_at" : "2017-05-02 18:47:52 +0000",
    "user" : {
      "name" : "Mouse Reeve",
      "screen_name" : "tripofmice",
      "protected" : false,
      "id_str" : "1304991110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877644089356713984\/sdBg_srE_normal.jpg",
      "id" : 1304991110,
      "verified" : false
    }
  },
  "id" : 859480480269254656,
  "created_at" : "2017-05-02 18:51:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus P\u00F6ssel",
      "screen_name" : "mpoessel",
      "indices" : [ 0, 9 ],
      "id_str" : "276597679",
      "id" : 276597679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/cbHhQu9W5h",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Thomas_Midgley_Jr",
      "display_url" : "en.wikipedia.org\/wiki\/Thomas_Mi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "859480139440304129",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51874454571669, -122.6860735167173 ]
  },
  "id_str" : "859480349356589056",
  "in_reply_to_user_id" : 276597679,
  "text" : "@mpoessel I\u2019d rather not. The Midgley comparison was not meant to flatter. ;-) https:\/\/t.co\/cbHhQu9W5h.",
  "id" : 859480349356589056,
  "in_reply_to_status_id" : 859480139440304129,
  "created_at" : "2017-05-02 18:50:58 +0000",
  "in_reply_to_screen_name" : "mpoessel",
  "in_reply_to_user_id_str" : "276597679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/FJ07zK1Pfj",
      "expanded_url" : "https:\/\/twitter.com\/tripofmice\/status\/859478974031736832",
      "display_url" : "twitter.com\/tripofmice\/sta\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "859479068793753600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51873077323298, -122.6860163698909 ]
  },
  "id_str" : "859479414513336320",
  "in_reply_to_user_id" : 14286491,
  "text" : "Also: not all people can see all of those colors. Ironic do demonstrate it with green &amp; red. #csvconf https:\/\/t.co\/FJ07zK1Pfj",
  "id" : 859479414513336320,
  "in_reply_to_status_id" : 859479068793753600,
  "created_at" : "2017-05-02 18:47:15 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Orbach",
      "screen_name" : "Orbachdl",
      "indices" : [ 51, 60 ],
      "id_str" : "474536826",
      "id" : 474536826
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859477071344553984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51873840234244, -122.686083800431 ]
  },
  "id_str" : "859479068793753600",
  "in_reply_to_user_id" : 14286491,
  "text" : "Q when doing data viz: What assumptions do I make? @Orbachdl  #csvconf",
  "id" : 859479068793753600,
  "in_reply_to_status_id" : 859477071344553984,
  "created_at" : "2017-05-02 18:45:53 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mouse Reeve",
      "screen_name" : "tripofmice",
      "indices" : [ 3, 14 ],
      "id_str" : "1304991110",
      "id" : 1304991110
    }, {
      "name" : "Daniel Orbach",
      "screen_name" : "Orbachdl",
      "indices" : [ 117, 126 ],
      "id_str" : "474536826",
      "id" : 474536826
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "859478726328832000",
  "text" : "RT @tripofmice: first question to ask when making a data visualization: \"should I make this visualization at all?\" --@Orbachdl #csvconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Orbach",
        "screen_name" : "Orbachdl",
        "indices" : [ 101, 110 ],
        "id_str" : "474536826",
        "id" : 474536826
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "csvconf",
        "indices" : [ 111, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "859478482937552897",
    "text" : "first question to ask when making a data visualization: \"should I make this visualization at all?\" --@Orbachdl #csvconf",
    "id" : 859478482937552897,
    "created_at" : "2017-05-02 18:43:33 +0000",
    "user" : {
      "name" : "Mouse Reeve",
      "screen_name" : "tripofmice",
      "protected" : false,
      "id_str" : "1304991110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877644089356713984\/sdBg_srE_normal.jpg",
      "id" : 1304991110,
      "verified" : false
    }
  },
  "id" : 859478726328832000,
  "created_at" : "2017-05-02 18:44:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859477930392662016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51873840234244, -122.686083800431 ]
  },
  "id_str" : "859478502789099520",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics can I join? :P",
  "id" : 859478502789099520,
  "in_reply_to_status_id" : 859477930392662016,
  "created_at" : "2017-05-02 18:43:38 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859477562451480577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51873348036156, -122.6860515466317 ]
  },
  "id_str" : "859477733910298626",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics I think that would be ideal, you can do the training somewhere outside Antarctica and then move there. :D",
  "id" : 859477733910298626,
  "in_reply_to_status_id" : 859477562451480577,
  "created_at" : "2017-05-02 18:40:34 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859476264914010112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51873786052234, -122.6860665355985 ]
  },
  "id_str" : "859477071344553984",
  "in_reply_to_user_id" : 14286491,
  "text" : "Shoutout to William Playfair, who brought us bar charts, pie charts and Circos plots. The Thomas Midgley Jr. of data viz. #csvconf",
  "id" : 859477071344553984,
  "in_reply_to_status_id" : 859476264914010112,
  "created_at" : "2017-05-02 18:37:56 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859475600318251008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51873782795253, -122.6860659230391 ]
  },
  "id_str" : "859476264914010112",
  "in_reply_to_user_id" : 14286491,
  "text" : "data visualization is opinion. #csvconf",
  "id" : 859476264914010112,
  "in_reply_to_status_id" : 859475600318251008,
  "created_at" : "2017-05-02 18:34:44 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hjoseph",
      "screen_name" : "hjoseph",
      "indices" : [ 0, 8 ],
      "id_str" : "17047046",
      "id" : 17047046
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 9, 18 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    }, {
      "name" : "Nick Shockey",
      "screen_name" : "nshockey",
      "indices" : [ 19, 28 ],
      "id_str" : "16728620",
      "id" : 16728620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859459949281198080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51871966777561, -122.6860506962556 ]
  },
  "id_str" : "859475938542706688",
  "in_reply_to_user_id" : 17047046,
  "text" : "@hjoseph @open_con @nshockey gotta do another group picture? ;)",
  "id" : 859475938542706688,
  "in_reply_to_status_id" : 859459949281198080,
  "created_at" : "2017-05-02 18:33:26 +0000",
  "in_reply_to_screen_name" : "hjoseph",
  "in_reply_to_user_id_str" : "17047046",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/E9l4pqAMnW",
      "expanded_url" : "https:\/\/twitter.com\/robustgar\/status\/859318971920769024",
      "display_url" : "twitter.com\/robustgar\/stat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "859475155969495040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51871966777561, -122.6860506962556 ]
  },
  "id_str" : "859475600318251008",
  "in_reply_to_user_id" : 14286491,
  "text" : "See a recent example of why bar graphs are problematic at best. https:\/\/t.co\/E9l4pqAMnW  #csvconf",
  "id" : 859475600318251008,
  "in_reply_to_status_id" : 859475155969495040,
  "created_at" : "2017-05-02 18:32:06 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Orbach",
      "screen_name" : "Orbachdl",
      "indices" : [ 70, 79 ],
      "id_str" : "474536826",
      "id" : 474536826
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859470943478927360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51873668729722, -122.6861106745336 ]
  },
  "id_str" : "859475155969495040",
  "in_reply_to_user_id" : 14286491,
  "text" : "Looking forward to \u201EThe Journey to a Better Bar Graph, and Beyond\u201C by @orbachdl #csvconf",
  "id" : 859475155969495040,
  "in_reply_to_status_id" : 859470943478927360,
  "created_at" : "2017-05-02 18:30:20 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    }, {
      "name" : "Simon Jockers",
      "screen_name" : "sjockers",
      "indices" : [ 26, 35 ],
      "id_str" : "37756965",
      "id" : 37756965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859474804872708096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51873668729722, -122.6861106745336 ]
  },
  "id_str" : "859474965841592320",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette I\u2019m sure @sjockers can point you to some good resources!",
  "id" : 859474965841592320,
  "in_reply_to_status_id" : 859474804872708096,
  "created_at" : "2017-05-02 18:29:34 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 3, 14 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "Kate Rabinowitz",
      "screen_name" : "DataLensDC",
      "indices" : [ 124, 135 ],
      "id_str" : "904420986438787072",
      "id" : 904420986438787072
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenData",
      "indices" : [ 105, 114 ]
    }, {
      "text" : "csvconf",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "859473115113336832",
  "text" : "RT @rchampieux: Data is not opinion-less and reflects the biases and mistakes underlying its collection. #OpenData #csvconf @DataLensDC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kate Rabinowitz",
        "screen_name" : "DataLensDC",
        "indices" : [ 108, 119 ],
        "id_str" : "904420986438787072",
        "id" : 904420986438787072
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenData",
        "indices" : [ 89, 98 ]
      }, {
        "text" : "csvconf",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "859472035210084352",
    "text" : "Data is not opinion-less and reflects the biases and mistakes underlying its collection. #OpenData #csvconf @DataLensDC",
    "id" : 859472035210084352,
    "created_at" : "2017-05-02 18:17:56 +0000",
    "user" : {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "protected" : false,
      "id_str" : "20653310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/77507928\/c016m_normal.jpg",
      "id" : 20653310,
      "verified" : false
    }
  },
  "id" : 859473115113336832,
  "created_at" : "2017-05-02 18:22:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859468873229189120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51873040978125, -122.686076173826 ]
  },
  "id_str" : "859470943478927360",
  "in_reply_to_user_id" : 14286491,
  "text" : "On interactive data visualizations: We\u2019re building tools, not graphics. #csvconf",
  "id" : 859470943478927360,
  "in_reply_to_status_id" : 859468873229189120,
  "created_at" : "2017-05-02 18:13:35 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurie Allen",
      "screen_name" : "librlaurie",
      "indices" : [ 3, 14 ],
      "id_str" : "213793319",
      "id" : 213793319
    }, {
      "name" : "Simon Jockers",
      "screen_name" : "sjockers",
      "indices" : [ 86, 95 ],
      "id_str" : "37756965",
      "id" : 37756965
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "859470576640860160",
  "text" : "RT @librlaurie: Fascinating story about publication of stazi data post Berlin-wall by @sjockers. a newspaper supplement from 1990. #csvconf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Simon Jockers",
        "screen_name" : "sjockers",
        "indices" : [ 70, 79 ],
        "id_str" : "37756965",
        "id" : 37756965
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/librlaurie\/status\/859470262063874048\/photo\/1",
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/1goP0K8X4J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-1zolzXcAIt8Po.jpg",
        "id_str" : "859470245077151746",
        "id" : 859470245077151746,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-1zolzXcAIt8Po.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/1goP0K8X4J"
      } ],
      "hashtags" : [ {
        "text" : "csvconf",
        "indices" : [ 115, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "859470262063874048",
    "text" : "Fascinating story about publication of stazi data post Berlin-wall by @sjockers. a newspaper supplement from 1990. #csvconf https:\/\/t.co\/1goP0K8X4J",
    "id" : 859470262063874048,
    "created_at" : "2017-05-02 18:10:53 +0000",
    "user" : {
      "name" : "Laurie Allen",
      "screen_name" : "librlaurie",
      "protected" : false,
      "id_str" : "213793319",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723916671803621376\/Jh0shr45_normal.jpg",
      "id" : 213793319,
      "verified" : false
    }
  },
  "id" : 859470576640860160,
  "created_at" : "2017-05-02 18:12:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859468436010713088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51873896111323, -122.6860891418161 ]
  },
  "id_str" : "859468873229189120",
  "in_reply_to_user_id" : 14286491,
  "text" : "Starting off with a history lesson about the fall of the Berlin wall. #csvconf",
  "id" : 859468873229189120,
  "in_reply_to_status_id" : 859468436010713088,
  "created_at" : "2017-05-02 18:05:22 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Jockers",
      "screen_name" : "sjockers",
      "indices" : [ 92, 101 ],
      "id_str" : "37756965",
      "id" : 37756965
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51873921525033, -122.6860909362181 ]
  },
  "id_str" : "859468436010713088",
  "text" : "Now: Designing data exploration: How to make large data sets accessible (and fun to use) by @sjockers #csvconf",
  "id" : 859468436010713088,
  "created_at" : "2017-05-02 18:03:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/r9ai5JPVNc",
      "expanded_url" : "https:\/\/twitter.com\/elliotharmon\/status\/859462514882498560",
      "display_url" : "twitter.com\/elliotharmon\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51846611064233, -122.6863459565691 ]
  },
  "id_str" : "859463400203575296",
  "text" : "Maybe they could offer a \u201EGitHub for Penguins\u201C course. #csvconf https:\/\/t.co\/r9ai5JPVNc",
  "id" : 859463400203575296,
  "created_at" : "2017-05-02 17:43:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5184644127618, -122.6863270858085 ]
  },
  "id_str" : "859461530076631040",
  "text" : "Software\/Data Carpentry is looking for volunteers in Antarctica, for running workshops there. #csvconf",
  "id" : 859461530076631040,
  "created_at" : "2017-05-02 17:36:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Becker",
      "screen_name" : "ErinSBecker",
      "indices" : [ 71, 83 ],
      "id_str" : "3704290280",
      "id" : 3704290280
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 85, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5184644127618, -122.6863270858085 ]
  },
  "id_str" : "859460156823699457",
  "text" : "Looking forward to \u201EEmpowering people by democratizing data skills\u201C by @ErinSBecker! #csvconf",
  "id" : 859460156823699457,
  "created_at" : "2017-05-02 17:30:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/859456278527000576\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/8ctaV21qHe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-1m5h4XYAIG-qA.jpg",
      "id_str" : "859456242430992386",
      "id" : 859456242430992386,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-1m5h4XYAIG-qA.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8ctaV21qHe"
    } ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.51806665961213, -122.6855951083104 ]
  },
  "id_str" : "859456278527000576",
  "text" : "#csvconf certainly has an interesting venue. Perfect to dispel the notions that this is all a cult. https:\/\/t.co\/8ctaV21qHe",
  "id" : 859456278527000576,
  "created_at" : "2017-05-02 17:15:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52396350999999, -122.67431276 ]
  },
  "id_str" : "859433608552955904",
  "text" : "Unsure whether my lost sense of time comes from actual jet lag or from living in YYZ for too long. \uD83E\uDD14",
  "id" : 859433608552955904,
  "created_at" : "2017-05-02 15:45:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coko Foundation",
      "screen_name" : "CokoFoundation",
      "indices" : [ 0, 15 ],
      "id_str" : "3871826339",
      "id" : 3871826339
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 16, 26 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859240516788944896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52339785999999, -122.6838104 ]
  },
  "id_str" : "859241420736966657",
  "in_reply_to_user_id" : 3871826339,
  "text" : "@CokoFoundation @blahah404 Looking forward to it!",
  "id" : 859241420736966657,
  "in_reply_to_status_id" : 859240516788944896,
  "created_at" : "2017-05-02 03:01:33 +0000",
  "in_reply_to_screen_name" : "CokoFoundation",
  "in_reply_to_user_id_str" : "3871826339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coko Foundation",
      "screen_name" : "CokoFoundation",
      "indices" : [ 0, 15 ],
      "id_str" : "3871826339",
      "id" : 3871826339
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 16, 26 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859236761100144640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.52339785999999, -122.6838104 ]
  },
  "id_str" : "859239922435203072",
  "in_reply_to_user_id" : 3871826339,
  "text" : "@CokoFoundation @blahah404 Thanks for the chat!",
  "id" : 859239922435203072,
  "in_reply_to_status_id" : 859236761100144640,
  "created_at" : "2017-05-02 02:55:36 +0000",
  "in_reply_to_screen_name" : "CokoFoundation",
  "in_reply_to_user_id_str" : "3871826339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Coko Foundation",
      "screen_name" : "CokoFoundation",
      "indices" : [ 11, 26 ],
      "id_str" : "3871826339",
      "id" : 3871826339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 53, 61 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859180988068499456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5207371758721, -122.6764863264958 ]
  },
  "id_str" : "859181226321563648",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @CokoFoundation Well, will be in town for #csvconf as well :)",
  "id" : 859181226321563648,
  "in_reply_to_status_id" : 859180988068499456,
  "created_at" : "2017-05-01 23:02:21 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coko Foundation",
      "screen_name" : "CokoFoundation",
      "indices" : [ 0, 15 ],
      "id_str" : "3871826339",
      "id" : 3871826339
    }, {
      "name" : "United",
      "screen_name" : "united",
      "indices" : [ 89, 96 ],
      "id_str" : "260907612",
      "id" : 260907612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859180216580571136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5228736391715, -122.6776719466994 ]
  },
  "id_str" : "859180657875931136",
  "in_reply_to_user_id" : 3871826339,
  "text" : "@CokoFoundation Thanks, so annoyed to have missed all of it due to the chaos at YYZ with @united",
  "id" : 859180657875931136,
  "in_reply_to_status_id" : 859180216580571136,
  "created_at" : "2017-05-01 23:00:06 +0000",
  "in_reply_to_screen_name" : "CokoFoundation",
  "in_reply_to_user_id_str" : "3871826339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coko Foundation",
      "screen_name" : "CokoFoundation",
      "indices" : [ 0, 15 ],
      "id_str" : "3871826339",
      "id" : 3871826339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859148702212018176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.57730823293848, -122.5672341698059 ]
  },
  "id_str" : "859171359045189633",
  "in_reply_to_user_id" : 3871826339,
  "text" : "@CokoFoundation How long does it run today? Just touched down at PDX and on my way down town!",
  "id" : 859171359045189633,
  "in_reply_to_status_id" : 859148702212018176,
  "created_at" : "2017-05-01 22:23:09 +0000",
  "in_reply_to_screen_name" : "CokoFoundation",
  "in_reply_to_user_id_str" : "3871826339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/PFMAlwt1bf",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTkOMqyldqP\/",
      "display_url" : "instagram.com\/p\/BTkOMqyldqP\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.589172453815, -122.59457497949 ]
  },
  "id_str" : "859167927127420930",
  "text" : "All-In with the stereotypes @ Portland International Airport https:\/\/t.co\/PFMAlwt1bf",
  "id" : 859167927127420930,
  "created_at" : "2017-05-01 22:09:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 0, 10 ],
      "id_str" : "11385492",
      "id" : 11385492
    }, {
      "name" : "Daniela Saderi",
      "screen_name" : "Neurosarda",
      "indices" : [ 11, 22 ],
      "id_str" : "4657994587",
      "id" : 4657994587
    }, {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 23, 34 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 35, 51 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 52, 64 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859163120517890049",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.58995262723936, -122.5910294709006 ]
  },
  "id_str" : "859163311509602306",
  "in_reply_to_user_id" : 11385492,
  "text" : "@jillemery @Neurosarda @rchampieux @daniellecrobins @denormalize That\u2019s all okay. This is all walkable worst case. :D",
  "id" : 859163311509602306,
  "in_reply_to_status_id" : 859163120517890049,
  "created_at" : "2017-05-01 21:51:10 +0000",
  "in_reply_to_screen_name" : "jillemery",
  "in_reply_to_user_id_str" : "11385492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 0, 10 ],
      "id_str" : "11385492",
      "id" : 11385492
    }, {
      "name" : "Daniela Saderi",
      "screen_name" : "Neurosarda",
      "indices" : [ 11, 22 ],
      "id_str" : "4657994587",
      "id" : 4657994587
    }, {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 23, 34 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 35, 51 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 52, 64 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859128933513482240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.59065247723647, -122.5904211923749 ]
  },
  "id_str" : "859162335281266688",
  "in_reply_to_user_id" : 11385492,
  "text" : "@jillemery @Neurosarda @rchampieux @daniellecrobins @denormalize Just touched down!",
  "id" : 859162335281266688,
  "in_reply_to_status_id" : 859128933513482240,
  "created_at" : "2017-05-01 21:47:17 +0000",
  "in_reply_to_screen_name" : "jillemery",
  "in_reply_to_user_id_str" : "11385492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/6pJfFfn6so",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTjvPWEl314\/",
      "display_url" : "instagram.com\/p\/BTjvPWEl314\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.977518173276, -87.904465198517 ]
  },
  "id_str" : "859099855410614273",
  "text" : "Along for the ride @ Chicago O'Hare International Airport https:\/\/t.co\/6pJfFfn6so",
  "id" : 859099855410614273,
  "created_at" : "2017-05-01 17:39:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeerJ CompSci",
      "screen_name" : "PeerJCompSci",
      "indices" : [ 3, 16 ],
      "id_str" : "2981463028",
      "id" : 2981463028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "859098383247691779",
  "text" : "RT @PeerJCompSci: New article: Gender differences and bias in open source: pull request acceptance of women versus men https:\/\/t.co\/VhHlsPT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PeerJCompSci\/status\/859091569114308608\/photo\/1",
        "indices" : [ 125, 148 ],
        "url" : "https:\/\/t.co\/HP9CmREMHj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-wbOP5WsAA8PzZ.jpg",
        "id_str" : "859091560520134656",
        "id" : 859091560520134656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-wbOP5WsAA8PzZ.jpg",
        "sizes" : [ {
          "h" : 321,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HP9CmREMHj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/VhHlsPT47I",
        "expanded_url" : "https:\/\/peerj.com\/articles\/cs-111\/",
        "display_url" : "peerj.com\/articles\/cs-11\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "859091569114308608",
    "text" : "New article: Gender differences and bias in open source: pull request acceptance of women versus men https:\/\/t.co\/VhHlsPT47I https:\/\/t.co\/HP9CmREMHj",
    "id" : 859091569114308608,
    "created_at" : "2017-05-01 17:06:05 +0000",
    "user" : {
      "name" : "PeerJ CompSci",
      "screen_name" : "PeerJCompSci",
      "protected" : false,
      "id_str" : "2981463028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562575007985844224\/JRKKMV-5_normal.png",
      "id" : 2981463028,
      "verified" : false
    }
  },
  "id" : 859098383247691779,
  "created_at" : "2017-05-01 17:33:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859083724935319552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.97709310803747, -87.9094828572943 ]
  },
  "id_str" : "859096546968829953",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks May you have better luck than I had.",
  "id" : 859096546968829953,
  "in_reply_to_status_id" : 859083724935319552,
  "created_at" : "2017-05-01 17:25:52 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/859093586591322113\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/XyGt8MnOFU",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C-wdDX6W0AAt9gN.jpg",
      "id_str" : "859093572716515328",
      "id" : 859093572716515328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C-wdDX6W0AAt9gN.jpg",
      "sizes" : [ {
        "h" : 200,
        "resize" : "fit",
        "w" : 464
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 464
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 464
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 464
      } ],
      "display_url" : "pic.twitter.com\/XyGt8MnOFU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859062322006044672",
  "geo" : { },
  "id_str" : "859093586591322113",
  "in_reply_to_user_id" : 14286491,
  "text" : "Thanks for all the wishes! Made it like this. And now I need a strong drink in PDX tonight. https:\/\/t.co\/XyGt8MnOFU",
  "id" : 859093586591322113,
  "in_reply_to_status_id" : 859062322006044672,
  "created_at" : "2017-05-01 17:14:06 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csvconf",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.67921611763879, -79.61360843859576 ]
  },
  "id_str" : "859062322006044672",
  "text" : "Replacement flight UA2751 YYZ\u2708\uFE0FORD now with 90 minutes delay. Might miss my connection to #csvconf (and let\u2019s see whether we take off\u2026)",
  "id" : 859062322006044672,
  "created_at" : "2017-05-01 15:09:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "859008528282988544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.67980622222255, -79.61171432129188 ]
  },
  "id_str" : "859012346664144896",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv They did, just to call me back after 10h at the airport :p",
  "id" : 859012346664144896,
  "in_reply_to_status_id" : 859008528282988544,
  "created_at" : "2017-05-01 11:51:17 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.68106547022089, -79.61037666341572 ]
  },
  "id_str" : "859005053432193024",
  "text" : "Back at YYZ, next try to leave \uD83C\uDDE8\uD83C\uDDE6.",
  "id" : 859005053432193024,
  "created_at" : "2017-05-01 11:22:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "skullsinthestars",
      "screen_name" : "drskyskull",
      "indices" : [ 0, 11 ],
      "id_str" : "110772878",
      "id" : 110772878
    }, {
      "name" : "Laurie",
      "screen_name" : "choiceIrregular",
      "indices" : [ 12, 28 ],
      "id_str" : "246012713",
      "id" : 246012713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858996245234425856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65036348991178, -79.70217786036176 ]
  },
  "id_str" : "858996403070042113",
  "in_reply_to_user_id" : 110772878,
  "text" : "@drskyskull @choiceIrregular \uD83C\uDF89\uD83C\uDF7B",
  "id" : 858996403070042113,
  "in_reply_to_status_id" : 858996245234425856,
  "created_at" : "2017-05-01 10:47:56 +0000",
  "in_reply_to_screen_name" : "drskyskull",
  "in_reply_to_user_id_str" : "110772878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "skullsinthestars",
      "screen_name" : "drskyskull",
      "indices" : [ 0, 11 ],
      "id_str" : "110772878",
      "id" : 110772878
    }, {
      "name" : "Laurie",
      "screen_name" : "choiceIrregular",
      "indices" : [ 12, 28 ],
      "id_str" : "246012713",
      "id" : 246012713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858991246110584832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65042385573791, -79.70209500462562 ]
  },
  "id_str" : "858996018188308480",
  "in_reply_to_user_id" : 110772878,
  "text" : "@drskyskull @choiceIrregular Can I join? :D",
  "id" : 858996018188308480,
  "in_reply_to_status_id" : 858991246110584832,
  "created_at" : "2017-05-01 10:46:24 +0000",
  "in_reply_to_screen_name" : "drskyskull",
  "in_reply_to_user_id_str" : "110772878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "skullsinthestars",
      "screen_name" : "drskyskull",
      "indices" : [ 0, 11 ],
      "id_str" : "110772878",
      "id" : 110772878
    }, {
      "name" : "Laurie",
      "screen_name" : "choiceIrregular",
      "indices" : [ 12, 28 ],
      "id_str" : "246012713",
      "id" : 246012713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858990396189413377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65054285130424, -79.70225970150317 ]
  },
  "id_str" : "858990763090350080",
  "in_reply_to_user_id" : 110772878,
  "text" : "@drskyskull @choiceIrregular Initially they said I\u2019d make it at least to ORD if not to PDX. Now I never left YYZ and play around with the idea of flying back to FRA.",
  "id" : 858990763090350080,
  "in_reply_to_status_id" : 858990396189413377,
  "created_at" : "2017-05-01 10:25:31 +0000",
  "in_reply_to_screen_name" : "drskyskull",
  "in_reply_to_user_id_str" : "110772878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurie",
      "screen_name" : "choiceIrregular",
      "indices" : [ 0, 16 ],
      "id_str" : "246012713",
      "id" : 246012713
    }, {
      "name" : "skullsinthestars",
      "screen_name" : "drskyskull",
      "indices" : [ 17, 28 ],
      "id_str" : "110772878",
      "id" : 110772878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858989752669941760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.6506229768264, -79.70237513064842 ]
  },
  "id_str" : "858990142769561600",
  "in_reply_to_user_id" : 246012713,
  "text" : "@choiceIrregular @drskyskull Actually ended up stranded at YYZ, the promised stranding at ORD didn\u2019t happen. (So far at least\u2026)",
  "id" : 858990142769561600,
  "in_reply_to_status_id" : 858989752669941760,
  "created_at" : "2017-05-01 10:23:03 +0000",
  "in_reply_to_screen_name" : "choiceIrregular",
  "in_reply_to_user_id_str" : "246012713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858956537754210306",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64987965815233, -79.70277741289998 ]
  },
  "id_str" : "858984439380152320",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Well, thanks to the super quick service it was &lt;3h of trying to sleep and now: next try of getting to PDX.",
  "id" : 858984439380152320,
  "in_reply_to_status_id" : 858956537754210306,
  "created_at" : "2017-05-01 10:00:24 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/1RrBqUM6Y7",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/bC2yOkD5zBX",
      "display_url" : "swarmapp.com\/c\/bC2yOkD5zBX"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.650481, -79.70216 ]
  },
  "id_str" : "858933519992705024",
  "text" : "The slowest check in I've ever seen. 1+ h waiting for the group\u2026 (@ Park Inn by Radisson, Toronto Airport West) https:\/\/t.co\/1RrBqUM6Y7",
  "id" : 858933519992705024,
  "created_at" : "2017-05-01 06:38:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858908966021156864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64596393403313, -79.64487460324936 ]
  },
  "id_str" : "858919175808536576",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps \u201CMay you live in interesting times\u201D",
  "id" : 858919175808536576,
  "in_reply_to_status_id" : 858908966021156864,
  "created_at" : "2017-05-01 05:41:04 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United",
      "screen_name" : "united",
      "indices" : [ 55, 62 ],
      "id_str" : "260907612",
      "id" : 260907612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.68231448363876, -79.6109714481701 ]
  },
  "id_str" : "858908779609509888",
  "text" : "Fun fact: the 0945 flight on which I was now booked by @united is already late! \uD83D\uDCAF",
  "id" : 858908779609509888,
  "created_at" : "2017-05-01 04:59:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abi Hartwick",
      "screen_name" : "abihartwick",
      "indices" : [ 0, 12 ],
      "id_str" : "169227203",
      "id" : 169227203
    }, {
      "name" : "United",
      "screen_name" : "united",
      "indices" : [ 13, 20 ],
      "id_str" : "260907612",
      "id" : 260907612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858907996780453888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.68244247629119, -79.61072521162788 ]
  },
  "id_str" : "858908187122118656",
  "in_reply_to_user_id" : 169227203,
  "text" : "@abihartwick @united They are rebooking people to tomorrow and getting them hotels for the night. Slow and painful process.",
  "id" : 858908187122118656,
  "in_reply_to_status_id" : 858907996780453888,
  "created_at" : "2017-05-01 04:57:24 +0000",
  "in_reply_to_screen_name" : "abihartwick",
  "in_reply_to_user_id_str" : "169227203",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858902370268459008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.68239632313934, -79.61079856093693 ]
  },
  "id_str" : "858906280580329472",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps At least I\u2019m now stuck in YYZ even\u2026",
  "id" : 858906280580329472,
  "in_reply_to_status_id" : 858902370268459008,
  "created_at" : "2017-05-01 04:49:49 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TVFunnyman",
      "screen_name" : "TVFunnyman",
      "indices" : [ 0, 11 ],
      "id_str" : "242050891",
      "id" : 242050891
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/858901052200038404\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/zx4eyig6Ni",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-tt8yaUwAAe6sl.jpg",
      "id_str" : "858901045035974656",
      "id" : 858901045035974656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-tt8yaUwAAe6sl.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/zx4eyig6Ni"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858897046102827008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.68177860360451, -79.61051727307401 ]
  },
  "id_str" : "858901052200038404",
  "in_reply_to_user_id" : 242050891,
  "text" : "@TVFunnyman Foursquare isn\u2019t helping! https:\/\/t.co\/zx4eyig6Ni",
  "id" : 858901052200038404,
  "in_reply_to_status_id" : 858897046102827008,
  "created_at" : "2017-05-01 04:29:03 +0000",
  "in_reply_to_screen_name" : "TVFunnyman",
  "in_reply_to_user_id_str" : "242050891",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TVFunnyman",
      "screen_name" : "TVFunnyman",
      "indices" : [ 0, 11 ],
      "id_str" : "242050891",
      "id" : 242050891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858897046102827008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.68041309999999, -79.61620707999997 ]
  },
  "id_str" : "858897171453800448",
  "in_reply_to_user_id" : 242050891,
  "text" : "@TVFunnyman That\u2019s all of them!",
  "id" : 858897171453800448,
  "in_reply_to_status_id" : 858897046102827008,
  "created_at" : "2017-05-01 04:13:37 +0000",
  "in_reply_to_screen_name" : "TVFunnyman",
  "in_reply_to_user_id_str" : "242050891",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TVFunnyman",
      "screen_name" : "TVFunnyman",
      "indices" : [ 0, 11 ],
      "id_str" : "242050891",
      "id" : 242050891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858896215492186112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.68041309999999, -79.61620707999997 ]
  },
  "id_str" : "858896414490988544",
  "in_reply_to_user_id" : 242050891,
  "text" : "@TVFunnyman Absolutely, In which line are you queueing right now? :D",
  "id" : 858896414490988544,
  "in_reply_to_status_id" : 858896215492186112,
  "created_at" : "2017-05-01 04:10:37 +0000",
  "in_reply_to_screen_name" : "TVFunnyman",
  "in_reply_to_user_id_str" : "242050891",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TVFunnyman",
      "screen_name" : "TVFunnyman",
      "indices" : [ 0, 11 ],
      "id_str" : "242050891",
      "id" : 242050891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858880608440922114",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.68041309999999, -79.61620707999997 ]
  },
  "id_str" : "858895759944691713",
  "in_reply_to_user_id" : 242050891,
  "text" : "@TVFunnyman Welcome to the club. \u201CThanks for trying with us today!\u201D",
  "id" : 858895759944691713,
  "in_reply_to_status_id" : 858880608440922114,
  "created_at" : "2017-05-01 04:08:01 +0000",
  "in_reply_to_screen_name" : "TVFunnyman",
  "in_reply_to_user_id_str" : "242050891",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abi Hartwick",
      "screen_name" : "abihartwick",
      "indices" : [ 0, 12 ],
      "id_str" : "169227203",
      "id" : 169227203
    }, {
      "name" : "United",
      "screen_name" : "united",
      "indices" : [ 13, 20 ],
      "id_str" : "260907612",
      "id" : 260907612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858889925466480640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.68041309999999, -79.61620707999997 ]
  },
  "id_str" : "858895366955126784",
  "in_reply_to_user_id" : 169227203,
  "text" : "@abihartwick @united UA582?",
  "id" : 858895366955126784,
  "in_reply_to_status_id" : 858889925466480640,
  "created_at" : "2017-05-01 04:06:27 +0000",
  "in_reply_to_screen_name" : "abihartwick",
  "in_reply_to_user_id_str" : "169227203",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United",
      "screen_name" : "united",
      "indices" : [ 1, 8 ],
      "id_str" : "260907612",
      "id" : 260907612
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/858886697534320641\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/DUlXZhvDgq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-tg4xPUQAAO8Xy.jpg",
      "id_str" : "858886682350731264",
      "id" : 858886682350731264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-tg4xPUQAAO8Xy.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/DUlXZhvDgq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858879037225267200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.67766395168418, -79.60649163700002 ]
  },
  "id_str" : "858886697534320641",
  "in_reply_to_user_id" : 14286491,
  "text" : ".@united Back in YYZ &amp; \uD83C\uDDE8\uD83C\uDDE6, after the small joy ride. https:\/\/t.co\/DUlXZhvDgq",
  "id" : 858886697534320641,
  "in_reply_to_status_id" : 858879037225267200,
  "created_at" : "2017-05-01 03:32:00 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United",
      "screen_name" : "united",
      "indices" : [ 1, 8 ],
      "id_str" : "260907612",
      "id" : 260907612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858878130844569604",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.67403667141345, -79.59684662252437 ]
  },
  "id_str" : "858879037225267200",
  "in_reply_to_user_id" : 14286491,
  "text" : ".@united Planned take-off 5:25pm, while driving around in the plane at 11pm they notice we\u2019re over the pilots allowed flight time. Geniuses.",
  "id" : 858879037225267200,
  "in_reply_to_status_id" : 858878130844569604,
  "created_at" : "2017-05-01 03:01:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United",
      "screen_name" : "united",
      "indices" : [ 114, 121 ],
      "id_str" : "260907612",
      "id" : 260907612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858869936898400256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.673153989989, -79.62080673322046 ]
  },
  "id_str" : "858878130844569604",
  "in_reply_to_user_id" : 14286491,
  "text" : "Not taking off because driving around on the tarmac for so long that the pilots aren\u2019t allowed to fly any longer. @united unable to count?",
  "id" : 858878130844569604,
  "in_reply_to_status_id" : 858869936898400256,
  "created_at" : "2017-05-01 02:57:58 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858871983760523264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.67638347856333, -79.61554765511066 ]
  },
  "id_str" : "858872270403641345",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer But the train ride is beautiful, if you ever get the chance. Only did LAX \uD83D\uDE82 SAN, but totally worth it.",
  "id" : 858872270403641345,
  "in_reply_to_status_id" : 858871983760523264,
  "created_at" : "2017-05-01 02:34:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858871191229968384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.67801289543852, -79.61413105025851 ]
  },
  "id_str" : "858871306577731584",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer There\u2019s a train!",
  "id" : 858871306577731584,
  "in_reply_to_status_id" : 858871191229968384,
  "created_at" : "2017-05-01 02:30:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858870349793865729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.67822474804118, -79.61374078884684 ]
  },
  "id_str" : "858870642594242560",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Reaching the point where it would have been equally quick\/quicker to drive to Chicago.",
  "id" : 858870642594242560,
  "in_reply_to_status_id" : 858870349793865729,
  "created_at" : "2017-05-01 02:28:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858857842710851584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.6785857373353, -79.61242254728153 ]
  },
  "id_str" : "858869936898400256",
  "in_reply_to_user_id" : 14286491,
  "text" : "Make that a 5h delay by now. \uD83D\uDE43\uD83E\uDD37\u200D\u2640\uFE0F",
  "id" : 858869936898400256,
  "in_reply_to_status_id" : 858857842710851584,
  "created_at" : "2017-05-01 02:25:24 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiffany Diane",
      "screen_name" : "tiffanydian",
      "indices" : [ 3, 15 ],
      "id_str" : "71593833",
      "id" : 71593833
    }, {
      "name" : "MUNCHIES",
      "screen_name" : "munchies",
      "indices" : [ 18, 27 ],
      "id_str" : "537645111",
      "id" : 537645111
    }, {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 45, 59 ],
      "id_str" : "257319757",
      "id" : 257319757
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tiffanydian\/status\/858851341480886272\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/NqptHpZZCI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-tAqTOVwAAN9k_.jpg",
      "id_str" : "858851249403314176",
      "id" : 858851249403314176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-tAqTOVwAAN9k_.jpg",
      "sizes" : [ {
        "h" : 163,
        "resize" : "fit",
        "w" : 671
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 671
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 671
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 671
      } ],
      "display_url" : "pic.twitter.com\/NqptHpZZCI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "858862259904368641",
  "text" : "RT @tiffanydian: .@munchies \uD83D\uDE4C\uD83C\uDFFD THIS QUOTE BY @lorrainechu3n SAYS IT ALL\uD83D\uDC47\uD83C\uDFFC \/3 https:\/\/t.co\/NqptHpZZCI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MUNCHIES",
        "screen_name" : "munchies",
        "indices" : [ 1, 10 ],
        "id_str" : "537645111",
        "id" : 537645111
      }, {
        "name" : "Lorraine Chuen",
        "screen_name" : "lorrainechu3n",
        "indices" : [ 28, 42 ],
        "id_str" : "257319757",
        "id" : 257319757
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tiffanydian\/status\/858851341480886272\/photo\/1",
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/NqptHpZZCI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-tAqTOVwAAN9k_.jpg",
        "id_str" : "858851249403314176",
        "id" : 858851249403314176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-tAqTOVwAAN9k_.jpg",
        "sizes" : [ {
          "h" : 163,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 671
        } ],
        "display_url" : "pic.twitter.com\/NqptHpZZCI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "858850067893145601",
    "geo" : { },
    "id_str" : "858851341480886272",
    "in_reply_to_user_id" : 71593833,
    "text" : ".@munchies \uD83D\uDE4C\uD83C\uDFFD THIS QUOTE BY @lorrainechu3n SAYS IT ALL\uD83D\uDC47\uD83C\uDFFC \/3 https:\/\/t.co\/NqptHpZZCI",
    "id" : 858851341480886272,
    "in_reply_to_status_id" : 858850067893145601,
    "created_at" : "2017-05-01 01:11:31 +0000",
    "in_reply_to_screen_name" : "tiffanydian",
    "in_reply_to_user_id_str" : "71593833",
    "user" : {
      "name" : "Tiffany Diane",
      "screen_name" : "tiffanydian",
      "protected" : false,
      "id_str" : "71593833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846592116771966976\/Ge8SWY3S_normal.jpg",
      "id" : 71593833,
      "verified" : false
    }
  },
  "id" : 858862259904368641,
  "created_at" : "2017-05-01 01:54:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.67843484044418, -79.61230731576644 ]
  },
  "id_str" : "858857842710851584",
  "text" : "YYZ \u2708\uFE0F ORD, with a 4+ hour delay. Passengers of UA 582 start to bond and make plans in case one of us will get dragged through the aisle.",
  "id" : 858857842710851584,
  "created_at" : "2017-05-01 01:37:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United",
      "screen_name" : "united",
      "indices" : [ 11, 18 ],
      "id_str" : "260907612",
      "id" : 260907612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.68050421800177, -79.6102626424937 ]
  },
  "id_str" : "858830012245569537",
  "text" : "Someone at @united is rolling dice to see when &amp; if UA 582 will ever leave (or arrive) at YYZ\u2026",
  "id" : 858830012245569537,
  "created_at" : "2017-04-30 23:46:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]