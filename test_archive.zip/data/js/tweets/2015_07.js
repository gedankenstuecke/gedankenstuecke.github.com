Grailbird.data.tweets_2015_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627129789434892289",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722381104829, 8.627625320183162 ]
  },
  "id_str" : "627130321826353152",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam at least this will solve the indent-debate for the Pythonista.",
  "id" : 627130321826353152,
  "in_reply_to_status_id" : 627129789434892289,
  "created_at" : "2015-07-31 14:54:54 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lara",
      "screen_name" : "alibi_ranch",
      "indices" : [ 0, 12 ],
      "id_str" : "265371167",
      "id" : 265371167
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627122909660753920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227186349577, 8.627568491553456 ]
  },
  "id_str" : "627124966102843393",
  "in_reply_to_user_id" : 265371167,
  "text" : "@alibi_ranch @Lobot i\u2019m sure there\u2019s prior art somewhere on the internet :3",
  "id" : 627124966102843393,
  "in_reply_to_status_id" : 627122909660753920,
  "created_at" : "2015-07-31 14:33:37 +0000",
  "in_reply_to_screen_name" : "alibi_ranch",
  "in_reply_to_user_id_str" : "265371167",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627121413602848770",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227186349577, 8.627568491553456 ]
  },
  "id_str" : "627122997497884672",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot (this is now the second time it occurs in your archive) \uD83C\uDF46\uD83D\uDC66",
  "id" : 627122997497884672,
  "in_reply_to_status_id" : 627121413602848770,
  "created_at" : "2015-07-31 14:25:48 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/627121158001979392\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/hUQb2PizwU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLP7Xp_WwAAnmEm.png",
      "id_str" : "627121156961779712",
      "id" : 627121156961779712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLP7Xp_WwAAnmEm.png",
      "sizes" : [ {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 659
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      } ],
      "display_url" : "pic.twitter.com\/hUQb2PizwU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627119681887989760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224713381412, 8.627593377589623 ]
  },
  "id_str" : "627121158001979392",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot that\u2019s right, but largely as many of your tweets consist of a single word only, eg: swag, yolo, peniskopf etc\u2026 http:\/\/t.co\/hUQb2PizwU",
  "id" : 627121158001979392,
  "in_reply_to_status_id" : 627119681887989760,
  "created_at" : "2015-07-31 14:18:30 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627117925120524288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228415031565, 8.627570778896791 ]
  },
  "id_str" : "627119225035956224",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot yay, so I don\u2019t have to read all 1565 tweets (w\/ 604 links) \uD83D\uDCDA\uD83D\uDE35",
  "id" : 627119225035956224,
  "in_reply_to_status_id" : 627117925120524288,
  "created_at" : "2015-07-31 14:10:49 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/y7hMnaCUmQ",
      "expanded_url" : "https:\/\/twitter.com\/genetics_blog\/status\/627116848593674240",
      "display_url" : "twitter.com\/genetics_blog\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224737102558, 8.627593195824415 ]
  },
  "id_str" : "627117395610632192",
  "text" : "What about creating an ontology for it? https:\/\/t.co\/y7hMnaCUmQ",
  "id" : 627117395610632192,
  "created_at" : "2015-07-31 14:03:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627116370384261120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224737102558, 8.627593195824415 ]
  },
  "id_str" : "627117006479851520",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot now reposting 4 months worth of \u201Ccc\u2019s i never send\u201D? \uD83D\uDE02",
  "id" : 627117006479851520,
  "in_reply_to_status_id" : 627116370384261120,
  "created_at" : "2015-07-31 14:02:00 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/AUbBnLTfyq",
      "expanded_url" : "http:\/\/xkcd.com\/1558\/",
      "display_url" : "xkcd.com\/1558\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225821115638, 8.62758949090628 ]
  },
  "id_str" : "627114784002056192",
  "text" : "that\u2019s why we\u2019re living on the ground floor: so he can roam freely as much as he wants. http:\/\/t.co\/AUbBnLTfyq",
  "id" : 627114784002056192,
  "created_at" : "2015-07-31 13:53:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maarten den Braber",
      "screen_name" : "mdbraber",
      "indices" : [ 3, 12 ],
      "id_str" : "9938952",
      "id" : 9938952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/67dlz1DaKK",
      "expanded_url" : "http:\/\/bit.ly\/1LUHv8t",
      "display_url" : "bit.ly\/1LUHv8t"
    } ]
  },
  "geo" : { },
  "id_str" : "627102801567555584",
  "text" : "RT @mdbraber: Goosebump. \"When I\u2019m Gone\" http:\/\/t.co\/67dlz1DaKK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/67dlz1DaKK",
        "expanded_url" : "http:\/\/bit.ly\/1LUHv8t",
        "display_url" : "bit.ly\/1LUHv8t"
      } ]
    },
    "geo" : { },
    "id_str" : "627101781403770880",
    "text" : "Goosebump. \"When I\u2019m Gone\" http:\/\/t.co\/67dlz1DaKK",
    "id" : 627101781403770880,
    "created_at" : "2015-07-31 13:01:30 +0000",
    "user" : {
      "name" : "Maarten den Braber",
      "screen_name" : "mdbraber",
      "protected" : false,
      "id_str" : "9938952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/831100581322293249\/_TZFF-1S_normal.jpg",
      "id" : 9938952,
      "verified" : false
    }
  },
  "id" : 627102801567555584,
  "created_at" : "2015-07-31 13:05:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227904903136, 8.627586923268245 ]
  },
  "id_str" : "627075124706025472",
  "text" : "Has anyone tried to use Metassembler with PacBio reads instead of Illumina mate pairs?",
  "id" : 627075124706025472,
  "created_at" : "2015-07-31 11:15:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627017179796475904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228149007249, 8.627593882903302 ]
  },
  "id_str" : "627017638393290752",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I actually was wondering how many soccer fields would fit into Saarland. \u26BD\uFE0F\uD83D\uDCE6",
  "id" : 627017638393290752,
  "in_reply_to_status_id" : 627017179796475904,
  "created_at" : "2015-07-31 07:27:09 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 40, 47 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627012620835508224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233847961187, 8.627536026561923 ]
  },
  "id_str" : "627015149820485632",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Alles Ansichtssache, ich vermute @malech w\u00FCrde behaupten an einer Ausfallstra\u00DFe zu wohnen. :D",
  "id" : 627015149820485632,
  "in_reply_to_status_id" : 627012620835508224,
  "created_at" : "2015-07-31 07:17:15 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/9yhMzcWu8u",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371\/journal.pbio.1002216",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    }, {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/HlsLS5kDQo",
      "expanded_url" : "https:\/\/upload.wikimedia.org\/wikipedia\/commons\/e\/e1\/Early_flight_02561u_%282%29.jpg",
      "display_url" : "upload.wikimedia.org\/wikipedia\/comm\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226272221905, 8.627613342201498 ]
  },
  "id_str" : "627014451955376128",
  "text" : "Where Next for Genetics and Genomics? http:\/\/t.co\/9yhMzcWu8u Fig1: https:\/\/t.co\/HlsLS5kDQo",
  "id" : 627014451955376128,
  "created_at" : "2015-07-31 07:14:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fieldworkfail",
      "indices" : [ 8, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224655735961, 8.627597925514618 ]
  },
  "id_str" : "627013050617458688",
  "text" : "Reading #fieldworkfail is hilarious. Makes me miss fieldwork while being happy about having quit at the same time.",
  "id" : 627013050617458688,
  "created_at" : "2015-07-31 07:08:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626973476566380544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228171957733, 8.627577249419874 ]
  },
  "id_str" : "627004682662215680",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam i wish all code came with nearly 10% comments.",
  "id" : 627004682662215680,
  "in_reply_to_status_id" : 626973476566380544,
  "created_at" : "2015-07-31 06:35:40 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susannah Tringe",
      "screen_name" : "sgtringe",
      "indices" : [ 0, 9 ],
      "id_str" : "737049997",
      "id" : 737049997
    }, {
      "name" : "Karen Lloyd",
      "screen_name" : "archaearama",
      "indices" : [ 10, 22 ],
      "id_str" : "920986483",
      "id" : 920986483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626885565120581632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403169654043, 8.753331498495324 ]
  },
  "id_str" : "626885849762897921",
  "in_reply_to_user_id" : 737049997,
  "text" : "@sgtringe @archaearama Ah, okay. That fits my experience with hybrid-SPAdes &amp; HGAP\/pb-only assemblers in general. :-)",
  "id" : 626885849762897921,
  "in_reply_to_status_id" : 626885565120581632,
  "created_at" : "2015-07-30 22:43:28 +0000",
  "in_reply_to_screen_name" : "sgtringe",
  "in_reply_to_user_id_str" : "737049997",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susannah Tringe",
      "screen_name" : "sgtringe",
      "indices" : [ 0, 9 ],
      "id_str" : "737049997",
      "id" : 737049997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/H4fGlThxmK",
      "expanded_url" : "https:\/\/twitter.com\/archaearama\/status\/626047838984794113",
      "display_url" : "twitter.com\/archaearama\/st\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "626882994783961088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403138794711, 8.753332193370113 ]
  },
  "id_str" : "626883143795142656",
  "in_reply_to_user_id" : 737049997,
  "text" : "@sgtringe ah, assumed differently based on https:\/\/t.co\/H4fGlThxmK :)",
  "id" : 626883143795142656,
  "in_reply_to_status_id" : 626882994783961088,
  "created_at" : "2015-07-30 22:32:43 +0000",
  "in_reply_to_screen_name" : "sgtringe",
  "in_reply_to_user_id_str" : "737049997",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susannah Tringe",
      "screen_name" : "sgtringe",
      "indices" : [ 0, 9 ],
      "id_str" : "737049997",
      "id" : 737049997
    }, {
      "name" : "Karen Lloyd",
      "screen_name" : "archaearama",
      "indices" : [ 10, 22 ],
      "id_str" : "920986483",
      "id" : 920986483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626880785350438912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402903913278, 8.753331525337382 ]
  },
  "id_str" : "626881219775582208",
  "in_reply_to_user_id" : 737049997,
  "text" : "@sgtringe @archaearama thanks! Know you can take raw PB reads basically for scaffolding, but did you do PB-only assembly w\/ uncorrected? :)",
  "id" : 626881219775582208,
  "in_reply_to_status_id" : 626880785350438912,
  "created_at" : "2015-07-30 22:25:04 +0000",
  "in_reply_to_screen_name" : "sgtringe",
  "in_reply_to_user_id_str" : "737049997",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.23253339256619, 6.999496479942847 ]
  },
  "id_str" : "626818576201216000",
  "text" : "30 years of Sepultura and the audience looks like it was transferred here straight from 1985. \uD83D\uDE02",
  "id" : 626818576201216000,
  "created_at" : "2015-07-30 18:16:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.23246279859817, 6.999286334478327 ]
  },
  "id_str" : "626805081409761280",
  "text" : "Visiting one of Germany\u2019s unofficial units of measure.",
  "id" : 626805081409761280,
  "created_at" : "2015-07-30 17:22:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626776456043954176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.96658302382563, 8.222337216146498 ]
  },
  "id_str" : "626777372809781249",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Wanderlust \uD83D\uDE22",
  "id" : 626777372809781249,
  "in_reply_to_status_id" : 626776456043954176,
  "created_at" : "2015-07-30 15:32:25 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/626775918531489792\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/7QevkoMZTa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLLBX_-WgAA4BnN.png",
      "id_str" : "626775916212027392",
      "id" : 626775916212027392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLLBX_-WgAA4BnN.png",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      } ],
      "display_url" : "pic.twitter.com\/7QevkoMZTa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.98101376933044, 8.330238210045108 ]
  },
  "id_str" : "626775918531489792",
  "text" : "Not the Gau you are looking for. http:\/\/t.co\/7QevkoMZTa",
  "id" : 626775918531489792,
  "created_at" : "2015-07-30 15:26:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Jewell",
      "screen_name" : "hcjewell",
      "indices" : [ 3, 12 ],
      "id_str" : "100187588",
      "id" : 100187588
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/hcjewell\/status\/626710477024980992\/photo\/1",
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/dEpNEfW18p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLKF24dWEAAO40N.png",
      "id_str" : "626710476072816640",
      "id" : 626710476072816640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLKF24dWEAAO40N.png",
      "sizes" : [ {
        "h" : 133,
        "resize" : "crop",
        "w" : 133
      }, {
        "h" : 133,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 133,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 133,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 133,
        "resize" : "fit",
        "w" : 533
      } ],
      "display_url" : "pic.twitter.com\/dEpNEfW18p"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/AUHTHcPbew",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/hannahjewell\/brits-tried-to-guess-the-cost-of-american-healthcare#.einM15QXYz",
      "display_url" : "buzzfeed.com\/hannahjewell\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "626731696361218048",
  "text" : "RT @hcjewell: Brits Tried To Guess The Cost Of American Healthcare And Got Really Confused--&gt;http:\/\/t.co\/AUHTHcPbew http:\/\/t.co\/dEpNEfW18p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hcjewell\/status\/626710477024980992\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/dEpNEfW18p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLKF24dWEAAO40N.png",
        "id_str" : "626710476072816640",
        "id" : 626710476072816640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLKF24dWEAAO40N.png",
        "sizes" : [ {
          "h" : 133,
          "resize" : "crop",
          "w" : 133
        }, {
          "h" : 133,
          "resize" : "fit",
          "w" : 533
        }, {
          "h" : 133,
          "resize" : "fit",
          "w" : 533
        }, {
          "h" : 133,
          "resize" : "fit",
          "w" : 533
        }, {
          "h" : 133,
          "resize" : "fit",
          "w" : 533
        } ],
        "display_url" : "pic.twitter.com\/dEpNEfW18p"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/AUHTHcPbew",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/hannahjewell\/brits-tried-to-guess-the-cost-of-american-healthcare#.einM15QXYz",
        "display_url" : "buzzfeed.com\/hannahjewell\/b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "626710477024980992",
    "text" : "Brits Tried To Guess The Cost Of American Healthcare And Got Really Confused--&gt;http:\/\/t.co\/AUHTHcPbew http:\/\/t.co\/dEpNEfW18p",
    "id" : 626710477024980992,
    "created_at" : "2015-07-30 11:06:36 +0000",
    "user" : {
      "name" : "Hannah Jewell",
      "screen_name" : "hcjewell",
      "protected" : false,
      "id_str" : "100187588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920791230660915201\/4RzCugS9_normal.jpg",
      "id" : 100187588,
      "verified" : true
    }
  },
  "id" : 626731696361218048,
  "created_at" : "2015-07-30 12:30:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "darth:\u2122",
      "screen_name" : "darth",
      "indices" : [ 3, 9 ],
      "id_str" : "1337271",
      "id" : 1337271
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/darth\/status\/626411198435729408\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/04CTz2xHuq",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CLF1e0rWEAA3ayR.png",
      "id_str" : "626410995578179584",
      "id" : 626410995578179584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CLF1e0rWEAA3ayR.png",
      "sizes" : [ {
        "h" : 209,
        "resize" : "fit",
        "w" : 380
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 209,
        "resize" : "fit",
        "w" : 380
      }, {
        "h" : 209,
        "resize" : "fit",
        "w" : 380
      }, {
        "h" : 209,
        "resize" : "fit",
        "w" : 380
      } ],
      "display_url" : "pic.twitter.com\/04CTz2xHuq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626710731816337409",
  "text" : "RT @darth: twitter:\n\"hey is that a chinchilla  sitting on a..\"\n\n\"ACTUALLY, ALL LIVES MATTER\" http:\/\/t.co\/04CTz2xHuq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/darth\/status\/626411198435729408\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/04CTz2xHuq",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CLF1e0rWEAA3ayR.png",
        "id_str" : "626410995578179584",
        "id" : 626410995578179584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CLF1e0rWEAA3ayR.png",
        "sizes" : [ {
          "h" : 209,
          "resize" : "fit",
          "w" : 380
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 209,
          "resize" : "fit",
          "w" : 380
        }, {
          "h" : 209,
          "resize" : "fit",
          "w" : 380
        }, {
          "h" : 209,
          "resize" : "fit",
          "w" : 380
        } ],
        "display_url" : "pic.twitter.com\/04CTz2xHuq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626411198435729408",
    "text" : "twitter:\n\"hey is that a chinchilla  sitting on a..\"\n\n\"ACTUALLY, ALL LIVES MATTER\" http:\/\/t.co\/04CTz2xHuq",
    "id" : 626411198435729408,
    "created_at" : "2015-07-29 15:17:22 +0000",
    "user" : {
      "name" : "darth:\u2122",
      "screen_name" : "darth",
      "protected" : false,
      "id_str" : "1337271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926966658362572800\/_kFCqjT__normal.jpg",
      "id" : 1337271,
      "verified" : false
    }
  },
  "id" : 626710731816337409,
  "created_at" : "2015-07-30 11:07:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/As8I9d1CLT",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/anthropology-in-practice\/we-ve-modified-our-behavior-so-we-can-text-and-walk\/",
      "display_url" : "blogs.scientificamerican.com\/anthropology-i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "626686069812109314",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223554479058, 8.62761756691152 ]
  },
  "id_str" : "626686251463278592",
  "in_reply_to_user_id" : 14286491,
  "text" : "There\u2019s also a good blogpost on the gait adjusting thingy: http:\/\/t.co\/As8I9d1CLT",
  "id" : 626686251463278592,
  "in_reply_to_status_id" : 626686069812109314,
  "created_at" : "2015-07-30 09:30:20 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 77, 86 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/wIyLGSETzX",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0133281",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223554479058, 8.62761756691152 ]
  },
  "id_str" : "626686069812109314",
  "text" : "Cool: How walking-while-texting alters your gait. http:\/\/t.co\/wIyLGSETzX \/cc @eramirez",
  "id" : 626686069812109314,
  "created_at" : "2015-07-30 09:29:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626677696940998656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226481676921, 8.627616456683683 ]
  },
  "id_str" : "626678881790111744",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer no one will remember :3",
  "id" : 626678881790111744,
  "in_reply_to_status_id" : 626677696940998656,
  "created_at" : "2015-07-30 09:01:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626676741247873024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1721706073506, 8.627714526934621 ]
  },
  "id_str" : "626677141296545792",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer kind of interesting though I have no idea how sensible their analysis actually is :D",
  "id" : 626677141296545792,
  "in_reply_to_status_id" : 626676741247873024,
  "created_at" : "2015-07-30 08:54:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626676314297212928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224328983817, 8.627625050160932 ]
  },
  "id_str" : "626676847724597248",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin unclipped adapters?",
  "id" : 626676847724597248,
  "in_reply_to_status_id" : 626676314297212928,
  "created_at" : "2015-07-30 08:52:58 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626674865274269696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222021166501, 8.627621585213653 ]
  },
  "id_str" : "626675650401857538",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin \u201Ccontigs\u201D, probably 250-300 bp MiSeq reads which were shredded down by the assembler. ;)",
  "id" : 626675650401857538,
  "in_reply_to_status_id" : 626674865274269696,
  "created_at" : "2015-07-30 08:48:12 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 123, 136 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/HfkpcucNjK",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0133678",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222228325889, 8.627616756865786 ]
  },
  "id_str" : "626672337346236416",
  "text" : "bitcoin exchange rates: \u00ABWe found that the generalized hyperbolic distribution gives the best fit\u00BB http:\/\/t.co\/HfkpcucNjK \/@PhilippBayer",
  "id" : 626672337346236416,
  "created_at" : "2015-07-30 08:35:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/uAxfvQKYwW",
      "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/required-reading-essay-questions-written-by-a-first-year-adjunct-who-does-not-have-the-time-or-wherewithal-to-do-the-required-reading",
      "display_url" : "mcsweeneys.net\/articles\/requi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223302848123, 8.627619456496195 ]
  },
  "id_str" : "626670506561916928",
  "text" : "\u00ABWho is The Lord of the Flies? How does one become lord of the flies? Is it a paying position?\u00BB http:\/\/t.co\/uAxfvQKYwW",
  "id" : 626670506561916928,
  "created_at" : "2015-07-30 08:27:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Werby",
      "screen_name" : "stevewerby",
      "indices" : [ 3, 14 ],
      "id_str" : "21435367",
      "id" : 21435367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626665391394287616",
  "text" : "RT @stevewerby: Gen X geeks thinks Lynx is dead.\nMillennial geeks don't know about Lynx.\nThen there's *this* person.\nI'm in awe. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/stevewerby\/status\/626552598968037376\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/GQ5v3EyORE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLH2RJ3UcAEgKOS.png",
        "id_str" : "626552597747363841",
        "id" : 626552597747363841,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLH2RJ3UcAEgKOS.png",
        "sizes" : [ {
          "h" : 513,
          "resize" : "fit",
          "w" : 518
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 518
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 518
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 518
        } ],
        "display_url" : "pic.twitter.com\/GQ5v3EyORE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626552598968037376",
    "text" : "Gen X geeks thinks Lynx is dead.\nMillennial geeks don't know about Lynx.\nThen there's *this* person.\nI'm in awe. http:\/\/t.co\/GQ5v3EyORE",
    "id" : 626552598968037376,
    "created_at" : "2015-07-30 00:39:15 +0000",
    "user" : {
      "name" : "Steve Werby",
      "screen_name" : "stevewerby",
      "protected" : false,
      "id_str" : "21435367",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932753020651229184\/9U_0ZGwU_normal.jpg",
      "id" : 21435367,
      "verified" : false
    }
  },
  "id" : 626665391394287616,
  "created_at" : "2015-07-30 08:07:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/iAoT3ETHtz",
      "expanded_url" : "https:\/\/biomickwatson.wordpress.com\/2015\/07\/29\/a-totally-non-sarcastic-list-n-ways-to-improve-productivity-at-universities\/",
      "display_url" : "biomickwatson.wordpress.com\/2015\/07\/29\/a-t\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224579968317, 8.627600985617915 ]
  },
  "id_str" : "626663067108179968",
  "text" : "On uni admin: \u00ABJust trust academics on expense claims, we lose money on it, I promise you.\u00BB relevant right now\u2026 https:\/\/t.co\/iAoT3ETHtz",
  "id" : 626663067108179968,
  "created_at" : "2015-07-30 07:58:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/tvukX8tx3P",
      "expanded_url" : "http:\/\/www.theonion.com\/video\/more-office-workers-switching-to-fetal-position-de-36240",
      "display_url" : "theonion.com\/video\/more-off\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "626400932713091072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227764753913, 8.62758112610575 ]
  },
  "id_str" : "626403233074966528",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot wenn die not-unknown-any-longer unknowns zur\u00FCckkommen kann man hierzu wechseln http:\/\/t.co\/tvukX8tx3P",
  "id" : 626403233074966528,
  "in_reply_to_status_id" : 626400932713091072,
  "created_at" : "2015-07-29 14:45:43 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/LCttcsjj3b",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/wp-dyn\/articles\/A6950-2004Jun25.html",
      "display_url" : "washingtonpost.com\/wp-dyn\/article\u2026"
    }, {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/X8p1TLuflc",
      "expanded_url" : "http:\/\/www.stuff.bryanrabeconstruction.com\/MISC\/PICS\/rumsfeld.gif",
      "display_url" : "stuff.bryanrabeconstruction.com\/MISC\/PICS\/rums\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "626398754808164352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722295611557, 8.627608907553837 ]
  },
  "id_str" : "626399526698545152",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot weisst du wer noch Stehpulte mochte! http:\/\/t.co\/LCttcsjj3b http:\/\/t.co\/X8p1TLuflc",
  "id" : 626399526698545152,
  "in_reply_to_status_id" : 626398754808164352,
  "created_at" : "2015-07-29 14:30:59 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626398023090896897",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221894435649, 8.627644609705495 ]
  },
  "id_str" : "626398366369476608",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot \u00B1 wie ich an meins gekommen bin.\uD83D\uDEB6",
  "id" : 626398366369476608,
  "in_reply_to_status_id" : 626398023090896897,
  "created_at" : "2015-07-29 14:26:23 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/1ePr4LAVXW",
      "expanded_url" : "http:\/\/2.bp.blogspot.com\/-T4MTWQr0MEk\/UboFzzDnKbI\/AAAAAAAAAD8\/nmVEVywYD7w\/s1600\/batman+onomatopoeia.jpg",
      "display_url" : "2.bp.blogspot.com\/-T4MTWQr0MEk\/U\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226154637351, 8.627587071682484 ]
  },
  "id_str" : "626331706719608832",
  "text" : "\u2018BAM\u2019, \u2018PoFF\u2019! Sometimes bioinformatics acronyms feel like the 1960\u2019s Batman onomatopoeia are back. http:\/\/t.co\/1ePr4LAVXW",
  "id" : 626331706719608832,
  "created_at" : "2015-07-29 10:01:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626316398889959424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226148216131, 8.627587702668922 ]
  },
  "id_str" : "626316679677669376",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot go Tenderloin, go. It\u2019s like OF, just with a bit less drugs &amp; hipsters. :p",
  "id" : 626316679677669376,
  "in_reply_to_status_id" : 626316398889959424,
  "created_at" : "2015-07-29 09:01:47 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626315997016948736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226148216131, 8.627587702668922 ]
  },
  "id_str" : "626316261262295040",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot the ref is missing, talking bout the SFnese-translator?",
  "id" : 626316261262295040,
  "in_reply_to_status_id" : 626315997016948736,
  "created_at" : "2015-07-29 09:00:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 17, 31 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Willem van Schaik",
      "screen_name" : "WvSchaik",
      "indices" : [ 32, 41 ],
      "id_str" : "18585425",
      "id" : 18585425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626300547247833088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172238717334, 8.627604779103166 ]
  },
  "id_str" : "626301210811858945",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick @BioMickWatson @WvSchaik so you can be super-wrong in your predictions? :p",
  "id" : 626301210811858945,
  "in_reply_to_status_id" : 626300547247833088,
  "created_at" : "2015-07-29 08:00:19 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "folu",
      "screen_name" : "notfolu",
      "indices" : [ 3, 11 ],
      "id_str" : "265543232",
      "id" : 265543232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/q45cOIVJGn",
      "expanded_url" : "https:\/\/vine.co\/v\/ezMVqK2jTXF",
      "display_url" : "vine.co\/v\/ezMVqK2jTXF"
    } ]
  },
  "geo" : { },
  "id_str" : "626293039372308480",
  "text" : "RT @notfolu: when a white dude gets out his guitar at a party https:\/\/t.co\/q45cOIVJGn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/q45cOIVJGn",
        "expanded_url" : "https:\/\/vine.co\/v\/ezMVqK2jTXF",
        "display_url" : "vine.co\/v\/ezMVqK2jTXF"
      } ]
    },
    "geo" : { },
    "id_str" : "626248174517284864",
    "text" : "when a white dude gets out his guitar at a party https:\/\/t.co\/q45cOIVJGn",
    "id" : 626248174517284864,
    "created_at" : "2015-07-29 04:29:34 +0000",
    "user" : {
      "name" : "folu",
      "screen_name" : "notfolu",
      "protected" : false,
      "id_str" : "265543232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000662297599\/e56fb1d2954819e2e88188d5016fb5e9_normal.jpeg",
      "id" : 265543232,
      "verified" : false
    }
  },
  "id" : 626293039372308480,
  "created_at" : "2015-07-29 07:27:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Oyen",
      "screen_name" : "michelleoyen",
      "indices" : [ 3, 16 ],
      "id_str" : "83589523",
      "id" : 83589523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626286148265054208",
  "text" : "RT @michelleoyen: LOL. \"When you wish to ask a question, have a man ask it for you, to save face.\" 13 Tips on How To Speak While Female htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/CF9ihp4YSh",
        "expanded_url" : "http:\/\/wapo.st\/1JsSrd2",
        "display_url" : "wapo.st\/1JsSrd2"
      } ]
    },
    "geo" : { },
    "id_str" : "626284923142471680",
    "text" : "LOL. \"When you wish to ask a question, have a man ask it for you, to save face.\" 13 Tips on How To Speak While Female http:\/\/t.co\/CF9ihp4YSh",
    "id" : 626284923142471680,
    "created_at" : "2015-07-29 06:55:36 +0000",
    "user" : {
      "name" : "Michelle Oyen",
      "screen_name" : "michelleoyen",
      "protected" : false,
      "id_str" : "83589523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479579308\/MyPicture_normal.jpg",
      "id" : 83589523,
      "verified" : false
    }
  },
  "id" : 626286148265054208,
  "created_at" : "2015-07-29 07:00:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/gu0LyZEEU8",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/125296179199\/when-a-reviewer-is-not-satisfied-with-my-response",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/125296179\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223565631785, 8.627615005074176 ]
  },
  "id_str" : "626279368722116608",
  "text" : "response to reviewer #3 from now on: http:\/\/t.co\/gu0LyZEEU8",
  "id" : 626279368722116608,
  "created_at" : "2015-07-29 06:33:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Lloyd",
      "screen_name" : "archaearama",
      "indices" : [ 0, 12 ],
      "id_str" : "920986483",
      "id" : 920986483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626047838984794113",
  "geo" : { },
  "id_str" : "626277218080133120",
  "in_reply_to_user_id" : 920986483,
  "text" : "@archaearama does Spades allow for uncorrected PacBio reads by now? Or is this after error correction? :)",
  "id" : 626277218080133120,
  "in_reply_to_status_id" : 626047838984794113,
  "created_at" : "2015-07-29 06:24:59 +0000",
  "in_reply_to_screen_name" : "archaearama",
  "in_reply_to_user_id_str" : "920986483",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 3, 17 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626273001332457472",
  "text" : "RT @beaugunderson: woah!\n\nGender and the Human Genome: \"Feminist bioethics offers a useful perspective for addressing these issues.\"\n\nhttp:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/6d1tmaD2MZ",
        "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pmc\/articles\/PMC3151445\/",
        "display_url" : "ncbi.nlm.nih.gov\/pmc\/articles\/P\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "626098903188836352",
    "text" : "woah!\n\nGender and the Human Genome: \"Feminist bioethics offers a useful perspective for addressing these issues.\"\n\nhttp:\/\/t.co\/6d1tmaD2MZ",
    "id" : 626098903188836352,
    "created_at" : "2015-07-28 18:36:25 +0000",
    "user" : {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "protected" : false,
      "id_str" : "5746882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/913840034016399360\/pU3IIxqf_normal.jpg",
      "id" : 5746882,
      "verified" : false
    }
  },
  "id" : 626273001332457472,
  "created_at" : "2015-07-29 06:08:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626189368215015424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239585551763, 8.627576438780748 ]
  },
  "id_str" : "626270152930275328",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Sweet. :)",
  "id" : 626270152930275328,
  "in_reply_to_status_id" : 626189368215015424,
  "created_at" : "2015-07-29 05:56:54 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "molly clare wilson",
      "screen_name" : "mollyclare",
      "indices" : [ 3, 14 ],
      "id_str" : "12138192",
      "id" : 12138192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/mmAOcR1xVy",
      "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/bay-area-to-standard-american-english-translator",
      "display_url" : "mcsweeneys.net\/articles\/bay-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "626185040133795841",
  "text" : "RT @mollyclare: A handy Sanfranciscanese translator, for those few of you who still think it's a city of hippies: http:\/\/t.co\/mmAOcR1xVy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/mmAOcR1xVy",
        "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/bay-area-to-standard-american-english-translator",
        "display_url" : "mcsweeneys.net\/articles\/bay-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "626144200829083648",
    "text" : "A handy Sanfranciscanese translator, for those few of you who still think it's a city of hippies: http:\/\/t.co\/mmAOcR1xVy",
    "id" : 626144200829083648,
    "created_at" : "2015-07-28 21:36:25 +0000",
    "user" : {
      "name" : "molly clare wilson",
      "screen_name" : "mollyclare",
      "protected" : false,
      "id_str" : "12138192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875775628762640385\/Es8xAowp_normal.jpg",
      "id" : 12138192,
      "verified" : false
    }
  },
  "id" : 626185040133795841,
  "created_at" : "2015-07-29 00:18:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "QSEU15",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626184760637784064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408012067553, 8.753350583436392 ]
  },
  "id_str" : "626184895048622081",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez btw will you be in Europe a bit before\/after #QSEU15?",
  "id" : 626184895048622081,
  "in_reply_to_status_id" : 626184760637784064,
  "created_at" : "2015-07-29 00:18:07 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626168792880513024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408012067553, 8.753350583436392 ]
  },
  "id_str" : "626184675938144256",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez thanks for the shoutout!",
  "id" : 626184675938144256,
  "in_reply_to_status_id" : 626168792880513024,
  "created_at" : "2015-07-29 00:17:15 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/vpwhCwP9cf",
      "expanded_url" : "https:\/\/twitter.com\/brainpicker\/status\/626151173658165248",
      "display_url" : "twitter.com\/brainpicker\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408013536009, 8.75335075219991 ]
  },
  "id_str" : "626183241515573248",
  "text" : "\uD83D\uDC93\uD83C\uDF44 Do want! https:\/\/t.co\/vpwhCwP9cf",
  "id" : 626183241515573248,
  "created_at" : "2015-07-29 00:11:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Dzick",
      "screen_name" : "AshleyDzick",
      "indices" : [ 3, 15 ],
      "id_str" : "1913012389",
      "id" : 1913012389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626181730811162624",
  "text" : "RT @AshleyDzick: Alcohol is pretty rampant in tech and UX. I love beer (and bars), but this was an eye-opening long read. https:\/\/t.co\/h4wW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/h4wWmxZOTZ",
        "expanded_url" : "https:\/\/modelviewculture.com\/pieces\/the-ux-of-alcohol-abuse-reflections-on-a-year-of-sobriety",
        "display_url" : "modelviewculture.com\/pieces\/the-ux-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "626096607079981056",
    "text" : "Alcohol is pretty rampant in tech and UX. I love beer (and bars), but this was an eye-opening long read. https:\/\/t.co\/h4wWmxZOTZ",
    "id" : 626096607079981056,
    "created_at" : "2015-07-28 18:27:18 +0000",
    "user" : {
      "name" : "Ashley Dzick",
      "screen_name" : "AshleyDzick",
      "protected" : false,
      "id_str" : "1913012389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573879795022364674\/t5A2aX2o_normal.jpeg",
      "id" : 1913012389,
      "verified" : false
    }
  },
  "id" : 626181730811162624,
  "created_at" : "2015-07-29 00:05:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 3, 10 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mrgunn\/status\/626145281030103040\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/4VGMF2WTwA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLCDccfUEAAafYL.jpg",
      "id_str" : "626144872911605760",
      "id" : 626144872911605760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLCDccfUEAAafYL.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/4VGMF2WTwA"
    } ],
    "hashtags" : [ {
      "text" : "RuinAWestern",
      "indices" : [ 12, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626179899951325184",
  "text" : "RT @mrgunn: #RuinAWestern http:\/\/t.co\/4VGMF2WTwA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mrgunn\/status\/626145281030103040\/photo\/1",
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/4VGMF2WTwA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLCDccfUEAAafYL.jpg",
        "id_str" : "626144872911605760",
        "id" : 626144872911605760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLCDccfUEAAafYL.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/4VGMF2WTwA"
      } ],
      "hashtags" : [ {
        "text" : "RuinAWestern",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626145281030103040",
    "text" : "#RuinAWestern http:\/\/t.co\/4VGMF2WTwA",
    "id" : 626145281030103040,
    "created_at" : "2015-07-28 21:40:42 +0000",
    "user" : {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "protected" : false,
      "id_str" : "15237935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/679914371770798080\/FBcokUq2_normal.jpg",
      "id" : 15237935,
      "verified" : false
    }
  },
  "id" : 626179899951325184,
  "created_at" : "2015-07-28 23:58:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/slOoyPljyN",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=HJwHGMdtIkk&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=HJwHGM\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403165471076, 8.753338781201414 ]
  },
  "id_str" : "626102101932933120",
  "text" : "If you want to see me explain openSNP in less than 5 minutes: I gave a lightning talk at #BOSC2015 https:\/\/t.co\/slOoyPljyN",
  "id" : 626102101932933120,
  "created_at" : "2015-07-28 18:49:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 24, 40 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/FkP344Io3N",
      "expanded_url" : "http:\/\/youtu.be\/HJwHGMdtIkk",
      "display_url" : "youtu.be\/HJwHGMdtIkk"
    } ]
  },
  "geo" : { },
  "id_str" : "626066328445693953",
  "text" : "RT @OBF_BOSC: #BOSC2015 @gedankenstuecke \"openSNP - personal genomics and the public domain\"\nVideo: http:\/\/t.co\/FkP344Io3N\nSlides: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 10, 26 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2015",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/FkP344Io3N",
        "expanded_url" : "http:\/\/youtu.be\/HJwHGMdtIkk",
        "display_url" : "youtu.be\/HJwHGMdtIkk"
      }, {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/xdHkvnQ82f",
        "expanded_url" : "http:\/\/figshare.com\/articles\/openSNP_BOSC15_Slides\/1480397",
        "display_url" : "figshare.com\/articles\/openS\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "622853766006575104",
    "geo" : { },
    "id_str" : "626065668027346944",
    "in_reply_to_user_id" : 583180584,
    "text" : "#BOSC2015 @gedankenstuecke \"openSNP - personal genomics and the public domain\"\nVideo: http:\/\/t.co\/FkP344Io3N\nSlides: http:\/\/t.co\/xdHkvnQ82f",
    "id" : 626065668027346944,
    "in_reply_to_status_id" : 622853766006575104,
    "created_at" : "2015-07-28 16:24:21 +0000",
    "in_reply_to_screen_name" : "OBF_BOSC",
    "in_reply_to_user_id_str" : "583180584",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 626066328445693953,
  "created_at" : "2015-07-28 16:26:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 72, 81 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/wv5gOnZfjp",
      "expanded_url" : "http:\/\/www.acgt.me\/blog\/2015\/7\/27\/bioinformatics-and-genomics-resources-on-reddit?utm_content=bufferc4342&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "acgt.me\/blog\/2015\/7\/27\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225034599895, 8.62760076621016 ]
  },
  "id_str" : "626054154201505792",
  "text" : "If you want to break the social norms of bioinformatics &amp; genomics: @kbradnam as a list of subreddits for you. http:\/\/t.co\/wv5gOnZfjp",
  "id" : 626054154201505792,
  "created_at" : "2015-07-28 15:38:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/g2tEKBz0na",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=3811",
      "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222757233175, 8.627621566303416 ]
  },
  "id_str" : "626051335419510784",
  "text" : "the 5 comic panels of grief http:\/\/t.co\/g2tEKBz0na",
  "id" : 626051335419510784,
  "created_at" : "2015-07-28 15:27:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dryad",
      "screen_name" : "datadryad",
      "indices" : [ 10, 20 ],
      "id_str" : "93950513",
      "id" : 93950513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224115111944, 8.62759868594447 ]
  },
  "id_str" : "626008491988287488",
  "text" : "Thanks to @datadryad for the great support!",
  "id" : 626008491988287488,
  "created_at" : "2015-07-28 12:37:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223106923535, 8.627608510944308 ]
  },
  "id_str" : "625986337267707908",
  "text" : "resubmit \u2713",
  "id" : 625986337267707908,
  "created_at" : "2015-07-28 11:09:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/GPczzxgPUR",
      "expanded_url" : "https:\/\/s-media-cache-ak0.pinimg.com\/originals\/da\/bf\/93\/dabf935bd3fd788111e2f464d78e03a4.gif",
      "display_url" : "s-media-cache-ak0.pinimg.com\/originals\/da\/b\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223307850112, 8.627609428398 ]
  },
  "id_str" : "625951220784627712",
  "text" : "\u2018scientific\u2019 discussions\u2026 https:\/\/t.co\/GPczzxgPUR",
  "id" : 625951220784627712,
  "created_at" : "2015-07-28 08:49:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Burnett",
      "screen_name" : "garwboy",
      "indices" : [ 3, 11 ],
      "id_str" : "20474878",
      "id" : 20474878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/wokcOTsxlv",
      "expanded_url" : "http:\/\/gu.com\/p\/4b34m\/stw",
      "display_url" : "gu.com\/p\/4b34m\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "625941218141315072",
  "text" : "RT @garwboy: Six (scientifically approved) tips to make your man fall for you http:\/\/t.co\/wokcOTsxlv I try to write for Glamour magazine. I\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/wokcOTsxlv",
        "expanded_url" : "http:\/\/gu.com\/p\/4b34m\/stw",
        "display_url" : "gu.com\/p\/4b34m\/stw"
      } ]
    },
    "geo" : { },
    "id_str" : "625914257180356608",
    "text" : "Six (scientifically approved) tips to make your man fall for you http:\/\/t.co\/wokcOTsxlv I try to write for Glamour magazine. It's awful.",
    "id" : 625914257180356608,
    "created_at" : "2015-07-28 06:22:42 +0000",
    "user" : {
      "name" : "Dean Burnett",
      "screen_name" : "garwboy",
      "protected" : false,
      "id_str" : "20474878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920282732428775424\/uA6CvDqE_normal.jpg",
      "id" : 20474878,
      "verified" : false
    }
  },
  "id" : 625941218141315072,
  "created_at" : "2015-07-28 08:09:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/LckQuFFCJ7",
      "expanded_url" : "http:\/\/lab.dessimoz.org\/blog\/media\/2009\/05\/itol.jpg",
      "display_url" : "lab.dessimoz.org\/blog\/media\/200\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "625939753368686593",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224033876171, 8.627601401433974 ]
  },
  "id_str" : "625940162208526336",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot now i get the reason for the circular tree representations \uD83D\uDC40 http:\/\/t.co\/LckQuFFCJ7",
  "id" : 625940162208526336,
  "in_reply_to_status_id" : 625939753368686593,
  "created_at" : "2015-07-28 08:05:38 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625937889378045952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722518875855, 8.627599144543938 ]
  },
  "id_str" : "625938872606806016",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83C\uDF32\uD83C\uDF69?",
  "id" : 625938872606806016,
  "in_reply_to_status_id" : 625937889378045952,
  "created_at" : "2015-07-28 08:00:31 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/MnC5KvAOaO",
      "expanded_url" : "https:\/\/twitter.com\/radaniba\/status\/625936090965385216",
      "display_url" : "twitter.com\/radaniba\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722518875855, 8.627599144543938 ]
  },
  "id_str" : "625938750812594176",
  "text" : "\u00ABThe fact that data science exists as a field is a colossal failure of statistics\u00BB https:\/\/t.co\/MnC5KvAOaO",
  "id" : 625938750812594176,
  "created_at" : "2015-07-28 08:00:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625934913343221760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222929177385, 8.627624924876198 ]
  },
  "id_str" : "625936501059231744",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ich finde den tree of life immer noch sch\u00F6ner f\u00FCr die rosette :3",
  "id" : 625936501059231744,
  "in_reply_to_status_id" : 625934913343221760,
  "created_at" : "2015-07-28 07:51:05 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/mOdjgCGDde",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371\/journal.pbio.1002206",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223552204683, 8.62761005882289 ]
  },
  "id_str" : "625934682820091904",
  "text" : "Let's Make Gender Diversity in Data Science a Priority Right from the Start http:\/\/t.co\/mOdjgCGDde",
  "id" : 625934682820091904,
  "created_at" : "2015-07-28 07:43:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/YlSmyU1VQ7",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/07\/27\/pequod-whale-game.html",
      "display_url" : "boingboing.net\/2015\/07\/27\/peq\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224489326462, 8.627611454335996 ]
  },
  "id_str" : "625932827079655424",
  "text" : "Great sales pitch: \u00ABDid you enjoy Ecco the Dolphin, but wish it had allowed you to commit mass murder?\u00BB http:\/\/t.co\/YlSmyU1VQ7",
  "id" : 625932827079655424,
  "created_at" : "2015-07-28 07:36:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Zimmerman",
      "screen_name" : "j_zimms",
      "indices" : [ 3, 11 ],
      "id_str" : "14714760",
      "id" : 14714760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/q1ajVnRSOb",
      "expanded_url" : "http:\/\/harpers.org\/archive\/2014\/10\/cassandra-among-the-creeps\/",
      "display_url" : "harpers.org\/archive\/2014\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "625775554546024448",
  "text" : "RT @j_zimms: Finally read Rebecca Solnit's \"Cassandra Among the Creeps\"; core ideas, brilliantly framed http:\/\/t.co\/q1ajVnRSOb http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/j_zimms\/status\/625767254043545600\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/sDGFCFKzTe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CK8r_pFVEAAjVdR.jpg",
        "id_str" : "625767245587746816",
        "id" : 625767245587746816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK8r_pFVEAAjVdR.jpg",
        "sizes" : [ {
          "h" : 983,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 983,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 983,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 443
        } ],
        "display_url" : "pic.twitter.com\/sDGFCFKzTe"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/j_zimms\/status\/625767254043545600\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/sDGFCFKzTe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CK8r_pQUsAA1aGT.jpg",
        "id_str" : "625767245633859584",
        "id" : 625767245633859584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK8r_pQUsAA1aGT.jpg",
        "sizes" : [ {
          "h" : 701,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 701,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 701,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 621
        } ],
        "display_url" : "pic.twitter.com\/sDGFCFKzTe"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/q1ajVnRSOb",
        "expanded_url" : "http:\/\/harpers.org\/archive\/2014\/10\/cassandra-among-the-creeps\/",
        "display_url" : "harpers.org\/archive\/2014\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "625767254043545600",
    "text" : "Finally read Rebecca Solnit's \"Cassandra Among the Creeps\"; core ideas, brilliantly framed http:\/\/t.co\/q1ajVnRSOb http:\/\/t.co\/sDGFCFKzTe",
    "id" : 625767254043545600,
    "created_at" : "2015-07-27 20:38:34 +0000",
    "user" : {
      "name" : "Jess Zimmerman",
      "screen_name" : "j_zimms",
      "protected" : false,
      "id_str" : "14714760",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/869618972999680000\/fC9mWoiv_normal.jpg",
      "id" : 14714760,
      "verified" : true
    }
  },
  "id" : 625775554546024448,
  "created_at" : "2015-07-27 21:11:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 10, 26 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625721912237228032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11385415219712, 8.754115076743767 ]
  },
  "id_str" : "625724842550120448",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam @pathogenomenick ok, now I really want to come too!",
  "id" : 625724842550120448,
  "in_reply_to_status_id" : 625721912237228032,
  "created_at" : "2015-07-27 17:50:02 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 103, 112 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/9lJLyLKN1C",
      "expanded_url" : "https:\/\/twitter.com\/SynFutures\/status\/625682742240538624",
      "display_url" : "twitter.com\/SynFutures\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "625684364098191360",
  "text" : "\u00ABByzantine and Mayan and Post-Modern and even a little bit of Memphis, just mash it all together.\u00BB \/cc @JP_Stich  https:\/\/t.co\/9lJLyLKN1C",
  "id" : 625684364098191360,
  "created_at" : "2015-07-27 15:09:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/s6fJsgM2Cp",
      "expanded_url" : "http:\/\/takehomemessage.com\/post\/122652416760\/2-aacgagagtacagaggac",
      "display_url" : "takehomemessage.com\/post\/122652416\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223820061904, 8.627608409150206 ]
  },
  "id_str" : "625677961728012288",
  "text" : "why aphids are really cool: http:\/\/t.co\/s6fJsgM2Cp",
  "id" : 625677961728012288,
  "created_at" : "2015-07-27 14:43:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "ginatrapani",
      "indices" : [ 3, 15 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ginatrapani\/status\/624405885025185792\/photo\/1",
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/YCWvXSeVev",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKpV1xYUsAAUOPi.jpg",
      "id_str" : "624405880621019136",
      "id" : 624405880621019136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKpV1xYUsAAUOPi.jpg",
      "sizes" : [ {
        "h" : 1649,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 931
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 528
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1649,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/YCWvXSeVev"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/GF0LcMGSRa",
      "expanded_url" : "http:\/\/annfriedman.com\/post\/49152967734\/in-my-ongoing-quest-for-the-perfect-framework-for",
      "display_url" : "annfriedman.com\/post\/491529677\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "625669217044570113",
  "text" : "RT @ginatrapani: &lt;3 this disapproval matrix. Understand the criticism before you consider it http:\/\/t.co\/GF0LcMGSRa http:\/\/t.co\/YCWvXSeVev",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ginatrapani\/status\/624405885025185792\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/YCWvXSeVev",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKpV1xYUsAAUOPi.jpg",
        "id_str" : "624405880621019136",
        "id" : 624405880621019136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKpV1xYUsAAUOPi.jpg",
        "sizes" : [ {
          "h" : 1649,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 931
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 528
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1649,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/YCWvXSeVev"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/GF0LcMGSRa",
        "expanded_url" : "http:\/\/annfriedman.com\/post\/49152967734\/in-my-ongoing-quest-for-the-perfect-framework-for",
        "display_url" : "annfriedman.com\/post\/491529677\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "624405362586816513",
    "geo" : { },
    "id_str" : "624405885025185792",
    "in_reply_to_user_id" : 930061,
    "text" : "&lt;3 this disapproval matrix. Understand the criticism before you consider it http:\/\/t.co\/GF0LcMGSRa http:\/\/t.co\/YCWvXSeVev",
    "id" : 624405885025185792,
    "in_reply_to_status_id" : 624405362586816513,
    "created_at" : "2015-07-24 02:28:58 +0000",
    "in_reply_to_screen_name" : "ginatrapani",
    "in_reply_to_user_id_str" : "930061",
    "user" : {
      "name" : "Gina Trapani \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "ginatrapani",
      "protected" : false,
      "id_str" : "930061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550825678673682432\/YRqb4FJE_normal.png",
      "id" : 930061,
      "verified" : true
    }
  },
  "id" : 625669217044570113,
  "created_at" : "2015-07-27 14:09:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625631534444322816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17250469824374, 8.627499847221697 ]
  },
  "id_str" : "625638385391128576",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot yes, I\u2019m sure she's also playing pj harvey in that case. ;)",
  "id" : 625638385391128576,
  "in_reply_to_status_id" : 625631534444322816,
  "created_at" : "2015-07-27 12:06:29 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/nIkSoHA66r",
      "expanded_url" : "https:\/\/www.biosharing.org\/biodbcore-000691",
      "display_url" : "biosharing.org\/biodbcore-0006\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224169152205, 8.62760689011318 ]
  },
  "id_str" : "625620442154430464",
  "text" : "Just added openSNP to the @biosharing repo https:\/\/t.co\/nIkSoHA66r",
  "id" : 625620442154430464,
  "created_at" : "2015-07-27 10:55:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625608708828041216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17161661965586, 8.632078714344187 ]
  },
  "id_str" : "625612669769383936",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u05D0\u05E0\u05D9 \u05DC\u05D0 \u05D9\u05D5\u05D3\u05E2 \u05DE\u05D4 \u05D0\u05EA \u05DB\u05D5\u05EA\u05D1",
  "id" : 625612669769383936,
  "in_reply_to_status_id" : 625608708828041216,
  "created_at" : "2015-07-27 10:24:18 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625605648290578432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226241931544, 8.627590693805978 ]
  },
  "id_str" : "625607198945755136",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot auch dann h\u00E4tte ich es retweetet und w\u00E4re impressed gewesen von deinen Sprachskills. Wobei, du bist ja auch Linguistin :D",
  "id" : 625607198945755136,
  "in_reply_to_status_id" : 625605648290578432,
  "created_at" : "2015-07-27 10:02:34 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 94, 110 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/WHGNkWikqc",
      "expanded_url" : "http:\/\/twee-q.com\/index.php",
      "display_url" : "twee-q.com\/index.php"
    } ]
  },
  "geo" : { },
  "id_str" : "625606060187996160",
  "text" : "RT @Lobot: Gender ratio of my retweets: 63% \/ 37%. Way to improve! http:\/\/t.co\/WHGNkWikqc via @gedankenstuecke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 83, 99 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/WHGNkWikqc",
        "expanded_url" : "http:\/\/twee-q.com\/index.php",
        "display_url" : "twee-q.com\/index.php"
      } ]
    },
    "geo" : { },
    "id_str" : "625605481751531520",
    "text" : "Gender ratio of my retweets: 63% \/ 37%. Way to improve! http:\/\/t.co\/WHGNkWikqc via @gedankenstuecke",
    "id" : 625605481751531520,
    "created_at" : "2015-07-27 09:55:44 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 625606060187996160,
  "created_at" : "2015-07-27 09:58:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625605524025921536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226241931544, 8.627590693805978 ]
  },
  "id_str" : "625606040311214080",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Takk! :p",
  "id" : 625606040311214080,
  "in_reply_to_status_id" : 625605524025921536,
  "created_at" : "2015-07-27 09:57:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 9, 15 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625603908900102145",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222879874198, 8.627617763970393 ]
  },
  "id_str" : "625604182318444544",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil @Lobot wenn ich nichts \u00FCbersehen habe beim schnellen Durchscrollen sind\u2019s 6 RTs in den letzten 12 Tagen f\u00FCr dich.",
  "id" : 625604182318444544,
  "in_reply_to_status_id" : 625603908900102145,
  "created_at" : "2015-07-27 09:50:34 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 9, 15 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625603615718293504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222879874198, 8.627617763970393 ]
  },
  "id_str" : "625603748224700416",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil @Lobot da steht zumindest die Anzahl der RTs die sie benutzen.",
  "id" : 625603748224700416,
  "in_reply_to_status_id" : 625603615718293504,
  "created_at" : "2015-07-27 09:48:51 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625601637944573952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227398952779, 8.627590977852769 ]
  },
  "id_str" : "625603181985329152",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot h\u00E4ttest du es mal in einer universelleren Sprache getwittert h\u00E4tte ich es retweeten k\u00F6nnen ;)",
  "id" : 625603181985329152,
  "in_reply_to_status_id" : 625601637944573952,
  "created_at" : "2015-07-27 09:46:36 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625598094734921728",
  "text" : "RT @bella_velo: Using Algorithms to Determine Character - your test score &amp; where you went to college can now determine your loan  http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/9UamrDgTG0",
        "expanded_url" : "http:\/\/mobile.nytimes.com\/blogs\/bits\/2015\/07\/26\/using-algorithms-to-determine-character\/?referrer=",
        "display_url" : "mobile.nytimes.com\/blogs\/bits\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "625556135349719040",
    "text" : "Using Algorithms to Determine Character - your test score &amp; where you went to college can now determine your loan  http:\/\/t.co\/9UamrDgTG0",
    "id" : 625556135349719040,
    "created_at" : "2015-07-27 06:39:39 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 625598094734921728,
  "created_at" : "2015-07-27 09:26:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/adgZTll3lm",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/opensnp_paper\/blob\/master\/paper_draft.tex",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "625593276725362688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230544923894, 8.62757145759672 ]
  },
  "id_str" : "625593531785216000",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon yes, even the journals that do offer tex templates have sucky ones, see our opensnp manuscript https:\/\/t.co\/adgZTll3lm",
  "id" : 625593531785216000,
  "in_reply_to_status_id" : 625593276725362688,
  "created_at" : "2015-07-27 09:08:15 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224586745866, 8.62760704436674 ]
  },
  "id_str" : "625592360597065728",
  "text" : "Pasting perfectly good vector graphs into docx\u2026 Academic publishing is broken beyond repair. \uD83D\uDE2D",
  "id" : 625592360597065728,
  "created_at" : "2015-07-27 09:03:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625578033227952128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223264005582, 8.627609378018054 ]
  },
  "id_str" : "625579859402694656",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Wie viel Urlaubstage hast du noch? \uD83D\uDE97\u2708\uFE0F\u26F5\uFE0F",
  "id" : 625579859402694656,
  "in_reply_to_status_id" : 625578033227952128,
  "created_at" : "2015-07-27 08:13:55 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/iAuafzLL0N",
      "expanded_url" : "https:\/\/twitter.com\/wordspinster\/status\/625329549946023936",
      "display_url" : "twitter.com\/wordspinster\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224284803272, 8.6276117204533 ]
  },
  "id_str" : "625556731662348288",
  "text" : "\u00ABTelling women their habits of speech are bad and wrong is not going to make them more confident speakers\u00BB https:\/\/t.co\/iAuafzLL0N",
  "id" : 625556731662348288,
  "created_at" : "2015-07-27 06:42:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/0h5M1sKR2h",
      "expanded_url" : "http:\/\/fivethirtyeight.com\/features\/stop-trying-to-be-creative\/",
      "display_url" : "fivethirtyeight.com\/features\/stop-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403276479793, 8.75333634281242 ]
  },
  "id_str" : "625426145920610305",
  "text" : "Jumping around in the creative fitness landscape: Stop Trying To Be Creative http:\/\/t.co\/0h5M1sKR2h",
  "id" : 625426145920610305,
  "created_at" : "2015-07-26 22:03:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/BCyjBoSpmp",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/7\/26\/9036993\/meme-font-impact",
      "display_url" : "vox.com\/2015\/7\/26\/9036\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403009526315, 8.75333694673875 ]
  },
  "id_str" : "625412372015001600",
  "text" : "Impact: The reason every meme uses that one\u00A0font http:\/\/t.co\/BCyjBoSpmp",
  "id" : 625412372015001600,
  "created_at" : "2015-07-26 21:08:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400064096924, 8.753270268565567 ]
  },
  "id_str" : "625387321597263876",
  "text" : "Important lessons learnt from scouts: question authority; stand up for others; how satisfying a cold drink while taking a hot shower is.",
  "id" : 625387321597263876,
  "created_at" : "2015-07-26 19:28:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625383081994682368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140085710736, 8.753263126707997 ]
  },
  "id_str" : "625383659558801409",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam to be fair: deep fried Mars bars are an invention by the scots.",
  "id" : 625383659558801409,
  "in_reply_to_status_id" : 625383081994682368,
  "created_at" : "2015-07-26 19:14:18 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/vCVgx2fCTK",
      "expanded_url" : "https:\/\/events.ccc.de\/camp\/2015\/wiki\/Village:Queer_Feminist_Geeks",
      "display_url" : "events.ccc.de\/camp\/2015\/wiki\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "625379625691152384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10728577247077, 8.766922935527067 ]
  },
  "id_str" : "625380178944991232",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer yes, more or less just came out of the planning meeting for https:\/\/t.co\/vCVgx2fCTK",
  "id" : 625380178944991232,
  "in_reply_to_status_id" : 625379625691152384,
  "created_at" : "2015-07-26 19:00:28 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/i9HL56Xtfu",
      "expanded_url" : "https:\/\/instagram.com\/p\/5m_YV0hwuV\/",
      "display_url" : "instagram.com\/p\/5m_YV0hwuV\/"
    } ]
  },
  "geo" : { },
  "id_str" : "625370363703259136",
  "text" : "wholly hole https:\/\/t.co\/i9HL56Xtfu",
  "id" : 625370363703259136,
  "created_at" : "2015-07-26 18:21:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/2IUGOEqCKj",
      "expanded_url" : "https:\/\/instagram.com\/p\/5mzmIUhwvq\/",
      "display_url" : "instagram.com\/p\/5mzmIUhwvq\/"
    } ]
  },
  "geo" : { },
  "id_str" : "625344448952696833",
  "text" : "Polypore https:\/\/t.co\/2IUGOEqCKj",
  "id" : 625344448952696833,
  "created_at" : "2015-07-26 16:38:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/u5R1OQYzga",
      "expanded_url" : "https:\/\/instagram.com\/p\/5mydBahwsi\/",
      "display_url" : "instagram.com\/p\/5mydBahwsi\/"
    } ]
  },
  "geo" : { },
  "id_str" : "625341937613189121",
  "text" : "Prep https:\/\/t.co\/u5R1OQYzga",
  "id" : 625341937613189121,
  "created_at" : "2015-07-26 16:28:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    }, {
      "name" : "Dan Savage",
      "screen_name" : "fakedansavage",
      "indices" : [ 88, 102 ],
      "id_str" : "313091751",
      "id" : 313091751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625303741160407040",
  "text" : "RT @JBYoder: On behalf of evolutionary biologists\/pedants everywhere, I\u2019d like to thank @fakedansavage for these footnotes. http:\/\/t.co\/raF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dan Savage",
        "screen_name" : "fakedansavage",
        "indices" : [ 75, 89 ],
        "id_str" : "313091751",
        "id" : 313091751
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/raFu852Lzs",
        "expanded_url" : "http:\/\/www.thestranger.com\/blogs\/slog\/2015\/07\/25\/22601295\/did-anyone-make-it-to-the-straight-pride-parade-today",
        "display_url" : "thestranger.com\/blogs\/slog\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "625277361446125568",
    "text" : "On behalf of evolutionary biologists\/pedants everywhere, I\u2019d like to thank @fakedansavage for these footnotes. http:\/\/t.co\/raFu852Lzs",
    "id" : 625277361446125568,
    "created_at" : "2015-07-26 12:11:54 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 625303741160407040,
  "created_at" : "2015-07-26 13:56:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625227986334150656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393727217095, 8.753330470527223 ]
  },
  "id_str" : "625266941100433408",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch should have come in a day early. :D",
  "id" : 625266941100433408,
  "in_reply_to_status_id" : 625227986334150656,
  "created_at" : "2015-07-26 11:30:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/8niva1au0f",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/srgRw3fu-5M\/if-phones-were-designed-to-ple.html",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "625230425007505408",
  "text" : "If phones were designed to please their owners, rather than corporations http:\/\/t.co\/8niva1au0f",
  "id" : 625230425007505408,
  "created_at" : "2015-07-26 09:05:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Revkin",
      "screen_name" : "Revkin",
      "indices" : [ 3, 10 ],
      "id_str" : "11178672",
      "id" : 11178672
    }, {
      "name" : "Oliver Sacks Fdn.",
      "screen_name" : "OliverSacks",
      "indices" : [ 19, 31 ],
      "id_str" : "52488565",
      "id" : 52488565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625223177623478272",
  "text" : "RT @Revkin: Thanks @OliverSacks for devoting some of your waning energy to another marvelous missive on the dying part of living. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oliver Sacks Fdn.",
        "screen_name" : "OliverSacks",
        "indices" : [ 7, 19 ],
        "id_str" : "52488565",
        "id" : 52488565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ppPpKbUjQh",
        "expanded_url" : "http:\/\/nyti.ms\/1VEZ54U",
        "display_url" : "nyti.ms\/1VEZ54U"
      } ]
    },
    "geo" : { },
    "id_str" : "624582903738036225",
    "text" : "Thanks @OliverSacks for devoting some of your waning energy to another marvelous missive on the dying part of living. http:\/\/t.co\/ppPpKbUjQh",
    "id" : 624582903738036225,
    "created_at" : "2015-07-24 14:12:23 +0000",
    "user" : {
      "name" : "Andy Revkin",
      "screen_name" : "Revkin",
      "protected" : false,
      "id_str" : "11178672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/814962508553338881\/CSyqEYu2_normal.jpg",
      "id" : 11178672,
      "verified" : true
    }
  },
  "id" : 625223177623478272,
  "created_at" : "2015-07-26 08:36:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625089206755274753",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11410080268404, 8.753247529994567 ]
  },
  "id_str" : "625217001481482240",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch sweet! Congratz!",
  "id" : 625217001481482240,
  "in_reply_to_status_id" : 625089206755274753,
  "created_at" : "2015-07-26 08:12:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/b5gFqWnlY8",
      "expanded_url" : "https:\/\/twitter.com\/FilthyRichmond\/status\/624670832879665152",
      "display_url" : "twitter.com\/FilthyRichmond\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402600254856, 8.753344990148982 ]
  },
  "id_str" : "625070191676903424",
  "text" : "Misread this as \u2018genius grant\u2019 https:\/\/t.co\/b5gFqWnlY8",
  "id" : 625070191676903424,
  "created_at" : "2015-07-25 22:28:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "michael_nielsen",
      "screen_name" : "michael_nielsen",
      "indices" : [ 13, 29 ],
      "id_str" : "15626406",
      "id" : 15626406
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 30, 40 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624972731889520640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11391188927306, 8.75333783777407 ]
  },
  "id_str" : "625069986948714496",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown @michael_nielsen @biocrusoe worked pretty well! Also: questions via Twitter is great.",
  "id" : 625069986948714496,
  "in_reply_to_status_id" : 624972731889520640,
  "created_at" : "2015-07-25 22:27:52 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 45, 55 ],
      "id_str" : "347340056",
      "id" : 347340056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/V0iWqWkUZ1",
      "expanded_url" : "https:\/\/twitter.com\/_medusa_cascade\/status\/624914026343104512",
      "display_url" : "twitter.com\/_medusa_cascad\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "624948126881849344",
  "geo" : { },
  "id_str" : "625031628071567360",
  "in_reply_to_user_id" : 347340056,
  "text" : "My gender role: Questioning Queerdo Queen RT @vortacist: Ooh! I got \u201CGenderfluid leather otter\u201D! https:\/\/t.co\/V0iWqWkUZ1",
  "id" : 625031628071567360,
  "in_reply_to_status_id" : 624948126881849344,
  "created_at" : "2015-07-25 19:55:27 +0000",
  "in_reply_to_screen_name" : "vortacist",
  "in_reply_to_user_id_str" : "347340056",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10491087980078, 8.759520816970916 ]
  },
  "id_str" : "624879262454181888",
  "text" : "2 more weeks with badly taped glasses \uD83D\uDE15",
  "id" : 624879262454181888,
  "created_at" : "2015-07-25 09:50:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 10, 19 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624869071117512704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10483091684708, 8.760855114848933 ]
  },
  "id_str" : "624873448733544448",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @open_con for old open-activist-times sake? ;)",
  "id" : 624873448733544448,
  "in_reply_to_status_id" : 624869071117512704,
  "created_at" : "2015-07-25 09:26:54 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 10, 19 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624847805484519424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10737215904842, 8.773759513606187 ]
  },
  "id_str" : "624848111337406464",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @open_con do you have a place to crash? ;)",
  "id" : 624848111337406464,
  "in_reply_to_status_id" : 624847805484519424,
  "created_at" : "2015-07-25 07:46:13 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624728889256988672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10735458113439, 8.77360940073863 ]
  },
  "id_str" : "624842369637220352",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye agree, I remember before they offered the archives I even tried and never heard back from them!",
  "id" : 624842369637220352,
  "in_reply_to_status_id" : 624728889256988672,
  "created_at" : "2015-07-25 07:23:24 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 10, 23 ],
      "id_str" : "478181304",
      "id" : 478181304
    }, {
      "name" : "Opencondomstyle",
      "screen_name" : "Opencon",
      "indices" : [ 24, 32 ],
      "id_str" : "1112318161",
      "id" : 1112318161
    }, {
      "name" : "@npettiaux@mamot.fr",
      "screen_name" : "npettiaux",
      "indices" : [ 33, 43 ],
      "id_str" : "21497527",
      "id" : 21497527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624744337155473408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10707265059528, 8.772019824737018 ]
  },
  "id_str" : "624842220147998720",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @Mcarthur_Joe @Opencon @npettiaux hope we find some time then :)",
  "id" : 624842220147998720,
  "in_reply_to_status_id" : 624744337155473408,
  "created_at" : "2015-07-25 07:22:48 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 40, 49 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 63, 72 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407846323628, 8.753345296157498 ]
  },
  "id_str" : "624834501194194944",
  "text" : "Looks like I will get a chance to visit @open_con this year. \/\/@Senficon",
  "id" : 624834501194194944,
  "created_at" : "2015-07-25 06:52:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/624727309535289344\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/BENblt262Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKt6LTuWUAA1ZnF.png",
      "id_str" : "624727308012769280",
      "id" : 624727308012769280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKt6LTuWUAA1ZnF.png",
      "sizes" : [ {
        "h" : 564,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 564,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 564,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/BENblt262Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/DV1FWSKUlX",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/geolocations",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "624696654311071744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402969068637, 8.753332284630293 ]
  },
  "id_str" : "624727309535289344",
  "in_reply_to_user_id" : 14286491,
  "text" : "Starts to turn heatmapish. Code for plotting w\/ ggplot2 + example data now avail as well https:\/\/t.co\/DV1FWSKUlX http:\/\/t.co\/BENblt262Q",
  "id" : 624727309535289344,
  "in_reply_to_status_id" : 624696654311071744,
  "created_at" : "2015-07-24 23:46:12 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624700247843934208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403114271103, 8.753333068921323 ]
  },
  "id_str" : "624723986195329025",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye you could make them give you all your data? :)",
  "id" : 624723986195329025,
  "in_reply_to_status_id" : 624700247843934208,
  "created_at" : "2015-07-24 23:32:59 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624697186811559940",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403043427384, 8.7533326833626 ]
  },
  "id_str" : "624697566798725120",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye is there a way to \u201Cprivately\u201D share location w\/ twitter? in any case: it takes whatever is in location-field of your archive :)",
  "id" : 624697566798725120,
  "in_reply_to_status_id" : 624697186811559940,
  "created_at" : "2015-07-24 21:48:00 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 76, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/DV1FWSKUlX",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/geolocations",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "618743820390416384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402723123415, 8.753332790628 ]
  },
  "id_str" : "624696654311071744",
  "in_reply_to_user_id" : 14286491,
  "text" : "Starting to gather some scripts for export\/viz of personal geolocation data #quantifiedself https:\/\/t.co\/DV1FWSKUlX",
  "id" : 624696654311071744,
  "in_reply_to_status_id" : 618743820390416384,
  "created_at" : "2015-07-24 21:44:23 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/yfLHfXgdXf",
      "expanded_url" : "http:\/\/simplystatistics.org\/2015\/07\/24\/stringsasfactors-an-unauthorized-biography\/",
      "display_url" : "simplystatistics.org\/2015\/07\/24\/str\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222433852053, 8.627607162799109 ]
  },
  "id_str" : "624623747048284160",
  "text" : "stringsAsFactors: An unauthorized biography http:\/\/t.co\/yfLHfXgdXf",
  "id" : 624623747048284160,
  "created_at" : "2015-07-24 16:54:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/DL7RV0dWTI",
      "expanded_url" : "http:\/\/journals.plos.org\/ploscompbiol\/article?id=10.1371\/journal.pcbi.1004365",
      "display_url" : "journals.plos.org\/ploscompbiol\/a\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222433852053, 8.627607162799109 ]
  },
  "id_str" : "624621789654618112",
  "text" : "Neutral Models of Microbiome Evolution http:\/\/t.co\/DL7RV0dWTI",
  "id" : 624621789654618112,
  "created_at" : "2015-07-24 16:46:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Moore",
      "screen_name" : "peromhc",
      "indices" : [ 0, 8 ],
      "id_str" : "4302347242",
      "id" : 4302347242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624615957130948609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223965385591, 8.627610763644132 ]
  },
  "id_str" : "624616221585977346",
  "in_reply_to_user_id" : 11824072,
  "text" : "@PeroMHC yes, could also have been CroissantKmeans.",
  "id" : 624616221585977346,
  "in_reply_to_status_id" : 624615957130948609,
  "created_at" : "2015-07-24 16:24:46 +0000",
  "in_reply_to_screen_name" : "macmanes",
  "in_reply_to_user_id_str" : "11824072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Moore",
      "screen_name" : "peromhc",
      "indices" : [ 0, 8 ],
      "id_str" : "4302347242",
      "id" : 4302347242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624615380879695872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223965385591, 8.627610763644132 ]
  },
  "id_str" : "624615832153264128",
  "in_reply_to_user_id" : 11824072,
  "text" : "@PeroMHC in the kitchen during coffee breaks ;)",
  "id" : 624615832153264128,
  "in_reply_to_status_id" : 624615380879695872,
  "created_at" : "2015-07-24 16:23:13 +0000",
  "in_reply_to_screen_name" : "macmanes",
  "in_reply_to_user_id_str" : "11824072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Chris Ball",
      "screen_name" : "cjbprime",
      "indices" : [ 10, 19 ],
      "id_str" : "41779829",
      "id" : 41779829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624548402899120129",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722769948972, 8.627614527807426 ]
  },
  "id_str" : "624580040194396160",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @cjbprime a well done pair programming exercise! Congratulations!",
  "id" : 624580040194396160,
  "in_reply_to_status_id" : 624548402899120129,
  "created_at" : "2015-07-24 14:01:00 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/0T8rXI2zwC",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/arts\/culturebox\/2015\/07\/bob_dylan_at_newport_dylan_goes_electric_by_elijah_wald_reviewed.html",
      "display_url" : "slate.com\/articles\/arts\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230941750905, 8.627568854962378 ]
  },
  "id_str" : "624566425273896960",
  "text" : "To true fans this must seem like a logical progression: US Civil War, World War I, The Night Dylan went Electric. http:\/\/t.co\/0T8rXI2zwC",
  "id" : 624566425273896960,
  "created_at" : "2015-07-24 13:06:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624557610839224320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228375937185, 8.62757436327396 ]
  },
  "id_str" : "624559167639060480",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler danke!",
  "id" : 624559167639060480,
  "in_reply_to_status_id" : 624557610839224320,
  "created_at" : "2015-07-24 12:38:03 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624522103723851776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226999580582, 8.62759090923971 ]
  },
  "id_str" : "624554357984481280",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler naja, um jetzt Fehlermodelle erstellen zu k\u00F6nnen stelle ich mir das ganz praktisch vor. Aber ich hab noch nie SCS betrieben. :)",
  "id" : 624554357984481280,
  "in_reply_to_status_id" : 624522103723851776,
  "created_at" : "2015-07-24 12:18:57 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624537228132360192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222175840715, 8.627620417666005 ]
  },
  "id_str" : "624537381975273472",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer I will be there :)",
  "id" : 624537381975273472,
  "in_reply_to_status_id" : 624537228132360192,
  "created_at" : "2015-07-24 11:11:29 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/CQ66Gz8u3V",
      "expanded_url" : "http:\/\/38.media.tumblr.com\/47780562e77c3dfce73a8612b8cbbfbe\/tumblr_ndmca8WK6j1rp0vkjo1_500.gif",
      "display_url" : "38.media.tumblr.com\/47780562e77c3d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "624506909685600260",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223384419837, 8.62762280812685 ]
  },
  "id_str" : "624508579484200960",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Und ich dachte es geht um http:\/\/t.co\/CQ66Gz8u3V",
  "id" : 624508579484200960,
  "in_reply_to_status_id" : 624506909685600260,
  "created_at" : "2015-07-24 09:17:02 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/STxlmU06NE",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2015\/07\/17\/022731",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220926917597, 8.627641202216457 ]
  },
  "id_str" : "624496890604818436",
  "text" : "What\u2019s in your next-generation sequence data? An exploration of unmapped DNA and RNA sequence reads http:\/\/t.co\/STxlmU06NE",
  "id" : 624496890604818436,
  "created_at" : "2015-07-24 08:30:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624494549616984064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224797864328, 8.627602101659031 ]
  },
  "id_str" : "624495679373754368",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler hier mehr, weil man spiel haben will alle Effekte zu sehen vermute ich?",
  "id" : 624495679373754368,
  "in_reply_to_status_id" : 624494549616984064,
  "created_at" : "2015-07-24 08:25:47 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/RccqeDFsd9",
      "expanded_url" : "http:\/\/nar.oxfordjournals.org\/content\/early\/2015\/07\/17\/nar.gkv717.full",
      "display_url" : "nar.oxfordjournals.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225605049411, 8.627596185686752 ]
  },
  "id_str" : "624490714307686400",
  "text" : "Nice survey: Sources of PCR-induced distortions in high-throughput sequencing data sets http:\/\/t.co\/RccqeDFsd9",
  "id" : 624490714307686400,
  "created_at" : "2015-07-24 08:06:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624482937539559424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225309196411, 8.62760559364504 ]
  },
  "id_str" : "624485348257738752",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin just assume it\u2019s MIT for those cases. ;)",
  "id" : 624485348257738752,
  "in_reply_to_status_id" : 624482937539559424,
  "created_at" : "2015-07-24 07:44:44 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/dF6aIXssaD",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view2\/2054482\/single-tumbleweed-o-gif",
      "display_url" : "stream1.gifsoup.com\/view2\/2054482\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225227214396, 8.627604966742206 ]
  },
  "id_str" : "624481460637036544",
  "text" : "did i miss any public holiday? situation in the office: http:\/\/t.co\/dF6aIXssaD",
  "id" : 624481460637036544,
  "created_at" : "2015-07-24 07:29:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/4oDhrAG1YS",
      "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/624323931067944960",
      "display_url" : "twitter.com\/wilbanks\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222563890763, 8.627620146131921 ]
  },
  "id_str" : "624477681543983104",
  "text" : "Recommended to do it at least twice a day https:\/\/t.co\/4oDhrAG1YS",
  "id" : 624477681543983104,
  "created_at" : "2015-07-24 07:14:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/GnWgDguEdK",
      "expanded_url" : "https:\/\/instagram.com\/p\/5fZ269hwja\/",
      "display_url" : "instagram.com\/p\/5fZ269hwja\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.108111776, 8.766002731 ]
  },
  "id_str" : "624302689204219904",
  "text" : "Hipster shack(les) @ Waggon Am Kulturgleis https:\/\/t.co\/GnWgDguEdK",
  "id" : 624302689204219904,
  "created_at" : "2015-07-23 19:38:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624292975451983872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10710289603132, 8.770179878982779 ]
  },
  "id_str" : "624297923984162816",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk I would love to, but I fear my travel budget won\u2019t allow for it right now. But I could buy some stamps;)",
  "id" : 624297923984162816,
  "in_reply_to_status_id" : 624292975451983872,
  "created_at" : "2015-07-23 19:19:58 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624291334669606912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407738005081, 8.753340977673696 ]
  },
  "id_str" : "624292656974311424",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk omg, i need those stickers :3",
  "id" : 624292656974311424,
  "in_reply_to_status_id" : 624291334669606912,
  "created_at" : "2015-07-23 18:59:02 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 3, 12 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/k24wvk3Dd9",
      "expanded_url" : "https:\/\/twitter.com\/fredtrotter\/status\/624279707459166208",
      "display_url" : "twitter.com\/fredtrotter\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "624281282416123904",
  "text" : "RT @eramirez: Ditto.  https:\/\/t.co\/k24wvk3Dd9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 8, 31 ],
        "url" : "https:\/\/t.co\/k24wvk3Dd9",
        "expanded_url" : "https:\/\/twitter.com\/fredtrotter\/status\/624279707459166208",
        "display_url" : "twitter.com\/fredtrotter\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "624280416539820032",
    "text" : "Ditto.  https:\/\/t.co\/k24wvk3Dd9",
    "id" : 624280416539820032,
    "created_at" : "2015-07-23 18:10:24 +0000",
    "user" : {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "protected" : false,
      "id_str" : "21135674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/866822214267666432\/IYzsQHYG_normal.jpg",
      "id" : 21135674,
      "verified" : false
    }
  },
  "id" : 624281282416123904,
  "created_at" : "2015-07-23 18:13:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225663809712, 8.627583639599127 ]
  },
  "id_str" : "624239891162005504",
  "text" : "Today was such a productive and busy day that I didn\u2019t even find the time to drink coffee. Wait, what?!",
  "id" : 624239891162005504,
  "created_at" : "2015-07-23 15:29:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624201680687656961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225055917998, 8.62759411049905 ]
  },
  "id_str" : "624220882345586688",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia uh, sounds like very remote in one of the worst possible senses\u2026",
  "id" : 624220882345586688,
  "in_reply_to_status_id" : 624201680687656961,
  "created_at" : "2015-07-23 14:13:50 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624168373916684288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221931228853, 8.627612444771556 ]
  },
  "id_str" : "624206103455338496",
  "in_reply_to_user_id" : 14286491,
  "text" : "Now up: \uD83D\uDE31 the \u2018how will I ever get this manuscript accepted\u2019-despair moves. \uD83D\uDE31",
  "id" : 624206103455338496,
  "in_reply_to_status_id" : 624168373916684288,
  "created_at" : "2015-07-23 13:15:06 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Fake Unicode \u2199",
      "screen_name" : "FakeUnicode",
      "indices" : [ 30, 42 ],
      "id_str" : "2183231114",
      "id" : 2183231114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624169279387123712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226314056396, 8.627583537367043 ]
  },
  "id_str" : "624172652358430720",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski time for the @FakeUnicode to kick in!",
  "id" : 624172652358430720,
  "in_reply_to_status_id" : 624169279387123712,
  "created_at" : "2015-07-23 11:02:11 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624168508570497024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240258303985, 8.627550921517647 ]
  },
  "id_str" : "624169152194945024",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski thx, and I hope you are seeing this on a Mac, so you see my fabulous emoji dress. \uD83D\uDC83\uD83C\uDFFD",
  "id" : 624169152194945024,
  "in_reply_to_status_id" : 624168508570497024,
  "created_at" : "2015-07-23 10:48:17 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236652453411, 8.627587219545273 ]
  },
  "id_str" : "624168373916684288",
  "text" : "Paper acceptance dance\uD83D\uDC83\uD83C\uDFFDespecially as this was one of those which took forever!\uD83D\uDC83\uD83C\uDFFD",
  "id" : 624168373916684288,
  "created_at" : "2015-07-23 10:45:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatjana Scheffler",
      "screen_name" : "tschfflr",
      "indices" : [ 0, 9 ],
      "id_str" : "313810815",
      "id" : 313810815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624159019406610432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225107134711, 8.627594045301551 ]
  },
  "id_str" : "624159164277878784",
  "in_reply_to_user_id" : 313810815,
  "text" : "@tschfflr angenommene pull-requests in anderen Projekten bleiben immer gro\u00DFartig glaube ich :)",
  "id" : 624159164277878784,
  "in_reply_to_status_id" : 624159019406610432,
  "created_at" : "2015-07-23 10:08:35 +0000",
  "in_reply_to_screen_name" : "tschfflr",
  "in_reply_to_user_id_str" : "313810815",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatjana Scheffler",
      "screen_name" : "tschfflr",
      "indices" : [ 0, 9 ],
      "id_str" : "313810815",
      "id" : 313810815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624156628460417024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225107134711, 8.627594045301551 ]
  },
  "id_str" : "624158764703293440",
  "in_reply_to_user_id" : 313810815,
  "text" : "@tschfflr \uD83D\uDC90congrats!",
  "id" : 624158764703293440,
  "in_reply_to_status_id" : 624156628460417024,
  "created_at" : "2015-07-23 10:07:00 +0000",
  "in_reply_to_screen_name" : "tschfflr",
  "in_reply_to_user_id_str" : "313810815",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/mtP63MX6jR",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/bengoldacre\/deworming-trials",
      "display_url" : "buzzfeed.com\/bengoldacre\/de\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225764902385, 8.627594526505119 ]
  },
  "id_str" : "624105240145604608",
  "text" : "\u00ABIt\u2019s not just naive to expect that all research will be perfectly free from errors, it\u2019s actively harmful.\u00BB http:\/\/t.co\/mtP63MX6jR",
  "id" : 624105240145604608,
  "created_at" : "2015-07-23 06:34:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 3, 13 ],
      "id_str" : "347340056",
      "id" : 347340056
    }, {
      "name" : "Everyday Feminism",
      "screen_name" : "EvrydayFeminism",
      "indices" : [ 37, 53 ],
      "id_str" : "591920938",
      "id" : 591920938
    }, {
      "name" : "Maisha Z. Johnson",
      "screen_name" : "mzjwords",
      "indices" : [ 107, 116 ],
      "id_str" : "24132614",
      "id" : 24132614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/s72ZOraJmc",
      "expanded_url" : "http:\/\/everydayfeminism.com\/2015\/07\/what-privilege-really-means\/",
      "display_url" : "everydayfeminism.com\/2015\/07\/what-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "623984095907987457",
  "text" : "RT @vortacist: Another home run from @EvrydayFeminism: \"What Privilege Really Means (And Doesn\u2019t Mean)\" by @mzjwords http:\/\/t.co\/s72ZOraJmc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Everyday Feminism",
        "screen_name" : "EvrydayFeminism",
        "indices" : [ 22, 38 ],
        "id_str" : "591920938",
        "id" : 591920938
      }, {
        "name" : "Maisha Z. Johnson",
        "screen_name" : "mzjwords",
        "indices" : [ 92, 101 ],
        "id_str" : "24132614",
        "id" : 24132614
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/s72ZOraJmc",
        "expanded_url" : "http:\/\/everydayfeminism.com\/2015\/07\/what-privilege-really-means\/",
        "display_url" : "everydayfeminism.com\/2015\/07\/what-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "623982036332748800",
    "text" : "Another home run from @EvrydayFeminism: \"What Privilege Really Means (And Doesn\u2019t Mean)\" by @mzjwords http:\/\/t.co\/s72ZOraJmc",
    "id" : 623982036332748800,
    "created_at" : "2015-07-22 22:24:45 +0000",
    "user" : {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "protected" : false,
      "id_str" : "347340056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819220259148177408\/UYT71cyh_normal.jpg",
      "id" : 347340056,
      "verified" : false
    }
  },
  "id" : 623984095907987457,
  "created_at" : "2015-07-22 22:32:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Khomenko",
      "screen_name" : "akhomenko",
      "indices" : [ 0, 10 ],
      "id_str" : "46498656",
      "id" : 46498656
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 11, 25 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 26, 35 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623957137123856385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400735762535, 8.753264409725217 ]
  },
  "id_str" : "623957680605020160",
  "in_reply_to_user_id" : 46498656,
  "text" : "@akhomenko @beaugunderson @wilbanks I remember this being a problem when we got a Wikimedia grant to get underrepresented groups genotyped.",
  "id" : 623957680605020160,
  "in_reply_to_status_id" : 623957137123856385,
  "created_at" : "2015-07-22 20:47:58 +0000",
  "in_reply_to_screen_name" : "akhomenko",
  "in_reply_to_user_id_str" : "46498656",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Khomenko",
      "screen_name" : "akhomenko",
      "indices" : [ 0, 10 ],
      "id_str" : "46498656",
      "id" : 46498656
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 11, 25 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 26, 35 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623957137123856385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400735762535, 8.753264409725217 ]
  },
  "id_str" : "623957551588208640",
  "in_reply_to_user_id" : 46498656,
  "text" : "@akhomenko @beaugunderson @wilbanks but being able to re-upload own data file requires the privilege of fast enough upload-speeds.",
  "id" : 623957551588208640,
  "in_reply_to_status_id" : 623957137123856385,
  "created_at" : "2015-07-22 20:47:27 +0000",
  "in_reply_to_screen_name" : "akhomenko",
  "in_reply_to_user_id_str" : "46498656",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Khomenko",
      "screen_name" : "akhomenko",
      "indices" : [ 0, 10 ],
      "id_str" : "46498656",
      "id" : 46498656
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 11, 25 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 26, 35 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623957137123856385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400735762535, 8.753264409725217 ]
  },
  "id_str" : "623957331588554752",
  "in_reply_to_user_id" : 46498656,
  "text" : "@akhomenko @beaugunderson @wilbanks not saying it\u2019s unreasonable, fair business decision from them.",
  "id" : 623957331588554752,
  "in_reply_to_status_id" : 623957137123856385,
  "created_at" : "2015-07-22 20:46:35 +0000",
  "in_reply_to_screen_name" : "akhomenko",
  "in_reply_to_user_id_str" : "46498656",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Alex Khomenko",
      "screen_name" : "akhomenko",
      "indices" : [ 15, 25 ],
      "id_str" : "46498656",
      "id" : 46498656
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 26, 35 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623955719847411712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401601785873, 8.753288258673772 ]
  },
  "id_str" : "623956321973477376",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson @akhomenko @wilbanks and tbh: downloading\/reuploading the files is still very painful &amp; far from being easy for many ppl.",
  "id" : 623956321973477376,
  "in_reply_to_status_id" : 623955719847411712,
  "created_at" : "2015-07-22 20:42:34 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400691204526, 8.753264786147838 ]
  },
  "id_str" : "623952970732990468",
  "text" : "you really have to step up your game, geologists: there are literally only two google hits for \u2018continental shelfie\u2019 so far! \uD83C\uDF0A\uD83C\uDF05\uD83D\uDCF7",
  "id" : 623952970732990468,
  "created_at" : "2015-07-22 20:29:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623929622116331521",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401419538341, 8.753290216364393 ]
  },
  "id_str" : "623951217375510528",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83D\uDC40\uD83D\uDC1B",
  "id" : 623951217375510528,
  "in_reply_to_status_id" : 623929622116331521,
  "created_at" : "2015-07-22 20:22:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623945062804811776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400470522679, 8.753266668923382 ]
  },
  "id_str" : "623945245999427584",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson ich \u00FCbernehme gerne Schichten als Hundesitter, von M\u00FCnsterl\u00E4nder zu M\u00FCnsterl\u00E4nderin ;)",
  "id" : 623945245999427584,
  "in_reply_to_status_id" : 623945062804811776,
  "created_at" : "2015-07-22 19:58:33 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623944231460147200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403091893359, 8.753331652726267 ]
  },
  "id_str" : "623944471898640384",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson yay \uD83D\uDC36:)",
  "id" : 623944471898640384,
  "in_reply_to_status_id" : 623944231460147200,
  "created_at" : "2015-07-22 19:55:29 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623943714818420736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403091893359, 8.753331652726267 ]
  },
  "id_str" : "623943997099220996",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson doch, das ist zumindest fest geplant. :)",
  "id" : 623943997099220996,
  "in_reply_to_status_id" : 623943714818420736,
  "created_at" : "2015-07-22 19:53:35 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623943306658099200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402933151653, 8.753332166456255 ]
  },
  "id_str" : "623943544143773696",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson \uD83D\uDC36\uD83D\uDC45",
  "id" : 623943544143773696,
  "in_reply_to_status_id" : 623943306658099200,
  "created_at" : "2015-07-22 19:51:47 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623942297227501568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402933151653, 8.753332166456255 ]
  },
  "id_str" : "623943133810847749",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson diesen Hund m\u00F6chte ich gerne kennenlernen :D",
  "id" : 623943133810847749,
  "in_reply_to_status_id" : 623942297227501568,
  "created_at" : "2015-07-22 19:50:10 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "phryk",
      "screen_name" : "lephryk",
      "indices" : [ 6, 14 ],
      "id_str" : "211820423",
      "id" : 211820423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623941863314096128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402948492476, 8.75333027540926 ]
  },
  "id_str" : "623942576006168576",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a @lephryk hard to tell indeed. then: the demo apparently only accepts white non-Ashkenazi.",
  "id" : 623942576006168576,
  "in_reply_to_status_id" : 623941863314096128,
  "created_at" : "2015-07-22 19:47:57 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623939421021315072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403051671437, 8.753332448300515 ]
  },
  "id_str" : "623940928248639488",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson Viel Gl\u00FCck! :)",
  "id" : 623940928248639488,
  "in_reply_to_status_id" : 623939421021315072,
  "created_at" : "2015-07-22 19:41:24 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phryk",
      "screen_name" : "lephryk",
      "indices" : [ 0, 8 ],
      "id_str" : "211820423",
      "id" : 211820423
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 9, 14 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623938960520314880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140314467667, 8.753328249360717 ]
  },
  "id_str" : "623940424420458496",
  "in_reply_to_user_id" : 211820423,
  "text" : "@lephryk @li5a i hadn\u2019t, but it\u2019s a joke, right? I mean, \u201Coffensive API\u201D?",
  "id" : 623940424420458496,
  "in_reply_to_status_id" : 623938960520314880,
  "created_at" : "2015-07-22 19:39:24 +0000",
  "in_reply_to_screen_name" : "lephryk",
  "in_reply_to_user_id_str" : "211820423",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/mhmwh9lLJd",
      "expanded_url" : "https:\/\/instagram.com\/p\/5czJ3uhwlw\/",
      "display_url" : "instagram.com\/p\/5czJ3uhwlw\/"
    } ]
  },
  "geo" : { },
  "id_str" : "623936103960215552",
  "text" : "~3500 km later and I'm slowly loosing my grip. https:\/\/t.co\/mhmwh9lLJd",
  "id" : 623936103960215552,
  "created_at" : "2015-07-22 19:22:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/uaT7ZpkcKV",
      "expanded_url" : "https:\/\/twitter.com\/existentialcoms\/status\/623931931780997121",
      "display_url" : "twitter.com\/existentialcom\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11116461250788, 8.754290327967684 ]
  },
  "id_str" : "623933201145331712",
  "text" : "Look, a tweetable definition of Academia. https:\/\/t.co\/uaT7ZpkcKV",
  "id" : 623933201145331712,
  "created_at" : "2015-07-22 19:10:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Feifer",
      "screen_name" : "heyfeifer",
      "indices" : [ 3, 13 ],
      "id_str" : "268944886",
      "id" : 268944886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/puLov55Xru",
      "expanded_url" : "http:\/\/nyti.ms\/1HRkz5d",
      "display_url" : "nyti.ms\/1HRkz5d"
    } ]
  },
  "geo" : { },
  "id_str" : "623929261930475520",
  "text" : "RT @heyfeifer: 1. The Times misuses \"selfie\"\n\n2. I demand a correction\n\n3. Instead, it lets me define selfie myself: http:\/\/t.co\/puLov55Xru\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/puLov55Xru",
        "expanded_url" : "http:\/\/nyti.ms\/1HRkz5d",
        "display_url" : "nyti.ms\/1HRkz5d"
      } ]
    },
    "in_reply_to_status_id_str" : "621690669418061824",
    "geo" : { },
    "id_str" : "623862067313922048",
    "in_reply_to_user_id" : 268944886,
    "text" : "1. The Times misuses \"selfie\"\n\n2. I demand a correction\n\n3. Instead, it lets me define selfie myself: http:\/\/t.co\/puLov55Xru YOU'RE WELCOME",
    "id" : 623862067313922048,
    "in_reply_to_status_id" : 621690669418061824,
    "created_at" : "2015-07-22 14:28:02 +0000",
    "in_reply_to_screen_name" : "heyfeifer",
    "in_reply_to_user_id_str" : "268944886",
    "user" : {
      "name" : "Jason Feifer",
      "screen_name" : "heyfeifer",
      "protected" : false,
      "id_str" : "268944886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/884880768820023296\/MTpuj-vD_normal.jpg",
      "id" : 268944886,
      "verified" : true
    }
  },
  "id" : 623929261930475520,
  "created_at" : "2015-07-22 18:55:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623902112934703104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11704107751149, 8.778641866528222 ]
  },
  "id_str" : "623925526353313792",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson ich w\u00FCrde mal eine freundliche Erinnerung schreiben. Hat bei mir bislang 2x geholfen es zu beschleunigen.",
  "id" : 623925526353313792,
  "in_reply_to_status_id" : 623902112934703104,
  "created_at" : "2015-07-22 18:40:12 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Holly Bik",
      "screen_name" : "hollybik",
      "indices" : [ 75, 84 ],
      "id_str" : "185910976",
      "id" : 185910976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/zRzeQWhOX1",
      "expanded_url" : "http:\/\/youtu.be\/dfCU4hZK2JA",
      "display_url" : "youtu.be\/dfCU4hZK2JA"
    }, {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/avfOnV0cKW",
      "expanded_url" : "http:\/\/www.open-bio.org\/wiki\/BOSC_2015_Schedule",
      "display_url" : "open-bio.org\/wiki\/BOSC_2015\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "623925078439424000",
  "text" : "RT @OBF_BOSC: First video from #BOSC2015 is now live, opening keynote from @hollybik http:\/\/t.co\/zRzeQWhOX1 - see http:\/\/t.co\/avfOnV0cKW fo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Holly Bik",
        "screen_name" : "hollybik",
        "indices" : [ 61, 70 ],
        "id_str" : "185910976",
        "id" : 185910976
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2015",
        "indices" : [ 17, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/zRzeQWhOX1",
        "expanded_url" : "http:\/\/youtu.be\/dfCU4hZK2JA",
        "display_url" : "youtu.be\/dfCU4hZK2JA"
      }, {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/avfOnV0cKW",
        "expanded_url" : "http:\/\/www.open-bio.org\/wiki\/BOSC_2015_Schedule",
        "display_url" : "open-bio.org\/wiki\/BOSC_2015\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "623897886204534784",
    "text" : "First video from #BOSC2015 is now live, opening keynote from @hollybik http:\/\/t.co\/zRzeQWhOX1 - see http:\/\/t.co\/avfOnV0cKW for more",
    "id" : 623897886204534784,
    "created_at" : "2015-07-22 16:50:22 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 623925078439424000,
  "created_at" : "2015-07-22 18:38:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402830595527, 8.753332941526685 ]
  },
  "id_str" : "623902901707108353",
  "text" : "Now my predictive iOS keyboard more or less on its own writes \u2018,my darling \uD83D\uDE18\u2019. A win for technology or just a lack of vocabulary on my end?",
  "id" : 623902901707108353,
  "created_at" : "2015-07-22 17:10:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623889310547353600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17288089406786, 8.627795713564053 ]
  },
  "id_str" : "623890276982071296",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon all the Bay Area hipsters will love it. They can legitimately say they listened to it before it was cool!",
  "id" : 623890276982071296,
  "in_reply_to_status_id" : 623889310547353600,
  "created_at" : "2015-07-22 16:20:08 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623884207962648585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225230727542, 8.627594869591762 ]
  },
  "id_str" : "623886252455149569",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon somehow parsed this as the Stanford Patreon experiment. \uD83D\uDE33",
  "id" : 623886252455149569,
  "in_reply_to_status_id" : 623884207962648585,
  "created_at" : "2015-07-22 16:04:08 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uBiome",
      "screen_name" : "uBiome",
      "indices" : [ 58, 65 ],
      "id_str" : "852039852",
      "id" : 852039852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/PcGf2EH8ZV",
      "expanded_url" : "https:\/\/github.com\/ubiome-opensource\/microbiome-data\/pulls",
      "display_url" : "github.com\/ubiome-opensou\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225230727542, 8.627594869591762 ]
  },
  "id_str" : "623885806424432641",
  "text" : "Seems I\u2019m the first one to start a pull request to get my @uBiome data into their repository. https:\/\/t.co\/PcGf2EH8ZV",
  "id" : 623885806424432641,
  "created_at" : "2015-07-22 16:02:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/L5nU0eFcfo",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/07\/22\/the-phenomenon-of-the-breakup.html",
      "display_url" : "boingboing.net\/2015\/07\/22\/the\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224433078983, 8.62759022722094 ]
  },
  "id_str" : "623877520748859392",
  "text" : "The phenomenon of the Breakup Explanation status update http:\/\/t.co\/L5nU0eFcfo",
  "id" : 623877520748859392,
  "created_at" : "2015-07-22 15:29:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623788095553556480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235197438524, 8.62758914658741 ]
  },
  "id_str" : "623788573192495104",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot yep, but as it\u2019s inner-european basically everyone could use it, wanna go? :p",
  "id" : 623788573192495104,
  "in_reply_to_status_id" : 623788095553556480,
  "created_at" : "2015-07-22 09:35:59 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623782929227980800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17248365870193, 8.627551554271347 ]
  },
  "id_str" : "623783813609598976",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ja, hast du mir gut beigebracht. stimmung:\uD83C\uDF0B",
  "id" : 623783813609598976,
  "in_reply_to_status_id" : 623782929227980800,
  "created_at" : "2015-07-22 09:17:05 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623782073967472640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237399912594, 8.627639026765925 ]
  },
  "id_str" : "623782517166985216",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot je weniger Promille drin, desto weniger Gewicht, desto weniger Spritverbrauch? \uD83D\uDE98\uD83C\uDF7B",
  "id" : 623782517166985216,
  "in_reply_to_status_id" : 623782073967472640,
  "created_at" : "2015-07-22 09:11:56 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623759642720641024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723420806651, 8.627593726529339 ]
  },
  "id_str" : "623780687171166208",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Schickermoos f\u00FCrs Auto?",
  "id" : 623780687171166208,
  "in_reply_to_status_id" : 623759642720641024,
  "created_at" : "2015-07-22 09:04:39 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liana Lareau",
      "screen_name" : "lianafaye",
      "indices" : [ 3, 13 ],
      "id_str" : "188520661",
      "id" : 188520661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/cIL1n6mcns",
      "expanded_url" : "http:\/\/courses.cs.washington.edu\/courses\/csep590\/06au\/readings\/p175-gurer.pdf",
      "display_url" : "courses.cs.washington.edu\/courses\/csep59\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "623767396621393920",
  "text" : "RT @lianafaye: Women made serious, integral contributions to the history of computing. It's not just token examples. http:\/\/t.co\/cIL1n6mcns",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/cIL1n6mcns",
        "expanded_url" : "http:\/\/courses.cs.washington.edu\/courses\/csep590\/06au\/readings\/p175-gurer.pdf",
        "display_url" : "courses.cs.washington.edu\/courses\/csep59\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "623675254934646784",
    "text" : "Women made serious, integral contributions to the history of computing. It's not just token examples. http:\/\/t.co\/cIL1n6mcns",
    "id" : 623675254934646784,
    "created_at" : "2015-07-22 02:05:42 +0000",
    "user" : {
      "name" : "Liana Lareau",
      "screen_name" : "lianafaye",
      "protected" : false,
      "id_str" : "188520661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620234052117774337\/si7QRHs8_normal.jpg",
      "id" : 188520661,
      "verified" : false
    }
  },
  "id" : 623767396621393920,
  "created_at" : "2015-07-22 08:11:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fakestats",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224746743722, 8.627601263276686 ]
  },
  "id_str" : "623763970529341440",
  "text" : "#1 reason why academic collaborations fail: being forced to use the MS Office tools. #fakestats",
  "id" : 623763970529341440,
  "created_at" : "2015-07-22 07:58:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227566120992, 8.627575848480763 ]
  },
  "id_str" : "623758857827975168",
  "text" : "the stupidity of multi-city-roundtrips: in order to save money there\u2019s a seat reserved on a flight MUC \u2708\uFE0F VIE for tomorrow morning.",
  "id" : 623758857827975168,
  "created_at" : "2015-07-22 07:37:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623536751773007872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407716822492, 8.753346361407436 ]
  },
  "id_str" : "623602456677756932",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam the txt output will be sadNam before converting to binary?",
  "id" : 623602456677756932,
  "in_reply_to_status_id" : 623536751773007872,
  "created_at" : "2015-07-21 21:16:26 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "Hein Bekker",
      "screen_name" : "netbek",
      "indices" : [ 12, 19 ],
      "id_str" : "13881112",
      "id" : 13881112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623590759455944712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407716822492, 8.753346361407436 ]
  },
  "id_str" : "623602073398026241",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo @netbek you\u2019re right on track to getting even more internet famous!",
  "id" : 623602073398026241,
  "in_reply_to_status_id" : 623590759455944712,
  "created_at" : "2015-07-21 21:14:54 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hein Bekker",
      "screen_name" : "netbek",
      "indices" : [ 0, 7 ],
      "id_str" : "13881112",
      "id" : 13881112
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 8, 19 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623543941808398336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407911968661, 8.753347354411739 ]
  },
  "id_str" : "623554038987128832",
  "in_reply_to_user_id" : 13881112,
  "text" : "@netbek @bella_velo that\u2019s just perfect :)",
  "id" : 623554038987128832,
  "in_reply_to_status_id" : 623543941808398336,
  "created_at" : "2015-07-21 18:04:02 +0000",
  "in_reply_to_screen_name" : "netbek",
  "in_reply_to_user_id_str" : "13881112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623532228665024512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11163618971815, 8.74029838520634 ]
  },
  "id_str" : "623532636326232064",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo I fear it\u2019s just lacking frames. Hard to add those. Could you do a video take of that? ;)",
  "id" : 623532636326232064,
  "in_reply_to_status_id" : 623532228665024512,
  "created_at" : "2015-07-21 16:38:59 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623528671073189888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11069472287608, 8.741616086341358 ]
  },
  "id_str" : "623532120091271168",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo proper in which sense? :)",
  "id" : 623532120091271168,
  "in_reply_to_status_id" : 623528671073189888,
  "created_at" : "2015-07-21 16:36:56 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/X8eEuJbQhD",
      "expanded_url" : "https:\/\/www.biostars.org\/p\/101890\/",
      "display_url" : "biostars.org\/p\/101890\/"
    } ]
  },
  "in_reply_to_status_id_str" : "623516675015618560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220487262211, 8.62762829038397 ]
  },
  "id_str" : "623516770943565824",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer https:\/\/t.co\/X8eEuJbQhD here\u2019s the biostars post :)",
  "id" : 623516770943565824,
  "in_reply_to_status_id" : 623516675015618560,
  "created_at" : "2015-07-21 15:35:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/EGb2OUrEiD",
      "expanded_url" : "https:\/\/github.com\/sujaikumar\/assemblage\/blob\/master\/README-annotation.md",
      "display_url" : "github.com\/sujaikumar\/ass\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "623515877879754753",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220487262211, 8.62762829038397 ]
  },
  "id_str" : "623516307837878272",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, found it! this turned up while googling and ending up on biostars: https:\/\/t.co\/EGb2OUrEiD :D",
  "id" : 623516307837878272,
  "in_reply_to_status_id" : 623515877879754753,
  "created_at" : "2015-07-21 15:34:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623509632330407936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221208150245, 8.627635847952023 ]
  },
  "id_str" : "623515455236493313",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw. didn\u2019t you have a good guide to eukaryotic gene annotation\/prediction at some point?",
  "id" : 623515455236493313,
  "in_reply_to_status_id" : 623509632330407936,
  "created_at" : "2015-07-21 15:30:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623514705051521024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225209550324, 8.627574491726726 ]
  },
  "id_str" : "623515004940255232",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a I think the extend to which people turn hangry (and how quickly it happens) varies widely.",
  "id" : 623515004940255232,
  "in_reply_to_status_id" : 623514705051521024,
  "created_at" : "2015-07-21 15:28:56 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623506007633842177",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722682054786, 8.627592080637298 ]
  },
  "id_str" : "623507657492692992",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83C\uDF4C",
  "id" : 623507657492692992,
  "in_reply_to_status_id" : 623506007633842177,
  "created_at" : "2015-07-21 14:59:44 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623499918360055808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722446054661, 8.627607764408628 ]
  },
  "id_str" : "623505824133054464",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot next: diese w\u00FCtenden Feministinnen m\u00FCssen nur mal ordentlich durchgef\u00FCttert werden! \uD83D\uDE31",
  "id" : 623505824133054464,
  "in_reply_to_status_id" : 623499918360055808,
  "created_at" : "2015-07-21 14:52:27 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 79, 88 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 89, 95 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/WnttMOEKLg",
      "expanded_url" : "https:\/\/theconversation.com\/health-check-the-science-of-hangry-or-why-some-people-get-grumpy-when-theyre-hungry-37229",
      "display_url" : "theconversation.com\/health-check-t\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225911007677, 8.62761099686194 ]
  },
  "id_str" : "623497800567922688",
  "text" : "the science of \u2018hangry\u2019, or why some people get grumpy when they\u2019re hungry \/cc @Senficon @Lobot https:\/\/t.co\/WnttMOEKLg",
  "id" : 623497800567922688,
  "created_at" : "2015-07-21 14:20:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/bFpj0NcSE6",
      "expanded_url" : "https:\/\/github.com\/sanger-pathogens\/circlator\/wiki",
      "display_url" : "github.com\/sanger-pathoge\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225911007677, 8.62761099686194 ]
  },
  "id_str" : "623496227057967104",
  "text" : "Circlator seems to work pretty nice to circularize bacterial genome assemblies https:\/\/t.co\/bFpj0NcSE6",
  "id" : 623496227057967104,
  "created_at" : "2015-07-21 14:14:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623491863459270656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224565920881, 8.62760981654966 ]
  },
  "id_str" : "623492024143097856",
  "in_reply_to_user_id" : 14286491,
  "text" : "Hard working: \u00ABWe played a total of 163 games of Halo 3 in the two manipulations. We stopped at 163 as this is a substantial time effort.\u00BB",
  "id" : 623492024143097856,
  "in_reply_to_status_id" : 623491863459270656,
  "created_at" : "2015-07-21 13:57:37 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/iZvD4FBih1",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371%2Fjournal.pone.0131613",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225473694163, 8.627597400149789 ]
  },
  "id_str" : "623491863459270656",
  "text" : "Totally missed this PLOS ONE article on sexism in video games http:\/\/t.co\/iZvD4FBih1",
  "id" : 623491863459270656,
  "created_at" : "2015-07-21 13:56:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Regehr",
      "screen_name" : "johnregehr",
      "indices" : [ 3, 14 ],
      "id_str" : "73469605",
      "id" : 73469605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/P3qwyjtnqH",
      "expanded_url" : "http:\/\/blogs.oregonstate.edu\/glencora\/2015\/07\/20\/1181\/",
      "display_url" : "blogs.oregonstate.edu\/glencora\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "623422931423633408",
  "text" : "RT @johnregehr: \"saved for publication until tenure\"\nhttp:\/\/t.co\/P3qwyjtnqH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/P3qwyjtnqH",
        "expanded_url" : "http:\/\/blogs.oregonstate.edu\/glencora\/2015\/07\/20\/1181\/",
        "display_url" : "blogs.oregonstate.edu\/glencora\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "623260022890364929",
    "text" : "\"saved for publication until tenure\"\nhttp:\/\/t.co\/P3qwyjtnqH",
    "id" : 623260022890364929,
    "created_at" : "2015-07-20 22:35:43 +0000",
    "user" : {
      "name" : "John Regehr",
      "screen_name" : "johnregehr",
      "protected" : false,
      "id_str" : "73469605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/861341285935833088\/M9XMqI6e_normal.jpg",
      "id" : 73469605,
      "verified" : false
    }
  },
  "id" : 623422931423633408,
  "created_at" : "2015-07-21 09:23:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/cYO39SDJf3",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/how-do-you-speak-american-mostly-just-make-up-words?utm_content=buffer65b7d&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "atlasobscura.com\/articles\/how-d\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224635431597, 8.627594738571291 ]
  },
  "id_str" : "623420707666591744",
  "text" : "How to speak American:\nBe flexible. Have fun. If Thomas Jefferson can make up words, so can you. http:\/\/t.co\/cYO39SDJf3",
  "id" : 623420707666591744,
  "created_at" : "2015-07-21 09:14:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722633828034, 8.62758274857413 ]
  },
  "id_str" : "623415710719545344",
  "text" : "Could we all please add \u201Ccontributing to open source projects 101\u201D as a core requirement to each bioinformatics course?",
  "id" : 623415710719545344,
  "created_at" : "2015-07-21 08:54:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/oIQ8EbTGHb",
      "expanded_url" : "http:\/\/i.imgur.com\/gEk61.gif",
      "display_url" : "i.imgur.com\/gEk61.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722667113644, 8.627587916215958 ]
  },
  "id_str" : "623379905301086208",
  "text" : "trying to use my polarized sunglasses for screen work http:\/\/t.co\/oIQ8EbTGHb",
  "id" : 623379905301086208,
  "created_at" : "2015-07-21 06:32:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/vYoMPJHy0y",
      "expanded_url" : "http:\/\/i.imgur.com\/1dsuiNi.gif",
      "display_url" : "i.imgur.com\/1dsuiNi.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "623262701704364032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407847141245, 8.7533317954769 ]
  },
  "id_str" : "623263798607151104",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima one of the academic initiation rites. here a cheer-up gif: http:\/\/t.co\/vYoMPJHy0y",
  "id" : 623263798607151104,
  "in_reply_to_status_id" : 623262701704364032,
  "created_at" : "2015-07-20 22:50:43 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/k2Av0gkyDA",
      "expanded_url" : "https:\/\/twitter.com\/lh3lh3\/status\/623213862679113728",
      "display_url" : "twitter.com\/lh3lh3\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407914207637, 8.753335946516103 ]
  },
  "id_str" : "623223386416775176",
  "text" : "How quickly bioinformatics progresses: the still most-used sequence file format and I share the same year of birth \uD83D\uDCBE https:\/\/t.co\/k2Av0gkyDA",
  "id" : 623223386416775176,
  "created_at" : "2015-07-20 20:10:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/DuwFgZzWGI",
      "expanded_url" : "http:\/\/duckhat.org\/misc\/spindoctor.gif",
      "display_url" : "duckhat.org\/misc\/spindocto\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406807844592, 8.753214049777368 ]
  },
  "id_str" : "623218687168921600",
  "text" : "Heard funniest openSNP misnomer today: openSpin. A quick google search tells me I really want to be a spin dogtor. http:\/\/t.co\/DuwFgZzWGI",
  "id" : 623218687168921600,
  "created_at" : "2015-07-20 19:51:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F1000Research",
      "screen_name" : "F1000Research",
      "indices" : [ 7, 21 ],
      "id_str" : "59126394",
      "id" : 59126394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/vmLogsWw9Y",
      "expanded_url" : "http:\/\/i.mobypicture.com\/user\/gedankenstuecke1\/view\/18156019",
      "display_url" : "i.mobypicture.com\/user\/gedankens\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "623197856959201280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402925807899, 8.753330166741515 ]
  },
  "id_str" : "623201509757595648",
  "in_reply_to_user_id" : 14286491,
  "text" : "And as @F1000Research doesn\u2019t allow dynamic slides as far as I can tell: this is what you\u2019re missing out on: http:\/\/t.co\/vmLogsWw9Y",
  "id" : 623201509757595648,
  "in_reply_to_status_id" : 623197856959201280,
  "created_at" : "2015-07-20 18:43:13 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F1000Research",
      "screen_name" : "F1000Research",
      "indices" : [ 102, 116 ],
      "id_str" : "59126394",
      "id" : 59126394
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 117, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/PKxESR9L9Y",
      "expanded_url" : "http:\/\/m.f1000research.com\/posters\/4-284",
      "display_url" : "m.f1000research.com\/posters\/4-284"
    }, {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/tYmETsA3rm",
      "expanded_url" : "http:\/\/m.f1000research.com\/slides\/4-285",
      "display_url" : "m.f1000research.com\/slides\/4-285"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400919728223, 8.753263747097108 ]
  },
  "id_str" : "623197856959201280",
  "text" : "Our poster (http:\/\/t.co\/PKxESR9L9Y) and my slides (http:\/\/t.co\/tYmETsA3rm) on openSNP are now also on @F1000Research #bosc2015",
  "id" : 623197856959201280,
  "created_at" : "2015-07-20 18:28:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 0, 7 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402967079525, 8.753329786061759 ]
  },
  "id_str" : "623195348580872192",
  "text" : "@malech quasi die umgekehrte Kausalit\u00E4t? :p",
  "id" : 623195348580872192,
  "created_at" : "2015-07-20 18:18:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623186551623782400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11004515799587, 8.759211623246335 ]
  },
  "id_str" : "623188447793168385",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju same here: on again, off again, gone again.",
  "id" : 623188447793168385,
  "in_reply_to_status_id" : 623186551623782400,
  "created_at" : "2015-07-20 17:51:18 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "indices" : [ 3, 12 ],
      "id_str" : "14075928",
      "id" : 14075928
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheOnion\/status\/621343477893173248\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/OqdEopjDEl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ9vBQaVAAAkctp.jpg",
      "id_str" : "621337340976365568",
      "id" : 621337340976365568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ9vBQaVAAAkctp.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1133,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 1133,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/OqdEopjDEl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/a13aCgFGUk",
      "expanded_url" : "http:\/\/onion.com\/1I2BcAi",
      "display_url" : "onion.com\/1I2BcAi"
    } ]
  },
  "geo" : { },
  "id_str" : "623150894683717632",
  "text" : "RT @TheOnion: Palestinian Man Marvels At How Much Childhood Refugee Camp Has Changed http:\/\/t.co\/a13aCgFGUk http:\/\/t.co\/OqdEopjDEl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheOnion\/status\/621343477893173248\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/OqdEopjDEl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ9vBQaVAAAkctp.jpg",
        "id_str" : "621337340976365568",
        "id" : 621337340976365568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ9vBQaVAAAkctp.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1133,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 1133,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/OqdEopjDEl"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/a13aCgFGUk",
        "expanded_url" : "http:\/\/onion.com\/1I2BcAi",
        "display_url" : "onion.com\/1I2BcAi"
      } ]
    },
    "geo" : { },
    "id_str" : "621343477893173248",
    "text" : "Palestinian Man Marvels At How Much Childhood Refugee Camp Has Changed http:\/\/t.co\/a13aCgFGUk http:\/\/t.co\/OqdEopjDEl",
    "id" : 621343477893173248,
    "created_at" : "2015-07-15 15:40:03 +0000",
    "user" : {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "protected" : false,
      "id_str" : "14075928",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875392068125769732\/yrN-1k0Y_normal.jpg",
      "id" : 14075928,
      "verified" : true
    }
  },
  "id" : 623150894683717632,
  "created_at" : "2015-07-20 15:22:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/LUWWhY2Sa8",
      "expanded_url" : "https:\/\/imgflip.com\/i\/oft62",
      "display_url" : "imgflip.com\/i\/oft62"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232112279548, 8.627546440574019 ]
  },
  "id_str" : "623133910059339776",
  "text" : "Bingo! https:\/\/t.co\/LUWWhY2Sa8",
  "id" : 623133910059339776,
  "created_at" : "2015-07-20 14:14:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/kjmLgb0XNI",
      "expanded_url" : "http:\/\/www.sciencedirect.com\/science\/article\/pii\/S0960982215006089",
      "display_url" : "sciencedirect.com\/science\/articl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723352146722, 8.627538341824847 ]
  },
  "id_str" : "623115633396449280",
  "text" : "Genomic Evidence that Sexual Selection Impedes Adaptation to a Novel Environment http:\/\/t.co\/kjmLgb0XNI",
  "id" : 623115633396449280,
  "created_at" : "2015-07-20 13:01:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/bI5zy2DUEG",
      "expanded_url" : "http:\/\/www.sitnprettyphoto.com\/display\/1500work.jpg",
      "display_url" : "sitnprettyphoto.com\/display\/1500wo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "623066505568194561",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221720482836, 8.627622291961258 ]
  },
  "id_str" : "623067236975157248",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot given my weight I may wanna opt for http:\/\/t.co\/bI5zy2DUEG",
  "id" : 623067236975157248,
  "in_reply_to_status_id" : 623066505568194561,
  "created_at" : "2015-07-20 09:49:39 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623066771713585152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222393352652, 8.62763216356554 ]
  },
  "id_str" : "623066900512305152",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot oreos, the universally accessible vegan sweets. :p",
  "id" : 623066900512305152,
  "in_reply_to_status_id" : 623066771713585152,
  "created_at" : "2015-07-20 09:48:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623066103409975296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222393352652, 8.62763216356554 ]
  },
  "id_str" : "623066575571132416",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot living your dream? \uD83C\uDF6A\uD83C\uDF4E\uD83C\uDF50\uD83D\uDC1B",
  "id" : 623066575571132416,
  "in_reply_to_status_id" : 623066103409975296,
  "created_at" : "2015-07-20 09:47:02 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/HyxNFljkD6",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/rosetta-stones\/the-awesome-power-of-lava-watch-metal-burn\/",
      "display_url" : "blogs.scientificamerican.com\/rosetta-stones\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223794957487, 8.627621965392352 ]
  },
  "id_str" : "623064437629550592",
  "text" : "\u00ABThe Awesome Power of Lava: Watch Metal Burn\u00BB could easily be a song title by Manowar http:\/\/t.co\/HyxNFljkD6",
  "id" : 623064437629550592,
  "created_at" : "2015-07-20 09:38:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/JhdrFqYwcF",
      "expanded_url" : "http:\/\/imgur.com\/YbkBxYb",
      "display_url" : "imgur.com\/YbkBxYb"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223794957305, 8.627621965391594 ]
  },
  "id_str" : "623063370690916352",
  "text" : "the not-so invisible thread of life http:\/\/t.co\/JhdrFqYwcF",
  "id" : 623063370690916352,
  "created_at" : "2015-07-20 09:34:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623051718453002240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222880895358, 8.627618154644786 ]
  },
  "id_str" : "623052259560177664",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot give it a couple of days and my \uD83D\uDE97 will only work as \uD83D\uDC36-drawn carriage anyway.",
  "id" : 623052259560177664,
  "in_reply_to_status_id" : 623051718453002240,
  "created_at" : "2015-07-20 08:50:09 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/yZee9tBJC0",
      "expanded_url" : "https:\/\/modernmodelorganism.wordpress.com\/2015\/07\/19\/biologists-and-bioinformaticians-have-different-software-needs\/",
      "display_url" : "modernmodelorganism.wordpress.com\/2015\/07\/19\/bio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "623048985310285824",
  "text" : "RT @pathogenomenick: This is a really nice definition of computational biologist vs bioinformatician: https:\/\/t.co\/yZee9tBJC0 also see http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/yZee9tBJC0",
        "expanded_url" : "https:\/\/modernmodelorganism.wordpress.com\/2015\/07\/19\/biologists-and-bioinformaticians-have-different-software-needs\/",
        "display_url" : "modernmodelorganism.wordpress.com\/2015\/07\/19\/bio\u2026"
      }, {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/9xDQ005lEO",
        "expanded_url" : "http:\/\/www.nature.com\/nbt\/journal\/v31\/n11\/full\/nbt.2740.html",
        "display_url" : "nature.com\/nbt\/journal\/v3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "623022239542300672",
    "text" : "This is a really nice definition of computational biologist vs bioinformatician: https:\/\/t.co\/yZee9tBJC0 also see http:\/\/t.co\/9xDQ005lEO",
    "id" : 623022239542300672,
    "created_at" : "2015-07-20 06:50:51 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 623048985310285824,
  "created_at" : "2015-07-20 08:37:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/Y4ytLUC3Oa",
      "expanded_url" : "https:\/\/mcgarnagle.files.wordpress.com\/2011\/10\/vlcsnap-00009.jpg",
      "display_url" : "mcgarnagle.files.wordpress.com\/2011\/10\/vlcsna\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722202628504, 8.627625863279247 ]
  },
  "id_str" : "623046136253808640",
  "text" : "accurate depiction of me right now: https:\/\/t.co\/Y4ytLUC3Oa",
  "id" : 623046136253808640,
  "created_at" : "2015-07-20 08:25:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 67, 83 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 54, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/avfOnV0cKW",
      "expanded_url" : "http:\/\/www.open-bio.org\/wiki\/BOSC_2015_Schedule",
      "display_url" : "open-bio.org\/wiki\/BOSC_2015\u2026"
    }, {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/vIC8zZ42fH",
      "expanded_url" : "http:\/\/figshare.com\/articles\/openSNP_BOSC15_Poster\/1466880",
      "display_url" : "figshare.com\/articles\/openS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "622866071297593344",
  "text" : "RT @OBF_BOSC: openSNP added to http:\/\/t.co\/avfOnV0cKW #BOSC2015 MT @gedankenstuecke Poster: http:\/\/t.co\/vIC8zZ42fH slides: http:\/\/t.co\/xdHk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 53, 69 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2015",
        "indices" : [ 40, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/avfOnV0cKW",
        "expanded_url" : "http:\/\/www.open-bio.org\/wiki\/BOSC_2015_Schedule",
        "display_url" : "open-bio.org\/wiki\/BOSC_2015\u2026"
      }, {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/vIC8zZ42fH",
        "expanded_url" : "http:\/\/figshare.com\/articles\/openSNP_BOSC15_Poster\/1466880",
        "display_url" : "figshare.com\/articles\/openS\u2026"
      }, {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/xdHkvnQ82f",
        "expanded_url" : "http:\/\/figshare.com\/articles\/openSNP_BOSC15_Slides\/1480397",
        "display_url" : "figshare.com\/articles\/openS\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "619819473923653632",
    "geo" : { },
    "id_str" : "622853766006575104",
    "in_reply_to_user_id" : 14286491,
    "text" : "openSNP added to http:\/\/t.co\/avfOnV0cKW #BOSC2015 MT @gedankenstuecke Poster: http:\/\/t.co\/vIC8zZ42fH slides: http:\/\/t.co\/xdHkvnQ82f :-)",
    "id" : 622853766006575104,
    "in_reply_to_status_id" : 619819473923653632,
    "created_at" : "2015-07-19 19:41:24 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 622866071297593344,
  "created_at" : "2015-07-19 20:30:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/sqN8qffnzN",
      "expanded_url" : "https:\/\/instagram.com\/p\/5U-9l2hwr6\/",
      "display_url" : "instagram.com\/p\/5U-9l2hwr6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "622836170720985092",
  "text" : "Accidentally figured out why I like the color of my nail polish so much. https:\/\/t.co\/sqN8qffnzN",
  "id" : 622836170720985092,
  "created_at" : "2015-07-19 18:31:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/MelB6nRHPF",
      "expanded_url" : "https:\/\/thescienceweb.wordpress.com\/2015\/07\/19\/publishing-paper-without-releasing-data-not-really-science\/",
      "display_url" : "thescienceweb.wordpress.com\/2015\/07\/19\/pub\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405640880511, 8.75342213033814 ]
  },
  "id_str" : "622740799864852480",
  "text" : "\u00AB\u2026saying that the \u201Cdata are available on request\u201D is rather like saying you \u201Cheard it from a mate\u201D\u2026\u00BB https:\/\/t.co\/MelB6nRHPF",
  "id" : 622740799864852480,
  "created_at" : "2015-07-19 12:12:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 3, 15 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/Jb88bCyQ4N",
      "expanded_url" : "http:\/\/ronininstitute.org\/symposium-on-academic-bureaucracy\/1082\/",
      "display_url" : "ronininstitute.org\/symposium-on-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "622683658030317568",
  "text" : "RT @jonfwilkins: Symposium on pathological academic bureaucracy. This is why we fight! http:\/\/t.co\/Jb88bCyQ4N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/Jb88bCyQ4N",
        "expanded_url" : "http:\/\/ronininstitute.org\/symposium-on-academic-bureaucracy\/1082\/",
        "display_url" : "ronininstitute.org\/symposium-on-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "622627836227158016",
    "text" : "Symposium on pathological academic bureaucracy. This is why we fight! http:\/\/t.co\/Jb88bCyQ4N",
    "id" : 622627836227158016,
    "created_at" : "2015-07-19 04:43:38 +0000",
    "user" : {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "protected" : false,
      "id_str" : "214099847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1279449740\/Dev2DEC_normal.jpg",
      "id" : 214099847,
      "verified" : false
    }
  },
  "id" : 622683658030317568,
  "created_at" : "2015-07-19 08:25:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622420596530511873",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10164763038487, 8.692425580668726 ]
  },
  "id_str" : "622427545301069825",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich das gibt so manchem Songtitel einen ganz anderen Frame. :3",
  "id" : 622427545301069825,
  "in_reply_to_status_id" : 622420596530511873,
  "created_at" : "2015-07-18 15:27:45 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622418271237767173",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10164837038118, 8.69242585615693 ]
  },
  "id_str" : "622420479329071104",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich wut?!",
  "id" : 622420479329071104,
  "in_reply_to_status_id" : 622418271237767173,
  "created_at" : "2015-07-18 14:59:40 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "csdfrankfurt",
      "indices" : [ 15, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/3QEWwWLBXx",
      "expanded_url" : "https:\/\/instagram.com\/p\/5SAiPFBwru\/",
      "display_url" : "instagram.com\/p\/5SAiPFBwru\/"
    } ]
  },
  "geo" : { },
  "id_str" : "622417416769945600",
  "text" : "\uD83C\uDF08\uD83D\uDC68\u200D\u2764\uFE0F\u200D\uD83D\uDC68\uD83D\uDC69\u200D\u2764\uFE0F\u200D\uD83D\uDC69\uD83C\uDDEE\uD83C\uDDF1#csdfrankfurt https:\/\/t.co\/3QEWwWLBXx",
  "id" : 622417416769945600,
  "created_at" : "2015-07-18 14:47:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/rAahFkOzpy",
      "expanded_url" : "https:\/\/instagram.com\/p\/5R9eSjBwk8\/",
      "display_url" : "instagram.com\/p\/5R9eSjBwk8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "622410682730983424",
  "text" : "Europe vs America\/Australia according to the natural history museum in Vienna\u2026 https:\/\/t.co\/rAahFkOzpy",
  "id" : 622410682730983424,
  "created_at" : "2015-07-18 14:20:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/4Nuzv1tEhD",
      "expanded_url" : "https:\/\/instagram.com\/p\/5R8aDyBwia\/",
      "display_url" : "instagram.com\/p\/5R8aDyBwia\/"
    } ]
  },
  "geo" : { },
  "id_str" : "622408338442199040",
  "text" : "Stephansplatz #latergram https:\/\/t.co\/4Nuzv1tEhD",
  "id" : 622408338442199040,
  "created_at" : "2015-07-18 14:11:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/replicakill\/status\/622273920310247424\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/V8NvgwvcdJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKLCx0TUkAEOqVU.jpg",
      "id_str" : "622273859639611393",
      "id" : 622273859639611393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKLCx0TUkAEOqVU.jpg",
      "sizes" : [ {
        "h" : 846,
        "resize" : "fit",
        "w" : 912
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 846,
        "resize" : "fit",
        "w" : 912
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 846,
        "resize" : "fit",
        "w" : 912
      } ],
      "display_url" : "pic.twitter.com\/V8NvgwvcdJ"
    } ],
    "hashtags" : [ {
      "text" : "Math",
      "indices" : [ 49, 54 ]
    }, {
      "text" : "Art",
      "indices" : [ 58, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/SDwqJ4wNIc",
      "expanded_url" : "http:\/\/rin.io\/im-not-good-at-math\/",
      "display_url" : "rin.io\/im-not-good-at\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "622337422827909120",
  "text" : "RT @replicakill: \u201CI\u2019m not good at math\u201D -over at #Math is #Art.\n\nhttp:\/\/t.co\/SDwqJ4wNIc http:\/\/t.co\/V8NvgwvcdJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/replicakill\/status\/622273920310247424\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/V8NvgwvcdJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKLCx0TUkAEOqVU.jpg",
        "id_str" : "622273859639611393",
        "id" : 622273859639611393,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKLCx0TUkAEOqVU.jpg",
        "sizes" : [ {
          "h" : 846,
          "resize" : "fit",
          "w" : 912
        }, {
          "h" : 631,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 846,
          "resize" : "fit",
          "w" : 912
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 846,
          "resize" : "fit",
          "w" : 912
        } ],
        "display_url" : "pic.twitter.com\/V8NvgwvcdJ"
      } ],
      "hashtags" : [ {
        "text" : "Math",
        "indices" : [ 32, 37 ]
      }, {
        "text" : "Art",
        "indices" : [ 41, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/SDwqJ4wNIc",
        "expanded_url" : "http:\/\/rin.io\/im-not-good-at-math\/",
        "display_url" : "rin.io\/im-not-good-at\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "622273920310247424",
    "text" : "\u201CI\u2019m not good at math\u201D -over at #Math is #Art.\n\nhttp:\/\/t.co\/SDwqJ4wNIc http:\/\/t.co\/V8NvgwvcdJ",
    "id" : 622273920310247424,
    "created_at" : "2015-07-18 05:17:18 +0000",
    "user" : {
      "name" : "Mexican Philosopher",
      "screen_name" : "mexphilosopher",
      "protected" : false,
      "id_str" : "131069387",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927020425367793665\/zXQ2i0k6_normal.jpg",
      "id" : 131069387,
      "verified" : false
    }
  },
  "id" : 622337422827909120,
  "created_at" : "2015-07-18 09:29:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10632636463684, 8.757999424225734 ]
  },
  "id_str" : "622306558320451585",
  "text" : "So for at least a week it will be \uD83D\uDE0E@\uD83C\uDF0C, as my regular glasses are off for repair. They should at least have offered a service-\uD83D\uDC36.",
  "id" : 622306558320451585,
  "created_at" : "2015-07-18 07:27:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.03804293931465, 8.51031711325842 ]
  },
  "id_str" : "622126617968648193",
  "text" : "\u2708\uFE0F\uD83C\uDFC8, with that the latest leg of the \uD83D\uDCCA\uD83D\uDCC9\u2014\uD83C\uDFAA comes to an end.",
  "id" : 622126617968648193,
  "created_at" : "2015-07-17 19:31:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Appropriate Tributes",
      "screen_name" : "godtributes",
      "indices" : [ 3, 15 ],
      "id_str" : "2566358196",
      "id" : 2566358196
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 17, 33 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622105578278678528",
  "text" : "RT @godtributes: @gedankenstuecke FRAS FOR THE FRA GOD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/jimkang.com\" rel=\"nofollow\"\u003Ebotsforthebotgod\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "622105391774703616",
    "geo" : { },
    "id_str" : "622105483109732353",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke FRAS FOR THE FRA GOD",
    "id" : 622105483109732353,
    "in_reply_to_status_id" : 622105391774703616,
    "created_at" : "2015-07-17 18:07:59 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Appropriate Tributes",
      "screen_name" : "godtributes",
      "protected" : false,
      "id_str" : "2566358196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816397890897649664\/ENsyhp0G_normal.jpg",
      "id" : 2566358196,
      "verified" : false
    }
  },
  "id" : 622105578278678528,
  "created_at" : "2015-07-17 18:08:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.11641161875329, 16.56893134253599 ]
  },
  "id_str" : "622105391774703616",
  "text" : "\u00ABThe emergency exits are marked with AUSGANG.\u00BB Even single Austrian-German words sound more intimidating. In other words: VIE \u2708\uFE0F FRA",
  "id" : 622105391774703616,
  "created_at" : "2015-07-17 18:07:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 0, 13 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622025883491147776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.11768800772328, 16.56843452257807 ]
  },
  "id_str" : "622086214775087104",
  "in_reply_to_user_id" : 116877838,
  "text" : "@MishaAngrist bgreshake@googlemail.com please :)",
  "id" : 622086214775087104,
  "in_reply_to_status_id" : 622025883491147776,
  "created_at" : "2015-07-17 16:51:26 +0000",
  "in_reply_to_screen_name" : "MishaAngrist",
  "in_reply_to_user_id_str" : "116877838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 0, 8 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622046592770646017",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.11768809521763, 16.56843451279168 ]
  },
  "id_str" : "622084477993545728",
  "in_reply_to_user_id" : 454724555,
  "text" : "@marc_rr only sad that I won\u2019t make it to eseb ;)",
  "id" : 622084477993545728,
  "in_reply_to_status_id" : 622046592770646017,
  "created_at" : "2015-07-17 16:44:31 +0000",
  "in_reply_to_screen_name" : "marc_rr",
  "in_reply_to_user_id_str" : "454724555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/622073360684580864\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/55azjLtz3a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKIMbO_WcAA7W1h.jpg",
      "id_str" : "622073360550359040",
      "id" : 622073360550359040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKIMbO_WcAA7W1h.jpg",
      "sizes" : [ {
        "h" : 1168,
        "resize" : "fit",
        "w" : 876
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1168,
        "resize" : "fit",
        "w" : 876
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1168,
        "resize" : "fit",
        "w" : 876
      } ],
      "display_url" : "pic.twitter.com\/55azjLtz3a"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622073360684580864",
  "text" : "Germanisierung des Alpenlandes http:\/\/t.co\/55azjLtz3a",
  "id" : 622073360684580864,
  "created_at" : "2015-07-17 16:00:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.14374489248557, 16.48123268970892 ]
  },
  "id_str" : "622069613484974080",
  "text" : "Stranger sitting next to me on this train is chewing on her headphone cords. Things like this make me miss commuting by public transport. \uD83D\uDE82\uD83D\uDE8B",
  "id" : 622069613484974080,
  "created_at" : "2015-07-17 15:45:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21501487404873, 16.37453776785766 ]
  },
  "id_str" : "622033612389654528",
  "text" : "\u00ABIt\u2019s dangerous to trust politicians&amp;scientists not only because they have no ethics, but also because of their lack of imagination&amp;emotion\u00BB",
  "id" : 622033612389654528,
  "created_at" : "2015-07-17 13:22:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/3sWsfa4Jka",
      "expanded_url" : "http:\/\/www.genomics.cn\/en\/news\/show_news?nid=104377",
      "display_url" : "genomics.cn\/en\/news\/show_n\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "622021859262001152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21434023965575, 16.37461045665763 ]
  },
  "id_str" : "622023835324411904",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer and there\u2019s the ICG-10 at BGI http:\/\/t.co\/3sWsfa4Jka",
  "id" : 622023835324411904,
  "in_reply_to_status_id" : 622021859262001152,
  "created_at" : "2015-07-17 12:43:33 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/lRXJXan6C3",
      "expanded_url" : "https:\/\/applbio.biologie.uni-frankfurt.de\/recombcg2015\/",
      "display_url" : "applbio.biologie.uni-frankfurt.de\/recombcg2015\/"
    } ]
  },
  "in_reply_to_status_id_str" : "622021859262001152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21444127717505, 16.37488638971339 ]
  },
  "id_str" : "622022236300550144",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer I hope so. There\u2019s the RECOMB Comparative Genomics in Frankfurt this year, you could drop by: https:\/\/t.co\/lRXJXan6C3",
  "id" : 622022236300550144,
  "in_reply_to_status_id" : 622021859262001152,
  "created_at" : "2015-07-17 12:37:12 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622021218951168000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21549391399233, 16.37454741539515 ]
  },
  "id_str" : "622021637915975680",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer nope, will be on vacation at the time (and my conf. schedule is already pretty packed again).",
  "id" : 622021637915975680,
  "in_reply_to_status_id" : 622021218951168000,
  "created_at" : "2015-07-17 12:34:49 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 0, 10 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622020923982540800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21477327161796, 16.37484917619789 ]
  },
  "id_str" : "622021104232755200",
  "in_reply_to_user_id" : 1515775878,
  "text" : "@fbnzimmer she sends her greetings, we briefly talked at the conference :)",
  "id" : 622021104232755200,
  "in_reply_to_status_id" : 622020923982540800,
  "created_at" : "2015-07-17 12:32:42 +0000",
  "in_reply_to_screen_name" : "fbnzimmer",
  "in_reply_to_user_id_str" : "1515775878",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/8NZof5buuH",
      "expanded_url" : "https:\/\/instagram.com\/p\/5PIUzdBwk5\/",
      "display_url" : "instagram.com\/p\/5PIUzdBwk5\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.177476116, 16.333141059 ]
  },
  "id_str" : "622012333787848704",
  "text" : "Rosy @ Ignazgasse https:\/\/t.co\/8NZof5buuH",
  "id" : 622012333787848704,
  "created_at" : "2015-07-17 11:57:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622010962229493760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21076303296133, 16.37130436375209 ]
  },
  "id_str" : "622011181721628672",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ist ja auch \u00B1 das gleiche ;)",
  "id" : 622011181721628672,
  "in_reply_to_status_id" : 622010962229493760,
  "created_at" : "2015-07-17 11:53:16 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622009892677775360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21078256431647, 16.37134552713744 ]
  },
  "id_str" : "622010089663262720",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich als Vegetarier hab ich von Weihnachten, \u00E4h, Gulasch, ja wenig Ahnung. Dachte aber immer es w\u00E4re ein Vulkan.",
  "id" : 622010089663262720,
  "in_reply_to_status_id" : 622009892677775360,
  "created_at" : "2015-07-17 11:48:56 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622009584929083392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21078256299229, 16.37134552649505 ]
  },
  "id_str" : "622009731280990208",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich 2 m\u00F6gliche Szenarien die zur Endzeit f\u00FChren ;)",
  "id" : 622009731280990208,
  "in_reply_to_status_id" : 622009584929083392,
  "created_at" : "2015-07-17 11:47:30 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621961037873553408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21078256299229, 16.37134552649505 ]
  },
  "id_str" : "622009329374339072",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich dann k\u00F6nnen wir ja bald Endland spielen \uD83C\uDF0B\uD83C\uDF20",
  "id" : 622009329374339072,
  "in_reply_to_status_id" : 621961037873553408,
  "created_at" : "2015-07-17 11:45:55 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20546807102711, 16.37071023926179 ]
  },
  "id_str" : "621989847515942912",
  "text" : "Vienna: where people are still allowed to smoke in coffee houses and people try to push healing quartz crystals to you on the street.",
  "id" : 621989847515942912,
  "created_at" : "2015-07-17 10:28:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/E2j4f8F7oo",
      "expanded_url" : "http:\/\/aeon.co\/magazine\/philosophy\/how-often-do-ethics-professors-call-their-mothers\/",
      "display_url" : "aeon.co\/magazine\/philo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621793324236697600",
  "text" : "\u00ABEthicists do not appear to behave better. Never once have we found ethicists as a whole behaving better\u2026\u00BB http:\/\/t.co\/E2j4f8F7oo",
  "id" : 621793324236697600,
  "created_at" : "2015-07-16 21:27:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21184961022258, 16.3786573822456 ]
  },
  "id_str" : "621751811138023424",
  "text" : "Server in the vegan restaurant: \u00ABI\u2019m also calling it \u2018Tiramisu\u2019 instead of \u2018Tirami-soy\u2019. I do not believe in the fascist vegan language.\u00BB",
  "id" : 621751811138023424,
  "created_at" : "2015-07-16 18:42:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621732869040402432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21564896203455, 16.37979637946227 ]
  },
  "id_str" : "621733010476527617",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek no, not at the conference dinner. Off-site random strangers.",
  "id" : 621733010476527617,
  "in_reply_to_status_id" : 621732869040402432,
  "created_at" : "2015-07-16 17:27:55 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21564833638092, 16.37975323946809 ]
  },
  "id_str" : "621726357291167744",
  "text" : "Fun way to end the #smbe15: during dinner there\u2019s a creationist arguing loudly at the next table.",
  "id" : 621726357291167744,
  "created_at" : "2015-07-16 17:01:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Logsdon",
      "screen_name" : "johnlogsdon",
      "indices" : [ 0, 12 ],
      "id_str" : "18414364",
      "id" : 18414364
    }, {
      "name" : "Liana Lareau",
      "screen_name" : "lianafaye",
      "indices" : [ 13, 23 ],
      "id_str" : "188520661",
      "id" : 188520661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621718113961291776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21639069514909, 16.37591688254423 ]
  },
  "id_str" : "621721557673619457",
  "in_reply_to_user_id" : 18414364,
  "text" : "@johnlogsdon @lianafaye sweet!",
  "id" : 621721557673619457,
  "in_reply_to_status_id" : 621718113961291776,
  "created_at" : "2015-07-16 16:42:25 +0000",
  "in_reply_to_screen_name" : "johnlogsdon",
  "in_reply_to_user_id_str" : "18414364",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Logsdon",
      "screen_name" : "johnlogsdon",
      "indices" : [ 0, 12 ],
      "id_str" : "18414364",
      "id" : 18414364
    }, {
      "name" : "Liana Lareau",
      "screen_name" : "lianafaye",
      "indices" : [ 13, 23 ],
      "id_str" : "188520661",
      "id" : 188520661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621705848038006784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21648447985259, 16.37607134889863 ]
  },
  "id_str" : "621717309367918592",
  "in_reply_to_user_id" : 18414364,
  "text" : "@johnlogsdon @lianafaye that\u2019s a shame! Should have shown them :)",
  "id" : 621717309367918592,
  "in_reply_to_status_id" : 621705848038006784,
  "created_at" : "2015-07-16 16:25:32 +0000",
  "in_reply_to_screen_name" : "johnlogsdon",
  "in_reply_to_user_id_str" : "18414364",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 0, 8 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621702134912970752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.206162786345, 16.36437975525327 ]
  },
  "id_str" : "621702503902670848",
  "in_reply_to_user_id" : 454724555,
  "text" : "@marc_rr save travels. Too bad you did the video part where they announced that there will be a rodeo at smbe16! #smbe15",
  "id" : 621702503902670848,
  "in_reply_to_status_id" : 621702134912970752,
  "created_at" : "2015-07-16 15:26:42 +0000",
  "in_reply_to_screen_name" : "marc_rr",
  "in_reply_to_user_id_str" : "454724555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20626792531296, 16.3647463634444 ]
  },
  "id_str" : "621701229991849984",
  "text" : "The video says smbe16\u2032s motto is: \u00ABNot getting any work done\u00BB #smbe15",
  "id" : 621701229991849984,
  "created_at" : "2015-07-16 15:21:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 3, 11 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "leakyleak",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "SMBE15",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621700729472974848",
  "text" : "RT @marc_rr: \"Next meeting started to leak out\". As in, they were giving out koalas #leakyleak #SMBE15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "leakyleak",
        "indices" : [ 71, 81 ]
      }, {
        "text" : "SMBE15",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621700515588608000",
    "text" : "\"Next meeting started to leak out\". As in, they were giving out koalas #leakyleak #SMBE15",
    "id" : 621700515588608000,
    "created_at" : "2015-07-16 15:18:48 +0000",
    "user" : {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "protected" : false,
      "id_str" : "454724555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1751744306\/mrr_caricature_normal.jpg",
      "id" : 454724555,
      "verified" : false
    }
  },
  "id" : 621700729472974848,
  "created_at" : "2015-07-16 15:19:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621658875327041537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20618612192295, 16.36457023173075 ]
  },
  "id_str" : "621665966884286465",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn yes, totally fitting for me. :p",
  "id" : 621665966884286465,
  "in_reply_to_status_id" : 621658875327041537,
  "created_at" : "2015-07-16 13:01:31 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/D5oLcXebhU",
      "expanded_url" : "https:\/\/instagram.com\/p\/5Mmn35Bwhl\/",
      "display_url" : "instagram.com\/p\/5Mmn35Bwhl\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.196575319, 16.337382409 ]
  },
  "id_str" : "621656749662183426",
  "text" : "Viennese traffic lights @ BahnhofCity Wien West https:\/\/t.co\/D5oLcXebhU",
  "id" : 621656749662183426,
  "created_at" : "2015-07-16 12:24:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 7, 20 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621618713289183232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20621196082745, 16.36439629797077 ]
  },
  "id_str" : "621619854672572416",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @PhilippBayer enjoy lunch \uD83D\uDE18\uD83C\uDF69\uD83C\uDF30\uD83C\uDF58\uD83C\uDF5C\uD83C\uDF67",
  "id" : 621619854672572416,
  "in_reply_to_status_id" : 621618713289183232,
  "created_at" : "2015-07-16 09:58:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 7, 20 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621616693006180352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20632907015064, 16.36400451542556 ]
  },
  "id_str" : "621617780509511680",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @PhilippBayer as if you\u2019d need an excuse \uD83C\uDF69\uD83D\uDC1B",
  "id" : 621617780509511680,
  "in_reply_to_status_id" : 621616693006180352,
  "created_at" : "2015-07-16 09:50:02 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/sJ4BYhDhp5",
      "expanded_url" : "https:\/\/instagram.com\/p\/5MLr0kBwiC\/",
      "display_url" : "instagram.com\/p\/5MLr0kBwiC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "621597508968534016",
  "text" : "The last conference day https:\/\/t.co\/sJ4BYhDhp5",
  "id" : 621597508968534016,
  "created_at" : "2015-07-16 08:29:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/2SJzkJBZ2C",
      "expanded_url" : "http:\/\/amzn.com\/k\/XLugwOppQWWbn4dDYKacHA",
      "display_url" : "amzn.com\/k\/XLugwOppQWWb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621595407118921730",
  "text" : "On libertarians.  \"I appreciate the freedom-loving, government-hating spirit of libertarians, but I think they... http:\/\/t.co\/2SJzkJBZ2C",
  "id" : 621595407118921730,
  "created_at" : "2015-07-16 08:21:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20665208228712, 16.36486338980523 ]
  },
  "id_str" : "621589057517322240",
  "text" : "Thou shalt not use blast e-values for measuring similarity\u2026 #smbe15",
  "id" : 621589057517322240,
  "created_at" : "2015-07-16 07:55:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20668212160821, 16.36486402664856 ]
  },
  "id_str" : "621587632032718848",
  "text" : "PP: Even using high binding affinity threshold there are still lots of promiscuous TFs. #smbe15",
  "id" : 621587632032718848,
  "created_at" : "2015-07-16 07:50:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20664183471611, 16.3647902336033 ]
  },
  "id_str" : "621587222492508160",
  "text" : "Paulo Pinto: Uses UniProbe data, includes binding affinity, showing promiscuity of TFs. #smbe15",
  "id" : 621587222492508160,
  "created_at" : "2015-07-16 07:48:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 3, 11 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 18, 25 ]
    }, {
      "text" : "bioinformatics",
      "indices" : [ 26, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/MB0EBcmmim",
      "expanded_url" : "https:\/\/twitter.com\/jag_ar_pascal\/status\/621576110606811136",
      "display_url" : "twitter.com\/jag_ar_pascal\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621579568235827200",
  "text" : "RT @marc_rr: Yes. #smbe15 #bioinformatics  https:\/\/t.co\/MB0EBcmmim",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "smbe15",
        "indices" : [ 5, 12 ]
      }, {
        "text" : "bioinformatics",
        "indices" : [ 13, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/MB0EBcmmim",
        "expanded_url" : "https:\/\/twitter.com\/jag_ar_pascal\/status\/621576110606811136",
        "display_url" : "twitter.com\/jag_ar_pascal\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "621577090148757504",
    "text" : "Yes. #smbe15 #bioinformatics  https:\/\/t.co\/MB0EBcmmim",
    "id" : 621577090148757504,
    "created_at" : "2015-07-16 07:08:21 +0000",
    "user" : {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "protected" : false,
      "id_str" : "454724555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1751744306\/mrr_caricature_normal.jpg",
      "id" : 454724555,
      "verified" : false
    }
  },
  "id" : 621579568235827200,
  "created_at" : "2015-07-16 07:18:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20709781723311, 16.36334440784346 ]
  },
  "id_str" : "621576429088731137",
  "text" : "Lesson learned: never compliment someone for their rad tattoo of a llama. It may turn out that it should depict a fighting bull.",
  "id" : 621576429088731137,
  "created_at" : "2015-07-16 07:05:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 14, 20 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621489238455021568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.2165387973105, 16.37598476817989 ]
  },
  "id_str" : "621563561513480192",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Lobot Betteridge\u2019s law \u2014 has science gone too far?",
  "id" : 621563561513480192,
  "in_reply_to_status_id" : 621489238455021568,
  "created_at" : "2015-07-16 06:14:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/L7v2ofBBSS",
      "expanded_url" : "http:\/\/amzn.com\/k\/52WldVn1TW2P7X7k9mWESQ",
      "display_url" : "amzn.com\/k\/52WldVn1TW2P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621447579704926208",
  "text" : "Quote from last tweet is out of \"The World Beyond Your Head\". See link, makes an interesting read: \"Getting th... http:\/\/t.co\/L7v2ofBBSS",
  "id" : 621447579704926208,
  "created_at" : "2015-07-15 22:33:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21659570098689, 16.37598389761185 ]
  },
  "id_str" : "621446709399429120",
  "text" : "\u00AB[\u2026] to be good at this kind of conversation you have to love the truth more than you love your own current state of understanding.\u00BB",
  "id" : 621446709399429120,
  "created_at" : "2015-07-15 22:30:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621440705462935552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21652446459365, 16.37589738390723 ]
  },
  "id_str" : "621440919250837509",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson ich erfreu mich an jedem Hunde-Foto und Emoji \uD83D\uDC96\uD83D\uDC36",
  "id" : 621440919250837509,
  "in_reply_to_status_id" : 621440705462935552,
  "created_at" : "2015-07-15 22:07:15 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "himbeerkomplott",
      "screen_name" : "raspberryperson",
      "indices" : [ 0, 16 ],
      "id_str" : "2841131495",
      "id" : 2841131495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621438587213586432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21652446455437, 16.37589738418711 ]
  },
  "id_str" : "621439680320512000",
  "in_reply_to_user_id" : 2841131495,
  "text" : "@raspberryperson \uD83D\uDC36 genauso",
  "id" : 621439680320512000,
  "in_reply_to_status_id" : 621438587213586432,
  "created_at" : "2015-07-15 22:02:20 +0000",
  "in_reply_to_screen_name" : "raspberryperson",
  "in_reply_to_user_id_str" : "2841131495",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 80, 93 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 94, 100 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/stVjL51Ie1",
      "expanded_url" : "http:\/\/www.replicatedtypo.com\/phylogenetics-in-linguistics-the-biggest-intellectual-fraud-since-chomsky\/10854.html",
      "display_url" : "replicatedtypo.com\/phylogenetics-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21674461722753, 16.37618190288586 ]
  },
  "id_str" : "621431863647846400",
  "text" : "Phylogenetics in linguistics: the biggest intellectual fraud since Chomsky? \/cc @PhilippBayer @Lobot http:\/\/t.co\/stVjL51Ie1",
  "id" : 621431863647846400,
  "created_at" : "2015-07-15 21:31:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21647690567897, 16.37598361797053 ]
  },
  "id_str" : "621424328647831553",
  "text" : "My conference roommate just unearthed the \u2018top 10 most hated songs\u2019 (actually called like this!) playlist on YouTube. #smbe15",
  "id" : 621424328647831553,
  "created_at" : "2015-07-15 21:01:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans Zauner",
      "screen_name" : "HansZauner",
      "indices" : [ 0, 11 ],
      "id_str" : "995259308",
      "id" : 995259308
    }, {
      "name" : "moepern",
      "screen_name" : "Moepern",
      "indices" : [ 12, 20 ],
      "id_str" : "2168283234",
      "id" : 2168283234
    }, {
      "name" : "Laborjournal",
      "screen_name" : "Lab_Journal",
      "indices" : [ 21, 33 ],
      "id_str" : "1060480867",
      "id" : 1060480867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621408077229760514",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.2150711062895, 16.37455692910731 ]
  },
  "id_str" : "621417347795034114",
  "in_reply_to_user_id" : 995259308,
  "text" : "@HansZauner @Moepern @Lab_Journal vielen Dank!",
  "id" : 621417347795034114,
  "in_reply_to_status_id" : 621408077229760514,
  "created_at" : "2015-07-15 20:33:35 +0000",
  "in_reply_to_screen_name" : "HansZauner",
  "in_reply_to_user_id_str" : "995259308",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621389798041849856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21521730001894, 16.37410809688371 ]
  },
  "id_str" : "621390746940243968",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot even Miller is only like 6kg I guess.",
  "id" : 621390746940243968,
  "in_reply_to_status_id" : 621389798041849856,
  "created_at" : "2015-07-15 18:47:53 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621389379030917120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21522665744063, 16.37472013046204 ]
  },
  "id_str" : "621389553153245184",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot no way, maybe both of them. More likely: someone did weigh their luggage.",
  "id" : 621389553153245184,
  "in_reply_to_status_id" : 621389379030917120,
  "created_at" : "2015-07-15 18:43:08 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621387870696288256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21644958999563, 16.37316601845921 ]
  },
  "id_str" : "621388988604149760",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot what\u2019s the weight?",
  "id" : 621388988604149760,
  "in_reply_to_status_id" : 621387870696288256,
  "created_at" : "2015-07-15 18:40:54 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621385618711539713",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21106426751555, 16.37257600447484 ]
  },
  "id_str" : "621385835796164608",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot guess I should check the logs. Or did you already?",
  "id" : 621385835796164608,
  "in_reply_to_status_id" : 621385618711539713,
  "created_at" : "2015-07-15 18:28:22 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Logsdon",
      "screen_name" : "johnlogsdon",
      "indices" : [ 3, 15 ],
      "id_str" : "18414364",
      "id" : 18414364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621310598987558912",
  "text" : "RT @johnlogsdon: CN: yarrowia clade has big and diverse genomes. Not due to gene number or transposons. Not wgd. Introns &amp; intergenic regio\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "smbe15",
        "indices" : [ 135, 142 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621305367214059520",
    "text" : "CN: yarrowia clade has big and diverse genomes. Not due to gene number or transposons. Not wgd. Introns &amp; intergenic region sizes! #smbe15",
    "id" : 621305367214059520,
    "created_at" : "2015-07-15 13:08:37 +0000",
    "user" : {
      "name" : "John Logsdon",
      "screen_name" : "johnlogsdon",
      "protected" : false,
      "id_str" : "18414364",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796392374213689344\/NXUYysDF_normal.jpg",
      "id" : 18414364,
      "verified" : false
    }
  },
  "id" : 621310598987558912,
  "created_at" : "2015-07-15 13:29:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J.J. Emerson",
      "screen_name" : "JJ_Emerson",
      "indices" : [ 0, 11 ],
      "id_str" : "9618642",
      "id" : 9618642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621309075335311360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20702631780065, 16.36498625099026 ]
  },
  "id_str" : "621309443163193344",
  "in_reply_to_user_id" : 9618642,
  "text" : "@JJ_Emerson fully agree. I worked a bit with such data. Was impressed on my own data as well. Still amazes me every time.",
  "id" : 621309443163193344,
  "in_reply_to_status_id" : 621309075335311360,
  "created_at" : "2015-07-15 13:24:49 +0000",
  "in_reply_to_screen_name" : "JJ_Emerson",
  "in_reply_to_user_id_str" : "9618642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20702631780065, 16.36498625099026 ]
  },
  "id_str" : "621308870128963584",
  "text" : "JS: just using PacBio reads resulted in chromosome level assembly for Neurospora species. #smbe15",
  "id" : 621308870128963584,
  "created_at" : "2015-07-15 13:22:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PacBio",
      "screen_name" : "PacBio",
      "indices" : [ 30, 37 ],
      "id_str" : "39694489",
      "id" : 39694489
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20702631780065, 16.36498625099026 ]
  },
  "id_str" : "621308384919318529",
  "text" : "Now: Jesper Svedberg on using @PacBio to investigate Spore Killers. #smbe15",
  "id" : 621308384919318529,
  "created_at" : "2015-07-15 13:20:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621307219947208704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20701168746396, 16.36496947798408 ]
  },
  "id_str" : "621307807002947584",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83D\uDC36\uD83D\uDC45\uD83C\uDF67(Let\u2019s make those!)",
  "id" : 621307807002947584,
  "in_reply_to_status_id" : 621307219947208704,
  "created_at" : "2015-07-15 13:18:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621305006919131136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20701739234956, 16.36497888560355 ]
  },
  "id_str" : "621305342576734208",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83D\uDC36\uD83D\uDC93",
  "id" : 621305342576734208,
  "in_reply_to_status_id" : 621305006919131136,
  "created_at" : "2015-07-15 13:08:31 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621294161904406528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20701739234956, 16.36497888560355 ]
  },
  "id_str" : "621304087263485953",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot i\u2019ll remind you of that!",
  "id" : 621304087263485953,
  "in_reply_to_status_id" : 621294161904406528,
  "created_at" : "2015-07-15 13:03:32 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Logsdon",
      "screen_name" : "johnlogsdon",
      "indices" : [ 44, 56 ],
      "id_str" : "18414364",
      "id" : 18414364
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/nlpSNE1WPp",
      "expanded_url" : "http:\/\/www.lcqb.upmc.fr\/CHROnicle\/",
      "display_url" : "lcqb.upmc.fr\/CHROnicle\/"
    } ]
  },
  "in_reply_to_status_id_str" : "621300767966822400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20701739234956, 16.36497888560355 ]
  },
  "id_str" : "621303567438249984",
  "in_reply_to_user_id" : 18414364,
  "text" : "Can be found here http:\/\/t.co\/nlpSNE1WPp RT @johnlogsdon: GF : ancestral genome reconstruction using SynChro ReChro AnChro  #smbe15",
  "id" : 621303567438249984,
  "in_reply_to_status_id" : 621300767966822400,
  "created_at" : "2015-07-15 13:01:28 +0000",
  "in_reply_to_screen_name" : "johnlogsdon",
  "in_reply_to_user_id_str" : "18414364",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Daniel",
      "screen_name" : "sleeksorrow",
      "indices" : [ 7, 19 ],
      "id_str" : "59806323",
      "id" : 59806323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621299331581222912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20683549310883, 16.36454998913568 ]
  },
  "id_str" : "621299594597675009",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @sleeksorrow I only do dogs!",
  "id" : 621299594597675009,
  "in_reply_to_status_id" : 621299331581222912,
  "created_at" : "2015-07-15 12:45:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Daniel",
      "screen_name" : "sleeksorrow",
      "indices" : [ 7, 19 ],
      "id_str" : "59806323",
      "id" : 59806323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621293698232487936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20686715328474, 16.36471120729944 ]
  },
  "id_str" : "621298397857902592",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @sleeksorrow i guess I have a new weekend project.",
  "id" : 621298397857902592,
  "in_reply_to_status_id" : 621293698232487936,
  "created_at" : "2015-07-15 12:40:55 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 34, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20688416099832, 16.36477013872526 ]
  },
  "id_str" : "621292108608065536",
  "text" : "Welcome to the Forgotten Kingdom! #smbe15",
  "id" : 621292108608065536,
  "created_at" : "2015-07-15 12:15:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Daniel",
      "screen_name" : "sleeksorrow",
      "indices" : [ 7, 19 ],
      "id_str" : "59806323",
      "id" : 59806323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621291584378826756",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20688416099832, 16.36477013872526 ]
  },
  "id_str" : "621291952479334400",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @sleeksorrow yo dog, i put a dog into your dog, so you can cuddle while you cuddle?",
  "id" : 621291952479334400,
  "in_reply_to_status_id" : 621291584378826756,
  "created_at" : "2015-07-15 12:15:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Daniel",
      "screen_name" : "sleeksorrow",
      "indices" : [ 7, 19 ],
      "id_str" : "59806323",
      "id" : 59806323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621286717077762048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20626114965249, 16.36438049377535 ]
  },
  "id_str" : "621286989007036417",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @sleeksorrow du hast dich also doch f\u00FCr Einen Hund entschieden? ;)",
  "id" : 621286989007036417,
  "in_reply_to_status_id" : 621286717077762048,
  "created_at" : "2015-07-15 11:55:35 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Daniel",
      "screen_name" : "sleeksorrow",
      "indices" : [ 7, 19 ],
      "id_str" : "59806323",
      "id" : 59806323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621285595617357824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20641772360374, 16.36491433718835 ]
  },
  "id_str" : "621285975965220864",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @sleeksorrow jetzt noch schwimmend?",
  "id" : 621285975965220864,
  "in_reply_to_status_id" : 621285595617357824,
  "created_at" : "2015-07-15 11:51:34 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Daniel",
      "screen_name" : "sleeksorrow",
      "indices" : [ 7, 19 ],
      "id_str" : "59806323",
      "id" : 59806323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621284893180456960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20626757168561, 16.36390610020183 ]
  },
  "id_str" : "621285820578840576",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @sleeksorrow ich hoffe die Ente hat mehr als ein Zimmer!",
  "id" : 621285820578840576,
  "in_reply_to_status_id" : 621284893180456960,
  "created_at" : "2015-07-15 11:50:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel",
      "screen_name" : "sleeksorrow",
      "indices" : [ 0, 12 ],
      "id_str" : "59806323",
      "id" : 59806323
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621284387540353024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20632804355859, 16.36375018059249 ]
  },
  "id_str" : "621284699600736256",
  "in_reply_to_user_id" : 59806323,
  "text" : "@sleeksorrow @Lobot wann kann ich einziehen?",
  "id" : 621284699600736256,
  "in_reply_to_status_id" : 621284387540353024,
  "created_at" : "2015-07-15 11:46:29 +0000",
  "in_reply_to_screen_name" : "sleeksorrow",
  "in_reply_to_user_id_str" : "59806323",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/llCaQo8oBZ",
      "expanded_url" : "https:\/\/instagram.com\/p\/5J2KaKhwlG\/",
      "display_url" : "instagram.com\/p\/5J2KaKhwlG\/"
    } ]
  },
  "geo" : { },
  "id_str" : "621268706086273024",
  "text" : "City Hall https:\/\/t.co\/llCaQo8oBZ",
  "id" : 621268706086273024,
  "created_at" : "2015-07-15 10:42:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/MpofHizWWZ",
      "expanded_url" : "http:\/\/ents.openforet.fr\/",
      "display_url" : "ents.openforet.fr"
    } ]
  },
  "in_reply_to_status_id_str" : "621258095348441089",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20604996760208, 16.36529881508682 ]
  },
  "id_str" : "621259686218739712",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot see http:\/\/t.co\/MpofHizWWZ if you like this stuff.",
  "id" : 621259686218739712,
  "in_reply_to_status_id" : 621258095348441089,
  "created_at" : "2015-07-15 10:07:06 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621259281975873536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20604644722975, 16.36483149764931 ]
  },
  "id_str" : "621259628245086208",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot apartment duck face!",
  "id" : 621259628245086208,
  "in_reply_to_status_id" : 621259281975873536,
  "created_at" : "2015-07-15 10:06:52 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621256081524817920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20616899456956, 16.36444237073085 ]
  },
  "id_str" : "621256331295592448",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot das mit den Steinigungen ist einfach nur ein \u00DCbersetzungsfehler?",
  "id" : 621256331295592448,
  "in_reply_to_status_id" : 621256081524817920,
  "created_at" : "2015-07-15 09:53:46 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621255099579506688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.2061691290728, 16.36439213730596 ]
  },
  "id_str" : "621255865685950464",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich nein, so w\u00E4scht man sich hier die H\u00E4nde. \uD83D\uDC4F\uD83C\uDFFC",
  "id" : 621255865685950464,
  "in_reply_to_status_id" : 621255099579506688,
  "created_at" : "2015-07-15 09:51:55 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621253337359511552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.2061691290728, 16.36439213730596 ]
  },
  "id_str" : "621255186892369920",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83D\uDC24\uD83C\uDFE2",
  "id" : 621255186892369920,
  "in_reply_to_status_id" : 621253337359511552,
  "created_at" : "2015-07-15 09:49:13 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20670628683845, 16.36488489575433 ]
  },
  "id_str" : "621247562507489280",
  "text" : "Ouch, even the ancient DNA project achieves a better fold-coverage when sequencing than we do with our algal DNA\u2026 #smbe15",
  "id" : 621247562507489280,
  "created_at" : "2015-07-15 09:18:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/6m7StiJgdq",
      "expanded_url" : "https:\/\/instagram.com\/p\/5JkyyYBwhg\/",
      "display_url" : "instagram.com\/p\/5JkyyYBwhg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "621230511982256129",
  "text" : "Tourist-ing https:\/\/t.co\/6m7StiJgdq",
  "id" : 621230511982256129,
  "created_at" : "2015-07-15 08:11:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 3, 11 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621229547254599680",
  "text" : "RT @marc_rr: If you like sex &amp; non model genomics, contact me, we'll have open positions in a cool project between Lausanne and Montpellier\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "smbe15",
        "indices" : [ 136, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621227894904385536",
    "text" : "If you like sex &amp; non model genomics, contact me, we'll have open positions in a cool project between Lausanne and Montpellier soon #smbe15",
    "id" : 621227894904385536,
    "created_at" : "2015-07-15 08:00:46 +0000",
    "user" : {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "protected" : false,
      "id_str" : "454724555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1751744306\/mrr_caricature_normal.jpg",
      "id" : 454724555,
      "verified" : false
    }
  },
  "id" : 621229547254599680,
  "created_at" : "2015-07-15 08:07:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yara Sanchez",
      "screen_name" : "yara_elena",
      "indices" : [ 3, 14 ],
      "id_str" : "1360330398",
      "id" : 1360330398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/VDAZQN8RSz",
      "expanded_url" : "https:\/\/theconversation.com\/workaholism-isnt-a-valid-requirement-for-advancing-in-science-44555",
      "display_url" : "theconversation.com\/workaholism-is\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621226390554308608",
  "text" : "RT @yara_elena: \"(...)the solution isn\u2019t to work longer, but to work smarter.\" https:\/\/t.co\/VDAZQN8RSz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/VDAZQN8RSz",
        "expanded_url" : "https:\/\/theconversation.com\/workaholism-isnt-a-valid-requirement-for-advancing-in-science-44555",
        "display_url" : "theconversation.com\/workaholism-is\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "621225879667122177",
    "text" : "\"(...)the solution isn\u2019t to work longer, but to work smarter.\" https:\/\/t.co\/VDAZQN8RSz",
    "id" : 621225879667122177,
    "created_at" : "2015-07-15 07:52:46 +0000",
    "user" : {
      "name" : "Yara Sanchez",
      "screen_name" : "yara_elena",
      "protected" : false,
      "id_str" : "1360330398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/439172286076026880\/Mpz4yPQ6_normal.jpeg",
      "id" : 1360330398,
      "verified" : false
    }
  },
  "id" : 621226390554308608,
  "created_at" : "2015-07-15 07:54:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20620260397246, 16.36439766545825 ]
  },
  "id_str" : "621222759172034560",
  "text" : "HM: platypus with 9 pseudoautosomal regions, some very large. Boundaries of those found using seq coverage. #smbe15",
  "id" : 621222759172034560,
  "created_at" : "2015-07-15 07:40:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20620260397246, 16.36439766545825 ]
  },
  "id_str" : "621222470738161664",
  "text" : "Twitter question to HM: Will there be a platypus emoji? #smbe15",
  "id" : 621222470738161664,
  "created_at" : "2015-07-15 07:39:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20616292055681, 16.36431520596847 ]
  },
  "id_str" : "621221923620528128",
  "text" : "HM: platypus have hotspots of recombination. #smbe15",
  "id" : 621221923620528128,
  "created_at" : "2015-07-15 07:37:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20616292055681, 16.36431520596847 ]
  },
  "id_str" : "621221284211503104",
  "text" : "HM: PCA shows how Tasmanian population is divergent from mainland ones. All populations rather isolated. #smbe15",
  "id" : 621221284211503104,
  "created_at" : "2015-07-15 07:34:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20616292055681, 16.36431520596847 ]
  },
  "id_str" : "621220953981366272",
  "text" : "HM: Using long mate pairs, BACs, Moleculo to improve reference assembly, doing rescaffolding. PacBio &amp; HiC ongoing. #smbe15",
  "id" : 621220953981366272,
  "created_at" : "2015-07-15 07:33:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20618277619462, 16.36430699531219 ]
  },
  "id_str" : "621220663806791680",
  "text" : "Now: Hilary Martin on what to learn by doing Whole Genome Sequencing on the platypus. #smbe15",
  "id" : 621220663806791680,
  "created_at" : "2015-07-15 07:32:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 0, 8 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621214478319927296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20615474358522, 16.36434141638632 ]
  },
  "id_str" : "621215445526409217",
  "in_reply_to_user_id" : 454724555,
  "text" : "@marc_rr even more fun: what the google ads shown to you will be for the next couple of weeks from there on.",
  "id" : 621215445526409217,
  "in_reply_to_status_id" : 621214478319927296,
  "created_at" : "2015-07-15 07:11:18 +0000",
  "in_reply_to_screen_name" : "marc_rr",
  "in_reply_to_user_id_str" : "454724555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621214998606553088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20616225419783, 16.36443594958366 ]
  },
  "id_str" : "621215142819299328",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich wir sind hier ja auch in \u00D6sterreich :D",
  "id" : 621215142819299328,
  "in_reply_to_status_id" : 621214998606553088,
  "created_at" : "2015-07-15 07:10:06 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/621211294390177792\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/SnvCjRaZLf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ78YX1W8AAnflv.jpg",
      "id_str" : "621211294268583936",
      "id" : 621211294268583936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ78YX1W8AAnflv.jpg",
      "sizes" : [ {
        "h" : 1189,
        "resize" : "fit",
        "w" : 1189
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1189,
        "resize" : "fit",
        "w" : 1189
      }, {
        "h" : 1189,
        "resize" : "fit",
        "w" : 1189
      } ],
      "display_url" : "pic.twitter.com\/SnvCjRaZLf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621211294390177792",
  "text" : "Weird find in a pub restroom. http:\/\/t.co\/SnvCjRaZLf",
  "id" : 621211294390177792,
  "created_at" : "2015-07-15 06:54:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621104337591386112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.2061656208325, 16.36434931978772 ]
  },
  "id_str" : "621202220315463680",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia ok, hope you find the time! :)",
  "id" : 621202220315463680,
  "in_reply_to_status_id" : 621104337591386112,
  "created_at" : "2015-07-15 06:18:45 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621094679258361856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21647491234982, 16.37580494939225 ]
  },
  "id_str" : "621094987455963136",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez and I know the soon-to-be Zuckerberg of trees! Because everything is better if you add big data to it! \uD83D\uDE02",
  "id" : 621094987455963136,
  "in_reply_to_status_id" : 621094679258361856,
  "created_at" : "2015-07-14 23:12:39 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621093936371662848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21643213807623, 16.37593924092579 ]
  },
  "id_str" : "621094563457970176",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez (also: I know someone who works on doing something like this large scale, for multiple cities. Have to fwd this to him)",
  "id" : 621094563457970176,
  "in_reply_to_status_id" : 621093936371662848,
  "created_at" : "2015-07-14 23:10:57 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621093936371662848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21643213807623, 16.37593924092579 ]
  },
  "id_str" : "621094392326160384",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez absolutely, I might have shed a \uD83D\uDE22 while reading. Will go talking to one right away tomorrow morning.",
  "id" : 621094392326160384,
  "in_reply_to_status_id" : 621093936371662848,
  "created_at" : "2015-07-14 23:10:17 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 48, 57 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/4hpoffT4Gf",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2015\/07\/when-you-give-a-tree-an-email-address\/398210\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "621092535742566400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21643213807623, 16.37593924092579 ]
  },
  "id_str" : "621093794553970689",
  "in_reply_to_user_id" : 21135674,
  "text" : "\u00ABYou are the gift that keeps on giving.\u00BB \uD83C\uDF30\uD83D\uDC98\uD83C\uDF32 RT @eramirez: \u201CI\u2019m glad we\u2019re in this together.\u201D - Emails to a tree: http:\/\/t.co\/4hpoffT4Gf",
  "id" : 621093794553970689,
  "in_reply_to_status_id" : 621092535742566400,
  "created_at" : "2015-07-14 23:07:54 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621089808497143808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21642576954998, 16.37597643731584 ]
  },
  "id_str" : "621092629103706112",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia reminds me: any plans for Germany so far? :)",
  "id" : 621092629103706112,
  "in_reply_to_status_id" : 621089808497143808,
  "created_at" : "2015-07-14 23:03:16 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Dylan Finch",
      "screen_name" : "samdylanfinch",
      "indices" : [ 3, 17 ],
      "id_str" : "2861010145",
      "id" : 2861010145
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 105, 121 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/xUGj1i0gzV",
      "expanded_url" : "http:\/\/wp.me\/p4QwYD-HP",
      "display_url" : "wp.me\/p4QwYD-HP"
    } ]
  },
  "geo" : { },
  "id_str" : "621091413632151552",
  "text" : "RT @samdylanfinch: A Love Letter to Anyone and Everyone with a Mental Illness http:\/\/t.co\/xUGj1i0gzV via @wordpressdotcom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 86, 102 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/xUGj1i0gzV",
        "expanded_url" : "http:\/\/wp.me\/p4QwYD-HP",
        "display_url" : "wp.me\/p4QwYD-HP"
      } ]
    },
    "geo" : { },
    "id_str" : "621079510759280640",
    "text" : "A Love Letter to Anyone and Everyone with a Mental Illness http:\/\/t.co\/xUGj1i0gzV via @wordpressdotcom",
    "id" : 621079510759280640,
    "created_at" : "2015-07-14 22:11:09 +0000",
    "user" : {
      "name" : "Sam Dylan Finch",
      "screen_name" : "samdylanfinch",
      "protected" : false,
      "id_str" : "2861010145",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/931393398002483206\/gq4bbZEX_normal.jpg",
      "id" : 2861010145,
      "verified" : false
    }
  },
  "id" : 621091413632151552,
  "created_at" : "2015-07-14 22:58:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ho, but thankful",
      "screen_name" : "CathyReisenwitz",
      "indices" : [ 3, 19 ],
      "id_str" : "181720256",
      "id" : 181720256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/qSWU02WMUf",
      "expanded_url" : "https:\/\/medium.com\/@cathyreisenwitz\/what-porn-can-teach-us-about-good-copy-fae320a32b31?source=tw-1f7d04af6f63-1436913317829",
      "display_url" : "medium.com\/@cathyreisenwi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621087684002512896",
  "text" : "RT @CathyReisenwitz: \"Most everybody writes. Most everybody has sex. Not everyone should try to take it pro.\" https:\/\/t.co\/qSWU02WMUf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/qSWU02WMUf",
        "expanded_url" : "https:\/\/medium.com\/@cathyreisenwitz\/what-porn-can-teach-us-about-good-copy-fae320a32b31?source=tw-1f7d04af6f63-1436913317829",
        "display_url" : "medium.com\/@cathyreisenwi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "621085753976717312",
    "text" : "\"Most everybody writes. Most everybody has sex. Not everyone should try to take it pro.\" https:\/\/t.co\/qSWU02WMUf",
    "id" : 621085753976717312,
    "created_at" : "2015-07-14 22:35:57 +0000",
    "user" : {
      "name" : "Ho, but thankful",
      "screen_name" : "CathyReisenwitz",
      "protected" : false,
      "id_str" : "181720256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/885174676950876161\/FpR_Qd40_normal.jpg",
      "id" : 181720256,
      "verified" : true
    }
  },
  "id" : 621087684002512896,
  "created_at" : "2015-07-14 22:43:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "z",
      "screen_name" : "zebrafinch",
      "indices" : [ 24, 35 ],
      "id_str" : "19893071",
      "id" : 19893071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/vXNxMSzR0I",
      "expanded_url" : "https:\/\/twitter.com\/scienceblogtwit\/status\/621079764753903617",
      "display_url" : "twitter.com\/scienceblogtwi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "621083032129306624",
  "geo" : { },
  "id_str" : "621086643815059456",
  "in_reply_to_user_id" : 19893071,
  "text" : "What about sleeping? RT @zebrafinch: What\u2019s left, flying, hovering, hanging upside down, running in place?  https:\/\/t.co\/vXNxMSzR0I",
  "id" : 621086643815059456,
  "in_reply_to_status_id" : 621083032129306624,
  "created_at" : "2015-07-14 22:39:29 +0000",
  "in_reply_to_screen_name" : "zebrafinch",
  "in_reply_to_user_id_str" : "19893071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621079265933684737",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21782673999999, 16.37629444 ]
  },
  "id_str" : "621079539372924928",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy keep doing it and soon you can level up and do outdated 454 transcriptomes!",
  "id" : 621079539372924928,
  "in_reply_to_status_id" : 621079265933684737,
  "created_at" : "2015-07-14 22:11:15 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 3, 12 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACGT",
      "indices" : [ 48, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621062933196480512",
  "text" : "RT @kbradnam: Someone posted on reddit about my #ACGT post on the dangers of default parameters. It's provoking some discussion http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACGT",
        "indices" : [ 34, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/8Fwk7NZCz8",
        "expanded_url" : "http:\/\/buff.ly\/1TB2HD0",
        "display_url" : "buff.ly\/1TB2HD0"
      } ]
    },
    "geo" : { },
    "id_str" : "621061875170701312",
    "text" : "Someone posted on reddit about my #ACGT post on the dangers of default parameters. It's provoking some discussion http:\/\/t.co\/8Fwk7NZCz8",
    "id" : 621061875170701312,
    "created_at" : "2015-07-14 21:01:04 +0000",
    "user" : {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "protected" : false,
      "id_str" : "17061155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583756306919489538\/D2fFCYq4_normal.jpg",
      "id" : 17061155,
      "verified" : false
    }
  },
  "id" : 621062933196480512,
  "created_at" : "2015-07-14 21:05:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620983183773974528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20619909746355, 16.36440257508995 ]
  },
  "id_str" : "620983401668038656",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek yes, in front of Festsaal.",
  "id" : 620983401668038656,
  "in_reply_to_status_id" : 620983183773974528,
  "created_at" : "2015-07-14 15:49:14 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/620979046881566720\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/H3dy9p5hpw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ4pJxrWIAAAwoz.jpg",
      "id_str" : "620979046554411008",
      "id" : 620979046554411008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ4pJxrWIAAAwoz.jpg",
      "sizes" : [ {
        "h" : 1530,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 896,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/H3dy9p5hpw"
    } ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20614143899018, 16.36429811815558 ]
  },
  "id_str" : "620979046881566720",
  "text" : "team predictability vs. contingency club. #smbe15 http:\/\/t.co\/H3dy9p5hpw",
  "id" : 620979046881566720,
  "created_at" : "2015-07-14 15:31:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/620977587943251968\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/ynCQCJtZEA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ4n03gWwAAC4iC.jpg",
      "id_str" : "620977587830046720",
      "id" : 620977587830046720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ4n03gWwAAC4iC.jpg",
      "sizes" : [ {
        "h" : 1054,
        "resize" : "fit",
        "w" : 1054
      }, {
        "h" : 1054,
        "resize" : "fit",
        "w" : 1054
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1054,
        "resize" : "fit",
        "w" : 1054
      } ],
      "display_url" : "pic.twitter.com\/ynCQCJtZEA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620977587943251968",
  "text" : "Story of my life! http:\/\/t.co\/ynCQCJtZEA",
  "id" : 620977587943251968,
  "created_at" : "2015-07-14 15:26:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Take-Home Message",
      "screen_name" : "TakeHomeMessage",
      "indices" : [ 26, 42 ],
      "id_str" : "3226741196",
      "id" : 3226741196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 8, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/7joffO3gas",
      "expanded_url" : "http:\/\/takehomemessage.com\/post\/120296738065\/1-gatgctcctcctgaacgc",
      "display_url" : "takehomemessage.com\/post\/120296738\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20618366368954, 16.36464243551402 ]
  },
  "id_str" : "620976245321428993",
  "text" : "For the #smbe15 crowd: MT @TakeHomeMessage: A new web comic about biology with a focus on genomics &amp; bioinformatics http:\/\/t.co\/7joffO3gas",
  "id" : 620976245321428993,
  "created_at" : "2015-07-14 15:20:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/LQ89jzc73a",
      "expanded_url" : "https:\/\/twitter.com\/ee_reh_neh\/status\/620973094476349442",
      "display_url" : "twitter.com\/ee_reh_neh\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20618366855655, 16.36464243876909 ]
  },
  "id_str" : "620974341765902336",
  "text" : "This, so much. Second Generation Sequencing democratized genomic studies just as much as making stupid mistakes. https:\/\/t.co\/LQ89jzc73a",
  "id" : 620974341765902336,
  "created_at" : "2015-07-14 15:13:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    }, {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 9, 17 ],
      "id_str" : "454724555",
      "id" : 454724555
    }, {
      "name" : "Yoav Gilad",
      "screen_name" : "Y_Gilad",
      "indices" : [ 18, 26 ],
      "id_str" : "2802558480",
      "id" : 2802558480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620966832585969664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20617494709131, 16.36456747103269 ]
  },
  "id_str" : "620970051185823744",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek @marc_rr @Y_Gilad but at the same time you get lots of interesting contacts you otherwise never would have made.",
  "id" : 620970051185823744,
  "in_reply_to_status_id" : 620966832585969664,
  "created_at" : "2015-07-14 14:56:11 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620968972935135232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20615242340673, 16.36452979264467 ]
  },
  "id_str" : "620969245124509696",
  "in_reply_to_user_id" : 14286491,
  "text" : "SB: Approach 2: compare probabilistic models describing mutation &amp; selection processes. null: Poisson #smbe15",
  "id" : 620969245124509696,
  "in_reply_to_status_id" : 620968972935135232,
  "created_at" : "2015-07-14 14:52:59 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20615242340673, 16.36452979264467 ]
  },
  "id_str" : "620968972935135232",
  "text" : "SB: What's the null distribution of mutations? Approach 1: regression to identity variables that influence mutations: length, dS, \u2026  #smbe15",
  "id" : 620968972935135232,
  "created_at" : "2015-07-14 14:51:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20615242340673, 16.36452979264467 ]
  },
  "id_str" : "620968041585770496",
  "text" : "SB: Amount of parallel evolution is influenced by environment. #smbe15",
  "id" : 620968041585770496,
  "created_at" : "2015-07-14 14:48:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20615242340673, 16.36452979264467 ]
  },
  "id_str" : "620967796562882561",
  "text" : "Susan Bailey: the larger the scale (nucleotide, gene, function, phenotype, fitness), the more parallel evolution you find.  #smbe15",
  "id" : 620967796562882561,
  "created_at" : "2015-07-14 14:47:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/SVbKs4fvYN",
      "expanded_url" : "https:\/\/instagram.com\/p\/5HsilYBwkx\/",
      "display_url" : "instagram.com\/p\/5HsilYBwkx\/"
    } ]
  },
  "geo" : { },
  "id_str" : "620966071579877376",
  "text" : "mumok https:\/\/t.co\/SVbKs4fvYN",
  "id" : 620966071579877376,
  "created_at" : "2015-07-14 14:40:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20619785115053, 16.36454428128037 ]
  },
  "id_str" : "620964804308639744",
  "text" : "\u00ABWhat\u2019s different about feet compared to ear and tail?\u00BB That\u2019s the kind of biology I enjoy and can grasp. #smbe15",
  "id" : 620964804308639744,
  "created_at" : "2015-07-14 14:35:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Williams",
      "screen_name" : "JasonWilliamsNY",
      "indices" : [ 3, 19 ],
      "id_str" : "1692248610",
      "id" : 1692248610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620964105504092160",
  "text" : "RT @JasonWilliamsNY: You haven't coded in perl until you have done so in the original Klingon:  Lingua::tlhInganHol::yIghun http:\/\/t.co\/wyX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tlhInganHol",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/wyXGQ4kuHX",
        "expanded_url" : "http:\/\/search.cpan.org\/~mschwern\/Lingua-tlhInganHol-yIghun-20090601\/lib\/Lingua\/tlhInganHol\/yIghun.pm",
        "display_url" : "search.cpan.org\/~mschwern\/Ling\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "620963971584004096",
    "text" : "You haven't coded in perl until you have done so in the original Klingon:  Lingua::tlhInganHol::yIghun http:\/\/t.co\/wyXGQ4kuHX #tlhInganHol",
    "id" : 620963971584004096,
    "created_at" : "2015-07-14 14:32:02 +0000",
    "user" : {
      "name" : "Jason Williams",
      "screen_name" : "JasonWilliamsNY",
      "protected" : false,
      "id_str" : "1692248610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000457792547\/976107892eb908ea79dcb6e8a4c209f9_normal.jpeg",
      "id" : 1692248610,
      "verified" : false
    }
  },
  "id" : 620964105504092160,
  "created_at" : "2015-07-14 14:32:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "3D Printing News",
      "screen_name" : "3DPrintGirl",
      "indices" : [ 3, 15 ],
      "id_str" : "1949322637",
      "id" : 1949322637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/lnx5tH85sP",
      "expanded_url" : "http:\/\/3dprint.com\/81006\/hemp-3d-printer-filament\/",
      "display_url" : "3dprint.com\/81006\/hemp-3d-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620964054421606400",
  "text" : "RT @3DPrintGirl: Kan\u00E8sis Looks to Bring Hemp Filament to Market for 3D Printing Hemp Drones &amp; Much More http:\/\/t.co\/lnx5tH85sP http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/3DPrintGirl\/status\/620963722958213120\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/yQ9mSGsLDj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ4as_VVEAEsv6r.png",
        "id_str" : "620963158841167873",
        "id" : 620963158841167873,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ4as_VVEAEsv6r.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/yQ9mSGsLDj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/lnx5tH85sP",
        "expanded_url" : "http:\/\/3dprint.com\/81006\/hemp-3d-printer-filament\/",
        "display_url" : "3dprint.com\/81006\/hemp-3d-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "620963722958213120",
    "text" : "Kan\u00E8sis Looks to Bring Hemp Filament to Market for 3D Printing Hemp Drones &amp; Much More http:\/\/t.co\/lnx5tH85sP http:\/\/t.co\/yQ9mSGsLDj",
    "id" : 620963722958213120,
    "created_at" : "2015-07-14 14:31:03 +0000",
    "user" : {
      "name" : "3D Printing News",
      "screen_name" : "3DPrintGirl",
      "protected" : false,
      "id_str" : "1949322637",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000641439947\/778de2f93eaf9450956aa3c9547099b6_normal.jpeg",
      "id" : 1949322637,
      "verified" : false
    }
  },
  "id" : 620964054421606400,
  "created_at" : "2015-07-14 14:32:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20679975220047, 16.3646118169558 ]
  },
  "id_str" : "620905992235188225",
  "text" : "Killer X Killer shoots (its spores) first. #smbe15",
  "id" : 620905992235188225,
  "created_at" : "2015-07-14 10:41:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20618240575364, 16.364265900543 ]
  },
  "id_str" : "620902558220091392",
  "text" : "PF: find evidence for selection in lake or river, reduced gene flow and background selection. #smbe15",
  "id" : 620902558220091392,
  "created_at" : "2015-07-14 10:28:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20618240575364, 16.364265900543 ]
  },
  "id_str" : "620902194389323776",
  "text" : "PF: Tajima\u2019s D drops in highly diff. regions compared to genome wide. #smbe15",
  "id" : 620902194389323776,
  "created_at" : "2015-07-14 10:26:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20618240575364, 16.364265900543 ]
  },
  "id_str" : "620901831716290561",
  "text" : "PF: species pairs show continuum of differentiation between locations. Effective recombination rate correlates w\/ differentiation.  #smbe15",
  "id" : 620901831716290561,
  "created_at" : "2015-07-14 10:25:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20620986481715, 16.36434345427985 ]
  },
  "id_str" : "620901335647551489",
  "text" : "PF: Fst for species pairs differs highly between different locations. #smbe15",
  "id" : 620901335647551489,
  "created_at" : "2015-07-14 10:23:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20616616498958, 16.36434410945787 ]
  },
  "id_str" : "620900775607304192",
  "text" : "PF: river and lake habitats differ in parasite load, sticklebacks adapt to it. Sampled 5 river\/lake pairs, 6 fish each. #smbe15",
  "id" : 620900775607304192,
  "created_at" : "2015-07-14 10:20:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 122, 132 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20616616498958, 16.36434410945787 ]
  },
  "id_str" : "620900371825823744",
  "text" : "Now Philine Feulner about Stickleback evolution. She co-supervised me during my Bachelor\u2019s work. Acknowledgements include @fbnzimmer #smbe15",
  "id" : 620900371825823744,
  "created_at" : "2015-07-14 10:19:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20613623272946, 16.36437249043821 ]
  },
  "id_str" : "620891041173012480",
  "text" : "OH: \u00ABWill he show pictures of his children next?\u00BB \u2013 \u00ABOnly if they are published in Nature\u2026\u00BB",
  "id" : 620891041173012480,
  "created_at" : "2015-07-14 09:42:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620889693840908288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20613623272946, 16.36437249043821 ]
  },
  "id_str" : "620889872883167232",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 das ist in Kombination mit dem visuellen Auftreten des Autos so sch\u00F6n :)",
  "id" : 620889872883167232,
  "in_reply_to_status_id" : 620889693840908288,
  "created_at" : "2015-07-14 09:37:35 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620889241686573057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20616486380229, 16.36433369674786 ]
  },
  "id_str" : "620889337966796800",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 sieht ja ganz bezaubernd aus!",
  "id" : 620889337966796800,
  "in_reply_to_status_id" : 620889241686573057,
  "created_at" : "2015-07-14 09:35:28 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620888755113730048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20616486380229, 16.36433369674786 ]
  },
  "id_str" : "620888945547722752",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 schon der Stadt Offenbach geschrieben?",
  "id" : 620888945547722752,
  "in_reply_to_status_id" : 620888755113730048,
  "created_at" : "2015-07-14 09:33:54 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620873650133143552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20618473369601, 16.364210531289 ]
  },
  "id_str" : "620888513530195968",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 wtf?!",
  "id" : 620888513530195968,
  "in_reply_to_status_id" : 620873650133143552,
  "created_at" : "2015-07-14 09:32:11 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20699540601723, 16.36488085329367 ]
  },
  "id_str" : "620863335085514752",
  "text" : "Susann Wicke: differences in substitution rates correlate with being obligate\/facultative parasitic plant. #smbe15",
  "id" : 620863335085514752,
  "created_at" : "2015-07-14 07:52:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/8IjzXLtqUX",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/89",
      "display_url" : "existentialcomics.com\/comic\/89"
    } ]
  },
  "geo" : { },
  "id_str" : "620860159137611776",
  "text" : "ScienceCorp isn't returning our calls :( http:\/\/t.co\/8IjzXLtqUX",
  "id" : 620860159137611776,
  "created_at" : "2015-07-14 07:39:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/hmprOhzooW",
      "expanded_url" : "http:\/\/www.molecularecologist.com\/2015\/07\/genomics-the-four-headed-beast-of-big-data\/",
      "display_url" : "molecularecologist.com\/2015\/07\/genomi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620858483810922496",
  "text" : "the \u201Cfour-headed beast\u201D of Godzillaesk Genomic Data http:\/\/t.co\/hmprOhzooW",
  "id" : 620858483810922496,
  "created_at" : "2015-07-14 07:32:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 7, 21 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/0TGXdvwalu",
      "expanded_url" : "https:\/\/www.scoutsforequality.org\/scouting\/boy-scouts-of-americas-executive-committee-unanimously-approves-end-to-ban-on-gay-adults\/",
      "display_url" : "scoutsforequality.org\/scouting\/boy-s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "620832629647020032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.206831957036, 16.36460695577534 ]
  },
  "id_str" : "620854270901002240",
  "in_reply_to_user_id" : 5746882,
  "text" : "\uD83D\uDE0D\u26FA\uFE0F RT @beaugunderson: pretty cool news re: removing the ban on openly gay or bisexual adults in the boy scouts: https:\/\/t.co\/0TGXdvwalu",
  "id" : 620854270901002240,
  "in_reply_to_status_id" : 620832629647020032,
  "created_at" : "2015-07-14 07:16:07 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 38, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/8GltB98Sid",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/620765757773713408",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20613082532807, 16.36446793201611 ]
  },
  "id_str" : "620850966347284480",
  "text" : "Maybe of interest for participants of #smbe15, after all diversity is a topic here as well https:\/\/t.co\/8GltB98Sid",
  "id" : 620850966347284480,
  "created_at" : "2015-07-14 07:02:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OfficialSMBE",
      "screen_name" : "OfficialSMBE",
      "indices" : [ 0, 13 ],
      "id_str" : "1120098811",
      "id" : 1120098811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620720135901478916",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21650782814191, 16.37601238288254 ]
  },
  "id_str" : "620720675532218368",
  "in_reply_to_user_id" : 1120098811,
  "text" : "@OfficialSMBE thx, will do :)",
  "id" : 620720675532218368,
  "in_reply_to_status_id" : 620720135901478916,
  "created_at" : "2015-07-13 22:25:16 +0000",
  "in_reply_to_screen_name" : "OfficialSMBE",
  "in_reply_to_user_id_str" : "1120098811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/620715010591981568\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/YrJsGbvLzL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ05AqMWUAACw4a.jpg",
      "id_str" : "620715007135862784",
      "id" : 620715007135862784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ05AqMWUAACw4a.jpg",
      "sizes" : [ {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/YrJsGbvLzL"
    } ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 27, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21668853056451, 16.3760833908025 ]
  },
  "id_str" : "620715010591981568",
  "text" : "care-\u2018not actually a bear\u2019 #smbe15 http:\/\/t.co\/YrJsGbvLzL",
  "id" : 620715010591981568,
  "created_at" : "2015-07-13 22:02:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 37, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/w9lgLwnyYR",
      "expanded_url" : "https:\/\/instagram.com\/p\/5FXCJdhwgU\/",
      "display_url" : "instagram.com\/p\/5FXCJdhwgU\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.206241361, 16.364417753 ]
  },
  "id_str" : "620637303250288640",
  "text" : "The next impressive conference venue #smbe15 @ Hofburg Palace Wien https:\/\/t.co\/w9lgLwnyYR",
  "id" : 620637303250288640,
  "created_at" : "2015-07-13 16:53:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OfficialSMBE",
      "screen_name" : "OfficialSMBE",
      "indices" : [ 0, 13 ],
      "id_str" : "1120098811",
      "id" : 1120098811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20660083182779, 16.36506776740997 ]
  },
  "id_str" : "620634719340863488",
  "in_reply_to_user_id" : 1120098811,
  "text" : "@OfficialSMBE is there really no food except fruit for vegans at the conference venue?",
  "id" : 620634719340863488,
  "created_at" : "2015-07-13 16:43:42 +0000",
  "in_reply_to_screen_name" : "OfficialSMBE",
  "in_reply_to_user_id_str" : "1120098811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Barton",
      "screen_name" : "bioinformatics",
      "indices" : [ 0, 15 ],
      "id_str" : "14126701",
      "id" : 14126701
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 16, 24 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620632577410338816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.208402661078, 16.36693967222545 ]
  },
  "id_str" : "620634273087913987",
  "in_reply_to_user_id" : 14126701,
  "text" : "@bioinformatics @kaiblin sure, happy to help out. :)",
  "id" : 620634273087913987,
  "in_reply_to_status_id" : 620632577410338816,
  "created_at" : "2015-07-13 16:41:56 +0000",
  "in_reply_to_screen_name" : "bioinformatics",
  "in_reply_to_user_id_str" : "14126701",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Michael Barton",
      "screen_name" : "bioinformatics",
      "indices" : [ 9, 24 ],
      "id_str" : "14126701",
      "id" : 14126701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/c7wMc0zVUH",
      "expanded_url" : "http:\/\/www.biomedcentral.com\/1471-2105\/14\/S14\/S5\/",
      "display_url" : "biomedcentral.com\/1471-2105\/14\/S\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "620607870204256256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20671743309732, 16.36485134464715 ]
  },
  "id_str" : "620609422381961216",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @bioinformatics  for link rot in general see http:\/\/t.co\/c7wMc0zVUH",
  "id" : 620609422381961216,
  "in_reply_to_status_id" : 620607870204256256,
  "created_at" : "2015-07-13 15:03:11 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 3, 15 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "ps",
      "screen_name" : "PatSchloss",
      "indices" : [ 69, 80 ],
      "id_str" : "185631499",
      "id" : 185631499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/CenasgnTTE",
      "expanded_url" : "http:\/\/blog.mothur.org\/2014\/09\/11\/Why-such-a-large-distance-matrix%3F\/",
      "display_url" : "blog.mothur.org\/2014\/09\/11\/Why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620607701115138049",
  "text" : "RT @ctitusbrown: Ran into someone who did this and (independently of @PatSchloss) concluded it was dumb: http:\/\/t.co\/CenasgnTTE - good indi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ps",
        "screen_name" : "PatSchloss",
        "indices" : [ 52, 63 ],
        "id_str" : "185631499",
        "id" : 185631499
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/CenasgnTTE",
        "expanded_url" : "http:\/\/blog.mothur.org\/2014\/09\/11\/Why-such-a-large-distance-matrix%3F\/",
        "display_url" : "blog.mothur.org\/2014\/09\/11\/Why\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "620606757602115584",
    "text" : "Ran into someone who did this and (independently of @PatSchloss) concluded it was dumb: http:\/\/t.co\/CenasgnTTE - good indicator ;)",
    "id" : 620606757602115584,
    "created_at" : "2015-07-13 14:52:35 +0000",
    "user" : {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "protected" : false,
      "id_str" : "26616462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662714429742514176\/bwLg2tBG_normal.jpg",
      "id" : 26616462,
      "verified" : false
    }
  },
  "id" : 620607701115138049,
  "created_at" : "2015-07-13 14:56:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20671929418938, 16.36483186399416 ]
  },
  "id_str" : "620600817897336832",
  "text" : "Still unsure on whether it shouldn\u2019t be \u00ABshorter \u2018genes\u2019 appear to be younger as they are bioinformatics artifacts\u00BB. #smbe15",
  "id" : 620600817897336832,
  "created_at" : "2015-07-13 14:28:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Michael Barton",
      "screen_name" : "bioinformatics",
      "indices" : [ 9, 24 ],
      "id_str" : "14126701",
      "id" : 14126701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/nEfyGF0KQz",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0024914",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "620596234949132288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20671929418938, 16.36483186399416 ]
  },
  "id_str" : "620599962943012865",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @bioinformatics this one is for web services http:\/\/t.co\/nEfyGF0KQz",
  "id" : 620599962943012865,
  "in_reply_to_status_id" : 620596234949132288,
  "created_at" : "2015-07-13 14:25:36 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PacBio",
      "screen_name" : "PacBio",
      "indices" : [ 57, 64 ],
      "id_str" : "39694489",
      "id" : 39694489
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20668696094275, 16.36538467393146 ]
  },
  "id_str" : "620585951316824065",
  "text" : "Most asked question regarding my poster: \u00ABHave you tried @PacBio?\u00BB yes, we did! #smbe15",
  "id" : 620585951316824065,
  "created_at" : "2015-07-13 13:29:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620567660699496448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20669887243121, 16.36539325612759 ]
  },
  "id_str" : "620571099563196416",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek 514B is my number. When heading upstairs turn right and right again, go past the bar and you are in he right room.",
  "id" : 620571099563196416,
  "in_reply_to_status_id" : 620567660699496448,
  "created_at" : "2015-07-13 12:30:54 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 38, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20668892513429, 16.36538317252027 ]
  },
  "id_str" : "620567255378735104",
  "text" : "Now for some (im)poster presentation. #smbe15",
  "id" : 620567255378735104,
  "created_at" : "2015-07-13 12:15:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rebecca dikow",
      "screen_name" : "rdikow",
      "indices" : [ 0, 7 ],
      "id_str" : "54937895",
      "id" : 54937895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620465103410958336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20674268719028, 16.36492959293376 ]
  },
  "id_str" : "620542088707461120",
  "in_reply_to_user_id" : 54937895,
  "text" : "@rdikow very cool work, I like the idea!",
  "id" : 620542088707461120,
  "in_reply_to_status_id" : 620465103410958336,
  "created_at" : "2015-07-13 10:35:37 +0000",
  "in_reply_to_screen_name" : "rdikow",
  "in_reply_to_user_id_str" : "54937895",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konrad F\u00F6rstner",
      "screen_name" : "konradfoerstner",
      "indices" : [ 3, 19 ],
      "id_str" : "15150655",
      "id" : 15150655
    }, {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 92, 101 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Nomi Harris",
      "screen_name" : "NomiHarris",
      "indices" : [ 107, 118 ],
      "id_str" : "351049850",
      "id" : 351049850
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 123, 131 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 24, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/mz1YY2gcV5",
      "expanded_url" : "http:\/\/thedaoofflow.fluxionary.net\/2015\/07\/bosc-2015-wrap-up\/",
      "display_url" : "thedaoofflow.fluxionary.net\/2015\/07\/bosc-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620541742207627264",
  "text" : "RT @konradfoerstner: My #BOSC2015 wrap up http:\/\/t.co\/mz1YY2gcV5. Once again many thanks to @OBF_BOSC esp. @NomiHarris and @pjacock for thi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BOSC",
        "screen_name" : "OBF_BOSC",
        "indices" : [ 71, 80 ],
        "id_str" : "583180584",
        "id" : 583180584
      }, {
        "name" : "Nomi Harris",
        "screen_name" : "NomiHarris",
        "indices" : [ 86, 97 ],
        "id_str" : "351049850",
        "id" : 351049850
      }, {
        "name" : "Peter Cock",
        "screen_name" : "pjacock",
        "indices" : [ 102, 110 ],
        "id_str" : "58756672",
        "id" : 58756672
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2015",
        "indices" : [ 3, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/mz1YY2gcV5",
        "expanded_url" : "http:\/\/thedaoofflow.fluxionary.net\/2015\/07\/bosc-2015-wrap-up\/",
        "display_url" : "thedaoofflow.fluxionary.net\/2015\/07\/bosc-2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "620511150569058305",
    "text" : "My #BOSC2015 wrap up http:\/\/t.co\/mz1YY2gcV5. Once again many thanks to @OBF_BOSC esp. @NomiHarris and @pjacock for this great meeting!",
    "id" : 620511150569058305,
    "created_at" : "2015-07-13 08:32:41 +0000",
    "user" : {
      "name" : "Konrad F\u00F6rstner",
      "screen_name" : "konradfoerstner",
      "protected" : false,
      "id_str" : "15150655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895375230281158656\/gXjAenaZ_normal.jpg",
      "id" : 15150655,
      "verified" : false
    }
  },
  "id" : 620541742207627264,
  "created_at" : "2015-07-13 10:34:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lionel Guy",
      "screen_name" : "LionelGuy",
      "indices" : [ 3, 13 ],
      "id_str" : "532932119",
      "id" : 532932119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/bDpnXmQFFn",
      "expanded_url" : "http:\/\/genev.unige.ch\/en\/users\/Juan-Montoya\/unit",
      "display_url" : "genev.unige.ch\/en\/users\/Juan-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620535978915176448",
  "text" : "RT @LionelGuy: CJRR: LS3 pipeline seemingly available here http:\/\/t.co\/bDpnXmQFFn #smbe15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "smbe15",
        "indices" : [ 67, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/bDpnXmQFFn",
        "expanded_url" : "http:\/\/genev.unige.ch\/en\/users\/Juan-Montoya\/unit",
        "display_url" : "genev.unige.ch\/en\/users\/Juan-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "620535632813756416",
    "text" : "CJRR: LS3 pipeline seemingly available here http:\/\/t.co\/bDpnXmQFFn #smbe15",
    "id" : 620535632813756416,
    "created_at" : "2015-07-13 10:09:58 +0000",
    "user" : {
      "name" : "Lionel Guy",
      "screen_name" : "LionelGuy",
      "protected" : false,
      "id_str" : "532932119",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/912703440060633088\/-yR6IeXi_normal.jpg",
      "id" : 532932119,
      "verified" : false
    }
  },
  "id" : 620535978915176448,
  "created_at" : "2015-07-13 10:11:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa WilsonSayres",
      "screen_name" : "mwilsonsayres",
      "indices" : [ 3, 17 ],
      "id_str" : "143086518",
      "id" : 143086518
    }, {
      "name" : "J.J. Emerson",
      "screen_name" : "JJ_Emerson",
      "indices" : [ 20, 31 ],
      "id_str" : "9618642",
      "id" : 9618642
    }, {
      "name" : "OfficialSMBE",
      "screen_name" : "OfficialSMBE",
      "indices" : [ 119, 132 ],
      "id_str" : "1120098811",
      "id" : 1120098811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620531705439481856",
  "text" : "RT @mwilsonsayres: .@JJ_Emerson &amp; I tabulated gender dist of speakers at #smbe15. \nConclusions: 61%M 39%F. Not bad @OfficialSMBE! http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "J.J. Emerson",
        "screen_name" : "JJ_Emerson",
        "indices" : [ 1, 12 ],
        "id_str" : "9618642",
        "id" : 9618642
      }, {
        "name" : "OfficialSMBE",
        "screen_name" : "OfficialSMBE",
        "indices" : [ 100, 113 ],
        "id_str" : "1120098811",
        "id" : 1120098811
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mwilsonsayres\/status\/620530051151327232\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/LeCGY8ugv7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJyQWZmUwAAQ0A2.png",
        "id_str" : "620529563173437440",
        "id" : 620529563173437440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJyQWZmUwAAQ0A2.png",
        "sizes" : [ {
          "h" : 513,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/LeCGY8ugv7"
      } ],
      "hashtags" : [ {
        "text" : "smbe15",
        "indices" : [ 58, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620530051151327232",
    "text" : ".@JJ_Emerson &amp; I tabulated gender dist of speakers at #smbe15. \nConclusions: 61%M 39%F. Not bad @OfficialSMBE! http:\/\/t.co\/LeCGY8ugv7",
    "id" : 620530051151327232,
    "created_at" : "2015-07-13 09:47:47 +0000",
    "user" : {
      "name" : "Melissa WilsonSayres",
      "screen_name" : "mwilsonsayres",
      "protected" : false,
      "id_str" : "143086518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/850459123124641792\/29LRtOHv_normal.jpg",
      "id" : 143086518,
      "verified" : false
    }
  },
  "id" : 620531705439481856,
  "created_at" : "2015-07-13 09:54:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620528799344644096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20663410330427, 16.36498851909921 ]
  },
  "id_str" : "620529123300147200",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek TEs are also like online ads: jumping up and down, screaming to get attention. :p",
  "id" : 620529123300147200,
  "in_reply_to_status_id" : 620528799344644096,
  "created_at" : "2015-07-13 09:44:06 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 3, 11 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620528868059934720",
  "text" : "RT @PhdGeek: Genome is like a free magazine. Mostly ads (transposons), few articles (genes), but ads are needed for mag to survive (TEs nee\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "smbe15",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620528799344644096",
    "text" : "Genome is like a free magazine. Mostly ads (transposons), few articles (genes), but ads are needed for mag to survive (TEs needed) #smbe15",
    "id" : 620528799344644096,
    "created_at" : "2015-07-13 09:42:49 +0000",
    "user" : {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "protected" : false,
      "id_str" : "27841081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745191411327328256\/PI3LgJTF_normal.jpg",
      "id" : 27841081,
      "verified" : false
    }
  },
  "id" : 620528868059934720,
  "created_at" : "2015-07-13 09:43:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Jane McTavish",
      "screen_name" : "snacktavish",
      "indices" : [ 3, 15 ],
      "id_str" : "245545600",
      "id" : 245545600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620523458036953088",
  "text" : "RT @snacktavish: Gascuel: data deluge requires fast algorithms and therefore simple models.  Least squares for dating large phylogenies. #S\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SMBE15",
        "indices" : [ 120, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620523183540686848",
    "text" : "Gascuel: data deluge requires fast algorithms and therefore simple models.  Least squares for dating large phylogenies. #SMBE15",
    "id" : 620523183540686848,
    "created_at" : "2015-07-13 09:20:30 +0000",
    "user" : {
      "name" : "Emily Jane McTavish",
      "screen_name" : "snacktavish",
      "protected" : false,
      "id_str" : "245545600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654415498248101888\/88H_VRxq_normal.jpg",
      "id" : 245545600,
      "verified" : false
    }
  },
  "id" : 620523458036953088,
  "created_at" : "2015-07-13 09:21:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 3, 15 ],
      "id_str" : "208988759",
      "id" : 208988759
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 33, 42 ]
    }, {
      "text" : "ISMB2015",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/aaG7sNquNB",
      "expanded_url" : "http:\/\/blogs.biomedcentral.com\/gigablog\/2015\/07\/12\/open-bioinformatics-irish-free-software-state\/",
      "display_url" : "blogs.biomedcentral.com\/gigablog\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620523224397422592",
  "text" : "RT @GigaScience: Our write-up of #bosc2015 Open Bioinformatics in The Irish Free Software State http:\/\/t.co\/aaG7sNquNB #ISMB2015 http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GigaScience\/status\/620513767483379713\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/0OkN1G1SRE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJyB-31UsAA6quN.jpg",
        "id_str" : "620513765809762304",
        "id" : 620513765809762304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJyB-31UsAA6quN.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/0OkN1G1SRE"
      } ],
      "hashtags" : [ {
        "text" : "bosc2015",
        "indices" : [ 16, 25 ]
      }, {
        "text" : "ISMB2015",
        "indices" : [ 102, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/aaG7sNquNB",
        "expanded_url" : "http:\/\/blogs.biomedcentral.com\/gigablog\/2015\/07\/12\/open-bioinformatics-irish-free-software-state\/",
        "display_url" : "blogs.biomedcentral.com\/gigablog\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "620513767483379713",
    "text" : "Our write-up of #bosc2015 Open Bioinformatics in The Irish Free Software State http:\/\/t.co\/aaG7sNquNB #ISMB2015 http:\/\/t.co\/0OkN1G1SRE",
    "id" : 620513767483379713,
    "created_at" : "2015-07-13 08:43:05 +0000",
    "user" : {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "protected" : false,
      "id_str" : "208988759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1404305552\/profile-photo-GigaScience-96x96_normal.jpg",
      "id" : 208988759,
      "verified" : false
    }
  },
  "id" : 620523224397422592,
  "created_at" : "2015-07-13 09:20:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OfficialSMBE",
      "screen_name" : "OfficialSMBE",
      "indices" : [ 13, 26 ],
      "id_str" : "1120098811",
      "id" : 1120098811
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/620522279483645952\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/iuFV1K5fHR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJyJuCLWsAArEXg.jpg",
      "id_str" : "620522272621768704",
      "id" : 620522272621768704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJyJuCLWsAArEXg.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/iuFV1K5fHR"
    } ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20675721077668, 16.36477035763829 ]
  },
  "id_str" : "620522279483645952",
  "text" : "Here you go, @OfficialSMBE. #smbe15 http:\/\/t.co\/iuFV1K5fHR",
  "id" : 620522279483645952,
  "created_at" : "2015-07-13 09:16:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zhouqi",
      "screen_name" : "wudinger",
      "indices" : [ 3, 12 ],
      "id_str" : "58003330",
      "id" : 58003330
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wudinger\/status\/620512289893040128\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/jAZyoSWnwu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJyAopTWwAAhQz1.jpg",
      "id_str" : "620512284440444928",
      "id" : 620512284440444928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJyAopTWwAAhQz1.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/jAZyoSWnwu"
    } ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620512787840659456",
  "text" : "RT @wudinger: Wow, how many people are tweeting #smbe15 http:\/\/t.co\/jAZyoSWnwu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wudinger\/status\/620512289893040128\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/jAZyoSWnwu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJyAopTWwAAhQz1.jpg",
        "id_str" : "620512284440444928",
        "id" : 620512284440444928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJyAopTWwAAhQz1.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/jAZyoSWnwu"
      } ],
      "hashtags" : [ {
        "text" : "smbe15",
        "indices" : [ 34, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620512289893040128",
    "text" : "Wow, how many people are tweeting #smbe15 http:\/\/t.co\/jAZyoSWnwu",
    "id" : 620512289893040128,
    "created_at" : "2015-07-13 08:37:13 +0000",
    "user" : {
      "name" : "zhouqi",
      "screen_name" : "wudinger",
      "protected" : false,
      "id_str" : "58003330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568851374448705536\/oCNdq_mS_normal.jpeg",
      "id" : 58003330,
      "verified" : false
    }
  },
  "id" : 620512787840659456,
  "created_at" : "2015-07-13 08:39:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20673903382887, 16.36483292634032 ]
  },
  "id_str" : "620512467039449088",
  "text" : "HS: developed ParConsel for partition-aware testing #smbe15",
  "id" : 620512467039449088,
  "created_at" : "2015-07-13 08:37:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20673903382887, 16.36483292634032 ]
  },
  "id_str" : "620511329263202304",
  "text" : "HS: The more genes and models we have, the higher the variance\/larger the tree space. #smbe15",
  "id" : 620511329263202304,
  "created_at" : "2015-07-13 08:33:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20673903382887, 16.36483292634032 ]
  },
  "id_str" : "620510980716535808",
  "text" : "Now: Heiko Schmidt on partition-aware tree testing #smbe15",
  "id" : 620510980716535808,
  "created_at" : "2015-07-13 08:32:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 3, 11 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/NSzuW2AAas",
      "expanded_url" : "https:\/\/twitter.com\/GenomeAnalysis\/status\/620291543602106369",
      "display_url" : "twitter.com\/GenomeAnalysis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620508385247666176",
  "text" : "RT @glyn_dk: Yay for women in bioinformatics!  https:\/\/t.co\/NSzuW2AAas",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/NSzuW2AAas",
        "expanded_url" : "https:\/\/twitter.com\/GenomeAnalysis\/status\/620291543602106369",
        "display_url" : "twitter.com\/GenomeAnalysis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "620490276642144256",
    "text" : "Yay for women in bioinformatics!  https:\/\/t.co\/NSzuW2AAas",
    "id" : 620490276642144256,
    "created_at" : "2015-07-13 07:09:44 +0000",
    "user" : {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "protected" : false,
      "id_str" : "32340834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3409523398\/35ae8a97e778ebb56089e9a9b58ab9b1_normal.png",
      "id" : 32340834,
      "verified" : false
    }
  },
  "id" : 620508385247666176,
  "created_at" : "2015-07-13 08:21:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/Q1nUxdCcms",
      "expanded_url" : "https:\/\/instagram.com\/p\/5EcNnnhwhq\/",
      "display_url" : "instagram.com\/p\/5EcNnnhwhq\/"
    } ]
  },
  "geo" : { },
  "id_str" : "620507954521968640",
  "text" : "Overhead https:\/\/t.co\/Q1nUxdCcms",
  "id" : 620507954521968640,
  "created_at" : "2015-07-13 08:19:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yves Clement",
      "screen_name" : "TwelveSharp",
      "indices" : [ 3, 15 ],
      "id_str" : "519952673",
      "id" : 519952673
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620500691270926336",
  "text" : "RT @TwelveSharp: TW: ASTRAL works better with high ILS &amp; short branches, contatenation is best method for low amounts of ILS #smbe15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "smbe15",
        "indices" : [ 112, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620496942804639744",
    "text" : "TW: ASTRAL works better with high ILS &amp; short branches, contatenation is best method for low amounts of ILS #smbe15",
    "id" : 620496942804639744,
    "created_at" : "2015-07-13 07:36:14 +0000",
    "user" : {
      "name" : "Yves Clement",
      "screen_name" : "TwelveSharp",
      "protected" : false,
      "id_str" : "519952673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/814538637576699910\/38UEmx2b_normal.jpg",
      "id" : 519952673,
      "verified" : false
    }
  },
  "id" : 620500691270926336,
  "created_at" : "2015-07-13 07:51:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20664342741367, 16.36477339956284 ]
  },
  "id_str" : "620498596450992128",
  "text" : "\u00ABConcatenation is not evil.\u00BB (at least if ILS is not too frequent). #smbe15",
  "id" : 620498596450992128,
  "created_at" : "2015-07-13 07:42:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20664342741367, 16.36477339956284 ]
  },
  "id_str" : "620498403361976320",
  "text" : "One of the best things about #smbe15: so many cool science tattoos!",
  "id" : 620498403361976320,
  "created_at" : "2015-07-13 07:42:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cobi Smith",
      "screen_name" : "cobismith",
      "indices" : [ 0, 10 ],
      "id_str" : "26703939",
      "id" : 26703939
    }, {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 11, 20 ],
      "id_str" : "224631899",
      "id" : 224631899
    }, {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 21, 30 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Harriet Dashnow",
      "screen_name" : "hdashnow",
      "indices" : [ 31, 40 ],
      "id_str" : "20126211",
      "id" : 20126211
    }, {
      "name" : "Timothy D. Smith",
      "screen_name" : "tim_d_smith",
      "indices" : [ 41, 53 ],
      "id_str" : "17982159",
      "id" : 17982159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620495524030877700",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20668576712087, 16.36480167779081 ]
  },
  "id_str" : "620497912506785792",
  "in_reply_to_user_id" : 26703939,
  "text" : "@cobismith @figshare @OBF_BOSC @hdashnow @tim_d_smith sure, always happy to share and talk about it!",
  "id" : 620497912506785792,
  "in_reply_to_status_id" : 620495524030877700,
  "created_at" : "2015-07-13 07:40:05 +0000",
  "in_reply_to_screen_name" : "cobismith",
  "in_reply_to_user_id_str" : "26703939",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 8, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/SDESsWR9QC",
      "expanded_url" : "https:\/\/instagram.com\/p\/5EO8_aBwhS\/",
      "display_url" : "instagram.com\/p\/5EO8_aBwhS\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.207337325, 16.365287924 ]
  },
  "id_str" : "620478796542685184",
  "text" : "Back to #smbe15 @ Hofburg Imperial Palace https:\/\/t.co\/SDESsWR9QC",
  "id" : 620478796542685184,
  "created_at" : "2015-07-13 06:24:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21645206665427, 16.3760394150688 ]
  },
  "id_str" : "620349419955859460",
  "text" : "\u00ABOh, Mr. Important added his Twitter handle to his #smbe15 name tag. Tell me, do you have more followers than David Beckham?\u00BB",
  "id" : 620349419955859460,
  "created_at" : "2015-07-12 21:50:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.2073639557288, 16.36537318372835 ]
  },
  "id_str" : "620309364965003264",
  "text" : "\u00ABCome on, tell me how much of an idiot I am. I see you not doing it is eating you alive.\u00BB",
  "id" : 620309364965003264,
  "created_at" : "2015-07-12 19:10:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20618996781747, 16.36409774641993 ]
  },
  "id_str" : "620272135416737792",
  "text" : "JF: \u00ABTo me energy is like the little yellow dots from PacMan.\u00BB #smbe15",
  "id" : 620272135416737792,
  "created_at" : "2015-07-12 16:42:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SMBE15",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20881652610369, 16.36054992992853 ]
  },
  "id_str" : "620270401277530112",
  "text" : "Felsenstein: \u00ABthis is not an endorsement of pan-selectionism (sorry ENCODE)\u00BB #SMBE15",
  "id" : 620270401277530112,
  "created_at" : "2015-07-12 16:36:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Stajich",
      "screen_name" : "hyphaltip",
      "indices" : [ 0, 10 ],
      "id_str" : "14324284",
      "id" : 14324284
    }, {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "indices" : [ 11, 20 ],
      "id_str" : "1205345400",
      "id" : 1205345400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620265924457852929",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20616411123454, 16.36434405922822 ]
  },
  "id_str" : "620267617564147712",
  "in_reply_to_user_id" : 14324284,
  "text" : "@hyphaltip @DanGraur poster sessions will be done waltzing back and forth in front of them.",
  "id" : 620267617564147712,
  "in_reply_to_status_id" : 620265924457852929,
  "created_at" : "2015-07-12 16:24:58 +0000",
  "in_reply_to_screen_name" : "hyphaltip",
  "in_reply_to_user_id_str" : "14324284",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20617075139784, 16.36428722698099 ]
  },
  "id_str" : "620262996355469312",
  "text" : "\u00ABSummer is migratory season for scientists.\u00BB\u2014\u00ABOf late if feels like every season is migratory season.\u00BB",
  "id" : 620262996355469312,
  "created_at" : "2015-07-12 16:06:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 14, 24 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "somersault1824",
      "screen_name" : "somersault1824",
      "indices" : [ 58, 73 ],
      "id_str" : "550497986",
      "id" : 550497986
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/9UDk2UGZ5k",
      "expanded_url" : "https:\/\/www.etsy.com\/shop\/somersault1824",
      "display_url" : "etsy.com\/shop\/somersaul\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21474028092567, 16.37516937099829 ]
  },
  "id_str" : "620243523414134784",
  "text" : "same here! RT @eltonjohn: awesome scientific jewellery by @somersault1824: https:\/\/t.co\/9UDk2UGZ5k (future and current boyfriends take note)",
  "id" : 620243523414134784,
  "created_at" : "2015-07-12 14:49:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liana Lareau",
      "screen_name" : "lianafaye",
      "indices" : [ 0, 10 ],
      "id_str" : "188520661",
      "id" : 188520661
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ismbeccb15",
      "indices" : [ 82, 93 ]
    }, {
      "text" : "smbe15",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620214096626065408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.2146074874987, 16.37476343905101 ]
  },
  "id_str" : "620239859458961412",
  "in_reply_to_user_id" : 188520661,
  "text" : "@lianafaye oh, I wasn\u2019t aware there were others. I only met people who weren\u2019t at #ismbeccb15 but were on their way to #smbe15 :)",
  "id" : 620239859458961412,
  "in_reply_to_status_id" : 620214096626065408,
  "created_at" : "2015-07-12 14:34:40 +0000",
  "in_reply_to_screen_name" : "lianafaye",
  "in_reply_to_user_id_str" : "188520661",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21466217492292, 16.37491418285936 ]
  },
  "id_str" : "620237815754977280",
  "text" : "Vienna so far: a random stranger very kindly offered to scratch my back and stroke my hair.",
  "id" : 620237815754977280,
  "created_at" : "2015-07-12 14:26:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 0, 9 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620191988827164672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21460055381272, 16.37464421219546 ]
  },
  "id_str" : "620233938162683905",
  "in_reply_to_user_id" : 583180584,
  "text" : "@OBF_BOSC thanks for all the work you put into this. One of best conferences I\u2019ve been to so far. Hope to see you some place not-Orlando. ;)",
  "id" : 620233938162683905,
  "in_reply_to_status_id" : 620191988827164672,
  "created_at" : "2015-07-12 14:11:08 +0000",
  "in_reply_to_screen_name" : "OBF_BOSC",
  "in_reply_to_user_id_str" : "583180584",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/UBl4213Vcd",
      "expanded_url" : "https:\/\/instagram.com\/p\/5CfRRIBwuV\/",
      "display_url" : "instagram.com\/p\/5CfRRIBwuV\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20790428, 16.371657469 ]
  },
  "id_str" : "620233202771316736",
  "text" : "Sightseeing @ Stephansplatz https:\/\/t.co\/UBl4213Vcd",
  "id" : 620233202771316736,
  "created_at" : "2015-07-12 14:08:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/YkKiVvAQYJ",
      "expanded_url" : "https:\/\/instagram.com\/p\/5CeMwcBwse\/",
      "display_url" : "instagram.com\/p\/5CeMwcBwse\/"
    } ]
  },
  "geo" : { },
  "id_str" : "620230848357470209",
  "text" : "Clash of Cultures https:\/\/t.co\/YkKiVvAQYJ",
  "id" : 620230848357470209,
  "created_at" : "2015-07-12 13:58:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linus Schumacher",
      "screen_name" : "LinusSchumacher",
      "indices" : [ 0, 16 ],
      "id_str" : "2289913051",
      "id" : 2289913051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620192521210232832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21645865687003, 16.37611809188163 ]
  },
  "id_str" : "620194185480679424",
  "in_reply_to_user_id" : 2289913051,
  "text" : "@LinusSchumacher I don\u2019t do conference shirts ;)",
  "id" : 620194185480679424,
  "in_reply_to_status_id" : 620192521210232832,
  "created_at" : "2015-07-12 11:33:11 +0000",
  "in_reply_to_screen_name" : "LinusSchumacher",
  "in_reply_to_user_id_str" : "2289913051",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linus Schumacher",
      "screen_name" : "LinusSchumacher",
      "indices" : [ 0, 16 ],
      "id_str" : "2289913051",
      "id" : 2289913051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620192224974872577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.21633295338186, 16.37575094054236 ]
  },
  "id_str" : "620192335452835840",
  "in_reply_to_user_id" : 2289913051,
  "text" : "@LinusSchumacher but then you lose the benefit of running into people. ;)",
  "id" : 620192335452835840,
  "in_reply_to_status_id" : 620192224974872577,
  "created_at" : "2015-07-12 11:25:50 +0000",
  "in_reply_to_screen_name" : "LinusSchumacher",
  "in_reply_to_user_id_str" : "2289913051",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.20732875265945, 16.38072009199893 ]
  },
  "id_str" : "620176065097527296",
  "text" : "As much as I hate carrying posters to conferences: never fails to kickstart conversations with peers while on plane\/public transport.",
  "id" : 620176065097527296,
  "created_at" : "2015-07-12 10:21:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 11, 21 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620161214165835776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.11911258220558, 16.56176049074456 ]
  },
  "id_str" : "620161964086554624",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko @biocrusoe now for the fun part: did my luggage arrive as well. ;)",
  "id" : 620161964086554624,
  "in_reply_to_status_id" : 620161214165835776,
  "created_at" : "2015-07-12 09:25:08 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 11, 21 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620138187760009216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.11903467282366, 16.56116053153103 ]
  },
  "id_str" : "620160026859192320",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko @biocrusoe made it safely to Vienna! :)",
  "id" : 620160026859192320,
  "in_reply_to_status_id" : 620138187760009216,
  "created_at" : "2015-07-12 09:17:27 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 43, 52 ]
    }, {
      "text" : "SMBE15",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.42392294403157, -6.24348082389192 ]
  },
  "id_str" : "620104008204689408",
  "text" : "Now waiting for EI660, DUB \u2708\uFE0F VIE. Goodbye #bosc2015, Welcome #SMBE15.",
  "id" : 620104008204689408,
  "created_at" : "2015-07-12 05:34:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620100193522835456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.42649907873157, -6.240148867379804 ]
  },
  "id_str" : "620100895381041152",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe that\u2019s what I get for going to sleep. ;) next time then :)",
  "id" : 620100895381041152,
  "in_reply_to_status_id" : 620100193522835456,
  "created_at" : "2015-07-12 05:22:29 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620095937088724992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.42599657564673, -6.240280773852053 ]
  },
  "id_str" : "620096779258830848",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe great, mine is 413, so I\u2019m on my way :)",
  "id" : 620096779258830848,
  "in_reply_to_status_id" : 620095937088724992,
  "created_at" : "2015-07-12 05:06:07 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.42660680852203, -6.239717824032441 ]
  },
  "id_str" : "620095857023713280",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe finally made it through security. Are you still around?",
  "id" : 620095857023713280,
  "created_at" : "2015-07-12 05:02:27 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.33833620968485, -6.236803962772164 ]
  },
  "id_str" : "620068359594450944",
  "text" : "Meh, early flights.\u2708\uFE0F",
  "id" : 620068359594450944,
  "created_at" : "2015-07-12 03:13:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34684533950664, -6.255563132813846 ]
  },
  "id_str" : "619969879605645312",
  "text" : "My phone thinks I\u2019d already be living in Dublin and predicts how long it would take me to drive home. \uD83D\uDE0A",
  "id" : 619969879605645312,
  "created_at" : "2015-07-11 20:41:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Angel Pizarro",
      "screen_name" : "delagoya",
      "indices" : [ 9, 18 ],
      "id_str" : "6977272",
      "id" : 6977272
    }, {
      "name" : "BF Francis Ouellette",
      "screen_name" : "bffo",
      "indices" : [ 19, 24 ],
      "id_str" : "22462234",
      "id" : 22462234
    }, {
      "name" : "EDAM ontology",
      "screen_name" : "edamontology",
      "indices" : [ 25, 38 ],
      "id_str" : "3369042688",
      "id" : 3369042688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619897959816261632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.3476331064749, -6.239639403093635 ]
  },
  "id_str" : "619898284342157312",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @delagoya @bffo @edamontology won\u2019t really solve the problem of same pronunciation and resulting bad googlebility.",
  "id" : 619898284342157312,
  "in_reply_to_status_id" : 619897959816261632,
  "created_at" : "2015-07-11 15:57:22 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Nitesh Kumar",
      "screen_name" : "nitesh1989",
      "indices" : [ 9, 20 ],
      "id_str" : "728162921331576834",
      "id" : 728162921331576834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619897122029203456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34763310405845, -6.239639420628807 ]
  },
  "id_str" : "619897588771364865",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @nitesh1989 then it would clash with arXiv, which isn\u2019t much better. ;-)",
  "id" : 619897588771364865,
  "in_reply_to_status_id" : 619897122029203456,
  "created_at" : "2015-07-11 15:54:36 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angel Pizarro",
      "screen_name" : "delagoya",
      "indices" : [ 0, 9 ],
      "id_str" : "6977272",
      "id" : 6977272
    }, {
      "name" : "BF Francis Ouellette",
      "screen_name" : "bffo",
      "indices" : [ 10, 15 ],
      "id_str" : "22462234",
      "id" : 22462234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/cDhaAUcyaE",
      "expanded_url" : "http:\/\/biorxiv.org",
      "display_url" : "biorxiv.org"
    }, {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/cVt5cCznBN",
      "expanded_url" : "https:\/\/bioarchive.galaxyproject.org\/#\/pkg\/Biobase\/",
      "display_url" : "bioarchive.galaxyproject.org\/#\/pkg\/Biobase\/"
    } ]
  },
  "in_reply_to_status_id_str" : "619896773641928704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34764488332861, -6.239669943375532 ]
  },
  "id_str" : "619897229176905728",
  "in_reply_to_user_id" : 6977272,
  "text" : "@delagoya @bffo http:\/\/t.co\/cDhaAUcyaE vs. https:\/\/t.co\/cVt5cCznBN maybe a taxonomist could clear precedence? ;)",
  "id" : 619897229176905728,
  "in_reply_to_status_id" : 619896773641928704,
  "created_at" : "2015-07-11 15:53:11 +0000",
  "in_reply_to_screen_name" : "delagoya",
  "in_reply_to_user_id_str" : "6977272",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34762835122736, -6.239645604498125 ]
  },
  "id_str" : "619896319365246976",
  "text" : "bioaRchive vs. bioRxiv. *sigh* #bosc2015",
  "id" : 619896319365246976,
  "created_at" : "2015-07-11 15:49:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/619880565471354882\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/SxxO8KErUZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJpCFj5UkAE_WZZ.jpg",
      "id_str" : "619880562019307521",
      "id" : 619880562019307521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJpCFj5UkAE_WZZ.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/SxxO8KErUZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34765380718388, -6.239601045393933 ]
  },
  "id_str" : "619880565471354882",
  "text" : "Whops, looks like Sn\u00E6fellsnes did secede the union (at least on the back of my iPad). http:\/\/t.co\/SxxO8KErUZ",
  "id" : 619880565471354882,
  "created_at" : "2015-07-11 14:46:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cloudy Butt",
      "screen_name" : "CloudyButt",
      "indices" : [ 3, 14 ],
      "id_str" : "3145263984",
      "id" : 3145263984
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619869347687829505",
  "text" : "RT @CloudyButt: IC: Idea is that you host data in my butt and move your analysis to the data #BOSC2015",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/en.wikipedia.org\/wiki\/Vincent_van_Gogh\" rel=\"nofollow\"\u003EArtist Robot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2015",
        "indices" : [ 77, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619868755338915840",
    "text" : "IC: Idea is that you host data in my butt and move your analysis to the data #BOSC2015",
    "id" : 619868755338915840,
    "created_at" : "2015-07-11 14:00:02 +0000",
    "user" : {
      "name" : "Cloudy Butt",
      "screen_name" : "CloudyButt",
      "protected" : false,
      "id_str" : "3145263984",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585915214362583040\/WbbqMHaG_normal.jpg",
      "id" : 3145263984,
      "verified" : false
    }
  },
  "id" : 619869347687829505,
  "created_at" : "2015-07-11 14:02:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Junge",
      "screen_name" : "JungeAlexander",
      "indices" : [ 0, 15 ],
      "id_str" : "566549406",
      "id" : 566549406
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 16, 30 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 31, 45 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619866433196027904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34765299223025, -6.239629596644434 ]
  },
  "id_str" : "619866622757601280",
  "in_reply_to_user_id" : 566549406,
  "text" : "@JungeAlexander @NazeefaFatima @BioMickWatson and any chance for going for coffee\/beer after the sessions? :)",
  "id" : 619866622757601280,
  "in_reply_to_status_id" : 619866433196027904,
  "created_at" : "2015-07-11 13:51:34 +0000",
  "in_reply_to_screen_name" : "JungeAlexander",
  "in_reply_to_user_id_str" : "566549406",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 75, 84 ]
    }, {
      "text" : "scnr",
      "indices" : [ 85, 90 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619865533077397504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34762243492024, -6.239641965810961 ]
  },
  "id_str" : "619866249842008064",
  "in_reply_to_user_id" : 14286491,
  "text" : "That is after (Bio)Perl nearly made me clutch onto my pipette forever. ;-) #bosc2015 #scnr",
  "id" : 619866249842008064,
  "in_reply_to_status_id" : 619865533077397504,
  "created_at" : "2015-07-11 13:50:05 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 90, 98 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34762243492024, -6.239641965810961 ]
  },
  "id_str" : "619865533077397504",
  "text" : "Biopython is ultimately what made me go from biology into bioinformatics. So thanks Jo\u00E3o, @pjacock et al. #bosc2015",
  "id" : 619865533077397504,
  "created_at" : "2015-07-11 13:47:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Junge",
      "screen_name" : "JungeAlexander",
      "indices" : [ 0, 15 ],
      "id_str" : "566549406",
      "id" : 566549406
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 82, 96 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619863150263955456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34765838629824, -6.239660053718235 ]
  },
  "id_str" : "619863339766808576",
  "in_reply_to_user_id" : 566549406,
  "text" : "@JungeAlexander would still have been fun I guess. Plus I also would love to meet @BioMickWatson ;-)",
  "id" : 619863339766808576,
  "in_reply_to_status_id" : 619863150263955456,
  "created_at" : "2015-07-11 13:38:31 +0000",
  "in_reply_to_screen_name" : "JungeAlexander",
  "in_reply_to_user_id_str" : "566549406",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 10, 20 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/HFGcnWiPZK",
      "expanded_url" : "http:\/\/www.crummy.com\/sumana\/2014\/08\/10\/1",
      "display_url" : "crummy.com\/sumana\/2014\/08\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "619861936788905984",
  "text" : "Thanks to @biocrusoe for sharing this article on our Inessential Weirdnesses http:\/\/t.co\/HFGcnWiPZK",
  "id" : 619861936788905984,
  "created_at" : "2015-07-11 13:32:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Junge",
      "screen_name" : "JungeAlexander",
      "indices" : [ 0, 15 ],
      "id_str" : "566549406",
      "id" : 566549406
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 45, 59 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619855256596443137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34760483418532, -6.239645195756808 ]
  },
  "id_str" : "619857502931419136",
  "in_reply_to_user_id" : 566549406,
  "text" : "@JungeAlexander you should have told me that @BioMickWatson is there, I would have come over for that :-)",
  "id" : 619857502931419136,
  "in_reply_to_status_id" : 619855256596443137,
  "created_at" : "2015-07-11 13:15:19 +0000",
  "in_reply_to_screen_name" : "JungeAlexander",
  "in_reply_to_user_id_str" : "566549406",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marten Czech",
      "screen_name" : "martenson",
      "indices" : [ 0, 10 ],
      "id_str" : "17590177",
      "id" : 17590177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619855644875718656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34765404844295, -6.239626391947367 ]
  },
  "id_str" : "619856269113982976",
  "in_reply_to_user_id" : 17590177,
  "text" : "@martenson I think not all FitBit data sets are linked to genomes. Some people only share phenotype &amp; activity, not genotype.",
  "id" : 619856269113982976,
  "in_reply_to_status_id" : 619855644875718656,
  "created_at" : "2015-07-11 13:10:25 +0000",
  "in_reply_to_screen_name" : "martenson",
  "in_reply_to_user_id_str" : "17590177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619837128978075648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34765404844295, -6.239626391947367 ]
  },
  "id_str" : "619855641105055744",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko doh, read that one too late!",
  "id" : 619855641105055744,
  "in_reply_to_status_id" : 619837128978075648,
  "created_at" : "2015-07-11 13:07:55 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34766962363992, -6.239628798566683 ]
  },
  "id_str" : "619848715835166720",
  "text" : "\u00ABFrom the way you present it looks like you\u2019re having fun doing openSNP.\u00BB Yep, &amp; if you want to talk about it: I\u2019m at the #bosc2015 posters.",
  "id" : 619848715835166720,
  "created_at" : "2015-07-11 12:40:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan MacLean",
      "screen_name" : "danmaclean",
      "indices" : [ 0, 11 ],
      "id_str" : "17136713",
      "id" : 17136713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619834258933350400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34765727075703, -6.239635331526679 ]
  },
  "id_str" : "619847096036904960",
  "in_reply_to_user_id" : 17136713,
  "text" : "@danmaclean thanks for sharing!",
  "id" : 619847096036904960,
  "in_reply_to_status_id" : 619834258933350400,
  "created_at" : "2015-07-11 12:33:58 +0000",
  "in_reply_to_screen_name" : "danmaclean",
  "in_reply_to_user_id_str" : "17136713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan MacLean",
      "screen_name" : "danmaclean",
      "indices" : [ 3, 14 ],
      "id_str" : "17136713",
      "id" : 17136713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/danmaclean\/status\/619834258933350400\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/DXJxD1GSDJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJoX-TEUsAAnj-l.jpg",
      "id_str" : "619834257754599424",
      "id" : 619834257754599424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJoX-TEUsAAnj-l.jpg",
      "sizes" : [ {
        "h" : 1600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 1600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      } ],
      "display_url" : "pic.twitter.com\/DXJxD1GSDJ"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 16, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619846790871949312",
  "text" : "RT @danmaclean: #BOSC2015 for bio. Yves Vandreissche and Bastian Greshke talks concept mapped http:\/\/t.co\/DXJxD1GSDJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mvilla.it\/fenix\" rel=\"nofollow\"\u003EFenix for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/danmaclean\/status\/619834258933350400\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/DXJxD1GSDJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJoX-TEUsAAnj-l.jpg",
        "id_str" : "619834257754599424",
        "id" : 619834257754599424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJoX-TEUsAAnj-l.jpg",
        "sizes" : [ {
          "h" : 1600,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        } ],
        "display_url" : "pic.twitter.com\/DXJxD1GSDJ"
      } ],
      "hashtags" : [ {
        "text" : "BOSC2015",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619834258933350400",
    "text" : "#BOSC2015 for bio. Yves Vandreissche and Bastian Greshke talks concept mapped http:\/\/t.co\/DXJxD1GSDJ",
    "id" : 619834258933350400,
    "created_at" : "2015-07-11 11:42:57 +0000",
    "user" : {
      "name" : "Dan MacLean",
      "screen_name" : "danmaclean",
      "protected" : false,
      "id_str" : "17136713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577840273356554241\/qiVBgjfh_normal.jpeg",
      "id" : 17136713,
      "verified" : false
    }
  },
  "id" : 619846790871949312,
  "created_at" : "2015-07-11 12:32:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Bj\u00F6rn Gr\u00FCning",
      "screen_name" : "bjoerngruening",
      "indices" : [ 9, 24 ],
      "id_str" : "117360280",
      "id" : 117360280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619831376666345472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34766644695446, -6.239632998060831 ]
  },
  "id_str" : "619846649876217856",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @bjoerngruening sorry for that ;)",
  "id" : 619846649876217856,
  "in_reply_to_status_id" : 619831376666345472,
  "created_at" : "2015-07-11 12:32:12 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 3, 15 ],
      "id_str" : "208988759",
      "id" : 208988759
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 43, 59 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 100, 111 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opendata",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619839607040045057",
  "text" : "RT @GigaScience: Last lightning speaker is @gedankenstuecke really pushing the \"open\" boundary with @openSNPorg. #opendata genomic\/phenomic\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 26, 42 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 83, 94 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opendata",
        "indices" : [ 96, 105 ]
      }, {
        "text" : "BOSC2015",
        "indices" : [ 128, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619831105580060672",
    "text" : "Last lightning speaker is @gedankenstuecke really pushing the \"open\" boundary with @openSNPorg. #opendata genomic\/phenomic data #BOSC2015",
    "id" : 619831105580060672,
    "created_at" : "2015-07-11 11:30:26 +0000",
    "user" : {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "protected" : false,
      "id_str" : "208988759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1404305552\/profile-photo-GigaScience-96x96_normal.jpg",
      "id" : 208988759,
      "verified" : false
    }
  },
  "id" : 619839607040045057,
  "created_at" : "2015-07-11 12:04:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 0, 15 ],
      "id_str" : "14897792",
      "id" : 14897792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619819734981312512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34764493858169, -6.239652771207669 ]
  },
  "id_str" : "619820181150433280",
  "in_reply_to_user_id" : 14897792,
  "text" : "@michaelhoffman happy birthday!",
  "id" : 619820181150433280,
  "in_reply_to_status_id" : 619819734981312512,
  "created_at" : "2015-07-11 10:47:01 +0000",
  "in_reply_to_screen_name" : "michaelhoffman",
  "in_reply_to_user_id_str" : "14897792",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 0, 9 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/mWHC783o3U",
      "expanded_url" : "http:\/\/figshare.com\/articles\/openSNP_BOSC15_Poster\/1466880",
      "display_url" : "figshare.com\/articles\/openS\u2026"
    }, {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/mbpzQUVnFH",
      "expanded_url" : "http:\/\/figshare.com\/articles\/openSNP_BOSC15_Slides\/1480397",
      "display_url" : "figshare.com\/articles\/openS\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "619819037565001729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34765483496452, -6.23963832709454 ]
  },
  "id_str" : "619819473923653632",
  "in_reply_to_user_id" : 583180584,
  "text" : "@OBF_BOSC great! Poster: http:\/\/t.co\/mWHC783o3U slides: http:\/\/t.co\/mbpzQUVnFH :-)",
  "id" : 619819473923653632,
  "in_reply_to_status_id" : 619819037565001729,
  "created_at" : "2015-07-11 10:44:12 +0000",
  "in_reply_to_screen_name" : "OBF_BOSC",
  "in_reply_to_user_id_str" : "583180584",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 0, 15 ],
      "id_str" : "14897792",
      "id" : 14897792
    }, {
      "name" : "Holly Bik",
      "screen_name" : "hollybik",
      "indices" : [ 16, 25 ],
      "id_str" : "185910976",
      "id" : 185910976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619817791911239680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34766551056447, -6.239643631961181 ]
  },
  "id_str" : "619819062244343808",
  "in_reply_to_user_id" : 14897792,
  "text" : "@michaelhoffman @hollybik ack, hard to foresee which tech will win out in competing space.",
  "id" : 619819062244343808,
  "in_reply_to_status_id" : 619817791911239680,
  "created_at" : "2015-07-11 10:42:34 +0000",
  "in_reply_to_screen_name" : "michaelhoffman",
  "in_reply_to_user_id_str" : "14897792",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly Bik",
      "screen_name" : "hollybik",
      "indices" : [ 0, 9 ],
      "id_str" : "185910976",
      "id" : 185910976
    }, {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 10, 25 ],
      "id_str" : "14897792",
      "id" : 14897792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619816446516928512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34757821327531, -6.239653209947357 ]
  },
  "id_str" : "619817056473600001",
  "in_reply_to_user_id" : 185910976,
  "text" : "@hollybik @michaelhoffman also: not doing anything comes with it\u2019s own costs.",
  "id" : 619817056473600001,
  "in_reply_to_status_id" : 619816446516928512,
  "created_at" : "2015-07-11 10:34:36 +0000",
  "in_reply_to_screen_name" : "hollybik",
  "in_reply_to_user_id_str" : "185910976",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ewan Birney",
      "screen_name" : "ewanbirney",
      "indices" : [ 3, 14 ],
      "id_str" : "183548902",
      "id" : 183548902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/DTgwCLrMmO",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/I_Have_a_Dream#Copyright_dispute",
      "display_url" : "en.m.wikipedia.org\/wiki\/I_Have_a_\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34760653494688, -6.239653358578633 ]
  },
  "id_str" : "619792780202803200",
  "text" : "So @ewanbirney may have committed the first case of DNA based copyright infringement? #bosc2015  https:\/\/t.co\/DTgwCLrMmO",
  "id" : 619792780202803200,
  "created_at" : "2015-07-11 08:58:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 11, 21 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 22, 37 ],
      "id_str" : "14897792",
      "id" : 14897792
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 38, 46 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619784457986379776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34761631019211, -6.239649319540161 ]
  },
  "id_str" : "619785377344323584",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko @biocrusoe @michaelhoffman @kaiblin I\u2019ll try keeping my eyes open and report missed questions.",
  "id" : 619785377344323584,
  "in_reply_to_status_id" : 619784457986379776,
  "created_at" : "2015-07-11 08:28:43 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 9, 24 ],
      "id_str" : "14897792",
      "id" : 14897792
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 25, 35 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 36, 46 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/NbO54MmObC",
      "expanded_url" : "https:\/\/twitter.com\/michaelhoffman\/status\/619781810009059328",
      "display_url" : "twitter.com\/michaelhoffman\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "619784222505594880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34764706860295, -6.239647268709821 ]
  },
  "id_str" : "619784463929733120",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @michaelhoffman @biocrusoe @HLWiencko that was the original suggestion: https:\/\/t.co\/NbO54MmObC but too late to switch mid-session?",
  "id" : 619784463929733120,
  "in_reply_to_status_id" : 619784222505594880,
  "created_at" : "2015-07-11 08:25:05 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619783696007213056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34764706860295, -6.239647268709821 ]
  },
  "id_str" : "619783993857323008",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds \u201Cit's all downhill from here\u201D! ;)",
  "id" : 619783993857323008,
  "in_reply_to_status_id" : 619783696007213056,
  "created_at" : "2015-07-11 08:23:13 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 3, 13 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 15, 31 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Brad Chapman",
      "screen_name" : "chapmanb",
      "indices" : [ 32, 41 ],
      "id_str" : "18284047",
      "id" : 18284047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619779971393953792",
  "text" : "RT @HLWiencko: @gedankenstuecke @chapmanb Not on my watch. ;)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Brad Chapman",
        "screen_name" : "chapmanb",
        "indices" : [ 17, 26 ],
        "id_str" : "18284047",
        "id" : 18284047
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "619779294651383808",
    "geo" : { },
    "id_str" : "619779460624216064",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke @chapmanb Not on my watch. ;)",
    "id" : 619779460624216064,
    "in_reply_to_status_id" : 619779294651383808,
    "created_at" : "2015-07-11 08:05:13 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "protected" : false,
      "id_str" : "2657942712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490274907117215746\/GBit7UNq_normal.jpeg",
      "id" : 2657942712,
      "verified" : false
    }
  },
  "id" : 619779971393953792,
  "created_at" : "2015-07-11 08:07:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    }, {
      "name" : "Brad Chapman",
      "screen_name" : "chapmanb",
      "indices" : [ 11, 20 ],
      "id_str" : "18284047",
      "id" : 18284047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619779460624216064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34762133719474, -6.239638688331254 ]
  },
  "id_str" : "619779961445056512",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko @chapmanb all respect to you, not an easy task to achieve in Dublin. ;)",
  "id" : 619779961445056512,
  "in_reply_to_status_id" : 619779460624216064,
  "created_at" : "2015-07-11 08:07:12 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Chapman",
      "screen_name" : "chapmanb",
      "indices" : [ 40, 49 ],
      "id_str" : "18284047",
      "id" : 18284047
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 66, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34762133719474, -6.239638688331254 ]
  },
  "id_str" : "619779294651383808",
  "text" : "\u00ABNo one died in Dublin, which is good.\u00BB @chapmanb about codefest. #bosc2015",
  "id" : 619779294651383808,
  "created_at" : "2015-07-11 08:04:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 20, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/oucrSW8Hiy",
      "expanded_url" : "https:\/\/instagram.com\/p\/4_Pw-lhwgd\/",
      "display_url" : "instagram.com\/p\/4_Pw-lhwgd\/"
    } ]
  },
  "geo" : { },
  "id_str" : "619776894532210688",
  "text" : "For the last day of #bosc2015 https:\/\/t.co\/oucrSW8Hiy",
  "id" : 619776894532210688,
  "created_at" : "2015-07-11 07:55:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konrad F\u00F6rstner",
      "screen_name" : "konradfoerstner",
      "indices" : [ 3, 19 ],
      "id_str" : "15150655",
      "id" : 15150655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619529808117137409",
  "text" : "RT @konradfoerstner: From the panel discussion: Role models are very important. Volunteering for meeting organisation and decides who can p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2015",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619529525077123072",
    "text" : "From the panel discussion: Role models are very important. Volunteering for meeting organisation and decides who can present, too. #BOSC2015",
    "id" : 619529525077123072,
    "created_at" : "2015-07-10 15:32:03 +0000",
    "user" : {
      "name" : "Konrad F\u00F6rstner",
      "screen_name" : "konradfoerstner",
      "protected" : false,
      "id_str" : "15150655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895375230281158656\/gXjAenaZ_normal.jpg",
      "id" : 15150655,
      "verified" : false
    }
  },
  "id" : 619529808117137409,
  "created_at" : "2015-07-10 15:33:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Carrie Ganote",
      "screen_name" : "clg_cganote",
      "indices" : [ 16, 28 ],
      "id_str" : "2205370274",
      "id" : 2205370274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/NBxF0FLcWj",
      "expanded_url" : "http:\/\/www.iscb.org\/ismbeccb2015-general-info\/ismbeccb2015-coc",
      "display_url" : "iscb.org\/ismbeccb2015-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "619526015287730176",
  "text" : "RT @OBF_BOSC: . @clg_cganote The ISCB code of conduct (which also covers the SIGs such as #BOSC2015) is at http:\/\/t.co\/NBxF0FLcWj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Carrie Ganote",
        "screen_name" : "clg_cganote",
        "indices" : [ 2, 14 ],
        "id_str" : "2205370274",
        "id" : 2205370274
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2015",
        "indices" : [ 76, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/NBxF0FLcWj",
        "expanded_url" : "http:\/\/www.iscb.org\/ismbeccb2015-general-info\/ismbeccb2015-coc",
        "display_url" : "iscb.org\/ismbeccb2015-g\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "619524884293619712",
    "geo" : { },
    "id_str" : "619525647342436352",
    "in_reply_to_user_id" : 2205370274,
    "text" : ". @clg_cganote The ISCB code of conduct (which also covers the SIGs such as #BOSC2015) is at http:\/\/t.co\/NBxF0FLcWj",
    "id" : 619525647342436352,
    "in_reply_to_status_id" : 619524884293619712,
    "created_at" : "2015-07-10 15:16:39 +0000",
    "in_reply_to_screen_name" : "clg_cganote",
    "in_reply_to_user_id_str" : "2205370274",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 619526015287730176,
  "created_at" : "2015-07-10 15:18:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34761770245809, -6.239636581373226 ]
  },
  "id_str" : "619523777362305024",
  "text" : "Now for the panel on diversity. One of the things I\u2019ve been looking forward to most. #bosc2015",
  "id" : 619523777362305024,
  "created_at" : "2015-07-10 15:09:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/NEzLZjmuff",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?id=3793",
      "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "619514228400128005",
  "text" : "I have a kid?! p(r=0.5) &lt; 0.05 http:\/\/t.co\/NEzLZjmuff",
  "id" : 619514228400128005,
  "created_at" : "2015-07-10 14:31:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619512160868302848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.3476251979279, -6.23964063691697 ]
  },
  "id_str" : "619512625345466368",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot wouldn\u2019t that be dottle? ;) Figuring out that the entity on the other end is a \uD83D\uDC36 or \uD83D\uDC04 would me like them even more.",
  "id" : 619512625345466368,
  "in_reply_to_status_id" : 619512160868302848,
  "created_at" : "2015-07-10 14:24:54 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619509862221922304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34763076771122, -6.239634996283315 ]
  },
  "id_str" : "619510466809864192",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot someone asked me today! Well, about cattle, but close enough. In the end: on the internet only the geneticists know you\u2019re a dog.",
  "id" : 619510466809864192,
  "in_reply_to_status_id" : 619509862221922304,
  "created_at" : "2015-07-10 14:16:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619509131129569280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34763076771122, -6.239634996283315 ]
  },
  "id_str" : "619509744580063233",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot sogar auf dotted paper! Den kann ich ja noch schnell in meine Slides einbauen ;)",
  "id" : 619509744580063233,
  "in_reply_to_status_id" : 619509131129569280,
  "created_at" : "2015-07-10 14:13:27 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/619509626447523840\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/mn13mRs4fL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJjwuP8WUAAbFtJ.jpg",
      "id_str" : "619509626107744256",
      "id" : 619509626107744256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJjwuP8WUAAbFtJ.jpg",
      "sizes" : [ {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1936
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1530
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 896
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 508
      } ],
      "display_url" : "pic.twitter.com\/mn13mRs4fL"
    } ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34763076771122, -6.239634996283315 ]
  },
  "id_str" : "619509626447523840",
  "text" : "\u00ABAncient juggernaut supporting immortal database and crushing unwary sysadmins in its path\u00BB #bosc2015 http:\/\/t.co\/mn13mRs4fL",
  "id" : 619509626447523840,
  "created_at" : "2015-07-10 14:12:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Chapman",
      "screen_name" : "chapmanb",
      "indices" : [ 3, 12 ],
      "id_str" : "18284047",
      "id" : 18284047
    }, {
      "name" : "Holly Bik",
      "screen_name" : "hollybik",
      "indices" : [ 88, 97 ],
      "id_str" : "185910976",
      "id" : 185910976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 60, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/8uGoSYCDn2",
      "expanded_url" : "https:\/\/smallchangebio.wordpress.com\/2015\/07\/10\/bosc2015day1a\/",
      "display_url" : "smallchangebio.wordpress.com\/2015\/07\/10\/bos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "619507528662171652",
  "text" : "RT @chapmanb: Notes: Bioinformatics Open Source Conference (#BOSC2015) day 1 morning -- @hollybik and Data Science https:\/\/t.co\/8uGoSYCDn2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Holly Bik",
        "screen_name" : "hollybik",
        "indices" : [ 74, 83 ],
        "id_str" : "185910976",
        "id" : 185910976
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2015",
        "indices" : [ 46, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/8uGoSYCDn2",
        "expanded_url" : "https:\/\/smallchangebio.wordpress.com\/2015\/07\/10\/bosc2015day1a\/",
        "display_url" : "smallchangebio.wordpress.com\/2015\/07\/10\/bos\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "619507287087038464",
    "text" : "Notes: Bioinformatics Open Source Conference (#BOSC2015) day 1 morning -- @hollybik and Data Science https:\/\/t.co\/8uGoSYCDn2",
    "id" : 619507287087038464,
    "created_at" : "2015-07-10 14:03:41 +0000",
    "user" : {
      "name" : "Brad Chapman",
      "screen_name" : "chapmanb",
      "protected" : false,
      "id_str" : "18284047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1200195086\/356314252_7adb180ecc_normal.jpg",
      "id" : 18284047,
      "verified" : false
    }
  },
  "id" : 619507528662171652,
  "created_at" : "2015-07-10 14:04:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/5GQ8Tn1PYc",
      "expanded_url" : "http:\/\/www.wired.co.uk\/news\/archive\/2015-07\/10\/public-selfies-saved-by-a-german-pirate",
      "display_url" : "wired.co.uk\/news\/archive\/2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34762893141608, -6.2396412228417 ]
  },
  "id_str" : "619502906073612288",
  "text" : "For those who asked about the last author on the openSNP poster: yes, you might have heard her name before. #bosc2015 http:\/\/t.co\/5GQ8Tn1PYc",
  "id" : 619502906073612288,
  "created_at" : "2015-07-10 13:46:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Andeer",
      "screen_name" : "robinandeer",
      "indices" : [ 0, 12 ],
      "id_str" : "14777364",
      "id" : 14777364
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 13, 23 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Guillermo Carrasco",
      "screen_name" : "guillemch",
      "indices" : [ 24, 34 ],
      "id_str" : "379637011",
      "id" : 379637011
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CommonWL",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619500779167182848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34766548903833, -6.239612762179798 ]
  },
  "id_str" : "619501133107736578",
  "in_reply_to_user_id" : 14777364,
  "text" : "@robinandeer @biocrusoe @guillemch totally agree. Great idea, but first time I heard about #CommonWL was unclear what the benefit would be.",
  "id" : 619501133107736578,
  "in_reply_to_status_id" : 619500779167182848,
  "created_at" : "2015-07-10 13:39:14 +0000",
  "in_reply_to_screen_name" : "robinandeer",
  "in_reply_to_user_id_str" : "14777364",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Andeer",
      "screen_name" : "robinandeer",
      "indices" : [ 0, 12 ],
      "id_str" : "14777364",
      "id" : 14777364
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 13, 23 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Guillermo Carrasco",
      "screen_name" : "guillemch",
      "indices" : [ 24, 34 ],
      "id_str" : "379637011",
      "id" : 379637011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619498907844902912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34766548903833, -6.239612762179798 ]
  },
  "id_str" : "619500067473502208",
  "in_reply_to_user_id" : 14777364,
  "text" : "@robinandeer @biocrusoe @guillemch ack, feel the same.",
  "id" : 619500067473502208,
  "in_reply_to_status_id" : 619498907844902912,
  "created_at" : "2015-07-10 13:35:00 +0000",
  "in_reply_to_screen_name" : "robinandeer",
  "in_reply_to_user_id_str" : "14777364",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 3, 15 ],
      "id_str" : "208988759",
      "id" : 208988759
    }, {
      "name" : "Alejandra Gonzalez-Beltran",
      "screen_name" : "alegonbel",
      "indices" : [ 27, 37 ],
      "id_str" : "84825820",
      "id" : 84825820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PLOSOne",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619497434671132673",
  "text" : "RT @GigaScience: Up now is @alegonbel presenting on the reproducibility case study we participated in, just out in #PLOSOne http:\/\/t.co\/4oD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alejandra Gonzalez-Beltran",
        "screen_name" : "alegonbel",
        "indices" : [ 10, 20 ],
        "id_str" : "84825820",
        "id" : 84825820
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PLOSOne",
        "indices" : [ 98, 106 ]
      }, {
        "text" : "BOSC2015",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/4oDZrfGUOs",
        "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0127612",
        "display_url" : "journals.plos.org\/plosone\/articl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "619497258564878336",
    "text" : "Up now is @alegonbel presenting on the reproducibility case study we participated in, just out in #PLOSOne http:\/\/t.co\/4oDZrfGUOs #BOSC2015",
    "id" : 619497258564878336,
    "created_at" : "2015-07-10 13:23:50 +0000",
    "user" : {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "protected" : false,
      "id_str" : "208988759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1404305552\/profile-photo-GigaScience-96x96_normal.jpg",
      "id" : 208988759,
      "verified" : false
    }
  },
  "id" : 619497434671132673,
  "created_at" : "2015-07-10 13:24:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 3, 13 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 29, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/r8YazKpULg",
      "expanded_url" : "https:\/\/goo.gl\/e7TLMs",
      "display_url" : "goo.gl\/e7TLMs"
    } ]
  },
  "geo" : { },
  "id_str" : "619493995031494656",
  "text" : "RT @biocrusoe: Slides for my #BOSC2015 talk \"Portable workflow and tool descriptions\nwith the CWL\" https:\/\/t.co\/r8YazKpULg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2015",
        "indices" : [ 14, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/r8YazKpULg",
        "expanded_url" : "https:\/\/goo.gl\/e7TLMs",
        "display_url" : "goo.gl\/e7TLMs"
      } ]
    },
    "geo" : { },
    "id_str" : "619488464522903552",
    "text" : "Slides for my #BOSC2015 talk \"Portable workflow and tool descriptions\nwith the CWL\" https:\/\/t.co\/r8YazKpULg",
    "id" : 619488464522903552,
    "created_at" : "2015-07-10 12:48:54 +0000",
    "user" : {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "protected" : false,
      "id_str" : "17645638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485998749311721472\/0yX4CFRV_normal.jpeg",
      "id" : 17645638,
      "verified" : false
    }
  },
  "id" : 619493995031494656,
  "created_at" : "2015-07-10 13:10:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619467878073561088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34763996083402, -6.239599078352008 ]
  },
  "id_str" : "619468502869639168",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin making you wish it was called lightning talk because you wish the speaker was hit by one? \u26A1\uFE0F ;)",
  "id" : 619468502869639168,
  "in_reply_to_status_id" : 619467878073561088,
  "created_at" : "2015-07-10 11:29:34 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 11, 21 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 22, 30 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619458072898093056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34763120162177, -6.239640110669022 ]
  },
  "id_str" : "619458743336607744",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko @biocrusoe @kaiblin agree, think it's no either-or thing, but could deploy both strategies.",
  "id" : 619458743336607744,
  "in_reply_to_status_id" : 619458072898093056,
  "created_at" : "2015-07-10 10:50:48 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 11, 21 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 22, 30 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 31, 39 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 40, 49 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619457937862471680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34763120162177, -6.239640110669022 ]
  },
  "id_str" : "619458058935226372",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe @HLWiencko @kaiblin @pjacock @OBF_BOSC could give it a try post-lunch as it seems we\u2019re 3 volunteers?",
  "id" : 619458058935226372,
  "in_reply_to_status_id" : 619457937862471680,
  "created_at" : "2015-07-10 10:48:04 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 11, 21 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 22, 30 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619457294527545344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34763120162177, -6.239640110669022 ]
  },
  "id_str" : "619457690738237440",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe @HLWiencko @kaiblin what about letting people hand their cards to the aisles? then 3 people could quickly grab them.",
  "id" : 619457690738237440,
  "in_reply_to_status_id" : 619457294527545344,
  "created_at" : "2015-07-10 10:46:37 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619449966520610820",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34764057880235, -6.239625279864551 ]
  },
  "id_str" : "619450521011769344",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Unsere sch\u00F6ne Sprache! Immerhin l\u00E4sst sich \u26A1\uFE0F\uD83D\uDCA3\uD83D\uDD2B darstellen, damit muss Deutsch doch abgehandelt sein.",
  "id" : 619450521011769344,
  "in_reply_to_status_id" : 619449966520610820,
  "created_at" : "2015-07-10 10:18:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 0, 9 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 10, 20 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 21, 29 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619449375497035776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34762665588141, -6.239636890900723 ]
  },
  "id_str" : "619449587498135552",
  "in_reply_to_user_id" : 583180584,
  "text" : "@OBF_BOSC @biocrusoe @pjacock sure!",
  "id" : 619449587498135552,
  "in_reply_to_status_id" : 619449375497035776,
  "created_at" : "2015-07-10 10:14:25 +0000",
  "in_reply_to_screen_name" : "OBF_BOSC",
  "in_reply_to_user_id_str" : "583180584",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619449040447610880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34762665588141, -6.239636890900723 ]
  },
  "id_str" : "619449245796564992",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ich wollte ja eigentlich einen Witz \u00FCber carriage return machen, aber es gibt kein Kutschen-Emoji! \uD83D\uDC34",
  "id" : 619449245796564992,
  "in_reply_to_status_id" : 619449040447610880,
  "created_at" : "2015-07-10 10:13:03 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619448450623651840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34763339858398, -6.239637564904265 ]
  },
  "id_str" : "619448894381015040",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot alternativ wireless per \uD83D\uDC26? ;)",
  "id" : 619448894381015040,
  "in_reply_to_status_id" : 619448450623651840,
  "created_at" : "2015-07-10 10:11:39 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 9, 24 ],
      "id_str" : "14897792",
      "id" : 14897792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619444731588837376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34761550288994, -6.239626822592206 ]
  },
  "id_str" : "619446111649038336",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @michaelhoffman wonder how many people here are biologists-turned-bioinformaticians as opposed to having formal training.",
  "id" : 619446111649038336,
  "in_reply_to_status_id" : 619444731588837376,
  "created_at" : "2015-07-10 10:00:36 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 0, 9 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619444231778770944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34761550288994, -6.239626822592206 ]
  },
  "id_str" : "619445374193922049",
  "in_reply_to_user_id" : 583180584,
  "text" : "@OBF_BOSC happy to help.",
  "id" : 619445374193922049,
  "in_reply_to_status_id" : 619444231778770944,
  "created_at" : "2015-07-10 09:57:40 +0000",
  "in_reply_to_screen_name" : "OBF_BOSC",
  "in_reply_to_user_id_str" : "583180584",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619438022979928064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34764715372621, -6.23962693203995 ]
  },
  "id_str" : "619442187495972865",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Bluetooth or USB? ;)",
  "id" : 619442187495972865,
  "in_reply_to_status_id" : 619438022979928064,
  "created_at" : "2015-07-10 09:45:00 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 61, 74 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 75, 87 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 88, 97 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/619439269870989312\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/SzQY8aYpIL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJiwufcUMAASQAv.jpg",
      "id_str" : "619439261524176896",
      "id" : 619439261524176896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJiwufcUMAASQAv.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/SzQY8aYpIL"
    } ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34759728677966, -6.239687506006583 ]
  },
  "id_str" : "619439269870989312",
  "text" : "Come by if you want to talk about data sharing and ethics. \/\/@PhilippBayer @helgerausch @Senficon #bosc2015 http:\/\/t.co\/SzQY8aYpIL",
  "id" : 619439269870989312,
  "created_at" : "2015-07-10 09:33:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly Bik",
      "screen_name" : "hollybik",
      "indices" : [ 14, 23 ],
      "id_str" : "185910976",
      "id" : 185910976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 109, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.3476484609354, -6.239648609111713 ]
  },
  "id_str" : "619431539294752768",
  "text" : "So happy that @hollybik mentions the trouble you run into when working with eukaryotic microbes\/metagenomes. #bosc2015",
  "id" : 619431539294752768,
  "created_at" : "2015-07-10 09:02:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/I6oroVPGXO",
      "expanded_url" : "https:\/\/canzac.files.wordpress.com\/2014\/04\/in-the-computer-o.gif",
      "display_url" : "canzac.files.wordpress.com\/2014\/04\/in-the\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.3476484609354, -6.239648609111713 ]
  },
  "id_str" : "619430737452863488",
  "text" : "Getting more comfortable with googling error messages takes practice. Start like this https:\/\/t.co\/I6oroVPGXO #bosc2015",
  "id" : 619430737452863488,
  "created_at" : "2015-07-10 08:59:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 3, 11 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Holly Bik",
      "screen_name" : "hollybik",
      "indices" : [ 28, 37 ],
      "id_str" : "185910976",
      "id" : 185910976
    }, {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 74, 89 ],
      "id_str" : "14897792",
      "id" : 14897792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619427719286255616",
  "text" : "RT @pjacock: Got a pic with @hollybik &amp; \"Biologist has exhaustion\" RT @michaelhoffman: I love HB's Oregon Trail analogy #bosc2015 http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Holly Bik",
        "screen_name" : "hollybik",
        "indices" : [ 15, 24 ],
        "id_str" : "185910976",
        "id" : 185910976
      }, {
        "name" : "Michael Hoffman",
        "screen_name" : "michaelhoffman",
        "indices" : [ 61, 76 ],
        "id_str" : "14897792",
        "id" : 14897792
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pjacock\/status\/619427652148043776\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/Dsra94u1W6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJimKuVWcAA0hs8.jpg",
        "id_str" : "619427651929927680",
        "id" : 619427651929927680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJimKuVWcAA0hs8.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/Dsra94u1W6"
      } ],
      "hashtags" : [ {
        "text" : "bosc2015",
        "indices" : [ 111, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619427652148043776",
    "text" : "Got a pic with @hollybik &amp; \"Biologist has exhaustion\" RT @michaelhoffman: I love HB's Oregon Trail analogy #bosc2015 http:\/\/t.co\/Dsra94u1W6",
    "id" : 619427652148043776,
    "created_at" : "2015-07-10 08:47:15 +0000",
    "user" : {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "protected" : false,
      "id_str" : "58756672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/324343873\/peter_cliff_normal.jpg",
      "id" : 58756672,
      "verified" : false
    }
  },
  "id" : 619427719286255616,
  "created_at" : "2015-07-10 08:47:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34763280588287, -6.239635192251875 ]
  },
  "id_str" : "619424518843576321",
  "text" : "\u00ABWhat do I call myself?\u00BB the identity loss that comes with being somewhere in the fuzzy field of bioinformatics. #bosc2015",
  "id" : 619424518843576321,
  "created_at" : "2015-07-10 08:34:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly Bik",
      "screen_name" : "hollybik",
      "indices" : [ 121, 130 ],
      "id_str" : "185910976",
      "id" : 185910976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2015",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34763280598038, -6.23963518883787 ]
  },
  "id_str" : "619423569022459904",
  "text" : "The most important skill you can pick up: \u00ABI know how to google error messages, which is the secret to bioinformatics\u00BB \u2013 @hollybik #bosc2015",
  "id" : 619423569022459904,
  "created_at" : "2015-07-10 08:31:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Valerie Aurora \uD83D\uDDFD",
      "screen_name" : "vaurorapub",
      "indices" : [ 45, 56 ],
      "id_str" : "2339814156",
      "id" : 2339814156
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 64, 74 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/YWBgP8GST8",
      "expanded_url" : "http:\/\/blog.valerieaurora.org\/2015\/06\/23\/ban-boring-mike-based-qa-sessions-and-use-index-cards-instead\/",
      "display_url" : "blog.valerieaurora.org\/2015\/06\/23\/ban\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "619421572168843264",
  "text" : "RT @OBF_BOSC: See http:\/\/t.co\/YWBgP8GST8 (by @vaurorapub) which @biocrusoe used to persuade us to try questions on cards (and twitter) at #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Aurora \uD83D\uDDFD",
        "screen_name" : "vaurorapub",
        "indices" : [ 31, 42 ],
        "id_str" : "2339814156",
        "id" : 2339814156
      }, {
        "name" : "Michael R. Crusoe",
        "screen_name" : "biocrusoe",
        "indices" : [ 50, 60 ],
        "id_str" : "17645638",
        "id" : 17645638
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2015",
        "indices" : [ 124, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 4, 26 ],
        "url" : "http:\/\/t.co\/YWBgP8GST8",
        "expanded_url" : "http:\/\/blog.valerieaurora.org\/2015\/06\/23\/ban-boring-mike-based-qa-sessions-and-use-index-cards-instead\/",
        "display_url" : "blog.valerieaurora.org\/2015\/06\/23\/ban\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "619421339896692737",
    "text" : "See http:\/\/t.co\/YWBgP8GST8 (by @vaurorapub) which @biocrusoe used to persuade us to try questions on cards (and twitter) at #BOSC2015",
    "id" : 619421339896692737,
    "created_at" : "2015-07-10 08:22:10 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 619421572168843264,
  "created_at" : "2015-07-10 08:23:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "indices" : [ 3, 15 ],
      "id_str" : "208988759",
      "id" : 208988759
    }, {
      "name" : "Holly Bik",
      "screen_name" : "hollybik",
      "indices" : [ 107, 116 ],
      "id_str" : "185910976",
      "id" : 185910976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bioinformatics",
      "indices" : [ 41, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619420282453950464",
  "text" : "RT @GigaScience: 1st \"I am an end user\" (#bioinformatics: still a scary world for biologists) keynote from @hollybik. Supposedly her first \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Holly Bik",
        "screen_name" : "hollybik",
        "indices" : [ 90, 99 ],
        "id_str" : "185910976",
        "id" : 185910976
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bioinformatics",
        "indices" : [ 24, 39 ]
      }, {
        "text" : "BOSC2015",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619419888554221569",
    "text" : "1st \"I am an end user\" (#bioinformatics: still a scary world for biologists) keynote from @hollybik. Supposedly her first time at #BOSC2015",
    "id" : 619419888554221569,
    "created_at" : "2015-07-10 08:16:24 +0000",
    "user" : {
      "name" : "GigaScience",
      "screen_name" : "GigaScience",
      "protected" : false,
      "id_str" : "208988759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1404305552\/profile-photo-GigaScience-96x96_normal.jpg",
      "id" : 208988759,
      "verified" : false
    }
  },
  "id" : 619420282453950464,
  "created_at" : "2015-07-10 08:17:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34763922179414, -6.239647170938947 ]
  },
  "id_str" : "619418184265932800",
  "text" : "Excited about the theme of #BOSC2015: \u00ABIncreasing diversity in the bioinformatics open source community.\u00BB Adopted a COC, also for ISMB.",
  "id" : 619418184265932800,
  "created_at" : "2015-07-10 08:09:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OfficialSMBE",
      "screen_name" : "OfficialSMBE",
      "indices" : [ 0, 13 ],
      "id_str" : "1120098811",
      "id" : 1120098811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/UP7pvR983G",
      "expanded_url" : "http:\/\/figshare.com\/articles\/Poster_for_smbe15\/1466892",
      "display_url" : "figshare.com\/articles\/Poste\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "619235800899788800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.33842568506365, -6.236823613253739 ]
  },
  "id_str" : "619401376142094336",
  "in_reply_to_user_id" : 1120098811,
  "text" : "@OfficialSMBE \u00ABPotential and pitfalls of eukaryotic metagenome skimming: A test case for lichens.\u00BB http:\/\/t.co\/UP7pvR983G",
  "id" : 619401376142094336,
  "in_reply_to_status_id" : 619235800899788800,
  "created_at" : "2015-07-10 07:02:50 +0000",
  "in_reply_to_screen_name" : "OfficialSMBE",
  "in_reply_to_user_id_str" : "1120098811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Bobe",
      "screen_name" : "jasonbobe",
      "indices" : [ 0, 10 ],
      "id_str" : "820582",
      "id" : 820582
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 11, 20 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 21, 30 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619313695865372673",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.33825305062201, -6.236725247598081 ]
  },
  "id_str" : "619395655715434496",
  "in_reply_to_user_id" : 820582,
  "text" : "@jasonbobe @madprime @eramirez thanks!",
  "id" : 619395655715434496,
  "in_reply_to_status_id" : 619313695865372673,
  "created_at" : "2015-07-10 06:40:06 +0000",
  "in_reply_to_screen_name" : "jasonbobe",
  "in_reply_to_user_id_str" : "820582",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/SBgj0l4Odu",
      "expanded_url" : "http:\/\/fortune.com\/2015\/07\/09\/23andme-is-the-startup-worlds-newest-unicorn\/",
      "display_url" : "fortune.com\/2015\/07\/09\/23a\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.33836227037926, -6.236732165720168 ]
  },
  "id_str" : "619278589087907840",
  "text" : "23andMe went unicorn http:\/\/t.co\/SBgj0l4Odu",
  "id" : 619278589087907840,
  "created_at" : "2015-07-09 22:54:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.33829302758626, -6.236514316864768 ]
  },
  "id_str" : "619271017094098944",
  "text" : "Also: as there were so many people talking about activity tracking at Codefest today: who\u2019s in for a pre-#BOSC2015 run tomorrow morning?",
  "id" : 619271017094098944,
  "created_at" : "2015-07-09 22:24:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/6mXsyoazxR",
      "expanded_url" : "https:\/\/instagram.com\/p\/47pbtHhwpu\/",
      "display_url" : "instagram.com\/p\/47pbtHhwpu\/"
    } ]
  },
  "geo" : { },
  "id_str" : "619270388808351744",
  "text" : "#latergram from my walks through Dublin. I get the sentiment of feeling at home right away. https:\/\/t.co\/6mXsyoazxR",
  "id" : 619270388808351744,
  "created_at" : "2015-07-09 22:22:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 10, 19 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619233996191465472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34568817559915, -6.293825714790709 ]
  },
  "id_str" : "619237416944185344",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @eramirez best of luck for that! How would I best apply for GET?",
  "id" : 619237416944185344,
  "in_reply_to_status_id" : 619233996191465472,
  "created_at" : "2015-07-09 20:11:19 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Junge",
      "screen_name" : "JungeAlexander",
      "indices" : [ 0, 15 ],
      "id_str" : "566549406",
      "id" : 566549406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619233487594385408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34563625440476, -6.293526412288356 ]
  },
  "id_str" : "619236808749129729",
  "in_reply_to_user_id" : 566549406,
  "text" : "@JungeAlexander dito und vielen Dank. Und wir sehen uns bestimmt noch mal. In den Mittagspausen werde ich wohl am Poster stehen ;)",
  "id" : 619236808749129729,
  "in_reply_to_status_id" : 619233487594385408,
  "created_at" : "2015-07-09 20:08:54 +0000",
  "in_reply_to_screen_name" : "JungeAlexander",
  "in_reply_to_user_id_str" : "566549406",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 10, 19 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619224262113673216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34267146488859, -6.276435724531815 ]
  },
  "id_str" : "619226089534136320",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @madprime yeah, so I\u2019ll have to choose I guess :(",
  "id" : 619226089534136320,
  "in_reply_to_status_id" : 619224262113673216,
  "created_at" : "2015-07-09 19:26:19 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619223571089477632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34247280095888, -6.27529051568219 ]
  },
  "id_str" : "619226039416455168",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I will teach you doing \u05E1\u05D1\u05D9\u05D7, and you teach me doing the costume? ;)",
  "id" : 619226039416455168,
  "in_reply_to_status_id" : 619223571089477632,
  "created_at" : "2015-07-09 19:26:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619214794046967808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34019596451371, -6.262165570202966 ]
  },
  "id_str" : "619216089990438912",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot will you make me one? ;)",
  "id" : 619216089990438912,
  "in_reply_to_status_id" : 619214794046967808,
  "created_at" : "2015-07-09 18:46:34 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619213357174927360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34019529556821, -6.262161714030801 ]
  },
  "id_str" : "619216044637462528",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez let me see whether I can find the time :)",
  "id" : 619216044637462528,
  "in_reply_to_status_id" : 619213357174927360,
  "created_at" : "2015-07-09 18:46:24 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 125, 134 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619213395900956672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34019489866398, -6.262159426055303 ]
  },
  "id_str" : "619215673240252418",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez great, would love to. Have to check logistics first. And I think there\u2019s the PGP doing their GET at the same time? @madprime",
  "id" : 619215673240252418,
  "in_reply_to_status_id" : 619213395900956672,
  "created_at" : "2015-07-09 18:44:55 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619135218516103169",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34378739344792, -6.255879663492683 ]
  },
  "id_str" : "619182375004688385",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABYou should add a photo of you wearing an animal- or fruit costume to your slides.\u00BB I \u2764\uFE0F getting useful comments.",
  "id" : 619182375004688385,
  "in_reply_to_status_id" : 619135218516103169,
  "created_at" : "2015-07-09 16:32:36 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619170803591053312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34379907975359, -6.255873362200724 ]
  },
  "id_str" : "619171175516737536",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot well, the times they are a-changin\u2019. ;)",
  "id" : 619171175516737536,
  "in_reply_to_status_id" : 619170803591053312,
  "created_at" : "2015-07-09 15:48:06 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "4lice_",
      "screen_name" : "syndikalist_in",
      "indices" : [ 7, 22 ],
      "id_str" : "723782419",
      "id" : 723782419
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 23, 30 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619169967200710656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34380274269603, -6.255870645238669 ]
  },
  "id_str" : "619170275515625472",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @syndikalist_in @TnaKng ich dachte wir trollen uns gar nicht mehr! \uD83C\uDF09\uD83D\uDC79\uD83D\uDEA8",
  "id" : 619170275515625472,
  "in_reply_to_status_id" : 619169967200710656,
  "created_at" : "2015-07-09 15:44:31 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619167445677379584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34381172001073, -6.255843373362535 ]
  },
  "id_str" : "619167684807274496",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy been through the genomic desert on a gene with no unique identifier?",
  "id" : 619167684807274496,
  "in_reply_to_status_id" : 619167445677379584,
  "created_at" : "2015-07-09 15:34:14 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/8ZjPfLSyFn",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/65EzQXyjjn5jW\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/65EzQXyj\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "619162093674209280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34381172001073, -6.255843373362535 ]
  },
  "id_str" : "619167302110547968",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy time to get out your js skills and do an overlay of this? http:\/\/t.co\/8ZjPfLSyFn",
  "id" : 619167302110547968,
  "in_reply_to_status_id" : 619162093674209280,
  "created_at" : "2015-07-09 15:32:43 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/rZFOWa0KDJ",
      "expanded_url" : "https:\/\/instagram.com\/p\/465_a-hwp8\/",
      "display_url" : "instagram.com\/p\/465_a-hwp8\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34380919036254, -6.255863007605235 ]
  },
  "id_str" : "619166282739515392",
  "text" : "The more I travel, the uglier my own university feels. https:\/\/t.co\/rZFOWa0KDJ",
  "id" : 619166282739515392,
  "created_at" : "2015-07-09 15:28:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4lice_",
      "screen_name" : "syndikalist_in",
      "indices" : [ 0, 15 ],
      "id_str" : "723782419",
      "id" : 723782419
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 16, 22 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 23, 30 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619160888193482752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34382387464525, -6.255838178733618 ]
  },
  "id_str" : "619165296734175232",
  "in_reply_to_user_id" : 723782419,
  "text" : "@syndikalist_in @Lobot @TnaKng es ist an der zeit \uD83D\uDE3A",
  "id" : 619165296734175232,
  "in_reply_to_status_id" : 619160888193482752,
  "created_at" : "2015-07-09 15:24:44 +0000",
  "in_reply_to_screen_name" : "syndikalist_in",
  "in_reply_to_user_id_str" : "723782419",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619154469775908864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.3438267797741, -6.255847128367281 ]
  },
  "id_str" : "619155895000408064",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen \u2764\uFE0F",
  "id" : 619155895000408064,
  "in_reply_to_status_id" : 619154469775908864,
  "created_at" : "2015-07-09 14:47:23 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/4euLtofi16",
      "expanded_url" : "https:\/\/opensnp.org\/phenotypes\/1",
      "display_url" : "opensnp.org\/phenotypes\/1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34380339949486, -6.255868192057997 ]
  },
  "id_str" : "619153730940858368",
  "text" : "I wanted to create a screenshot of eye color answers in openSNP. But my screen is too small to all of them at once\u2026 https:\/\/t.co\/4euLtofi16",
  "id" : 619153730940858368,
  "created_at" : "2015-07-09 14:38:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 88, 97 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619150015236317184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34381340948404, -6.255837459567657 ]
  },
  "id_str" : "619150417457451008",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot the ball pit image has been featured in nearly every talk on the topic so far :p @Senficon",
  "id" : 619150417457451008,
  "in_reply_to_status_id" : 619150015236317184,
  "created_at" : "2015-07-09 14:25:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619149115142840320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34379876173501, -6.255872770815874 ]
  },
  "id_str" : "619150004628885504",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot after \u2019nearly splitting up over missing emoticons\u2019 it\u2019s now \u2018nearly splitting up over wrongly used emoji\u2019? \uD83D\uDE40",
  "id" : 619150004628885504,
  "in_reply_to_status_id" : 619149115142840320,
  "created_at" : "2015-07-09 14:23:59 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619146391634509824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.3438050158918, -6.255864389008408 ]
  },
  "id_str" : "619146915809259520",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot the title of your emoji is \u2018sleepy face\u2019 \u263A\uFE0F",
  "id" : 619146915809259520,
  "in_reply_to_status_id" : 619146391634509824,
  "created_at" : "2015-07-09 14:11:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/619143884589899777\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/l7Mu2NfJkZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJekEe_WsAAbh_u.jpg",
      "id_str" : "619143870731956224",
      "id" : 619143870731956224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJekEe_WsAAbh_u.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/l7Mu2NfJkZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34386475389203, -6.255660178145631 ]
  },
  "id_str" : "619143884589899777",
  "text" : "Antifa in Dublin http:\/\/t.co\/l7Mu2NfJkZ",
  "id" : 619143884589899777,
  "created_at" : "2015-07-09 13:59:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619133253413392384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34378588977741, -6.255882436301042 ]
  },
  "id_str" : "619137491786985472",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot i love you, but i\u2019ve chosen \uD83D\uDEBD",
  "id" : 619137491786985472,
  "in_reply_to_status_id" : 619133253413392384,
  "created_at" : "2015-07-09 13:34:15 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619135311138979841",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34378588977741, -6.255882436301042 ]
  },
  "id_str" : "619137146331471872",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen 5 minutes on \u201Cwhy I\u2019m not the Mark Zuckerberg of whatever\u201D? :P",
  "id" : 619137146331471872,
  "in_reply_to_status_id" : 619135311138979841,
  "created_at" : "2015-07-09 13:32:53 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34379951932804, -6.255874548113232 ]
  },
  "id_str" : "619135218516103169",
  "text" : "Assume \u2018someone\u2019 would have to give a 5 min slide talk about openSNP. What to include? \uD83D\uDCC9",
  "id" : 619135218516103169,
  "created_at" : "2015-07-09 13:25:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619108430494724096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34381493860924, -6.255906189341331 ]
  },
  "id_str" : "619109714576691200",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot false advertising makes customers unhappy!",
  "id" : 619109714576691200,
  "in_reply_to_status_id" : 619108430494724096,
  "created_at" : "2015-07-09 11:43:53 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 70, 77 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619103793846833152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34379958196027, -6.255875864384461 ]
  },
  "id_str" : "619105103707025412",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u2018dein Grab, birgt es mehr als ein Bein, eine Hand?\u2019 \uD83D\uDE31 Einsatz, @TnaKng! ;-)",
  "id" : 619105103707025412,
  "in_reply_to_status_id" : 619103793846833152,
  "created_at" : "2015-07-09 11:25:33 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/hevQwdXBdE",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/07\/08\/how-to-make-a-drinking-game.html",
      "display_url" : "boingboing.net\/2015\/07\/08\/how\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34378330902459, -6.255891721294412 ]
  },
  "id_str" : "619098767460040704",
  "text" : "\u00ABhow to make drinking games.\u00BB let\u2019s just say that \u2018speed fist\u2019 might want to think about renaming. http:\/\/t.co\/hevQwdXBdE",
  "id" : 619098767460040704,
  "created_at" : "2015-07-09 11:00:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 9, 23 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619087808708386816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34378518415235, -6.255883497716257 ]
  },
  "id_str" : "619088058458210305",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek @NazeefaFatima the irony of then having to shorten down synonym for big. ;)",
  "id" : 619088058458210305,
  "in_reply_to_status_id" : 619087808708386816,
  "created_at" : "2015-07-09 10:17:49 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619086779476496384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34381443103518, -6.255849747834737 ]
  },
  "id_str" : "619086998381400064",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima I ran out of characters for the tweet! ;)",
  "id" : 619086998381400064,
  "in_reply_to_status_id" : 619086779476496384,
  "created_at" : "2015-07-09 10:13:37 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/LF33R9K9mI",
      "expanded_url" : "https:\/\/thescienceweb.wordpress.com\/2015\/07\/09\/scientists-decide-just-to-discover-things-they-already-know\/",
      "display_url" : "thescienceweb.wordpress.com\/2015\/07\/09\/sci\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34378922766255, -6.255872038297158 ]
  },
  "id_str" : "619084487872393216",
  "text" : "\u00ABwe don\u2019t want new knowledge, because we have enough of that already.\u00A0What we want is big data\u00BB Big Genome Data! https:\/\/t.co\/LF33R9K9mI",
  "id" : 619084487872393216,
  "created_at" : "2015-07-09 10:03:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/iCRObNX1pS",
      "expanded_url" : "http:\/\/dat-data.com\/",
      "display_url" : "dat-data.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34379661057196, -6.255856106112541 ]
  },
  "id_str" : "619082565941600256",
  "text" : "\u00ABOne thousand forks when all you need is a knife isn't irony\u00BB http:\/\/t.co\/iCRObNX1pS",
  "id" : 619082565941600256,
  "created_at" : "2015-07-09 09:56:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/ClWzzaWZDF",
      "expanded_url" : "https:\/\/instagram.com\/p\/46NTsHBwtF\/",
      "display_url" : "instagram.com\/p\/46NTsHBwtF\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34383349745944, -6.255686585261553 ]
  },
  "id_str" : "619067900436070400",
  "text" : "What you find at the same intersection in Dublin. https:\/\/t.co\/ClWzzaWZDF",
  "id" : 619067900436070400,
  "created_at" : "2015-07-09 08:57:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618933836018155520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.34377306334923, -6.2559587921375 ]
  },
  "id_str" : "619064752434647040",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez btw. still looking for speakers f\u00FCr QS europe? :p",
  "id" : 619064752434647040,
  "in_reply_to_status_id" : 618933836018155520,
  "created_at" : "2015-07-09 08:45:13 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/Hc3GPxKCaS",
      "expanded_url" : "https:\/\/instagram.com\/p\/46F0DvhwlF\/",
      "display_url" : "instagram.com\/p\/46F0DvhwlF\/"
    } ]
  },
  "geo" : { },
  "id_str" : "619051323246424064",
  "text" : "Nomnomnom https:\/\/t.co\/Hc3GPxKCaS",
  "id" : 619051323246424064,
  "created_at" : "2015-07-09 07:51:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618933836018155520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.33826968710839, -6.236690594440208 ]
  },
  "id_str" : "619022913807773696",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez got some cool insights from the data as well, can forward you an email on this if you\u2019re interested.",
  "id" : 619022913807773696,
  "in_reply_to_status_id" : 618933836018155520,
  "created_at" : "2015-07-09 05:58:58 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 10, 21 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618933069207093248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.33830052550468, -6.236850465108896 ]
  },
  "id_str" : "619022750368276481",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @shellyjang thanks, it\u2019s lots of fun creating those. :)",
  "id" : 619022750368276481,
  "in_reply_to_status_id" : 618933069207093248,
  "created_at" : "2015-07-09 05:58:19 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618902235687354368",
  "geo" : { },
  "id_str" : "618912716640657409",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima small data makes you go \u2018aww!\u2019 and hug it! \uD83D\uDC39",
  "id" : 618912716640657409,
  "in_reply_to_status_id" : 618902235687354368,
  "created_at" : "2015-07-08 22:41:05 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/hLYZCUl2LS",
      "expanded_url" : "https:\/\/instagram.com\/p\/45GWHWhwv3\/",
      "display_url" : "instagram.com\/p\/45GWHWhwv3\/"
    } ]
  },
  "geo" : { },
  "id_str" : "618911952983707648",
  "text" : "Rainbowish https:\/\/t.co\/hLYZCUl2LS",
  "id" : 618911952983707648,
  "created_at" : "2015-07-08 22:38:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618901327758893056",
  "geo" : { },
  "id_str" : "618902202959155200",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima just start using them and maybe they will become standard genomics vocabulary ;)",
  "id" : 618902202959155200,
  "in_reply_to_status_id" : 618901327758893056,
  "created_at" : "2015-07-08 21:59:18 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618899512342528000",
  "text" : "Took me 5 minutes to go from \u2018nice, free WiFi on buses!\u2019 to \u2018Wait, which websites are blocked?!\u2019\u2026",
  "id" : 618899512342528000,
  "created_at" : "2015-07-08 21:48:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618897950262095872",
  "geo" : { },
  "id_str" : "618898134786252800",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83D\uDC83\uD83C\uDFFD\uD83D\uDC83\uD83C\uDFFD\uD83C\uDFBC\uD83C\uDFB6 not even close ;)",
  "id" : 618898134786252800,
  "in_reply_to_status_id" : 618897950262095872,
  "created_at" : "2015-07-08 21:43:08 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618891604833759232",
  "text" : "Just walking through DUB makes me hit my daily step goal.",
  "id" : 618891604833759232,
  "created_at" : "2015-07-08 21:17:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618853060278939648",
  "geo" : { },
  "id_str" : "618853831322005504",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot changing what kind of \uD83D\uDC3B-do I am. \uD83D\uDE0A",
  "id" : 618853831322005504,
  "in_reply_to_status_id" : 618853060278939648,
  "created_at" : "2015-07-08 18:47:05 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618851969143341056",
  "geo" : { },
  "id_str" : "618852532966846464",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot my day. \uD83D\uDE0A Not depicted: the confused looks I got at check in, she flat out refused to believe that the passport pictures me. \uD83D\uDC40",
  "id" : 618852532966846464,
  "in_reply_to_status_id" : 618851969143341056,
  "created_at" : "2015-07-08 18:41:56 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618847514859577344",
  "geo" : { },
  "id_str" : "618851319009419265",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima next: humongous genome data and Godzillaesk genome data.",
  "id" : 618851319009419265,
  "in_reply_to_status_id" : 618847514859577344,
  "created_at" : "2015-07-08 18:37:06 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618849351444635648",
  "geo" : { },
  "id_str" : "618850219069964288",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83D\uDE98\uD83D\uDCCA\uD83D\uDCC9\uD83D\uDCC8\uD83D\uDD2D\uD83D\uDD2C\uD83D\uDC59\uD83D\uDC54\uD83D\uDC58\uD83D\uDC60\uD83C\uDF92\uD83D\uDCBC\uD83C\uDF46\uD83C\uDF46\uD83C\uDF46\uD83D\uDE98\uD83D\uDE81",
  "id" : 618850219069964288,
  "in_reply_to_status_id" : 618849351444635648,
  "created_at" : "2015-07-08 18:32:44 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/okrRfZnaL2",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/kIHQ29dJAn8\/info%3Adoi%2F10.1371%2Fjournal.pone.0130903",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "618848788921348096",
  "text" : "Can Walking or Biking to Work Really Make a Difference? http:\/\/t.co\/okrRfZnaL2",
  "id" : 618848788921348096,
  "created_at" : "2015-07-08 18:27:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05065861893481, 8.58448996409086 ]
  },
  "id_str" : "618843044339691520",
  "text" : "Made it to the airport in time and even managed to find a place to stay for tonight. Awarded the \u2018Master of Irresponsible Travel Plans.",
  "id" : 618843044339691520,
  "created_at" : "2015-07-08 18:04:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 0, 9 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618783493250764800",
  "geo" : { },
  "id_str" : "618784171029340160",
  "in_reply_to_user_id" : 583180584,
  "text" : "@OBF_BOSC I will! Are you out somewhere tonight? :)",
  "id" : 618784171029340160,
  "in_reply_to_status_id" : 618783493250764800,
  "created_at" : "2015-07-08 14:10:17 +0000",
  "in_reply_to_screen_name" : "OBF_BOSC",
  "in_reply_to_user_id_str" : "583180584",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618768786607472640",
  "text" : "Looks like I\u2019m already leaving for Dublin and #BOSC2015 today instead of tomorrow. A date mixup like this was bound to happen some day\u2026 \uD83D\uDE31",
  "id" : 618768786607472640,
  "created_at" : "2015-07-08 13:09:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 0, 12 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618731128883707904",
  "geo" : { },
  "id_str" : "618750777922818048",
  "in_reply_to_user_id" : 13766492,
  "text" : "@AkshatRathi for how long are you in town? :)",
  "id" : 618750777922818048,
  "in_reply_to_status_id" : 618731128883707904,
  "created_at" : "2015-07-08 11:57:35 +0000",
  "in_reply_to_screen_name" : "AkshatRathi",
  "in_reply_to_user_id_str" : "13766492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618743820390416384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722209576216, 8.627589265457408 ]
  },
  "id_str" : "618745268943613952",
  "in_reply_to_user_id" : 14286491,
  "text" : "Errors obvious to me: additional edges Iceland \u2194\uFE0F Germany. And apparently didn\u2019t tweet while in Kiev when going FRA\u2194\uFE0FTLV (or vice versa).",
  "id" : 618745268943613952,
  "in_reply_to_status_id" : 618743820390416384,
  "created_at" : "2015-07-08 11:35:42 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/618743820390416384\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/BPLcUYDn0E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJY4OZNWcAA7vlk.png",
      "id_str" : "618743818746228736",
      "id" : 618743818746228736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJY4OZNWcAA7vlk.png",
      "sizes" : [ {
        "h" : 2234,
        "resize" : "fit",
        "w" : 4251
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1076,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/BPLcUYDn0E"
    } ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 102, 117 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618701515067363328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223178249473, 8.62762443885968 ]
  },
  "id_str" : "618743820390416384",
  "in_reply_to_user_id" : 14286491,
  "text" : "Connecting the dots of where I\u2019ve been using the timestamps gives a rather accurate movement history. #quantifiedself http:\/\/t.co\/BPLcUYDn0E",
  "id" : 618743820390416384,
  "in_reply_to_status_id" : 618701515067363328,
  "created_at" : "2015-07-08 11:29:57 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/gPBvx120dh",
      "expanded_url" : "http:\/\/media3.giphy.com\/media\/4I9dMCXLyifKM\/giphy.gif",
      "display_url" : "media3.giphy.com\/media\/4I9dMCXL\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "618701156638965761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222229507267, 8.627630870752807 ]
  },
  "id_str" : "618702131286007808",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot that\u2019s a shame http:\/\/t.co\/gPBvx120dh",
  "id" : 618702131286007808,
  "in_reply_to_status_id" : 618701156638965761,
  "created_at" : "2015-07-08 08:44:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/618701515067363328\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/8CRBSx2leB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJYRv61WwAAE87H.png",
      "id_str" : "618701513754591232",
      "id" : 618701513754591232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJYRv61WwAAE87H.png",
      "sizes" : [ {
        "h" : 2234,
        "resize" : "fit",
        "w" : 4251
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1076,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/8CRBSx2leB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222854760833, 8.627611370351607 ]
  },
  "id_str" : "618701515067363328",
  "text" : "Where I\u2019ve been since 2011, according to my tweets. http:\/\/t.co\/8CRBSx2leB",
  "id" : 618701515067363328,
  "created_at" : "2015-07-08 08:41:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/d5oQsJ256x",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view2\/1362352\/dog-exploding-o.gif",
      "display_url" : "stream1.gifsoup.com\/view2\/1362352\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "618698825880965120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228476228014, 8.627576190201882 ]
  },
  "id_str" : "618700473273569280",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/d5oQsJ256x",
  "id" : 618700473273569280,
  "in_reply_to_status_id" : 618698825880965120,
  "created_at" : "2015-07-08 08:37:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618669638080155649",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220830682361, 8.62762107129568 ]
  },
  "id_str" : "618686647320842240",
  "in_reply_to_user_id" : 14286491,
  "text" : "fitting: more \u2708\uFE0F to come! \uD83D\uDC4D",
  "id" : 618686647320842240,
  "in_reply_to_status_id" : 618669638080155649,
  "created_at" : "2015-07-08 07:42:46 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/bwCFTRJdM9",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Gallery_of_passport_stamps_by_country_or_territory",
      "display_url" : "en.wikipedia.org\/wiki\/Gallery_o\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222065498196, 8.627607490516434 ]
  },
  "id_str" : "618669638080155649",
  "text" : "All travel is either inside the European Union or stamp collecting. https:\/\/t.co\/bwCFTRJdM9",
  "id" : 618669638080155649,
  "created_at" : "2015-07-08 06:35:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 0, 11 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618576905063698432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407800386604, 8.75332886503184 ]
  },
  "id_str" : "618577404718661632",
  "in_reply_to_user_id" : 19054513,
  "text" : "@shellyjang the benefit of tweeting a lot: you generate a huge data set to play around with ;)",
  "id" : 618577404718661632,
  "in_reply_to_status_id" : 618576905063698432,
  "created_at" : "2015-07-08 00:28:40 +0000",
  "in_reply_to_screen_name" : "shellyjang",
  "in_reply_to_user_id_str" : "19054513",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 0, 11 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618570203945762816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407822381983, 8.753331741418636 ]
  },
  "id_str" : "618571431148945408",
  "in_reply_to_user_id" : 19054513,
  "text" : "@shellyjang just watch out. tweets prior to 2011-02-01 seem to have broken timestamps (or I really only tweeted at 00:00) ;)",
  "id" : 618571431148945408,
  "in_reply_to_status_id" : 618570203945762816,
  "created_at" : "2015-07-08 00:04:56 +0000",
  "in_reply_to_screen_name" : "shellyjang",
  "in_reply_to_user_id_str" : "19054513",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 0, 11 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/EquPUegdzQ",
      "expanded_url" : "https:\/\/twitter.com\/settings\/account",
      "display_url" : "twitter.com\/settings\/accou\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "618569875905089536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407807177974, 8.753329764661917 ]
  },
  "id_str" : "618570104645795840",
  "in_reply_to_user_id" : 19054513,
  "text" : "@shellyjang https:\/\/t.co\/EquPUegdzQ down here you should find \u201Crequest archive\u201D. Gives you all tweets encoded as json.",
  "id" : 618570104645795840,
  "in_reply_to_status_id" : 618569875905089536,
  "created_at" : "2015-07-07 23:59:40 +0000",
  "in_reply_to_screen_name" : "shellyjang",
  "in_reply_to_user_id_str" : "19054513",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618531468923551744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407785811107, 8.75332695940001 ]
  },
  "id_str" : "618560879618052097",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena congratulations!",
  "id" : 618560879618052097,
  "in_reply_to_status_id" : 618531468923551744,
  "created_at" : "2015-07-07 23:23:00 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618558472905453568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407809926191, 8.75333011490806 ]
  },
  "id_str" : "618558799318777856",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy yep, ggplot2 + ggthemes + cowplot.",
  "id" : 618558799318777856,
  "in_reply_to_status_id" : 618558472905453568,
  "created_at" : "2015-07-07 23:14:44 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 93, 104 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/618558169254658048\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/evfBmBj2f7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJWPYD2WoAAwfw6.png",
      "id_str" : "618558167346225152",
      "id" : 618558167346225152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJWPYD2WoAAwfw6.png",
      "sizes" : [ {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2234,
        "resize" : "fit",
        "w" : 4251
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1076,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/evfBmBj2f7"
    } ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 73, 88 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618421468070825984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407696770332, 8.753327877677151 ]
  },
  "id_str" : "618558169254658048",
  "in_reply_to_user_id" : 14286491,
  "text" : "Playing around with your own twitter archive can be pretty cool as well. #quantifiedself \/cc @shellyjang http:\/\/t.co\/evfBmBj2f7",
  "id" : 618558169254658048,
  "in_reply_to_status_id" : 618421468070825984,
  "created_at" : "2015-07-07 23:12:14 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herten",
      "screen_name" : "AndiH",
      "indices" : [ 0, 6 ],
      "id_str" : "4586881",
      "id" : 4586881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618473822384222208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221704730971, 8.627631668659184 ]
  },
  "id_str" : "618473968849321984",
  "in_reply_to_user_id" : 4586881,
  "text" : "@AndiH ich mach einen guten Teil meines Datawranglings sowieso in Python, da w\u00E4re es nett nicht noch mal zu wechseln auf den letzten Metern.",
  "id" : 618473968849321984,
  "in_reply_to_status_id" : 618473822384222208,
  "created_at" : "2015-07-07 17:37:39 +0000",
  "in_reply_to_screen_name" : "AndiH",
  "in_reply_to_user_id_str" : "4586881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Herten",
      "screen_name" : "AndiH",
      "indices" : [ 0, 6 ],
      "id_str" : "4586881",
      "id" : 4586881
    }, {
      "name" : "die_krabbe",
      "screen_name" : "die_krabbe",
      "indices" : [ 7, 18 ],
      "id_str" : "8991502",
      "id" : 8991502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618472672574480388",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228076027047, 8.62756224011549 ]
  },
  "id_str" : "618473407194267648",
  "in_reply_to_user_id" : 4586881,
  "text" : "@AndiH @die_krabbe I hadn\u2019t (or maybe it\u2019s somewhere in my instapaper already). Still would love to switch to Python-only.",
  "id" : 618473407194267648,
  "in_reply_to_status_id" : 618472672574480388,
  "created_at" : "2015-07-07 17:35:25 +0000",
  "in_reply_to_screen_name" : "AndiH",
  "in_reply_to_user_id_str" : "4586881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "die_krabbe",
      "screen_name" : "die_krabbe",
      "indices" : [ 0, 11 ],
      "id_str" : "8991502",
      "id" : 8991502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618472072239542272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224233806763, 8.627612746753798 ]
  },
  "id_str" : "618472705319436292",
  "in_reply_to_user_id" : 8991502,
  "text" : "@die_krabbe it\u2019s R all the way down \uD83D\uDC22: ggplot2 (geom_tile + scale_fill_gradient + coord_polar) &amp; ggthemes (tufte, but changed font)",
  "id" : 618472705319436292,
  "in_reply_to_status_id" : 618472072239542272,
  "created_at" : "2015-07-07 17:32:38 +0000",
  "in_reply_to_screen_name" : "die_krabbe",
  "in_reply_to_user_id_str" : "8991502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Hae Kyung Im",
      "screen_name" : "hakyim",
      "indices" : [ 10, 17 ],
      "id_str" : "84626947",
      "id" : 84626947
    }, {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 18, 27 ],
      "id_str" : "495517322",
      "id" : 495517322
    }, {
      "name" : "Arvind Narayanan",
      "screen_name" : "random_walker",
      "indices" : [ 28, 42 ],
      "id_str" : "10834752",
      "id" : 10834752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618433039580983296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224470232419, 8.62759321408788 ]
  },
  "id_str" : "618471113371348992",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @hakyim @erlichya @random_walker yes, but I think so far it\u2019s only pictures of eyes and less than 50 participants.",
  "id" : 618471113371348992,
  "in_reply_to_status_id" : 618433039580983296,
  "created_at" : "2015-07-07 17:26:18 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "die_krabbe",
      "screen_name" : "die_krabbe",
      "indices" : [ 0, 11 ],
      "id_str" : "8991502",
      "id" : 8991502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618430004699992064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224470232419, 8.62759321408788 ]
  },
  "id_str" : "618471008245317632",
  "in_reply_to_user_id" : 8991502,
  "text" : "@die_krabbe thanks, ggplot2 is just awesome. :3",
  "id" : 618471008245317632,
  "in_reply_to_status_id" : 618430004699992064,
  "created_at" : "2015-07-07 17:25:53 +0000",
  "in_reply_to_screen_name" : "die_krabbe",
  "in_reply_to_user_id_str" : "8991502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. Shelly Jang",
      "screen_name" : "shellyjang",
      "indices" : [ 89, 100 ],
      "id_str" : "19054513",
      "id" : 19054513
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/618421468070825984\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/g4wy6MVLM7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJUTDCyWoAAvP7i.png",
      "id_str" : "618421466841915392",
      "id" : 618421466841915392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJUTDCyWoAAvP7i.png",
      "sizes" : [ {
        "h" : 2198,
        "resize" : "fit",
        "w" : 2303
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1145,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1955,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 649,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/g4wy6MVLM7"
    } ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 69, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226855165396, 8.62757800158675 ]
  },
  "id_str" : "618421468070825984",
  "text" : "my chat habits per weekday\/hour, based on \u00B1 complete data from 2013. #quantifiedself \/cc @shellyjang http:\/\/t.co\/g4wy6MVLM7",
  "id" : 618421468070825984,
  "created_at" : "2015-07-07 14:09:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17244990995675, 8.627517541923767 ]
  },
  "id_str" : "618363474784206848",
  "text" : "I guess it will be the first time that I succumb to preparing slides midair. \u2708\uFE0F\uD83D\uDCCA",
  "id" : 618363474784206848,
  "created_at" : "2015-07-07 10:18:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226748032515, 8.62759487925843 ]
  },
  "id_str" : "618338231520768000",
  "text" : "Today\u2019s seminar: The Very Memory-Hungry ConCaterpillar \uD83D\uDCBE\uD83D\uDC1B",
  "id" : 618338231520768000,
  "created_at" : "2015-07-07 08:38:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Hill",
      "screen_name" : "Sci_Phile",
      "indices" : [ 3, 13 ],
      "id_str" : "60709500",
      "id" : 60709500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618313975441268737",
  "text" : "RT @Sci_Phile: Sharks are older than trees.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618216822727290880",
    "text" : "Sharks are older than trees.",
    "id" : 618216822727290880,
    "created_at" : "2015-07-07 00:35:51 +0000",
    "user" : {
      "name" : "Kyle Hill",
      "screen_name" : "Sci_Phile",
      "protected" : false,
      "id_str" : "60709500",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/928411502159134720\/zvY8LnWg_normal.jpg",
      "id" : 60709500,
      "verified" : true
    }
  },
  "id" : 618313975441268737,
  "created_at" : "2015-07-07 07:01:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/1h5Eq94Nna",
      "expanded_url" : "https:\/\/instagram.com\/p\/401otDhwo4\/",
      "display_url" : "instagram.com\/p\/401otDhwo4\/"
    } ]
  },
  "geo" : { },
  "id_str" : "618312061420965888",
  "text" : "Of late my secret skill is breaking my vision aids just before embarking on int. travel. Before it\u2026 https:\/\/t.co\/1h5Eq94Nna",
  "id" : 618312061420965888,
  "created_at" : "2015-07-07 06:54:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618302256237182977",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224854522957, 8.627593437826445 ]
  },
  "id_str" : "618302678163193856",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek perfect, looking forward to it!",
  "id" : 618302678163193856,
  "in_reply_to_status_id" : 618302256237182977,
  "created_at" : "2015-07-07 06:17:00 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618295892702011392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223834976281, 8.627601870098506 ]
  },
  "id_str" : "618301945057558529",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek happy to hear that I\u2019m not alone in this. And nice freudian! (btw: wanna catch up on the drinks we missed in PR when in Vienna? ;))",
  "id" : 618301945057558529,
  "in_reply_to_status_id" : 618295892702011392,
  "created_at" : "2015-07-07 06:14:05 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618293315830706176",
  "text" : "Explorative data analysis is just too much fun. Somehow went from \u2018let me quickly plot this\u2019 to \u2018why is it 3am again?!\u2019.",
  "id" : 618293315830706176,
  "created_at" : "2015-07-07 05:39:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 10, 19 ],
      "id_str" : "495517322",
      "id" : 495517322
    }, {
      "name" : "Arvind Narayanan",
      "screen_name" : "random_walker",
      "indices" : [ 20, 34 ],
      "id_str" : "10834752",
      "id" : 10834752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/PGttcT3Kbg",
      "expanded_url" : "https:\/\/hal.archives-ouvertes.fr\/hal-01151960\/",
      "display_url" : "hal.archives-ouvertes.fr\/hal-01151960\/"
    } ]
  },
  "in_reply_to_status_id_str" : "618179697856368640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408127194531, 8.753337318998668 ]
  },
  "id_str" : "618182119249022976",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @erlichya @random_walker combinatorics-wise that\u2019s probably not too unlikely, similar to Humbert et al? https:\/\/t.co\/PGttcT3Kbg",
  "id" : 618182119249022976,
  "in_reply_to_status_id" : 618179697856368640,
  "created_at" : "2015-07-06 22:17:57 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arvind Narayanan",
      "screen_name" : "random_walker",
      "indices" : [ 3, 17 ],
      "id_str" : "10834752",
      "id" : 10834752
    }, {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 129, 138 ],
      "id_str" : "495517322",
      "id" : 495517322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/CWiqSK648H",
      "expanded_url" : "http:\/\/www.nature.com\/nrg\/journal\/v15\/n6\/full\/nrg3723.html#ref-link-73",
      "display_url" : "nature.com\/nrg\/journal\/v1\u2026"
    }, {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/JucNM5L4b9",
      "expanded_url" : "http:\/\/thenewinquiry.com\/sci-fi-crime-drama-with-a-strong-black-lead\/",
      "display_url" : "thenewinquiry.com\/sci-fi-crime-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "618178659405426688",
  "text" : "RT @random_walker: Making suspect facial sketches based on DNA is pseudoscience http:\/\/t.co\/CWiqSK648H http:\/\/t.co\/JucNM5L4b9 cc @erlichya",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yaniv (((Erlich)))",
        "screen_name" : "erlichya",
        "indices" : [ 110, 119 ],
        "id_str" : "495517322",
        "id" : 495517322
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/CWiqSK648H",
        "expanded_url" : "http:\/\/www.nature.com\/nrg\/journal\/v15\/n6\/full\/nrg3723.html#ref-link-73",
        "display_url" : "nature.com\/nrg\/journal\/v1\u2026"
      }, {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/JucNM5L4b9",
        "expanded_url" : "http:\/\/thenewinquiry.com\/sci-fi-crime-drama-with-a-strong-black-lead\/",
        "display_url" : "thenewinquiry.com\/sci-fi-crime-d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "618177485553987584",
    "text" : "Making suspect facial sketches based on DNA is pseudoscience http:\/\/t.co\/CWiqSK648H http:\/\/t.co\/JucNM5L4b9 cc @erlichya",
    "id" : 618177485553987584,
    "created_at" : "2015-07-06 21:59:32 +0000",
    "user" : {
      "name" : "Arvind Narayanan",
      "screen_name" : "random_walker",
      "protected" : false,
      "id_str" : "10834752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/575322862917001217\/QsEvFqX3_normal.jpeg",
      "id" : 10834752,
      "verified" : true
    }
  },
  "id" : 618178659405426688,
  "created_at" : "2015-07-06 22:04:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/S4sTjPqdwj",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/88",
      "display_url" : "existentialcomics.com\/comic\/88"
    } ]
  },
  "geo" : { },
  "id_str" : "618175454260953092",
  "text" : "Leibniz admits that Monadology was an elaborate April Fools Joke http:\/\/t.co\/S4sTjPqdwj",
  "id" : 618175454260953092,
  "created_at" : "2015-07-06 21:51:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/618159119044841472\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/Dkmf1mP6CD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJQkcTfXAAA5XpX.png",
      "id_str" : "618159117543342080",
      "id" : 618159117543342080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJQkcTfXAAA5XpX.png",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 453
      } ],
      "display_url" : "pic.twitter.com\/Dkmf1mP6CD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408232652487, 8.75335118670239 ]
  },
  "id_str" : "618159119044841472",
  "text" : "A book I would love to read. http:\/\/t.co\/Dkmf1mP6CD",
  "id" : 618159119044841472,
  "created_at" : "2015-07-06 20:46:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rockstart",
      "screen_name" : "rockstart",
      "indices" : [ 3, 13 ],
      "id_str" : "191381510",
      "id" : 191381510
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DigitalHealth",
      "indices" : [ 89, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/thphxi7FnY",
      "expanded_url" : "http:\/\/bit.ly\/1JCk1DN",
      "display_url" : "bit.ly\/1JCk1DN"
    } ]
  },
  "geo" : { },
  "id_str" : "618091983375069184",
  "text" : "RT @rockstart: 2 more weeks to submit your startup application for Rockstart Accelerator #DigitalHealth: http:\/\/t.co\/thphxi7FnY http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockstart\/status\/618034163619270657\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/rnsOYUFCat",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJOyzBbUMAE9GH4.jpg",
        "id_str" : "618034163505967105",
        "id" : 618034163505967105,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJOyzBbUMAE9GH4.jpg",
        "sizes" : [ {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/rnsOYUFCat"
      } ],
      "hashtags" : [ {
        "text" : "DigitalHealth",
        "indices" : [ 74, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/thphxi7FnY",
        "expanded_url" : "http:\/\/bit.ly\/1JCk1DN",
        "display_url" : "bit.ly\/1JCk1DN"
      } ]
    },
    "geo" : { },
    "id_str" : "618034163619270657",
    "text" : "2 more weeks to submit your startup application for Rockstart Accelerator #DigitalHealth: http:\/\/t.co\/thphxi7FnY http:\/\/t.co\/rnsOYUFCat",
    "id" : 618034163619270657,
    "created_at" : "2015-07-06 12:30:01 +0000",
    "user" : {
      "name" : "Rockstart",
      "screen_name" : "rockstart",
      "protected" : false,
      "id_str" : "191381510",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1435433463\/image_normal.jpg",
      "id" : 191381510,
      "verified" : false
    }
  },
  "id" : 618091983375069184,
  "created_at" : "2015-07-06 16:19:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dedalus Root",
      "screen_name" : "DedalusRoot",
      "indices" : [ 0, 12 ],
      "id_str" : "112733212",
      "id" : 112733212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618018081185660928",
  "geo" : { },
  "id_str" : "618049593780080640",
  "in_reply_to_user_id" : 112733212,
  "text" : "@DedalusRoot nom!",
  "id" : 618049593780080640,
  "in_reply_to_status_id" : 618018081185660928,
  "created_at" : "2015-07-06 13:31:20 +0000",
  "in_reply_to_screen_name" : "DedalusRoot",
  "in_reply_to_user_id_str" : "112733212",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618008752600518656",
  "text" : "\u00ABEven if you are sitting on the Illumina beach towel, putting your feet into the pool is not \u201Cdoing Pool-seq\u201D by any reasonable standard!\u00BB",
  "id" : 618008752600518656,
  "created_at" : "2015-07-06 10:49:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/hqPXQeu4aa",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/87",
      "display_url" : "existentialcomics.com\/comic\/87"
    } ]
  },
  "in_reply_to_status_id_str" : "617992107547066368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223799879995, 8.6275908641197 ]
  },
  "id_str" : "617993906702131200",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek http:\/\/t.co\/hqPXQeu4aa basically it\u2019s this ;-)",
  "id" : 617993906702131200,
  "in_reply_to_status_id" : 617992107547066368,
  "created_at" : "2015-07-06 09:50:03 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/qvgs0kmrgb",
      "expanded_url" : "https:\/\/twitter.com\/AliciaOshlack\/status\/616881898132930560",
      "display_url" : "twitter.com\/AliciaOshlack\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "617993006357028864",
  "text" : "\u00ABWe should not fault a method for finding difference in measured values, when differences are due to batch effect\u00BB https:\/\/t.co\/qvgs0kmrgb",
  "id" : 617993006357028864,
  "created_at" : "2015-07-06 09:46:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617991378115665920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17220426317883, 8.627591645903317 ]
  },
  "id_str" : "617991713915826177",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek I always assumed academia requires your attitude to bleed despair, otherwise you\u2019d be ill-fitted?",
  "id" : 617991713915826177,
  "in_reply_to_status_id" : 617991378115665920,
  "created_at" : "2015-07-06 09:41:20 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/n50TMShuY1",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/07\/04\/canadas-brave-resistance-ver.html",
      "display_url" : "boingboing.net\/2015\/07\/04\/can\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226159051582, 8.62759437930912 ]
  },
  "id_str" : "617991168194953216",
  "text" : "\u00ABCanada's brave resistance versus America's giant killer\u00A0robots\u00BB The latest installment of \uD83C\uDDE8\uD83C\uDDE6 vs \uD83C\uDDFA\uD83C\uDDF8 sounds like fun. http:\/\/t.co\/n50TMShuY1",
  "id" : 617991168194953216,
  "created_at" : "2015-07-06 09:39:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/Om3X8uOKsl",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/123224336905\/trying-to-socialize-with-non-scientists",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/123224336\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224604605386, 8.627617844554463 ]
  },
  "id_str" : "617983934740213760",
  "text" : "guilty as charged http:\/\/t.co\/Om3X8uOKsl",
  "id" : 617983934740213760,
  "created_at" : "2015-07-06 09:10:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/xJoaKbxJ90",
      "expanded_url" : "https:\/\/medium.com\/matter\/everything-is-yours-everything-is-not-yours-d6f66bd9c6f9",
      "display_url" : "medium.com\/matter\/everyth\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223086016685, 8.627611509672757 ]
  },
  "id_str" : "617962489913954305",
  "text" : "\u00ABIt\u2019s strange, how you go from a being person who is away from home to a person with no home at all.\u00BB https:\/\/t.co\/xJoaKbxJ90",
  "id" : 617962489913954305,
  "created_at" : "2015-07-06 07:45:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617416960758845440",
  "geo" : { },
  "id_str" : "617417312698793984",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn guess it depends on how well formed the answers are. But in principle: yes! :)",
  "id" : 617417312698793984,
  "in_reply_to_status_id" : 617416960758845440,
  "created_at" : "2015-07-04 19:38:53 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/33EkktPlWU",
      "expanded_url" : "https:\/\/instagram.com\/p\/4uepx7Bwhl\/",
      "display_url" : "instagram.com\/p\/4uepx7Bwhl\/"
    } ]
  },
  "geo" : { },
  "id_str" : "617417095916191744",
  "text" : "Hipster-Foodie https:\/\/t.co\/33EkktPlWU",
  "id" : 617417095916191744,
  "created_at" : "2015-07-04 19:38:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Broderick Greer",
      "screen_name" : "BroderickGreer",
      "indices" : [ 3, 18 ],
      "id_str" : "412008580",
      "id" : 412008580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/ABaUcLuW3t",
      "expanded_url" : "http:\/\/www.theguardian.com\/us-news\/2015\/jul\/01\/gary-younge-farewell-to-america",
      "display_url" : "theguardian.com\/us-news\/2015\/j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "617381376007012352",
  "text" : "RT @BroderickGreer: \"...the summers, like hurricanes, have had names...full names like Trayvon Martin...\" http:\/\/t.co\/ABaUcLuW3t http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BroderickGreer\/status\/616607170235207680\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/iMmi9Of0dy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CI6g8nrVAAAupU8.jpg",
        "id_str" : "616607162299645952",
        "id" : 616607162299645952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CI6g8nrVAAAupU8.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 460,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 305,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 460,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 460,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/iMmi9Of0dy"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/ABaUcLuW3t",
        "expanded_url" : "http:\/\/www.theguardian.com\/us-news\/2015\/jul\/01\/gary-younge-farewell-to-america",
        "display_url" : "theguardian.com\/us-news\/2015\/j\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "616607170235207680",
    "text" : "\"...the summers, like hurricanes, have had names...full names like Trayvon Martin...\" http:\/\/t.co\/ABaUcLuW3t http:\/\/t.co\/iMmi9Of0dy",
    "id" : 616607170235207680,
    "created_at" : "2015-07-02 13:59:40 +0000",
    "user" : {
      "name" : "Broderick Greer",
      "screen_name" : "BroderickGreer",
      "protected" : false,
      "id_str" : "412008580",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/921369200974733312\/f91GUVNJ_normal.jpg",
      "id" : 412008580,
      "verified" : true
    }
  },
  "id" : 617381376007012352,
  "created_at" : "2015-07-04 17:16:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe15",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/NdGRx6KPa5",
      "expanded_url" : "https:\/\/instagram.com\/p\/4uMO6QBwnu\/",
      "display_url" : "instagram.com\/p\/4uMO6QBwnu\/"
    } ]
  },
  "geo" : { },
  "id_str" : "617376591363096576",
  "text" : "Getting ready for #smbe15 https:\/\/t.co\/NdGRx6KPa5",
  "id" : 617376591363096576,
  "created_at" : "2015-07-04 16:57:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617305339579506689",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408160880257, 8.753338844182728 ]
  },
  "id_str" : "617311229665783813",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer very nice. Next time I\u2019m in iceland i should try to go for a visit. :)",
  "id" : 617311229665783813,
  "in_reply_to_status_id" : 617305339579506689,
  "created_at" : "2015-07-04 12:37:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 114, 130 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/F3kdb5Wxlp",
      "expanded_url" : "http:\/\/nautil.us\/issue\/26\/color\/bring-us-your-genes",
      "display_url" : "nautil.us\/issue\/26\/color\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "617311103333330944",
  "text" : "RT @PhilippBayer: \"Bring Us Your Genes - A Viking scientist\u2019s quest to conquer disease\" http:\/\/t.co\/F3kdb5Wxlp cc @gedankenstuecke #longrea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 96, 112 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "longreads",
        "indices" : [ 113, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/F3kdb5Wxlp",
        "expanded_url" : "http:\/\/nautil.us\/issue\/26\/color\/bring-us-your-genes",
        "display_url" : "nautil.us\/issue\/26\/color\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "617305339579506689",
    "text" : "\"Bring Us Your Genes - A Viking scientist\u2019s quest to conquer disease\" http:\/\/t.co\/F3kdb5Wxlp cc @gedankenstuecke #longreads",
    "id" : 617305339579506689,
    "created_at" : "2015-07-04 12:13:56 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 617311103333330944,
  "created_at" : "2015-07-04 12:36:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "The New Yorker",
      "screen_name" : "NewYorker",
      "indices" : [ 82, 92 ],
      "id_str" : "14677919",
      "id" : 14677919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/32n2CKAK7D",
      "expanded_url" : "http:\/\/www.newyorker.com\/tech\/elements\/no-one-asks-to-be-buried-with-his-ipad",
      "display_url" : "newyorker.com\/tech\/elements\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "617297100188086272",
  "text" : "RT @EffyVayena: No One Asks To Be Buried with His iPad http:\/\/t.co\/32n2CKAK7D via @newyorker",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New Yorker",
        "screen_name" : "NewYorker",
        "indices" : [ 66, 76 ],
        "id_str" : "14677919",
        "id" : 14677919
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/32n2CKAK7D",
        "expanded_url" : "http:\/\/www.newyorker.com\/tech\/elements\/no-one-asks-to-be-buried-with-his-ipad",
        "display_url" : "newyorker.com\/tech\/elements\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "617228920056885249",
    "text" : "No One Asks To Be Buried with His iPad http:\/\/t.co\/32n2CKAK7D via @newyorker",
    "id" : 617228920056885249,
    "created_at" : "2015-07-04 07:10:16 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 617297100188086272,
  "created_at" : "2015-07-04 11:41:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617195017631707138",
  "geo" : { },
  "id_str" : "617271750057926656",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn would love that too. Any luck with that?",
  "id" : 617271750057926656,
  "in_reply_to_status_id" : 617195017631707138,
  "created_at" : "2015-07-04 10:00:28 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veggiepolygamy",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617268465339076608",
  "text" : "For me it\u2019s Tahina RT @_medusa_cascade: Next up on the marriage rights front: I want to be able to legally wed avocados. #veggiepolygamy",
  "id" : 617268465339076608,
  "created_at" : "2015-07-04 09:47:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Sanders",
      "screen_name" : "Foster_Dawg",
      "indices" : [ 3, 15 ],
      "id_str" : "3415929759",
      "id" : 3415929759
    }, {
      "name" : "\u03B1\u043C\u03B1\u03B7\u2202\u03B1 \u263C",
      "screen_name" : "AmandaGramig",
      "indices" : [ 90, 103 ],
      "id_str" : "1025722572",
      "id" : 1025722572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/SkZXOERQpP",
      "expanded_url" : "https:\/\/vine.co\/v\/e5DPmTAZHlh",
      "display_url" : "vine.co\/v\/e5DPmTAZHlh"
    } ]
  },
  "geo" : { },
  "id_str" : "617267679657857024",
  "text" : "RT @foster_dawg: When people criticize your relationship... \uD83D\uDC9E (W\/ Gabrielle Goodman &amp; @AmandaGramig) https:\/\/t.co\/SkZXOERQpP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u03B1\u043C\u03B1\u03B7\u2202\u03B1 \u263C",
        "screen_name" : "AmandaGramig",
        "indices" : [ 73, 86 ],
        "id_str" : "1025722572",
        "id" : 1025722572
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/SkZXOERQpP",
        "expanded_url" : "https:\/\/vine.co\/v\/e5DPmTAZHlh",
        "display_url" : "vine.co\/v\/e5DPmTAZHlh"
      } ]
    },
    "geo" : { },
    "id_str" : "613804846983049216",
    "text" : "When people criticize your relationship... \uD83D\uDC9E (W\/ Gabrielle Goodman &amp; @AmandaGramig) https:\/\/t.co\/SkZXOERQpP",
    "id" : 613804846983049216,
    "created_at" : "2015-06-24 20:24:14 +0000",
    "user" : {
      "name" : "Thomas Sanders",
      "screen_name" : "ThomasSanders",
      "protected" : false,
      "id_str" : "612750924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/893721499198046211\/G1bpj0ly_normal.jpg",
      "id" : 612750924,
      "verified" : true
    }
  },
  "id" : 617267679657857024,
  "created_at" : "2015-07-04 09:44:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Sousanis",
      "screen_name" : "Nsousanis",
      "indices" : [ 0, 10 ],
      "id_str" : "427354566",
      "id" : 427354566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617134674721116160",
  "geo" : { },
  "id_str" : "617231224780812288",
  "in_reply_to_user_id" : 427354566,
  "text" : "@Nsousanis I really loved the maps &amp; stick charts and well done in any case! :-) a project focussed on maps would be great!",
  "id" : 617231224780812288,
  "in_reply_to_status_id" : 617134674721116160,
  "created_at" : "2015-07-04 07:19:26 +0000",
  "in_reply_to_screen_name" : "Nsousanis",
  "in_reply_to_user_id_str" : "427354566",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617078875688931328",
  "geo" : { },
  "id_str" : "617091782032142337",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima enjoy. \uD83C\uDF4C\uD83C\uDF4D\uD83C\uDF52\uD83C\uDF53\uD83C\uDF48\u2665\uFE0F",
  "id" : 617091782032142337,
  "in_reply_to_status_id" : 617078875688931328,
  "created_at" : "2015-07-03 22:05:20 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617066118260359168",
  "geo" : { },
  "id_str" : "617069462915821568",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima nearly made it!",
  "id" : 617069462915821568,
  "in_reply_to_status_id" : 617066118260359168,
  "created_at" : "2015-07-03 20:36:39 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meredith L Patterson",
      "screen_name" : "maradydd",
      "indices" : [ 3, 12 ],
      "id_str" : "7601492",
      "id" : 7601492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/HWp7uKJz4m",
      "expanded_url" : "https:\/\/medium.com\/@maradydd\/on-port-80-d8d6d3443d9a",
      "display_url" : "medium.com\/@maradydd\/on-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "617069320385003520",
  "text" : "RT @maradydd: On Port 80, a short piece motivated by today's Reddit blackout. https:\/\/t.co\/HWp7uKJz4m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/HWp7uKJz4m",
        "expanded_url" : "https:\/\/medium.com\/@maradydd\/on-port-80-d8d6d3443d9a",
        "display_url" : "medium.com\/@maradydd\/on-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "616980732246892544",
    "text" : "On Port 80, a short piece motivated by today's Reddit blackout. https:\/\/t.co\/HWp7uKJz4m",
    "id" : 616980732246892544,
    "created_at" : "2015-07-03 14:44:04 +0000",
    "user" : {
      "name" : "Meredith L Patterson",
      "screen_name" : "maradydd",
      "protected" : false,
      "id_str" : "7601492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/24374252\/face_normal.jpg",
      "id" : 7601492,
      "verified" : true
    }
  },
  "id" : 617069320385003520,
  "created_at" : "2015-07-03 20:36:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "addingfueltothefire",
      "indices" : [ 63, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/kP2ufK5lLz",
      "expanded_url" : "https:\/\/twitter.com\/NazeefaFatima\/status\/617043758656417792",
      "display_url" : "twitter.com\/NazeefaFatima\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "617062671586865152",
  "text" : "Basic computer vision applied to microscopy images: in or out? #addingfueltothefire https:\/\/t.co\/kP2ufK5lLz",
  "id" : 617062671586865152,
  "created_at" : "2015-07-03 20:09:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/617060911598170112\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/V2M0F4FauR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJA9oTGWcAAz1Kk.jpg",
      "id_str" : "617060911480729600",
      "id" : 617060911480729600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJA9oTGWcAAz1Kk.jpg",
      "sizes" : [ {
        "h" : 862,
        "resize" : "fit",
        "w" : 862
      }, {
        "h" : 862,
        "resize" : "fit",
        "w" : 862
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 862,
        "resize" : "fit",
        "w" : 862
      } ],
      "display_url" : "pic.twitter.com\/V2M0F4FauR"
    } ],
    "hashtags" : [ {
      "text" : "unflattening",
      "indices" : [ 11, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617060911598170112",
  "text" : "Also nice: #unflattening features the Dymaxion map (no Gall-Peters though). http:\/\/t.co\/V2M0F4FauR",
  "id" : 617060911598170112,
  "created_at" : "2015-07-03 20:02:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Moore",
      "screen_name" : "peromhc",
      "indices" : [ 0, 8 ],
      "id_str" : "4302347242",
      "id" : 4302347242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617015184314486784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140823414509, 8.753326935474908 ]
  },
  "id_str" : "617058381371715584",
  "in_reply_to_user_id" : 11824072,
  "text" : "@PeroMHC i see, I would like to scaffolding existing assembly w\/ Illumina MP + PacBio data. Will let you know how it works out.",
  "id" : 617058381371715584,
  "in_reply_to_status_id" : 617015184314486784,
  "created_at" : "2015-07-03 19:52:37 +0000",
  "in_reply_to_screen_name" : "macmanes",
  "in_reply_to_user_id_str" : "11824072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/617057753220153345\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/7plfngzKli",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJA6wdZXAAEP-6W.jpg",
      "id_str" : "617057753148882945",
      "id" : 617057753148882945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJA6wdZXAAEP-6W.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 950,
        "resize" : "fit",
        "w" : 1266
      }, {
        "h" : 950,
        "resize" : "fit",
        "w" : 1266
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/7plfngzKli"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617057753220153345",
  "text" : "Standardization according to 'Unflattening'. http:\/\/t.co\/7plfngzKli",
  "id" : 617057753220153345,
  "created_at" : "2015-07-03 19:50:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Moore",
      "screen_name" : "peromhc",
      "indices" : [ 0, 8 ],
      "id_str" : "4302347242",
      "id" : 4302347242
    }, {
      "name" : "The Assemblathon",
      "screen_name" : "assemblathon",
      "indices" : [ 9, 22 ],
      "id_str" : "216793572",
      "id" : 216793572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617001766396235776",
  "geo" : { },
  "id_str" : "617014893250805761",
  "in_reply_to_user_id" : 11824072,
  "text" : "@PeroMHC @assemblathon thanks, will give it a try then. Did you use it with PacBio+Illumina? :)",
  "id" : 617014893250805761,
  "in_reply_to_status_id" : 617001766396235776,
  "created_at" : "2015-07-03 16:59:48 +0000",
  "in_reply_to_screen_name" : "macmanes",
  "in_reply_to_user_id_str" : "11824072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/vDxJgl1Rc3",
      "expanded_url" : "https:\/\/youtube.com\/watch?v=y9K18CGEeiI",
      "display_url" : "youtube.com\/watch?v=y9K18C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616972893919047680",
  "text" : "Not saying the weather is turning us stupid, but this is looping in our office. https:\/\/t.co\/vDxJgl1Rc3",
  "id" : 616972893919047680,
  "created_at" : "2015-07-03 14:12:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/0cS27wOin8",
      "expanded_url" : "https:\/\/instagram.com\/p\/4rS-xiBwl8\/",
      "display_url" : "instagram.com\/p\/4rS-xiBwl8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "616969216084848640",
  "text" : "still happy https:\/\/t.co\/0cS27wOin8",
  "id" : 616969216084848640,
  "created_at" : "2015-07-03 13:58:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan Jackson",
      "screen_name" : "BioInFocus",
      "indices" : [ 3, 14 ],
      "id_str" : "233278341",
      "id" : 233278341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/6zuXtdoR9m",
      "expanded_url" : "http:\/\/www.biodiversityinfocus.com\/blog\/2015\/07\/03\/breaking-taxonomists-are-broke-will-do-what-they-need-to-do-for-funding\/",
      "display_url" : "biodiversityinfocus.com\/blog\/2015\/07\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616955513675350017",
  "text" : "RT @BioInFocus: BREAKING: Taxonomists are broke, and will do what they need to do for funding. http:\/\/t.co\/6zuXtdoR9m\n\nIn which I get snark\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AlsoGIFs",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/6zuXtdoR9m",
        "expanded_url" : "http:\/\/www.biodiversityinfocus.com\/blog\/2015\/07\/03\/breaking-taxonomists-are-broke-will-do-what-they-need-to-do-for-funding\/",
        "display_url" : "biodiversityinfocus.com\/blog\/2015\/07\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "616875402749964288",
    "text" : "BREAKING: Taxonomists are broke, and will do what they need to do for funding. http:\/\/t.co\/6zuXtdoR9m\n\nIn which I get snarky. #AlsoGIFs",
    "id" : 616875402749964288,
    "created_at" : "2015-07-03 07:45:31 +0000",
    "user" : {
      "name" : "Morgan Jackson",
      "screen_name" : "BioInFocus",
      "protected" : false,
      "id_str" : "233278341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514517277631197184\/YVXT30z7_normal.jpeg",
      "id" : 233278341,
      "verified" : false
    }
  },
  "id" : 616955513675350017,
  "created_at" : "2015-07-03 13:03:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/daSPJblY7i",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0131468",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722357007576, 8.62761022461226 ]
  },
  "id_str" : "616953508059856896",
  "text" : "The \u2018kissing your dog\u2019-microbiome http:\/\/t.co\/daSPJblY7i",
  "id" : 616953508059856896,
  "created_at" : "2015-07-03 12:55:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/vpZNJpDbdi",
      "expanded_url" : "https:\/\/instagram.com\/p\/4qwL92hwm7\/",
      "display_url" : "instagram.com\/p\/4qwL92hwm7\/"
    } ]
  },
  "geo" : { },
  "id_str" : "616892703373197312",
  "text" : "Looks like the shield bug I saved from the pool will be fine after all. https:\/\/t.co\/vpZNJpDbdi",
  "id" : 616892703373197312,
  "created_at" : "2015-07-03 08:54:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/218NPw14gy",
      "expanded_url" : "http:\/\/images3.wikia.nocookie.net\/__cb20110216082661\/fallout\/images\/2\/26\/Fo1_Tardis.gif",
      "display_url" : "images3.wikia.nocookie.net\/__cb2011021608\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "616882625270128640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226170780367, 8.627578299453075 ]
  },
  "id_str" : "616882896276688896",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ich w\u00FCrde ja behaupten die pop-culture-refs sind mehr schuld daran, e.g. http:\/\/t.co\/218NPw14gy",
  "id" : 616882896276688896,
  "in_reply_to_status_id" : 616882625270128640,
  "created_at" : "2015-07-03 08:15:18 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Pho, M.D.",
      "screen_name" : "kevinmd",
      "indices" : [ 116, 124 ],
      "id_str" : "11274452",
      "id" : 11274452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/v4kolinYvH",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=aS3xaXsh6vo&sns",
      "display_url" : "youtube.com\/watch?v=aS3xaX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616880405862576128",
  "text" : "RT @dire_tribe: Hospital readmissions, R Kelly style. There's a lot of bouncing back... http:\/\/t.co\/v4kolinYvH (via @kevinmd)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Pho, M.D.",
        "screen_name" : "kevinmd",
        "indices" : [ 100, 108 ],
        "id_str" : "11274452",
        "id" : 11274452
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/v4kolinYvH",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=aS3xaXsh6vo&sns",
        "display_url" : "youtube.com\/watch?v=aS3xaX\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "616879957172715521",
    "text" : "Hospital readmissions, R Kelly style. There's a lot of bouncing back... http:\/\/t.co\/v4kolinYvH (via @kevinmd)",
    "id" : 616879957172715521,
    "created_at" : "2015-07-03 08:03:37 +0000",
    "user" : {
      "name" : "Navjoyt Ladher",
      "screen_name" : "NavjoytLadher",
      "protected" : false,
      "id_str" : "18343072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890907451150790656\/4t5R5N8D_normal.jpg",
      "id" : 18343072,
      "verified" : false
    }
  },
  "id" : 616880405862576128,
  "created_at" : "2015-07-03 08:05:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 60, 69 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/3hPbzCfsRA",
      "expanded_url" : "https:\/\/medium.com\/war-is-boring\/why-fallout-is-the-best-nuclear-war-story-ever-told-5910918d28e4",
      "display_url" : "medium.com\/war-is-boring\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722583576282, 8.62757520648287 ]
  },
  "id_str" : "616878474184232960",
  "text" : "\u00ABWhy \u2018Fallout\u2019 Is the Best Nuclear War Story Ever Told\u00BB \/cc @JP_Stich https:\/\/t.co\/3hPbzCfsRA",
  "id" : 616878474184232960,
  "created_at" : "2015-07-03 07:57:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225106169802, 8.627578739683536 ]
  },
  "id_str" : "616874588107067392",
  "text" : "TIL about SigmaPlot. So you can push what\u2019s basically an equivalent to a not-so-fancy graphical user interface to R\/ggplot2 for 900 bucks?",
  "id" : 616874588107067392,
  "created_at" : "2015-07-03 07:42:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/dIrsiqnr71",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2015\/06\/01\/020230",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17221931677583, 8.627610364801637 ]
  },
  "id_str" : "616865229746634752",
  "text" : "genome assembly crowd: has anyone already tested OPERA-LG? http:\/\/t.co\/dIrsiqnr71",
  "id" : 616865229746634752,
  "created_at" : "2015-07-03 07:05:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/Hbx4BPB3MH",
      "expanded_url" : "http:\/\/gawker.com\/reddit-in-chaos-after-allegedly-firing-ama-coordinator-1715556970",
      "display_url" : "gawker.com\/reddit-in-chao\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17225489224693, 8.627603457815402 ]
  },
  "id_str" : "616863191377801217",
  "text" : "\u00ABTo the three subscribers of \/r\/sexwithbears, we are so sorry for your loss\u00BB http:\/\/t.co\/Hbx4BPB3MH",
  "id" : 616863191377801217,
  "created_at" : "2015-07-03 06:57:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Animal Gifs \uD83D\uDC3E",
      "screen_name" : "BabyAnimalGifs",
      "indices" : [ 3, 18 ],
      "id_str" : "2572190766",
      "id" : 2572190766
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BabyAnimalGifs\/status\/616758804328411136\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/JPfyafaoZi",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CI8q3UBXAAE-x13.png",
      "id_str" : "616758803728629761",
      "id" : 616758803728629761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CI8q3UBXAAE-x13.png",
      "sizes" : [ {
        "h" : 272,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/JPfyafaoZi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616858144749289473",
  "text" : "RT @BabyAnimalGifs: rt if this cat is more rad than u http:\/\/t.co\/JPfyafaoZi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BabyAnimalGifs\/status\/616758804328411136\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/JPfyafaoZi",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CI8q3UBXAAE-x13.png",
        "id_str" : "616758803728629761",
        "id" : 616758803728629761,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CI8q3UBXAAE-x13.png",
        "sizes" : [ {
          "h" : 272,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/JPfyafaoZi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "616758804328411136",
    "text" : "rt if this cat is more rad than u http:\/\/t.co\/JPfyafaoZi",
    "id" : 616758804328411136,
    "created_at" : "2015-07-03 00:02:12 +0000",
    "user" : {
      "name" : "Animal Gifs \uD83D\uDC3E",
      "screen_name" : "BabyAnimalGifs",
      "protected" : false,
      "id_str" : "2572190766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484962656940351488\/Ro2xhmwg_normal.jpeg",
      "id" : 2572190766,
      "verified" : false
    }
  },
  "id" : 616858144749289473,
  "created_at" : "2015-07-03 06:36:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/1OJ8Rkd4IU",
      "expanded_url" : "http:\/\/99percentinvisible.org\/episode\/johnnycab-automation-paradox-pt-2\/",
      "display_url" : "99percentinvisible.org\/episode\/johnny\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616855292232507392",
  "text" : "Driveway moment with the 99pi episode about self driving cars. :3 http:\/\/t.co\/1OJ8Rkd4IU",
  "id" : 616855292232507392,
  "created_at" : "2015-07-03 06:25:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "olja mjak",
      "screen_name" : "phylorich",
      "indices" : [ 3, 13 ],
      "id_str" : "162237887",
      "id" : 162237887
    }, {
      "name" : "Colin Osborne",
      "screen_name" : "sheffieldplants",
      "indices" : [ 123, 139 ],
      "id_str" : "91305834",
      "id" : 91305834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/8e9CmmPIlF",
      "expanded_url" : "http:\/\/www.nytimes.com\/interactive\/2015\/07\/03\/upshot\/a-quick-puzzle-to-test-your-problem-solving.html",
      "display_url" : "nytimes.com\/interactive\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616739593979863040",
  "text" : "RT @phylorich: Hypothesis: people who enjoy test driven development will do well on this puzzle http:\/\/t.co\/8e9CmmPIlF via @sheffieldplants",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Colin Osborne",
        "screen_name" : "sheffieldplants",
        "indices" : [ 108, 124 ],
        "id_str" : "91305834",
        "id" : 91305834
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/8e9CmmPIlF",
        "expanded_url" : "http:\/\/www.nytimes.com\/interactive\/2015\/07\/03\/upshot\/a-quick-puzzle-to-test-your-problem-solving.html",
        "display_url" : "nytimes.com\/interactive\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "616731630690959360",
    "text" : "Hypothesis: people who enjoy test driven development will do well on this puzzle http:\/\/t.co\/8e9CmmPIlF via @sheffieldplants",
    "id" : 616731630690959360,
    "created_at" : "2015-07-02 22:14:13 +0000",
    "user" : {
      "name" : "Rich FitzJohn",
      "screen_name" : "rgfitzjohn",
      "protected" : false,
      "id_str" : "189172089",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2376413175\/cfrf8uf9wvrza9a8ymve_normal.jpeg",
      "id" : 189172089,
      "verified" : false
    }
  },
  "id" : 616739593979863040,
  "created_at" : "2015-07-02 22:45:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/5We2H4KzVS",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/blink1_morse",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408215226061, 8.753320928573956 ]
  },
  "id_str" : "616725812201582592",
  "text" : "Sweet, someone took the time to fix some stuff on my 2 year old morse-code for the blink1 https:\/\/t.co\/5We2H4KzVS",
  "id" : 616725812201582592,
  "created_at" : "2015-07-02 21:51:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616678219278876672",
  "geo" : { },
  "id_str" : "616705132588216320",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr well done \\o\/",
  "id" : 616705132588216320,
  "in_reply_to_status_id" : 616678219278876672,
  "created_at" : "2015-07-02 20:28:56 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yoav Gilad",
      "screen_name" : "Y_Gilad",
      "indices" : [ 3, 11 ],
      "id_str" : "2802558480",
      "id" : 2802558480
    }, {
      "name" : "Steven Salzberg",
      "screen_name" : "StevenSalzberg1",
      "indices" : [ 78, 94 ],
      "id_str" : "782615960",
      "id" : 782615960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/DxiIcciHbm",
      "expanded_url" : "http:\/\/f1000research.com\/articles\/4-180\/v1",
      "display_url" : "f1000research.com\/articles\/4-180\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616591244987363328",
  "text" : "RT @Y_Gilad: Another attempt to use F1000 platform for a refutation study. By @StevenSalzberg1 http:\/\/t.co\/DxiIcciHbm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven Salzberg",
        "screen_name" : "StevenSalzberg1",
        "indices" : [ 65, 81 ],
        "id_str" : "782615960",
        "id" : 782615960
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/DxiIcciHbm",
        "expanded_url" : "http:\/\/f1000research.com\/articles\/4-180\/v1",
        "display_url" : "f1000research.com\/articles\/4-180\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "616585156946587648",
    "text" : "Another attempt to use F1000 platform for a refutation study. By @StevenSalzberg1 http:\/\/t.co\/DxiIcciHbm",
    "id" : 616585156946587648,
    "created_at" : "2015-07-02 12:32:11 +0000",
    "user" : {
      "name" : "Yoav Gilad",
      "screen_name" : "Y_Gilad",
      "protected" : false,
      "id_str" : "2802558480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769726601189691392\/qsKOSDDu_normal.jpg",
      "id" : 2802558480,
      "verified" : false
    }
  },
  "id" : 616591244987363328,
  "created_at" : "2015-07-02 12:56:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 3, 11 ],
      "id_str" : "454724555",
      "id" : 454724555
    }, {
      "name" : "SIB",
      "screen_name" : "ISBSIB",
      "indices" : [ 105, 112 ],
      "id_str" : "461099519",
      "id" : 461099519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/Nb4sttcqbz",
      "expanded_url" : "http:\/\/gbe.oxfordjournals.org\/content\/early\/2015\/06\/30\/gbe.evv121.short",
      "display_url" : "gbe.oxfordjournals.org\/content\/early\/\u2026"
    }, {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/l25pj51TT9",
      "expanded_url" : "http:\/\/swisstree.vital-it.ch\/species_tree",
      "display_url" : "swisstree.vital-it.ch\/species_tree"
    } ]
  },
  "geo" : { },
  "id_str" : "616584033699504128",
  "text" : "RT @marc_rr: Quest for Orthologs entails Quest for Tree of Life:\nhttp:\/\/t.co\/Nb4sttcqbz\nSwissTree server @ISBSIB http:\/\/t.co\/l25pj51TT9 HT \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SIB",
        "screen_name" : "ISBSIB",
        "indices" : [ 92, 99 ],
        "id_str" : "461099519",
        "id" : 461099519
      }, {
        "name" : "Toni Gabald\u00F3n",
        "screen_name" : "toni_gabaldon",
        "indices" : [ 126, 140 ],
        "id_str" : "839468576",
        "id" : 839468576
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/Nb4sttcqbz",
        "expanded_url" : "http:\/\/gbe.oxfordjournals.org\/content\/early\/2015\/06\/30\/gbe.evv121.short",
        "display_url" : "gbe.oxfordjournals.org\/content\/early\/\u2026"
      }, {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/l25pj51TT9",
        "expanded_url" : "http:\/\/swisstree.vital-it.ch\/species_tree",
        "display_url" : "swisstree.vital-it.ch\/species_tree"
      } ]
    },
    "geo" : { },
    "id_str" : "616515330228244480",
    "text" : "Quest for Orthologs entails Quest for Tree of Life:\nhttp:\/\/t.co\/Nb4sttcqbz\nSwissTree server @ISBSIB http:\/\/t.co\/l25pj51TT9 HT @toni_gabaldon",
    "id" : 616515330228244480,
    "created_at" : "2015-07-02 07:54:43 +0000",
    "user" : {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "protected" : false,
      "id_str" : "454724555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1751744306\/mrr_caricature_normal.jpg",
      "id" : 454724555,
      "verified" : false
    }
  },
  "id" : 616584033699504128,
  "created_at" : "2015-07-02 12:27:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 10, 24 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616575621133697024",
  "geo" : { },
  "id_str" : "616576002819530752",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @NazeefaFatima I escaped the danger zone. No need to tip-toe around any longer.",
  "id" : 616576002819530752,
  "in_reply_to_status_id" : 616575621133697024,
  "created_at" : "2015-07-02 11:55:49 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 10, 24 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616568612086792192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226830860019, 8.62757649300956 ]
  },
  "id_str" : "616569081265831936",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @NazeefaFatima if the two of you continue like this I will drown in my \u2018pool\u2019 thanks to rolling on the floor laughing. ;-)",
  "id" : 616569081265831936,
  "in_reply_to_status_id" : 616568612086792192,
  "created_at" : "2015-07-02 11:28:18 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616557285209440256",
  "geo" : { },
  "id_str" : "616563190546235392",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot containern geht : \uD83D\uDEAE\u267B\uFE0F",
  "id" : 616563190546235392,
  "in_reply_to_status_id" : 616557285209440256,
  "created_at" : "2015-07-02 11:04:54 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616558411782565888",
  "geo" : { },
  "id_str" : "616559812550262784",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83C\uDFAF\u263A\uFE0F",
  "id" : 616559812550262784,
  "in_reply_to_status_id" : 616558411782565888,
  "created_at" : "2015-07-02 10:51:29 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616555941429907456",
  "geo" : { },
  "id_str" : "616556277523742720",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima hilarious \u2665\uFE0F",
  "id" : 616556277523742720,
  "in_reply_to_status_id" : 616555941429907456,
  "created_at" : "2015-07-02 10:37:26 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 3, 17 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 19, 35 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sorrynotsorry",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616556082505367552",
  "text" : "RT @NazeefaFatima: @gedankenstuecke That's toe-tally acceptable! as long as your sole objective is to get your work done! #sorrynotsorry",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sorrynotsorry",
        "indices" : [ 103, 117 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "616550739868057601",
    "geo" : { },
    "id_str" : "616555941429907456",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke That's toe-tally acceptable! as long as your sole objective is to get your work done! #sorrynotsorry",
    "id" : 616555941429907456,
    "in_reply_to_status_id" : 616550739868057601,
    "created_at" : "2015-07-02 10:36:06 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "protected" : false,
      "id_str" : "37054704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930210077885202432\/DY8D8hGM_normal.jpg",
      "id" : 37054704,
      "verified" : false
    }
  },
  "id" : 616556082505367552,
  "created_at" : "2015-07-02 10:36:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616552847073804289",
  "geo" : { },
  "id_str" : "616555291618988032",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot i like how it\u2019s \u00ABnot getting caught\u00BB, instead of \u00ABnot speeding\u00BB. \uD83D\uDCF7\uD83D\uDE99\uD83D\uDCA8\uD83D\uDEA8\uD83D\uDE93\uD83D\uDCA8",
  "id" : 616555291618988032,
  "in_reply_to_status_id" : 616552847073804289,
  "created_at" : "2015-07-02 10:33:31 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616551671200673792",
  "geo" : { },
  "id_str" : "616552762374004736",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot the benefits of having everyone know about your fetishes. ;)",
  "id" : 616552762374004736,
  "in_reply_to_status_id" : 616551671200673792,
  "created_at" : "2015-07-02 10:23:28 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616552375847899137",
  "geo" : { },
  "id_str" : "616552596376002560",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot that\u2019s just what I wish for. Can we do one next year? \uD83C\uDF0B",
  "id" : 616552596376002560,
  "in_reply_to_status_id" : 616552375847899137,
  "created_at" : "2015-07-02 10:22:48 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/7XcRmjVFgB",
      "expanded_url" : "https:\/\/instagram.com\/p\/4oUrh1hwjZ\/",
      "display_url" : "instagram.com\/p\/4oUrh1hwjZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "616550739868057601",
  "text" : "I'm not slacking off, I'm using a standing desk! https:\/\/t.co\/7XcRmjVFgB",
  "id" : 616550739868057601,
  "created_at" : "2015-07-02 10:15:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17253879212355, 8.627547839088917 ]
  },
  "id_str" : "616530044354215936",
  "text" : "If all you know about stats originates from reading history books, everything looks like a German Tank Problem.",
  "id" : 616530044354215936,
  "created_at" : "2015-07-02 08:53:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616504504582803456",
  "text" : "Travel plans \u2665\uFE0F\u2708\uFE0F\uD83D\uDE81",
  "id" : 616504504582803456,
  "created_at" : "2015-07-02 07:11:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Assemblathon",
      "screen_name" : "assemblathon",
      "indices" : [ 3, 16 ],
      "id_str" : "216793572",
      "id" : 216793572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/wD8FMAFLUK",
      "expanded_url" : "https:\/\/twitter.com\/EduEyras\/status\/615876024971173889",
      "display_url" : "twitter.com\/EduEyras\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616504340916924416",
  "text" : "RT @assemblathon: Nice slide deck about transcripome assembly https:\/\/t.co\/wD8FMAFLUK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/wD8FMAFLUK",
        "expanded_url" : "https:\/\/twitter.com\/EduEyras\/status\/615876024971173889",
        "display_url" : "twitter.com\/EduEyras\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "615891291532988416",
    "text" : "Nice slide deck about transcripome assembly https:\/\/t.co\/wD8FMAFLUK",
    "id" : 615891291532988416,
    "created_at" : "2015-06-30 14:35:01 +0000",
    "user" : {
      "name" : "The Assemblathon",
      "screen_name" : "assemblathon",
      "protected" : false,
      "id_str" : "216793572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458989689794355202\/qgt5fqB4_normal.jpeg",
      "id" : 216793572,
      "verified" : false
    }
  },
  "id" : 616504340916924416,
  "created_at" : "2015-07-02 07:11:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 11, 22 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616401750870917120",
  "geo" : { },
  "id_str" : "616499787068801024",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn @bella_velo i hope you did raise a glass of maple syrup!",
  "id" : 616499787068801024,
  "in_reply_to_status_id" : 616401750870917120,
  "created_at" : "2015-07-02 06:52:57 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/616273799953125376\/photo\/1",
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/FfoWKPowBp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CI1xwSgW8AAhw27.png",
      "id_str" : "616273798434844672",
      "id" : 616273798434844672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CI1xwSgW8AAhw27.png",
      "sizes" : [ {
        "h" : 24,
        "resize" : "fit",
        "w" : 27
      }, {
        "h" : 24,
        "resize" : "fit",
        "w" : 27
      }, {
        "h" : 24,
        "resize" : "fit",
        "w" : 27
      }, {
        "h" : 24,
        "resize" : "fit",
        "w" : 27
      }, {
        "h" : 24,
        "resize" : "crop",
        "w" : 24
      } ],
      "display_url" : "pic.twitter.com\/FfoWKPowBp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615545074303283201",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227022712559, 8.627568355121298 ]
  },
  "id_str" : "616273799953125376",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 http:\/\/t.co\/FfoWKPowBp",
  "id" : 616273799953125376,
  "in_reply_to_status_id" : 615545074303283201,
  "created_at" : "2015-07-01 15:54:58 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/tzaiDB95iP",
      "expanded_url" : "http:\/\/xkcd.com\/1545\/",
      "display_url" : "xkcd.com\/1545\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172244059523, 8.627603316019854 ]
  },
  "id_str" : "616260106754347009",
  "text" : "I\u2019m still working on my biggest strength http:\/\/t.co\/tzaiDB95iP",
  "id" : 616260106754347009,
  "created_at" : "2015-07-01 15:00:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat Holt",
      "screen_name" : "DrKatHolt",
      "indices" : [ 3, 13 ],
      "id_str" : "2402497014",
      "id" : 2402497014
    }, {
      "name" : "Ryan Wick",
      "screen_name" : "rrwick",
      "indices" : [ 84, 91 ],
      "id_str" : "1677127723",
      "id" : 1677127723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/k1n1PLU4GC",
      "expanded_url" : "http:\/\/bioinformatics.oxfordjournals.org\/content\/early\/2015\/06\/21\/bioinformatics.btv383.abstract",
      "display_url" : "bioinformatics.oxfordjournals.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616221833675821056",
  "text" : "RT @DrKatHolt: \"Bandage: interactive visualisation of de novo genome assemblies\" by @rrwick paper is out! http:\/\/t.co\/k1n1PLU4GC http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ryan Wick",
        "screen_name" : "rrwick",
        "indices" : [ 69, 76 ],
        "id_str" : "1677127723",
        "id" : 1677127723
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/k1n1PLU4GC",
        "expanded_url" : "http:\/\/bioinformatics.oxfordjournals.org\/content\/early\/2015\/06\/21\/bioinformatics.btv383.abstract",
        "display_url" : "bioinformatics.oxfordjournals.org\/content\/early\/\u2026"
      }, {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/83BEjE7bAJ",
        "expanded_url" : "http:\/\/rrwick.github.io\/Bandage\/",
        "display_url" : "rrwick.github.io\/Bandage\/"
      } ]
    },
    "geo" : { },
    "id_str" : "616040431457964032",
    "text" : "\"Bandage: interactive visualisation of de novo genome assemblies\" by @rrwick paper is out! http:\/\/t.co\/k1n1PLU4GC http:\/\/t.co\/83BEjE7bAJ",
    "id" : 616040431457964032,
    "created_at" : "2015-07-01 00:27:38 +0000",
    "user" : {
      "name" : "Kat Holt",
      "screen_name" : "DrKatHolt",
      "protected" : false,
      "id_str" : "2402497014",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895113658006519808\/yeVm7z2g_normal.jpg",
      "id" : 2402497014,
      "verified" : false
    }
  },
  "id" : 616221833675821056,
  "created_at" : "2015-07-01 12:28:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 11, 18 ],
      "id_str" : "22910316",
      "id" : 22910316
    }, {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 19, 31 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/Hvk9lX6Zc7",
      "expanded_url" : "http:\/\/i3.kym-cdn.com\/photos\/images\/newsfeed\/000\/511\/980\/352.jpg",
      "display_url" : "i3.kym-cdn.com\/photos\/images\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "616207315885162496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228033295279, 8.627575385769939 ]
  },
  "id_str" : "616207672766021632",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @Evo2Me @terrorzicke http:\/\/t.co\/Hvk9lX6Zc7 ;)",
  "id" : 616207672766021632,
  "in_reply_to_status_id" : 616207315885162496,
  "created_at" : "2015-07-01 11:32:12 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 11, 23 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616206339040149506",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223158312087, 8.627604510004984 ]
  },
  "id_str" : "616206538710085632",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @terrorzicke Ich w\u00FCrde auch nichts verraten. Und falls da zuf\u00E4llig noch Platz f\u00FCr ein Platypus ist *pfeiff*",
  "id" : 616206538710085632,
  "in_reply_to_status_id" : 616206339040149506,
  "created_at" : "2015-07-01 11:27:42 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 0, 12 ],
      "id_str" : "14728378",
      "id" : 14728378
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 82, 92 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616205298013900804",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222403197507, 8.627619767800676 ]
  },
  "id_str" : "616205713006850048",
  "in_reply_to_user_id" : 14728378,
  "text" : "@terrorzicke lasst mich raten, rein zuf\u00E4llig ist mindestens eines im Rucksack von @Fischblog gelandet? ;)",
  "id" : 616205713006850048,
  "in_reply_to_status_id" : 616205298013900804,
  "created_at" : "2015-07-01 11:24:25 +0000",
  "in_reply_to_screen_name" : "terrorzicke",
  "in_reply_to_user_id_str" : "14728378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616185037218816000",
  "geo" : { },
  "id_str" : "616200337528066048",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach er brummte nur einen Sommer lang?",
  "id" : 616200337528066048,
  "in_reply_to_status_id" : 616185037218816000,
  "created_at" : "2015-07-01 11:03:03 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616175788606521344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233539470991, 8.627540855081547 ]
  },
  "id_str" : "616176510513348608",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer (would make a great drinking game, first to down 2000+ of those wins! ;))",
  "id" : 616176510513348608,
  "in_reply_to_status_id" : 616175788606521344,
  "created_at" : "2015-07-01 09:28:22 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/pkmcHYT9x4",
      "expanded_url" : "http:\/\/www.instructables.com\/id\/DNAquiri-the-delicious-DNA-extraction\/",
      "display_url" : "instructables.com\/id\/DNAquiri-th\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "616175788606521344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233539470991, 8.627540855081547 ]
  },
  "id_str" : "616176072409939968",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer we could do DNAquiris ;-) http:\/\/t.co\/pkmcHYT9x4",
  "id" : 616176072409939968,
  "in_reply_to_status_id" : 616175788606521344,
  "created_at" : "2015-07-01 09:26:38 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616174807084847104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234135669273, 8.627575730901015 ]
  },
  "id_str" : "616175058566971392",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer how about cccamp? :D",
  "id" : 616175058566971392,
  "in_reply_to_status_id" : 616174807084847104,
  "created_at" : "2015-07-01 09:22:36 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 56, 69 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 70, 82 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223760441602, 8.627607335280304 ]
  },
  "id_str" : "616168035200671744",
  "text" : "totally missed it, but openSNP now has 2000+ data sets! @PhilippBayer @helgerausch",
  "id" : 616168035200671744,
  "created_at" : "2015-07-01 08:54:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226019881758, 8.627591560877079 ]
  },
  "id_str" : "616161245637558272",
  "text" : "I\u2019m such a genius: second day in a row I fail at simple geometric problems thanks to forgetting about the Pythagorean theorem\u2026",
  "id" : 616161245637558272,
  "created_at" : "2015-07-01 08:27:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 14, 25 ],
      "id_str" : "3782931",
      "id" : 3782931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/oQ7eKvGyKu",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=e5K4ykE38N0",
      "display_url" : "youtube.com\/watch?v=e5K4yk\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "616150802558787585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224709867499, 8.627595121217865 ]
  },
  "id_str" : "616152362554662913",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot um den @spreeblick zu channeln: i live by the river. ;-) https:\/\/t.co\/oQ7eKvGyKu",
  "id" : 616152362554662913,
  "in_reply_to_status_id" : 616150802558787585,
  "created_at" : "2015-07-01 07:52:25 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "MIT Tech Review",
      "screen_name" : "techreview",
      "indices" : [ 94, 105 ],
      "id_str" : "15808647",
      "id" : 15808647
    }, {
      "name" : "Christian Lovis",
      "screen_name" : "chr_lovis",
      "indices" : [ 110, 120 ],
      "id_str" : "274368093",
      "id" : 274368093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/ZZCwOuedwp",
      "expanded_url" : "http:\/\/www.technologyreview.com\/view\/538866\/the-social-network-illusion-that-tricks-your-mind\/",
      "display_url" : "technologyreview.com\/view\/538866\/th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "616151866599186433",
  "text" : "RT @EffyVayena: The Social-Network Illusion That Tricks Your Mind  http:\/\/t.co\/ZZCwOuedwp &gt;@TechReview via @chr_lovis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MIT Tech Review",
        "screen_name" : "techreview",
        "indices" : [ 78, 89 ],
        "id_str" : "15808647",
        "id" : 15808647
      }, {
        "name" : "Christian Lovis",
        "screen_name" : "chr_lovis",
        "indices" : [ 94, 104 ],
        "id_str" : "274368093",
        "id" : 274368093
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/ZZCwOuedwp",
        "expanded_url" : "http:\/\/www.technologyreview.com\/view\/538866\/the-social-network-illusion-that-tricks-your-mind\/",
        "display_url" : "technologyreview.com\/view\/538866\/th\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "616150336772812800",
    "text" : "The Social-Network Illusion That Tricks Your Mind  http:\/\/t.co\/ZZCwOuedwp &gt;@TechReview via @chr_lovis",
    "id" : 616150336772812800,
    "created_at" : "2015-07-01 07:44:22 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 616151866599186433,
  "created_at" : "2015-07-01 07:50:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226602616818, 8.627584525191107 ]
  },
  "id_str" : "616147510126624768",
  "text" : "I really enjoy \u2018fact checking\u2019 texts where people already got my name wrong.",
  "id" : 616147510126624768,
  "created_at" : "2015-07-01 07:33:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 12, 22 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/226yd8okjs",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=AVDwriw6FXs",
      "display_url" : "youtube.com\/watch?v=AVDwri\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "616146694795825152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226602616818, 8.627584525191107 ]
  },
  "id_str" : "616147087412101120",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo @eltonjohn I fear it would end up like those renditions. ;-) https:\/\/t.co\/226yd8okjs",
  "id" : 616147087412101120,
  "in_reply_to_status_id" : 616146694795825152,
  "created_at" : "2015-07-01 07:31:27 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 17, 28 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 30, 40 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17223527242567, 8.627593053552786 ]
  },
  "id_str" : "616145694882181121",
  "text" : "Happy Canada Day @bella_velo, @eltonjohn et al! \uD83C\uDDE8\uD83C\uDDE6\uD83C\uDDE8\uD83C\uDDE6\uD83C\uDDE8\uD83C\uDDE6",
  "id" : 616145694882181121,
  "created_at" : "2015-07-01 07:25:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]