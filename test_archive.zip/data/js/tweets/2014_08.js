Grailbird.data.tweets_2014_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506119365654511617",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.08362543, 34.78278228 ]
  },
  "id_str" : "506122766819786755",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach safe travels :)",
  "id" : 506122766819786755,
  "in_reply_to_status_id" : 506119365654511617,
  "created_at" : "2014-08-31 16:54:05 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506111825956843520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0833761232, 34.7799347262 ]
  },
  "id_str" : "506113467070558208",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU wann muss man zur Verkostung vorbeikommen?",
  "id" : 506113467070558208,
  "in_reply_to_status_id" : 506111825956843520,
  "created_at" : "2014-08-31 16:17:08 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/TKePiq6qvl",
      "expanded_url" : "https:\/\/medium.com\/festival-of-dangerous-ideas\/philosophers-are-more-important-than-scientists-27f350d39544",
      "display_url" : "medium.com\/festival-of-da\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0834557255, 34.7799632156 ]
  },
  "id_str" : "506111374054141952",
  "text" : "\u00ABReligion may have given to many hope for the world to come, but it is philosophy that gives us hope for this world\u00BB https:\/\/t.co\/TKePiq6qvl",
  "id" : 506111374054141952,
  "created_at" : "2014-08-31 16:08:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0832878946, 34.7799384565 ]
  },
  "id_str" : "506080496229826560",
  "text" : "\u00ABYou turn me on so much. Well, you and looking at ape phylogenies with you.\u00BB",
  "id" : 506080496229826560,
  "created_at" : "2014-08-31 14:06:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 10, 17 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 18, 24 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506071886187757568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0833936162, 34.7799466906 ]
  },
  "id_str" : "506072436887269376",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @acid23 @Lobot ne, passt bislang. Alle meine Hardware die mit umgezogen werden sollte ist mitgekommen so weit ich gesehen hab.",
  "id" : 506072436887269376,
  "in_reply_to_status_id" : 506071886187757568,
  "created_at" : "2014-08-31 13:34:05 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 10, 17 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 30, 36 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506068341031993344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0836254072, 34.7827821077 ]
  },
  "id_str" : "506071601704873984",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @acid23 Ich vermute @lobot meinte das mini was ich nutze, aber ist j\/k weil sie meinen Rechner verkauft.",
  "id" : 506071601704873984,
  "in_reply_to_status_id" : 506068341031993344,
  "created_at" : "2014-08-31 13:30:46 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506066424776114176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0836248428, 34.7827816948 ]
  },
  "id_str" : "506067321409253376",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr I\u2019m pretty sure we will come back to that offer.",
  "id" : 506067321409253376,
  "in_reply_to_status_id" : 506066424776114176,
  "created_at" : "2014-08-31 13:13:46 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506065104023330816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0836195923, 34.782776462 ]
  },
  "id_str" : "506066056629481473",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr and we missed out on all the fun! So you will have to host us again for the next time.",
  "id" : 506066056629481473,
  "in_reply_to_status_id" : 506065104023330816,
  "created_at" : "2014-08-31 13:08:44 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0833260642, 34.779892243 ]
  },
  "id_str" : "506064425414311936",
  "text" : "\u00ABA pastor will probably explain what you must do to have a good afterlife but will have little to say on what to do to have a good life.\u00BB",
  "id" : 506064425414311936,
  "created_at" : "2014-08-31 13:02:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 120, 134 ],
      "id_str" : "16066596",
      "id" : 16066596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/ax9gRKwkRP",
      "expanded_url" : "http:\/\/bjorn.tipling.com\/if-programming-languages-were-weapons",
      "display_url" : "bjorn.tipling.com\/if-programming\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0833818395, 34.7799029063 ]
  },
  "id_str" : "506059547996590081",
  "text" : "\u00ABbash is a cursed hammer, when wielded everything looks like a nail, especially your thumb.\u00BB http:\/\/t.co\/ax9gRKwkRP \/HT @onetruecathal",
  "id" : 506059547996590081,
  "created_at" : "2014-08-31 12:42:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TwistedDoodles",
      "screen_name" : "twisteddoodles",
      "indices" : [ 3, 18 ],
      "id_str" : "487584390",
      "id" : 487584390
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/twisteddoodles\/status\/505871593994612736\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/QJVYE0JM8I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwU3iHVCAAAJy7W.jpg",
      "id_str" : "505871592371388416",
      "id" : 505871592371388416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwU3iHVCAAAJy7W.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 518
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 780
      } ],
      "display_url" : "pic.twitter.com\/QJVYE0JM8I"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506055753858580480",
  "text" : "RT @twisteddoodles: Hipster ghost! http:\/\/t.co\/QJVYE0JM8I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/twisteddoodles\/status\/505871593994612736\/photo\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/QJVYE0JM8I",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwU3iHVCAAAJy7W.jpg",
        "id_str" : "505871592371388416",
        "id" : 505871592371388416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwU3iHVCAAAJy7W.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 518
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 780
        } ],
        "display_url" : "pic.twitter.com\/QJVYE0JM8I"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505871593994612736",
    "text" : "Hipster ghost! http:\/\/t.co\/QJVYE0JM8I",
    "id" : 505871593994612736,
    "created_at" : "2014-08-31 00:16:01 +0000",
    "user" : {
      "name" : "TwistedDoodles",
      "screen_name" : "twisteddoodles",
      "protected" : false,
      "id_str" : "487584390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2923852396\/20613163743438c5ee92899367284184_normal.jpeg",
      "id" : 487584390,
      "verified" : true
    }
  },
  "id" : 506055753858580480,
  "created_at" : "2014-08-31 12:27:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 7, 14 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 27, 36 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506052660110577665",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0833515127, 34.7799262069 ]
  },
  "id_str" : "506053005528293376",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @acid23 da musst du @Senficon fragen. Vorzeitiger Hardwareverlust scheint irgendwie mein Ding zu sein.",
  "id" : 506053005528293376,
  "in_reply_to_status_id" : 506052660110577665,
  "created_at" : "2014-08-31 12:16:53 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/1RD89HRClZ",
      "expanded_url" : "http:\/\/kleinanzeigen.ebay.de\/anzeigen\/s-anzeige\/macbook-pro,-early-2011,-mattes-15-zoll-display\/235867348-278-4354",
      "display_url" : "kleinanzeigen.ebay.de\/anzeigen\/s-anz\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0833515127, 34.7799262069 ]
  },
  "id_str" : "506052832689401856",
  "text" : "Kauft der @Lobot mal meinen alten Rechner ab. Vielleicht bezahlt sie mir dann ein Return-Ticket. http:\/\/t.co\/1RD89HRClZ",
  "id" : 506052832689401856,
  "created_at" : "2014-08-31 12:16:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 7, 14 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506049813881053184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0833515127, 34.7799262069 ]
  },
  "id_str" : "506052379255771136",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @acid23 tja, das hab ich jetzt wohl davon unbedingt mit dir zusammenziehen zu wollen.",
  "id" : 506052379255771136,
  "in_reply_to_status_id" : 506049813881053184,
  "created_at" : "2014-08-31 12:14:23 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/ZOLdRhY15V",
      "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/2014-a-facebook-odyssey",
      "display_url" : "mcsweeneys.net\/articles\/2014-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.083337, 34.779938 ]
  },
  "id_str" : "506035613460865024",
  "text" : "2014: A Facebook Odyssey http:\/\/t.co\/ZOLdRhY15V",
  "id" : 506035613460865024,
  "created_at" : "2014-08-31 11:07:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.08362543, 34.7825776415 ]
  },
  "id_str" : "506029135635152896",
  "text" : "\u00ABOh, there are new pictures of Hitler petting animals. Do you want to see them?\u00BB",
  "id" : 506029135635152896,
  "created_at" : "2014-08-31 10:42:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/JvcocbwcSa",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/DyCdWjqXYOs\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.083344, 34.779928 ]
  },
  "id_str" : "506000879011762176",
  "text" : "Why intra-discipline mating ultimately lead to inbreeding depression. http:\/\/t.co\/JvcocbwcSa",
  "id" : 506000879011762176,
  "created_at" : "2014-08-31 08:49:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/fY4EJDw7lc",
      "expanded_url" : "http:\/\/instagram.com\/p\/sWwisnBwpl\/",
      "display_url" : "instagram.com\/p\/sWwisnBwpl\/"
    } ]
  },
  "geo" : { },
  "id_str" : "505992343104008192",
  "text" : "\u05E8\u05D1-\u05DC\u05E9\u05D5\u05E0\u05D9\u05D5\u05EA http:\/\/t.co\/fY4EJDw7lc",
  "id" : 505992343104008192,
  "created_at" : "2014-08-31 08:15:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0836197768, 34.7827766459 ]
  },
  "id_str" : "505831275975176193",
  "text" : "\u00ABI guess that\u2019s one way to put it. Though I wouldn\u2019t put it like this. Because I\u2019m genuinely nice and not only on occasion.\u00BB",
  "id" : 505831275975176193,
  "created_at" : "2014-08-30 21:35:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Barton",
      "screen_name" : "bioinformatics",
      "indices" : [ 3, 18 ],
      "id_str" : "14126701",
      "id" : 14126701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/8SoJzKHpKA",
      "expanded_url" : "http:\/\/www.bioinformaticszen.com\/post\/reproducible-assembler-benchmarks\/",
      "display_url" : "bioinformaticszen.com\/post\/reproduci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505801783323947009",
  "text" : "RT @bioinformatics: Continuous, reproducible genome assembler benchmarking \u00B7 Bioinformatics Zen http:\/\/t.co\/8SoJzKHpKA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/8SoJzKHpKA",
        "expanded_url" : "http:\/\/www.bioinformaticszen.com\/post\/reproducible-assembler-benchmarks\/",
        "display_url" : "bioinformaticszen.com\/post\/reproduci\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "489782154730016769",
    "text" : "Continuous, reproducible genome assembler benchmarking \u00B7 Bioinformatics Zen http:\/\/t.co\/8SoJzKHpKA",
    "id" : 489782154730016769,
    "created_at" : "2014-07-17 14:42:20 +0000",
    "user" : {
      "name" : "Michael Barton",
      "screen_name" : "bioinformatics",
      "protected" : false,
      "id_str" : "14126701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/910600171704033280\/3V8Zte9P_normal.jpg",
      "id" : 14126701,
      "verified" : false
    }
  },
  "id" : 505801783323947009,
  "created_at" : "2014-08-30 19:38:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 15, 23 ],
      "id_str" : "114220397",
      "id" : 114220397
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 24, 31 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 32, 41 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505771760114208768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0833530776, 34.7799252991 ]
  },
  "id_str" : "505785266083475456",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 @Lobot @branleb @TnaKng @Senficon Hallo Deutschland, M\u00F6belaufnahme wird diskutiert. ;)",
  "id" : 505785266083475456,
  "in_reply_to_status_id" : 505771760114208768,
  "created_at" : "2014-08-30 18:32:59 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0832522809, 34.7799283916 ]
  },
  "id_str" : "505766825817559040",
  "text" : "\u00ABOh, you\u2019re back from jogging. Why don\u2019t you take me to the shower?\u00BB \u2013 \u00ABThat feels wrong on so many levels\u2026\u00BB \u2013 \u00ABYet, strangely arousing?\u00BB",
  "id" : 505766825817559040,
  "created_at" : "2014-08-30 17:19:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0833733331, 34.7799449073 ]
  },
  "id_str" : "505732848599719936",
  "text" : "\u00ABWe could dress little Fritz half-german, half-jewish.\u00BB \u00ABDirndl for the top &amp; naked belly onwards, so everyone sees he is circumcised?\u00BB",
  "id" : 505732848599719936,
  "created_at" : "2014-08-30 15:04:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505715218832711680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0833540932, 34.7799077983 ]
  },
  "id_str" : "505724445852717057",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot +3 Voyeurismus.",
  "id" : 505724445852717057,
  "in_reply_to_status_id" : 505715218832711680,
  "created_at" : "2014-08-30 14:31:18 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0834875035, 34.7826437808 ]
  },
  "id_str" : "505672952822890497",
  "text" : "\u00ABDo we have to do everything that duolingo asks you to do?\u00BB \u2013 \u00ABYes, especially if they order me in a stern german voice.\u00BB",
  "id" : 505672952822890497,
  "created_at" : "2014-08-30 11:06:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/OimJkRmGor",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1147",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.08362543, 34.7827664163 ]
  },
  "id_str" : "505655102297083904",
  "text" : "melting hearts http:\/\/t.co\/OimJkRmGor",
  "id" : 505655102297083904,
  "created_at" : "2014-08-30 09:55:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505623584241631232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0833724832, 34.7799610239 ]
  },
  "id_str" : "505646152260542464",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Der Safety Dance passt doch total zu dir!",
  "id" : 505646152260542464,
  "in_reply_to_status_id" : 505623584241631232,
  "created_at" : "2014-08-30 09:20:11 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.08362543, 34.7826593359 ]
  },
  "id_str" : "505476119530061824",
  "text" : "\u00ABWe could go to the movies and see \u201CThe German Doctor\u201D. Wait, that doesn\u2019t have subtitles, but \u201CThe Soft German\u201D does!\u00BB",
  "id" : 505476119530061824,
  "created_at" : "2014-08-29 22:04:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.08362543, 34.78278228 ]
  },
  "id_str" : "505446711154991104",
  "text" : "\u00ABTo say it with Darwin: You could as well be talking Hebrew.\u00BB \u2013 \u00ABI am\u2026\u00BB \u2013 \u00ABOh, that explains so much!\u00BB",
  "id" : 505446711154991104,
  "created_at" : "2014-08-29 20:07:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505360554199089153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.083438997, 34.7825962397 ]
  },
  "id_str" : "505361742684504064",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy \u201Cuntil-our-harddrives-are-full sequencing\u201D",
  "id" : 505361742684504064,
  "in_reply_to_status_id" : 505360554199089153,
  "created_at" : "2014-08-29 14:30:03 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0833875938, 34.7798643262 ]
  },
  "id_str" : "505354810477281280",
  "text" : "Das t\u00E4gliche R\u00FCckreiseplan-Update: \u00ABKeine Fluggef\u00E4hrdende Asche bisher und Putin marschiert auch nur ganz langsam in der Ukraine ein.\u00BB",
  "id" : 505354810477281280,
  "created_at" : "2014-08-29 14:02:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.instapaper.com\/\" rel=\"nofollow\"\u003EInstapaper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 52, 65 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/WkY3V5iYzJ",
      "expanded_url" : "http:\/\/www.plosbiology.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pbio.1001935",
      "display_url" : "plosbiology.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505341151398739968",
  "text" : "The Genomic Landscape of Compensatory Evolution \/cc @philippbayer http:\/\/t.co\/WkY3V5iYzJ",
  "id" : 505341151398739968,
  "created_at" : "2014-08-29 13:08:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.08362535, 34.7827554222 ]
  },
  "id_str" : "505332077370548224",
  "text" : "\u00ABI guess I briefly might have felt better than I actually am.\u00BB \u2013 \u00ABOh, that\u2019s a well-known side effect of medicinal sex.\u00BB",
  "id" : 505332077370548224,
  "created_at" : "2014-08-29 12:32:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505282284225064961",
  "text" : "RT @pathogenomenick: \"could lead us to believe that platypus prefers a salinine, alkaline and warm environment but lives everywhere\" http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/p1VYhVao04",
        "expanded_url" : "http:\/\/imgur.com\/Up4mGEE",
        "display_url" : "imgur.com\/Up4mGEE"
      } ]
    },
    "geo" : { },
    "id_str" : "505250798012727296",
    "text" : "\"could lead us to believe that platypus prefers a salinine, alkaline and warm environment but lives everywhere\" http:\/\/t.co\/p1VYhVao04 lol",
    "id" : 505250798012727296,
    "created_at" : "2014-08-29 07:09:12 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 505282284225064961,
  "created_at" : "2014-08-29 09:14:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Ross-Ibarra",
      "screen_name" : "jrossibarra",
      "indices" : [ 3, 15 ],
      "id_str" : "561297215",
      "id" : 561297215
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jrossibarra\/status\/505115467443228673\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/aCtIslXwvo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwKH1ywIIAAoOqL.png",
      "id_str" : "505115466445365248",
      "id" : 505115466445365248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwKH1ywIIAAoOqL.png",
      "sizes" : [ {
        "h" : 524,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 524,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 524,
        "resize" : "fit",
        "w" : 704
      } ],
      "display_url" : "pic.twitter.com\/aCtIslXwvo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505115777205547009",
  "text" : "RT @jrossibarra: Tell me botany doesn\u2019t have a recruitment problem. 800 undergrad bio students say: http:\/\/t.co\/aCtIslXwvo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jrossibarra\/status\/505115467443228673\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/aCtIslXwvo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwKH1ywIIAAoOqL.png",
        "id_str" : "505115466445365248",
        "id" : 505115466445365248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwKH1ywIIAAoOqL.png",
        "sizes" : [ {
          "h" : 524,
          "resize" : "fit",
          "w" : 704
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 506,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 524,
          "resize" : "fit",
          "w" : 704
        }, {
          "h" : 524,
          "resize" : "fit",
          "w" : 704
        } ],
        "display_url" : "pic.twitter.com\/aCtIslXwvo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505115467443228673",
    "text" : "Tell me botany doesn\u2019t have a recruitment problem. 800 undergrad bio students say: http:\/\/t.co\/aCtIslXwvo",
    "id" : 505115467443228673,
    "created_at" : "2014-08-28 22:11:26 +0000",
    "user" : {
      "name" : "Jeffrey Ross-Ibarra",
      "screen_name" : "jrossibarra",
      "protected" : false,
      "id_str" : "561297215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656691317519466496\/tJ966bzU_normal.png",
      "id" : 561297215,
      "verified" : false
    }
  },
  "id" : 505115777205547009,
  "created_at" : "2014-08-28 22:12:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0836020795, 34.7827590082 ]
  },
  "id_str" : "505075038916464641",
  "text" : "\u00ABAre you less attracted to me now that there\u2019s a ceasefire?\u00BB \u2013 \u00ABNope, so we won\u2019t have to start World War 3 on your return visit.\u00BB",
  "id" : 505075038916464641,
  "created_at" : "2014-08-28 19:30:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0833595953, 34.7798744239 ]
  },
  "id_str" : "504700421932601347",
  "text" : "\u00ABDein deutscher Wortschatz wird am Ende der Woche sehr eklektisch sein.\u00BB \u2013 \u00ABLinker Aktivismus, Bahnreisen, Sex. Works out.\u00BB",
  "id" : 504700421932601347,
  "created_at" : "2014-08-27 18:42:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/GpY8sexVjp",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosbiology\/NewArticles\/~3\/mPyrPNGEEFU\/info%3Adoi%2F10.1371%2Fjournal.pbio.1001934",
      "display_url" : "feedproxy.google.com\/~r\/plosbiology\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.083461, 34.779889 ]
  },
  "id_str" : "504345967341359104",
  "text" : "How Could Language Have Evolved? http:\/\/t.co\/GpY8sexVjp",
  "id" : 504345967341359104,
  "created_at" : "2014-08-26 19:13:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/zXudgAeHNO",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/43",
      "display_url" : "existentialcomics.com\/comic\/43"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.083453, 34.779891 ]
  },
  "id_str" : "504342688976867328",
  "text" : "\u00ABWig-based microtransactions are the future of gaming, Gabe.\u00BB http:\/\/t.co\/zXudgAeHNO",
  "id" : 504342688976867328,
  "created_at" : "2014-08-26 19:00:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.0834599035, 34.7798559402 ]
  },
  "id_str" : "504340809509265408",
  "text" : "Learned: the Dead Sea is not only as warm as the hot springs of Iceland, bathing in it also gives you the same sulphuric smell.",
  "id" : 504340809509265408,
  "created_at" : "2014-08-26 18:53:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503156944191127552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0234014899, 8.5948557364 ]
  },
  "id_str" : "503157265604833280",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot Das kommt dann irgendwann mit dem Kind. ;-)",
  "id" : 503157265604833280,
  "in_reply_to_status_id" : 503156944191127552,
  "created_at" : "2014-08-23 12:30:14 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503155867471339520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0234014899, 8.5948557364 ]
  },
  "id_str" : "503156179061993472",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot Ich f\u00FCrchte dann halten die B\u00FCcher bei uns am Bett nicht lang.",
  "id" : 503156179061993472,
  "in_reply_to_status_id" : 503155867471339520,
  "created_at" : "2014-08-23 12:25:55 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503153236745154560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0237727444, 8.5944496105 ]
  },
  "id_str" : "503153744490807296",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich Daf\u00FCr bekommen wir doch jemanden der uns im Haushalt hilft! alsob.jpg",
  "id" : 503153744490807296,
  "in_reply_to_status_id" : 503153236745154560,
  "created_at" : "2014-08-23 12:16:15 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Otto",
      "screen_name" : "PhilippOtto",
      "indices" : [ 101, 113 ],
      "id_str" : "40187679",
      "id" : 40187679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/iP0FKCaqfS",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plosgenetics\/NewArticles\/~3\/1ipvX0h9NsY\/info%3Adoi%2F10.1371%2Fjournal.pgen.1004561",
      "display_url" : "feeds.plos.org\/~r\/plosgenetic\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.022114, 8.594479 ]
  },
  "id_str" : "503146924607037440",
  "text" : "A Model-Based Approach for Identifying Signatures of Ancient Balancing Selection in Genetic Data \/cc @PhilippOtto  http:\/\/t.co\/iP0FKCaqfS",
  "id" : 503146924607037440,
  "created_at" : "2014-08-23 11:49:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/kVyg5KGfjZ",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1737",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "503146619681120256",
  "text" : "Why Academics Really Use Twitter http:\/\/t.co\/kVyg5KGfjZ",
  "id" : 503146619681120256,
  "created_at" : "2014-08-23 11:47:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 30, 36 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/v5Uufihkvr",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/ippuTFg7U58\/headboard-made-from-books.html",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.022747, 8.594468 ]
  },
  "id_str" : "503146236376252416",
  "text" : "Headboard made from\u00A0books \/cc @Lobot  http:\/\/t.co\/v5Uufihkvr",
  "id" : 503146236376252416,
  "created_at" : "2014-08-23 11:46:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503144753425571840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0266068824, 8.5944224478 ]
  },
  "id_str" : "503145031520505856",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot V\u00F6lkerverst\u00E4ndigung. Und Bewerbungen nehme ich auf unserer Casting-Couch entgegen.",
  "id" : 503145031520505856,
  "in_reply_to_status_id" : 503144753425571840,
  "created_at" : "2014-08-23 11:41:38 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503144111411838976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0232740262, 8.5948583659 ]
  },
  "id_str" : "503144306467950592",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot hat dir die Autokorrektur den Pornologen zerschossen? :p",
  "id" : 503144306467950592,
  "in_reply_to_status_id" : 503144111411838976,
  "created_at" : "2014-08-23 11:38:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/t5makSkoWp",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/NerdcoreRSS2\/~3\/BsMosf656Gk\/",
      "display_url" : "feedproxy.google.com\/~r\/NerdcoreRSS\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.022338, 8.594553 ]
  },
  "id_str" : "503143820297793538",
  "text" : "Poop-Invader on the Run http:\/\/t.co\/t5makSkoWp",
  "id" : 503143820297793538,
  "created_at" : "2014-08-23 11:36:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503143405309145088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.023305541, 8.5948686483 ]
  },
  "id_str" : "503143569063149568",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot d.h. neben meiner Mechanikerin sollten wir noch einen Orthop\u00E4den mitnehmen? ;)",
  "id" : 503143569063149568,
  "in_reply_to_status_id" : 503143405309145088,
  "created_at" : "2014-08-23 11:35:49 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503142200419823616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0228555046, 8.5946964298 ]
  },
  "id_str" : "503142637877354496",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Du willst sie nicht bis Ulan Bator anbehalten?",
  "id" : 503142637877354496,
  "in_reply_to_status_id" : 503142200419823616,
  "created_at" : "2014-08-23 11:32:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503138139062685696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0245206854, 8.5944364078 ]
  },
  "id_str" : "503138268536655873",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot aber ich liebe angeblich die Gefahr? ;)",
  "id" : 503138268536655873,
  "in_reply_to_status_id" : 503138139062685696,
  "created_at" : "2014-08-23 11:14:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.14348539, 8.58180568 ]
  },
  "id_str" : "503134646750949376",
  "text" : "\u00ABGleich sehen wir zwei Kacknoobs nackt durch die Wohnung laufen. Und einer davon f\u00E4hrt dann in Hausschl\u00E4ppchen zum Flughafen.\u00BB",
  "id" : 503134646750949376,
  "created_at" : "2014-08-23 11:00:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/tdrd03fRAK",
      "expanded_url" : "http:\/\/instagram.com\/p\/sA74HPhwsW\/",
      "display_url" : "instagram.com\/p\/sA74HPhwsW\/"
    } ]
  },
  "geo" : { },
  "id_str" : "502921044936499200",
  "text" : "Just a song before I go http:\/\/t.co\/tdrd03fRAK",
  "id" : 502921044936499200,
  "created_at" : "2014-08-22 20:51:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502588269419593728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11073369, 8.75194632 ]
  },
  "id_str" : "502596432277549056",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC now you have a feeling of how my week was. ;)",
  "id" : 502596432277549056,
  "in_reply_to_status_id" : 502588269419593728,
  "created_at" : "2014-08-21 23:21:41 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502549902422200320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1116309264, 8.7550565955 ]
  },
  "id_str" : "502553493979537408",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC Tel Aviv I'm coming! :p",
  "id" : 502553493979537408,
  "in_reply_to_status_id" : 502549902422200320,
  "created_at" : "2014-08-21 20:31:04 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502548716675690496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1125999562, 8.7494015091 ]
  },
  "id_str" : "502549350338535424",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC this week has a knack for making my life suck in the most peculiar ways. So glad to leave for a week of peace &amp; quiet on Saturday.",
  "id" : 502549350338535424,
  "in_reply_to_status_id" : 502548716675690496,
  "created_at" : "2014-08-21 20:14:36 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502546260147310592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140871691, 8.7533994299 ]
  },
  "id_str" : "502548185852944384",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC went for a regular vacuum instead. Still: hours of fun.",
  "id" : 502548185852944384,
  "in_reply_to_status_id" : 502546260147310592,
  "created_at" : "2014-08-21 20:09:59 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502542716577021953",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1132110863, 8.7512720268 ]
  },
  "id_str" : "502548082245242883",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC train lines stay the same. Just board them in the other direction ;)",
  "id" : 502548082245242883,
  "in_reply_to_status_id" : 502542716577021953,
  "created_at" : "2014-08-21 20:09:34 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502523378826498049",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11073369, 8.75194632 ]
  },
  "id_str" : "502529037999538176",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC yes, by making them pay in hard currency for my valuable time.",
  "id" : 502529037999538176,
  "in_reply_to_status_id" : 502523378826498049,
  "created_at" : "2014-08-21 18:53:53 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502480163859603456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106659942, 8.7586605945 ]
  },
  "id_str" : "502517310981406720",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC moving in my instance: where people order you to do things that take 10x longer than they estimated\u2026",
  "id" : 502517310981406720,
  "in_reply_to_status_id" : 502480163859603456,
  "created_at" : "2014-08-21 18:07:17 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139583393, 8.7527328171 ]
  },
  "id_str" : "502511315211284480",
  "text" : "Experiment today: how long does a Roomba need to get rid of the styrofoam content of a bean bag\u2026",
  "id" : 502511315211284480,
  "created_at" : "2014-08-21 17:43:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502480163859603456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106659907, 8.7495945086 ]
  },
  "id_str" : "502489771084890112",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC and made it, tomorrow I will hand over the keys and then it\u2019s done.",
  "id" : 502489771084890112,
  "in_reply_to_status_id" : 502480163859603456,
  "created_at" : "2014-08-21 16:17:51 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 16, 22 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502478926787391489",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106660008, 8.7495944876 ]
  },
  "id_str" : "502489623608963072",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC nein, @lobot und ich hatten genauso dirty minds als wir es im Kellerdungeon fanden.",
  "id" : 502489623608963072,
  "in_reply_to_status_id" : 502478926787391489,
  "created_at" : "2014-08-21 16:17:16 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D\u24D0niel Mietchen",
      "screen_name" : "EvoMRI",
      "indices" : [ 3, 10 ],
      "id_str" : "15132914",
      "id" : 15132914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/FD6QI3u06C",
      "expanded_url" : "http:\/\/www.mbl.is\/frettir\/innlent\/2014\/08\/19\/how_to_pronounce_bardarbunga\/",
      "display_url" : "mbl.is\/frettir\/innlen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502371463459274752",
  "text" : "RT @EvoMRI: How to pronounce \"B\u00E1r\u00F0arbunga\" http:\/\/t.co\/FD6QI3u06C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/FD6QI3u06C",
        "expanded_url" : "http:\/\/www.mbl.is\/frettir\/innlent\/2014\/08\/19\/how_to_pronounce_bardarbunga\/",
        "display_url" : "mbl.is\/frettir\/innlen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "502262851772620800",
    "text" : "How to pronounce \"B\u00E1r\u00F0arbunga\" http:\/\/t.co\/FD6QI3u06C",
    "id" : 502262851772620800,
    "created_at" : "2014-08-21 01:16:10 +0000",
    "user" : {
      "name" : "D\u24D0niel Mietchen",
      "screen_name" : "EvoMRI",
      "protected" : false,
      "id_str" : "15132914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1022748634\/belemnite_2009-05-08_1424-green_normal.png",
      "id" : 15132914,
      "verified" : false
    }
  },
  "id" : 502371463459274752,
  "created_at" : "2014-08-21 08:27:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 0, 11 ],
      "id_str" : "3782931",
      "id" : 3782931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723097218, 8.6275642758 ]
  },
  "id_str" : "502359348233121792",
  "in_reply_to_user_id" : 3782931,
  "text" : "@spreeblick alles gute!",
  "id" : 502359348233121792,
  "created_at" : "2014-08-21 07:39:36 +0000",
  "in_reply_to_screen_name" : "spreeblick",
  "in_reply_to_user_id_str" : "3782931",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502265316122959872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.110731198, 8.7521934818 ]
  },
  "id_str" : "502339027765592064",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch that explains the 'can't register' emails at info@ can you reply?",
  "id" : 502339027765592064,
  "in_reply_to_status_id" : 502265316122959872,
  "created_at" : "2014-08-21 06:18:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/502204628730404865\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/vZt4AZCrVq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvgwcugIIAAE-oO.jpg",
      "id_str" : "502204628529061888",
      "id" : 502204628529061888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvgwcugIIAAE-oO.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1136
      } ],
      "display_url" : "pic.twitter.com\/vZt4AZCrVq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.112477, 8.74714 ]
  },
  "id_str" : "502204628730404865",
  "text" : "\u00ABDu musst nur schnell noch durchfegen und den Sperrm\u00FCll rausstellen.\u00BB aka \u00AB2 Personen arbeiten 5 Stunden lang\u00BB\u2026 http:\/\/t.co\/vZt4AZCrVq",
  "id" : 502204628730404865,
  "created_at" : "2014-08-20 21:24:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/502183629800636416\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/qXXYMfnoQq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvgdVlcIYAE_VGo.jpg",
      "id_str" : "502183615116369921",
      "id" : 502183615116369921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvgdVlcIYAE_VGo.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/qXXYMfnoQq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096453966, 8.2829290811 ]
  },
  "id_str" : "502183629800636416",
  "text" : "Ratespiel: Welche deutsche Europaparlamentarierin der Piratenpartei liest dies in ihrer Freizeit? http:\/\/t.co\/qXXYMfnoQq",
  "id" : 502183629800636416,
  "created_at" : "2014-08-20 20:01:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096474096, 8.2829695182 ]
  },
  "id_str" : "502171911057854465",
  "text" : "Bioinformatics: where relatives call your for IT support and help in interpreting their BRCA testing results at the same time.",
  "id" : 502171911057854465,
  "created_at" : "2014-08-20 19:14:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095768192, 8.2823815622 ]
  },
  "id_str" : "502142187761840129",
  "text" : "gone for the 220 V electrocution therapy against my cold\u2026",
  "id" : 502142187761840129,
  "created_at" : "2014-08-20 17:16:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502128855591964673",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095747876, 8.2828951361 ]
  },
  "id_str" : "502134122387886081",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng Schlaraffenland f\u00FCr die Leute die sich um nichts in der Wohnung k\u00FCmmern, eh?",
  "id" : 502134122387886081,
  "in_reply_to_status_id" : 502128855591964673,
  "created_at" : "2014-08-20 16:44:38 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722699379, 8.6276045038 ]
  },
  "id_str" : "502072195032809472",
  "text" : "Next: drafting a paper. \\o\/",
  "id" : 502072195032809472,
  "created_at" : "2014-08-20 12:38:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722883, 8.6275683602 ]
  },
  "id_str" : "502041898631303168",
  "text" : "The network is broken. Too bad we only have VoIP phones, so we can\u2019t call tech support.",
  "id" : 502041898631303168,
  "created_at" : "2014-08-20 10:38:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17415129, 8.61807578 ]
  },
  "id_str" : "502040059953307648",
  "text" : "\u00ABWir haben im B\u00FCro geschlafen um deinen Talk nicht zu verpassen.\u00BB \u2013 \u00ABIhr habt euch also gestern Abend volllaufen lassen.\u00BB \u2013 \u00ABVielleicht\u2026\u00BB",
  "id" : 502040059953307648,
  "created_at" : "2014-08-20 10:30:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501995719876960257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11073369, 8.75194632 ]
  },
  "id_str" : "501996206634319872",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 @Lobot want to learn more? Contact the Cyborg e.V.!",
  "id" : 501996206634319872,
  "in_reply_to_status_id" : 501995719876960257,
  "created_at" : "2014-08-20 07:36:36 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501994085193093120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11073369, 8.75194632 ]
  },
  "id_str" : "501995630664114176",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 @Lobot Was sollen dann die Menschen vom Bau gegen\u00FCber erst sagen!",
  "id" : 501995630664114176,
  "in_reply_to_status_id" : 501994085193093120,
  "created_at" : "2014-08-20 07:34:19 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501993347092074497",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11073369, 8.75194632 ]
  },
  "id_str" : "501993901876858880",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u00ABWie der 12 Finger-Darm wirklich zu seinem Namen kam.\u00BB",
  "id" : 501993901876858880,
  "in_reply_to_status_id" : 501993347092074497,
  "created_at" : "2014-08-20 07:27:27 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/5DIbh35hfS",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2014\/08\/is-a-different-icelandic-volcano-about-to-act-up\/#p3",
      "display_url" : "arstechnica.com\/science\/2014\/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114125, 8.750045 ]
  },
  "id_str" : "501799565960699904",
  "text" : "On what might happen when B\u00E1r\u00F0arbunga erupts  http:\/\/t.co\/5DIbh35hfS",
  "id" : 501799565960699904,
  "created_at" : "2014-08-19 18:35:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501698686666424320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172316804, 8.6275716825 ]
  },
  "id_str" : "501699215790460929",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC so words that have no need to be translated instead of words that can\u2019t be translated. ;)",
  "id" : 501699215790460929,
  "in_reply_to_status_id" : 501698686666424320,
  "created_at" : "2014-08-19 11:56:28 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501696625400893440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1820107158, 8.6197984358 ]
  },
  "id_str" : "501697226503376896",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC still, Kopfkino is one of the best words to teach people who are just starting with German (or that\u2019s just me).",
  "id" : 501697226503376896,
  "in_reply_to_status_id" : 501696625400893440,
  "created_at" : "2014-08-19 11:48:34 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 3, 9 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Slate\/status\/501375527232765953\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/AxKyR2eqPO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvU-YpzIUAAoD9n.png",
      "id_str" : "501375526779768832",
      "id" : 501375526779768832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvU-YpzIUAAoD9n.png",
      "sizes" : [ {
        "h" : 828,
        "resize" : "fit",
        "w" : 1436
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 692,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 828,
        "resize" : "fit",
        "w" : 1436
      } ],
      "display_url" : "pic.twitter.com\/AxKyR2eqPO"
    } ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/eAmH6rOdSr",
      "expanded_url" : "http:\/\/slate.me\/1oJhT4z",
      "display_url" : "slate.me\/1oJhT4z"
    } ]
  },
  "geo" : { },
  "id_str" : "501674541182382080",
  "text" : "RT @Slate: John Oliver's take on #Ferguson and the police is spot-on--WATCH: http:\/\/t.co\/eAmH6rOdSr http:\/\/t.co\/AxKyR2eqPO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Slate\/status\/501375527232765953\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/AxKyR2eqPO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvU-YpzIUAAoD9n.png",
        "id_str" : "501375526779768832",
        "id" : 501375526779768832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvU-YpzIUAAoD9n.png",
        "sizes" : [ {
          "h" : 828,
          "resize" : "fit",
          "w" : 1436
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 692,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 392,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 828,
          "resize" : "fit",
          "w" : 1436
        } ],
        "display_url" : "pic.twitter.com\/AxKyR2eqPO"
      } ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 22, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/eAmH6rOdSr",
        "expanded_url" : "http:\/\/slate.me\/1oJhT4z",
        "display_url" : "slate.me\/1oJhT4z"
      } ]
    },
    "geo" : { },
    "id_str" : "501375527232765953",
    "text" : "John Oliver's take on #Ferguson and the police is spot-on--WATCH: http:\/\/t.co\/eAmH6rOdSr http:\/\/t.co\/AxKyR2eqPO",
    "id" : 501375527232765953,
    "created_at" : "2014-08-18 14:30:15 +0000",
    "user" : {
      "name" : "Slate",
      "screen_name" : "Slate",
      "protected" : false,
      "id_str" : "15164565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785838392336678913\/UP9SKq0X_normal.jpg",
      "id" : 15164565,
      "verified" : true
    }
  },
  "id" : 501674541182382080,
  "created_at" : "2014-08-19 10:18:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/ZRDYUUPKvh",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/rOOAg70f30s\/info%3Adoi%2F10.1371%2Fjournal.pone.0103510",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.173648, 8.620535 ]
  },
  "id_str" : "501660152882552832",
  "text" : "Papers, please: Passport Officers\u2019 Errors in Face Matching http:\/\/t.co\/ZRDYUUPKvh",
  "id" : 501660152882552832,
  "created_at" : "2014-08-19 09:21:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501476517416042497",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1147101682, 8.7538019519 ]
  },
  "id_str" : "501482819819159552",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach ich liebe euch!",
  "id" : 501482819819159552,
  "in_reply_to_status_id" : 501476517416042497,
  "created_at" : "2014-08-18 21:36:36 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1141425396, 8.7500499762 ]
  },
  "id_str" : "501482745542242304",
  "text" : "How nice moving must be if you don\u2019t have to take care of anything\u2026",
  "id" : 501482745542242304,
  "created_at" : "2014-08-18 21:36:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain \u2744\uFE0F\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDF93",
      "screen_name" : "DevilleSy",
      "indices" : [ 3, 13 ],
      "id_str" : "331228486",
      "id" : 331228486
    }, {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 16, 30 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/c6pJxTWfsj",
      "expanded_url" : "http:\/\/phylogenomics.blogspot.com\/2014\/08\/aaas-blocking-access-to-scientific.html?spref=tw",
      "display_url" : "phylogenomics.blogspot.com\/2014\/08\/aaas-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501393643039911936",
  "text" : "RT @DevilleSy: .@phylogenomics tries to download one of his old paper. Usual craziness ensues. http:\/\/t.co\/c6pJxTWfsj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
        "screen_name" : "phylogenomics",
        "indices" : [ 1, 15 ],
        "id_str" : "15154811",
        "id" : 15154811
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/c6pJxTWfsj",
        "expanded_url" : "http:\/\/phylogenomics.blogspot.com\/2014\/08\/aaas-blocking-access-to-scientific.html?spref=tw",
        "display_url" : "phylogenomics.blogspot.com\/2014\/08\/aaas-b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "501391986063335424",
    "text" : ".@phylogenomics tries to download one of his old paper. Usual craziness ensues. http:\/\/t.co\/c6pJxTWfsj",
    "id" : 501391986063335424,
    "created_at" : "2014-08-18 15:35:39 +0000",
    "user" : {
      "name" : "Sylvain \u2744\uFE0F\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDF93",
      "screen_name" : "DevilleSy",
      "protected" : false,
      "id_str" : "331228486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887046588954226688\/p3UlM_8C_normal.jpg",
      "id" : 331228486,
      "verified" : false
    }
  },
  "id" : 501393643039911936,
  "created_at" : "2014-08-18 15:42:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/swl6Gm9tJJ",
      "expanded_url" : "http:\/\/qwantz.com\/index.php?comic=2672",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723082406, 8.6275775168 ]
  },
  "id_str" : "501387473671708672",
  "text" : "Why nobody wants to date social media experts http:\/\/t.co\/swl6Gm9tJJ",
  "id" : 501387473671708672,
  "created_at" : "2014-08-18 15:17:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722669493, 8.6275607846 ]
  },
  "id_str" : "501361604651671553",
  "text" : "\u00ABIch komme nur f\u00FCr ein kurzes Briefing.\u00BB \u2013 \u00ABBash, Beziehung oder MySQL?\u00BB",
  "id" : 501361604651671553,
  "created_at" : "2014-08-18 13:34:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722991189, 8.6275757037 ]
  },
  "id_str" : "501291498768695298",
  "text" : "Ich will nicht sagen das meine Workstation unbenutzbar ist. Aber ich drucke PDFs lieber weil das Scrollen so langsam ist\u2026",
  "id" : 501291498768695298,
  "created_at" : "2014-08-18 08:56:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 3, 17 ],
      "id_str" : "16066596",
      "id" : 16066596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501290550046490624",
  "text" : "RT @onetruecathal: BTW, if any of ye have a job in Cork for a Synbio \/ Programming (either or both) nerd, I'm all ears and I'll bring cake.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501089222892457984",
    "text" : "BTW, if any of ye have a job in Cork for a Synbio \/ Programming (either or both) nerd, I'm all ears and I'll bring cake.",
    "id" : 501089222892457984,
    "created_at" : "2014-08-17 19:32:35 +0000",
    "user" : {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "protected" : false,
      "id_str" : "16066596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/673955584920563713\/KsGsM0A5_normal.jpg",
      "id" : 16066596,
      "verified" : false
    }
  },
  "id" : 501290550046490624,
  "created_at" : "2014-08-18 08:52:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/ARCwD36rQ4",
      "expanded_url" : "http:\/\/instagram.com\/p\/r0LX70Bwuz\/",
      "display_url" : "instagram.com\/p\/r0LX70Bwuz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "501125576431005698",
  "text" : "Moved http:\/\/t.co\/ARCwD36rQ4",
  "id" : 501125576431005698,
  "created_at" : "2014-08-17 21:57:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412534, 8.75004462 ]
  },
  "id_str" : "501033602944368641",
  "text" : "\u00ABWieso steht auf der Umzugskiste \u2018Entartete Hardware\u2019?\u00BB \u2013 \u00ABEntertainment-Hardware!\u00BB",
  "id" : 501033602944368641,
  "created_at" : "2014-08-17 15:51:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1141136978, 8.7535367254 ]
  },
  "id_str" : "500960387219873792",
  "text" : "\u00ABDiese Tasse wird mich immer an den Flug mit Icelandair erinnern. Als ich dachte ich muss sterben. In deinem\nBart.\u00BB",
  "id" : 500960387219873792,
  "created_at" : "2014-08-17 11:00:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "500753549035577344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.112747294, 8.7504898778 ]
  },
  "id_str" : "500755166032044033",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC that's the usual transition to meaning.",
  "id" : 500755166032044033,
  "in_reply_to_status_id" : 500753549035577344,
  "created_at" : "2014-08-16 21:25:09 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "500751088346468352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1125408288, 8.7496924718 ]
  },
  "id_str" : "500752049253126144",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC tell me about it.",
  "id" : 500752049253126144,
  "in_reply_to_status_id" : 500751088346468352,
  "created_at" : "2014-08-16 21:12:46 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/4ulHGVyPmJ",
      "expanded_url" : "http:\/\/i.imgur.com\/0JxOliz.jpg",
      "display_url" : "i.imgur.com\/0JxOliz.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723119394, 8.6275225054 ]
  },
  "id_str" : "500324727286923264",
  "text" : "same sex marriage http:\/\/t.co\/4ulHGVyPmJ",
  "id" : 500324727286923264,
  "created_at" : "2014-08-15 16:54:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "500252299038838784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172301827, 8.6275864025 ]
  },
  "id_str" : "500253949052850176",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot did you already create the reminder?",
  "id" : 500253949052850176,
  "in_reply_to_status_id" : 500252299038838784,
  "created_at" : "2014-08-15 12:13:30 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matus Sotak",
      "screen_name" : "biomatushiq",
      "indices" : [ 0, 12 ],
      "id_str" : "122310304",
      "id" : 122310304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "500250864947580928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1837038452, 8.62303234 ]
  },
  "id_str" : "500251170120953858",
  "in_reply_to_user_id" : 122310304,
  "text" : "@biomatushiq gratulations!",
  "id" : 500251170120953858,
  "in_reply_to_status_id" : 500250864947580928,
  "created_at" : "2014-08-15 12:02:27 +0000",
  "in_reply_to_screen_name" : "biomatushiq",
  "in_reply_to_user_id_str" : "122310304",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722313543, 8.6274288494 ]
  },
  "id_str" : "500248387560964096",
  "text" : "\u00ABWenn du dich in deren Luftraum abschiessen l\u00E4sst marschiere ich da ein und sage \u2018Ey, den Typen wollte ich noch heiraten\u2019!\u00BB",
  "id" : 500248387560964096,
  "created_at" : "2014-08-15 11:51:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 54, 60 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/0JJsMZWIz3",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/RAYCGwuS7lo\/vesper-pendant-thats-also-a.html",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172318, 8.627558 ]
  },
  "id_str" : "500224470146359296",
  "text" : "Vesper: pendant that's also a USB-charged\u00A0sex-toy \/cc\u00A0@Lobot  http:\/\/t.co\/0JJsMZWIz3",
  "id" : 500224470146359296,
  "created_at" : "2014-08-15 10:16:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/WxEEDAumUs",
      "expanded_url" : "http:\/\/instagram.com\/p\/rtvbjtBwnG\/",
      "display_url" : "instagram.com\/p\/rtvbjtBwnG\/"
    } ]
  },
  "geo" : { },
  "id_str" : "500219661607518209",
  "text" : "\u00ABDu musst mich besch\u00FCtzen!\u00BB \u2014 \u00ABVor dem Wetter?!\u00BB \u2014 \u00ABVor allem!\u00BB http:\/\/t.co\/WxEEDAumUs",
  "id" : 500219661607518209,
  "created_at" : "2014-08-15 09:57:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16534141, 8.62028641 ]
  },
  "id_str" : "500206180762152961",
  "text" : "\u00ABDoing the bioinformatics triathlon? Drowning in data, CPU cycling, running jobs.\u00BB",
  "id" : 500206180762152961,
  "created_at" : "2014-08-15 09:03:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1171030834, 8.6810167788 ]
  },
  "id_str" : "499958029019013123",
  "text" : "\u00ABAch du, du bist ja auch kein Kerl, sondern mehr so geschlechtslos.\u00BB \u2014 \u00ABBestes Kompliment von dir ever.\u00BB \u2014 \u00ABUnd genauso war es gemeint.\u00BB",
  "id" : 499958029019013123,
  "created_at" : "2014-08-14 16:37:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172294036, 8.6275889145 ]
  },
  "id_str" : "499943928679104513",
  "text" : "\u00ABWas macht der Hund da?\u00BB \u2014 \u00ABEin Fellvieh-Selfie!\u00BB",
  "id" : 499943928679104513,
  "created_at" : "2014-08-14 15:41:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ChaosTom",
      "screen_name" : "chaostom",
      "indices" : [ 0, 9 ],
      "id_str" : "71142746",
      "id" : 71142746
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499875398231269376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723097805, 8.6275243605 ]
  },
  "id_str" : "499876404411252737",
  "in_reply_to_user_id" : 71142746,
  "text" : "@chaostom @Senficon nope, we went with Sixt and Dollar as they were cheaper at the time.",
  "id" : 499876404411252737,
  "in_reply_to_status_id" : 499875398231269376,
  "created_at" : "2014-08-14 11:13:16 +0000",
  "in_reply_to_screen_name" : "chaostom",
  "in_reply_to_user_id_str" : "71142746",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/Uo9UkSb0Hg",
      "expanded_url" : "http:\/\/sadcars.com",
      "display_url" : "sadcars.com"
    } ]
  },
  "in_reply_to_status_id_str" : "499864488024096769",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723032353, 8.6275366374 ]
  },
  "id_str" : "499865600207093760",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon when in Iceland you can book with http:\/\/t.co\/Uo9UkSb0Hg :3",
  "id" : 499865600207093760,
  "in_reply_to_status_id" : 499864488024096769,
  "created_at" : "2014-08-14 10:30:20 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723032353, 8.6275366374 ]
  },
  "id_str" : "499865428660092928",
  "text" : "\u00ABHast du etwa keine Schuhe?\u00BB \u2013 \u00ABIch weiss momentan nicht mal in welchem PLZ-Bereich sich meine Schuhe aufhalten k\u00F6nnten.\u00BB",
  "id" : 499865428660092928,
  "created_at" : "2014-08-14 10:29:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/yruziTWJcR",
      "expanded_url" : "https:\/\/youtube.com\/watch?v=YWFYYvZEC1s",
      "display_url" : "youtube.com\/watch?v=YWFYYv\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1742768168, 8.6182211516 ]
  },
  "id_str" : "499858213958066176",
  "text" : "we\u2019re not lost, we just don\u2019t know where to go https:\/\/t.co\/yruziTWJcR",
  "id" : 499858213958066176,
  "created_at" : "2014-08-14 10:00:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/uoMe5MfGgE",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1736",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "499827193300926464",
  "text" : "Typical Academic Behavior http:\/\/t.co\/uoMe5MfGgE",
  "id" : 499827193300926464,
  "created_at" : "2014-08-14 07:57:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1957587944, 8.5857070359 ]
  },
  "id_str" : "499582738950025218",
  "text" : "\u00ABM\u00FCde?\u00BB \u2013 \u00ABNein.\u00BB \u2013 \u00ABGenervt?\u00BB \u2013 \u00ABNein.\u00BB \u2013 \u00ABUnd jetzt? Und jetzt? Und jetzt? Und jetzt?\u00BB",
  "id" : 499582738950025218,
  "created_at" : "2014-08-13 15:46:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Harford",
      "screen_name" : "TimHarford",
      "indices" : [ 3, 14 ],
      "id_str" : "32493647",
      "id" : 32493647
    }, {
      "name" : "Fran Monks",
      "screen_name" : "FranMonks",
      "indices" : [ 86, 96 ],
      "id_str" : "147538059",
      "id" : 147538059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/fnBMmPfrXA",
      "expanded_url" : "http:\/\/dlvr.it\/6bl11m",
      "display_url" : "dlvr.it\/6bl11m"
    } ]
  },
  "geo" : { },
  "id_str" : "499545981223182336",
  "text" : "RT @TimHarford: How to have it all: Bring your kids to work. (Every. Single. Day.) cc @franmonks http:\/\/t.co\/fnBMmPfrXA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fran Monks",
        "screen_name" : "FranMonks",
        "indices" : [ 70, 80 ],
        "id_str" : "147538059",
        "id" : 147538059
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/fnBMmPfrXA",
        "expanded_url" : "http:\/\/dlvr.it\/6bl11m",
        "display_url" : "dlvr.it\/6bl11m"
      } ]
    },
    "geo" : { },
    "id_str" : "499491238936977409",
    "text" : "How to have it all: Bring your kids to work. (Every. Single. Day.) cc @franmonks http:\/\/t.co\/fnBMmPfrXA",
    "id" : 499491238936977409,
    "created_at" : "2014-08-13 09:42:46 +0000",
    "user" : {
      "name" : "Tim Harford",
      "screen_name" : "TimHarford",
      "protected" : false,
      "id_str" : "32493647",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1338890256\/Harford_Cropped_normal.JPG",
      "id" : 32493647,
      "verified" : true
    }
  },
  "id" : 499545981223182336,
  "created_at" : "2014-08-13 13:20:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722820365, 8.6275741128 ]
  },
  "id_str" : "499507234217684992",
  "text" : "\u00ABDoing this paper really is a never ending story\u2026\u00BB \u2013 \u00ABGiven your name I\u2019m not too surprised by that!\u00BB",
  "id" : 499507234217684992,
  "created_at" : "2014-08-13 10:46:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/Rk2t7vLJvE",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/T0EghHZ7clg\/biology-student-in-colombia-co.html",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172353, 8.627517 ]
  },
  "id_str" : "499484639023890432",
  "text" : "Biology student in Colombia faces jail for reposting scholarly\u00A0article http:\/\/t.co\/Rk2t7vLJvE",
  "id" : 499484639023890432,
  "created_at" : "2014-08-13 09:16:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "indices" : [ 3, 12 ],
      "id_str" : "1205345400",
      "id" : 1205345400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/INEVXZzcWx",
      "expanded_url" : "http:\/\/judgestarling.tumblr.com\/post\/94564627621\/facts-and-interpretation-in-the-case-of-a-very-small",
      "display_url" : "judgestarling.tumblr.com\/post\/945646276\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "499465928003051520",
  "text" : "RT @DanGraur: How NOT to interpret a genome sequence: The case of the midge genome. http:\/\/t.co\/INEVXZzcWx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/INEVXZzcWx",
        "expanded_url" : "http:\/\/judgestarling.tumblr.com\/post\/94564627621\/facts-and-interpretation-in-the-case-of-a-very-small",
        "display_url" : "judgestarling.tumblr.com\/post\/945646276\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "499377650407051264",
    "text" : "How NOT to interpret a genome sequence: The case of the midge genome. http:\/\/t.co\/INEVXZzcWx",
    "id" : 499377650407051264,
    "created_at" : "2014-08-13 02:11:24 +0000",
    "user" : {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "protected" : false,
      "id_str" : "1205345400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822591216776835072\/IO7mOPZQ_normal.jpg",
      "id" : 1205345400,
      "verified" : false
    }
  },
  "id" : 499465928003051520,
  "created_at" : "2014-08-13 08:02:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1113825704, 8.7413251083 ]
  },
  "id_str" : "499448433653342209",
  "text" : "Verleser: \u00ABAmbulantes Rechenzentrum\u00BB",
  "id" : 499448433653342209,
  "created_at" : "2014-08-13 06:52:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @sckottie",
      "screen_name" : "recology_",
      "indices" : [ 0, 10 ],
      "id_str" : "4465848374",
      "id" : 4465848374
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499189825438613504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722896358, 8.6275021837 ]
  },
  "id_str" : "499190536360964096",
  "in_reply_to_user_id" : 103004948,
  "text" : "@recology_ @PhilippBayer Thanks for always letting us know when things break :)",
  "id" : 499190536360964096,
  "in_reply_to_status_id" : 499189825438613504,
  "created_at" : "2014-08-12 13:47:53 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722805243, 8.627544799 ]
  },
  "id_str" : "499186288634114048",
  "text" : "\u00ABWhy did you bring a guitar?\u00BB \u2013 \u00ABSo I can learn the Nirvana-hit \u2018In Bloom filter\u2019 for next week\u2019s journal club.\u00BB",
  "id" : 499186288634114048,
  "created_at" : "2014-08-12 13:31:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/ObQkXpEMhY",
      "expanded_url" : "http:\/\/instagram.com\/p\/rl3inqhwu2\/",
      "display_url" : "instagram.com\/p\/rl3inqhwu2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "499111597022117888",
  "text" : "I miss jumping over stepping stones (and getting wet feet) all day http:\/\/t.co\/ObQkXpEMhY",
  "id" : 499111597022117888,
  "created_at" : "2014-08-12 08:34:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499106603136999424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722769442, 8.6275602656 ]
  },
  "id_str" : "499106748054384640",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon thanks for checking :)",
  "id" : 499106748054384640,
  "in_reply_to_status_id" : 499106603136999424,
  "created_at" : "2014-08-12 08:14:56 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499103267230474240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722919315, 8.6275759832 ]
  },
  "id_str" : "499103476660838400",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara when results are so great they stimulate the bowel movements. ;)",
  "id" : 499103476660838400,
  "in_reply_to_status_id" : 499103267230474240,
  "created_at" : "2014-08-12 08:01:56 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722919315, 8.6275759832 ]
  },
  "id_str" : "499102900355080192",
  "text" : "doing the \u2018the data supports my gut feeling\u2019-dance \\o\/",
  "id" : 499102900355080192,
  "created_at" : "2014-08-12 07:59:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723063831, 8.627569799 ]
  },
  "id_str" : "499088428907393024",
  "text" : "\u00ABIntellectual rigor? More like intellectual rigor mortis\u2026\u00BB",
  "id" : 499088428907393024,
  "created_at" : "2014-08-12 07:02:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499016518995161088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723015377, 8.6275928035 ]
  },
  "id_str" : "499082898667233280",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch thanks a lot!",
  "id" : 499082898667233280,
  "in_reply_to_status_id" : 499016518995161088,
  "created_at" : "2014-08-12 06:40:10 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gegengewalt",
      "screen_name" : "ekelias",
      "indices" : [ 0, 8 ],
      "id_str" : "15890805",
      "id" : 15890805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/UM8X8mdVJ0",
      "expanded_url" : "http:\/\/www.hotpinknailpolish.com\/uploads\/3\/6\/3\/0\/3630603\/9405954_orig.jpg",
      "display_url" : "hotpinknailpolish.com\/uploads\/3\/6\/3\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "498949121202749441",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096557322, 8.283058874 ]
  },
  "id_str" : "498949758841786370",
  "in_reply_to_user_id" : 15890805,
  "text" : "@ekelias http:\/\/t.co\/UM8X8mdVJ0",
  "id" : 498949758841786370,
  "in_reply_to_status_id" : 498949121202749441,
  "created_at" : "2014-08-11 21:51:07 +0000",
  "in_reply_to_screen_name" : "ekelias",
  "in_reply_to_user_id_str" : "15890805",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex T. Fenris [Der Dritte Spieler]",
      "screen_name" : "dritterspieler",
      "indices" : [ 0, 15 ],
      "id_str" : "173897436",
      "id" : 173897436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498943254038335488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095568865, 8.2828941777 ]
  },
  "id_str" : "498943379133435904",
  "in_reply_to_user_id" : 173897436,
  "text" : "@dritterspieler science is just getting started!",
  "id" : 498943379133435904,
  "in_reply_to_status_id" : 498943254038335488,
  "created_at" : "2014-08-11 21:25:46 +0000",
  "in_reply_to_screen_name" : "dritterspieler",
  "in_reply_to_user_id_str" : "173897436",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/iYkZGCS8Eg",
      "expanded_url" : "http:\/\/www.bondara.co.uk\/blog\/sexy-news\/sexfit\/",
      "display_url" : "bondara.co.uk\/blog\/sexy-news\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009557, 8.282894 ]
  },
  "id_str" : "498942736469594113",
  "text" : "A cock ring \u00ABthat will provide insights into your intimate workout, including calories burnt &amp; thrusts per minute.\u00BB http:\/\/t.co\/iYkZGCS8Eg",
  "id" : 498942736469594113,
  "created_at" : "2014-08-11 21:23:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/SSwYMH5WHp",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/08\/11\/13-dogs-all-jumping-rope-at-th.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+boingboing%2FiBag+%28Boing+Boing%29",
      "display_url" : "boingboing.net\/2014\/08\/11\/13-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "498941509455323139",
  "text" : "Every day needs this video  http:\/\/t.co\/SSwYMH5WHp",
  "id" : 498941509455323139,
  "created_at" : "2014-08-11 21:18:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9930833652, 8.2711048699 ]
  },
  "id_str" : "498923688436457472",
  "text" : "\u00ABThe only weapon you will ever need. People, the electric guitar. And it never runs out of ammunition!\u00BB &lt;3",
  "id" : 498923688436457472,
  "created_at" : "2014-08-11 20:07:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/uAEVv1kSSW",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/41",
      "display_url" : "existentialcomics.com\/comic\/41"
    } ]
  },
  "geo" : { },
  "id_str" : "498887699882061824",
  "text" : "Existential Radio http:\/\/t.co\/uAEVv1kSSW",
  "id" : 498887699882061824,
  "created_at" : "2014-08-11 17:44:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722917293, 8.6275467483 ]
  },
  "id_str" : "498862550399082497",
  "text" : "Academia: where people seriously entertain to pass on their payment because they fear they might be greedy if they take it.",
  "id" : 498862550399082497,
  "created_at" : "2014-08-11 16:04:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/RSQ8BJ08ux",
      "expanded_url" : "https:\/\/twitter.com\/recology_\/status\/498855806822285313",
      "display_url" : "twitter.com\/recology_\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172287583, 8.6275678706 ]
  },
  "id_str" : "498856057616482304",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer just fyi :) https:\/\/t.co\/RSQ8BJ08ux",
  "id" : 498856057616482304,
  "created_at" : "2014-08-11 15:38:47 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723061738, 8.6275636874 ]
  },
  "id_str" : "498842688759037952",
  "text" : "\u00ABIs it your \u2018Year of Learning Incomprehensible Languages\u2019? First Perl, now Hebrew\u2026\u00BB",
  "id" : 498842688759037952,
  "created_at" : "2014-08-11 14:45:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1116350987, 8.7558574645 ]
  },
  "id_str" : "498814022557659136",
  "text" : "Wildes Offenbach: \u00ABWas schreibt man da jetzt auf den Zettel? 'Gelbe Tonne hat ihren Wagen angefahren. Bitte melden'?\u00BB",
  "id" : 498814022557659136,
  "created_at" : "2014-08-11 12:51:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498683455727620096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.007965164, 8.2823508154 ]
  },
  "id_str" : "498734766750179328",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer cool, thanks a lot.",
  "id" : 498734766750179328,
  "in_reply_to_status_id" : 498683455727620096,
  "created_at" : "2014-08-11 07:36:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096121949, 8.2829789296 ]
  },
  "id_str" : "498569652147351552",
  "text" : "\u00ABKann ich Cards Against Humanity schon einpacken?\u00BB \u2013 \u00ABNein, die Sextoys gehen zuletzt!\u00BB",
  "id" : 498569652147351552,
  "created_at" : "2014-08-10 20:40:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@F0O0",
      "screen_name" : "F0O0",
      "indices" : [ 0, 5 ],
      "id_str" : "105943845",
      "id" : 105943845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498546564592574466",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096784989, 8.2829952855 ]
  },
  "id_str" : "498547048673996800",
  "in_reply_to_user_id" : 105943845,
  "text" : "@F0O0 Zumindest gibt es seit der Wahl in diesem Haushalt ein B\u00FCgeleisen\/brett. Das sagt doch schon alles!",
  "id" : 498547048673996800,
  "in_reply_to_status_id" : 498546564592574466,
  "created_at" : "2014-08-10 19:10:53 +0000",
  "in_reply_to_screen_name" : "F0O0",
  "in_reply_to_user_id_str" : "105943845",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096990641, 8.2831076339 ]
  },
  "id_str" : "498546353652654080",
  "text" : "\u00ABIch glaube ich falte die Klamotten lieber.\u00BB \u2014 \u00ABOh, kaum in der Politik und schon im Establishment angekommen. Mit gefalteten Hoodies.\u00BB",
  "id" : 498546353652654080,
  "created_at" : "2014-08-10 19:08:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 27, 36 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096989423, 8.2828496833 ]
  },
  "id_str" : "498505160046702592",
  "text" : "H\u00E4tte meinen Reisepass von @senficon in einem Umzugskarton verstecken lassen sollen. H\u00E4tte dann 50% der Kisten in der 1. Woche ausger\u00E4umt.",
  "id" : 498505160046702592,
  "created_at" : "2014-08-10 16:24:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096731321, 8.2829120871 ]
  },
  "id_str" : "498495085475287040",
  "text" : "I get the feeling that \u00ABPolyamory: Married and Dating\u00BB should add \u00ABand Never Working a Day in your Life\u00BB to its subtitle.",
  "id" : 498495085475287040,
  "created_at" : "2014-08-10 15:44:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498456083086970881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096335501, 8.2829093987 ]
  },
  "id_str" : "498456507227582465",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente billiger, gr\u00F6\u00DFer und bessere Verkehrsanbindung in both senses of the word.",
  "id" : 498456507227582465,
  "in_reply_to_status_id" : 498456083086970881,
  "created_at" : "2014-08-10 13:11:06 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498455497365020672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096697458, 8.2828943254 ]
  },
  "id_str" : "498455566625566720",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente Offenbach.",
  "id" : 498455566625566720,
  "in_reply_to_status_id" : 498455497365020672,
  "created_at" : "2014-08-10 13:07:22 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piratenpartei",
      "screen_name" : "Piratenpartei",
      "indices" : [ 106, 120 ],
      "id_str" : "14341194",
      "id" : 14341194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965523, 8.28418338 ]
  },
  "id_str" : "498445689962389504",
  "text" : "Funfact: Gut 95% der Post die ich jetzt beim Aufr\u00E4umen finde und (z.T. unge\u00F6ffnet) wegwerfe kommt von der @Piratenpartei.",
  "id" : 498445689962389504,
  "created_at" : "2014-08-10 12:28:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096501533, 8.2838683521 ]
  },
  "id_str" : "498435531949498368",
  "text" : "Moving Out II \u2013 In the Paper Mountains of Madness",
  "id" : 498435531949498368,
  "created_at" : "2014-08-10 11:47:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/VGDY9VImYx",
      "expanded_url" : "https:\/\/jdrewscott.files.wordpress.com\/2010\/01\/darwin_evolves_pokemon.jpg",
      "display_url" : "jdrewscott.files.wordpress.com\/2010\/01\/darwin\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00883979, 8.2835296 ]
  },
  "id_str" : "498406036207054848",
  "text" : "Thanks to @PhilippBayer I\u2019m now reading about Darwin\u2019s knack for beetle hunting. Always reminds me of this: https:\/\/t.co\/VGDY9VImYx",
  "id" : 498406036207054848,
  "created_at" : "2014-08-10 09:50:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498285129257594880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096774217, 8.2830198536 ]
  },
  "id_str" : "498285756511956992",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer would love to see the effect of rising the price to the same level here in Germany. :D",
  "id" : 498285756511956992,
  "in_reply_to_status_id" : 498285129257594880,
  "created_at" : "2014-08-10 01:52:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498284489877901312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009687309, 8.2830229627 ]
  },
  "id_str" : "498284732065796096",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer guess that's highly dependent on the crowd you're moving in. Partying students might show higher prevalence. ;)",
  "id" : 498284732065796096,
  "in_reply_to_status_id" : 498284489877901312,
  "created_at" : "2014-08-10 01:48:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498279879905783808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097043063, 8.2830335926 ]
  },
  "id_str" : "498280745438568450",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer in .de it's 27\/23% according to Wikipedia. Doesn't seem too big a difference given the price gap.",
  "id" : 498280745438568450,
  "in_reply_to_status_id" : 498279879905783808,
  "created_at" : "2014-08-10 01:32:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498279033147113472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097524655, 8.2829451654 ]
  },
  "id_str" : "498279521922338816",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer wow, does it help in reducing the prevalence of smoking?",
  "id" : 498279521922338816,
  "in_reply_to_status_id" : 498279033147113472,
  "created_at" : "2014-08-10 01:27:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498278362419187712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009702862, 8.2829589081 ]
  },
  "id_str" : "498278631953924097",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer so by smuggling some boxes of cigarettes I could pay for the flights? :p",
  "id" : 498278631953924097,
  "in_reply_to_status_id" : 498278362419187712,
  "created_at" : "2014-08-10 01:24:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498276269511802881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096887981, 8.2830148065 ]
  },
  "id_str" : "498276915388878848",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, your flat was located pretty conveniently for that. Guess I will have to come to Oz for some drinks some day.",
  "id" : 498276915388878848,
  "in_reply_to_status_id" : 498276269511802881,
  "created_at" : "2014-08-10 01:17:28 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/498275809162182656\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/0TpsZ6UjKg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Buo7NI-CMAAvBbn.jpg",
      "id_str" : "498275805709873152",
      "id" : 498275805709873152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Buo7NI-CMAAvBbn.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/0TpsZ6UjKg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498275397994180609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096867691, 8.2830445148 ]
  },
  "id_str" : "498275809162182656",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer still, it was a nice trip down memory lane. Made me miss drinking and sciencing at your place. http:\/\/t.co\/0TpsZ6UjKg",
  "id" : 498275809162182656,
  "in_reply_to_status_id" : 498275397994180609,
  "created_at" : "2014-08-10 01:13:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498274284138004480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097195769, 8.2829459579 ]
  },
  "id_str" : "498274730152312832",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer had, I even found our math submissions and other stuff. Now they are lost in time, like waste paper in the 21st century.",
  "id" : 498274730152312832,
  "in_reply_to_status_id" : 498274284138004480,
  "created_at" : "2014-08-10 01:08:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeorgeMonbiot",
      "screen_name" : "GeorgeMonbiot",
      "indices" : [ 3, 17 ],
      "id_str" : "198584761",
      "id" : 198584761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498274145663475712",
  "text" : "RT @GeorgeMonbiot: This week's blog post is about the dodgy claims and magical thinking in a TED talk viewed 2.6m times. http:\/\/t.co\/wQJdYG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/wQJdYGFkLT",
        "expanded_url" : "http:\/\/www.theguardian.com\/environment\/georgemonbiot\/2014\/aug\/04\/eat-more-meat-and-save-the-world-the-latest-implausible-farming-miracle",
        "display_url" : "theguardian.com\/environment\/ge\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "496305242208993280",
    "text" : "This week's blog post is about the dodgy claims and magical thinking in a TED talk viewed 2.6m times. http:\/\/t.co\/wQJdYGFkLT",
    "id" : 496305242208993280,
    "created_at" : "2014-08-04 14:42:45 +0000",
    "user" : {
      "name" : "GeorgeMonbiot",
      "screen_name" : "GeorgeMonbiot",
      "protected" : false,
      "id_str" : "198584761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3594607450\/ff6fbd42964f9a0def79d8acbfa034bd_normal.jpeg",
      "id" : 198584761,
      "verified" : false
    }
  },
  "id" : 498274145663475712,
  "created_at" : "2014-08-10 01:06:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan Maher",
      "screen_name" : "bmahersciwriter",
      "indices" : [ 3, 19 ],
      "id_str" : "4874562838",
      "id" : 4874562838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498271297798148096",
  "text" : "RT @bmahersciwriter: Nick Wade doubles down, says 130 scientists who think he misinterpreted their work with it are guided by politics.   h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/126drHDKfc",
        "expanded_url" : "http:\/\/blogs.nature.com\/news\/2014\/08\/geneticists-say-popular-book-misrepresents-research-on-human-evolution.html",
        "display_url" : "blogs.nature.com\/news\/2014\/08\/g\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "497960439570235393",
    "text" : "Nick Wade doubles down, says 130 scientists who think he misinterpreted their work with it are guided by politics.   http:\/\/t.co\/126drHDKfc",
    "id" : 497960439570235393,
    "created_at" : "2014-08-09 04:19:55 +0000",
    "user" : {
      "name" : "Brendan Maher",
      "screen_name" : "bmaher",
      "protected" : false,
      "id_str" : "18089292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67268364\/brendan_hs_normal.jpg",
      "id" : 18089292,
      "verified" : true
    }
  },
  "id" : 498271297798148096,
  "created_at" : "2014-08-10 00:55:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096858271, 8.2831950653 ]
  },
  "id_str" : "498254250221506560",
  "text" : "\u00ABI don't play guitar, I callus myself in the pursuit of happiness.\u00BB",
  "id" : 498254250221506560,
  "created_at" : "2014-08-09 23:47:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "padeluun | Art d\u2018Ameublement",
      "screen_name" : "padeluun",
      "indices" : [ 0, 9 ],
      "id_str" : "41388754",
      "id" : 41388754
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498211064694444032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0103301069, 8.278273149 ]
  },
  "id_str" : "498212277427118080",
  "in_reply_to_user_id" : 41388754,
  "text" : "@padeluun @Senficon danke, passt zu unserer Beobachtung.",
  "id" : 498212277427118080,
  "in_reply_to_status_id" : 498211064694444032,
  "created_at" : "2014-08-09 21:00:37 +0000",
  "in_reply_to_screen_name" : "padeluun",
  "in_reply_to_user_id_str" : "41388754",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0090431888, 8.279347904 ]
  },
  "id_str" : "498206915399532544",
  "text" : "ISS spotting right next to FRA: 'There! Wait, that's a plane\u2026 There! Wait, a plane again\u2026 There! Ah, fuck that\u2026\u00BB",
  "id" : 498206915399532544,
  "created_at" : "2014-08-09 20:39:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 12, 21 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 41, 48 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498202634441203713",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097394095, 8.2830393864 ]
  },
  "id_str" : "498202733577764864",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach @Senficon Ich hab geh\u00F6rt der @seb666 hat da vielleicht eine ;)",
  "id" : 498202733577764864,
  "in_reply_to_status_id" : 498202634441203713,
  "created_at" : "2014-08-09 20:22:42 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 12, 21 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/MweBha86qQ",
      "expanded_url" : "http:\/\/img.pandawhale.com\/post-25106-Waldorf-Statler-Internet-sarca-9qnT.gif",
      "display_url" : "img.pandawhale.com\/post-25106-Wal\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "498199331967860736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095930417, 8.2828781102 ]
  },
  "id_str" : "498201756258811905",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach @Senficon worauf wir all die Jahre gewartet haben! http:\/\/t.co\/MweBha86qQ",
  "id" : 498201756258811905,
  "in_reply_to_status_id" : 498199331967860736,
  "created_at" : "2014-08-09 20:18:49 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 10, 21 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498198689710878720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096709814, 8.2829169287 ]
  },
  "id_str" : "498199246873829376",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @herrurbach bekommen wir zumindest irgendwelche besonderen Shirts die uns als graue Eminenzen ausweisen? ;)",
  "id" : 498199246873829376,
  "in_reply_to_status_id" : 498198689710878720,
  "created_at" : "2014-08-09 20:08:51 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 10, 21 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498197577415024640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0088399731, 8.2835294784 ]
  },
  "id_str" : "498198346470031360",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @herrurbach hast du uns ErstBESUCHER-Tickets geklickt? :P",
  "id" : 498198346470031360,
  "in_reply_to_status_id" : 498197577415024640,
  "created_at" : "2014-08-09 20:05:16 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498122221916004352",
  "text" : "\u00ABDieser Joghurt ist nicht aus unserer Kultur.\u00BB \u2013 \u00ABNicht linksdrehend?\u00BB \u2013 \u00ABDie Packung spricht franz\u00F6sisch.\u00BB",
  "id" : 498122221916004352,
  "created_at" : "2014-08-09 15:02:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/RajoMXqERI",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/94158370037",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/941583700\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "498115634543480832",
  "text" : "and i like it that way http:\/\/t.co\/RajoMXqERI",
  "id" : 498115634543480832,
  "created_at" : "2014-08-09 14:36:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009604356, 8.2828424924 ]
  },
  "id_str" : "498097409264979968",
  "text" : "\u00ABDas Herbarium zieht wieder mit um?\u00BB \u2013 \u00ABDamit ich meinen Kindern mal sagen kann \u2018So sahen Pflanzen aus, als es noch welche gab\u2019.\u00BB",
  "id" : 498097409264979968,
  "created_at" : "2014-08-09 13:24:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 33, 46 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096584656, 8.2828739352 ]
  },
  "id_str" : "498083736437932032",
  "text" : "I not only took the herbarium of @PhilippBayer and me during my last move, but also all notes for biology 101 &amp; inorganic chemistry 101\u2026",
  "id" : 498083736437932032,
  "created_at" : "2014-08-09 12:29:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095660381, 8.2830400775 ]
  },
  "id_str" : "498076815437856769",
  "text" : "Related to moving: anyone nearby interested in a +\/- complete 2008-2010 catalog of Nature? Otherwise they will go the way of all paper.",
  "id" : 498076815437856769,
  "created_at" : "2014-08-09 12:02:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/WqfT0GgTdL",
      "expanded_url" : "http:\/\/instagram.com\/p\/regYXAhwmT\/",
      "display_url" : "instagram.com\/p\/regYXAhwmT\/"
    } ]
  },
  "geo" : { },
  "id_str" : "498075504813953025",
  "text" : "The latest addition to the survival horror genre: moving out. http:\/\/t.co\/WqfT0GgTdL",
  "id" : 498075504813953025,
  "created_at" : "2014-08-09 11:57:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/506r1qDrQG",
      "expanded_url" : "http:\/\/instagram.com\/p\/reNA4whwuv\/",
      "display_url" : "instagram.com\/p\/reNA4whwuv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "498032916057059329",
  "text" : "One cannot think well, love well, sleep well, if one has not dined well. http:\/\/t.co\/506r1qDrQG",
  "id" : 498032916057059329,
  "created_at" : "2014-08-09 09:07:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 5, 12 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497856018463080448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0061093551, 8.2753333915 ]
  },
  "id_str" : "497867247801872384",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy @acid23 @Lobot hab die KSO Trek und die Lontra. Beide toll, je nach Wetter.",
  "id" : 497867247801872384,
  "in_reply_to_status_id" : 497856018463080448,
  "created_at" : "2014-08-08 22:09:36 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/Ov9aa5v33S",
      "expanded_url" : "http:\/\/instagram.com\/p\/rcgROqhwh7\/",
      "display_url" : "instagram.com\/p\/rcgROqhwh7\/"
    } ]
  },
  "geo" : { },
  "id_str" : "497793784986349568",
  "text" : "the color of the atmospheric distance between you and the mountains http:\/\/t.co\/Ov9aa5v33S",
  "id" : 497793784986349568,
  "created_at" : "2014-08-08 17:17:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/or9nKCOsJM",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/4DW5fftFupY\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172287, 8.627553 ]
  },
  "id_str" : "497748222258204672",
  "text" : "the bureaucracy works\u2026  http:\/\/t.co\/or9nKCOsJM",
  "id" : 497748222258204672,
  "created_at" : "2014-08-08 14:16:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/XJ9Y9RTCqx",
      "expanded_url" : "http:\/\/instagram.com\/p\/rcK9AtBwrX\/",
      "display_url" : "instagram.com\/p\/rcK9AtBwrX\/"
    } ]
  },
  "geo" : { },
  "id_str" : "497746910711521282",
  "text" : "Trollpenis (small) http:\/\/t.co\/XJ9Y9RTCqx",
  "id" : 497746910711521282,
  "created_at" : "2014-08-08 14:11:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497743519893958656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172336591, 8.6275733809 ]
  },
  "id_str" : "497744148112605184",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83D\uDDFB",
  "id" : 497744148112605184,
  "in_reply_to_status_id" : 497743519893958656,
  "created_at" : "2014-08-08 14:00:27 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/GQsycgDEVf",
      "expanded_url" : "http:\/\/global3.memecdn.com\/i-lava-you_o_986800.jpg",
      "display_url" : "global3.memecdn.com\/i-lava-you_o_9\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "497739397270614016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723389024, 8.6275286739 ]
  },
  "id_str" : "497740740802646016",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/GQsycgDEVf",
  "id" : 497740740802646016,
  "in_reply_to_status_id" : 497739397270614016,
  "created_at" : "2014-08-08 13:46:54 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/I1dIhNhTpc",
      "expanded_url" : "http:\/\/xkcd.com\/1405\/",
      "display_url" : "xkcd.com\/1405\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172284, 8.627442 ]
  },
  "id_str" : "497734981876473856",
  "text" : "actually, it's called magma! http:\/\/t.co\/I1dIhNhTpc",
  "id" : 497734981876473856,
  "created_at" : "2014-08-08 13:24:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172338734, 8.6275281645 ]
  },
  "id_str" : "497714141256499200",
  "text" : "\u00ABUnd dann sind wir auf Island-Polys geritten!\u00BB",
  "id" : 497714141256499200,
  "created_at" : "2014-08-08 12:01:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724824912, 8.6274091623 ]
  },
  "id_str" : "497706661059256320",
  "text" : "\u00ABDu bist furchtbar!\u00BB \u2014 \u00ABFurchtbar gutaussehend meinst du!\u00BB \u2014 \u00ABJa, du sexy Lachs-Bagel!\u00BB",
  "id" : 497706661059256320,
  "created_at" : "2014-08-08 11:31:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723112311, 8.6275523088 ]
  },
  "id_str" : "497699447879766016",
  "text" : "\u00ABWelcher Religion geh\u00F6rst du denn an? Barebacking Baptist Church?\u00BB",
  "id" : 497699447879766016,
  "created_at" : "2014-08-08 11:02:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497695783874220033",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1719938391, 8.6309132744 ]
  },
  "id_str" : "497695896340275200",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 genau, jetzt mal irgendwann in den Apple Store damit.",
  "id" : 497695896340275200,
  "in_reply_to_status_id" : 497695783874220033,
  "created_at" : "2014-08-08 10:48:43 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497695318713331712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1720009363, 8.6309533182 ]
  },
  "id_str" : "497695687543652352",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 hab jetzt alles wichtige\nvon der Platte ziehen k\u00F6nnen.",
  "id" : 497695687543652352,
  "in_reply_to_status_id" : 497695318713331712,
  "created_at" : "2014-08-08 10:47:53 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 73, 79 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497695318713331712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1720910608, 8.6308764958 ]
  },
  "id_str" : "497695604395741184",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 so semi. Ich k\u00F6nnte zumindest das OS noch mal booten nachdem ich @Lobot's Rechner zum Recovery der Partition missbraucht hab.",
  "id" : 497695604395741184,
  "in_reply_to_status_id" : 497695318713331712,
  "created_at" : "2014-08-08 10:47:33 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497693497294856192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227882, 8.6306711003 ]
  },
  "id_str" : "497694457681440769",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot in dem Song geht es um was?!",
  "id" : 497694457681440769,
  "in_reply_to_status_id" : 497693497294856192,
  "created_at" : "2014-08-08 10:43:00 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "antiprodukt",
      "screen_name" : "antiprodukt",
      "indices" : [ 0, 12 ],
      "id_str" : "149089037",
      "id" : 149089037
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497693570284134400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1720778216, 8.6308748987 ]
  },
  "id_str" : "497694175199248384",
  "in_reply_to_user_id" : 149089037,
  "text" : "@antiprodukt @Lobot und nur noch gut 3 Wochen bis ich dann wieder im Urlaub bin :3",
  "id" : 497694175199248384,
  "in_reply_to_status_id" : 497693570284134400,
  "created_at" : "2014-08-08 10:41:52 +0000",
  "in_reply_to_screen_name" : "antiprodukt",
  "in_reply_to_user_id_str" : "149089037",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1719541062, 8.6309488208 ]
  },
  "id_str" : "497692764805427200",
  "text" : "\u00ABUnd dann muss man dabei durch Eiswasser tauchen und ganz viel durch Matsch rennen.\u00BB \u2014 \u00ABAh, also das was ich Urlaub nenne?\u00BB",
  "id" : 497692764805427200,
  "created_at" : "2014-08-08 10:36:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 45, 58 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/Tx7PpBgquH",
      "expanded_url" : "http:\/\/simplystatistics.org\/2014\/08\/07\/its-like-tinder-but-for-peer-review\/",
      "display_url" : "simplystatistics.org\/2014\/08\/07\/its\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009595, 8.282899 ]
  },
  "id_str" : "497484754745573377",
  "text" : "\u00ABIt's like Tinder, but for peer review.\u00BB \/cc @PhilippBayer  http:\/\/t.co\/Tx7PpBgquH",
  "id" : 497484754745573377,
  "created_at" : "2014-08-07 20:49:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096566213, 8.2829511949 ]
  },
  "id_str" : "497466674766155777",
  "text" : "In der S-Bahn: \u00ABHast du deine Luftgitarre etwa auch immer dabei? Die ben\u00F6tigt man echt, so schrecklich wie das Deutschland da draussen ist.\u00BB",
  "id" : 497466674766155777,
  "created_at" : "2014-08-07 19:37:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "renamed @sckottie",
      "screen_name" : "recology_",
      "indices" : [ 13, 23 ],
      "id_str" : "4465848374",
      "id" : 4465848374
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 24, 37 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497411090922606592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172391543, 8.6274425556 ]
  },
  "id_str" : "497411312910336000",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @recology_ @PhilippBayer thx!",
  "id" : 497411312910336000,
  "in_reply_to_status_id" : 497411090922606592,
  "created_at" : "2014-08-07 15:57:53 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "renamed @sckottie",
      "screen_name" : "recology_",
      "indices" : [ 13, 23 ],
      "id_str" : "4465848374",
      "id" : 4465848374
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 24, 37 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497407574728531968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723208655, 8.6275546501 ]
  },
  "id_str" : "497408030921986048",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @recology_ @PhilippBayer thanks, hopefully my laptop will be fixed soon, so I can be more productive again.",
  "id" : 497408030921986048,
  "in_reply_to_status_id" : 497407574728531968,
  "created_at" : "2014-08-07 15:44:50 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @sckottie",
      "screen_name" : "recology_",
      "indices" : [ 0, 10 ],
      "id_str" : "4465848374",
      "id" : 4465848374
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 85, 98 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 103, 115 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497406388604129281",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723208655, 8.6275546501 ]
  },
  "id_str" : "497406718016368640",
  "in_reply_to_user_id" : 103004948,
  "text" : "@recology_ sorry, no idea. Currently lacking access to the server from my end. Maybe @PhilippBayer and @helgerausch can help?",
  "id" : 497406718016368640,
  "in_reply_to_status_id" : 497406388604129281,
  "created_at" : "2014-08-07 15:39:37 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharin Tai",
      "screen_name" : "Whitey_chan",
      "indices" : [ 58, 70 ],
      "id_str" : "48357885",
      "id" : 48357885
    }, {
      "name" : "Tasmo",
      "screen_name" : "_Tasmo",
      "indices" : [ 122, 129 ],
      "id_str" : "19062604",
      "id" : 19062604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/afDz1058ac",
      "expanded_url" : "http:\/\/pocket.co\/sL89F",
      "display_url" : "pocket.co\/sL89F"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724266737, 8.6273912206 ]
  },
  "id_str" : "497399172476456960",
  "text" : "yes, please: \u00ABa single Earth Time for all of humanity\u00BB RT @Whitey_chan: Zeitzonen \u00FCberwinden! http:\/\/t.co\/afDz1058ac (via @_tasmo)",
  "id" : 497399172476456960,
  "created_at" : "2014-08-07 15:09:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/IReAvrJLQD",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/lGjqso5mIYw\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172388, 8.627489 ]
  },
  "id_str" : "497377466949042177",
  "text" : "Ethics .\/. Bioethics http:\/\/t.co\/IReAvrJLQD",
  "id" : 497377466949042177,
  "created_at" : "2014-08-07 13:43:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/x0gsk6I1zY",
      "expanded_url" : "http:\/\/www.anglizismen.info\/wordpress\/",
      "display_url" : "anglizismen.info\/wordpress\/"
    } ]
  },
  "geo" : { },
  "id_str" : "497344991266869248",
  "text" : "RT @Lobot: Ich will rausfinden was an LOL so toll ist (oder auch nicht). Helft ihr mir dabei? http:\/\/t.co\/x0gsk6I1zY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/x0gsk6I1zY",
        "expanded_url" : "http:\/\/www.anglizismen.info\/wordpress\/",
        "display_url" : "anglizismen.info\/wordpress\/"
      } ]
    },
    "geo" : { },
    "id_str" : "497341368126427136",
    "text" : "Ich will rausfinden was an LOL so toll ist (oder auch nicht). Helft ihr mir dabei? http:\/\/t.co\/x0gsk6I1zY",
    "id" : 497341368126427136,
    "created_at" : "2014-08-07 11:19:56 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 497344991266869248,
  "created_at" : "2014-08-07 11:34:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497177901821730816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097245103, 8.282975174 ]
  },
  "id_str" : "497246214656888832",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer banjo guitar. :3",
  "id" : 497246214656888832,
  "in_reply_to_status_id" : 497177901821730816,
  "created_at" : "2014-08-07 05:01:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497166221335613440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009602487, 8.2827991958 ]
  },
  "id_str" : "497174142173851648",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks, it's a beautiful work of art :3",
  "id" : 497174142173851648,
  "in_reply_to_status_id" : 497166221335613440,
  "created_at" : "2014-08-07 00:15:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097151136, 8.2831041362 ]
  },
  "id_str" : "497129412522180609",
  "text" : "\u00ABN\u00E4chster Poly-Papst wird derjenige, von dessen Penis als erstes wei\u00DFer Rauch aufsteigt!\u00BB",
  "id" : 497129412522180609,
  "created_at" : "2014-08-06 21:17:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "nad no ennas",
      "screen_name" : "nadnoennas",
      "indices" : [ 8, 19 ],
      "id_str" : "769945612167081984",
      "id" : 769945612167081984
    }, {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 20, 28 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497054263659724800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1766563932, 8.6288361146 ]
  },
  "id_str" : "497055751521992704",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 @nadnoennas @insideX ok, sind so gegen 1900\/1915 bei dir.",
  "id" : 497055751521992704,
  "in_reply_to_status_id" : 497054263659724800,
  "created_at" : "2014-08-06 16:25:00 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497047723020132352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722892664, 8.6275787409 ]
  },
  "id_str" : "497048745738264577",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 sollte gehen.",
  "id" : 497048745738264577,
  "in_reply_to_status_id" : 497047723020132352,
  "created_at" : "2014-08-06 15:57:10 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1786751162, 8.6139318582 ]
  },
  "id_str" : "497005293801578497",
  "text" : "\u00ABWas ist denn los?\u00BB \u2013 \u00ABIch bin frustriert. Los, gib mir die Spr\u00FChsahne direkt in den Mund.\u00BB",
  "id" : 497005293801578497,
  "created_at" : "2014-08-06 13:04:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/9JDWnbWRUk",
      "expanded_url" : "https:\/\/github.com\/vice87\/gam-ngs\/issues\/15",
      "display_url" : "github.com\/vice87\/gam-ngs\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1991497339, 8.5828787844 ]
  },
  "id_str" : "497003858632409088",
  "text" : "Has anyone else encountered this strange and somewhat randomly appearing memory corruption error with gam-ngs? https:\/\/t.co\/9JDWnbWRUk",
  "id" : 497003858632409088,
  "created_at" : "2014-08-06 12:58:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 0, 11 ],
      "id_str" : "16084074",
      "id" : 16084074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497000518842339328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723681398, 8.6274846115 ]
  },
  "id_str" : "497002115727110144",
  "in_reply_to_user_id" : 16084074,
  "text" : "@sofakissen well, wait until you see the next version of this bioinformatics software :p",
  "id" : 497002115727110144,
  "in_reply_to_status_id" : 497000518842339328,
  "created_at" : "2014-08-06 12:51:52 +0000",
  "in_reply_to_screen_name" : "sofakissen",
  "in_reply_to_user_id_str" : "16084074",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172367157, 8.62749897 ]
  },
  "id_str" : "496998841443688449",
  "text" : "\u00ABfeature request: mini game instead of progress bar.\u00BB",
  "id" : 496998841443688449,
  "created_at" : "2014-08-06 12:38:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/af1nIjhCjv",
      "expanded_url" : "http:\/\/blogs.villagevoice.com\/forkintheroad\/120517085419-jesus-popsicles-1-story-top.jpg",
      "display_url" : "blogs.villagevoice.com\/forkintheroad\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "496983554229010433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723564502, 8.6274444778 ]
  },
  "id_str" : "496984653535117312",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot lick me, messiah! http:\/\/t.co\/af1nIjhCjv",
  "id" : 496984653535117312,
  "in_reply_to_status_id" : 496983554229010433,
  "created_at" : "2014-08-06 11:42:29 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496983301878734848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723564502, 8.6274444778 ]
  },
  "id_str" : "496983770432831488",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot more like ice cream cold turkey.",
  "id" : 496983770432831488,
  "in_reply_to_status_id" : 496983301878734848,
  "created_at" : "2014-08-06 11:38:59 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496982050852077568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723564502, 8.6274444778 ]
  },
  "id_str" : "496982835887353857",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot are you already showing icicle induced stigmata?",
  "id" : 496982835887353857,
  "in_reply_to_status_id" : 496982050852077568,
  "created_at" : "2014-08-06 11:35:16 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 9, 15 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496971002598150144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1756605062, 8.6297028565 ]
  },
  "id_str" : "496973011569090561",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju @Lobot mit super erkennbaren Avataren!",
  "id" : 496973011569090561,
  "in_reply_to_status_id" : 496971002598150144,
  "created_at" : "2014-08-06 10:56:13 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Netzblockierer",
      "screen_name" : "Netzblockierer",
      "indices" : [ 0, 15 ],
      "id_str" : "370916512",
      "id" : 370916512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496972122393411584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17552146, 8.6296179052 ]
  },
  "id_str" : "496972688876109824",
  "in_reply_to_user_id" : 370916512,
  "text" : "@Netzblockierer Sparkasse!",
  "id" : 496972688876109824,
  "in_reply_to_status_id" : 496972122393411584,
  "created_at" : "2014-08-06 10:54:57 +0000",
  "in_reply_to_screen_name" : "Netzblockierer",
  "in_reply_to_user_id_str" : "370916512",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1771885278, 8.6297982061 ]
  },
  "id_str" : "496971891408912384",
  "text" : "Bei der Geldw\u00E4sche f\u00FCr meine Studenten geholfen. Meine Job Description weitet sich irgendwie immer weiter aus.",
  "id" : 496971891408912384,
  "created_at" : "2014-08-06 10:51:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724034332, 8.6275058896 ]
  },
  "id_str" : "496948500400455682",
  "text" : "\u00ABSome things we have only as long as they remain lost, some things are not lost only as long as they are distant.\u00BB",
  "id" : 496948500400455682,
  "created_at" : "2014-08-06 09:18:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496945202888998912",
  "text" : "RT @Lobot: Arbeitslos melden \u2714 (Jobangebote im Rhein-Main-Gebiet gerne zu mir. Bin Journalistin, Linguistin, Dildo-Designerin, arbeite gern\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "496942925033766912",
    "text" : "Arbeitslos melden \u2714 (Jobangebote im Rhein-Main-Gebiet gerne zu mir. Bin Journalistin, Linguistin, Dildo-Designerin, arbeite gerne abends.)",
    "id" : 496942925033766912,
    "created_at" : "2014-08-06 08:56:40 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 496945202888998912,
  "created_at" : "2014-08-06 09:05:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172327193, 8.6275355316 ]
  },
  "id_str" : "496939253482676224",
  "text" : "\u00ABSome inherit values &amp; practices as a house they inhabit; some of us have to burn down that house, find our own ground, built from scratch.\u00BB",
  "id" : 496939253482676224,
  "created_at" : "2014-08-06 08:42:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723399375, 8.6275202547 ]
  },
  "id_str" : "496932381346254848",
  "text" : "\u00ABSometimes we're calling out for help. Sometimes we're offering help, and then this hostile world becomes a very different place.\u00BB",
  "id" : 496932381346254848,
  "created_at" : "2014-08-06 08:14:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172316033, 8.6275563438 ]
  },
  "id_str" : "496932326094688256",
  "text" : "\u00ABcalling out for help is a very generous act because it allows others to help us and it allows us to be helped.\u00BB",
  "id" : 496932326094688256,
  "created_at" : "2014-08-06 08:14:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496924046844383234",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723548203, 8.6274493893 ]
  },
  "id_str" : "496924334989246465",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nah, his autobiography was bad, but not that bad. In a way even fun to see the mind boggling stupidity.",
  "id" : 496924334989246465,
  "in_reply_to_status_id" : 496924046844383234,
  "created_at" : "2014-08-06 07:42:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496910618301956096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1739421315, 8.6273105789 ]
  },
  "id_str" : "496911016685735936",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you're my benchmark on how much literary inflicted mental abuse a human can endure and still come out of the experience alive",
  "id" : 496911016685735936,
  "in_reply_to_status_id" : 496910618301956096,
  "created_at" : "2014-08-06 06:49:53 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496908207571230722",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1567010315, 8.6562110854 ]
  },
  "id_str" : "496908392079036416",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I have to remember that. If even you gave up I won\u2019t have to feel bad once it defeated me.",
  "id" : 496908392079036416,
  "in_reply_to_status_id" : 496908207571230722,
  "created_at" : "2014-08-06 06:39:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496903442292412417",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1018463912, 8.586644282 ]
  },
  "id_str" : "496903632529678336",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I\u2019ll give it a try (really, nearly anything to keep me from Infinite Jest :p)",
  "id" : 496903632529678336,
  "in_reply_to_status_id" : 496903442292412417,
  "created_at" : "2014-08-06 06:20:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/aIslviyW4l",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/567249",
      "display_url" : "goodreads.com\/book\/show\/5672\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "496902656842276865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1013913843, 8.5745556584 ]
  },
  "id_str" : "496902765659316224",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer haha, it\u2019s this one, right? https:\/\/t.co\/aIslviyW4l Worth a read?",
  "id" : 496902765659316224,
  "in_reply_to_status_id" : 496902656842276865,
  "created_at" : "2014-08-06 06:17:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496902050907578369",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1013913843, 8.5745556584 ]
  },
  "id_str" : "496902335529226240",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer the Desmond book is in there, just downloaded it. Was uploaded 3 weeks ago.",
  "id" : 496902335529226240,
  "in_reply_to_status_id" : 496902050907578369,
  "created_at" : "2014-08-06 06:15:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496899516050571265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.092648889, 8.5182215695 ]
  },
  "id_str" : "496901689593823232",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw: did you drop the Darwin book?",
  "id" : 496901689593823232,
  "in_reply_to_status_id" : 496899516050571265,
  "created_at" : "2014-08-06 06:12:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 15, 28 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496900026510352384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.092648889, 8.5182215695 ]
  },
  "id_str" : "496900811461771264",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon @PhilippBayer aren\u2019t citation chains just simple graphs of the nodes &amp; edges-variety? ;)",
  "id" : 496900811461771264,
  "in_reply_to_status_id" : 496900026510352384,
  "created_at" : "2014-08-06 06:09:20 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496899516050571265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0926348614, 8.5182069987 ]
  },
  "id_str" : "496900076426780672",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u2026at least you knew directly what the source is, instead of reading 10 papers in the citation chain before figuring out the age",
  "id" : 496900076426780672,
  "in_reply_to_status_id" : 496899516050571265,
  "created_at" : "2014-08-06 06:06:24 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496899516050571265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0678149008, 8.4897027019 ]
  },
  "id_str" : "496899951272943616",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that\u2019s the downside of giving the first citation: in most cases it\u2019s not easily available any longer, but\u2026",
  "id" : 496899951272943616,
  "in_reply_to_status_id" : 496899516050571265,
  "created_at" : "2014-08-06 06:05:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496898828701016064",
  "text" : "RT @PhilippBayer: 'The story that the iron content of spinach was a myth based on a misplaced decimal point is itself a myth' http:\/\/t.co\/e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/e8ViYcSTcQ",
        "expanded_url" : "http:\/\/sss.sagepub.com\/content\/44\/4\/638.long",
        "display_url" : "sss.sagepub.com\/content\/44\/4\/6\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "496887702726275072",
    "text" : "'The story that the iron content of spinach was a myth based on a misplaced decimal point is itself a myth' http:\/\/t.co\/e8ViYcSTcQ",
    "id" : 496887702726275072,
    "created_at" : "2014-08-06 05:17:14 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 496898828701016064,
  "created_at" : "2014-08-06 06:01:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496887702726275072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0678149008, 8.4897027019 ]
  },
  "id_str" : "496898819280613376",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Oh yes, these damn searches for primary sources down the citation rabbit hole, only tears come out of that!",
  "id" : 496898819280613376,
  "in_reply_to_status_id" : 496887702726275072,
  "created_at" : "2014-08-06 06:01:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/4SkA2lSX2g",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/AbtcunuXDFM\/timelapse-reviving-rose-of-je.html",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.143485, 8.581806 ]
  },
  "id_str" : "496896779259244544",
  "text" : "Timelapse: Reviving Rose of Jericho\u00A0plants http:\/\/t.co\/4SkA2lSX2g",
  "id" : 496896779259244544,
  "created_at" : "2014-08-06 05:53:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/lNeTfC89ho",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/08\/05\/how-groupthink-gets-reality-ba.html",
      "display_url" : "boingboing.net\/2014\/08\/05\/how\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009712, 8.283077 ]
  },
  "id_str" : "496800556821008385",
  "text" : "\u00ABYou can try to do as the Romans do, but remember that the Romans are doing what they think the Romans do\u00BB http:\/\/t.co\/lNeTfC89ho",
  "id" : 496800556821008385,
  "created_at" : "2014-08-05 23:30:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723068595, 8.6275768757 ]
  },
  "id_str" : "496713478896619520",
  "text" : "\u00ABChildren are good at getting lost, because the key in surviving is knowing you're lost.\u00BB",
  "id" : 496713478896619520,
  "created_at" : "2014-08-05 17:44:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724583779, 8.6273232242 ]
  },
  "id_str" : "496700974095138816",
  "text" : "\u00ABStatistics means never having to say you are certain.\u00BB &lt;3",
  "id" : 496700974095138816,
  "created_at" : "2014-08-05 16:55:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723021568, 8.6275816799 ]
  },
  "id_str" : "496692957463207936",
  "text" : "\u00ABThe explorers' most important skill was simply a sense of optimism about surviving and finding their way.\u00BB",
  "id" : 496692957463207936,
  "created_at" : "2014-08-05 16:23:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723082661, 8.6275846045 ]
  },
  "id_str" : "496686323823308800",
  "text" : "\u00ABThe color of where you can never go. For the blue is not in the place itself, but in the atmospheric distance between you &amp; the mountains.\u00BB",
  "id" : 496686323823308800,
  "created_at" : "2014-08-05 15:57:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1280884991, 8.7153061591 ]
  },
  "id_str" : "496659827398287360",
  "text" : "The apartment lease had landed (and after spending 30 minutes in their offices I have some sympathy for their workflow). \\o\/",
  "id" : 496659827398287360,
  "created_at" : "2014-08-05 14:11:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172359367, 8.6275114636 ]
  },
  "id_str" : "496616590591664128",
  "text" : "\u00ABSay, did we leave a hummus box full of rocks at your place?\u00BB probably the worst guest gift ever.",
  "id" : 496616590591664128,
  "created_at" : "2014-08-05 11:19:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Zimmer",
      "screen_name" : "fbnzimmer",
      "indices" : [ 42, 52 ],
      "id_str" : "1515775878",
      "id" : 1515775878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/YBRIpqeAvw",
      "expanded_url" : "http:\/\/jamesmcinerney.ie\/humor\/why-do-a-phd\/",
      "display_url" : "jamesmcinerney.ie\/humor\/why-do-a\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1725157846, 8.6272296573 ]
  },
  "id_str" : "496594723076071424",
  "text" : "Why do a PhD? http:\/\/t.co\/YBRIpqeAvw \/via @fbnzimmer",
  "id" : 496594723076071424,
  "created_at" : "2014-08-05 09:53:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496544736685998080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723223118, 8.6275401806 ]
  },
  "id_str" : "496554127980523520",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks, I think it should still be covered by the warranty, but I wanna try saving data before bringing it to the store.",
  "id" : 496554127980523520,
  "in_reply_to_status_id" : 496544736685998080,
  "created_at" : "2014-08-05 07:11:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496538441899724800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1436630497, 8.6685207579 ]
  },
  "id_str" : "496538986404675584",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer and It looks like the HDD in my laptop killed itself, so my productivity is a bit limited right now.",
  "id" : 496538986404675584,
  "in_reply_to_status_id" : 496538441899724800,
  "created_at" : "2014-08-05 06:11:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496538441899724800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1374181661, 8.6679065843 ]
  },
  "id_str" : "496538819496542209",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer sure, no problem. It\u2019s just that some issues can\u2019t be solved with a flaky ssh-over-3G-connection. ;)",
  "id" : 496538819496542209,
  "in_reply_to_status_id" : 496538441899724800,
  "created_at" : "2014-08-05 06:10:54 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/ZjP8krCyTB",
      "expanded_url" : "http:\/\/www.brainpickings.org\/index.php\/2014\/08\/04\/field-guide-to-getting-lost-rebecca-solnit\/",
      "display_url" : "brainpickings.org\/index.php\/2014\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1053994436, 8.6522196889 ]
  },
  "id_str" : "496538435596079104",
  "text" : "\u00ABNever to get lost is not to live, not to know how to get lost brings you to destruction\u00BB http:\/\/t.co\/ZjP8krCyTB",
  "id" : 496538435596079104,
  "created_at" : "2014-08-05 06:09:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496529587170312192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1027063134, 8.6475576908 ]
  },
  "id_str" : "496534463535648769",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer reminds me: Sorry, still no news for that student of yours. Everything crashed while being in Iceland, will fix it today :3",
  "id" : 496534463535648769,
  "in_reply_to_status_id" : 496529587170312192,
  "created_at" : "2014-08-05 05:53:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/IK6lz2u8j5",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0104035?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosone%2FPLoSONE+%28PLOS+ONE+Alerts%3A+New+Articles%29",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "496533331019046912",
  "text" : "Unimodal Latitudinal Pattern of Land-Snail Species Richness across Northern Eurasian Lowlands http:\/\/t.co\/IK6lz2u8j5",
  "id" : 496533331019046912,
  "created_at" : "2014-08-05 05:49:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/QqsMT8AeaO",
      "expanded_url" : "http:\/\/www.vice.com\/read\/slaves-of-happiness-island-0000412-v21n8",
      "display_url" : "vice.com\/read\/slaves-of\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "496532006474625024",
  "text" : "Slaves of Happiness Island: Abu Dhabi and the Dark Side of High Art\n http:\/\/t.co\/QqsMT8AeaO",
  "id" : 496532006474625024,
  "created_at" : "2014-08-05 05:43:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/EIDk1xfQvo",
      "expanded_url" : "http:\/\/explore.noodle.com\/post\/93830010688\/being-happy-and-finding-life-meaningful-overlap",
      "display_url" : "explore.noodle.com\/post\/938300106\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0013080063, 8.3994646826 ]
  },
  "id_str" : "496526333472952320",
  "text" : "Meaningfulness. Also known as \u2018Overthinking Everything\u2019 http:\/\/t.co\/EIDk1xfQvo",
  "id" : 496526333472952320,
  "created_at" : "2014-08-05 05:21:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/en6zZxLss7",
      "expanded_url" : "http:\/\/thecasualsexproject.com",
      "display_url" : "thecasualsexproject.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096934596, 8.2830156622 ]
  },
  "id_str" : "496420579835396097",
  "text" : "(nearly-T)IL about: The Casual Sex Project http:\/\/t.co\/en6zZxLss7",
  "id" : 496420579835396097,
  "created_at" : "2014-08-04 22:21:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/Xfr0AMt4yV",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/40",
      "display_url" : "existentialcomics.com\/comic\/40"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009607, 8.282888 ]
  },
  "id_str" : "496362630270177281",
  "text" : "Heeeeegel! http:\/\/t.co\/Xfr0AMt4yV",
  "id" : 496362630270177281,
  "created_at" : "2014-08-04 18:30:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095827794, 8.2829594238 ]
  },
  "id_str" : "496279567213285376",
  "text" : "Lebe in einem Haushalt in dem ich im Bett problemlos durch das Buch \u201EPolitik in Rheinland-Pfalz\u201C ersetzt werde.",
  "id" : 496279567213285376,
  "created_at" : "2014-08-04 13:00:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.062377184, 8.5290777031 ]
  },
  "id_str" : "496268930387042304",
  "text" : "Home for less than two hours and I'm already annoyed by humans in general.",
  "id" : 496268930387042304,
  "created_at" : "2014-08-04 12:18:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "496147546511638528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.9958787723, -22.6235982492 ]
  },
  "id_str" : "496173112317460480",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nice!",
  "id" : 496173112317460480,
  "in_reply_to_status_id" : 496147546511638528,
  "created_at" : "2014-08-04 05:57:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/UxeDKok9Ce",
      "expanded_url" : "http:\/\/instagram.com\/p\/rP3hV9Bwij\/",
      "display_url" : "instagram.com\/p\/rP3hV9Bwij\/"
    } ]
  },
  "geo" : { },
  "id_str" : "496015328975933441",
  "text" : "Still somewhat amazed that we could actually find the hot spring given the directions provided by\u2026 http:\/\/t.co\/UxeDKok9Ce",
  "id" : 496015328975933441,
  "created_at" : "2014-08-03 19:30:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417110498, -21.9355363978 ]
  },
  "id_str" : "495991105369157632",
  "text" : "google: bioinformatics positions iceland",
  "id" : 495991105369157632,
  "created_at" : "2014-08-03 17:54:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495965382268964864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417213377, -21.9356132033 ]
  },
  "id_str" : "495965707189104640",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot hala hestur!",
  "id" : 495965707189104640,
  "in_reply_to_status_id" : 495965382268964864,
  "created_at" : "2014-08-03 16:13:33 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iceland",
      "indices" : [ 3, 11 ]
    }, {
      "text" : "icecream",
      "indices" : [ 40, 49 ]
    }, {
      "text" : "omnom",
      "indices" : [ 50, 56 ]
    }, {
      "text" : "foodporn",
      "indices" : [ 57, 66 ]
    }, {
      "text" : "moeffjugedenkeis",
      "indices" : [ 67, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/iIBMhpvLBk",
      "expanded_url" : "http:\/\/instagram.com\/p\/rPgKR1hwkk\/",
      "display_url" : "instagram.com\/p\/rPgKR1hwkk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "495963959178977281",
  "text" : "In #iceland even the ice cream is lava! #icecream #omnom #foodporn #moeffjugedenkeis http:\/\/t.co\/iIBMhpvLBk",
  "id" : 495963959178977281,
  "created_at" : "2014-08-03 16:06:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495927084444028928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417008552, -21.9354892645 ]
  },
  "id_str" : "495927220750548993",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 cool, das fehlt in der tat noch, dann w\u00FCrde ich deshalb mal vorbeikommen.",
  "id" : 495927220750548993,
  "in_reply_to_status_id" : 495927084444028928,
  "created_at" : "2014-08-03 13:40:37 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 38, 44 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495919895792861184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417003225, -21.9354784522 ]
  },
  "id_str" : "495920312694079488",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 danke. Ich wollte den Mac von @Lobot nehmen um meinen als Slave dranzufh\u00E4ngen, mein Zeug auf externe HDD &amp; dann meine interne wipen.",
  "id" : 495920312694079488,
  "in_reply_to_status_id" : 495919895792861184,
  "created_at" : "2014-08-03 13:13:10 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495900004226457601",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1416998093, -21.935494268 ]
  },
  "id_str" : "495900322531794944",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 danke, du hast nicht zuf\u00E4llig Erfahrung mit dem Target Disk Mode, oder?",
  "id" : 495900322531794944,
  "in_reply_to_status_id" : 495900004226457601,
  "created_at" : "2014-08-03 11:53:44 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495899185754148864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1416998093, -21.935494268 ]
  },
  "id_str" : "495899310140424192",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 keine Ahnung, ist am Freitag des Abflugs nach Island passiert.",
  "id" : 495899310140424192,
  "in_reply_to_status_id" : 495899185754148864,
  "created_at" : "2014-08-03 11:49:43 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495899125981151232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1416998093, -21.935494268 ]
  },
  "id_str" : "495899182075752450",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 ebenfalls iMovie.",
  "id" : 495899182075752450,
  "in_reply_to_status_id" : 495899125981151232,
  "created_at" : "2014-08-03 11:49:13 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495898959354007552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1416994198, -21.9354984614 ]
  },
  "id_str" : "495899116623630336",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 Ich hab nur zur Zeit keinen Rechner weil die HDD in meinem Macbook defekt ist.",
  "id" : 495899116623630336,
  "in_reply_to_status_id" : 495898959354007552,
  "created_at" : "2014-08-03 11:48:57 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495898478971596801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1416994198, -21.9354984614 ]
  },
  "id_str" : "495898790545879041",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 aufgenommen mit Quicktime, geschnitten in iMovie.",
  "id" : 495898790545879041,
  "in_reply_to_status_id" : 495898478971596801,
  "created_at" : "2014-08-03 11:47:39 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495898116290523136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1416994198, -21.9354984614 ]
  },
  "id_str" : "495898717946642432",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 du h\u00E4ttest es vermutlich auch nicht mit iMovie auf einem iPad mini geschnitten. ;)",
  "id" : 495898717946642432,
  "in_reply_to_status_id" : 495898116290523136,
  "created_at" : "2014-08-03 11:47:22 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 8, 15 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iceland",
      "indices" : [ 75, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/fVS7XJ35to",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=uze0ZaGA_w8",
      "display_url" : "m.youtube.com\/watch?v=uze0Za\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1416994198, -21.9354984614 ]
  },
  "id_str" : "495897129794433024",
  "text" : "Hab den @Seb666 gemacht und ein Video geschnitten! https:\/\/t.co\/fVS7XJ35to #iceland",
  "id" : 495897129794433024,
  "created_at" : "2014-08-03 11:41:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitzwilliam Darcy",
      "screen_name" : "FtzwilliamDarcy",
      "indices" : [ 3, 19 ],
      "id_str" : "872329956",
      "id" : 872329956
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FtzwilliamDarcy\/status\/495508741836775424\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/Ldbjhk4ukB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuBmkqNIgAAYy_R.jpg",
      "id_str" : "495508739001450496",
      "id" : 495508739001450496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuBmkqNIgAAYy_R.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Ldbjhk4ukB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495858174055165952",
  "text" : "RT @FtzwilliamDarcy: 1A-Karton, topp Zustand, beste Lage. http:\/\/t.co\/Ldbjhk4ukB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FtzwilliamDarcy\/status\/495508741836775424\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/Ldbjhk4ukB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BuBmkqNIgAAYy_R.jpg",
        "id_str" : "495508739001450496",
        "id" : 495508739001450496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuBmkqNIgAAYy_R.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/Ldbjhk4ukB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "495508741836775424",
    "text" : "1A-Karton, topp Zustand, beste Lage. http:\/\/t.co\/Ldbjhk4ukB",
    "id" : 495508741836775424,
    "created_at" : "2014-08-02 09:57:44 +0000",
    "user" : {
      "name" : "Fitzwilliam Darcy",
      "screen_name" : "FtzwilliamDarcy",
      "protected" : false,
      "id_str" : "872329956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000400227784\/d9bab2ccb1c84180a83841325c257640_normal.jpeg",
      "id" : 872329956,
      "verified" : false
    }
  },
  "id" : 495858174055165952,
  "created_at" : "2014-08-03 09:06:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "followerpower",
      "indices" : [ 86, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417015793, -21.9354970478 ]
  },
  "id_str" : "495857208220221441",
  "text" : "Wieviele Tonnen Schokolade darf man als Privatperson eigentlich aus Island ausf\u00FChren? #followerpower",
  "id" : 495857208220221441,
  "created_at" : "2014-08-03 09:02:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iceland",
      "indices" : [ 79, 87 ]
    }, {
      "text" : "laugavegur",
      "indices" : [ 88, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/TLiXv5BESd",
      "expanded_url" : "http:\/\/instagram.com\/p\/rOo1WxBwmi\/",
      "display_url" : "instagram.com\/p\/rOo1WxBwmi\/"
    } ]
  },
  "geo" : { },
  "id_str" : "495842293518045184",
  "text" : "And another waterfall: standing at the bottom of Sk\u00F3gafoss made me soaking wet #iceland #laugavegur\u2026 http:\/\/t.co\/TLiXv5BESd",
  "id" : 495842293518045184,
  "created_at" : "2014-08-03 08:03:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1416998103, -21.9354866386 ]
  },
  "id_str" : "495739234175942658",
  "text" : "\u00ABWer ist den hier der Ern\u00E4hrungshitler. Mit Hakenkreuzen aus Sellerie als Wappen!\u00BB \u2013 \u00ABAber ich bin allergisch gegen Sellerie!\u00BB",
  "id" : 495739234175942658,
  "created_at" : "2014-08-03 01:13:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1416987576, -21.9355279312 ]
  },
  "id_str" : "495724437921357824",
  "text" : "\u00ABH\u00E4tten wir uns gerade fast getrennt weil ich die Remoulade nicht zur\u00FCck in den K\u00FChlschrank gestellt habe?\u00BB\u2014\u00ABUnd die Preiselbeermarmelade!\u00BB",
  "id" : 495724437921357824,
  "created_at" : "2014-08-03 00:14:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Margaret Smith",
      "screen_name" : "DrMobs",
      "indices" : [ 3, 10 ],
      "id_str" : "24493624",
      "id" : 24493624
    }, {
      "name" : "Ewan St. John Smith",
      "screen_name" : "psalmotoxin",
      "indices" : [ 23, 35 ],
      "id_str" : "77555604",
      "id" : 77555604
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495685888165548032",
  "text" : "RT @DrMobs: Me too. RT @psalmotoxin: I'm usually predictable, but sometimes, obsessive compulsive going by this table #science http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ewan St. John Smith",
        "screen_name" : "psalmotoxin",
        "indices" : [ 11, 23 ],
        "id_str" : "77555604",
        "id" : 77555604
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/psalmotoxin\/status\/495630254267187200\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/XNqZ2USRnN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BuDVFr0IYAA4kAC.jpg",
        "id_str" : "495630252648194048",
        "id" : 495630252648194048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuDVFr0IYAA4kAC.jpg",
        "sizes" : [ {
          "h" : 709,
          "resize" : "fit",
          "w" : 586
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 709,
          "resize" : "fit",
          "w" : 586
        }, {
          "h" : 709,
          "resize" : "fit",
          "w" : 586
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 562
        } ],
        "display_url" : "pic.twitter.com\/XNqZ2USRnN"
      } ],
      "hashtags" : [ {
        "text" : "science",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "495663008886968320",
    "text" : "Me too. RT @psalmotoxin: I'm usually predictable, but sometimes, obsessive compulsive going by this table #science http:\/\/t.co\/XNqZ2USRnN",
    "id" : 495663008886968320,
    "created_at" : "2014-08-02 20:10:44 +0000",
    "user" : {
      "name" : "Margaret Smith",
      "screen_name" : "DrMobs",
      "protected" : false,
      "id_str" : "24493624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1109624241\/MebyJo_normal.jpg",
      "id" : 24493624,
      "verified" : false
    }
  },
  "id" : 495685888165548032,
  "created_at" : "2014-08-02 21:41:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417000308, -21.9354805818 ]
  },
  "id_str" : "495674272455852032",
  "text" : "Not too surprised about having hiked about 250 km in Iceland (~1\/10 of the distance we covered by car), but having climbed nearly 4 km does.",
  "id" : 495674272455852032,
  "created_at" : "2014-08-02 20:55:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hj\u00F6rleifsh\u00F6f\u00F0i",
      "indices" : [ 48, 63 ]
    }, {
      "text" : "iceland",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/S9Tvnjg3bb",
      "expanded_url" : "http:\/\/instagram.com\/p\/rNSwyChwnT\/",
      "display_url" : "instagram.com\/p\/rNSwyChwnT\/"
    } ]
  },
  "geo" : { },
  "id_str" : "495653020395241472",
  "text" : "View from Hj\u00F6rleifsh\u00F6f\u00F0i with sand-crop circles #Hj\u00F6rleifsh\u00F6f\u00F0i #iceland http:\/\/t.co\/S9Tvnjg3bb",
  "id" : 495653020395241472,
  "created_at" : "2014-08-02 19:31:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/LfMjjI1WyP",
      "expanded_url" : "http:\/\/instagram.com\/p\/rNRNP2BwkP\/",
      "display_url" : "instagram.com\/p\/rNRNP2BwkP\/"
    } ]
  },
  "geo" : { },
  "id_str" : "495649599739404288",
  "text" : "\u00ABAs the river is eating away it's bank quickly you might want to park your car a bit further away.\u00BB http:\/\/t.co\/LfMjjI1WyP",
  "id" : 495649599739404288,
  "created_at" : "2014-08-02 19:17:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iceland",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/PvwWNIjvxV",
      "expanded_url" : "http:\/\/instagram.com\/p\/rNC7ASBwnU\/",
      "display_url" : "instagram.com\/p\/rNC7ASBwnU\/"
    } ]
  },
  "geo" : { },
  "id_str" : "495618187996565504",
  "text" : "Stj\u00F3rnarfoss #iceland http:\/\/t.co\/PvwWNIjvxV",
  "id" : 495618187996565504,
  "created_at" : "2014-08-02 17:12:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/FMHQnyZ807",
      "expanded_url" : "http:\/\/instagram.com\/p\/rNB2OdhwlA\/",
      "display_url" : "instagram.com\/p\/rNB2OdhwlA\/"
    } ]
  },
  "geo" : { },
  "id_str" : "495615824800272384",
  "text" : "\u00ABDer Boden ist Lava. Und geht echt schwer wieder von den Schuhen ab!\u00BB http:\/\/t.co\/FMHQnyZ807",
  "id" : 495615824800272384,
  "created_at" : "2014-08-02 17:03:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 6, 12 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iceland",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/Dbru3Fq2l9",
      "expanded_url" : "http:\/\/instagram.com\/p\/rNAotxBwix\/",
      "display_url" : "instagram.com\/p\/rNAotxBwix\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417012341, -21.9354951148 ]
  },
  "id_str" : "495613338462982145",
  "text" : "Well, @Lobot told me that this would be the latest fad in #iceland http:\/\/t.co\/Dbru3Fq2l9",
  "id" : 495613338462982145,
  "created_at" : "2014-08-02 16:53:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1416989133, -21.9355008608 ]
  },
  "id_str" : "495609016371150848",
  "text" : "\u00ABHat der dich gerade angebaggert?\u00BB \u2013 \u00ABJa, ich glaube er wollte mir auf isl\u00E4ndisch mitteilen das er some hot beard-on-beard action will.\u00BB",
  "id" : 495609016371150848,
  "created_at" : "2014-08-02 16:36:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Sweeney",
      "screen_name" : "sween",
      "indices" : [ 3, 9 ],
      "id_str" : "9930742",
      "id" : 9930742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495607372497571840",
  "text" : "RT @sween: God: *opens beer*\nJesus: Isn't it a little early for that?\nGod: It's five o'clock somewhere.\nJesus: No, it isn't.\nGod: *creates \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "495216037101850624",
    "text" : "God: *opens beer*\nJesus: Isn't it a little early for that?\nGod: It's five o'clock somewhere.\nJesus: No, it isn't.\nGod: *creates universe*",
    "id" : 495216037101850624,
    "created_at" : "2014-08-01 14:34:38 +0000",
    "user" : {
      "name" : "Jason Sweeney",
      "screen_name" : "sween",
      "protected" : false,
      "id_str" : "9930742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576723767402983424\/xLGkIHkA_normal.jpeg",
      "id" : 9930742,
      "verified" : true
    }
  },
  "id" : 495607372497571840,
  "created_at" : "2014-08-02 16:29:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 100, 113 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/KIaGaRuGUr",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plosone\/PLoSONE\/~3\/g3Y8SVWE-P8\/info%3Adoi%2F10.1371%2Fjournal.pone.0103171",
      "display_url" : "feeds.plos.org\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417, -21.935472 ]
  },
  "id_str" : "495562421076262912",
  "text" : "Two Different Bacterial Community Types Are Linked with the Low-Methane Emission Trait in Sheep \/cc @PhilippBayer  http:\/\/t.co\/KIaGaRuGUr",
  "id" : 495562421076262912,
  "created_at" : "2014-08-02 13:31:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495560218517196800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1416995399, -21.9354772252 ]
  },
  "id_str" : "495561022678503424",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente das wiederum ist etwas ern\u00FCchternd.",
  "id" : 495561022678503424,
  "in_reply_to_status_id" : 495560218517196800,
  "created_at" : "2014-08-02 13:25:29 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 90, 96 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 97, 110 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/L7viNtetIT",
      "expanded_url" : "http:\/\/feeds.plos.org\/~r\/plosone\/PLoSONE\/~3\/0EL7fuLXYy4\/info%3Adoi%2F10.1371%2Fjournal.pone.0102882",
      "display_url" : "feeds.plos.org\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417, -21.935477 ]
  },
  "id_str" : "495560819900710912",
  "text" : "Dynamics in Language: Evidence from Verb Regularity in a Historical Corpus of English \/cc @Lobot @PhilippBayer  http:\/\/t.co\/L7viNtetIT",
  "id" : 495560819900710912,
  "created_at" : "2014-08-02 13:24:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495555400981569536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1416998136, -21.935486903 ]
  },
  "id_str" : "495559663132622849",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente Laguiole!",
  "id" : 495559663132622849,
  "in_reply_to_status_id" : 495555400981569536,
  "created_at" : "2014-08-02 13:20:05 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iceland",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/ZFoI7fxcS4",
      "expanded_url" : "http:\/\/instagram.com\/p\/rMl99Ahwil\/",
      "display_url" : "instagram.com\/p\/rMl99Ahwil\/"
    } ]
  },
  "geo" : { },
  "id_str" : "495554516193132545",
  "text" : "That red thingy could be Cladonia cristatella, but what do I know about lichens in #iceland http:\/\/t.co\/ZFoI7fxcS4",
  "id" : 495554516193132545,
  "created_at" : "2014-08-02 12:59:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/o7KfHk25rz",
      "expanded_url" : "http:\/\/instagram.com\/p\/rMkxu1BwhJ\/",
      "display_url" : "instagram.com\/p\/rMkxu1BwhJ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "495551897986551808",
  "text" : "The grave of Hj\u00F6rleifur Hr\u00F3\u00F0marsson, the 2nd settler of Iceland &amp; killed by his Irish slaves. http:\/\/t.co\/o7KfHk25rz",
  "id" : 495551897986551808,
  "created_at" : "2014-08-02 12:49:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nein.",
      "screen_name" : "NeinQuarterly",
      "indices" : [ 34, 48 ],
      "id_str" : "458966079",
      "id" : 458966079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iceland",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/4i8zOhEl9l",
      "expanded_url" : "http:\/\/instagram.com\/p\/rLXfBahwvR\/",
      "display_url" : "instagram.com\/p\/rLXfBahwvR\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417021327, -21.9354856865 ]
  },
  "id_str" : "495382033011834880",
  "text" : "Die Wandererin \u00FCber dem Lavameer. @NeinQuarterly approves #iceland http:\/\/t.co\/4i8zOhEl9l",
  "id" : 495382033011834880,
  "created_at" : "2014-08-02 01:34:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1487503046, -21.9402275068 ]
  },
  "id_str" : "495349481165299712",
  "text" : "\u00ABSchon lustig, da fliegt man knapp 3000 km um ein Festival zu besuchen was \u00FCbersetzt so viel wie 'Stubenhocker' hei\u00DFt.\u00BB",
  "id" : 495349481165299712,
  "created_at" : "2014-08-01 23:24:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/GwrCT0N1rJ",
      "expanded_url" : "http:\/\/innipukinn.is\/",
      "display_url" : "innipukinn.is"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417027116, -21.9354627369 ]
  },
  "id_str" : "495330518993747969",
  "text" : "Off to Innip\u00FAkinn http:\/\/t.co\/GwrCT0N1rJ",
  "id" : 495330518993747969,
  "created_at" : "2014-08-01 22:09:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iceland",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/2xh7jS3hH3",
      "expanded_url" : "https:\/\/flickr.com\/photos\/79376123@N00\/sets\/72157645692089939",
      "display_url" : "flickr.com\/photos\/7937612\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1416967789, -21.9355075846 ]
  },
  "id_str" : "495327447370715137",
  "text" : "Of course, the professional phone photography hipster also takes panorama pictures. https:\/\/t.co\/2xh7jS3hH3 #iceland",
  "id" : 495327447370715137,
  "created_at" : "2014-08-01 21:57:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel",
      "screen_name" : "sleeksorrow",
      "indices" : [ 0, 12 ],
      "id_str" : "59806323",
      "id" : 59806323
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 13, 19 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495311890101190656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1416984463, -21.9355092915 ]
  },
  "id_str" : "495320448679555072",
  "in_reply_to_user_id" : 59806323,
  "text" : "@sleeksorrow @Lobot aber mit gesunden Z\u00E4hnen!",
  "id" : 495320448679555072,
  "in_reply_to_status_id" : 495311890101190656,
  "created_at" : "2014-08-01 21:29:32 +0000",
  "in_reply_to_screen_name" : "sleeksorrow",
  "in_reply_to_user_id_str" : "59806323",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "snufkin",
      "screen_name" : "frandevol",
      "indices" : [ 0, 10 ],
      "id_str" : "14626248",
      "id" : 14626248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495299574899429376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1416998604, -21.935486253 ]
  },
  "id_str" : "495302506252361728",
  "in_reply_to_user_id" : 14626248,
  "text" : "@frandevol Ja, viel Spass damit. Bzw. Erfolg f\u00FCr die Sch\u00FClerInnen :)",
  "id" : 495302506252361728,
  "in_reply_to_status_id" : 495299574899429376,
  "created_at" : "2014-08-01 20:18:14 +0000",
  "in_reply_to_screen_name" : "frandevol",
  "in_reply_to_user_id_str" : "14626248",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "snufkin",
      "screen_name" : "frandevol",
      "indices" : [ 0, 10 ],
      "id_str" : "14626248",
      "id" : 14626248
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/495298126023258112\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/NFHVNJM9XZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt-nBVGIMAAeQZq.jpg",
      "id_str" : "495298125318598656",
      "id" : 495298125318598656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt-nBVGIMAAeQZq.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/NFHVNJM9XZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495293760113487873",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.1417472213, -21.9355849315 ]
  },
  "id_str" : "495298126023258112",
  "in_reply_to_user_id" : 14626248,
  "text" : "@frandevol ah, ich wusste ja den Zweck nicht. Dann auch hier gern ein zweites. http:\/\/t.co\/NFHVNJM9XZ",
  "id" : 495298126023258112,
  "in_reply_to_status_id" : 495293760113487873,
  "created_at" : "2014-08-01 20:00:50 +0000",
  "in_reply_to_screen_name" : "frandevol",
  "in_reply_to_user_id_str" : "14626248",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495288517392863232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.14172057, -21.9357302206 ]
  },
  "id_str" : "495291046130352129",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot don't forget to f[l]oss your teeth!",
  "id" : 495291046130352129,
  "in_reply_to_status_id" : 495288517392863232,
  "created_at" : "2014-08-01 19:32:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "snufkin",
      "screen_name" : "frandevol",
      "indices" : [ 0, 10 ],
      "id_str" : "14626248",
      "id" : 14626248
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/495290662305423360\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/93dPxYWoTE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt-gOrwCMAEoAeT.jpg",
      "id_str" : "495290658156851201",
      "id" : 495290658156851201,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt-gOrwCMAEoAeT.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/93dPxYWoTE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "495288428935016448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 64.14172057, -21.9357302206 ]
  },
  "id_str" : "495290662305423360",
  "in_reply_to_user_id" : 14626248,
  "text" : "@frandevol bitte sehr, ist das Standardmotiv vor Ort. Nach Reynisdrangar googlen liefert auch jede Menge. :) http:\/\/t.co\/93dPxYWoTE",
  "id" : 495290662305423360,
  "in_reply_to_status_id" : 495288428935016448,
  "created_at" : "2014-08-01 19:31:10 +0000",
  "in_reply_to_screen_name" : "frandevol",
  "in_reply_to_user_id_str" : "14626248",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iceland",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/WEsaj2kpkC",
      "expanded_url" : "http:\/\/instagram.com\/p\/rKtuvBBwp2\/",
      "display_url" : "instagram.com\/p\/rKtuvBBwp2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "495290110804385793",
  "text" : "One more time at J\u00F6kuls\u00E1rl\u00F3n #iceland http:\/\/t.co\/WEsaj2kpkC",
  "id" : 495290110804385793,
  "created_at" : "2014-08-01 19:28:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/18vewhGb8M",
      "expanded_url" : "http:\/\/instagram.com\/p\/rKsIP2hwm2\/",
      "display_url" : "instagram.com\/p\/rKsIP2hwm2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "495286589287718912",
  "text" : "Basalt at Reynisdrangar http:\/\/t.co\/18vewhGb8M",
  "id" : 495286589287718912,
  "created_at" : "2014-08-01 19:14:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iceland",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/SIHpWKFNPQ",
      "expanded_url" : "http:\/\/instagram.com\/p\/rKUXGrBwt3\/",
      "display_url" : "instagram.com\/p\/rKUXGrBwt3\/"
    } ]
  },
  "geo" : { },
  "id_str" : "495234324430471168",
  "text" : "Another random roadside view #iceland http:\/\/t.co\/SIHpWKFNPQ",
  "id" : 495234324430471168,
  "created_at" : "2014-08-01 15:47:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iceland",
      "indices" : [ 84, 92 ]
    }, {
      "text" : "latergram",
      "indices" : [ 93, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/LfHzXotIxr",
      "expanded_url" : "http:\/\/instagram.com\/p\/rKTPX8hwrv\/",
      "display_url" : "instagram.com\/p\/rKTPX8hwrv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "495231858440155136",
  "text" : "After a failed attempt to get onto Vatnaj\u00F6kull at J\u00F6kuls\u00E1rl\u00F3n we went to Brei\u00F0\u00E1rl\u00F3n #iceland #latergram http:\/\/t.co\/LfHzXotIxr",
  "id" : 495231858440155136,
  "created_at" : "2014-08-01 15:37:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/Ou01SdgqGo",
      "expanded_url" : "http:\/\/instagram.com\/p\/rKSrjOBwqq\/",
      "display_url" : "instagram.com\/p\/rKSrjOBwqq\/"
    } ]
  },
  "geo" : { },
  "id_str" : "495230627244150785",
  "text" : "Vatnaj\u00F6kull II http:\/\/t.co\/Ou01SdgqGo",
  "id" : 495230627244150785,
  "created_at" : "2014-08-01 15:32:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iceland",
      "indices" : [ 12, 20 ]
    }, {
      "text" : "glacier",
      "indices" : [ 21, 29 ]
    }, {
      "text" : "latergram",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/afhqTRi0qZ",
      "expanded_url" : "http:\/\/instagram.com\/p\/rJ16dpBwuC\/",
      "display_url" : "instagram.com\/p\/rJ16dpBwuC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "495167367950106625",
  "text" : "Vatnaj\u00F6kull #iceland #glacier #latergram http:\/\/t.co\/afhqTRi0qZ",
  "id" : 495167367950106625,
  "created_at" : "2014-08-01 11:21:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iceland",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/kLNbRP1guO",
      "expanded_url" : "http:\/\/instagram.com\/p\/rJr3mRBwh5\/",
      "display_url" : "instagram.com\/p\/rJr3mRBwh5\/"
    } ]
  },
  "geo" : { },
  "id_str" : "495145279117856768",
  "text" : "Graffiti in the middle of nowhere on an abandoned farm #iceland http:\/\/t.co\/kLNbRP1guO",
  "id" : 495145279117856768,
  "created_at" : "2014-08-01 09:53:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iceland",
      "indices" : [ 19, 27 ]
    }, {
      "text" : "hoefn",
      "indices" : [ 28, 34 ]
    }, {
      "text" : "latergram",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/Ex2C7H3yQg",
      "expanded_url" : "http:\/\/instagram.com\/p\/rJnKvThwrT\/",
      "display_url" : "instagram.com\/p\/rJnKvThwrT\/"
    } ]
  },
  "geo" : { },
  "id_str" : "495134943308034049",
  "text" : "Dirt road evidence #iceland #hoefn #latergram http:\/\/t.co\/Ex2C7H3yQg",
  "id" : 495134943308034049,
  "created_at" : "2014-08-01 09:12:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]