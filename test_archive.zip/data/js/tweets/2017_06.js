Grailbird.data.tweets_2017_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "880898946591281152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399035760012, 8.753325641411706 ]
  },
  "id_str" : "880899168218296320",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABBut what kind of Gods are we? Gods who survey their toxic, murderous garden with satellites yet know neither what they themselves are\u2026\u00BB \uD83D\uDC96\uD83D\uDE31",
  "id" : 880899168218296320,
  "in_reply_to_status_id" : 880898946591281152,
  "created_at" : "2017-06-30 21:21:42 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 88, 98 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/mfwinWj2MZ",
      "expanded_url" : "http:\/\/atlas-for-the-end-of-the-world.com\/",
      "display_url" : "atlas-for-the-end-of-the-world.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399035760012, 8.753325641411706 ]
  },
  "id_str" : "880898946591281152",
  "text" : "This is an awesome page: The Atlas for the End of the World. https:\/\/t.co\/mfwinWj2MZ HT @auremoser",
  "id" : 880898946591281152,
  "created_at" : "2017-06-30 21:20:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S.P. Mohanty",
      "screen_name" : "MeMohanty",
      "indices" : [ 3, 13 ],
      "id_str" : "381054288",
      "id" : 381054288
    }, {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 41, 50 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/pn9lNffJui",
      "expanded_url" : "https:\/\/github.com\/crowdAI\/opensnp-challenge-starter-kit",
      "display_url" : "github.com\/crowdAI\/opensn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "880826737092952064",
  "text" : "RT @MeMohanty: And And And theres a nice @crowd_ai starter kit for people to quickly get started : https:\/\/t.co\/pn9lNffJui https:\/\/t.co\/a8M\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CrowdAI",
        "screen_name" : "crowd_ai",
        "indices" : [ 26, 35 ],
        "id_str" : "706885331224813568",
        "id" : 706885331224813568
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/pn9lNffJui",
        "expanded_url" : "https:\/\/github.com\/crowdAI\/opensnp-challenge-starter-kit",
        "display_url" : "github.com\/crowdAI\/opensn\u2026"
      }, {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/a8M9oBnZBY",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/880821820739518466",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "880826192911364096",
    "text" : "And And And theres a nice @crowd_ai starter kit for people to quickly get started : https:\/\/t.co\/pn9lNffJui https:\/\/t.co\/a8M9oBnZBY",
    "id" : 880826192911364096,
    "created_at" : "2017-06-30 16:31:44 +0000",
    "user" : {
      "name" : "S.P. Mohanty",
      "screen_name" : "MeMohanty",
      "protected" : false,
      "id_str" : "381054288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567604474324066304\/050U5CeN_normal.jpeg",
      "id" : 381054288,
      "verified" : false
    }
  },
  "id" : 880826737092952064,
  "created_at" : "2017-06-30 16:33:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 11, 20 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "880824509783318528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11390866626294, 8.753238494999549 ]
  },
  "id_str" : "880824800842743809",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @crowd_ai Nah, I think worst is like every month if the mails cluster and then there\u2019s like a year without hearing from us. \uD83D\uDE02",
  "id" : 880824800842743809,
  "in_reply_to_status_id" : 880824509783318528,
  "created_at" : "2017-06-30 16:26:12 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 11, 20 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "880824083868471297",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399568587639, 8.753337697774926 ]
  },
  "id_str" : "880824368640782339",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @crowd_ai Thanks! \uD83D\uDC4D\uD83D\uDE0D",
  "id" : 880824368640782339,
  "in_reply_to_status_id" : 880824083868471297,
  "created_at" : "2017-06-30 16:24:29 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 11, 20 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "880823305430855680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399568587639, 8.753337697774926 ]
  },
  "id_str" : "880823720943726593",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @crowd_ai Ah, gotcha. We send between 1 to 6 newsletters a year to keep the volume down. (And because we\u2019re lazy in writing them)",
  "id" : 880823720943726593,
  "in_reply_to_status_id" : 880823305430855680,
  "created_at" : "2017-06-30 16:21:54 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 11, 20 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "880822380951719936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140086680212, 8.753359489135873 ]
  },
  "id_str" : "880822862386475008",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @crowd_ai Did you disable our newsletter? :)",
  "id" : 880822862386475008,
  "in_reply_to_status_id" : 880822380951719936,
  "created_at" : "2017-06-30 16:18:29 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 11, 20 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "880822380951719936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140086680212, 8.753359489135873 ]
  },
  "id_str" : "880822822809030656",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @crowd_ai We sent out a survey to everyone, at least two times. But that was a while back.",
  "id" : 880822822809030656,
  "in_reply_to_status_id" : 880822380951719936,
  "created_at" : "2017-06-30 16:18:20 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 144, 167 ],
      "url" : "https:\/\/t.co\/B9C6S9boPj",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/880821302193528837",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "880821302193528837",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11386286937642, 8.75338132494013 ]
  },
  "id_str" : "880821820739518466",
  "in_reply_to_user_id" : 14286491,
  "text" : "The winners are invited to an expenses-covered trip to the 2nd Applied Machine Learning Days at EPFL in Switzerland, January 29 &amp; 30, 2018. https:\/\/t.co\/B9C6S9boPj",
  "id" : 880821820739518466,
  "in_reply_to_status_id" : 880821302193528837,
  "created_at" : "2017-06-30 16:14:21 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S.P. Mohanty",
      "screen_name" : "MeMohanty",
      "indices" : [ 0, 10 ],
      "id_str" : "381054288",
      "id" : 381054288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "880814181439729664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11386286937642, 8.75338132494013 ]
  },
  "id_str" : "880821363459604480",
  "in_reply_to_user_id" : 381054288,
  "text" : "@MeMohanty Awesome, thanks!",
  "id" : 880821363459604480,
  "in_reply_to_status_id" : 880814181439729664,
  "created_at" : "2017-06-30 16:12:32 +0000",
  "in_reply_to_screen_name" : "MeMohanty",
  "in_reply_to_user_id_str" : "381054288",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 74, 83 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/YfyGfBWbxF",
      "expanded_url" : "https:\/\/www.crowdai.org\/challenges\/opensnp-height-prediction",
      "display_url" : "crowdai.org\/challenges\/ope\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11384572648722, 8.753290449616323 ]
  },
  "id_str" : "880821302193528837",
  "text" : "Parts of the openSNP data are now part of a machine learning challenge on @crowd_ai: Predict height from genotypes \uD83C\uDF89 https:\/\/t.co\/YfyGfBWbxF",
  "id" : 880821302193528837,
  "created_at" : "2017-06-30 16:12:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anson W. Mackay",
      "screen_name" : "AnsonMackay",
      "indices" : [ 0, 12 ],
      "id_str" : "18426460",
      "id" : 18426460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "880773751582883841",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11410740628369, 8.753318737457795 ]
  },
  "id_str" : "880774878055600128",
  "in_reply_to_user_id" : 18426460,
  "text" : "@AnsonMackay Tell me about it, in this household no one is getting more attention than the cats \uD83D\uDE02",
  "id" : 880774878055600128,
  "in_reply_to_status_id" : 880773751582883841,
  "created_at" : "2017-06-30 13:07:49 +0000",
  "in_reply_to_screen_name" : "AnsonMackay",
  "in_reply_to_user_id_str" : "18426460",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anson W. Mackay",
      "screen_name" : "AnsonMackay",
      "indices" : [ 0, 12 ],
      "id_str" : "18426460",
      "id" : 18426460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "880731251098910720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392699925026, 8.753096149382595 ]
  },
  "id_str" : "880771862439088128",
  "in_reply_to_user_id" : 18426460,
  "text" : "@AnsonMackay Looks super ready for belly rubs! \uD83D\uDE02",
  "id" : 880771862439088128,
  "in_reply_to_status_id" : 880731251098910720,
  "created_at" : "2017-06-30 12:55:50 +0000",
  "in_reply_to_screen_name" : "AnsonMackay",
  "in_reply_to_user_id_str" : "18426460",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NumFOCUS",
      "screen_name" : "NumFOCUS",
      "indices" : [ 3, 12 ],
      "id_str" : "1068951084",
      "id" : 1068951084
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NumFOCUS\/status\/879786596739850240\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/xt1HG1pyIs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DDWhPukUIAUzc-n.jpg",
      "id_str" : "879786593791254533",
      "id" : 879786593791254533,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DDWhPukUIAUzc-n.jpg",
      "sizes" : [ {
        "h" : 382,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 639
      } ],
      "display_url" : "pic.twitter.com\/xt1HG1pyIs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/4NTfoJPPft",
      "expanded_url" : "https:\/\/www.numfocus.org\/blog\/why-is-numpy-only-now-getting-funded\/",
      "display_url" : "numfocus.org\/blog\/why-is-nu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "880715903884812289",
  "text" : "RT @NumFOCUS: Why Is NumPy Only Now Getting\u00A0Funded? https:\/\/t.co\/4NTfoJPPft https:\/\/t.co\/xt1HG1pyIs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NumFOCUS\/status\/879786596739850240\/photo\/1",
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/xt1HG1pyIs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DDWhPukUIAUzc-n.jpg",
        "id_str" : "879786593791254533",
        "id" : 879786593791254533,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DDWhPukUIAUzc-n.jpg",
        "sizes" : [ {
          "h" : 382,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 639
        } ],
        "display_url" : "pic.twitter.com\/xt1HG1pyIs"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/4NTfoJPPft",
        "expanded_url" : "https:\/\/www.numfocus.org\/blog\/why-is-numpy-only-now-getting-funded\/",
        "display_url" : "numfocus.org\/blog\/why-is-nu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "879786596739850240",
    "text" : "Why Is NumPy Only Now Getting\u00A0Funded? https:\/\/t.co\/4NTfoJPPft https:\/\/t.co\/xt1HG1pyIs",
    "id" : 879786596739850240,
    "created_at" : "2017-06-27 19:40:44 +0000",
    "user" : {
      "name" : "NumFOCUS",
      "screen_name" : "NumFOCUS",
      "protected" : false,
      "id_str" : "1068951084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882723198818590720\/LH034Czl_normal.jpg",
      "id" : 1068951084,
      "verified" : false
    }
  },
  "id" : 880715903884812289,
  "created_at" : "2017-06-30 09:13:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anson W. Mackay",
      "screen_name" : "AnsonMackay",
      "indices" : [ 0, 12 ],
      "id_str" : "18426460",
      "id" : 18426460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "880698302026612736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139216439479, 8.753457706794423 ]
  },
  "id_str" : "880699826572275713",
  "in_reply_to_user_id" : 18426460,
  "text" : "@AnsonMackay And \uD83D\uDE0D that\u2019s such a cool avatar, who\u2019s the cute guy in it? (The canine that is \uD83D\uDE0B)",
  "id" : 880699826572275713,
  "in_reply_to_status_id" : 880698302026612736,
  "created_at" : "2017-06-30 08:09:35 +0000",
  "in_reply_to_screen_name" : "AnsonMackay",
  "in_reply_to_user_id_str" : "18426460",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anson W. Mackay",
      "screen_name" : "AnsonMackay",
      "indices" : [ 0, 12 ],
      "id_str" : "18426460",
      "id" : 18426460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "880698302026612736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139216439479, 8.753457706794423 ]
  },
  "id_str" : "880699450548727808",
  "in_reply_to_user_id" : 18426460,
  "text" : "@AnsonMackay Yeah that took some time. And it\u2019s hard to not be cynical and see this as just a pre-election move to gain support before September.",
  "id" : 880699450548727808,
  "in_reply_to_status_id" : 880698302026612736,
  "created_at" : "2017-06-30 08:08:06 +0000",
  "in_reply_to_screen_name" : "AnsonMackay",
  "in_reply_to_user_id_str" : "18426460",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/j5TcOFR3xx",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Same-sex_marriage#\/media\/File%3AWorld_marriage-equality_laws.svg",
      "display_url" : "en.m.wikipedia.org\/wiki\/Same-sex_\u2026"
    }, {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/Q7ngyF4CHf",
      "expanded_url" : "https:\/\/twitter.com\/haaretzcom\/status\/880691669724790784",
      "display_url" : "twitter.com\/haaretzcom\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398895646374, 8.753327205038886 ]
  },
  "id_str" : "880694493648998405",
  "text" : "Germany finally joined a good number of its neighbors in making same-sex marriages legal. \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08 https:\/\/t.co\/j5TcOFR3xx https:\/\/t.co\/Q7ngyF4CHf",
  "id" : 880694493648998405,
  "created_at" : "2017-06-30 07:48:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InformedConsent",
      "indices" : [ 29, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/qnZXunZCTt",
      "expanded_url" : "http:\/\/www.tandfonline.com\/doi\/full\/10.1080\/15265161.2017.1328532#.WVVgWR8WhNQ.twitter",
      "display_url" : "tandfonline.com\/doi\/full\/10.10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "880676271415582720",
  "text" : "RT @EffyVayena: Our comment: #InformedConsent &amp; the Disclosure of Clinical Results to Research Participants https:\/\/t.co\/qnZXunZCTt @a_blas\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alessandro Blasimme",
        "screen_name" : "a_blasimme",
        "indices" : [ 120, 131 ],
        "id_str" : "51029208",
        "id" : 51029208
      }, {
        "name" : "Samia Hurst",
        "screen_name" : "samiahurst",
        "indices" : [ 132, 143 ],
        "id_str" : "40063747",
        "id" : 40063747
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InformedConsent",
        "indices" : [ 13, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/qnZXunZCTt",
        "expanded_url" : "http:\/\/www.tandfonline.com\/doi\/full\/10.1080\/15265161.2017.1328532#.WVVgWR8WhNQ.twitter",
        "display_url" : "tandfonline.com\/doi\/full\/10.10\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "880521245510561792",
    "text" : "Our comment: #InformedConsent &amp; the Disclosure of Clinical Results to Research Participants https:\/\/t.co\/qnZXunZCTt @a_blasimme @samiahurst",
    "id" : 880521245510561792,
    "created_at" : "2017-06-29 20:19:58 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 880676271415582720,
  "created_at" : "2017-06-30 06:35:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Whitehead",
      "screen_name" : "Mikey_Whitehead",
      "indices" : [ 3, 19 ],
      "id_str" : "25774136",
      "id" : 25774136
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 100, 116 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "880674771423375360",
  "text" : "RT @Mikey_Whitehead: Elsevier victory says our research is their property (with choice quotes from \n@gedankenstuecke) https:\/\/t.co\/O9kC5Ofz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 79, 95 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scihub",
        "indices" : [ 121, 128 ]
      }, {
        "text" : "openaccess",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/O9kC5OfzVe",
        "expanded_url" : "https:\/\/www.timeshighereducation.com\/news\/elsevier-victory-over-sci-hub-shows-research-corporate-asset",
        "display_url" : "timeshighereducation.com\/news\/elsevier-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "880573589002506240",
    "text" : "Elsevier victory says our research is their property (with choice quotes from \n@gedankenstuecke) https:\/\/t.co\/O9kC5OfzVe #scihub #openaccess",
    "id" : 880573589002506240,
    "created_at" : "2017-06-29 23:47:58 +0000",
    "user" : {
      "name" : "Michael Whitehead",
      "screen_name" : "Mikey_Whitehead",
      "protected" : false,
      "id_str" : "25774136",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816073886320107520\/j1q-F5oE_normal.jpg",
      "id" : 25774136,
      "verified" : false
    }
  },
  "id" : 880674771423375360,
  "created_at" : "2017-06-30 06:30:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/b5Fe6I4Yvc",
      "expanded_url" : "http:\/\/www.cibiv.at\/software\/treesnatcher\/",
      "display_url" : "cibiv.at\/software\/trees\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "880523062415896577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399061883424, 8.753327349136253 ]
  },
  "id_str" : "880530963989647360",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai always wondered whether there\u2019s an OSS alternative to this that\u2019s still developed. https:\/\/t.co\/b5Fe6I4Yvc",
  "id" : 880530963989647360,
  "in_reply_to_status_id" : 880523062415896577,
  "created_at" : "2017-06-29 20:58:35 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    }, {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 15, 24 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 25, 36 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "880392865771335681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11387802940747, 8.753216539116893 ]
  },
  "id_str" : "880496862641483778",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe @crowd_ai @openSNPorg Are the few hours over already? \uD83D\uDE0D\uD83D\uDE02",
  "id" : 880496862641483778,
  "in_reply_to_status_id" : 880392865771335681,
  "created_at" : "2017-06-29 18:43:05 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 10, 20 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 21, 36 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "880496218048126976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11387802940747, 8.753216539116893 ]
  },
  "id_str" : "880496533208264704",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @blahah404 @MozillaScience And where can I get one? \uD83D\uDE02",
  "id" : 880496533208264704,
  "in_reply_to_status_id" : 880496218048126976,
  "created_at" : "2017-06-29 18:41:47 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/880417435224076288\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/iU8V9kHNmK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DDfe_PCWsAMowoG.png",
      "id_str" : "880417430123753475",
      "id" : 880417430123753475,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DDfe_PCWsAMowoG.png",
      "sizes" : [ {
        "h" : 780,
        "resize" : "fit",
        "w" : 732
      }, {
        "h" : 780,
        "resize" : "fit",
        "w" : 732
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 780,
        "resize" : "fit",
        "w" : 732
      } ],
      "display_url" : "pic.twitter.com\/iU8V9kHNmK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234300860213, 8.627509742990839 ]
  },
  "id_str" : "880417435224076288",
  "text" : "How much does the openSNP population sleep in a given 24h window? (n=114) https:\/\/t.co\/iU8V9kHNmK",
  "id" : 880417435224076288,
  "created_at" : "2017-06-29 13:27:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/WkTPCzT9sj",
      "expanded_url" : "https:\/\/twitter.com\/marcelsalathe\/status\/880392865771335681",
      "display_url" : "twitter.com\/marcelsalathe\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240280367937, 8.627456024926616 ]
  },
  "id_str" : "880393527619923969",
  "text" : "You like to fiddle with machine learning and open genetics data? This will be for you! https:\/\/t.co\/WkTPCzT9sj",
  "id" : 880393527619923969,
  "created_at" : "2017-06-29 11:52:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Markie",
      "screen_name" : "MMMarksman",
      "indices" : [ 3, 14 ],
      "id_str" : "237650650",
      "id" : 237650650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "880169384127455232",
  "text" : "RT @MMMarksman: We've published some cool software tools recently, and we want more! Read our latest blog to see what's going on: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/6Y5YFLuk1q",
        "expanded_url" : "https:\/\/blog.f1000.com\/2017\/06\/28\/show-me-the-code\/",
        "display_url" : "blog.f1000.com\/2017\/06\/28\/sho\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "880132690497982464",
    "text" : "We've published some cool software tools recently, and we want more! Read our latest blog to see what's going on: https:\/\/t.co\/6Y5YFLuk1q",
    "id" : 880132690497982464,
    "created_at" : "2017-06-28 18:36:00 +0000",
    "user" : {
      "name" : "Michael Markie",
      "screen_name" : "MMMarksman",
      "protected" : false,
      "id_str" : "237650650",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/909811703264800769\/3eUaFf-V_normal.jpg",
      "id" : 237650650,
      "verified" : false
    }
  },
  "id" : 880169384127455232,
  "created_at" : "2017-06-28 21:01:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/R9kqVQ4IDS",
      "expanded_url" : "https:\/\/twitter.com\/lorrainechu3n\/status\/880145273565196288",
      "display_url" : "twitter.com\/lorrainechu3n\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392201525155, 8.753461720223532 ]
  },
  "id_str" : "880159553563893764",
  "text" : "Signed! https:\/\/t.co\/R9kqVQ4IDS",
  "id" : 880159553563893764,
  "created_at" : "2017-06-28 20:22:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 3, 17 ],
      "id_str" : "257319757",
      "id" : 257319757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "880159300672516096",
  "text" : "RT @lorrainechu3n: Oooh, a pledge for male speakers not be part of all-male panels! also\u2014ask yourself if there are POCs on the panel. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/rdlg3oLj4o",
        "expanded_url" : "http:\/\/www.owen.org\/pledge",
        "display_url" : "owen.org\/pledge"
      } ]
    },
    "geo" : { },
    "id_str" : "880145273565196288",
    "text" : "Oooh, a pledge for male speakers not be part of all-male panels! also\u2014ask yourself if there are POCs on the panel. https:\/\/t.co\/rdlg3oLj4o",
    "id" : 880145273565196288,
    "created_at" : "2017-06-28 19:26:00 +0000",
    "user" : {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "protected" : false,
      "id_str" : "257319757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926996461719621632\/aBq5xtJy_normal.jpg",
      "id" : 257319757,
      "verified" : false
    }
  },
  "id" : 880159300672516096,
  "created_at" : "2017-06-28 20:21:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 3, 18 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 98, 114 ],
      "id_str" : "383289779",
      "id" : 383289779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 43, 50 ]
    }, {
      "text" : "mozfellows",
      "indices" : [ 71, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/jBjyfIiagy",
      "expanded_url" : "https:\/\/science.mozilla.org\/blog\/fellows-south-africa-2017\/",
      "display_url" : "science.mozilla.org\/blog\/fellows-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "880144060308230145",
  "text" : "RT @MozillaScience: Inspiring recap of our #mozwow in South Africa and #mozfellows offboarding by @daniellecrobins:  https:\/\/t.co\/jBjyfIiagy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "D Robinson, PhD",
        "screen_name" : "daniellecrobins",
        "indices" : [ 78, 94 ],
        "id_str" : "383289779",
        "id" : 383289779
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mozwow",
        "indices" : [ 23, 30 ]
      }, {
        "text" : "mozfellows",
        "indices" : [ 51, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/jBjyfIiagy",
        "expanded_url" : "https:\/\/science.mozilla.org\/blog\/fellows-south-africa-2017\/",
        "display_url" : "science.mozilla.org\/blog\/fellows-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "880139548583264256",
    "text" : "Inspiring recap of our #mozwow in South Africa and #mozfellows offboarding by @daniellecrobins:  https:\/\/t.co\/jBjyfIiagy",
    "id" : 880139548583264256,
    "created_at" : "2017-06-28 19:03:15 +0000",
    "user" : {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "protected" : false,
      "id_str" : "1428575976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687287790049034240\/lwIk-ZQT_normal.png",
      "id" : 1428575976,
      "verified" : false
    }
  },
  "id" : 880144060308230145,
  "created_at" : "2017-06-28 19:21:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "880123157121835009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399280687139, 8.753332555739735 ]
  },
  "id_str" : "880124075733118977",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABImmediate press release: There\u2019s a website where you can get all of \u2018our\u2019 stuff for free!\u00BB",
  "id" : 880124075733118977,
  "in_reply_to_status_id" : 880123157121835009,
  "created_at" : "2017-06-28 18:01:46 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/tEkniCwxnA",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/880109698334076928",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1138425701042, 8.753412552580178 ]
  },
  "id_str" : "880123157121835009",
  "text" : "Someone else wants to jump on the Streisand-effect bandwagon it seems. https:\/\/t.co\/tEkniCwxnA",
  "id" : 880123157121835009,
  "created_at" : "2017-06-28 17:58:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Singer-Vine",
      "screen_name" : "jsvine",
      "indices" : [ 105, 112 ],
      "id_str" : "261025036",
      "id" : 261025036
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/YQJ1q6NDuv",
      "expanded_url" : "https:\/\/tinyletter.com\/data-is-plural\/letters\/data-is-plural-2017-06-28-edition",
      "display_url" : "tinyletter.com\/data-is-plural\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11373301245423, 8.753516354248196 ]
  },
  "id_str" : "880075827454640128",
  "text" : "So cool, openSNP is featured in the current edition of \u2018Data Is Plural\u2019 (an excellent newsletter) thanks @jsvine! https:\/\/t.co\/YQJ1q6NDuv",
  "id" : 880075827454640128,
  "created_at" : "2017-06-28 14:50:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/p2m8vbih6u",
      "expanded_url" : "https:\/\/www.timeshighereducation.com\/news\/elsevier-victory-over-sci-hub-shows-research-corporate-asset",
      "display_url" : "timeshighereducation.com\/news\/elsevier-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408550213895, 8.753313576550912 ]
  },
  "id_str" : "880070957766979584",
  "text" : "I commented on the Sci-Hub ruling for THE: https:\/\/t.co\/p2m8vbih6u",
  "id" : 880070957766979584,
  "created_at" : "2017-06-28 14:30:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mich\u24D0el\u24D0  Rossini",
      "screen_name" : "mr0ssini",
      "indices" : [ 0, 9 ],
      "id_str" : "161270361",
      "id" : 161270361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "880019543699193856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234157574492, 8.627501956887743 ]
  },
  "id_str" : "880020192314748928",
  "in_reply_to_user_id" : 161270361,
  "text" : "@mr0ssini makes it much more fun to get back to writing!",
  "id" : 880020192314748928,
  "in_reply_to_status_id" : 880019543699193856,
  "created_at" : "2017-06-28 11:08:58 +0000",
  "in_reply_to_screen_name" : "mr0ssini",
  "in_reply_to_user_id_str" : "161270361",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/OPXTNgMXi0",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BV4YeljlDSq\/",
      "display_url" : "instagram.com\/p\/BV4YeljlDSq\/"
    } ]
  },
  "geo" : { },
  "id_str" : "880019696891944960",
  "text" : "Stuck outside in the rain. The students' first reaction is taking dramatic \uD83D\uDCF7 instead of bringing\u2026 https:\/\/t.co\/OPXTNgMXi0",
  "id" : 880019696891944960,
  "created_at" : "2017-06-28 11:07:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/880014630915059712\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/atOVZAV8DA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DDZwnSOXsAEdJOC.jpg",
      "id_str" : "880014597406830593",
      "id" : 880014597406830593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DDZwnSOXsAEdJOC.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/atOVZAV8DA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723277675497, 8.62752471811594 ]
  },
  "id_str" : "880014630915059712",
  "text" : "Came back from lunch and found this under my desk. \uD83D\uDC36 https:\/\/t.co\/atOVZAV8DA",
  "id" : 880014630915059712,
  "created_at" : "2017-06-28 10:46:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/rX5kB80ftV",
      "expanded_url" : "https:\/\/twitter.com\/usefulcharts\/status\/879031424887566336",
      "display_url" : "twitter.com\/usefulcharts\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233650799967, 8.627517736850193 ]
  },
  "id_str" : "880006821863358464",
  "text" : "These are awesome! \uD83D\uDE0D https:\/\/t.co\/rX5kB80ftV",
  "id" : 880006821863358464,
  "created_at" : "2017-06-28 10:15:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 0, 10 ],
      "id_str" : "11385492",
      "id" : 11385492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879936163779301376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17242303588444, 8.627571892001319 ]
  },
  "id_str" : "879999722953605120",
  "in_reply_to_user_id" : 11385492,
  "text" : "@jillemery Are you already writing the grant for this? :p",
  "id" : 879999722953605120,
  "in_reply_to_status_id" : 879936163779301376,
  "created_at" : "2017-06-28 09:47:38 +0000",
  "in_reply_to_screen_name" : "jillemery",
  "in_reply_to_user_id_str" : "11385492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 0, 10 ],
      "id_str" : "11385492",
      "id" : 11385492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879931296889266176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139884937345, 8.753327045138201 ]
  },
  "id_str" : "879935101949419525",
  "in_reply_to_user_id" : 11385492,
  "text" : "@jillemery Wonder what distance measure should be applied. Somehow measure research interests to find \u201Ctopical\u201D distance as opposed to geographical?",
  "id" : 879935101949419525,
  "in_reply_to_status_id" : 879931296889266176,
  "created_at" : "2017-06-28 05:30:51 +0000",
  "in_reply_to_screen_name" : "jillemery",
  "in_reply_to_user_id_str" : "11385492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 0, 14 ],
      "id_str" : "257319757",
      "id" : 257319757
    }, {
      "name" : "The Method",
      "screen_name" : "methodpodcast",
      "indices" : [ 15, 29 ],
      "id_str" : "841811845811974146",
      "id" : 841811845811974146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879776384662601728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398877609302, 8.753323967377856 ]
  },
  "id_str" : "879848592185413635",
  "in_reply_to_user_id" : 257319757,
  "text" : "@lorrainechu3n @methodpodcast \uD83D\uDC4D for 2016. First \u201Ebig\u201C open* conf I\u2019ve personally seen putting so much emphasis on it. Shows goal of not only opening science but society.",
  "id" : 879848592185413635,
  "in_reply_to_status_id" : 879776384662601728,
  "created_at" : "2017-06-27 23:47:05 +0000",
  "in_reply_to_screen_name" : "lorrainechu3n",
  "in_reply_to_user_id_str" : "257319757",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 3, 17 ],
      "id_str" : "257319757",
      "id" : 257319757
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenCon",
      "indices" : [ 54, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "879847870278414336",
  "text" : "RT @lorrainechu3n: Looking for some testimonials from #OpenCon alum: How did OpenCon's efforts to create a diverse\/inclusive space affect y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenCon",
        "indices" : [ 35, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "879776384662601728",
    "text" : "Looking for some testimonials from #OpenCon alum: How did OpenCon's efforts to create a diverse\/inclusive space affect your experience?",
    "id" : 879776384662601728,
    "created_at" : "2017-06-27 19:00:10 +0000",
    "user" : {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "protected" : false,
      "id_str" : "257319757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926996461719621632\/aBq5xtJy_normal.jpg",
      "id" : 257319757,
      "verified" : false
    }
  },
  "id" : 879847870278414336,
  "created_at" : "2017-06-27 23:44:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chealsye Bowley",
      "screen_name" : "chealsye",
      "indices" : [ 0, 9 ],
      "id_str" : "39194970",
      "id" : 39194970
    }, {
      "name" : "Kyle K. Courtney",
      "screen_name" : "KyleKCourtney",
      "indices" : [ 10, 24 ],
      "id_str" : "462273819",
      "id" : 462273819
    }, {
      "name" : "sarah v melton",
      "screen_name" : "WorldCatLady",
      "indices" : [ 25, 38 ],
      "id_str" : "25760074",
      "id" : 25760074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879802169859358720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11390519881478, 8.753291514952208 ]
  },
  "id_str" : "879802297617981440",
  "in_reply_to_user_id" : 39194970,
  "text" : "@chealsye @KyleKCourtney @WorldCatLady I want to hear the manatee one!",
  "id" : 879802297617981440,
  "in_reply_to_status_id" : 879802169859358720,
  "created_at" : "2017-06-27 20:43:08 +0000",
  "in_reply_to_screen_name" : "chealsye",
  "in_reply_to_user_id_str" : "39194970",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chealsye Bowley",
      "screen_name" : "chealsye",
      "indices" : [ 0, 9 ],
      "id_str" : "39194970",
      "id" : 39194970
    }, {
      "name" : "sarah v melton",
      "screen_name" : "WorldCatLady",
      "indices" : [ 10, 23 ],
      "id_str" : "25760074",
      "id" : 25760074
    }, {
      "name" : "Kyle K. Courtney",
      "screen_name" : "KyleKCourtney",
      "indices" : [ 24, 38 ],
      "id_str" : "462273819",
      "id" : 462273819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879799596246908928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399586603405, 8.753337970052003 ]
  },
  "id_str" : "879800544612810756",
  "in_reply_to_user_id" : 39194970,
  "text" : "@chealsye @WorldCatLady @KyleKCourtney I think the opencon community must be full of people who\u2019d pass.",
  "id" : 879800544612810756,
  "in_reply_to_status_id" : 879799596246908928,
  "created_at" : "2017-06-27 20:36:10 +0000",
  "in_reply_to_screen_name" : "chealsye",
  "in_reply_to_user_id_str" : "39194970",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarah v melton",
      "screen_name" : "WorldCatLady",
      "indices" : [ 0, 13 ],
      "id_str" : "25760074",
      "id" : 25760074
    }, {
      "name" : "Kyle K. Courtney",
      "screen_name" : "KyleKCourtney",
      "indices" : [ 14, 28 ],
      "id_str" : "462273819",
      "id" : 462273819
    }, {
      "name" : "Chealsye Bowley",
      "screen_name" : "chealsye",
      "indices" : [ 29, 38 ],
      "id_str" : "39194970",
      "id" : 39194970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879799055542616064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399056957276, 8.753330590272677 ]
  },
  "id_str" : "879799200384503808",
  "in_reply_to_user_id" : 25760074,
  "text" : "@WorldCatLady @KyleKCourtney @chealsye Sold right away!",
  "id" : 879799200384503808,
  "in_reply_to_status_id" : 879799055542616064,
  "created_at" : "2017-06-27 20:30:49 +0000",
  "in_reply_to_screen_name" : "WorldCatLady",
  "in_reply_to_user_id_str" : "25760074",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chealsye Bowley",
      "screen_name" : "chealsye",
      "indices" : [ 0, 9 ],
      "id_str" : "39194970",
      "id" : 39194970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879795951040319488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398072280677, 8.753463651673393 ]
  },
  "id_str" : "879796700218523649",
  "in_reply_to_user_id" : 39194970,
  "text" : "@chealsye My solution: putting so much open* advocacy people that such people would never write to me.",
  "id" : 879796700218523649,
  "in_reply_to_status_id" : 879795951040319488,
  "created_at" : "2017-06-27 20:20:53 +0000",
  "in_reply_to_screen_name" : "chealsye",
  "in_reply_to_user_id_str" : "39194970",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879793277012258817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400264171714, 8.753348721614882 ]
  },
  "id_str" : "879795182090285057",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 Yep, what happens if you can\u2019t talk about anything but science :p",
  "id" : 879795182090285057,
  "in_reply_to_status_id" : 879793277012258817,
  "created_at" : "2017-06-27 20:14:51 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879792833317806083",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398918418957, 8.753328062463227 ]
  },
  "id_str" : "879793543115681794",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab Seemed to have worked out though! That\u2019s really cool!",
  "id" : 879793543115681794,
  "in_reply_to_status_id" : 879792833317806083,
  "created_at" : "2017-06-27 20:08:21 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879790057896517633",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399498138968, 8.75333665815625 ]
  },
  "id_str" : "879790589537026048",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab Now I\u2019m jealous! \uD83D\uDE02",
  "id" : 879790589537026048,
  "in_reply_to_status_id" : 879790057896517633,
  "created_at" : "2017-06-27 19:56:36 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Shockey",
      "screen_name" : "nshockey",
      "indices" : [ 0, 9 ],
      "id_str" : "16728620",
      "id" : 16728620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/6ljuhBdOmo",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/879789144305750016",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "879789009156939777",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11391433426189, 8.753136657186554 ]
  },
  "id_str" : "879789356323663873",
  "in_reply_to_user_id" : 16728620,
  "text" : "@nshockey Another chance for this https:\/\/t.co\/6ljuhBdOmo ;)",
  "id" : 879789356323663873,
  "in_reply_to_status_id" : 879789009156939777,
  "created_at" : "2017-06-27 19:51:42 +0000",
  "in_reply_to_screen_name" : "nshockey",
  "in_reply_to_user_id_str" : "16728620",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar17",
      "indices" : [ 105, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 128, 151 ],
      "url" : "https:\/\/t.co\/zT6OnrxQHZ",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/879788752251625472",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "879788752251625472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11389658472987, 8.753133199915657 ]
  },
  "id_str" : "879789144305750016",
  "in_reply_to_user_id" : 14286491,
  "text" : "Well, I did say that online dating can sometimes be a good place for preaching about open science at the #LGBTSTEMinar17. \uD83D\uDE02\uD83E\uDD37\u200D\u2640\uFE0F https:\/\/t.co\/zT6OnrxQHZ",
  "id" : 879789144305750016,
  "in_reply_to_status_id" : 879788752251625472,
  "created_at" : "2017-06-27 19:50:52 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140802868699, 8.753302412807887 ]
  },
  "id_str" : "879788752251625472",
  "text" : "Got what might be the weirdest request for collaborating on a metagenomic next generation sequencing project ever. In an OkCupid message.",
  "id" : 879788752251625472,
  "created_at" : "2017-06-27 19:49:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Merkley",
      "screen_name" : "ryanmerkley",
      "indices" : [ 3, 15 ],
      "id_str" : "16648767",
      "id" : 16648767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/i2N3UWa9pq",
      "expanded_url" : "https:\/\/twitter.com\/UserRoadmap\/status\/879327399665696768",
      "display_url" : "twitter.com\/UserRoadmap\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "879587049942261760",
  "text" : "RT @ryanmerkley: Great post about CC0 and why marking images matters for users of the commons. https:\/\/t.co\/i2N3UWa9pq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/i2N3UWa9pq",
        "expanded_url" : "https:\/\/twitter.com\/UserRoadmap\/status\/879327399665696768",
        "display_url" : "twitter.com\/UserRoadmap\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "879366478851710977",
    "text" : "Great post about CC0 and why marking images matters for users of the commons. https:\/\/t.co\/i2N3UWa9pq",
    "id" : 879366478851710977,
    "created_at" : "2017-06-26 15:51:21 +0000",
    "user" : {
      "name" : "Ryan Merkley",
      "screen_name" : "ryanmerkley",
      "protected" : false,
      "id_str" : "16648767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/861675858309795840\/wDGdUQCQ_normal.jpg",
      "id" : 16648767,
      "verified" : true
    }
  },
  "id" : 879587049942261760,
  "created_at" : "2017-06-27 06:27:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/hLXbJgJeeS",
      "expanded_url" : "https:\/\/twitter.com\/macmanes\/status\/879463567585443844",
      "display_url" : "twitter.com\/macmanes\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399671546265, 8.753338021200172 ]
  },
  "id_str" : "879464427728384004",
  "text" : "Maybe the death of 454 was meant? \uD83D\uDE02 https:\/\/t.co\/hLXbJgJeeS",
  "id" : 879464427728384004,
  "created_at" : "2017-06-26 22:20:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879456031427973120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399734792693, 8.753337985561135 ]
  },
  "id_str" : "879456325712973824",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski Not sure whether Bratwurstur will work. \uD83D\uDE02",
  "id" : 879456325712973824,
  "in_reply_to_status_id" : 879456031427973120,
  "created_at" : "2017-06-26 21:48:22 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879455396783632384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11384274930204, 8.753478203831522 ]
  },
  "id_str" : "879455869636935680",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski Try using your German nouns and add an -ur to the end. E.g. Hundur means dog. \uD83D\uDE09",
  "id" : 879455869636935680,
  "in_reply_to_status_id" : 879455396783632384,
  "created_at" : "2017-06-26 21:46:33 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marl\u00E8ne Delhaye",
      "screen_name" : "mdelhaye",
      "indices" : [ 37, 46 ],
      "id_str" : "106989588",
      "id" : 106989588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/dxSsSwokbH",
      "expanded_url" : "https:\/\/marlenescorner.net\/2017\/06\/25\/sci-hub-analyse-croisee\/",
      "display_url" : "marlenescorner.net\/2017\/06\/25\/sci\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11382970450669, 8.753512739595461 ]
  },
  "id_str" : "879453745029009408",
  "text" : "I don\u2019t speak French, but if you do: @mdelhaye blogged about my work on the Sci-Hub usage! https:\/\/t.co\/dxSsSwokbH",
  "id" : 879453745029009408,
  "created_at" : "2017-06-26 21:38:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Clarke",
      "screen_name" : "mtclarke",
      "indices" : [ 0, 9 ],
      "id_str" : "17217488",
      "id" : 17217488
    }, {
      "name" : "Erin McKiern\u24D0n",
      "screen_name" : "emckiernan13",
      "indices" : [ 10, 23 ],
      "id_str" : "404442001",
      "id" : 404442001
    }, {
      "name" : "Vicky Steeves",
      "screen_name" : "VickySteeves",
      "indices" : [ 24, 37 ],
      "id_str" : "991182416",
      "id" : 991182416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879417384515325953",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393745953226, 8.752880634321347 ]
  },
  "id_str" : "879448622391283712",
  "in_reply_to_user_id" : 17217488,
  "text" : "@mtclarke @emckiernan13 @VickySteeves No worries, No one\u2019s forcing you to invite her (Plus I doubt she would come to your conferences in any case\u2026) \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 879448622391283712,
  "in_reply_to_status_id" : 879417384515325953,
  "created_at" : "2017-06-26 21:17:45 +0000",
  "in_reply_to_screen_name" : "mtclarke",
  "in_reply_to_user_id_str" : "17217488",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 150 ],
      "url" : "https:\/\/t.co\/3efhHcu2GA",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/879435900626755584",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398826402458, 8.753324661793629 ]
  },
  "id_str" : "879439771478765570",
  "text" : "If you squint very hard you can see me somewhere in the middle of the author list. \uD83D\uDE02 Worked on this during #opencon last year! https:\/\/t.co\/3efhHcu2GA",
  "id" : 879439771478765570,
  "created_at" : "2017-06-26 20:42:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879439211958611972",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398826402458, 8.753324661793629 ]
  },
  "id_str" : "879439526472691713",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField No clue yet, still trying with the cutoff fingers of latex gloves.",
  "id" : 879439526472691713,
  "in_reply_to_status_id" : 879439211958611972,
  "created_at" : "2017-06-26 20:41:36 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399201671025, 8.753329829286812 ]
  },
  "id_str" : "879439092915810304",
  "text" : "DIY-levels while tending to the injured cat: \u00ABCould delubricated condoms work as non slip socks to wear over his bandages?\u00BB \uD83D\uDC08",
  "id" : 879439092915810304,
  "created_at" : "2017-06-26 20:39:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879340795194621952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139912316263, 8.753325919562052 ]
  },
  "id_str" : "879345377106898944",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown Totally agree on the run time constraints of parameter sweeps. Can\u2019t count how many assemblies I ran for the cited study \uD83D\uDE02",
  "id" : 879345377106898944,
  "in_reply_to_status_id" : 879340795194621952,
  "created_at" : "2017-06-26 14:27:30 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879341631798779904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399875488959, 8.75333609261728 ]
  },
  "id_str" : "879343262301130755",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown Count me in! :)",
  "id" : 879343262301130755,
  "in_reply_to_status_id" : 879341631798779904,
  "created_at" : "2017-06-26 14:19:05 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879340795194621952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398823368275, 8.753322711884593 ]
  },
  "id_str" : "879341087273492480",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown Will have a deeper look! Our experience: optimizing for N50 leads to completely ignoring low abundant genomes.",
  "id" : 879341087273492480,
  "in_reply_to_status_id" : 879340795194621952,
  "created_at" : "2017-06-26 14:10:27 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/swAXWc011r",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/1755-0998.12463\/full",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/17\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "879324737792393216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398998920614, 8.753323324105295 ]
  },
  "id_str" : "879340345955409920",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown Different metagenomic research, but naive parameter optimizing for even simple meta genomes makes it worse: https:\/\/t.co\/swAXWc011r",
  "id" : 879340345955409920,
  "in_reply_to_status_id" : 879324737792393216,
  "created_at" : "2017-06-26 14:07:30 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 0, 13 ],
      "id_str" : "189118361",
      "id" : 189118361
    }, {
      "name" : "Nature News&Comment",
      "screen_name" : "NatureNews",
      "indices" : [ 14, 25 ],
      "id_str" : "15862891",
      "id" : 15862891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879312316478705664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.07599621661407, 8.875213387141253 ]
  },
  "id_str" : "879316473231147009",
  "in_reply_to_user_id" : 189118361,
  "text" : "@MaliciaRogue @NatureNews Hadn\u2019t even noticed that! (thanks! Hope other people will reuse that data too!)",
  "id" : 879316473231147009,
  "in_reply_to_status_id" : 879312316478705664,
  "created_at" : "2017-06-26 12:32:38 +0000",
  "in_reply_to_screen_name" : "MaliciaRogue",
  "in_reply_to_user_id_str" : "189118361",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 0, 13 ],
      "id_str" : "189118361",
      "id" : 189118361
    }, {
      "name" : "Nature News&Comment",
      "screen_name" : "NatureNews",
      "indices" : [ 14, 25 ],
      "id_str" : "15862891",
      "id" : 15862891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "879307777822380032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399672813052, 8.753168210709987 ]
  },
  "id_str" : "879308664808644608",
  "in_reply_to_user_id" : 189118361,
  "text" : "@MaliciaRogue @NatureNews Yes. Though they at least by now added a link to the paper they mention.",
  "id" : 879308664808644608,
  "in_reply_to_status_id" : 879307777822380032,
  "created_at" : "2017-06-26 12:01:37 +0000",
  "in_reply_to_screen_name" : "MaliciaRogue",
  "in_reply_to_user_id_str" : "189118361",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave",
      "screen_name" : "daveyp",
      "indices" : [ 0, 7 ],
      "id_str" : "836681",
      "id" : 836681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878890486471307265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399064382466, 8.753327137206252 ]
  },
  "id_str" : "878969264451051520",
  "in_reply_to_user_id" : 836681,
  "text" : "@daveyp I agree on that, still I couldn\u2019t find any public data on Sci-Hub directly engaging in this.",
  "id" : 878969264451051520,
  "in_reply_to_status_id" : 878890486471307265,
  "created_at" : "2017-06-25 13:32:57 +0000",
  "in_reply_to_screen_name" : "daveyp",
  "in_reply_to_user_id_str" : "836681",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave",
      "screen_name" : "daveyp",
      "indices" : [ 0, 7 ],
      "id_str" : "836681",
      "id" : 836681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878887627415539712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399064382466, 8.753327137206252 ]
  },
  "id_str" : "878968659275894784",
  "in_reply_to_user_id" : 836681,
  "text" : "@daveyp Common sense isn\u2019t really something one can cite though. Plus my common sense is that people easily might do that to support a cause.",
  "id" : 878968659275894784,
  "in_reply_to_status_id" : 878887627415539712,
  "created_at" : "2017-06-25 13:30:33 +0000",
  "in_reply_to_screen_name" : "daveyp",
  "in_reply_to_user_id_str" : "836681",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/29faXfm8xx",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BVw5vW_Foey\/",
      "display_url" : "instagram.com\/p\/BVw5vW_Foey\/"
    } ]
  },
  "geo" : { },
  "id_str" : "878966922624344064",
  "text" : "After a week of writing: back from 15km of hiking. https:\/\/t.co\/29faXfm8xx",
  "id" : 878966922624344064,
  "created_at" : "2017-06-25 13:23:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave",
      "screen_name" : "daveyp",
      "indices" : [ 0, 7 ],
      "id_str" : "836681",
      "id" : 836681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878751643742941184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400831741099, 8.753352078118025 ]
  },
  "id_str" : "878756284979453952",
  "in_reply_to_user_id" : 836681,
  "text" : "@daveyp Still, hard for me to cite sources w\/o clear reports on those instances? But see how I could have included a mention of the claims at least.",
  "id" : 878756284979453952,
  "in_reply_to_status_id" : 878751643742941184,
  "created_at" : "2017-06-24 23:26:39 +0000",
  "in_reply_to_screen_name" : "daveyp",
  "in_reply_to_user_id_str" : "836681",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 3, 13 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "878754209633624064",
  "text" : "RT @biocrusoe: Everytime I meet a new person (which is all the time)\n\nThem: Why do you live in Lithuania?\nMe, wondering if I want to out my\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/eWVatnWB7m",
        "expanded_url" : "https:\/\/twitter.com\/brownlashon\/status\/878710136348356609",
        "display_url" : "twitter.com\/brownlashon\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "878753015750172672",
    "text" : "Everytime I meet a new person (which is all the time)\n\nThem: Why do you live in Lithuania?\nMe, wondering if I want to out myself right now:\u2026 https:\/\/t.co\/eWVatnWB7m",
    "id" : 878753015750172672,
    "created_at" : "2017-06-24 23:13:40 +0000",
    "user" : {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "protected" : false,
      "id_str" : "17645638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485998749311721472\/0yX4CFRV_normal.jpeg",
      "id" : 17645638,
      "verified" : false
    }
  },
  "id" : 878754209633624064,
  "created_at" : "2017-06-24 23:18:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave",
      "screen_name" : "daveyp",
      "indices" : [ 0, 7 ],
      "id_str" : "836681",
      "id" : 836681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878750842291138561",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.113980212805, 8.753309954573227 ]
  },
  "id_str" : "878751161750347776",
  "in_reply_to_user_id" : 836681,
  "text" : "@daveyp So, no one bothered to actually write this up somewhere for people to actually find out?",
  "id" : 878751161750347776,
  "in_reply_to_status_id" : 878750842291138561,
  "created_at" : "2017-06-24 23:06:18 +0000",
  "in_reply_to_screen_name" : "daveyp",
  "in_reply_to_user_id_str" : "836681",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave",
      "screen_name" : "daveyp",
      "indices" : [ 0, 7 ],
      "id_str" : "836681",
      "id" : 836681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878747460553904134",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11390788808178, 8.753460945418832 ]
  },
  "id_str" : "878749737247281152",
  "in_reply_to_user_id" : 836681,
  "text" : "@daveyp I couldn\u2019t find any solid published evidence on the hacking\/phishing, any links for me?",
  "id" : 878749737247281152,
  "in_reply_to_status_id" : 878747460553904134,
  "created_at" : "2017-06-24 23:00:38 +0000",
  "in_reply_to_screen_name" : "daveyp",
  "in_reply_to_user_id_str" : "836681",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Steeves",
      "screen_name" : "VickySteeves",
      "indices" : [ 3, 16 ],
      "id_str" : "991182416",
      "id" : 991182416
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckyeahOAwomen",
      "indices" : [ 22, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/2dW4fXpgC9",
      "expanded_url" : "https:\/\/fyoaw.vickysteeves.com\/",
      "display_url" : "fyoaw.vickysteeves.com"
    }, {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/5Vg0RrJ60Z",
      "expanded_url" : "https:\/\/gitlab.com\/VickySteeves\/Women-Leaders-Openness",
      "display_url" : "gitlab.com\/VickySteeves\/W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "878741376141332482",
  "text" : "RT @VickySteeves: The #fuckyeahOAwomen database is here!! https:\/\/t.co\/2dW4fXpgC9 &amp; the repo is here: https:\/\/t.co\/5Vg0RrJ60Z https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VickySteeves\/status\/878004624388759561\/photo\/1",
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/oP9HPs2gvB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DC9J295WsAAHMuY.jpg",
        "id_str" : "878001661037424640",
        "id" : 878001661037424640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DC9J295WsAAHMuY.jpg",
        "sizes" : [ {
          "h" : 348,
          "resize" : "fit",
          "w" : 529
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 529
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 529
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 529
        } ],
        "display_url" : "pic.twitter.com\/oP9HPs2gvB"
      } ],
      "hashtags" : [ {
        "text" : "fuckyeahOAwomen",
        "indices" : [ 4, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/2dW4fXpgC9",
        "expanded_url" : "https:\/\/fyoaw.vickysteeves.com\/",
        "display_url" : "fyoaw.vickysteeves.com"
      }, {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/5Vg0RrJ60Z",
        "expanded_url" : "https:\/\/gitlab.com\/VickySteeves\/Women-Leaders-Openness",
        "display_url" : "gitlab.com\/VickySteeves\/W\u2026"
      }, {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/JkA6r19y92",
        "expanded_url" : "https:\/\/twitter.com\/AprilHathcock\/status\/877581326928420865",
        "display_url" : "twitter.com\/AprilHathcock\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "878004624388759561",
    "text" : "The #fuckyeahOAwomen database is here!! https:\/\/t.co\/2dW4fXpgC9 &amp; the repo is here: https:\/\/t.co\/5Vg0RrJ60Z https:\/\/t.co\/JkA6r19y92 https:\/\/t.co\/oP9HPs2gvB",
    "id" : 878004624388759561,
    "created_at" : "2017-06-22 21:39:49 +0000",
    "user" : {
      "name" : "Vicky Steeves",
      "screen_name" : "VickySteeves",
      "protected" : false,
      "id_str" : "991182416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755124384218681345\/HpqngOHf_normal.jpg",
      "id" : 991182416,
      "verified" : false
    }
  },
  "id" : 878741376141332482,
  "created_at" : "2017-06-24 22:27:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    }, {
      "name" : "Nature News&Comment",
      "screen_name" : "NatureNews",
      "indices" : [ 8, 19 ],
      "id_str" : "15862891",
      "id" : 15862891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878344204052701185",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11126110182575, 8.751943561036866 ]
  },
  "id_str" : "878349474199879680",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn @NatureNews For once complaining helped? :D",
  "id" : 878349474199879680,
  "in_reply_to_status_id" : 878344204052701185,
  "created_at" : "2017-06-23 20:30:08 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878297315253080067",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11395381302583, 8.752780677758858 ]
  },
  "id_str" : "878318669591334912",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor Oh, yes! The firefly one is awesome as well! \uD83D\uDC96 as soon as my tattoo is healed enough to allow for short sleeves I\u2019ll wear them!",
  "id" : 878318669591334912,
  "in_reply_to_status_id" : 878297315253080067,
  "created_at" : "2017-06-23 18:27:43 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTQ",
      "indices" : [ 13, 19 ]
    }, {
      "text" : "Evol2017",
      "indices" : [ 36, 45 ]
    }, {
      "text" : "QueerSTEM",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/tiR7ltzFyP",
      "expanded_url" : "https:\/\/www.facebook.com\/events\/1519590228092755",
      "display_url" : "facebook.com\/events\/1519590\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "878251176545984513",
  "text" : "RT @JBYoder: #LGBTQ folks coming to #Evol2017\u2014yes, Outgroup is happening! RSVP so we have a head count https:\/\/t.co\/tiR7ltzFyP #QueerSTEM h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JBYoder\/status\/877751060399505408\/photo\/1",
        "indices" : [ 125, 148 ],
        "url" : "https:\/\/t.co\/DNe0iPCTNR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DC5lnubUIAIqjef.jpg",
        "id_str" : "877750710535725058",
        "id" : 877750710535725058,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DC5lnubUIAIqjef.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1125,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1125,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/DNe0iPCTNR"
      } ],
      "hashtags" : [ {
        "text" : "LGBTQ",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "Evol2017",
        "indices" : [ 23, 32 ]
      }, {
        "text" : "QueerSTEM",
        "indices" : [ 114, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/tiR7ltzFyP",
        "expanded_url" : "https:\/\/www.facebook.com\/events\/1519590228092755",
        "display_url" : "facebook.com\/events\/1519590\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "877751060399505408",
    "text" : "#LGBTQ folks coming to #Evol2017\u2014yes, Outgroup is happening! RSVP so we have a head count https:\/\/t.co\/tiR7ltzFyP #QueerSTEM https:\/\/t.co\/DNe0iPCTNR",
    "id" : 877751060399505408,
    "created_at" : "2017-06-22 04:52:15 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 878251176545984513,
  "created_at" : "2017-06-23 13:59:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 123, 131 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398438857089, 8.753319495370496 ]
  },
  "id_str" : "878250362670469125",
  "text" : "Such a small world: a Master student asked me for some advice on analyzing the Sci-Hub data, by chance it\u2019s a classmate of @PhdGeek! \uD83D\uDE02",
  "id" : 878250362670469125,
  "created_at" : "2017-06-23 13:56:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Curry",
      "screen_name" : "Stephen_Curry",
      "indices" : [ 0, 14 ],
      "id_str" : "41358714",
      "id" : 41358714
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878242853914263555",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398430485909, 8.753318669752007 ]
  },
  "id_str" : "878249110775660552",
  "in_reply_to_user_id" : 41358714,
  "text" : "@Stephen_Curry I understand, hope to hear his substantiation asap as well.",
  "id" : 878249110775660552,
  "in_reply_to_status_id" : 878242853914263555,
  "created_at" : "2017-06-23 13:51:19 +0000",
  "in_reply_to_screen_name" : "Stephen_Curry",
  "in_reply_to_user_id_str" : "41358714",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Santos",
      "screen_name" : "ansate",
      "indices" : [ 0, 7 ],
      "id_str" : "9723702",
      "id" : 9723702
    }, {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 8, 23 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878245448070217728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398238204202, 8.75331375751829 ]
  },
  "id_str" : "878246146174459904",
  "in_reply_to_user_id" : 9723702,
  "text" : "@ansate @TheConstructor yes! \uD83D\uDE0D",
  "id" : 878246146174459904,
  "in_reply_to_status_id" : 878245448070217728,
  "created_at" : "2017-06-23 13:39:32 +0000",
  "in_reply_to_screen_name" : "ansate",
  "in_reply_to_user_id_str" : "9723702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Curry",
      "screen_name" : "Stephen_Curry",
      "indices" : [ 0, 14 ],
      "id_str" : "41358714",
      "id" : 41358714
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878240182570409984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11331814012227, 8.755934450241044 ]
  },
  "id_str" : "878242051451650048",
  "in_reply_to_user_id" : 41358714,
  "text" : "@Stephen_Curry Just saying, demanding an answer at 5am is maybe a bit over the top, all justified disagreements aside?",
  "id" : 878242051451650048,
  "in_reply_to_status_id" : 878240182570409984,
  "created_at" : "2017-06-23 13:23:16 +0000",
  "in_reply_to_screen_name" : "Stephen_Curry",
  "in_reply_to_user_id_str" : "41358714",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Curry",
      "screen_name" : "Stephen_Curry",
      "indices" : [ 0, 14 ],
      "id_str" : "41358714",
      "id" : 41358714
    }, {
      "name" : "Richard Poynder",
      "screen_name" : "RickyPo",
      "indices" : [ 15, 23 ],
      "id_str" : "20298671",
      "id" : 20298671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878213566733500416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11427010414201, 8.753458354630277 ]
  },
  "id_str" : "878239572613890049",
  "in_reply_to_user_id" : 41358714,
  "text" : "@Stephen_Curry @RickyPo to be fair: 6h ago was already midnight in PDT and now it\u2019s 6AM\u2026",
  "id" : 878239572613890049,
  "in_reply_to_status_id" : 878213566733500416,
  "created_at" : "2017-06-23 13:13:25 +0000",
  "in_reply_to_screen_name" : "Stephen_Curry",
  "in_reply_to_user_id_str" : "41358714",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878228427186339841",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398203641258, 8.753313230336834 ]
  },
  "id_str" : "878228706627420160",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim do you want me to merge unseen? :D",
  "id" : 878228706627420160,
  "in_reply_to_status_id" : 878228427186339841,
  "created_at" : "2017-06-23 12:30:15 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Syme",
      "screen_name" : "robsyme",
      "indices" : [ 0, 8 ],
      "id_str" : "15027761",
      "id" : 15027761
    }, {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 9, 24 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878228064370438144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11331234658786, 8.755961334396497 ]
  },
  "id_str" : "878228217248837632",
  "in_reply_to_user_id" : 15027761,
  "text" : "@robsyme @TheConstructor Qwertee. :)",
  "id" : 878228217248837632,
  "in_reply_to_status_id" : 878228064370438144,
  "created_at" : "2017-06-23 12:28:18 +0000",
  "in_reply_to_screen_name" : "robsyme",
  "in_reply_to_user_id_str" : "15027761",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Morley",
      "screen_name" : "alex__morley",
      "indices" : [ 0, 13 ],
      "id_str" : "730032952525131777",
      "id" : 730032952525131777
    }, {
      "name" : "Nature News&Comment",
      "screen_name" : "NatureNews",
      "indices" : [ 14, 25 ],
      "id_str" : "15862891",
      "id" : 15862891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878161785072889856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398492409133, 8.753320020532005 ]
  },
  "id_str" : "878219028547776512",
  "in_reply_to_user_id" : 730032952525131777,
  "text" : "@alex__morley @NatureNews I wouldn\u2019t hold my breath. It seems no one at Springer Nature is engaging on social media.",
  "id" : 878219028547776512,
  "in_reply_to_status_id" : 878161785072889856,
  "created_at" : "2017-06-23 11:51:47 +0000",
  "in_reply_to_screen_name" : "alex__morley",
  "in_reply_to_user_id_str" : "730032952525131777",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 25, 40 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/878212631122681856\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/TsSO2Cf1OW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DDAJsKJXkAAaI1f.jpg",
      "id_str" : "878212581579788288",
      "id" : 878212581579788288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DDAJsKJXkAAaI1f.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      } ],
      "display_url" : "pic.twitter.com\/TsSO2Cf1OW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398341870807, 8.753318913149988 ]
  },
  "id_str" : "878212631122681856",
  "text" : "I have the best friends! @TheConstructor sent this shirt my way! \uD83D\uDE02\uD83D\uDE0D https:\/\/t.co\/TsSO2Cf1OW",
  "id" : 878212631122681856,
  "created_at" : "2017-06-23 11:26:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 11, 25 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "Egon Willigh\u24D0gen",
      "screen_name" : "egonwillighagen",
      "indices" : [ 26, 42 ],
      "id_str" : "22911650",
      "id" : 22911650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878206214009536512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398152417162, 8.753312448465284 ]
  },
  "id_str" : "878206327431938048",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @CameronNeylon @egonwillighagen I did, for other data. Which reminds me I have to send a ping re: my last request.",
  "id" : 878206327431938048,
  "in_reply_to_status_id" : 878206214009536512,
  "created_at" : "2017-06-23 11:01:19 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 0, 14 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 15, 25 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Egon Willigh\u24D0gen",
      "screen_name" : "egonwillighagen",
      "indices" : [ 26, 42 ],
      "id_str" : "22911650",
      "id" : 22911650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878203244463276033",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398212626698, 8.75331335645824 ]
  },
  "id_str" : "878205517566529536",
  "in_reply_to_user_id" : 12984852,
  "text" : "@CameronNeylon @blahah404 @egonwillighagen unfortunately it doesn\u2019t.",
  "id" : 878205517566529536,
  "in_reply_to_status_id" : 878203244463276033,
  "created_at" : "2017-06-23 10:58:06 +0000",
  "in_reply_to_screen_name" : "CameronNeylon",
  "in_reply_to_user_id_str" : "12984852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 11, 25 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "Egon Willigh\u24D0gen",
      "screen_name" : "egonwillighagen",
      "indices" : [ 26, 42 ],
      "id_str" : "22911650",
      "id" : 22911650
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/878191431504068608\/photo\/1",
      "indices" : [ 145, 168 ],
      "url" : "https:\/\/t.co\/8QjbL8Muyn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DC_2crbXcAEHMjT.png",
      "id_str" : "878191424914812929",
      "id" : 878191424914812929,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DC_2crbXcAEHMjT.png",
      "sizes" : [ {
        "h" : 358,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 619,
        "resize" : "fit",
        "w" : 1176
      }, {
        "h" : 619,
        "resize" : "fit",
        "w" : 1176
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 619,
        "resize" : "fit",
        "w" : 1176
      } ],
      "display_url" : "pic.twitter.com\/8QjbL8Muyn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878188403199815680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398295815047, 8.753314606732713 ]
  },
  "id_str" : "878191431504068608",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @CameronNeylon @egonwillighagen there you go. Daily requests over time from the Bohannon\/Elbakyan data. Sci-Hub was down in November. https:\/\/t.co\/8QjbL8Muyn",
  "id" : 878191431504068608,
  "in_reply_to_status_id" : 878188403199815680,
  "created_at" : "2017-06-23 10:02:07 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 3, 8 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/N4pYBnqGo4",
      "expanded_url" : "https:\/\/commons.wikimedia.org\/w\/index.php?title=File:Falsehoods_programmers_believe_about_languages.pdf",
      "display_url" : "commons.wikimedia.org\/w\/index.php?ti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "878167920647430145",
  "text" : "RT @johl: Falsehoods programmers believe about languages https:\/\/t.co\/N4pYBnqGo4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/N4pYBnqGo4",
        "expanded_url" : "https:\/\/commons.wikimedia.org\/w\/index.php?title=File:Falsehoods_programmers_believe_about_languages.pdf",
        "display_url" : "commons.wikimedia.org\/w\/index.php?ti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "878125157486931968",
    "text" : "Falsehoods programmers believe about languages https:\/\/t.co\/N4pYBnqGo4",
    "id" : 878125157486931968,
    "created_at" : "2017-06-23 05:38:46 +0000",
    "user" : {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "protected" : false,
      "id_str" : "1147751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/876909912185597952\/E61jm8M3_normal.jpg",
      "id" : 1147751,
      "verified" : false
    }
  },
  "id" : 878167920647430145,
  "created_at" : "2017-06-23 08:28:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    }, {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 54, 63 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878135552951934976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11340804394802, 8.749751248548517 ]
  },
  "id_str" : "878161719150948352",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU Good point, thanks for the feedback! @OBF_BOSC",
  "id" : 878161719150948352,
  "in_reply_to_status_id" : 878135552951934976,
  "created_at" : "2017-06-23 08:04:03 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 11, 21 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Cathy Deng",
      "screen_name" : "cthydng",
      "indices" : [ 22, 30 ],
      "id_str" : "113507714",
      "id" : 113507714
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878057773715476480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398428719007, 8.753319530783774 ]
  },
  "id_str" : "878116125321461760",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j @blahah404 @cthydng Well done!",
  "id" : 878116125321461760,
  "in_reply_to_status_id" : 878057773715476480,
  "created_at" : "2017-06-23 05:02:53 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "878037689869586432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398005989811, 8.753311912791226 ]
  },
  "id_str" : "878039991393320960",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j how about doing a 4-way one for easier tracking of both dimensions? (saw your open issue, on the repo)",
  "id" : 878039991393320960,
  "in_reply_to_status_id" : 878037689869586432,
  "created_at" : "2017-06-23 00:00:21 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "877992193948086272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388608130851, 8.753148587262649 ]
  },
  "id_str" : "878007605863473152",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU Care to explain? :)",
  "id" : 878007605863473152,
  "in_reply_to_status_id" : 877992193948086272,
  "created_at" : "2017-06-22 21:51:40 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 14, 23 ]
    }, {
      "text" : "OpenSource",
      "indices" : [ 85, 96 ]
    }, {
      "text" : "Bioinformatics",
      "indices" : [ 97, 112 ]
    }, {
      "text" : "openscience",
      "indices" : [ 113, 125 ]
    }, {
      "text" : "opendata",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "877988027707961344",
  "text" : "RT @OBF_BOSC: #BOSC2017 has 860 followers--can we get to 1000 before the conference? #OpenSource #Bioinformatics #openscience #opendata",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "OpenSource",
        "indices" : [ 71, 82 ]
      }, {
        "text" : "Bioinformatics",
        "indices" : [ 83, 98 ]
      }, {
        "text" : "openscience",
        "indices" : [ 99, 111 ]
      }, {
        "text" : "opendata",
        "indices" : [ 112, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "877924991831990272",
    "text" : "#BOSC2017 has 860 followers--can we get to 1000 before the conference? #OpenSource #Bioinformatics #openscience #opendata",
    "id" : 877924991831990272,
    "created_at" : "2017-06-22 16:23:23 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 877988027707961344,
  "created_at" : "2017-06-22 20:33:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nature News&Comment",
      "screen_name" : "NatureNews",
      "indices" : [ 50, 61 ],
      "id_str" : "15862891",
      "id" : 15862891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/aXqtUiH83b",
      "expanded_url" : "https:\/\/f1000research.com\/articles\/6-541\/v1",
      "display_url" : "f1000research.com\/articles\/6-541\u2026"
    }, {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/NOakmChO88",
      "expanded_url" : "https:\/\/twitter.com\/NatureNews\/status\/877956048010829826",
      "display_url" : "twitter.com\/NatureNews\/sta\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "877956048010829826",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1137672543069, 8.753517282270785 ]
  },
  "id_str" : "877986268784640000",
  "in_reply_to_user_id" : 15862891,
  "text" : "Also, thanks for not citing my \u201Crecent analysis\u201D, @NatureNews https:\/\/t.co\/aXqtUiH83b \uD83E\uDD37\u200D\u2640\uFE0F https:\/\/t.co\/NOakmChO88",
  "id" : 877986268784640000,
  "in_reply_to_status_id" : 877956048010829826,
  "created_at" : "2017-06-22 20:26:53 +0000",
  "in_reply_to_screen_name" : "NatureNews",
  "in_reply_to_user_id_str" : "15862891",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/aXqtUiH83b",
      "expanded_url" : "https:\/\/f1000research.com\/articles\/6-541\/v1",
      "display_url" : "f1000research.com\/articles\/6-541\u2026"
    }, {
      "indices" : [ 137, 160 ],
      "url" : "https:\/\/t.co\/q1vPyC4pnD",
      "expanded_url" : "https:\/\/twitter.com\/Townesfolk\/status\/877977632452747264",
      "display_url" : "twitter.com\/Townesfolk\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1137672543069, 8.753517282270785 ]
  },
  "id_str" : "877985794761162753",
  "text" : "My analysis of the sci-hub use says there\u2019s a big value to the scholarly community as well as the general public https:\/\/t.co\/aXqtUiH83b https:\/\/t.co\/q1vPyC4pnD",
  "id" : 877985794761162753,
  "created_at" : "2017-06-22 20:25:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 3, 11 ],
      "id_str" : "289107682",
      "id" : 289107682
    }, {
      "name" : "Sci Hub",
      "screen_name" : "Sci_Hub",
      "indices" : [ 42, 50 ],
      "id_str" : "381187236",
      "id" : 381187236
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Elsevier",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "877984595936804864",
  "text" : "RT @dhimmel: Doesn't change the fact that @Sci_Hub provides access to 97.3% of all #Elsevier articles! Stay tuned for our Sci-Hub Coverage\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sci Hub",
        "screen_name" : "Sci_Hub",
        "indices" : [ 29, 37 ],
        "id_str" : "381187236",
        "id" : 381187236
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Elsevier",
        "indices" : [ 70, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/wk5Tunn7Cc",
        "expanded_url" : "https:\/\/twitter.com\/NatureNews\/status\/877956048010829826",
        "display_url" : "twitter.com\/NatureNews\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "877977570632802304",
    "text" : "Doesn't change the fact that @Sci_Hub provides access to 97.3% of all #Elsevier articles! Stay tuned for our Sci-Hub Coverage preprint! https:\/\/t.co\/wk5Tunn7Cc",
    "id" : 877977570632802304,
    "created_at" : "2017-06-22 19:52:19 +0000",
    "user" : {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "protected" : false,
      "id_str" : "289107682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761279291053240320\/0xmzeIsg_normal.jpg",
      "id" : 289107682,
      "verified" : false
    }
  },
  "id" : 877984595936804864,
  "created_at" : "2017-06-22 20:20:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Casey Greene",
      "screen_name" : "GreeneScientist",
      "indices" : [ 15, 31 ],
      "id_str" : "95233492",
      "id" : 95233492
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 32, 42 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 43, 50 ],
      "id_str" : "15237935",
      "id" : 15237935
    }, {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 99, 107 ],
      "id_str" : "289107682",
      "id" : 289107682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "877978761555189761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397639169633, 8.753305986733789 ]
  },
  "id_str" : "877979149956030464",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @GreeneScientist @blahah404 @mrgunn Not exactly. But that\u2019s in good hands as I know @dhimmel :)",
  "id" : 877979149956030464,
  "in_reply_to_status_id" : 877978761555189761,
  "created_at" : "2017-06-22 19:58:36 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/FvioESSs6M",
      "expanded_url" : "https:\/\/peerj.com\/preprints\/2989\/",
      "display_url" : "peerj.com\/preprints\/2989\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233590565978, 8.627528166710874 ]
  },
  "id_str" : "877927522339573766",
  "text" : "Project level effects of gender on contribution evaluation on GitHub https:\/\/t.co\/FvioESSs6M",
  "id" : 877927522339573766,
  "created_at" : "2017-06-22 16:33:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VALIUM",
      "screen_name" : "alibi_rage",
      "indices" : [ 0, 11 ],
      "id_str" : "971867420",
      "id" : 971867420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/y8jE1feoe5",
      "expanded_url" : "https:\/\/68.media.tumblr.com\/3859ec8d17028837aa8f43fefd76d805\/tumblr_o1m7gv60It1uhezseo1_250.gif",
      "display_url" : "68.media.tumblr.com\/3859ec8d170288\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "877848324346454016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233113724475, 8.627516422600072 ]
  },
  "id_str" : "877888437889765376",
  "in_reply_to_user_id" : 971867420,
  "text" : "@alibi_rage high five! \uD83D\uDC36 https:\/\/t.co\/y8jE1feoe5",
  "id" : 877888437889765376,
  "in_reply_to_status_id" : 877848324346454016,
  "created_at" : "2017-06-22 13:58:08 +0000",
  "in_reply_to_screen_name" : "alibi_rage",
  "in_reply_to_user_id_str" : "971867420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/VfEyvLLLlj",
      "expanded_url" : "https:\/\/twitter.com\/NeuroPost\/status\/877662764235333632",
      "display_url" : "twitter.com\/NeuroPost\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230032596519, 8.627507425921102 ]
  },
  "id_str" : "877799339191676928",
  "text" : "Next R package coming up: stRoop effect. https:\/\/t.co\/VfEyvLLLlj",
  "id" : 877799339191676928,
  "created_at" : "2017-06-22 08:04:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Martin",
      "screen_name" : "Jenny_STEM",
      "indices" : [ 3, 14 ],
      "id_str" : "1607703990",
      "id" : 1607703990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "877772392289886208",
  "text" : "RT @Jenny_STEM: gosh if I did that with all my rejected papers\/grants etc the whole building would be wallpapered in negative outcomes http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/fOJIYi5F2a",
        "expanded_url" : "https:\/\/twitter.com\/NHopUTS\/status\/877406216300843009",
        "display_url" : "twitter.com\/NHopUTS\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "877755494080761856",
    "text" : "gosh if I did that with all my rejected papers\/grants etc the whole building would be wallpapered in negative outcomes https:\/\/t.co\/fOJIYi5F2a",
    "id" : 877755494080761856,
    "created_at" : "2017-06-22 05:09:52 +0000",
    "user" : {
      "name" : "Jenny Martin",
      "screen_name" : "Jenny_STEM",
      "protected" : false,
      "id_str" : "1607703990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/827114378453331968\/n_Kd5whX_normal.jpg",
      "id" : 1607703990,
      "verified" : false
    }
  },
  "id" : 877772392289886208,
  "created_at" : "2017-06-22 06:17:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 11, 19 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 20, 32 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "877663913931886592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11387467470794, 8.752887441758416 ]
  },
  "id_str" : "877664376873943040",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @o_guest @ctitusbrown Totally my approach, I just stop once it reaches a local optimum, so it\u2019s far from good. \uD83D\uDE02",
  "id" : 877664376873943040,
  "in_reply_to_status_id" : 877663913931886592,
  "created_at" : "2017-06-21 23:07:48 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla",
      "screen_name" : "mozilla",
      "indices" : [ 3, 11 ],
      "id_str" : "106682853",
      "id" : 106682853
    }, {
      "name" : "National Science Fdn",
      "screen_name" : "NSF",
      "indices" : [ 27, 31 ],
      "id_str" : "16245822",
      "id" : 16245822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "877662037513515009",
  "text" : "RT @mozilla: Mozilla &amp; @NSF are offering a $2 million prize to decentralize the web. We\u2019re accepting applications *today.* https:\/\/t.co\/Fvd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "National Science Fdn",
        "screen_name" : "NSF",
        "indices" : [ 14, 18 ],
        "id_str" : "16245822",
        "id" : 16245822
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/FvdtpdbtbI",
        "expanded_url" : "https:\/\/mzl.la\/2sPUqq3",
        "display_url" : "mzl.la\/2sPUqq3"
      } ]
    },
    "geo" : { },
    "id_str" : "877611635145400320",
    "text" : "Mozilla &amp; @NSF are offering a $2 million prize to decentralize the web. We\u2019re accepting applications *today.* https:\/\/t.co\/FvdtpdbtbI",
    "id" : 877611635145400320,
    "created_at" : "2017-06-21 19:38:13 +0000",
    "user" : {
      "name" : "Mozilla",
      "screen_name" : "mozilla",
      "protected" : false,
      "id_str" : "106682853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821735271049768960\/jJZXlJwZ_normal.jpg",
      "id" : 106682853,
      "verified" : true
    }
  },
  "id" : 877662037513515009,
  "created_at" : "2017-06-21 22:58:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/Xmdq6zOo2h",
      "expanded_url" : "http:\/\/www.nashturley.org\/2012\/09\/27\/pinguin-poop-paper\/",
      "display_url" : "nashturley.org\/2012\/09\/27\/pin\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "877551101490323456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231345338066, 8.627543654142631 ]
  },
  "id_str" : "877551371934978048",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer sure you don\u2019t want to go for Fig 1 in this one? https:\/\/t.co\/Xmdq6zOo2h",
  "id" : 877551371934978048,
  "in_reply_to_status_id" : 877551101490323456,
  "created_at" : "2017-06-21 15:38:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 134, 157 ],
      "url" : "https:\/\/t.co\/V7wSUqXhau",
      "expanded_url" : "https:\/\/twitter.com\/MsPhelps\/status\/877252485160873985",
      "display_url" : "twitter.com\/MsPhelps\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723365667735, 8.627521183092007 ]
  },
  "id_str" : "877546117017329665",
  "text" : "This is super effective. So far, each time I did this the conference organizers \u201Cmagically found\u201D non-white-male panelists. \u00AF\\_(\u30C4)_\/\u00AF https:\/\/t.co\/V7wSUqXhau",
  "id" : 877546117017329665,
  "created_at" : "2017-06-21 15:17:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 17, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232899870797, 8.62752713928367 ]
  },
  "id_str" : "877493899186626560",
  "text" : "Booked my \u2708\uFE0F for #BOSC2017! \uD83C\uDF89",
  "id" : 877493899186626560,
  "created_at" : "2017-06-21 11:50:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "877460071659077632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234102129966, 8.627522920739619 ]
  },
  "id_str" : "877465361586823168",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer it\u2019s your turn now :D",
  "id" : 877465361586823168,
  "in_reply_to_status_id" : 877460071659077632,
  "created_at" : "2017-06-21 09:56:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Galardini",
      "screen_name" : "mgalactus",
      "indices" : [ 0, 10 ],
      "id_str" : "531045394",
      "id" : 531045394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "877458944784052224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234102129966, 8.627522920739619 ]
  },
  "id_str" : "877465312999993344",
  "in_reply_to_user_id" : 531045394,
  "text" : "@mgalactus thanks!",
  "id" : 877465312999993344,
  "in_reply_to_status_id" : 877458944784052224,
  "created_at" : "2017-06-21 09:56:47 +0000",
  "in_reply_to_screen_name" : "mgalactus",
  "in_reply_to_user_id_str" : "531045394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "877448288768851970",
  "text" : "RT @gedankenstuecke: \u00ABIn industry there undoubtedly are better jobs but they never go to women.\u00BB \u2014 Rosalind Franklin on Industry vs Academi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309729297264959489",
    "text" : "\u00ABIn industry there undoubtedly are better jobs but they never go to women.\u00BB \u2014 Rosalind Franklin on Industry vs Academia, in the 1940s.",
    "id" : 309729297264959489,
    "created_at" : "2013-03-07 18:16:33 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 877448288768851970,
  "created_at" : "2017-06-21 08:49:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max",
      "screen_name" : "gau",
      "indices" : [ 0, 4 ],
      "id_str" : "29538964",
      "id" : 29538964
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 5, 12 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "877445246203953153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232112804887, 8.62753324478952 ]
  },
  "id_str" : "877445529550061568",
  "in_reply_to_user_id" : 29538964,
  "text" : "@gau @github thanks!",
  "id" : 877445529550061568,
  "in_reply_to_status_id" : 877445246203953153,
  "created_at" : "2017-06-21 08:38:11 +0000",
  "in_reply_to_screen_name" : "gau",
  "in_reply_to_user_id_str" : "29538964",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Method",
      "screen_name" : "methodpodcast",
      "indices" : [ 31, 45 ],
      "id_str" : "841811845811974146",
      "id" : 841811845811974146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/CBuM8QK0YF",
      "expanded_url" : "https:\/\/themethodpodcast.com\/listen\/010101-hello-world",
      "display_url" : "themethodpodcast.com\/listen\/010101-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233313286012, 8.627517054036446 ]
  },
  "id_str" : "877412117393092608",
  "text" : "Listen to the first episode of @methodpodcast! https:\/\/t.co\/CBuM8QK0YF",
  "id" : 877412117393092608,
  "created_at" : "2017-06-21 06:25:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jens Foell",
      "screen_name" : "fMRI_guy",
      "indices" : [ 0, 9 ],
      "id_str" : "2377958781",
      "id" : 2377958781
    }, {
      "name" : "Dennis Eckmeier, not that kind of Dr.",
      "screen_name" : "DennisEckmeier",
      "indices" : [ 10, 25 ],
      "id_str" : "595982444",
      "id" : 595982444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "877280994184876032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11371356872231, 8.753332026939034 ]
  },
  "id_str" : "877401119294717953",
  "in_reply_to_user_id" : 2377958781,
  "text" : "@fMRI_guy @DennisEckmeier I think you even have the obligation to do so! :D (plus: writing about it in an accessible way. :))",
  "id" : 877401119294717953,
  "in_reply_to_status_id" : 877280994184876032,
  "created_at" : "2017-06-21 05:41:42 +0000",
  "in_reply_to_screen_name" : "fMRI_guy",
  "in_reply_to_user_id_str" : "2377958781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Burks",
      "screen_name" : "djburks87",
      "indices" : [ 3, 13 ],
      "id_str" : "737778742257324032",
      "id" : 737778742257324032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "877286276977897472",
  "text" : "RT @djburks87: \"How do you keep all of those projects, collaborations, teaching assignments, and your dissertation from getting away from y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/djburks87\/status\/877269608318816259\/photo\/1",
        "indices" : [ 133, 156 ],
        "url" : "https:\/\/t.co\/ZmJsE7CrEq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DCyvqgcV0AAo6tf.jpg",
        "id_str" : "877269172228575232",
        "id" : 877269172228575232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DCyvqgcV0AAo6tf.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2304,
          "resize" : "fit",
          "w" : 4096
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/ZmJsE7CrEq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "877269608318816259",
    "text" : "\"How do you keep all of those projects, collaborations, teaching assignments, and your dissertation from getting away from you?\"\nMe: https:\/\/t.co\/ZmJsE7CrEq",
    "id" : 877269608318816259,
    "created_at" : "2017-06-20 20:59:08 +0000",
    "user" : {
      "name" : "David Burks",
      "screen_name" : "djburks87",
      "protected" : false,
      "id_str" : "737778742257324032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/928800795935490048\/bSGDW5TB_normal.jpg",
      "id" : 737778742257324032,
      "verified" : false
    }
  },
  "id" : 877286276977897472,
  "created_at" : "2017-06-20 22:05:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damaris Brisco",
      "screen_name" : "Fungal_Love",
      "indices" : [ 3, 15 ],
      "id_str" : "16597324",
      "id" : 16597324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "877256185283588098",
  "text" : "RT @Fungal_Love: Progress on the screen printing front! Finally finished a thing in india ink on acetate. Now I gotta build an exposure uni\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Fungal_Love\/status\/876984252700569600\/photo\/1",
        "indices" : [ 127, 150 ],
        "url" : "https:\/\/t.co\/QiMzVvVxof",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DCushuRVwAAIW8n.jpg",
        "id_str" : "876984247810113536",
        "id" : 876984247810113536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DCushuRVwAAIW8n.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/QiMzVvVxof"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "876984252700569600",
    "text" : "Progress on the screen printing front! Finally finished a thing in india ink on acetate. Now I gotta build an exposure unit... https:\/\/t.co\/QiMzVvVxof",
    "id" : 876984252700569600,
    "created_at" : "2017-06-20 02:05:14 +0000",
    "user" : {
      "name" : "Damaris Brisco",
      "screen_name" : "Fungal_Love",
      "protected" : false,
      "id_str" : "16597324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/815013452498554880\/2PvA4x7Y_normal.jpg",
      "id" : 16597324,
      "verified" : false
    }
  },
  "id" : 877256185283588098,
  "created_at" : "2017-06-20 20:05:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 3, 8 ],
      "id_str" : "9377892",
      "id" : 9377892
    }, {
      "name" : "Monica Granados",
      "screen_name" : "Monsauce",
      "indices" : [ 36, 45 ],
      "id_str" : "297073565",
      "id" : 297073565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/oq6lMm1YmA",
      "expanded_url" : "https:\/\/twitter.com\/ESAOpenSci\/status\/877237137934102529",
      "display_url" : "twitter.com\/ESAOpenSci\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "877244964501159936",
  "text" : "RT @tpoi: Attention all ecologists. @Monsauce is an AWESOME instructor. Go attend her workshop. https:\/\/t.co\/oq6lMm1YmA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Monica Granados",
        "screen_name" : "Monsauce",
        "indices" : [ 26, 35 ],
        "id_str" : "297073565",
        "id" : 297073565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/oq6lMm1YmA",
        "expanded_url" : "https:\/\/twitter.com\/ESAOpenSci\/status\/877237137934102529",
        "display_url" : "twitter.com\/ESAOpenSci\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "877238900166713344",
    "text" : "Attention all ecologists. @Monsauce is an AWESOME instructor. Go attend her workshop. https:\/\/t.co\/oq6lMm1YmA",
    "id" : 877238900166713344,
    "created_at" : "2017-06-20 18:57:06 +0000",
    "user" : {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "protected" : false,
      "id_str" : "9377892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/919272965581299713\/CCD-XjJ1_normal.jpg",
      "id" : 9377892,
      "verified" : false
    }
  },
  "id" : 877244964501159936,
  "created_at" : "2017-06-20 19:21:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Korlis",
      "screen_name" : "Korlis",
      "indices" : [ 3, 10 ],
      "id_str" : "14698527",
      "id" : 14698527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "877232519766257664",
  "text" : "RT @Korlis: London's Tube has been running so long the tunnels can no longer absorb heat, thus the increasing temperature on it o.O https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/XZyrpNzB7v",
        "expanded_url" : "https:\/\/twitter.com\/DaniRabaiotti\/status\/877164249176576000",
        "display_url" : "twitter.com\/DaniRabaiotti\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "877223212320518148",
    "text" : "London's Tube has been running so long the tunnels can no longer absorb heat, thus the increasing temperature on it o.O https:\/\/t.co\/XZyrpNzB7v",
    "id" : 877223212320518148,
    "created_at" : "2017-06-20 17:54:46 +0000",
    "user" : {
      "name" : "Korlis",
      "screen_name" : "Korlis",
      "protected" : false,
      "id_str" : "14698527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925494938569121792\/SXnRBwIo_normal.jpg",
      "id" : 14698527,
      "verified" : false
    }
  },
  "id" : 877232519766257664,
  "created_at" : "2017-06-20 18:31:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Granados",
      "screen_name" : "Monsauce",
      "indices" : [ 0, 9 ],
      "id_str" : "297073565",
      "id" : 297073565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "877217945222623232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11378116535369, 8.753389647372373 ]
  },
  "id_str" : "877218085052219392",
  "in_reply_to_user_id" : 297073565,
  "text" : "@Monsauce Maybe for the next one \uD83D\uDE02",
  "id" : 877218085052219392,
  "in_reply_to_status_id" : 877217945222623232,
  "created_at" : "2017-06-20 17:34:24 +0000",
  "in_reply_to_screen_name" : "Monsauce",
  "in_reply_to_user_id_str" : "297073565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Granados",
      "screen_name" : "Monsauce",
      "indices" : [ 0, 9 ],
      "id_str" : "297073565",
      "id" : 297073565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "877216751481761794",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11386472527966, 8.753109495595288 ]
  },
  "id_str" : "877217382527270913",
  "in_reply_to_user_id" : 297073565,
  "text" : "@Monsauce The blue print totally reminded me of the endoplasmatic reticulum somehow \uD83D\uDE02",
  "id" : 877217382527270913,
  "in_reply_to_status_id" : 877216751481761794,
  "created_at" : "2017-06-20 17:31:36 +0000",
  "in_reply_to_screen_name" : "Monsauce",
  "in_reply_to_user_id_str" : "297073565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grace Mosley",
      "screen_name" : "runDRG",
      "indices" : [ 0, 7 ],
      "id_str" : "797960868977786880",
      "id" : 797960868977786880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "877215753988190210",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11382100810031, 8.753295156317948 ]
  },
  "id_str" : "877216876128079873",
  "in_reply_to_user_id" : 797960868977786880,
  "text" : "@runDRG Yes, even better than I hoped!",
  "id" : 877216876128079873,
  "in_reply_to_status_id" : 877215753988190210,
  "created_at" : "2017-06-20 17:29:35 +0000",
  "in_reply_to_screen_name" : "runDRG",
  "in_reply_to_user_id_str" : "797960868977786880",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grace Mosley",
      "screen_name" : "runDRG",
      "indices" : [ 0, 7 ],
      "id_str" : "797960868977786880",
      "id" : 797960868977786880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/SmXk4xCEx2",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/877215405558902785",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "877213627618668546",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11378606792508, 8.753304027239471 ]
  },
  "id_str" : "877215594105516033",
  "in_reply_to_user_id" : 797960868977786880,
  "text" : "@runDRG See https:\/\/t.co\/SmXk4xCEx2 for the result \uD83D\uDE0A",
  "id" : 877215594105516033,
  "in_reply_to_status_id" : 877213627618668546,
  "created_at" : "2017-06-20 17:24:30 +0000",
  "in_reply_to_screen_name" : "runDRG",
  "in_reply_to_user_id_str" : "797960868977786880",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/XeJHu7sLxz",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BVkdPmuFjAi\/",
      "display_url" : "instagram.com\/p\/BVkdPmuFjAi\/"
    } ]
  },
  "geo" : { },
  "id_str" : "877215405558902785",
  "text" : "Here's the Post-\uD83D\uDC89-Proof. Thanks Ms. Franklin! \uD83D\uDC96 https:\/\/t.co\/XeJHu7sLxz",
  "id" : 877215405558902785,
  "created_at" : "2017-06-20 17:23:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 21, 27 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/eN5L7M1u0B",
      "expanded_url" : "https:\/\/soundcloud.com\/thesoundofpeople",
      "display_url" : "soundcloud.com\/thesoundofpeop\u2026"
    }, {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/5nzudMx3LV",
      "expanded_url" : "https:\/\/twitter.com\/samstudio8\/status\/877127927539929089",
      "display_url" : "twitter.com\/samstudio8\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "877184446474199041",
  "text" : "RT @PhilippBayer: cc @dvzrv, seems a bit like https:\/\/t.co\/eN5L7M1u0B https:\/\/t.co\/5nzudMx3LV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "dvzrv",
        "screen_name" : "dvzrv",
        "indices" : [ 3, 9 ],
        "id_str" : "30868098",
        "id" : 30868098
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/eN5L7M1u0B",
        "expanded_url" : "https:\/\/soundcloud.com\/thesoundofpeople",
        "display_url" : "soundcloud.com\/thesoundofpeop\u2026"
      }, {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/5nzudMx3LV",
        "expanded_url" : "https:\/\/twitter.com\/samstudio8\/status\/877127927539929089",
        "display_url" : "twitter.com\/samstudio8\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "877138208588316672",
    "text" : "cc @dvzrv, seems a bit like https:\/\/t.co\/eN5L7M1u0B https:\/\/t.co\/5nzudMx3LV",
    "id" : 877138208588316672,
    "created_at" : "2017-06-20 12:17:00 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 877184446474199041,
  "created_at" : "2017-06-20 15:20:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "877183673107394561",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0504305727146, 8.695850356819049 ]
  },
  "id_str" : "877183911968862209",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon Beste \uD83C\uDFAF-Variante!",
  "id" : 877183911968862209,
  "in_reply_to_status_id" : 877183673107394561,
  "created_at" : "2017-06-20 15:18:36 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gero Nagel",
      "screen_name" : "zweifeln",
      "indices" : [ 0, 9 ],
      "id_str" : "170420130",
      "id" : 170420130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/2rs2l1CabA",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Photo_51",
      "display_url" : "en.m.wikipedia.org\/wiki\/Photo_51"
    } ]
  },
  "in_reply_to_status_id_str" : "877183546045210629",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0503954395876, 8.695975881045596 ]
  },
  "id_str" : "877183702178172928",
  "in_reply_to_user_id" : 170420130,
  "text" : "@zweifeln Noch besser: https:\/\/t.co\/2rs2l1CabA :)",
  "id" : 877183702178172928,
  "in_reply_to_status_id" : 877183546045210629,
  "created_at" : "2017-06-20 15:17:46 +0000",
  "in_reply_to_screen_name" : "zweifeln",
  "in_reply_to_user_id_str" : "170420130",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/877183391053094912\/photo\/1",
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/3pttHjAZ8d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DCxhosNWAAMh4Bu.jpg",
      "id_str" : "877183379120193539",
      "id" : 877183379120193539,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DCxhosNWAAMh4Bu.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/3pttHjAZ8d"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05044875741677, 8.695888780581209 ]
  },
  "id_str" : "877183391053094912",
  "text" : "Pre-\uD83D\uDC89-Prep. https:\/\/t.co\/3pttHjAZ8d",
  "id" : 877183391053094912,
  "created_at" : "2017-06-20 15:16:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VALIUM",
      "screen_name" : "alibi_rage",
      "indices" : [ 0, 11 ],
      "id_str" : "971867420",
      "id" : 971867420
    }, {
      "name" : "zen_fic0n",
      "screen_name" : "zen_fic0n",
      "indices" : [ 12, 22 ],
      "id_str" : "2655150655",
      "id" : 2655150655
    }, {
      "name" : "Ragetina",
      "screen_name" : "Ragetina",
      "indices" : [ 23, 32 ],
      "id_str" : "819601236",
      "id" : 819601236
    }, {
      "name" : "Ranting @branleb",
      "screen_name" : "rantleb",
      "indices" : [ 33, 41 ],
      "id_str" : "748130881",
      "id" : 748130881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "877148873772412929",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17245078402885, 8.627607422580533 ]
  },
  "id_str" : "877149205772607488",
  "in_reply_to_user_id" : 971867420,
  "text" : "@alibi_rage @zen_fic0n @Ragetina @rantleb finde hat mehr was von Asterix &amp; Obelix: \u201EOhnemus &amp; Alleskann\u201C",
  "id" : 877149205772607488,
  "in_reply_to_status_id" : 877148873772412929,
  "created_at" : "2017-06-20 13:00:41 +0000",
  "in_reply_to_screen_name" : "alibi_rage",
  "in_reply_to_user_id_str" : "971867420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zen_fic0n",
      "screen_name" : "zen_fic0n",
      "indices" : [ 0, 10 ],
      "id_str" : "2655150655",
      "id" : 2655150655
    }, {
      "name" : "Ragetina",
      "screen_name" : "Ragetina",
      "indices" : [ 11, 20 ],
      "id_str" : "819601236",
      "id" : 819601236
    }, {
      "name" : "Ranting @branleb",
      "screen_name" : "rantleb",
      "indices" : [ 21, 29 ],
      "id_str" : "748130881",
      "id" : 748130881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "877145016824627200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17246056250371, 8.627590890217315 ]
  },
  "id_str" : "877145215492116485",
  "in_reply_to_user_id" : 2655150655,
  "text" : "@zen_fic0n @Ragetina @rantleb Ich komme heute &amp; morgen erst super sp\u00E4t aus dem B\u00FCro bzw. nach Hause. W\u00E4re \uD83D\uDC4D wen einer von euch das machen k\u00F6nnte.",
  "id" : 877145215492116485,
  "in_reply_to_status_id" : 877145016824627200,
  "created_at" : "2017-06-20 12:44:50 +0000",
  "in_reply_to_screen_name" : "zen_fic0n",
  "in_reply_to_user_id_str" : "2655150655",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 0, 13 ],
      "id_str" : "9104202",
      "id" : 9104202
    }, {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 14, 23 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "AstridvanWesenbeeck",
      "screen_name" : "Astrid_KB",
      "indices" : [ 24, 34 ],
      "id_str" : "2650100144",
      "id" : 2650100144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "877108611100676096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231376894711, 8.627510579886854 ]
  },
  "id_str" : "877134352467013632",
  "in_reply_to_user_id" : 9104202,
  "text" : "@jeroenbosman @MsPhelps @Astrid_KB Soon you can start a tumblr with pictures of this genre: \u201C\u2702\uFE0F on \uD83D\uDE82s &amp; \u2708\uFE0Fs\u201D",
  "id" : 877134352467013632,
  "in_reply_to_status_id" : 877108611100676096,
  "created_at" : "2017-06-20 12:01:40 +0000",
  "in_reply_to_screen_name" : "jeroenbosman",
  "in_reply_to_user_id_str" : "9104202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 42, 49 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/877064324526874628\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/RI13Wep99w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DCv1Wf9WAAAio54.jpg",
      "id_str" : "877064319338414080",
      "id" : 877064319338414080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DCv1Wf9WAAAio54.jpg",
      "sizes" : [ {
        "h" : 574,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/RI13Wep99w"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233241855973, 8.62755628106288 ]
  },
  "id_str" : "877064324526874628",
  "text" : "Just saw the (new?) community profiles on @github, along with the guides on building a strong community. Nice! \uD83C\uDF89 https:\/\/t.co\/RI13Wep99w",
  "id" : 877064324526874628,
  "created_at" : "2017-06-20 07:23:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233441971202, 8.627568567090178 ]
  },
  "id_str" : "877063326525685760",
  "text" : "Personal growth: finally fixing bugs that were reported 2 year ago but that I couldn\u2019t figure out then. \uD83D\uDE0E\uD83D\uDE02",
  "id" : 877063326525685760,
  "created_at" : "2017-06-20 07:19:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 12, 28 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "877035712046039040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239294950389, 8.627457330364962 ]
  },
  "id_str" : "877061971161624576",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena @kevinschawinski Me too, might make a nice bribe for the border patrol on the next  \uD83C\uDDE9\uD83C\uDDEA\/\uD83C\uDDE8\uD83C\uDDED crossing.",
  "id" : 877061971161624576,
  "in_reply_to_status_id" : 877035712046039040,
  "created_at" : "2017-06-20 07:14:03 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Zimmerman",
      "screen_name" : "j_zimms",
      "indices" : [ 0, 8 ],
      "id_str" : "14714760",
      "id" : 14714760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "876895021676494848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400666092533, 8.753236066558168 ]
  },
  "id_str" : "876896028515065860",
  "in_reply_to_user_id" : 14714760,
  "text" : "@j_zimms \uD83D\uDCAF band name!",
  "id" : 876896028515065860,
  "in_reply_to_status_id" : 876895021676494848,
  "created_at" : "2017-06-19 20:14:39 +0000",
  "in_reply_to_screen_name" : "j_zimms",
  "in_reply_to_user_id_str" : "14714760",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zen_fic0n",
      "screen_name" : "zen_fic0n",
      "indices" : [ 0, 10 ],
      "id_str" : "2655150655",
      "id" : 2655150655
    }, {
      "name" : "Ranting @branleb",
      "screen_name" : "rantleb",
      "indices" : [ 11, 19 ],
      "id_str" : "748130881",
      "id" : 748130881
    }, {
      "name" : "Ragetina",
      "screen_name" : "Ragetina",
      "indices" : [ 20, 29 ],
      "id_str" : "819601236",
      "id" : 819601236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "876875818181566465",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11131192096519, 8.754887804397153 ]
  },
  "id_str" : "876876478360813568",
  "in_reply_to_user_id" : 2655150655,
  "text" : "@zen_fic0n @rantleb @Ragetina War gerade mal beim Nordring aber nix zu sehen :(",
  "id" : 876876478360813568,
  "in_reply_to_status_id" : 876875818181566465,
  "created_at" : "2017-06-19 18:56:58 +0000",
  "in_reply_to_screen_name" : "zen_fic0n",
  "in_reply_to_user_id_str" : "2655150655",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Granados",
      "screen_name" : "Monsauce",
      "indices" : [ 0, 9 ],
      "id_str" : "297073565",
      "id" : 297073565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "876875494653911040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11163420514214, 8.755976697438168 ]
  },
  "id_str" : "876876320227119104",
  "in_reply_to_user_id" : 297073565,
  "text" : "@Monsauce Happy to send some your way too! (And the idea must have been copied from someone :))",
  "id" : 876876320227119104,
  "in_reply_to_status_id" : 876875494653911040,
  "created_at" : "2017-06-19 18:56:20 +0000",
  "in_reply_to_screen_name" : "Monsauce",
  "in_reply_to_user_id_str" : "297073565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/876873139170529280\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/Uh94wqO3Fz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DCtHcbtXUAI8s8X.jpg",
      "id_str" : "876873106253631490",
      "id" : 876873106253631490,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DCtHcbtXUAI8s8X.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Uh94wqO3Fz"
    } ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399724774784, 8.75333948848983 ]
  },
  "id_str" : "876873139170529280",
  "text" : "Sticker packages for the new #mozsprint contributors! \u2705 https:\/\/t.co\/Uh94wqO3Fz",
  "id" : 876873139170529280,
  "created_at" : "2017-06-19 18:43:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17242426116965, 8.627568223497386 ]
  },
  "id_str" : "876858365254803463",
  "text" : "After hours of debugging a JS error I found out my element is just hidden behind another one for having a too small z-index in the CSS\u2026",
  "id" : 876858365254803463,
  "created_at" : "2017-06-19 17:45:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 0, 10 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "876774612973092864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17243822744105, 8.62762651262737 ]
  },
  "id_str" : "876783122339254272",
  "in_reply_to_user_id" : 186529934,
  "text" : "@auremoser that\u2019s a great one. About rhoticity in this case, couldn\u2019t find gif for the difference between alveolar tap \/r\/ and the uvular trill \/r\/. \uD83D\uDE02",
  "id" : 876783122339254272,
  "in_reply_to_status_id" : 876774612973092864,
  "created_at" : "2017-06-19 12:46:00 +0000",
  "in_reply_to_screen_name" : "auremoser",
  "in_reply_to_user_id_str" : "186529934",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "876738751883612160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17281025433814, 8.627601855542483 ]
  },
  "id_str" : "876743938681565184",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim Don\u2019t give her any ideas. I\u2019m sure she\u2019d like that!",
  "id" : 876743938681565184,
  "in_reply_to_status_id" : 876738751883612160,
  "created_at" : "2017-06-19 10:10:18 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "876709248843075589",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.05866168443957, 8.500415654860902 ]
  },
  "id_str" : "876713301400539136",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim Crappy old car plus single male driver?",
  "id" : 876713301400539136,
  "in_reply_to_status_id" : 876709248843075589,
  "created_at" : "2017-06-19 08:08:34 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "876708223016947712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.91366205182756, 8.7082110811106 ]
  },
  "id_str" : "876708608204996608",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim Not sure whether that makes a difference thanks to Schengen.",
  "id" : 876708608204996608,
  "in_reply_to_status_id" : 876708223016947712,
  "created_at" : "2017-06-19 07:49:55 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "876705133807226880",
  "text" : "RT @gedankenstuecke: The joy of taking on cross-cultural double names: spending your weekends learning how to nail the pronunciation of you\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/876541730497196032\/photo\/1",
        "indices" : [ 130, 153 ],
        "url" : "https:\/\/t.co\/CaBqwiYMIW",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DCoaDXHWAAEP_j6.jpg",
        "id_str" : "876541722523729921",
        "id" : 876541722523729921,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DCoaDXHWAAEP_j6.jpg",
        "sizes" : [ {
          "h" : 220,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/CaBqwiYMIW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "876541730497196032",
    "text" : "The joy of taking on cross-cultural double names: spending your weekends learning how to nail the pronunciation of your new name. https:\/\/t.co\/CaBqwiYMIW",
    "id" : 876541730497196032,
    "created_at" : "2017-06-18 20:46:48 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 876705133807226880,
  "created_at" : "2017-06-19 07:36:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/dF9Nx3xxQF",
      "expanded_url" : "https:\/\/www.washingtonpost.com\/world\/europe\/germany-begins-border-controls-in-lead-up-to-g20-summit\/2017\/06\/12\/4e16c0b0-4f60-11e7-b74e-0d2785d3083d_story.html?utm_term=.ac2a5f717a62",
      "display_url" : "washingtonpost.com\/world\/europe\/g\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.8881901782452, 8.744268352173961 ]
  },
  "id_str" : "876687984892014592",
  "text" : "Things that make my Switzerland \uD83C\uDDE8\uD83C\uDDED- \uD83C\uDDE9\uD83C\uDDEA commute even less fun: https:\/\/t.co\/dF9Nx3xxQF",
  "id" : 876687984892014592,
  "created_at" : "2017-06-19 06:27:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Erin McKiern\u24D0n",
      "screen_name" : "emckiernan13",
      "indices" : [ 11, 24 ],
      "id_str" : "404442001",
      "id" : 404442001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "876566358187794433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35935904798804, 8.58782167919156 ]
  },
  "id_str" : "876662932255514624",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @emckiernan13 This new reply feature ends up being reply spam rather quickly :p",
  "id" : 876662932255514624,
  "in_reply_to_status_id" : 876566358187794433,
  "created_at" : "2017-06-19 04:48:25 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin McKiern\u24D0n",
      "screen_name" : "emckiernan13",
      "indices" : [ 0, 13 ],
      "id_str" : "404442001",
      "id" : 404442001
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 14, 22 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Dnavid",
      "screen_name" : "davidweisss",
      "indices" : [ 23, 35 ],
      "id_str" : "19355816",
      "id" : 19355816
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 60, 72 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 77, 87 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "876553831852761090",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.359236390374, 8.587792804472695 ]
  },
  "id_str" : "876553989432762368",
  "in_reply_to_user_id" : 404442001,
  "text" : "@emckiernan13 @glyn_dk @davidweisss Happy to help. I\u2019m sure @denormalize and @blahah404 can name more!",
  "id" : 876553989432762368,
  "in_reply_to_status_id" : 876553831852761090,
  "created_at" : "2017-06-18 21:35:31 +0000",
  "in_reply_to_screen_name" : "emckiernan13",
  "in_reply_to_user_id_str" : "404442001",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Erin McKiern\u24D0n",
      "screen_name" : "emckiernan13",
      "indices" : [ 9, 22 ],
      "id_str" : "404442001",
      "id" : 404442001
    }, {
      "name" : "Dnavid",
      "screen_name" : "davidweisss",
      "indices" : [ 23, 35 ],
      "id_str" : "19355816",
      "id" : 19355816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/2Ey6Nbnjzq",
      "expanded_url" : "https:\/\/github.com\/HospitalRun",
      "display_url" : "github.com\/HospitalRun"
    } ]
  },
  "in_reply_to_status_id_str" : "876538032911994880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35917036887703, 8.587799014034198 ]
  },
  "id_str" : "876553203562815488",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @emckiernan13 @davidweisss I\u2019m less familiar with https:\/\/t.co\/2Ey6Nbnjzq but seems fitting.",
  "id" : 876553203562815488,
  "in_reply_to_status_id" : 876538032911994880,
  "created_at" : "2017-06-18 21:32:23 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Erin McKiern\u24D0n",
      "screen_name" : "emckiernan13",
      "indices" : [ 9, 22 ],
      "id_str" : "404442001",
      "id" : 404442001
    }, {
      "name" : "Dnavid",
      "screen_name" : "davidweisss",
      "indices" : [ 23, 35 ],
      "id_str" : "19355816",
      "id" : 19355816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/vogvf9YXDG",
      "expanded_url" : "https:\/\/github.com\/RefugeRestrooms\/refugerestrooms",
      "display_url" : "github.com\/RefugeRestroom\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "876538032911994880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35917036887703, 8.587799014034198 ]
  },
  "id_str" : "876550526867034113",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @emckiernan13 @davidweisss Something like e.g. https:\/\/t.co\/vogvf9YXDG?",
  "id" : 876550526867034113,
  "in_reply_to_status_id" : 876538032911994880,
  "created_at" : "2017-06-18 21:21:45 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/876541730497196032\/photo\/1",
      "indices" : [ 130, 153 ],
      "url" : "https:\/\/t.co\/CaBqwiYMIW",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DCoaDXHWAAEP_j6.jpg",
      "id_str" : "876541722523729921",
      "id" : 876541722523729921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DCoaDXHWAAEP_j6.jpg",
      "sizes" : [ {
        "h" : 220,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/CaBqwiYMIW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "876541730497196032",
  "text" : "The joy of taking on cross-cultural double names: spending your weekends learning how to nail the pronunciation of your new name. https:\/\/t.co\/CaBqwiYMIW",
  "id" : 876541730497196032,
  "created_at" : "2017-06-18 20:46:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly OBrien Burford",
      "screen_name" : "obrienwrite",
      "indices" : [ 0, 12 ],
      "id_str" : "248919613",
      "id" : 248919613
    }, {
      "name" : "Patreon",
      "screen_name" : "Patreon",
      "indices" : [ 13, 21 ],
      "id_str" : "1228325660",
      "id" : 1228325660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "876459391595069440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35937854150016, 8.587817772113395 ]
  },
  "id_str" : "876503284189724673",
  "in_reply_to_user_id" : 248919613,
  "text" : "@obrienwrite @Patreon Thanks so much for that! \uD83D\uDC96",
  "id" : 876503284189724673,
  "in_reply_to_status_id" : 876459391595069440,
  "created_at" : "2017-06-18 18:14:02 +0000",
  "in_reply_to_screen_name" : "obrienwrite",
  "in_reply_to_user_id_str" : "248919613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zen_fic0n",
      "screen_name" : "zen_fic0n",
      "indices" : [ 0, 10 ],
      "id_str" : "2655150655",
      "id" : 2655150655
    }, {
      "name" : "Ragetina",
      "screen_name" : "Ragetina",
      "indices" : [ 11, 20 ],
      "id_str" : "819601236",
      "id" : 819601236
    }, {
      "name" : "Ranting @branleb",
      "screen_name" : "rantleb",
      "indices" : [ 21, 29 ],
      "id_str" : "748130881",
      "id" : 748130881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "876417752818479104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.36120546391916, 8.571091281539417 ]
  },
  "id_str" : "876491899821060096",
  "in_reply_to_user_id" : 2655150655,
  "text" : "@zen_fic0n @Ragetina @rantleb Hab gerade per Facebook einen Hinweis bekommen. Siehe E-Mail.",
  "id" : 876491899821060096,
  "in_reply_to_status_id" : 876417752818479104,
  "created_at" : "2017-06-18 17:28:48 +0000",
  "in_reply_to_screen_name" : "zen_fic0n",
  "in_reply_to_user_id_str" : "2655150655",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "876456328402751490",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35934079834022, 8.588009459778297 ]
  },
  "id_str" : "876456459080433665",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim \u201Emore ice cream eating is clearly needed\u201C",
  "id" : 876456459080433665,
  "in_reply_to_status_id" : 876456328402751490,
  "created_at" : "2017-06-18 15:07:58 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/zreiIeuJQz",
      "expanded_url" : "http:\/\/sharingisnotacrime.org",
      "display_url" : "sharingisnotacrime.org"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3592721819598, 8.587820365592647 ]
  },
  "id_str" : "876453823979585536",
  "text" : "After accidentally sending out an old newsletter: mailing openSNP users about #mozsprint &amp; asking for help for Diego https:\/\/t.co\/zreiIeuJQz",
  "id" : 876453823979585536,
  "created_at" : "2017-06-18 14:57:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 66, 74 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 16, 23 ]
    }, {
      "text" : "mozsprint",
      "indices" : [ 36, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37683868309973, 8.543800135407478 ]
  },
  "id_str" : "876109861255303168",
  "text" : "Finally another #mozwow reunion and #mozsprint debriefing: \uD83C\uDF68\uD83C\uDF66with @betatim! \uD83C\uDF89",
  "id" : 876109861255303168,
  "created_at" : "2017-06-17 16:10:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane McKee",
      "screen_name" : "shanemuk",
      "indices" : [ 3, 12 ],
      "id_str" : "38022768",
      "id" : 38022768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "876021856448466948",
  "text" : "RT @shanemuk: \"A GWAS of 100,000 GWAS researchers has uncovered 500 novel variants associated with wanting to do Genome Wide Association St\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "876013258288898048",
    "text" : "\"A GWAS of 100,000 GWAS researchers has uncovered 500 novel variants associated with wanting to do Genome Wide Association Studies.\"",
    "id" : 876013258288898048,
    "created_at" : "2017-06-17 09:46:50 +0000",
    "user" : {
      "name" : "Shane McKee",
      "screen_name" : "shanemuk",
      "protected" : false,
      "id_str" : "38022768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/891197562459484160\/rmpvnmiJ_normal.jpg",
      "id" : 38022768,
      "verified" : false
    }
  },
  "id" : 876021856448466948,
  "created_at" : "2017-06-17 10:21:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura J. Wilkinson",
      "screen_name" : "laurajwilkinson",
      "indices" : [ 3, 19 ],
      "id_str" : "22655246",
      "id" : 22655246
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 102, 118 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "875791805794701312",
  "text" : "RT @laurajwilkinson: A closer look at the Sci-Hub corpus: what is being downloaded and from where? by @gedankenstuecke\n\nhttps:\/\/t.co\/gAhlcC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 81, 97 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/gAhlcC4dM4",
        "expanded_url" : "http:\/\/blogs.lse.ac.uk\/impactofsocialsciences\/2017\/06\/12\/a-closer-look-at-the-sci-hub-corpus-what-is-being-downloaded-and-from-where\/",
        "display_url" : "blogs.lse.ac.uk\/impactofsocial\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "875725407785537540",
    "text" : "A closer look at the Sci-Hub corpus: what is being downloaded and from where? by @gedankenstuecke\n\nhttps:\/\/t.co\/gAhlcC4dM4",
    "id" : 875725407785537540,
    "created_at" : "2017-06-16 14:43:02 +0000",
    "user" : {
      "name" : "Laura J. Wilkinson",
      "screen_name" : "laurajwilkinson",
      "protected" : false,
      "id_str" : "22655246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841958801511194627\/17ByxESa_normal.jpg",
      "id" : 22655246,
      "verified" : false
    }
  },
  "id" : 875791805794701312,
  "created_at" : "2017-06-16 19:06:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "Bruno Vieira",
      "screen_name" : "bmpvieira",
      "indices" : [ 11, 21 ],
      "id_str" : "55388565",
      "id" : 55388565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "875662116765782016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35909924154767, 8.587566983692735 ]
  },
  "id_str" : "875715559312281601",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j @bmpvieira I do this much more often than I would like to! \uD83D\uDE02",
  "id" : 875715559312281601,
  "in_reply_to_status_id" : 875662116765782016,
  "created_at" : "2017-06-16 14:03:54 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Brain&BeerBCN",
      "screen_name" : "BrainBeerBCN",
      "indices" : [ 10, 23 ],
      "id_str" : "715953637298683904",
      "id" : 715953637298683904
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 24, 37 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "875432482035965952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35935461177735, 8.587834774981802 ]
  },
  "id_str" : "875656846131871744",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @BrainBeerBCN @jeroenbosman That looks cool!",
  "id" : 875656846131871744,
  "in_reply_to_status_id" : 875432482035965952,
  "created_at" : "2017-06-16 10:10:35 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "875455351033704448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35913333171219, 8.587758343563136 ]
  },
  "id_str" : "875602216731549696",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna \uD83D\uDE0D",
  "id" : 875602216731549696,
  "in_reply_to_status_id" : 875455351033704448,
  "created_at" : "2017-06-16 06:33:31 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 0, 11 ],
      "id_str" : "20342875",
      "id" : 20342875
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 12, 26 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "875410230108200963",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35947061190822, 8.588169699290411 ]
  },
  "id_str" : "875430248011182080",
  "in_reply_to_user_id" : 20342875,
  "text" : "@LouWoodley @Protohedgehog That\u2019s cool, thanks!",
  "id" : 875430248011182080,
  "in_reply_to_status_id" : 875410230108200963,
  "created_at" : "2017-06-15 19:10:10 +0000",
  "in_reply_to_screen_name" : "LouWoodley",
  "in_reply_to_user_id_str" : "20342875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Colper Science",
      "screen_name" : "Colper_Science",
      "indices" : [ 24, 39 ],
      "id_str" : "831947517424234496",
      "id" : 831947517424234496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "875369816118394880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35946473166092, 8.588172730422368 ]
  },
  "id_str" : "875400933240434688",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski Great, @Colper_Science, you take it from here! \uD83D\uDE0A",
  "id" : 875400933240434688,
  "in_reply_to_status_id" : 875369816118394880,
  "created_at" : "2017-06-15 17:13:41 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/vcisxkYOtE",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/875286779372425216",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35934859460147, 8.587795792684863 ]
  },
  "id_str" : "875362015031832577",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski would you be up for it? Here\u2019s the episode they did w\/ me about openSNP. https:\/\/t.co\/vcisxkYOtE",
  "id" : 875362015031832577,
  "created_at" : "2017-06-15 14:39:02 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Colper Science",
      "screen_name" : "Colper_Science",
      "indices" : [ 29, 44 ],
      "id_str" : "831947517424234496",
      "id" : 831947517424234496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35934824001304, 8.587795358945653 ]
  },
  "id_str" : "875362007209435136",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski The guys of @Colper_Science are looking for someone to interview for a podcast episode about cit sci &amp; gamification.",
  "id" : 875362007209435136,
  "created_at" : "2017-06-15 14:39:00 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Jef Ausloos",
      "screen_name" : "Jausl00s",
      "indices" : [ 10, 19 ],
      "id_str" : "132647934",
      "id" : 132647934
    }, {
      "name" : "Dominique Soenens",
      "screen_name" : "Dsoenens",
      "indices" : [ 20, 29 ],
      "id_str" : "381074489",
      "id" : 381074489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "875347988062900225",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35930024760696, 8.58774052998477 ]
  },
  "id_str" : "875348249414168576",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @Jausl00s @Dsoenens thanks, happy to talk about it.",
  "id" : 875348249414168576,
  "in_reply_to_status_id" : 875347988062900225,
  "created_at" : "2017-06-15 13:44:20 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Research Bazaar",
      "screen_name" : "ResBaz",
      "indices" : [ 55, 62 ],
      "id_str" : "2252889422",
      "id" : 2252889422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "875333755958960130",
  "text" : "RT @PhilippBayer: We've started to plan the program of @ResBaz Feb 2018 at UWA in Perth - if you want to help out or present a 3 hour works\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Research Bazaar",
        "screen_name" : "ResBaz",
        "indices" : [ 37, 44 ],
        "id_str" : "2252889422",
        "id" : 2252889422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "875259232462880772",
    "text" : "We've started to plan the program of @ResBaz Feb 2018 at UWA in Perth - if you want to help out or present a 3 hour workshop, contact me!",
    "id" : 875259232462880772,
    "created_at" : "2017-06-15 07:50:37 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 875333755958960130,
  "created_at" : "2017-06-15 12:46:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Arnold \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "DaveArnold91",
      "indices" : [ 0, 13 ],
      "id_str" : "536465090",
      "id" : 536465090
    }, {
      "name" : "Naturkundemuseum",
      "screen_name" : "MfNBerlin",
      "indices" : [ 14, 24 ],
      "id_str" : "47616261",
      "id" : 47616261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "875258332327661568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35926006925046, 8.587651150309096 ]
  },
  "id_str" : "875333566980292611",
  "in_reply_to_user_id" : 536465090,
  "text" : "@DaveArnold91 @MfNBerlin I love those! \uD83D\uDE0D",
  "id" : 875333566980292611,
  "in_reply_to_status_id" : 875258332327661568,
  "created_at" : "2017-06-15 12:45:59 +0000",
  "in_reply_to_screen_name" : "DaveArnold91",
  "in_reply_to_user_id_str" : "536465090",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 0, 14 ],
      "id_str" : "15090415",
      "id" : 15090415
    }, {
      "name" : "Teresa Santos",
      "screen_name" : "tessalsantos",
      "indices" : [ 15, 28 ],
      "id_str" : "1101161509",
      "id" : 1101161509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "875290602589626368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.5127755301525, 8.860482014723923 ]
  },
  "id_str" : "875294777201315840",
  "in_reply_to_user_id" : 15090415,
  "text" : "@annakrystalli @tessalsantos Well done! \uD83D\uDC96",
  "id" : 875294777201315840,
  "in_reply_to_status_id" : 875290602589626368,
  "created_at" : "2017-06-15 10:11:51 +0000",
  "in_reply_to_screen_name" : "annakrystalli",
  "in_reply_to_user_id_str" : "15090415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 0, 14 ],
      "id_str" : "15090415",
      "id" : 15090415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.74150631022522, 9.033645512544581 ]
  },
  "id_str" : "875287458409263104",
  "in_reply_to_user_id" : 15090415,
  "text" : "@annakrystalli awesome new avatar! \uD83D\uDE0D",
  "id" : 875287458409263104,
  "created_at" : "2017-06-15 09:42:46 +0000",
  "in_reply_to_screen_name" : "annakrystalli",
  "in_reply_to_user_id_str" : "15090415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 3, 18 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 129, 152 ],
      "url" : "https:\/\/t.co\/NQ8BRlnluD",
      "expanded_url" : "https:\/\/twitter.com\/Colper_Science\/status\/875219799911124992",
      "display_url" : "twitter.com\/Colper_Science\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.7415229063935, 9.033646518372962 ]
  },
  "id_str" : "875286779372425216",
  "text" : "My @MozOpenLeaders mentees started a podcast about all thing open. And they asked me to be interviewee #2. Well done! #mozsprint https:\/\/t.co\/NQ8BRlnluD",
  "id" : 875286779372425216,
  "created_at" : "2017-06-15 09:40:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/8qE8iJCmao",
      "expanded_url" : "https:\/\/twitter.com\/justinwolfers\/status\/666448547097677829",
      "display_url" : "twitter.com\/justinwolfers\/\u2026"
    }, {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/6K1YGDbW6h",
      "expanded_url" : "https:\/\/twitter.com\/chrisalbon\/status\/874683365865029632",
      "display_url" : "twitter.com\/chrisalbon\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11396253123289, 8.753151178185753 ]
  },
  "id_str" : "875249366927376384",
  "text" : "My favorite way to remember what\u2019s a type I and type II error: https:\/\/t.co\/8qE8iJCmao https:\/\/t.co\/6K1YGDbW6h",
  "id" : 875249366927376384,
  "created_at" : "2017-06-15 07:11:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurent Karila",
      "screen_name" : "laurentKarila",
      "indices" : [ 15, 29 ],
      "id_str" : "258389296",
      "id" : 258389296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "875239429379698692",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399881560664, 8.753340170832386 ]
  },
  "id_str" : "875240254550282240",
  "in_reply_to_user_id" : 2968079445,
  "text" : "@AnneAdamPluen @laurentKarila \uD83E\uDD18\uD83E\uDD18\uD83E\uDD18\uD83C\uDFB8",
  "id" : 875240254550282240,
  "in_reply_to_status_id" : 875239429379698692,
  "created_at" : "2017-06-15 06:35:12 +0000",
  "in_reply_to_screen_name" : "AnneHTTP404",
  "in_reply_to_user_id_str" : "2968079445",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 3, 14 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "indices" : [ 114, 128 ],
      "id_str" : "3209949862",
      "id" : 3209949862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "875143977271480320",
  "text" : "RT @rchampieux: Essential &amp; helpful thoughts on recognizing and being critical of our roles as gentrifiers by @AprilHathcock: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "April H.",
        "screen_name" : "AprilHathcock",
        "indices" : [ 98, 112 ],
        "id_str" : "3209949862",
        "id" : 3209949862
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/NngsTqy4bv",
        "expanded_url" : "https:\/\/aprilhathcock.wordpress.com\/2017\/05\/29\/how-to-be-less-of-a-gentrifier\/",
        "display_url" : "aprilhathcock.wordpress.com\/2017\/05\/29\/how\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "875079727698120706",
    "text" : "Essential &amp; helpful thoughts on recognizing and being critical of our roles as gentrifiers by @AprilHathcock: https:\/\/t.co\/NngsTqy4bv",
    "id" : 875079727698120706,
    "created_at" : "2017-06-14 19:57:19 +0000",
    "user" : {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "protected" : false,
      "id_str" : "20653310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/77507928\/c016m_normal.jpg",
      "id" : 20653310,
      "verified" : false
    }
  },
  "id" : 875143977271480320,
  "created_at" : "2017-06-15 00:12:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/875047950765916162\/photo\/1",
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/4UfCiVdqW0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DCTLcO_XgAAXcsB.jpg",
      "id_str" : "875047913537372160",
      "id" : 875047913537372160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DCTLcO_XgAAXcsB.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/4UfCiVdqW0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400496492607, 8.753355264693791 ]
  },
  "id_str" : "875047950765916162",
  "text" : "Team \uD83D\uDC31 SAR\u2026 \uD83D\uDC08 https:\/\/t.co\/4UfCiVdqW0",
  "id" : 875047950765916162,
  "created_at" : "2017-06-14 17:51:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VALIUM",
      "screen_name" : "alibi_rage",
      "indices" : [ 0, 11 ],
      "id_str" : "971867420",
      "id" : 971867420
    }, {
      "name" : "Ragetina",
      "screen_name" : "Ragetina",
      "indices" : [ 12, 21 ],
      "id_str" : "819601236",
      "id" : 819601236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "875036094198407168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400399389115, 8.753363126325153 ]
  },
  "id_str" : "875045189060091908",
  "in_reply_to_user_id" : 971867420,
  "text" : "@alibi_rage @Ragetina awesome!",
  "id" : 875045189060091908,
  "in_reply_to_status_id" : 875036094198407168,
  "created_at" : "2017-06-14 17:40:05 +0000",
  "in_reply_to_screen_name" : "alibi_rage",
  "in_reply_to_user_id_str" : "971867420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "874992880359702528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723642137293, 8.627540289145506 ]
  },
  "id_str" : "874993731904131073",
  "in_reply_to_user_id" : 14286491,
  "text" : "Altmetrics says only 25% of the people tweeting about the paper are scientists (~35% on biorxiv). Go figure who really profits from Sci-Hub.",
  "id" : 874993731904131073,
  "in_reply_to_status_id" : 874992880359702528,
  "created_at" : "2017-06-14 14:15:36 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 130, 153 ],
      "url" : "https:\/\/t.co\/zIaQ7UDxSq",
      "expanded_url" : "https:\/\/twitter.com\/LSEImpactBlog\/status\/874899215671058433",
      "display_url" : "twitter.com\/LSEImpactBlog\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230518673068, 8.627505184978533 ]
  },
  "id_str" : "874992880359702528",
  "text" : "I\u2019m impressed by the interest in the Sci-Hub research. Looks like it struck a nerve outside traditional academic circles as well. https:\/\/t.co\/zIaQ7UDxSq",
  "id" : 874992880359702528,
  "created_at" : "2017-06-14 14:12:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "874972249710841857",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230872533935, 8.627504951794036 ]
  },
  "id_str" : "874977604662644738",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna Schade! \uD83D\uDE1E",
  "id" : 874977604662644738,
  "in_reply_to_status_id" : 874972249710841857,
  "created_at" : "2017-06-14 13:11:31 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "874954653129216001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17242351619665, 8.627590167787938 ]
  },
  "id_str" : "874957944550567936",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a don\u2019t know for sure yet, I want to make it, but my work schedule might not allow it \uD83D\uDE22",
  "id" : 874957944550567936,
  "in_reply_to_status_id" : 874954653129216001,
  "created_at" : "2017-06-14 11:53:24 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "874910847096762368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234975078992, 8.627539564138344 ]
  },
  "id_str" : "874945764828622848",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna kannst du die Stelle ggf \u00FCber Google Books und damit die Seitenzahl finden?",
  "id" : 874945764828622848,
  "in_reply_to_status_id" : 874910847096762368,
  "created_at" : "2017-06-14 11:05:00 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Appropriate Tributes",
      "screen_name" : "godtributes",
      "indices" : [ 0, 12 ],
      "id_str" : "2566358196",
      "id" : 2566358196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "874904554252513280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230143218102, 8.627506763140788 ]
  },
  "id_str" : "874907248992169986",
  "in_reply_to_user_id" : 2566358196,
  "text" : "@godtributes Can\u2019t argue with that!",
  "id" : 874907248992169986,
  "in_reply_to_status_id" : 874904554252513280,
  "created_at" : "2017-06-14 08:31:57 +0000",
  "in_reply_to_screen_name" : "godtributes",
  "in_reply_to_user_id_str" : "2566358196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/874904486774538240\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/f1kl2MTWPi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DCRI_JeXcAIboeX.jpg",
      "id_str" : "874904477328961538",
      "id" : 874904477328961538,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DCRI_JeXcAIboeX.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/f1kl2MTWPi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230501265687, 8.627505008633689 ]
  },
  "id_str" : "874904486774538240",
  "text" : "Reading \u2018This Is What a Librarian Looks Like\u2019 and totally jealous of this tattoo! \uD83D\uDE0D \uD83D\uDCD6 https:\/\/t.co\/f1kl2MTWPi",
  "id" : 874904486774538240,
  "created_at" : "2017-06-14 08:20:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 84, 100 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/AJjoDtiHCU",
      "expanded_url" : "https:\/\/twitter.com\/OBF_BOSC\/status\/874646469764014082",
      "display_url" : "twitter.com\/OBF_BOSC\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400285916321, 8.753361386622673 ]
  },
  "id_str" : "874757652101951490",
  "text" : "Dr. Loman or: How I Learned to Stop Worrying and Love the Bradyrhizobium. #BOSC2017 @pathogenomenick https:\/\/t.co\/AJjoDtiHCU",
  "id" : 874757652101951490,
  "created_at" : "2017-06-13 22:37:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diego Gomez",
      "screen_name" : "diegogomezhoyos",
      "indices" : [ 24, 40 ],
      "id_str" : "402519372",
      "id" : 402519372
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 44, 52 ]
    }, {
      "text" : "CompartirNoEsDelito",
      "indices" : [ 94, 114 ]
    }, {
      "text" : "sharingisnotacrime",
      "indices" : [ 115, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/gtYt0P5gNT",
      "expanded_url" : "http:\/\/sharingisnotacrime.org\/",
      "display_url" : "sharingisnotacrime.org"
    }, {
      "indices" : [ 135, 158 ],
      "url" : "https:\/\/t.co\/K3F3407A2G",
      "expanded_url" : "https:\/\/twitter.com\/InquisitiveVi\/status\/798488066818187264",
      "display_url" : "twitter.com\/InquisitiveVi\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399893846099, 8.753349091277933 ]
  },
  "id_str" : "874733120083427328",
  "text" : "It was an honor to meet @diegogomezhoyos at #opencon. Help him now at https:\/\/t.co\/gtYt0P5gNT #CompartirNoEsDelito #sharingisnotacrime https:\/\/t.co\/K3F3407A2G",
  "id" : 874733120083427328,
  "created_at" : "2017-06-13 21:00:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SharingIsNotACrime",
      "indices" : [ 97, 116 ]
    }, {
      "text" : "CompartirNoEsDelito",
      "indices" : [ 117, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "874611550547529730",
  "text" : "RT @gedankenstuecke: Diego G\u00F3mez needs your help to fight the appeal of his case. Donate for him #SharingIsNotACrime #CompartirNoEsDelito h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SharingIsNotACrime",
        "indices" : [ 76, 95 ]
      }, {
        "text" : "CompartirNoEsDelito",
        "indices" : [ 96, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/zreiIeuJQz",
        "expanded_url" : "http:\/\/sharingisnotacrime.org",
        "display_url" : "sharingisnotacrime.org"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.17251920537322, 8.62768950623635 ]
    },
    "id_str" : "874537467600400384",
    "text" : "Diego G\u00F3mez needs your help to fight the appeal of his case. Donate for him #SharingIsNotACrime #CompartirNoEsDelito https:\/\/t.co\/zreiIeuJQz",
    "id" : 874537467600400384,
    "created_at" : "2017-06-13 08:02:35 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 874611550547529730,
  "created_at" : "2017-06-13 12:56:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SharingIsNotACrime",
      "indices" : [ 76, 95 ]
    }, {
      "text" : "CompartirNoEsDelito",
      "indices" : [ 96, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/zreiIeuJQz",
      "expanded_url" : "http:\/\/sharingisnotacrime.org",
      "display_url" : "sharingisnotacrime.org"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17251920537322, 8.62768950623635 ]
  },
  "id_str" : "874537467600400384",
  "text" : "Diego G\u00F3mez needs your help to fight the appeal of his case. Donate for him #SharingIsNotACrime #CompartirNoEsDelito https:\/\/t.co\/zreiIeuJQz",
  "id" : 874537467600400384,
  "created_at" : "2017-06-13 08:02:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Curry",
      "screen_name" : "Stephen_Curry",
      "indices" : [ 0, 14 ],
      "id_str" : "41358714",
      "id" : 41358714
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/yMNklTg8Hm",
      "expanded_url" : "http:\/\/ruleofthirds.de\/nature-malvertising\/",
      "display_url" : "ruleofthirds.de\/nature-malvert\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "874300110762647554",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1142227882986, 8.7535591051064 ]
  },
  "id_str" : "874318828473397248",
  "in_reply_to_user_id" : 41358714,
  "text" : "@Stephen_Curry Well, c.f. https:\/\/t.co\/yMNklTg8Hm",
  "id" : 874318828473397248,
  "in_reply_to_status_id" : 874300110762647554,
  "created_at" : "2017-06-12 17:33:47 +0000",
  "in_reply_to_screen_name" : "Stephen_Curry",
  "in_reply_to_user_id_str" : "41358714",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LSE Impact Blog",
      "screen_name" : "LSEImpactBlog",
      "indices" : [ 60, 74 ],
      "id_str" : "273935884",
      "id" : 273935884
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/nNw70RpU4K",
      "expanded_url" : "https:\/\/twitter.com\/LSEImpactBlog\/status\/874205552087367680",
      "display_url" : "twitter.com\/LSEImpactBlog\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "874205552087367680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230515730798, 8.627507650578178 ]
  },
  "id_str" : "874284695277764609",
  "in_reply_to_user_id" : 273935884,
  "text" : "I wrote a short summary of my research into Sci-Hub for the @LSEImpactBlog, find it here: https:\/\/t.co\/nNw70RpU4K",
  "id" : 874284695277764609,
  "in_reply_to_status_id" : 874205552087367680,
  "created_at" : "2017-06-12 15:18:09 +0000",
  "in_reply_to_screen_name" : "LSEImpactBlog",
  "in_reply_to_user_id_str" : "273935884",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 9, 19 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Dani Rabaiotti",
      "screen_name" : "DaniRabaiotti",
      "indices" : [ 20, 34 ],
      "id_str" : "636216638",
      "id" : 636216638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "874243755544645633",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17919383712133, 8.614022141738516 ]
  },
  "id_str" : "874247333533319168",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Julie_B92 @DaniRabaiotti I\u2019ll try to speak out more. Know I\u2019m failing there right now.",
  "id" : 874247333533319168,
  "in_reply_to_status_id" : 874243755544645633,
  "created_at" : "2017-06-12 12:49:41 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 9, 19 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Dani Rabaiotti",
      "screen_name" : "DaniRabaiotti",
      "indices" : [ 20, 34 ],
      "id_str" : "636216638",
      "id" : 636216638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "874240211454218240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237008184158, 8.627314481402708 ]
  },
  "id_str" : "874242225525444609",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Julie_B92 @DaniRabaiotti \uD83D\uDE4F",
  "id" : 874242225525444609,
  "in_reply_to_status_id" : 874240211454218240,
  "created_at" : "2017-06-12 12:29:23 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LSE Impact Blog",
      "screen_name" : "LSEImpactBlog",
      "indices" : [ 3, 17 ],
      "id_str" : "273935884",
      "id" : 273935884
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/D0Z5AmPyU6",
      "expanded_url" : "http:\/\/ow.ly\/jbsV30cvN5c",
      "display_url" : "ow.ly\/jbsV30cvN5c"
    } ]
  },
  "geo" : { },
  "id_str" : "874211448871948290",
  "text" : "RT @LSEImpactBlog: New: A closer look at the Sci-Hub corpus - what is being downloaded and from where? https:\/\/t.co\/D0Z5AmPyU6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/D0Z5AmPyU6",
        "expanded_url" : "http:\/\/ow.ly\/jbsV30cvN5c",
        "display_url" : "ow.ly\/jbsV30cvN5c"
      } ]
    },
    "geo" : { },
    "id_str" : "874205552087367680",
    "text" : "New: A closer look at the Sci-Hub corpus - what is being downloaded and from where? https:\/\/t.co\/D0Z5AmPyU6",
    "id" : 874205552087367680,
    "created_at" : "2017-06-12 10:03:40 +0000",
    "user" : {
      "name" : "LSE Impact Blog",
      "screen_name" : "LSEImpactBlog",
      "protected" : false,
      "id_str" : "273935884",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908703729813254145\/hfgw7Shs_normal.jpg",
      "id" : 273935884,
      "verified" : false
    }
  },
  "id" : 874211448871948290,
  "created_at" : "2017-06-12 10:27:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Klein",
      "screen_name" : "metasj",
      "indices" : [ 0, 7 ],
      "id_str" : "75123",
      "id" : 75123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/tECgOd2nWp",
      "expanded_url" : "http:\/\/m.20min.ch\/schweiz\/zuerich\/story\/13559548",
      "display_url" : "m.20min.ch\/schweiz\/zueric\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "873597101204287488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35816895637459, 8.565490302051472 ]
  },
  "id_str" : "873597359229476865",
  "in_reply_to_user_id" : 75123,
  "text" : "@metasj It\u2019s a writer who put this on his car as a joke. (German language source: https:\/\/t.co\/tECgOd2nWp)",
  "id" : 873597359229476865,
  "in_reply_to_status_id" : 873597101204287488,
  "created_at" : "2017-06-10 17:46:55 +0000",
  "in_reply_to_screen_name" : "metasj",
  "in_reply_to_user_id_str" : "75123",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/873596029748359168\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/B0KY6RLp3E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DB-i9XyWsAEkn0v.jpg",
      "id_str" : "873596027974103041",
      "id" : 873596027974103041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DB-i9XyWsAEkn0v.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/B0KY6RLp3E"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "873596029748359168",
  "text" : "Finally saw Zurich's \"Department of Irony\" today! https:\/\/t.co\/B0KY6RLp3E",
  "id" : 873596029748359168,
  "created_at" : "2017-06-10 17:41:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/873583173774565376\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/3xWSYiRzkE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DB-XQkYWsAERjev.jpg",
      "id_str" : "873583163632693249",
      "id" : 873583163632693249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DB-XQkYWsAERjev.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/3xWSYiRzkE"
    } ],
    "hashtags" : [ {
      "text" : "mycheckpoint",
      "indices" : [ 26, 39 ]
    }, {
      "text" : "ZurichPride",
      "indices" : [ 67, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37062951522718, 8.529524114258228 ]
  },
  "id_str" : "873583173774565376",
  "text" : "Last year the people from #mycheckpoint did ~400 free HIV tests at #ZurichPride. This year they expect &gt;600. https:\/\/t.co\/3xWSYiRzkE",
  "id" : 873583173774565376,
  "created_at" : "2017-06-10 16:50:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/873564011425652736\/photo\/1",
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/aR6llXAJUK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DB-F1qOXgAIrvVd.jpg",
      "id_str" : "873564009647276034",
      "id" : 873564009647276034,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DB-F1qOXgAIrvVd.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/aR6llXAJUK"
    } ],
    "hashtags" : [ {
      "text" : "ZurichPride",
      "indices" : [ 9, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "873564011425652736",
  "text" : "Omnomnom #ZurichPride https:\/\/t.co\/aR6llXAJUK",
  "id" : 873564011425652736,
  "created_at" : "2017-06-10 15:34:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zurichpride",
      "indices" : [ 22, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/jEi65nK9An",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BVKR44hlDkg\/",
      "display_url" : "instagram.com\/p\/BVKR44hlDkg\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3667, 8.55 ]
  },
  "id_str" : "873531269547798528",
  "text" : "Stonewall remembrance #zurichpride @ Z\u00FCrich, Switzerland https:\/\/t.co\/jEi65nK9An",
  "id" : 873531269547798528,
  "created_at" : "2017-06-10 13:24:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/873524226703151109\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/iGJPzgMVaj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DB9hpOEXkAIa7Xd.jpg",
      "id_str" : "873524213512114178",
      "id" : 873524213512114178,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DB9hpOEXkAIa7Xd.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/iGJPzgMVaj"
    } ],
    "hashtags" : [ {
      "text" : "zurichpride",
      "indices" : [ 42, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37446945165039, 8.540125004955138 ]
  },
  "id_str" : "873524226703151109",
  "text" : "No ottering. Stop suppressing fluffiness! #zurichpride https:\/\/t.co\/iGJPzgMVaj",
  "id" : 873524226703151109,
  "created_at" : "2017-06-10 12:56:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 0, 16 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 17, 32 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Teon L Brooks, PhD",
      "screen_name" : "teon_io",
      "indices" : [ 33, 41 ],
      "id_str" : "30960103",
      "id" : 30960103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "873442714318237697",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35914858993828, 8.587658023469697 ]
  },
  "id_str" : "873452171165126656",
  "in_reply_to_user_id" : 383289779,
  "text" : "@daniellecrobins @MozillaScience @teon_io safe travels!",
  "id" : 873452171165126656,
  "in_reply_to_status_id" : 873442714318237697,
  "created_at" : "2017-06-10 08:10:00 +0000",
  "in_reply_to_screen_name" : "daniellecrobins",
  "in_reply_to_user_id_str" : "383289779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Method",
      "screen_name" : "methodpodcast",
      "indices" : [ 3, 17 ],
      "id_str" : "841811845811974146",
      "id" : 841811845811974146
    }, {
      "name" : "K. Jane Burpee",
      "screen_name" : "kjane",
      "indices" : [ 95, 101 ],
      "id_str" : "772689",
      "id" : 772689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "podcasts",
      "indices" : [ 31, 40 ]
    }, {
      "text" : "science",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "873252937069465601",
  "text" : "RT @methodpodcast: Do you love #podcasts + #science? Of course you do! Listen to the brilliant @kjane in a new episode by our new #mozsprin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "K. Jane Burpee",
        "screen_name" : "kjane",
        "indices" : [ 76, 82 ],
        "id_str" : "772689",
        "id" : 772689
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "podcasts",
        "indices" : [ 12, 21 ]
      }, {
        "text" : "science",
        "indices" : [ 24, 32 ]
      }, {
        "text" : "mozsprint",
        "indices" : [ 111, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/bvoKrR2JC3",
        "expanded_url" : "https:\/\/twitter.com\/Colper_Science\/status\/873008482370428928",
        "display_url" : "twitter.com\/Colper_Science\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "873189451052318720",
    "text" : "Do you love #podcasts + #science? Of course you do! Listen to the brilliant @kjane in a new episode by our new #mozsprint friends. \uD83C\uDF99\uFE0F\uD83D\uDC69\uD83C\uDFFE\u200D\uD83D\uDD2C https:\/\/t.co\/bvoKrR2JC3",
    "id" : 873189451052318720,
    "created_at" : "2017-06-09 14:46:02 +0000",
    "user" : {
      "name" : "The Method",
      "screen_name" : "methodpodcast",
      "protected" : false,
      "id_str" : "841811845811974146",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841813767092547584\/3m_KI3Xl_normal.jpg",
      "id" : 841811845811974146,
      "verified" : false
    }
  },
  "id" : 873252937069465601,
  "created_at" : "2017-06-09 18:58:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/873235324297764867\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/iASSrjQaAL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DB5a5GIW0AAt5dm.jpg",
      "id_str" : "873235314701160448",
      "id" : 873235314701160448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DB5a5GIW0AAt5dm.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/iASSrjQaAL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "873226528016003073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.374831251667, 8.516842471211362 ]
  },
  "id_str" : "873235324297764867",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim Made it! https:\/\/t.co\/iASSrjQaAL",
  "id" : 873235324297764867,
  "in_reply_to_status_id" : 873226528016003073,
  "created_at" : "2017-06-09 17:48:19 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/873229478901755904\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/sRLLjwVRKC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DB5VlTdXYAEiaPq.jpg",
      "id_str" : "873229477123416065",
      "id" : 873229477123416065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DB5VlTdXYAEiaPq.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 534
      }, {
        "h" : 805,
        "resize" : "fit",
        "w" : 632
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 805,
        "resize" : "fit",
        "w" : 632
      }, {
        "h" : 805,
        "resize" : "fit",
        "w" : 632
      } ],
      "display_url" : "pic.twitter.com\/sRLLjwVRKC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "873229478901755904",
  "text" : "That's a cool Google Maps feature. Anyone around for it tomorrow? \uD83D\uDE0A https:\/\/t.co\/sRLLjwVRKC",
  "id" : 873229478901755904,
  "created_at" : "2017-06-09 17:25:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "873226528016003073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37538831778557, 8.516310760759298 ]
  },
  "id_str" : "873229006287642624",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim Perfect business model. Predatory ice cream publishing.",
  "id" : 873229006287642624,
  "in_reply_to_status_id" : 873226528016003073,
  "created_at" : "2017-06-09 17:23:13 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "873224393756954626",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37528563947172, 8.516638828449432 ]
  },
  "id_str" : "873224797840437252",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim The queue now was so long that we\u2019ll go for dinner first and then try again. \uD83D\uDE02",
  "id" : 873224797840437252,
  "in_reply_to_status_id" : 873224393756954626,
  "created_at" : "2017-06-09 17:06:30 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 19, 27 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/873217205441372161\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/vfKLLLgxwh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DB5KabhXoAAaGHh.jpg",
      "id_str" : "873217195681226752",
      "id" : 873217195681226752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DB5KabhXoAAaGHh.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/vfKLLLgxwh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37479789652617, 8.517036214478795 ]
  },
  "id_str" : "873217205441372161",
  "text" : "Look what I found, @betatim! \uD83C\uDF68\uD83C\uDF66\uD83D\uDE0D https:\/\/t.co\/vfKLLLgxwh",
  "id" : 873217205441372161,
  "created_at" : "2017-06-09 16:36:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "873065429358358528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35927456189604, 8.587773525200527 ]
  },
  "id_str" : "873083978890199044",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB That\u2019s great, allows you to end with some more emoji than usually! \uD83C\uDF89\uD83D\uDE02",
  "id" : 873083978890199044,
  "in_reply_to_status_id" : 873065429358358528,
  "created_at" : "2017-06-09 07:46:56 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua McClure",
      "screen_name" : "joshuamcclure",
      "indices" : [ 0, 14 ],
      "id_str" : "14209307",
      "id" : 14209307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872923857883062273",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35943409434901, 8.587915884265596 ]
  },
  "id_str" : "872934876441440256",
  "in_reply_to_user_id" : 14209307,
  "text" : "@joshuamcclure Thanks!",
  "id" : 872934876441440256,
  "in_reply_to_status_id" : 872923857883062273,
  "created_at" : "2017-06-08 21:54:27 +0000",
  "in_reply_to_screen_name" : "joshuamcclure",
  "in_reply_to_user_id_str" : "14209307",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/872894776491864064\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/3xrwplNl5Y",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DB0lKNkXgAI4QBb.jpg",
      "id_str" : "872894760150859778",
      "id" : 872894760150859778,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DB0lKNkXgAI4QBb.jpg",
      "sizes" : [ {
        "h" : 318,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/3xrwplNl5Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "872894776491864064",
  "text" : "The bureaucracy did its best to prevent it, but \uD83D\uDC70\uD83C\uDFFC\uD83D\uDC8D\uD83C\uDFA9\uD83D\uDCC6\u2705 https:\/\/t.co\/3xrwplNl5Y",
  "id" : 872894776491864064,
  "created_at" : "2017-06-08 19:15:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fbz",
      "screen_name" : "fbz",
      "indices" : [ 0, 4 ],
      "id_str" : "15282432",
      "id" : 15282432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872824432473001985",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35935696083547, 8.587822367551762 ]
  },
  "id_str" : "872824498948591617",
  "in_reply_to_user_id" : 15282432,
  "text" : "@fbz please let me know when that happens!",
  "id" : 872824498948591617,
  "in_reply_to_status_id" : 872824432473001985,
  "created_at" : "2017-06-08 14:35:51 +0000",
  "in_reply_to_screen_name" : "fbz",
  "in_reply_to_user_id_str" : "15282432",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/cgHVRc3acw",
      "expanded_url" : "https:\/\/twitter.com\/MozillaScience\/status\/872809864250175490",
      "display_url" : "twitter.com\/MozillaScience\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35899780582194, 8.587427489556745 ]
  },
  "id_str" : "872810325677973504",
  "text" : "Looking forward to it! \uD83C\uDF89 https:\/\/t.co\/cgHVRc3acw",
  "id" : 872810325677973504,
  "created_at" : "2017-06-08 13:39:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TDM",
      "indices" : [ 41, 45 ]
    }, {
      "text" : "copyright",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/0J5sQNnNFb",
      "expanded_url" : "https:\/\/juliareda.eu\/2017\/05\/alternative-compromise\/",
      "display_url" : "juliareda.eu\/2017\/05\/altern\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "872788714791084034",
  "text" : "RT @Senficon: Rapporteur\u2019s compromise on #TDM was rejected. Will have to analyse the final text on TDM. https:\/\/t.co\/0J5sQNnNFb #copyright\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/872735868917776384\/photo\/1",
        "indices" : [ 125, 148 ],
        "url" : "https:\/\/t.co\/aC4aDawKMo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DByUpFIXcAAUs1c.jpg",
        "id_str" : "872735861275848704",
        "id" : 872735861275848704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DByUpFIXcAAUs1c.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 697,
          "resize" : "fit",
          "w" : 1046
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 697,
          "resize" : "fit",
          "w" : 1046
        }, {
          "h" : 697,
          "resize" : "fit",
          "w" : 1046
        } ],
        "display_url" : "pic.twitter.com\/aC4aDawKMo"
      } ],
      "hashtags" : [ {
        "text" : "TDM",
        "indices" : [ 27, 31 ]
      }, {
        "text" : "copyright",
        "indices" : [ 114, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/0J5sQNnNFb",
        "expanded_url" : "https:\/\/juliareda.eu\/2017\/05\/alternative-compromise\/",
        "display_url" : "juliareda.eu\/2017\/05\/altern\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "872735449789468673",
    "geo" : { },
    "id_str" : "872735868917776384",
    "in_reply_to_user_id" : 14861745,
    "text" : "Rapporteur\u2019s compromise on #TDM was rejected. Will have to analyse the final text on TDM. https:\/\/t.co\/0J5sQNnNFb #copyright https:\/\/t.co\/aC4aDawKMo",
    "id" : 872735868917776384,
    "in_reply_to_status_id" : 872735449789468673,
    "created_at" : "2017-06-08 08:43:40 +0000",
    "in_reply_to_screen_name" : "Senficon",
    "in_reply_to_user_id_str" : "14861745",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 872788714791084034,
  "created_at" : "2017-06-08 12:13:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/PXQMsXtnYB",
      "expanded_url" : "https:\/\/ironholds.org\/not-about-image\/",
      "display_url" : "ironholds.org\/not-about-imag\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400883585868, 8.753364393583851 ]
  },
  "id_str" : "872709524993564672",
  "text" : "Just found this now: \u201CBehaviour and Community in Open Science\u201C. Some  \uD83D\uDE1A\uD83D\uDC4C advice by @kopshtik! https:\/\/t.co\/PXQMsXtnYB",
  "id" : 872709524993564672,
  "created_at" : "2017-06-08 06:58:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fbz",
      "screen_name" : "fbz",
      "indices" : [ 0, 4 ],
      "id_str" : "15282432",
      "id" : 15282432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872625395878699008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400842921103, 8.753363519874894 ]
  },
  "id_str" : "872706436798849024",
  "in_reply_to_user_id" : 15282432,
  "text" : "@fbz Oh how much I hate myself for not contributing to the campaign, every day when I see the pictures! \uD83D\uDE0D\uD83D\uDE0D",
  "id" : 872706436798849024,
  "in_reply_to_status_id" : 872625395878699008,
  "created_at" : "2017-06-08 06:46:43 +0000",
  "in_reply_to_screen_name" : "fbz",
  "in_reply_to_user_id_str" : "15282432",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg",
      "screen_name" : "EatYourSoup1",
      "indices" : [ 0, 13 ],
      "id_str" : "824026115513679873",
      "id" : 824026115513679873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872602375864889346",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401472979365, 8.753373782814764 ]
  },
  "id_str" : "872602812399702020",
  "in_reply_to_user_id" : 824026115513679873,
  "text" : "@EatYourSoup1 Living the dream \uD83D\uDE02",
  "id" : 872602812399702020,
  "in_reply_to_status_id" : 872602375864889346,
  "created_at" : "2017-06-07 23:54:57 +0000",
  "in_reply_to_screen_name" : "EatYourSoup1",
  "in_reply_to_user_id_str" : "824026115513679873",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilyass",
      "screen_name" : "Joydisee",
      "indices" : [ 0, 9 ],
      "id_str" : "49310539",
      "id" : 49310539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872539769418522624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401457771686, 8.75337567138891 ]
  },
  "id_str" : "872541380291297280",
  "in_reply_to_user_id" : 49310539,
  "text" : "@Joydisee you did great! \uD83D\uDC4D",
  "id" : 872541380291297280,
  "in_reply_to_status_id" : 872539769418522624,
  "created_at" : "2017-06-07 19:50:50 +0000",
  "in_reply_to_screen_name" : "Joydisee",
  "in_reply_to_user_id_str" : "49310539",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Robin N. Kok",
      "screen_name" : "robinnkok",
      "indices" : [ 9, 19 ],
      "id_str" : "4841450680",
      "id" : 4841450680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872500578697584640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11264058947503, 8.755097541279913 ]
  },
  "id_str" : "872535661672374272",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @robinnkok \uD83D\uDE0D\uD83D\uDC4D",
  "id" : 872535661672374272,
  "in_reply_to_status_id" : 872500578697584640,
  "created_at" : "2017-06-07 19:28:07 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colper Science",
      "screen_name" : "Colper_Science",
      "indices" : [ 53, 68 ],
      "id_str" : "831947517424234496",
      "id" : 831947517424234496
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/872533981262204929\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ubhueme7QW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DBvdBlwXYAAS1yy.jpg",
      "id_str" : "872533972210900992",
      "id" : 872533972210900992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBvdBlwXYAAS1yy.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/ubhueme7QW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872455321809276928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11370794469766, 8.753817248027579 ]
  },
  "id_str" : "872533981262204929",
  "in_reply_to_user_id" : 14286491,
  "text" : "Speaking of speaking, I did a fun video podcast with @Colper_Science today! https:\/\/t.co\/ubhueme7QW",
  "id" : 872533981262204929,
  "in_reply_to_status_id" : 872455321809276928,
  "created_at" : "2017-06-07 19:21:26 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Robin N. Kok",
      "screen_name" : "robinnkok",
      "indices" : [ 9, 19 ],
      "id_str" : "4841450680",
      "id" : 4841450680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872492048951259137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11212785075248, 8.755209983925251 ]
  },
  "id_str" : "872492908993277953",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @robinnkok Yeah, see thread that evolved here about that experience, common theme :)",
  "id" : 872492908993277953,
  "in_reply_to_status_id" : 872492048951259137,
  "created_at" : "2017-06-07 16:38:14 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Robin N. Kok",
      "screen_name" : "robinnkok",
      "indices" : [ 9, 19 ],
      "id_str" : "4841450680",
      "id" : 4841450680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872484551582523393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401586578705, 8.75337569760411 ]
  },
  "id_str" : "872488403895451648",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @robinnkok With an Apple Watch.",
  "id" : 872488403895451648,
  "in_reply_to_status_id" : 872484551582523393,
  "created_at" : "2017-06-07 16:20:20 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin N. Kok",
      "screen_name" : "robinnkok",
      "indices" : [ 0, 10 ],
      "id_str" : "4841450680",
      "id" : 4841450680
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 11, 20 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872474468337295360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11116890660519, 8.752036437352416 ]
  },
  "id_str" : "872484116763115521",
  "in_reply_to_user_id" : 4841450680,
  "text" : "@robinnkok @madprime \u201CToday we\u2019ll read the slides together, because that\u2019s all I can offer\u201D",
  "id" : 872484116763115521,
  "in_reply_to_status_id" : 872474468337295360,
  "created_at" : "2017-06-07 16:03:18 +0000",
  "in_reply_to_screen_name" : "robinnkok",
  "in_reply_to_user_id_str" : "4841450680",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Robin N. Kok",
      "screen_name" : "robinnkok",
      "indices" : [ 10, 20 ],
      "id_str" : "4841450680",
      "id" : 4841450680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872473158229647361",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404312220412, 8.753799162813232 ]
  },
  "id_str" : "872474173288984577",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @robinnkok Yes, think if it\u2019s more my content and work instead of PPT-Karaoke it helps a lot \uD83D\uDE02",
  "id" : 872474173288984577,
  "in_reply_to_status_id" : 872473158229647361,
  "created_at" : "2017-06-07 15:23:47 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin N. Kok",
      "screen_name" : "robinnkok",
      "indices" : [ 0, 10 ],
      "id_str" : "4841450680",
      "id" : 4841450680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872457396840542208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401549309012, 8.753368635937813 ]
  },
  "id_str" : "872470520603656192",
  "in_reply_to_user_id" : 4841450680,
  "text" : "@robinnkok I think it actually is getting better for me. If it\u2019s my slides and I prepared. Instead of \u201Ctake these slides and present tomorrow\u201D",
  "id" : 872470520603656192,
  "in_reply_to_status_id" : 872457396840542208,
  "created_at" : "2017-06-07 15:09:16 +0000",
  "in_reply_to_screen_name" : "robinnkok",
  "in_reply_to_user_id_str" : "4841450680",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872458984208420865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409682449241, 8.753330777953284 ]
  },
  "id_str" : "872469796096528386",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime Starts a bit before the talk. First dip probably an artifact. Second one: after the lecture a short break and then taking the stairs.",
  "id" : 872469796096528386,
  "in_reply_to_status_id" : 872458984208420865,
  "created_at" : "2017-06-07 15:06:23 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 3, 9 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "indices" : [ 44, 59 ],
      "id_str" : "26250872",
      "id" : 26250872
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 77, 93 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenAccess",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/whX7NDUE7F",
      "expanded_url" : "https:\/\/www.chemistryworld.com\/opinion\/chemistrys-piracy-problem\/3007214.article",
      "display_url" : "chemistryworld.com\/opinion\/chemis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "872456071289458689",
  "text" : "RT @heluc: \"Chemistry has a piracy problem\" @ChemistryWorld (\u00A3) reporting on @gedankenstuecke's findings https:\/\/t.co\/whX7NDUE7F #OpenAccess",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chemistry World",
        "screen_name" : "ChemistryWorld",
        "indices" : [ 33, 48 ],
        "id_str" : "26250872",
        "id" : 26250872
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 66, 82 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenAccess",
        "indices" : [ 118, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/whX7NDUE7F",
        "expanded_url" : "https:\/\/www.chemistryworld.com\/opinion\/chemistrys-piracy-problem\/3007214.article",
        "display_url" : "chemistryworld.com\/opinion\/chemis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "872440778110504960",
    "text" : "\"Chemistry has a piracy problem\" @ChemistryWorld (\u00A3) reporting on @gedankenstuecke's findings https:\/\/t.co\/whX7NDUE7F #OpenAccess",
    "id" : 872440778110504960,
    "created_at" : "2017-06-07 13:11:05 +0000",
    "user" : {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "protected" : false,
      "id_str" : "850645992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479959658359050240\/f-1Log7L_normal.jpeg",
      "id" : 850645992,
      "verified" : false
    }
  },
  "id" : 872456071289458689,
  "created_at" : "2017-06-07 14:11:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 137, 160 ],
      "url" : "https:\/\/t.co\/TyEIQu8j7h",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/872454930023559168",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "872454930023559168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231461684514, 8.627509465505776 ]
  },
  "id_str" : "872455321809276928",
  "in_reply_to_user_id" : 14286491,
  "text" : "It\u2019s kind of hilarious how many talks and panels I give, given that I still nearly die from a heart attack when doing public speaking. \uD83D\uDE02 https:\/\/t.co\/TyEIQu8j7h",
  "id" : 872455321809276928,
  "in_reply_to_status_id" : 872454930023559168,
  "created_at" : "2017-06-07 14:08:52 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "indices" : [ 7, 22 ],
      "id_str" : "26250872",
      "id" : 26250872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872440778110504960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230581261633, 8.627512625274102 ]
  },
  "id_str" : "872454969185767427",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc @ChemistryWorld Thanks!",
  "id" : 872454969185767427,
  "in_reply_to_status_id" : 872440778110504960,
  "created_at" : "2017-06-07 14:07:28 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/872454930023559168\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/1nL4lwWjiH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DBuVIMeXgAE6kV0.jpg",
      "id_str" : "872454920846409729",
      "id" : 872454920846409729,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBuVIMeXgAE6kV0.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/1nL4lwWjiH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231997221483, 8.627509076735588 ]
  },
  "id_str" : "872454930023559168",
  "text" : "Me, having to spontaneously wing a lecture (by no fault of my own\u2026) \uD83D\uDE31\uD83D\uDD73 https:\/\/t.co\/1nL4lwWjiH",
  "id" : 872454930023559168,
  "created_at" : "2017-06-07 14:07:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 14, 22 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872348409537146880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17251507814537, 8.62764949004608 ]
  },
  "id_str" : "872356752901255169",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @heyaudy yep, used that for my last paper to get the Bibtex entries for all entries of my bibliography and works pretty good (not always perfect).",
  "id" : 872356752901255169,
  "in_reply_to_status_id" : 872348409537146880,
  "created_at" : "2017-06-07 07:37:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 9, 22 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/35X3keBtj8",
      "expanded_url" : "http:\/\/www.doi2bib.org\/#\/doi",
      "display_url" : "doi2bib.org\/#\/doi"
    } ]
  },
  "in_reply_to_status_id_str" : "872346496167018496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231434360704, 8.627510035260514 ]
  },
  "id_str" : "872347736963764224",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy @PhilippBayer https:\/\/t.co\/35X3keBtj8",
  "id" : 872347736963764224,
  "in_reply_to_status_id" : 872346496167018496,
  "created_at" : "2017-06-07 07:01:22 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 3, 13 ],
      "id_str" : "347340056",
      "id" : 347340056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "872244339623288832",
  "text" : "RT @vortacist: \"Queer Hacking is a publishing project aimed at telling the stories of queer women, men &amp; non-binary persons who are hacking\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 144, 167 ],
        "url" : "https:\/\/t.co\/hmCslQ7EKS",
        "expanded_url" : "https:\/\/twitter.com\/eschmaltzzz\/status\/872206732209963008",
        "display_url" : "twitter.com\/eschmaltzzz\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "872213538038841346",
    "text" : "\"Queer Hacking is a publishing project aimed at telling the stories of queer women, men &amp; non-binary persons who are hacking the world.\" !! https:\/\/t.co\/hmCslQ7EKS",
    "id" : 872213538038841346,
    "created_at" : "2017-06-06 22:08:07 +0000",
    "user" : {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "protected" : false,
      "id_str" : "347340056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819220259148177408\/UYT71cyh_normal.jpg",
      "id" : 347340056,
      "verified" : false
    }
  },
  "id" : 872244339623288832,
  "created_at" : "2017-06-07 00:10:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 15, 23 ],
      "id_str" : "44890780",
      "id" : 44890780
    }, {
      "name" : "Overleaf",
      "screen_name" : "overleaf",
      "indices" : [ 24, 33 ],
      "id_str" : "854581958",
      "id" : 854581958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872179952258392064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398108375609, 8.753445689650247 ]
  },
  "id_str" : "872194995566116865",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @tonyR_H @overleaf clone to git somewhere and look at the commits maybe?",
  "id" : 872194995566116865,
  "in_reply_to_status_id" : 872179952258392064,
  "created_at" : "2017-06-06 20:54:26 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliot Harmon",
      "screen_name" : "elliotharmon",
      "indices" : [ 0, 13 ],
      "id_str" : "4215881",
      "id" : 4215881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872177058775932928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401392448246, 8.753366790961422 ]
  },
  "id_str" : "872177176753446912",
  "in_reply_to_user_id" : 4215881,
  "text" : "@elliotharmon Next time we run into each other!",
  "id" : 872177176753446912,
  "in_reply_to_status_id" : 872177058775932928,
  "created_at" : "2017-06-06 19:43:37 +0000",
  "in_reply_to_screen_name" : "elliotharmon",
  "in_reply_to_user_id_str" : "4215881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0394 (alt-J)",
      "screen_name" : "alt_J",
      "indices" : [ 3, 9 ],
      "id_str" : "301931359",
      "id" : 301931359
    }, {
      "name" : "Song Exploder",
      "screen_name" : "SongExploder",
      "indices" : [ 55, 68 ],
      "id_str" : "2249590315",
      "id" : 2249590315
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/alt_J\/status\/871760297614356483\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/VqCcSYeW1w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DBkdXpPXoAAB87P.jpg",
      "id_str" : "871760294917414912",
      "id" : 871760294917414912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBkdXpPXoAAB87P.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 630
      } ],
      "display_url" : "pic.twitter.com\/VqCcSYeW1w"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/cUyTTEgzUC",
      "expanded_url" : "http:\/\/j.mp\/2sJmmZm",
      "display_url" : "j.mp\/2sJmmZm"
    } ]
  },
  "geo" : { },
  "id_str" : "872174602457419777",
  "text" : "RT @alt_J: Listen to us dissect 'In Cold Blood' on the @SongExploder podcast - https:\/\/t.co\/cUyTTEgzUC https:\/\/t.co\/VqCcSYeW1w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Song Exploder",
        "screen_name" : "SongExploder",
        "indices" : [ 44, 57 ],
        "id_str" : "2249590315",
        "id" : 2249590315
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/alt_J\/status\/871760297614356483\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/VqCcSYeW1w",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DBkdXpPXoAAB87P.jpg",
        "id_str" : "871760294917414912",
        "id" : 871760294917414912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBkdXpPXoAAB87P.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 630
        } ],
        "display_url" : "pic.twitter.com\/VqCcSYeW1w"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/cUyTTEgzUC",
        "expanded_url" : "http:\/\/j.mp\/2sJmmZm",
        "display_url" : "j.mp\/2sJmmZm"
      } ]
    },
    "geo" : { },
    "id_str" : "871760297614356483",
    "text" : "Listen to us dissect 'In Cold Blood' on the @SongExploder podcast - https:\/\/t.co\/cUyTTEgzUC https:\/\/t.co\/VqCcSYeW1w",
    "id" : 871760297614356483,
    "created_at" : "2017-06-05 16:07:06 +0000",
    "user" : {
      "name" : "\u0394 (alt-J)",
      "screen_name" : "alt_J",
      "protected" : false,
      "id_str" : "301931359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/847091337870675968\/w9J6SPFD_normal.jpg",
      "id" : 301931359,
      "verified" : true
    }
  },
  "id" : 872174602457419777,
  "created_at" : "2017-06-06 19:33:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "Jens-Wolfhard",
      "screen_name" : "Drahflow",
      "indices" : [ 11, 20 ],
      "id_str" : "92904426",
      "id" : 92904426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872173049868685312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139423775166, 8.753520880528228 ]
  },
  "id_str" : "872173365250928640",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe @Drahflow it\u2019s a small world after all. \uD83D\uDE1C",
  "id" : 872173365250928640,
  "in_reply_to_status_id" : 872173049868685312,
  "created_at" : "2017-06-06 19:28:29 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 3, 13 ],
      "id_str" : "17645638",
      "id" : 17645638
    }, {
      "name" : "The Debian Project",
      "screen_name" : "debian",
      "indices" : [ 23, 30 ],
      "id_str" : "24253645",
      "id" : 24253645
    }, {
      "name" : "Jens-Wolfhard",
      "screen_name" : "Drahflow",
      "indices" : [ 88, 97 ],
      "id_str" : "92904426",
      "id" : 92904426
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 121, 137 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "872173298456637440",
  "text" : "RT @biocrusoe: Wore my @Debian shirt on the train, got to talking with a fellow techie (@Drahflow) who turns out to know @gedankenstuecke o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Debian Project",
        "screen_name" : "debian",
        "indices" : [ 8, 15 ],
        "id_str" : "24253645",
        "id" : 24253645
      }, {
        "name" : "Jens-Wolfhard",
        "screen_name" : "Drahflow",
        "indices" : [ 73, 82 ],
        "id_str" : "92904426",
        "id" : 92904426
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 106, 122 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "872173049868685312",
    "text" : "Wore my @Debian shirt on the train, got to talking with a fellow techie (@Drahflow) who turns out to know @gedankenstuecke of course!",
    "id" : 872173049868685312,
    "created_at" : "2017-06-06 19:27:13 +0000",
    "user" : {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "protected" : false,
      "id_str" : "17645638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485998749311721472\/0yX4CFRV_normal.jpeg",
      "id" : 17645638,
      "verified" : false
    }
  },
  "id" : 872173298456637440,
  "created_at" : "2017-06-06 19:28:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/WW8RXCh4bQ",
      "expanded_url" : "http:\/\/ruleofthirds.de\/participation-mozsprint\/",
      "display_url" : "ruleofthirds.de\/participation-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401652670154, 8.753376700271827 ]
  },
  "id_str" : "872171993776496640",
  "text" : "I wrote a quick summary on what we\u2019ve done with openSNP at the #mozsprint https:\/\/t.co\/WW8RXCh4bQ",
  "id" : 872171993776496640,
  "created_at" : "2017-06-06 19:23:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/872144062375231489\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/uiS0hJ5JUh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DBp6XWnXcAAG4fM.jpg",
      "id_str" : "872144019475886080",
      "id" : 872144019475886080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBp6XWnXcAAG4fM.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/uiS0hJ5JUh"
    } ],
    "hashtags" : [ {
      "text" : "CC0",
      "indices" : [ 56, 60 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872089254444269572",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11414823126989, 8.753638230272339 ]
  },
  "id_str" : "872144062375231489",
  "in_reply_to_user_id" : 14286491,
  "text" : "Fitting: my latest set of stickers just arrived today. \uD83D\uDE0D#CC0 https:\/\/t.co\/uiS0hJ5JUh",
  "id" : 872144062375231489,
  "in_reply_to_status_id" : 872089254444269572,
  "created_at" : "2017-06-06 17:32:02 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Shockey",
      "screen_name" : "nshockey",
      "indices" : [ 0, 9 ],
      "id_str" : "16728620",
      "id" : 16728620
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/872140006562902016\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/nc4A53pN8U",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DBp2tTYWAAgmqbY.jpg",
      "id_str" : "872139998518181896",
      "id" : 872139998518181896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DBp2tTYWAAgmqbY.jpg",
      "sizes" : [ {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/nc4A53pN8U"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872137895175389184",
  "geo" : { },
  "id_str" : "872140006562902016",
  "in_reply_to_user_id" : 16728620,
  "text" : "@nshockey if you've bought into the idea of unchecked capitalism a bit too much. \uD83D\uDE09 https:\/\/t.co\/nc4A53pN8U",
  "id" : 872140006562902016,
  "in_reply_to_status_id" : 872137895175389184,
  "created_at" : "2017-06-06 17:15:55 +0000",
  "in_reply_to_screen_name" : "nshockey",
  "in_reply_to_user_id_str" : "16728620",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/872089254444269572\/photo\/1",
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/WHDFH6lgHz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DBpIjUXW0AAcc2E.jpg",
      "id_str" : "872089249448906752",
      "id" : 872089249448906752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBpIjUXW0AAcc2E.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 525
      } ],
      "display_url" : "pic.twitter.com\/WHDFH6lgHz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/n9omHA2bNT",
      "expanded_url" : "https:\/\/twitter.com\/wisealic\/status\/872044216830111744",
      "display_url" : "twitter.com\/wisealic\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235404662587, 8.627543723455195 ]
  },
  "id_str" : "872089254444269572",
  "text" : "Oh no, people are reusing things that are shared under licenses designed to enable reuse!  \u00AF\\_(\u30C4)_\/\u00AF https:\/\/t.co\/n9omHA2bNT https:\/\/t.co\/WHDFH6lgHz",
  "id" : 872089254444269572,
  "created_at" : "2017-06-06 13:54:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amoeba Sisters",
      "screen_name" : "AmoebaSisters",
      "indices" : [ 3, 17 ],
      "id_str" : "1640411761",
      "id" : 1640411761
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AmoebaSisters\/status\/871365261726687233\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/S9sRfZGNQz",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DBe1bKDUwAMkgUF.jpg",
      "id_str" : "871364531078873091",
      "id" : 871364531078873091,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DBe1bKDUwAMkgUF.jpg",
      "sizes" : [ {
        "h" : 1012,
        "resize" : "fit",
        "w" : 1034
      }, {
        "h" : 1012,
        "resize" : "fit",
        "w" : 1034
      }, {
        "h" : 666,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1012,
        "resize" : "fit",
        "w" : 1034
      } ],
      "display_url" : "pic.twitter.com\/S9sRfZGNQz"
    } ],
    "hashtags" : [ {
      "text" : "scicomm",
      "indices" : [ 57, 65 ]
    }, {
      "text" : "botany",
      "indices" : [ 66, 73 ]
    }, {
      "text" : "amoebasisters",
      "indices" : [ 74, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "872079568768782338",
  "text" : "RT @AmoebaSisters: Flower to fruit! An angiosperm GIF. \uD83C\uDF37\n#scicomm #botany #amoebasisters https:\/\/t.co\/S9sRfZGNQz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AmoebaSisters\/status\/871365261726687233\/photo\/1",
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/S9sRfZGNQz",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DBe1bKDUwAMkgUF.jpg",
        "id_str" : "871364531078873091",
        "id" : 871364531078873091,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DBe1bKDUwAMkgUF.jpg",
        "sizes" : [ {
          "h" : 1012,
          "resize" : "fit",
          "w" : 1034
        }, {
          "h" : 1012,
          "resize" : "fit",
          "w" : 1034
        }, {
          "h" : 666,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1012,
          "resize" : "fit",
          "w" : 1034
        } ],
        "display_url" : "pic.twitter.com\/S9sRfZGNQz"
      } ],
      "hashtags" : [ {
        "text" : "scicomm",
        "indices" : [ 38, 46 ]
      }, {
        "text" : "botany",
        "indices" : [ 47, 54 ]
      }, {
        "text" : "amoebasisters",
        "indices" : [ 55, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "871365261726687233",
    "text" : "Flower to fruit! An angiosperm GIF. \uD83C\uDF37\n#scicomm #botany #amoebasisters https:\/\/t.co\/S9sRfZGNQz",
    "id" : 871365261726687233,
    "created_at" : "2017-06-04 13:57:22 +0000",
    "user" : {
      "name" : "Amoeba Sisters",
      "screen_name" : "AmoebaSisters",
      "protected" : false,
      "id_str" : "1640411761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816747817397956608\/bMZNbtNa_normal.jpg",
      "id" : 1640411761,
      "verified" : false
    }
  },
  "id" : 872079568768782338,
  "created_at" : "2017-06-06 13:15:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "872014835432730624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231183456975, 8.627505135204608 ]
  },
  "id_str" : "872019303524126720",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer oh, nice!",
  "id" : 872019303524126720,
  "in_reply_to_status_id" : 872014835432730624,
  "created_at" : "2017-06-06 09:16:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 3, 17 ],
      "id_str" : "257319757",
      "id" : 257319757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "871965802148311042",
  "text" : "RT @lorrainechu3n: thinking about how the words 'diversity' and 'inclusion' still centre whiteness and those who have the most power. inclu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "871961992801783808",
    "text" : "thinking about how the words 'diversity' and 'inclusion' still centre whiteness and those who have the most power. inclusion: including who?",
    "id" : 871961992801783808,
    "created_at" : "2017-06-06 05:28:34 +0000",
    "user" : {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "protected" : false,
      "id_str" : "257319757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926996461719621632\/aBq5xtJy_normal.jpg",
      "id" : 257319757,
      "verified" : false
    }
  },
  "id" : 871965802148311042,
  "created_at" : "2017-06-06 05:43:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/iOyj4mx9GM",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BU9GADLFqyD\/",
      "display_url" : "instagram.com\/p\/BU9GADLFqyD\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.111926605779, 8.7542334820657 ]
  },
  "id_str" : "871675537462366208",
  "text" : "\uD83D\uDC31\uD83D\uDC4B @ Offenbach Hafeninsel https:\/\/t.co\/iOyj4mx9GM",
  "id" : 871675537462366208,
  "created_at" : "2017-06-05 10:30:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/b1wlp47RJb",
      "expanded_url" : "https:\/\/twitter.com\/christi3k\/status\/870872580835508224",
      "display_url" : "twitter.com\/christi3k\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11385891417279, 8.75342214486763 ]
  },
  "id_str" : "871426845736136704",
  "text" : "Important thread! https:\/\/t.co\/b1wlp47RJb",
  "id" : 871426845736136704,
  "created_at" : "2017-06-04 18:02:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/LFJ3x9KVw9",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BU7DAENF1n4\/",
      "display_url" : "instagram.com\/p\/BU7DAENF1n4\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.113472516667, 8.7491891 ]
  },
  "id_str" : "871387465638084609",
  "text" : "\uD83D\uDC77\u200D\u2640\uFE0F\u26CF\uD83D\uDD6F @ Hafen Offenbach am Main https:\/\/t.co\/LFJ3x9KVw9",
  "id" : 871387465638084609,
  "created_at" : "2017-06-04 15:25:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NOT A WOLF",
      "screen_name" : "SICKOFWOLVES",
      "indices" : [ 3, 16 ],
      "id_str" : "1656244670",
      "id" : 1656244670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/GFHxgjvYnP",
      "expanded_url" : "https:\/\/twitter.com\/OnlyInBOS\/status\/870641167423197187",
      "display_url" : "twitter.com\/OnlyInBOS\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "871312317136461824",
  "text" : "RT @SICKOFWOLVES: FAILED?\n\nALL I SEE ARE DOGS THAT ARE NOT WILLING TO BE NARCS https:\/\/t.co\/GFHxgjvYnP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/GFHxgjvYnP",
        "expanded_url" : "https:\/\/twitter.com\/OnlyInBOS\/status\/870641167423197187",
        "display_url" : "twitter.com\/OnlyInBOS\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "870667335211909120",
    "text" : "FAILED?\n\nALL I SEE ARE DOGS THAT ARE NOT WILLING TO BE NARCS https:\/\/t.co\/GFHxgjvYnP",
    "id" : 870667335211909120,
    "created_at" : "2017-06-02 15:44:03 +0000",
    "user" : {
      "name" : "NOT A WOLF",
      "screen_name" : "SICKOFWOLVES",
      "protected" : false,
      "id_str" : "1656244670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870748901174910978\/mh3S-VRD_normal.jpg",
      "id" : 1656244670,
      "verified" : false
    }
  },
  "id" : 871312317136461824,
  "created_at" : "2017-06-04 10:26:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sMyle",
      "screen_name" : "MylesBorins",
      "indices" : [ 3, 15 ],
      "id_str" : "150664007",
      "id" : 150664007
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MylesBorins\/status\/870710532407402496\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/lUXOXRu7fa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DBVimukUAAEZ442.jpg",
      "id_str" : "870710520440946689",
      "id" : 870710520440946689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBVimukUAAEZ442.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/lUXOXRu7fa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "871307022460997632",
  "text" : "RT @MylesBorins: This is what you get when you google \"Dank Fast Fourier Transform\" https:\/\/t.co\/lUXOXRu7fa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MylesBorins\/status\/870710532407402496\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/lUXOXRu7fa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DBVimukUAAEZ442.jpg",
        "id_str" : "870710520440946689",
        "id" : 870710520440946689,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBVimukUAAEZ442.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/lUXOXRu7fa"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "870710532407402496",
    "text" : "This is what you get when you google \"Dank Fast Fourier Transform\" https:\/\/t.co\/lUXOXRu7fa",
    "id" : 870710532407402496,
    "created_at" : "2017-06-02 18:35:42 +0000",
    "user" : {
      "name" : "sMyle \uD83C\uDDF9\uD83C\uDDFC",
      "screen_name" : "MylesBorins",
      "protected" : false,
      "id_str" : "150664007",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714160971137347584\/kR6KSJbw_normal.jpg",
      "id" : 150664007,
      "verified" : true
    }
  },
  "id" : 871307022460997632,
  "created_at" : "2017-06-04 10:05:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/M2w13ODx0J",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BU6cxnKFOHe\/",
      "display_url" : "instagram.com\/p\/BU6cxnKFOHe\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.111926605779, 8.7542334820657 ]
  },
  "id_str" : "871303407155458048",
  "text" : "Someone's having a slow Sunday @ Offenbach Hafeninsel https:\/\/t.co\/M2w13ODx0J",
  "id" : 871303407155458048,
  "created_at" : "2017-06-04 09:51:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 10, 25 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "871007469354569729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140114331087, 8.753373212615402 ]
  },
  "id_str" : "871023685586624512",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @MozOpenLeaders Good to hear that. Will check it out! \uD83C\uDF89\uD83D\uDC4D",
  "id" : 871023685586624512,
  "in_reply_to_status_id" : 871007469354569729,
  "created_at" : "2017-06-03 15:20:04 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 58, 71 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/fL0bL4MwjS",
      "expanded_url" : "https:\/\/openSNP.org",
      "display_url" : "openSNP.org"
    } ]
  },
  "in_reply_to_status_id_str" : "870557011209056256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114062610129, 8.75331971795182 ]
  },
  "id_str" : "870958196583804928",
  "in_reply_to_user_id" : 14286491,
  "text" : "All but one issue we\u2019re aware of are now fixed, thanks to @PhilippBayer\u2019s \uD83D\uDD75\uFE0F work. Super happy with how https:\/\/t.co\/fL0bL4MwjS looks now. \uD83D\uDE0D",
  "id" : 870958196583804928,
  "in_reply_to_status_id" : 870557011209056256,
  "created_at" : "2017-06-03 10:59:50 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Bryan",
      "screen_name" : "JennyBryan",
      "indices" : [ 3, 14 ],
      "id_str" : "2167059661",
      "id" : 2167059661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "870932050785730561",
  "text" : "RT @JennyBryan: My main takeaways: write better docs or make it easy for others to do so. If you're going to be rude, consider keeping your\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/jQzmePDQjO",
        "expanded_url" : "https:\/\/twitter.com\/nayafia\/status\/870651444717731841",
        "display_url" : "twitter.com\/nayafia\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "870705461535809537",
    "text" : "My main takeaways: write better docs or make it easy for others to do so. If you're going to be rude, consider keeping your mouth shut. https:\/\/t.co\/jQzmePDQjO",
    "id" : 870705461535809537,
    "created_at" : "2017-06-02 18:15:33 +0000",
    "user" : {
      "name" : "Jenny Bryan",
      "screen_name" : "JennyBryan",
      "protected" : false,
      "id_str" : "2167059661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660978605606875137\/s3YrJetD_normal.jpg",
      "id" : 2167059661,
      "verified" : false
    }
  },
  "id" : 870932050785730561,
  "created_at" : "2017-06-03 09:15:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 0, 15 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "870850385602326528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400662175552, 8.753371795516934 ]
  },
  "id_str" : "870891760716742656",
  "in_reply_to_user_id" : 791070237949034496,
  "text" : "@MozOpenLeaders The bubble size doesn\u2019t have a label\/legend. \uD83E\uDD13\uD83D\uDE09\uD83D\uDCCA",
  "id" : 870891760716742656,
  "in_reply_to_status_id" : 870850385602326528,
  "created_at" : "2017-06-03 06:35:50 +0000",
  "in_reply_to_screen_name" : "MozOpenLeaders",
  "in_reply_to_user_id_str" : "791070237949034496",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 3, 18 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "870891546169794560",
  "text" : "RT @MozOpenLeaders: #mozsprint by the (GitHub) numbers! 50 hours of non-stop collaboration on open projects for a healthy Internet \uD83D\uDC4F\uD83D\uDC4F\uD83D\uDC4F\nhttp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MozOpenLeaders\/status\/870850385602326528\/photo\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/dDdNAAyv4g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DBXhrKUVoAABShf.jpg",
        "id_str" : "870850234586341376",
        "id" : 870850234586341376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBXhrKUVoAABShf.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 1036
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1036
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1036
        } ],
        "display_url" : "pic.twitter.com\/dDdNAAyv4g"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/MozOpenLeaders\/status\/870850385602326528\/photo\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/dDdNAAyv4g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DBXhtnPV0AANol1.jpg",
        "id_str" : "870850276709748736",
        "id" : 870850276709748736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBXhtnPV0AANol1.jpg",
        "sizes" : [ {
          "h" : 611,
          "resize" : "fit",
          "w" : 988
        }, {
          "h" : 611,
          "resize" : "fit",
          "w" : 988
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 611,
          "resize" : "fit",
          "w" : 988
        } ],
        "display_url" : "pic.twitter.com\/dDdNAAyv4g"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/MozOpenLeaders\/status\/870850385602326528\/photo\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/dDdNAAyv4g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DBXhuvpUAAAC9rm.jpg",
        "id_str" : "870850296146034688",
        "id" : 870850296146034688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBXhuvpUAAAC9rm.jpg",
        "sizes" : [ {
          "h" : 421,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 912
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 912
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 912
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/dDdNAAyv4g"
      } ],
      "hashtags" : [ {
        "text" : "mozsprint",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/bsor3KNvU6",
        "expanded_url" : "https:\/\/medium.com\/@MozOpenLeaders\/mozsprint-by-the-github-numbers-49d518551725",
        "display_url" : "medium.com\/@MozOpenLeader\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "870850385602326528",
    "text" : "#mozsprint by the (GitHub) numbers! 50 hours of non-stop collaboration on open projects for a healthy Internet \uD83D\uDC4F\uD83D\uDC4F\uD83D\uDC4F\nhttps:\/\/t.co\/bsor3KNvU6 https:\/\/t.co\/dDdNAAyv4g",
    "id" : 870850385602326528,
    "created_at" : "2017-06-03 03:51:26 +0000",
    "user" : {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "protected" : false,
      "id_str" : "791070237949034496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/842142191032123392\/GS5Ptjrs_normal.jpg",
      "id" : 791070237949034496,
      "verified" : false
    }
  },
  "id" : 870891546169794560,
  "created_at" : "2017-06-03 06:34:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nadia Eghbal",
      "screen_name" : "nayafia",
      "indices" : [ 3, 11 ],
      "id_str" : "326511843",
      "id" : 326511843
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/xEIDw5BcC8",
      "expanded_url" : "https:\/\/thenextweb.com\/dd\/2017\/06\/02\/free-software-is-suffering-because-coders-dont-know-how-to-write-documentation\/#.tnw_N4qM7rvo",
      "display_url" : "thenextweb.com\/dd\/2017\/06\/02\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "870708010678603776",
  "text" : "RT @nayafia: One of my favorite findings: https:\/\/t.co\/xEIDw5BcC8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/xEIDw5BcC8",
        "expanded_url" : "https:\/\/thenextweb.com\/dd\/2017\/06\/02\/free-software-is-suffering-because-coders-dont-know-how-to-write-documentation\/#.tnw_N4qM7rvo",
        "display_url" : "thenextweb.com\/dd\/2017\/06\/02\/\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "870652084995055617",
    "geo" : { },
    "id_str" : "870703635826491392",
    "in_reply_to_user_id" : 326511843,
    "text" : "One of my favorite findings: https:\/\/t.co\/xEIDw5BcC8",
    "id" : 870703635826491392,
    "in_reply_to_status_id" : 870652084995055617,
    "created_at" : "2017-06-02 18:08:18 +0000",
    "in_reply_to_screen_name" : "nayafia",
    "in_reply_to_user_id_str" : "326511843",
    "user" : {
      "name" : "Nadia Eghbal",
      "screen_name" : "nayafia",
      "protected" : false,
      "id_str" : "326511843",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1648848489\/twitter_normal.png",
      "id" : 326511843,
      "verified" : false
    }
  },
  "id" : 870708010678603776,
  "created_at" : "2017-06-02 18:25:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nadia Eghbal",
      "screen_name" : "nayafia",
      "indices" : [ 3, 11 ],
      "id_str" : "326511843",
      "id" : 326511843
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/zDSsFyaDfW",
      "expanded_url" : "http:\/\/opensourcesurvey.org\/2017",
      "display_url" : "opensourcesurvey.org\/2017"
    } ]
  },
  "geo" : { },
  "id_str" : "870707931787911169",
  "text" : "RT @nayafia: We just released a bunch of survey data about open source communities: https:\/\/t.co\/zDSsFyaDfW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/zDSsFyaDfW",
        "expanded_url" : "http:\/\/opensourcesurvey.org\/2017",
        "display_url" : "opensourcesurvey.org\/2017"
      } ]
    },
    "geo" : { },
    "id_str" : "870651444717731841",
    "text" : "We just released a bunch of survey data about open source communities: https:\/\/t.co\/zDSsFyaDfW",
    "id" : 870651444717731841,
    "created_at" : "2017-06-02 14:40:54 +0000",
    "user" : {
      "name" : "Nadia Eghbal",
      "screen_name" : "nayafia",
      "protected" : false,
      "id_str" : "326511843",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1648848489\/twitter_normal.png",
      "id" : 326511843,
      "verified" : false
    }
  },
  "id" : 870707931787911169,
  "created_at" : "2017-06-02 18:25:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Ross",
      "screen_name" : "sw1ayfe",
      "indices" : [ 51, 59 ],
      "id_str" : "585100333",
      "id" : 585100333
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/870693696592728066\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/ncCLVCckd8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DBVTStQXgAA4Xed.jpg",
      "id_str" : "870693683817054208",
      "id" : 870693683817054208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBVTStQXgAA4Xed.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/ncCLVCckd8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397744999277, 8.752944041051672 ]
  },
  "id_str" : "870693696592728066",
  "text" : "Be careful what you wish for: this morning I wrote @sw1ayfe that I\u2019d love some of the London rain. https:\/\/t.co\/ncCLVCckd8",
  "id" : 870693696592728066,
  "created_at" : "2017-06-02 17:28:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 81, 89 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/wVQISBZdWl",
      "expanded_url" : "https:\/\/twitter.com\/openSNPorg\/status\/870679611436261376",
      "display_url" : "twitter.com\/openSNPorg\/sta\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "870557190981079040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16600442589276, 8.63368590363174 ]
  },
  "id_str" : "870680218494681088",
  "in_reply_to_user_id" : 14286491,
  "text" : "That was a fun ride. And additionally I even managed to get some commits in into @betatim\u2019s project! \uD83C\uDFC3\u200D\u2640\uFE0F\uD83C\uDF70\uD83C\uDF89 #mozsprint https:\/\/t.co\/wVQISBZdWl",
  "id" : 870680218494681088,
  "in_reply_to_status_id" : 870557190981079040,
  "created_at" : "2017-06-02 16:35:15 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/XDp8fOZy14",
      "expanded_url" : "https:\/\/twitter.com\/betatim\/status\/870569382375829505",
      "display_url" : "twitter.com\/betatim\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231937140517, 8.627516368193525 ]
  },
  "id_str" : "870620323657502721",
  "text" : "Already requested stickers of this logo. #mozsprint https:\/\/t.co\/XDp8fOZy14",
  "id" : 870620323657502721,
  "created_at" : "2017-06-02 12:37:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/870596965024899072\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/vZ5imkDsmd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DBT7UeXWAAAqUe6.jpg",
      "id_str" : "870596957156278272",
      "id" : 870596957156278272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBT7UeXWAAAqUe6.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/vZ5imkDsmd"
    } ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232363965628, 8.627512462893487 ]
  },
  "id_str" : "870596965024899072",
  "text" : "Found my \uD83C\uDF70 for lunch. #mozsprint https:\/\/t.co\/vZ5imkDsmd",
  "id" : 870596965024899072,
  "created_at" : "2017-06-02 11:04:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "870573832897257472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231394792014, 8.627526259502195 ]
  },
  "id_str" : "870574816318943232",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime hah, yes! That was the biggest thing that was driving me nuts as well. The responsive layout makes it much easier. If not ideal yet.",
  "id" : 870574816318943232,
  "in_reply_to_status_id" : 870573832897257472,
  "created_at" : "2017-06-02 09:36:25 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/fuEcDOa10n",
      "expanded_url" : "https:\/\/github.com\/openSNP\/snpr\/issues\/375",
      "display_url" : "github.com\/openSNP\/snpr\/i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "870557011209056256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340923505, 8.627515327960163 ]
  },
  "id_str" : "870557190981079040",
  "in_reply_to_user_id" : 14286491,
  "text" : "Any bugs not on our todo yet? Write a comment here https:\/\/t.co\/fuEcDOa10n #mozsprint",
  "id" : 870557190981079040,
  "in_reply_to_status_id" : 870557011209056256,
  "created_at" : "2017-06-02 08:26:23 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/I3h3I8vMcY",
      "expanded_url" : "https:\/\/opensnp.org\/news",
      "display_url" : "opensnp.org\/news"
    }, {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/cwrLii87C8",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/870221486317084673",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "870395794603610112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172340923505, 8.627515327960163 ]
  },
  "id_str" : "870557011209056256",
  "in_reply_to_user_id" : 14286491,
  "text" : "Now live, still with some bugs: Our new openSNP interface! \uD83C\uDF89 https:\/\/t.co\/I3h3I8vMcY #mozsprint https:\/\/t.co\/cwrLii87C8",
  "id" : 870557011209056256,
  "in_reply_to_status_id" : 870395794603610112,
  "created_at" : "2017-06-02 08:25:40 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/DOWQFBOhun",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/870151886627905536",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "870151886627905536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10631890506493, 8.751732856043382 ]
  },
  "id_str" : "870512761851101184",
  "in_reply_to_user_id" : 14286491,
  "text" : "Didn\u2019t forget my shoes today! \uD83D\uDC5F \uD83D\uDC60 #mozsprint https:\/\/t.co\/DOWQFBOhun",
  "id" : 870512761851101184,
  "in_reply_to_status_id" : 870151886627905536,
  "created_at" : "2017-06-02 05:29:50 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Armin Scheben",
      "screen_name" : "arminscheben",
      "indices" : [ 0, 13 ],
      "id_str" : "717251324438401024",
      "id" : 717251324438401024
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 14, 25 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "870479866759532545",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400731085575, 8.753378567333048 ]
  },
  "id_str" : "870502291656265728",
  "in_reply_to_user_id" : 717251324438401024,
  "text" : "@arminscheben @openSNPorg Thanks so much! \uD83D\uDC96",
  "id" : 870502291656265728,
  "in_reply_to_status_id" : 870479866759532545,
  "created_at" : "2017-06-02 04:48:14 +0000",
  "in_reply_to_screen_name" : "arminscheben",
  "in_reply_to_user_id_str" : "717251324438401024",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Nicholson",
      "screen_name" : "nicholdav",
      "indices" : [ 0, 10 ],
      "id_str" : "614440298",
      "id" : 614440298
    }, {
      "name" : "Science Hu\u03B2",
      "screen_name" : "scihub",
      "indices" : [ 11, 18 ],
      "id_str" : "192124363",
      "id" : 192124363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "870402973834375169",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401229469774, 8.753388393596323 ]
  },
  "id_str" : "870405169674145792",
  "in_reply_to_user_id" : 614440298,
  "text" : "@nicholdav @scihub Mixed use for me, often don\u2019t have access to very new stuff (and of course always when not in the office w\/ library access)",
  "id" : 870405169674145792,
  "in_reply_to_status_id" : 870402973834375169,
  "created_at" : "2017-06-01 22:22:18 +0000",
  "in_reply_to_screen_name" : "nicholdav",
  "in_reply_to_user_id_str" : "614440298",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Nicholson",
      "screen_name" : "nicholdav",
      "indices" : [ 0, 10 ],
      "id_str" : "614440298",
      "id" : 614440298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "870402338921611265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401229469774, 8.753388393596323 ]
  },
  "id_str" : "870404944385454080",
  "in_reply_to_user_id" : 614440298,
  "text" : "@nicholdav I guess only if you\u2019re publishing about Sci-Hub :)",
  "id" : 870404944385454080,
  "in_reply_to_status_id" : 870402338921611265,
  "created_at" : "2017-06-01 22:21:24 +0000",
  "in_reply_to_screen_name" : "nicholdav",
  "in_reply_to_user_id_str" : "614440298",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/fYUXVoia5M",
      "expanded_url" : "https:\/\/twitter.com\/rach_glover\/status\/870272381109116928",
      "display_url" : "twitter.com\/rach_glover\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401479429338, 8.753389001602521 ]
  },
  "id_str" : "870396181398114304",
  "text" : "Just what FASTQ needed, Unicode errors in the quality strings! \uD83D\uDC4D https:\/\/t.co\/fYUXVoia5M",
  "id" : 870396181398114304,
  "created_at" : "2017-06-01 21:46:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/Vz1ZcWHWVa",
      "expanded_url" : "https:\/\/twitter.com\/MozOpenLeaders\/status\/870393544594382850",
      "display_url" : "twitter.com\/MozOpenLeaders\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "870389194975191041",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401479429338, 8.753389001602521 ]
  },
  "id_str" : "870395794603610112",
  "in_reply_to_user_id" : 14286491,
  "text" : "~200 of these pushed commits must have been me trying to get my code to pass all tests. \uD83D\uDE02 #mozsprint https:\/\/t.co\/Vz1ZcWHWVa",
  "id" : 870395794603610112,
  "in_reply_to_status_id" : 870389194975191041,
  "created_at" : "2017-06-01 21:45:03 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Nicholson",
      "screen_name" : "nicholdav",
      "indices" : [ 0, 10 ],
      "id_str" : "614440298",
      "id" : 614440298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "870379213584465920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388748327929, 8.753269705323307 ]
  },
  "id_str" : "870393521282273280",
  "in_reply_to_user_id" : 614440298,
  "text" : "@nicholdav Seemed fair enough :p",
  "id" : 870393521282273280,
  "in_reply_to_status_id" : 870379213584465920,
  "created_at" : "2017-06-01 21:36:01 +0000",
  "in_reply_to_screen_name" : "nicholdav",
  "in_reply_to_user_id_str" : "614440298",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 36, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "870314742618914816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401254104565, 8.753387008464339 ]
  },
  "id_str" : "870389194975191041",
  "in_reply_to_user_id" : 14286491,
  "text" : "openSNP-statistics for day 1 of the #mozsprint: 3 new contributors, 9 merged PRs, 1 open PR, 3 closed issues.",
  "id" : 870389194975191041,
  "in_reply_to_status_id" : 870314742618914816,
  "created_at" : "2017-06-01 21:18:49 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "infinome",
      "screen_name" : "InfinoMe",
      "indices" : [ 0, 9 ],
      "id_str" : "2362226100",
      "id" : 2362226100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "870316166488571904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232251222249, 8.627515423437702 ]
  },
  "id_str" : "870318465340592128",
  "in_reply_to_user_id" : 2362226100,
  "text" : "@InfinoMe I think everyone does these once in a while ;)",
  "id" : 870318465340592128,
  "in_reply_to_status_id" : 870316166488571904,
  "created_at" : "2017-06-01 16:37:46 +0000",
  "in_reply_to_screen_name" : "InfinoMe",
  "in_reply_to_user_id_str" : "2362226100",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/870314742618914816\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/tfCYVB0SF4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DBP6pDgXsAAxKlo.jpg",
      "id_str" : "870314736235294720",
      "id" : 870314736235294720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBP6pDgXsAAxKlo.jpg",
      "sizes" : [ {
        "h" : 305,
        "resize" : "fit",
        "w" : 809
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 809
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 809
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/tfCYVB0SF4"
    } ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 70, 80 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "870307011480735745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233548391725, 8.627514695569541 ]
  },
  "id_str" : "870314742618914816",
  "in_reply_to_user_id" : 14286491,
  "text" : "Oh the irony. But at least it did work in the end I guess.  \u00AF\\_(\u30C4)_\/\u00AF #mozsprint https:\/\/t.co\/tfCYVB0SF4",
  "id" : 870314742618914816,
  "in_reply_to_status_id" : 870307011480735745,
  "created_at" : "2017-06-01 16:22:58 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/870307011480735745\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/xMJSP7AQKB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DBPznM0XkAAvB6B.jpg",
      "id_str" : "870307007793958912",
      "id" : 870307007793958912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DBPznM0XkAAvB6B.jpg",
      "sizes" : [ {
        "h" : 411,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/xMJSP7AQKB"
    } ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 26, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232060979646, 8.627517911693388 ]
  },
  "id_str" : "870307011480735745",
  "text" : "Current development level #mozsprint https:\/\/t.co\/xMJSP7AQKB",
  "id" : 870307011480735745,
  "created_at" : "2017-06-01 15:52:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 13, 21 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "870277585845993473",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233510720191, 8.627510848708964 ]
  },
  "id_str" : "870277780151427072",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown @betatim he\u2019s been living in \uD83C\uDDE8\uD83C\uDDED for too long, he forgot about how that works. \uD83D\uDE1C",
  "id" : 870277780151427072,
  "in_reply_to_status_id" : 870277585845993473,
  "created_at" : "2017-06-01 13:56:06 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 9, 21 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "870275378211934209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233510720191, 8.627510848708964 ]
  },
  "id_str" : "870277256274485248",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @ctitusbrown where\u2019s the fun in that? \uD83D\uDE09",
  "id" : 870277256274485248,
  "in_reply_to_status_id" : 870275378211934209,
  "created_at" : "2017-06-01 13:54:01 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/cwrLii87C8",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/870221486317084673",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "870221486317084673",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17245233034969, 8.627247939996987 ]
  },
  "id_str" : "870266674871771136",
  "in_reply_to_user_id" : 14286491,
  "text" : "Pulled the trigger \uD83D\uDE31\uD83D\uDE48 #mozsprint https:\/\/t.co\/cwrLii87C8",
  "id" : 870266674871771136,
  "in_reply_to_status_id" : 870221486317084673,
  "created_at" : "2017-06-01 13:11:58 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 9, 21 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 58, 70 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "870262474305568774",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232871978782, 8.62751481594478 ]
  },
  "id_str" : "870265712601968640",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @ctitusbrown ha, say hi back! Still need to meet @ctitusbrown one day! \uD83D\uDE00",
  "id" : 870265712601968640,
  "in_reply_to_status_id" : 870262474305568774,
  "created_at" : "2017-06-01 13:08:09 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 3, 9 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 11, 27 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "870243129986875392",
  "text" : "RT @shefw: @gedankenstuecke Your project got the first pull request of #mozsprint this year!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mozsprint",
        "indices" : [ 60, 70 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "870143938719600640",
    "geo" : { },
    "id_str" : "870166845466173445",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke Your project got the first pull request of #mozsprint this year!",
    "id" : 870166845466173445,
    "in_reply_to_status_id" : 870143938719600640,
    "created_at" : "2017-06-01 06:35:17 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "protected" : false,
      "id_str" : "48636190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677947392080019456\/CHnYz4aV_normal.jpg",
      "id" : 48636190,
      "verified" : false
    }
  },
  "id" : 870243129986875392,
  "created_at" : "2017-06-01 11:38:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dixie",
      "screen_name" : "timiat",
      "indices" : [ 0, 7 ],
      "id_str" : "10388582",
      "id" : 10388582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "870239865035796480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231136612245, 8.627513796947877 ]
  },
  "id_str" : "870242669615820800",
  "in_reply_to_user_id" : 10388582,
  "text" : "@timiat hope that works out!",
  "id" : 870242669615820800,
  "in_reply_to_status_id" : 870239865035796480,
  "created_at" : "2017-06-01 11:36:35 +0000",
  "in_reply_to_screen_name" : "timiat",
  "in_reply_to_user_id_str" : "10388582",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 20, 33 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 54, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/fuF76Ed7Vl",
      "expanded_url" : "https:\/\/github.com\/openSNP\/snpr\/issues?q=is%3Aissue+is%3Aopen+label%3Amozsprint",
      "display_url" : "github.com\/openSNP\/snpr\/i\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230828473653, 8.627517927521396 ]
  },
  "id_str" : "870237559313575936",
  "text" : "If you want to join @PhilippBayer &amp; me during the #mozsprint. Here\u2019s the list of issues we\u2019re working on: https:\/\/t.co\/fuF76Ed7Vl",
  "id" : 870237559313575936,
  "created_at" : "2017-06-01 11:16:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 23, 36 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232157212963, 8.627520415771226 ]
  },
  "id_str" : "870221486317084673",
  "text" : "Whop whop, so excited. @PhilippBayer and I might merge a PR that has been in the making for a year! #mozsprint \uD83D\uDE0D\uD83D\uDE31",
  "id" : 870221486317084673,
  "created_at" : "2017-06-01 10:12:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "870166845466173445",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231225270119, 8.627506647367143 ]
  },
  "id_str" : "870167398275588097",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw wow, that\u2019s some commitment! \uD83D\uDC96",
  "id" : 870167398275588097,
  "in_reply_to_status_id" : 870166845466173445,
  "created_at" : "2017-06-01 06:37:29 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11137926955718, 8.752666767694757 ]
  },
  "id_str" : "870151886627905536",
  "text" : "I know someone who\u2019s so excited about the sprint that he nearly walked to the train station on bare feet. \uD83D\uDE02\uD83D\uDE8A\uD83C\uDFC3\u200D\u2640\uFE0F #mozsprint",
  "id" : 870151886627905536,
  "created_at" : "2017-06-01 05:35:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400549227794, 8.753377601046695 ]
  },
  "id_str" : "870143938719600640",
  "text" : "Waking up in my timezone &amp; my mailbox is full of Github notifications for issues and pull requests to openSNP thanks to #mozsprint \uD83D\uDC96\uD83D\uDE0D",
  "id" : 870143938719600640,
  "created_at" : "2017-06-01 05:04:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]