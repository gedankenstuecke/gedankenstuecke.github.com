Grailbird.data.tweets_2016_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781913334983647232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11389013044346, 8.75359091668032 ]
  },
  "id_str" : "781925348518850560",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick Yersinia\u2026 now the plague is written to the walls. \uD83D\uDE02",
  "id" : 781925348518850560,
  "in_reply_to_status_id" : 781913334983647232,
  "created_at" : "2016-09-30 18:35:05 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781920865806086148",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402732659541, 8.753389200077292 ]
  },
  "id_str" : "781924623139078145",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest mine only leads to people doing very weird and awkward compliments.",
  "id" : 781924623139078145,
  "in_reply_to_status_id" : 781920865806086148,
  "created_at" : "2016-09-30 18:32:12 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781919031964082176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11434432589459, 8.753441674642966 ]
  },
  "id_str" : "781919680424452096",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest yeah, but my hair is happy to have the natural color for a while. \uD83D\uDE02",
  "id" : 781919680424452096,
  "in_reply_to_status_id" : 781919031964082176,
  "created_at" : "2016-09-30 18:12:33 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781918236724133888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407501534569, 8.75350194052677 ]
  },
  "id_str" : "781918929568555008",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest yay! \uD83D\uDC9C\uD83D\uDC9C\uD83D\uDC9C never tried \uD83D\uDC99",
  "id" : 781918929568555008,
  "in_reply_to_status_id" : 781918236724133888,
  "created_at" : "2016-09-30 18:09:34 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781917705943351301",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11229767468768, 8.756994176664163 ]
  },
  "id_str" : "781918124039864320",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 now I need a wealthy congregation :p",
  "id" : 781918124039864320,
  "in_reply_to_status_id" : 781917705943351301,
  "created_at" : "2016-09-30 18:06:22 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781915427605708801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11154057928371, 8.75790629536729 ]
  },
  "id_str" : "781917498409160704",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest \uD83D\uDC9C\uD83D\uDC9C",
  "id" : 781917498409160704,
  "in_reply_to_status_id" : 781915427605708801,
  "created_at" : "2016-09-30 18:03:53 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781893911128248320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10742946532564, 8.7696611601941 ]
  },
  "id_str" : "781914479504330753",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest ~ 1 1\/2 since I kicked the purple out \uD83D\uDE02",
  "id" : 781914479504330753,
  "in_reply_to_status_id" : 781893911128248320,
  "created_at" : "2016-09-30 17:51:53 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/781913766657228800\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/9hl0uo7qBf",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CtnqaoSWYAAQ1X4.jpg",
      "id_str" : "781913753537372160",
      "id" : 781913753537372160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CtnqaoSWYAAQ1X4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 280
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 280
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 280
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 280
      } ],
      "display_url" : "pic.twitter.com\/9hl0uo7qBf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781913766657228800",
  "text" : "All these event invites. \uD83D\uDE33 I need a job that pays me for traveling and preaching the open* gospel. https:\/\/t.co\/9hl0uo7qBf",
  "id" : 781913766657228800,
  "created_at" : "2016-09-30 17:49:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cassie",
      "screen_name" : "KittenFlower",
      "indices" : [ 3, 16 ],
      "id_str" : "40785142",
      "id" : 40785142
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KittenFlower\/status\/781866809066565632\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/aHsP1zHLpT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ctm_thoUIAAUGM5.jpg",
      "id_str" : "781866799167971328",
      "id" : 781866799167971328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ctm_thoUIAAUGM5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 513
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 513
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 513
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 513
      } ],
      "display_url" : "pic.twitter.com\/aHsP1zHLpT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781905087522308096",
  "text" : "RT @KittenFlower: https:\/\/t.co\/aHsP1zHLpT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KittenFlower\/status\/781866809066565632\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/aHsP1zHLpT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ctm_thoUIAAUGM5.jpg",
        "id_str" : "781866799167971328",
        "id" : 781866799167971328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ctm_thoUIAAUGM5.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 513
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 513
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 513
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 513
        } ],
        "display_url" : "pic.twitter.com\/aHsP1zHLpT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "781866809066565632",
    "text" : "https:\/\/t.co\/aHsP1zHLpT",
    "id" : 781866809066565632,
    "created_at" : "2016-09-30 14:42:28 +0000",
    "user" : {
      "name" : "Cassie",
      "screen_name" : "KittenFlower",
      "protected" : false,
      "id_str" : "40785142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/931429658528067585\/FK-VfCRV_normal.jpg",
      "id" : 40785142,
      "verified" : false
    }
  },
  "id" : 781905087522308096,
  "created_at" : "2016-09-30 17:14:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781887814761902080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402701211395, 8.753389439677367 ]
  },
  "id_str" : "781899906374111232",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 stating that one is sapiosexual basically guarantees that the person is an asshole :D",
  "id" : 781899906374111232,
  "in_reply_to_status_id" : 781887814761902080,
  "created_at" : "2016-09-30 16:53:59 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781868480622624768",
  "geo" : { },
  "id_str" : "781887510477672449",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 the more I think about it the more annoyed I get by this. But not surprised, given the weird people I\u2019ve stumbled upon there :D",
  "id" : 781887510477672449,
  "in_reply_to_status_id" : 781868480622624768,
  "created_at" : "2016-09-30 16:04:43 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781868480622624768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11380621796056, 8.753458881799878 ]
  },
  "id_str" : "781886781839015936",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 also ask him about the mismeasure of man\u2026",
  "id" : 781886781839015936,
  "in_reply_to_status_id" : 781868480622624768,
  "created_at" : "2016-09-30 16:01:50 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781872685252960258",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10182756016551, 8.71256041533394 ]
  },
  "id_str" : "781872823270793216",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy fuckin\u2019 plants!",
  "id" : 781872823270793216,
  "in_reply_to_status_id" : 781872685252960258,
  "created_at" : "2016-09-30 15:06:22 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781864433010282496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11641602809411, 8.68375711393499 ]
  },
  "id_str" : "781870945686388736",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr any recommendations for good academic buildings? :)",
  "id" : 781870945686388736,
  "in_reply_to_status_id" : 781864433010282496,
  "created_at" : "2016-09-30 14:58:54 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781858543532118016",
  "geo" : { },
  "id_str" : "781859559572959232",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 i will head home soon, to start the new backup on a new HDD there.",
  "id" : 781859559572959232,
  "in_reply_to_status_id" : 781858543532118016,
  "created_at" : "2016-09-30 14:13:39 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781855465852383232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17242753728409, 8.627432210352376 ]
  },
  "id_str" : "781855919055499264",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo \uD83D\uDC4D\uD83D\uDE4F",
  "id" : 781855919055499264,
  "in_reply_to_status_id" : 781855465852383232,
  "created_at" : "2016-09-30 13:59:11 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 3, 11 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMINAR",
      "indices" : [ 69, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/92qtfPXuRT",
      "expanded_url" : "http:\/\/goo.gl\/q0EKN2",
      "display_url" : "goo.gl\/q0EKN2"
    } ]
  },
  "geo" : { },
  "id_str" : "781853459427553280",
  "text" : "RT @PhdGeek: Don't forget today it the last day to submit a talk for #LGBTSTEMINAR https:\/\/t.co\/92qtfPXuRT - Don't miss out!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTSTEMINAR",
        "indices" : [ 56, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/92qtfPXuRT",
        "expanded_url" : "http:\/\/goo.gl\/q0EKN2",
        "display_url" : "goo.gl\/q0EKN2"
      } ]
    },
    "geo" : { },
    "id_str" : "781850865535750144",
    "text" : "Don't forget today it the last day to submit a talk for #LGBTSTEMINAR https:\/\/t.co\/92qtfPXuRT - Don't miss out!",
    "id" : 781850865535750144,
    "created_at" : "2016-09-30 13:39:07 +0000",
    "user" : {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "protected" : false,
      "id_str" : "27841081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745191411327328256\/PI3LgJTF_normal.jpg",
      "id" : 27841081,
      "verified" : false
    }
  },
  "id" : 781853459427553280,
  "created_at" : "2016-09-30 13:49:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/ITXDc1Vp9L",
      "expanded_url" : "http:\/\/www.vohwinkel.net\/home\/2010-11\/kindersachentroedelmarkt.htm",
      "display_url" : "vohwinkel.net\/home\/2010-11\/k\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "781849828393443328",
  "geo" : { },
  "id_str" : "781852713923510273",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot some google-fu later: B\u00FCrgerBahnhof Vohwinkel, c.f. https:\/\/t.co\/ITXDc1Vp9L",
  "id" : 781852713923510273,
  "in_reply_to_status_id" : 781849828393443328,
  "created_at" : "2016-09-30 13:46:27 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240358860839, 8.62754042049296 ]
  },
  "id_str" : "781845535569379328",
  "text" : "\u2018Error code -43\u2032 means I need to get a new Time Machine backup, right?",
  "id" : 781845535569379328,
  "created_at" : "2016-09-30 13:17:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "[]",
      "screen_name" : "himbeer_",
      "indices" : [ 0, 9 ],
      "id_str" : "761209723794382848",
      "id" : 761209723794382848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/2aeuu4zv80",
      "expanded_url" : "https:\/\/github.com\/ropensci\/onboarding\/blob\/master\/policies.md",
      "display_url" : "github.com\/ropensci\/onboa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "781829566197297152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240972390081, 8.62750770704867 ]
  },
  "id_str" : "781840170547118080",
  "in_reply_to_user_id" : 761209723794382848,
  "text" : "@himbeer_ well hidden but there is https:\/\/t.co\/2aeuu4zv80",
  "id" : 781840170547118080,
  "in_reply_to_status_id" : 781829566197297152,
  "created_at" : "2016-09-30 12:56:37 +0000",
  "in_reply_to_screen_name" : "himbeer_",
  "in_reply_to_user_id_str" : "761209723794382848",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/LAP35isNdG",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/watch-an-impromptu-medieval-icelandic-hymn-sung-in-a-modern-train-station",
      "display_url" : "atlasobscura.com\/articles\/watch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781820700554321920",
  "text" : "Who knew that Wuppertal\u2019s main station could be useful for something after all? https:\/\/t.co\/LAP35isNdG",
  "id" : 781820700554321920,
  "created_at" : "2016-09-30 11:39:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781801538985406464",
  "geo" : { },
  "id_str" : "781813723556085760",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer found mine yesterday and was puzzled as well :D",
  "id" : 781813723556085760,
  "in_reply_to_status_id" : 781801538985406464,
  "created_at" : "2016-09-30 11:11:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yogi Jaeger",
      "screen_name" : "yoginho",
      "indices" : [ 3, 11 ],
      "id_str" : "91583793",
      "id" : 91583793
    }, {
      "name" : "EPFL",
      "screen_name" : "EPFL_en",
      "indices" : [ 69, 77 ],
      "id_str" : "104604540",
      "id" : 104604540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781813453036085248",
  "text" : "RT @yoginho: Another example (after the Human Brain Project) of what @EPFL_en president Patrick Aebischer calls a focus on \u201Cexcellence\u201D in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EPFL",
        "screen_name" : "EPFL_en",
        "indices" : [ 56, 64 ],
        "id_str" : "104604540",
        "id" : 104604540
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/D4tzyVMnQE",
        "expanded_url" : "https:\/\/twitter.com\/schneiderleonid\/status\/781779546131619840",
        "display_url" : "twitter.com\/schneiderleoni\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781786968711626752",
    "text" : "Another example (after the Human Brain Project) of what @EPFL_en president Patrick Aebischer calls a focus on \u201Cexcellence\u201D in research. https:\/\/t.co\/D4tzyVMnQE",
    "id" : 781786968711626752,
    "created_at" : "2016-09-30 09:25:12 +0000",
    "user" : {
      "name" : "Yogi Jaeger",
      "screen_name" : "yoginho",
      "protected" : false,
      "id_str" : "91583793",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537098099\/yogi_normal.jpg",
      "id" : 91583793,
      "verified" : false
    }
  },
  "id" : 781813453036085248,
  "created_at" : "2016-09-30 11:10:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/XqVNTLtkYg",
      "expanded_url" : "https:\/\/twitter.com\/o_guest\/status\/781792442001612800",
      "display_url" : "twitter.com\/o_guest\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240666910129, 8.627553933186729 ]
  },
  "id_str" : "781795972150075392",
  "text" : "Actually, no one believed these results even before that happened. \uD83D\uDE02 https:\/\/t.co\/XqVNTLtkYg",
  "id" : 781795972150075392,
  "created_at" : "2016-09-30 10:00:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781789448971415552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17242838362736, 8.62750035976369 ]
  },
  "id_str" : "781795388500115456",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg \uD83D\uDC96\uD83D\uDC96\uD83D\uDC96\uD83D\uDC96",
  "id" : 781795388500115456,
  "in_reply_to_status_id" : 781789448971415552,
  "created_at" : "2016-09-30 09:58:40 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781787748629897216",
  "geo" : { },
  "id_str" : "781794974430007296",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest no one ever said empirical answers have to be true in any meaningful sense. \uD83D\uDE02\uD83D\uDE07",
  "id" : 781794974430007296,
  "in_reply_to_status_id" : 781787748629897216,
  "created_at" : "2016-09-30 09:57:01 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781777865528451072",
  "geo" : { },
  "id_str" : "781778123272650752",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon always people using their technical jargon :(",
  "id" : 781778123272650752,
  "in_reply_to_status_id" : 781777865528451072,
  "created_at" : "2016-09-30 08:50:03 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781740208274288640",
  "geo" : { },
  "id_str" : "781773756209520640",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy \u201Ewake me up when I\u2019m out of job\u201C :D",
  "id" : 781773756209520640,
  "in_reply_to_status_id" : 781740208274288640,
  "created_at" : "2016-09-30 08:32:42 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781771069996822528",
  "geo" : { },
  "id_str" : "781771151597006848",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 \uD83D\uDE31 that\u2019s a hard trade-off to make!",
  "id" : 781771151597006848,
  "in_reply_to_status_id" : 781771069996822528,
  "created_at" : "2016-09-30 08:22:21 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/781770954863247360\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/MjoOGzBtbu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtlogpEWAAAfjYP.jpg",
      "id_str" : "781770920314667008",
      "id" : 781770920314667008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtlogpEWAAAfjYP.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/MjoOGzBtbu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781770483977060352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241731970405, 8.627494687725086 ]
  },
  "id_str" : "781770954863247360",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 convinced. How about I come over for a coffee \uD83D\uDE02 https:\/\/t.co\/MjoOGzBtbu",
  "id" : 781770954863247360,
  "in_reply_to_status_id" : 781770483977060352,
  "created_at" : "2016-09-30 08:21:34 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781770084603850752",
  "geo" : { },
  "id_str" : "781770262794600448",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 you\u2019re happily invited to come over to have a look (and a coffee!)",
  "id" : 781770262794600448,
  "in_reply_to_status_id" : 781770084603850752,
  "created_at" : "2016-09-30 08:18:49 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/781769090641854464\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/IFvZrEMVJv",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ctlm0-0XgAAYEoq.jpg",
      "id_str" : "781769070727364608",
      "id" : 781769070727364608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ctlm0-0XgAAYEoq.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 244
      } ],
      "display_url" : "pic.twitter.com\/IFvZrEMVJv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781769090641854464",
  "text" : "Academics trying to fix the broken espresso machine. https:\/\/t.co\/IFvZrEMVJv",
  "id" : 781769090641854464,
  "created_at" : "2016-09-30 08:14:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The CSPH",
      "screen_name" : "TheCSPH",
      "indices" : [ 3, 11 ],
      "id_str" : "65074661",
      "id" : 65074661
    }, {
      "name" : "#periodpositive",
      "screen_name" : "PeriodPositive",
      "indices" : [ 95, 110 ],
      "id_str" : "906374994",
      "id" : 906374994
    }, {
      "name" : "Chella Quint",
      "screen_name" : "chellaquint",
      "indices" : [ 112, 124 ],
      "id_str" : "189873080",
      "id" : 189873080
    }, {
      "name" : "Mx Nillin",
      "screen_name" : "MxNillin",
      "indices" : [ 130, 139 ],
      "id_str" : "3091030988",
      "id" : 3091030988
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "menstruation",
      "indices" : [ 56, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781765872536940544",
  "text" : "RT @TheCSPH: The *flow* chart on inclusive messages abt #menstruation is delightful! Thanks to @periodpositive, @chellaquint, and @MxNillin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "#periodpositive",
        "screen_name" : "PeriodPositive",
        "indices" : [ 82, 97 ],
        "id_str" : "906374994",
        "id" : 906374994
      }, {
        "name" : "Chella Quint",
        "screen_name" : "chellaquint",
        "indices" : [ 99, 111 ],
        "id_str" : "189873080",
        "id" : 189873080
      }, {
        "name" : "Mx Nillin",
        "screen_name" : "MxNillin",
        "indices" : [ 117, 126 ],
        "id_str" : "3091030988",
        "id" : 3091030988
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheCSPH\/status\/781592171912790016\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/8iNld80vMI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtjFJN5XEAAleeu.jpg",
        "id_str" : "781591297488523264",
        "id" : 781591297488523264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtjFJN5XEAAleeu.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 678
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 678
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 678
        } ],
        "display_url" : "pic.twitter.com\/8iNld80vMI"
      } ],
      "hashtags" : [ {
        "text" : "menstruation",
        "indices" : [ 43, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "781592171912790016",
    "text" : "The *flow* chart on inclusive messages abt #menstruation is delightful! Thanks to @periodpositive, @chellaquint, and @MxNillin for sharing! https:\/\/t.co\/8iNld80vMI",
    "id" : 781592171912790016,
    "created_at" : "2016-09-29 20:31:09 +0000",
    "user" : {
      "name" : "The CSPH",
      "screen_name" : "TheCSPH",
      "protected" : false,
      "id_str" : "65074661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/848311908696567809\/juWDjwoo_normal.jpg",
      "id" : 65074661,
      "verified" : false
    }
  },
  "id" : 781765872536940544,
  "created_at" : "2016-09-30 08:01:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/Snxry2USyo",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/781622589454184448",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06077692516483, 8.818583020437801 ]
  },
  "id_str" : "781638796739772417",
  "text" : "Finally I know what made you go into paleontology! https:\/\/t.co\/Snxry2USyo",
  "id" : 781638796739772417,
  "created_at" : "2016-09-29 23:36:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "_katsel",
      "indices" : [ 3, 11 ],
      "id_str" : "892038837052076033",
      "id" : 892038837052076033
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 13, 24 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 25, 41 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Mike LaVigne",
      "screen_name" : "MikeLaVigne_",
      "indices" : [ 42, 55 ],
      "id_str" : "2213865002",
      "id" : 2213865002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781629750943023104",
  "text" : "RT @_katsel: @bella_velo @gedankenstuecke @MikeLaVigne_ Sorry, this \u203Amen don't have periods\u2039 and \u203Afemale biology\u2039 stuff is cissexist as shi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
        "screen_name" : "bella_velo",
        "indices" : [ 0, 11 ],
        "id_str" : "6745972",
        "id" : 6745972
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 12, 28 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Mike LaVigne",
        "screen_name" : "MikeLaVigne_",
        "indices" : [ 29, 42 ],
        "id_str" : "2213865002",
        "id" : 2213865002
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "781565430016122880",
    "geo" : { },
    "id_str" : "781614700333334528",
    "in_reply_to_user_id" : 6745972,
    "text" : "@bella_velo @gedankenstuecke @MikeLaVigne_ Sorry, this \u203Amen don't have periods\u2039 and \u203Afemale biology\u2039 stuff is cissexist as shit.",
    "id" : 781614700333334528,
    "in_reply_to_status_id" : 781565430016122880,
    "created_at" : "2016-09-29 22:00:40 +0000",
    "in_reply_to_screen_name" : "bella_velo",
    "in_reply_to_user_id_str" : "6745972",
    "user" : {
      "name" : "Katharina",
      "screen_name" : "katheyrina",
      "protected" : false,
      "id_str" : "730326143295959040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/885460122394349569\/oHlt5LK-_normal.jpg",
      "id" : 730326143295959040,
      "verified" : false
    }
  },
  "id" : 781629750943023104,
  "created_at" : "2016-09-29 23:00:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "_katsel",
      "indices" : [ 0, 8 ],
      "id_str" : "892038837052076033",
      "id" : 892038837052076033
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 9, 20 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "Mike LaVigne",
      "screen_name" : "MikeLaVigne_",
      "indices" : [ 21, 34 ],
      "id_str" : "2213865002",
      "id" : 2213865002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781614700333334528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078762036134, 8.818606733208414 ]
  },
  "id_str" : "781629743552720896",
  "in_reply_to_user_id" : 730326143295959040,
  "text" : "@_katsel @bella_velo @MikeLaVigne_ good point \uD83D\uDE22",
  "id" : 781629743552720896,
  "in_reply_to_status_id" : 781614700333334528,
  "created_at" : "2016-09-29 23:00:27 +0000",
  "in_reply_to_screen_name" : "katheyrina",
  "in_reply_to_user_id_str" : "730326143295959040",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enguerrand Habran",
      "screen_name" : "EnguerrandH",
      "indices" : [ 15, 27 ],
      "id_str" : "1480632475",
      "id" : 1480632475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781608109932441600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06113447110584, 8.818720620733782 ]
  },
  "id_str" : "781608280275681284",
  "in_reply_to_user_id" : 2968079445,
  "text" : "@AnneAdamPluen @EnguerrandH that\u2019s great. And pleased to meet!",
  "id" : 781608280275681284,
  "in_reply_to_status_id" : 781608109932441600,
  "created_at" : "2016-09-29 21:35:10 +0000",
  "in_reply_to_screen_name" : "AnneHTTP404",
  "in_reply_to_user_id_str" : "2968079445",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gobble Gobble \uD83E\uDD83",
      "screen_name" : "EntirelyAmelia",
      "indices" : [ 3, 18 ],
      "id_str" : "585789428",
      "id" : 585789428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/fg6ajiBcBm",
      "expanded_url" : "http:\/\/jezebel.com\/the-feminist-bookstore-featured-in-portlandia-has-a-fuc-1787223865?utm_medium=sharefromsite&utm_source=Jezebel_twitter",
      "display_url" : "jezebel.com\/the-feminist-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781591847407849472",
  "text" : "RT @EntirelyAmelia: \uD83D\uDC4F\uD83D\uDC4F\uD83D\uDC4F The Feminist Bookstore Featured in Portlandia Has a 'Fuck Portlandia' Sign in the Window https:\/\/t.co\/fg6ajiBcBm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/fg6ajiBcBm",
        "expanded_url" : "http:\/\/jezebel.com\/the-feminist-bookstore-featured-in-portlandia-has-a-fuc-1787223865?utm_medium=sharefromsite&utm_source=Jezebel_twitter",
        "display_url" : "jezebel.com\/the-feminist-b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781559018103988224",
    "text" : "\uD83D\uDC4F\uD83D\uDC4F\uD83D\uDC4F The Feminist Bookstore Featured in Portlandia Has a 'Fuck Portlandia' Sign in the Window https:\/\/t.co\/fg6ajiBcBm",
    "id" : 781559018103988224,
    "created_at" : "2016-09-29 18:19:25 +0000",
    "user" : {
      "name" : "Amelia Gobble Gobble \uD83E\uDD83",
      "screen_name" : "EntirelyAmelia",
      "protected" : false,
      "id_str" : "585789428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920102858216919040\/RQ-z4sh4_normal.jpg",
      "id" : 585789428,
      "verified" : true
    }
  },
  "id" : 781591847407849472,
  "created_at" : "2016-09-29 20:29:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "Mike LaVigne",
      "screen_name" : "MikeLaVigne_",
      "indices" : [ 66, 79 ],
      "id_str" : "2213865002",
      "id" : 2213865002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/DEQse5v2sT",
      "expanded_url" : "https:\/\/medium.com\/clued-in\/the-manly-guide-to-menstruation-833d97d811ea#.d5l753pp4",
      "display_url" : "medium.com\/clued-in\/the-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781586021016281088",
  "text" : "RT @bella_velo: Great article \u201CThe Manly Guide to Menstruation\u201D\u200A\u2014\u200A@MikeLaVigne_ https:\/\/t.co\/DEQse5v2sT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike LaVigne",
        "screen_name" : "MikeLaVigne_",
        "indices" : [ 50, 63 ],
        "id_str" : "2213865002",
        "id" : 2213865002
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/DEQse5v2sT",
        "expanded_url" : "https:\/\/medium.com\/clued-in\/the-manly-guide-to-menstruation-833d97d811ea#.d5l753pp4",
        "display_url" : "medium.com\/clued-in\/the-m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781565430016122880",
    "text" : "Great article \u201CThe Manly Guide to Menstruation\u201D\u200A\u2014\u200A@MikeLaVigne_ https:\/\/t.co\/DEQse5v2sT",
    "id" : 781565430016122880,
    "created_at" : "2016-09-29 18:44:53 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 781586021016281088,
  "created_at" : "2016-09-29 20:06:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karyn MeltzSteinberg",
      "screen_name" : "KMS_Meltzy",
      "indices" : [ 0, 11 ],
      "id_str" : "1425644274",
      "id" : 1425644274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781563267990839297",
  "geo" : { },
  "id_str" : "781584804290715648",
  "in_reply_to_user_id" : 1425644274,
  "text" : "@KMS_Meltzy talking to others who feel the same is always a good start for me. \uD83D\uDC4B",
  "id" : 781584804290715648,
  "in_reply_to_status_id" : 781563267990839297,
  "created_at" : "2016-09-29 20:01:53 +0000",
  "in_reply_to_screen_name" : "KMS_Meltzy",
  "in_reply_to_user_id_str" : "1425644274",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thursday Bram",
      "screen_name" : "thursdayb",
      "indices" : [ 3, 13 ],
      "id_str" : "1008061",
      "id" : 1008061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781559091596582912",
  "text" : "RT @thursdayb: Projects you shouldn't take on without extremely experienced advisors: crypto, time zones, and inclusive language. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/575G1r46V8",
        "expanded_url" : "https:\/\/recompilermag.com\/2016\/09\/21\/announcing-our-first-section-editors-for-the-responsible-communication-style-guide\/",
        "display_url" : "recompilermag.com\/2016\/09\/21\/ann\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781524667962126336",
    "text" : "Projects you shouldn't take on without extremely experienced advisors: crypto, time zones, and inclusive language. https:\/\/t.co\/575G1r46V8",
    "id" : 781524667962126336,
    "created_at" : "2016-09-29 16:02:55 +0000",
    "user" : {
      "name" : "Thursday Bram",
      "screen_name" : "thursdayb",
      "protected" : false,
      "id_str" : "1008061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558850098440859648\/LYbgqe8c_normal.jpeg",
      "id" : 1008061,
      "verified" : false
    }
  },
  "id" : 781559091596582912,
  "created_at" : "2016-09-29 18:19:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "indices" : [ 0, 14 ],
      "id_str" : "3209949862",
      "id" : 3209949862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781537241323614208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06044747312558, 8.814886305489404 ]
  },
  "id_str" : "781551866790436865",
  "in_reply_to_user_id" : 3209949862,
  "text" : "@AprilHathcock totally, I started to conciously replace the dudes usually cited when writing intros.",
  "id" : 781551866790436865,
  "in_reply_to_status_id" : 781537241323614208,
  "created_at" : "2016-09-29 17:51:00 +0000",
  "in_reply_to_screen_name" : "AprilHathcock",
  "in_reply_to_user_id_str" : "3209949862",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 15, 25 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781550152020615168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05977605872426, 8.810747908067535 ]
  },
  "id_str" : "781550737876811776",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima @Julie_B92 Ich bin wirklich genervt davon wie schwer es ist deutsch zu lernen. \uD83D\uDE02",
  "id" : 781550737876811776,
  "in_reply_to_status_id" : 781550152020615168,
  "created_at" : "2016-09-29 17:46:31 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781549298467106817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05948894875099, 8.808327804418383 ]
  },
  "id_str" : "781550408778985472",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima I\u2019m serious, putting ones vocabulary to use is super useful, even if it\u2019s still small. Best way to learn.",
  "id" : 781550408778985472,
  "in_reply_to_status_id" : 781549298467106817,
  "created_at" : "2016-09-29 17:45:12 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781519414118256641",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08026405242279, 8.811337575324634 ]
  },
  "id_str" : "781547520023494656",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima doing pretty well!",
  "id" : 781547520023494656,
  "in_reply_to_status_id" : 781519414118256641,
  "created_at" : "2016-09-29 17:33:43 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724120652943, 8.627501067044658 ]
  },
  "id_str" : "781519042934874112",
  "text" : "Tree reconstruction, aka: \u201CYou can expect your results in 6 months, give or take a few days\u201D. \uD83D\uDE02",
  "id" : 781519042934874112,
  "created_at" : "2016-09-29 15:40:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781518031746981888",
  "geo" : { },
  "id_str" : "781518116954275840",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima that\u2019s like the biggest part of the \uD83D\uDC96 for it!",
  "id" : 781518116954275840,
  "in_reply_to_status_id" : 781518031746981888,
  "created_at" : "2016-09-29 15:36:53 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781514443809185797",
  "geo" : { },
  "id_str" : "781514762026876928",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy just visiting for once! \uD83C\uDF89",
  "id" : 781514762026876928,
  "in_reply_to_status_id" : 781514443809185797,
  "created_at" : "2016-09-29 15:23:33 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777608631252418560",
  "geo" : { },
  "id_str" : "781513577500999682",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy so, will be around SFO ~20th of November or so (leaving 26th).",
  "id" : 781513577500999682,
  "in_reply_to_status_id" : 777608631252418560,
  "created_at" : "2016-09-29 15:18:51 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 0, 12 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "Karissa McKelvey",
      "screen_name" : "okdistribute",
      "indices" : [ 13, 26 ],
      "id_str" : "21713505",
      "id" : 21713505
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 39, 53 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781511045676343297",
  "geo" : { },
  "id_str" : "781511223292661761",
  "in_reply_to_user_id" : 12241752,
  "text" : "@denormalize @okdistribute even though @Protohedgehog just left he\u2019ll know tons of people there!",
  "id" : 781511223292661761,
  "in_reply_to_status_id" : 781511045676343297,
  "created_at" : "2016-09-29 15:09:30 +0000",
  "in_reply_to_screen_name" : "denormalize",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781501097106169857",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241747116036, 8.627501665383011 ]
  },
  "id_str" : "781501703786995712",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 okay, gotta figure out my size then \uD83D\uDE0A",
  "id" : 781501703786995712,
  "in_reply_to_status_id" : 781501097106169857,
  "created_at" : "2016-09-29 14:31:40 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781498952751407104",
  "geo" : { },
  "id_str" : "781499017427582978",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 are you happy with it? :)",
  "id" : 781499017427582978,
  "in_reply_to_status_id" : 781498952751407104,
  "created_at" : "2016-09-29 14:20:59 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/QlbfRIENRy",
      "expanded_url" : "http:\/\/www.svahausa.com\/product\/dna-iconic-double-helix-stripes-dress\/",
      "display_url" : "svahausa.com\/product\/dna-ic\u2026"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/cuO2RybWFt",
      "expanded_url" : "https:\/\/twitter.com\/Julie_B92\/status\/781494260793311233",
      "display_url" : "twitter.com\/Julie_B92\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241735205535, 8.6275381013751 ]
  },
  "id_str" : "781496335652491264",
  "text" : "There\u2019s also one with DNA. \uD83D\uDE0D And there I thought I wouldn\u2019t dress up for my PhD defense! https:\/\/t.co\/QlbfRIENRy https:\/\/t.co\/cuO2RybWFt",
  "id" : 781496335652491264,
  "created_at" : "2016-09-29 14:10:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/781488264297545728\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/fBSvBu1WoZ",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cthmq6iWYAAZo9n.jpg",
      "id_str" : "781487422802649088",
      "id" : 781487422802649088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cthmq6iWYAAZo9n.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/fBSvBu1WoZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780765640089042944",
  "geo" : { },
  "id_str" : "781488264297545728",
  "in_reply_to_user_id" : 14286491,
  "text" : "Worked on the viz: My last 6 years of daily travel, boiled down to less than 60 seconds. https:\/\/t.co\/fBSvBu1WoZ",
  "id" : 781488264297545728,
  "in_reply_to_status_id" : 780765640089042944,
  "created_at" : "2016-09-29 13:38:16 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "indices" : [ 3, 10 ],
      "id_str" : "47876842",
      "id" : 47876842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenAccess",
      "indices" : [ 17, 28 ]
    }, {
      "text" : "oa",
      "indices" : [ 114, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/S9J9lJ0Dwz",
      "expanded_url" : "http:\/\/buff.ly\/2cDRUaO",
      "display_url" : "buff.ly\/2cDRUaO"
    } ]
  },
  "geo" : { },
  "id_str" : "781483979358756864",
  "text" : "RT @brembs: BAM! #OpenAccess journal eLife to start charging fees - and GlamFees at that! https:\/\/t.co\/S9J9lJ0Dwz #oa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenAccess",
        "indices" : [ 5, 16 ]
      }, {
        "text" : "oa",
        "indices" : [ 102, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/S9J9lJ0Dwz",
        "expanded_url" : "http:\/\/buff.ly\/2cDRUaO",
        "display_url" : "buff.ly\/2cDRUaO"
      } ]
    },
    "geo" : { },
    "id_str" : "781471632930078720",
    "text" : "BAM! #OpenAccess journal eLife to start charging fees - and GlamFees at that! https:\/\/t.co\/S9J9lJ0Dwz #oa",
    "id" : 781471632930078720,
    "created_at" : "2016-09-29 12:32:10 +0000",
    "user" : {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "protected" : false,
      "id_str" : "47876842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524937570984013824\/uPSUsTcU_normal.png",
      "id" : 47876842,
      "verified" : false
    }
  },
  "id" : 781483979358756864,
  "created_at" : "2016-09-29 13:21:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241332768795, 8.627505945425845 ]
  },
  "id_str" : "781445606980149248",
  "text" : "The weird trip planning continues. FRA \u2708\uFE0F KEF \u2708\uFE0F BWI \u2708\uFE0F LAX \uD83D\uDE85 SAN \uD83D\uDE97 SFO \u2708\uFE0F KEF \u2708\uFE0F FRA.",
  "id" : 781445606980149248,
  "created_at" : "2016-09-29 10:48:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781421427505426432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232258549874, 8.627595248961997 ]
  },
  "id_str" : "781422122098982913",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon you don\u2019t have to convince me. But then I did grow up ~14\u00B0 more north. Which is ~ difference from home to Iceland. \uD83D\uDE02",
  "id" : 781422122098982913,
  "in_reply_to_status_id" : 781421427505426432,
  "created_at" : "2016-09-29 09:15:26 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/781420199056637952\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/9Awxbz8I7b",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CtgpgqPWEAEIlBS.jpg",
      "id_str" : "781420176419983361",
      "id" : 781420176419983361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CtgpgqPWEAEIlBS.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/9Awxbz8I7b"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781420199056637952",
  "text" : "\u00ABI think I could survive Iceland if we\u2019d go in November, but not with grace.\u00BB https:\/\/t.co\/9Awxbz8I7b",
  "id" : 781420199056637952,
  "created_at" : "2016-09-29 09:07:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "indices" : [ 15, 29 ],
      "id_str" : "3209949862",
      "id" : 3209949862
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 56, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/McvpKeniZJ",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/781384692033544192",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "781384692033544192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235998652785, 8.627564775200124 ]
  },
  "id_str" : "781396979565858816",
  "in_reply_to_user_id" : 14286491,
  "text" : "By the kickass @AprilHathcock. If you read one piece on #FutureCommons today make it this one. https:\/\/t.co\/McvpKeniZJ",
  "id" : 781396979565858816,
  "in_reply_to_status_id" : 781384692033544192,
  "created_at" : "2016-09-29 07:35:32 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/4oELELP018",
      "expanded_url" : "https:\/\/aprilhathcock.wordpress.com\/2016\/09\/27\/making-the-local-global-the-colonialism-of-scholarly-communication\/",
      "display_url" : "aprilhathcock.wordpress.com\/2016\/09\/27\/mak\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781384692033544192",
  "text" : "\u00ABThe Western neoliberal research institution is alive and well and fully colonized across the globe.\u00BB https:\/\/t.co\/4oELELP018",
  "id" : 781384692033544192,
  "created_at" : "2016-09-29 06:46:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janet D. Stemwedel",
      "screen_name" : "docfreeride",
      "indices" : [ 3, 15 ],
      "id_str" : "17175139",
      "id" : 17175139
    }, {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 27, 37 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/sE4VT6k6At",
      "expanded_url" : "https:\/\/www.buzzfeed.com\/tamerragriffin\/neil-degrasse-tyson-sexual-harassment-science-community?utm_term=.keRnNJYX5#.kpZ6rOP0L",
      "display_url" : "buzzfeed.com\/tamerragriffin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781254492155174912",
  "text" : "RT @docfreeride: Cool that @neiltyson is so confident on the basis of all the research he cites (none, by my count)\nhttps:\/\/t.co\/sE4VT6k6At",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neil deGrasse Tyson",
        "screen_name" : "neiltyson",
        "indices" : [ 10, 20 ],
        "id_str" : "19725644",
        "id" : 19725644
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/sE4VT6k6At",
        "expanded_url" : "https:\/\/www.buzzfeed.com\/tamerragriffin\/neil-degrasse-tyson-sexual-harassment-science-community?utm_term=.keRnNJYX5#.kpZ6rOP0L",
        "display_url" : "buzzfeed.com\/tamerragriffin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781187345844363264",
    "text" : "Cool that @neiltyson is so confident on the basis of all the research he cites (none, by my count)\nhttps:\/\/t.co\/sE4VT6k6At",
    "id" : 781187345844363264,
    "created_at" : "2016-09-28 17:42:31 +0000",
    "user" : {
      "name" : "Janet D. Stemwedel",
      "screen_name" : "docfreeride",
      "protected" : false,
      "id_str" : "17175139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2750509030\/a5f3cdbcdf6ed45f411f87cfc4e33736_normal.jpeg",
      "id" : 17175139,
      "verified" : true
    }
  },
  "id" : 781254492155174912,
  "created_at" : "2016-09-28 22:09:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/QvmBgmkT8W",
      "expanded_url" : "https:\/\/twitter.com\/pjacock\/status\/781161524312309760",
      "display_url" : "twitter.com\/pjacock\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086907059309, 8.818513744207879 ]
  },
  "id_str" : "781248146806542337",
  "text" : "This whole thread reads like a weird sports event commentary. Bioinformatics triathlon: configure, make, cry. https:\/\/t.co\/QvmBgmkT8W",
  "id" : 781248146806542337,
  "created_at" : "2016-09-28 21:44:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Schwartz",
      "screen_name" : "dschwartz_pf",
      "indices" : [ 0, 13 ],
      "id_str" : "3824125822",
      "id" : 3824125822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/GVYsdb2QDI",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/781173049181802497",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "781189053928669184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06094803809373, 8.818585056780122 ]
  },
  "id_str" : "781189262792388608",
  "in_reply_to_user_id" : 3824125822,
  "text" : "@dschwartz_pf https:\/\/t.co\/GVYsdb2QDI",
  "id" : 781189262792388608,
  "in_reply_to_status_id" : 781189053928669184,
  "created_at" : "2016-09-28 17:50:08 +0000",
  "in_reply_to_screen_name" : "dschwartz_pf",
  "in_reply_to_user_id_str" : "3824125822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781172808546156544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085333072307, 8.818665599276601 ]
  },
  "id_str" : "781173064226709504",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU well spotted! :D",
  "id" : 781173064226709504,
  "in_reply_to_status_id" : 781172808546156544,
  "created_at" : "2016-09-28 16:45:46 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Chin",
      "screen_name" : "infoecho",
      "indices" : [ 0, 9 ],
      "id_str" : "29575969",
      "id" : 29575969
    }, {
      "name" : "Neil Gaiman",
      "screen_name" : "neilhimself",
      "indices" : [ 27, 39 ],
      "id_str" : "18393773",
      "id" : 18393773
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/781173049181802497\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/pE51KOussv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtdIqV1WcAAGFWu.jpg",
      "id_str" : "781172952624689152",
      "id" : 781172952624689152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtdIqV1WcAAGFWu.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/pE51KOussv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781172693760552960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085333072307, 8.818665599276601 ]
  },
  "id_str" : "781173049181802497",
  "in_reply_to_user_id" : 29575969,
  "text" : "@infoecho American Gods by @neilhimself. https:\/\/t.co\/pE51KOussv",
  "id" : 781173049181802497,
  "in_reply_to_status_id" : 781172693760552960,
  "created_at" : "2016-09-28 16:45:43 +0000",
  "in_reply_to_screen_name" : "infoecho",
  "in_reply_to_user_id_str" : "29575969",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/781171353529581570\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/T2W7vzcZJh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtdHNKOXYAE0A1b.jpg",
      "id_str" : "781171351780548609",
      "id" : 781171351780548609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtdHNKOXYAE0A1b.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/T2W7vzcZJh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781171353529581570",
  "text" : "Sounds like a good set of beliefs to me. https:\/\/t.co\/T2W7vzcZJh",
  "id" : 781171353529581570,
  "created_at" : "2016-09-28 16:38:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 3, 12 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781150134772068352",
  "text" : "RT @crowd_ai: ICYMI: The openfood nutrition challenge has a $2000 prize + travel &amp; hotel to Applied Machine Learning Days at EPFL https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/qujbrMaiPH",
        "expanded_url" : "https:\/\/www.crowdai.org\/challenges\/3",
        "display_url" : "crowdai.org\/challenges\/3"
      } ]
    },
    "geo" : { },
    "id_str" : "781146839840124928",
    "text" : "ICYMI: The openfood nutrition challenge has a $2000 prize + travel &amp; hotel to Applied Machine Learning Days at EPFL https:\/\/t.co\/qujbrMaiPH",
    "id" : 781146839840124928,
    "created_at" : "2016-09-28 15:01:34 +0000",
    "user" : {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "protected" : false,
      "id_str" : "706885331224813568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710716318849363968\/JG-XbwBL_normal.jpg",
      "id" : 706885331224813568,
      "verified" : false
    }
  },
  "id" : 781150134772068352,
  "created_at" : "2016-09-28 15:14:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/zfp0woLWvJ",
      "expanded_url" : "https:\/\/twitter.com\/tkb\/status\/781141283494621185",
      "display_url" : "twitter.com\/tkb\/status\/781\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781149307777015808",
  "text" : "Oh, dammit! Not again! https:\/\/t.co\/zfp0woLWvJ",
  "id" : 781149307777015808,
  "created_at" : "2016-09-28 15:11:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/uaDyy4BUsE",
      "expanded_url" : "https:\/\/twitter.com\/AwkwardSciPoses\/status\/780884843651600385",
      "display_url" : "twitter.com\/AwkwardSciPose\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781142504510980096",
  "text" : "A standard amongst the academic Power Poses. https:\/\/t.co\/uaDyy4BUsE",
  "id" : 781142504510980096,
  "created_at" : "2016-09-28 14:44:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781081042572681216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241666446191, 8.627492590206398 ]
  },
  "id_str" : "781124045525975041",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg damit ist er wohl der letzte :D",
  "id" : 781124045525975041,
  "in_reply_to_status_id" : 781081042572681216,
  "created_at" : "2016-09-28 13:30:59 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "indices" : [ 3, 12 ],
      "id_str" : "2442015493",
      "id" : 2442015493
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTSTEMinar",
      "indices" : [ 68, 81 ]
    }, {
      "text" : "LGBTSTEM",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/SyIg5HknZ6",
      "expanded_url" : "https:\/\/lgbtstem.wordpress.com\/lgbt-steminar-2017\/",
      "display_url" : "lgbtstem.wordpress.com\/lgbt-steminar-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781119062864789504",
  "text" : "RT @LGBTSTEM: Reminder: deadline for submitting a talk for the 2017 #LGBTSTEMinar is this Friday! https:\/\/t.co\/SyIg5HknZ6 #LGBTSTEM #QueerI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTSTEMinar",
        "indices" : [ 54, 67 ]
      }, {
        "text" : "LGBTSTEM",
        "indices" : [ 108, 117 ]
      }, {
        "text" : "QueerInSTEM",
        "indices" : [ 118, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/SyIg5HknZ6",
        "expanded_url" : "https:\/\/lgbtstem.wordpress.com\/lgbt-steminar-2017\/",
        "display_url" : "lgbtstem.wordpress.com\/lgbt-steminar-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780846769924149249",
    "text" : "Reminder: deadline for submitting a talk for the 2017 #LGBTSTEMinar is this Friday! https:\/\/t.co\/SyIg5HknZ6 #LGBTSTEM #QueerInSTEM",
    "id" : 780846769924149249,
    "created_at" : "2016-09-27 19:09:12 +0000",
    "user" : {
      "name" : "LGBTQ+ STEM",
      "screen_name" : "LGBTSTEM",
      "protected" : false,
      "id_str" : "2442015493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685082380223295488\/XGTcyfxo_normal.jpg",
      "id" : 2442015493,
      "verified" : false
    }
  },
  "id" : 781119062864789504,
  "created_at" : "2016-09-28 13:11:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/nHk3SUIvJw",
      "expanded_url" : "http:\/\/images.firstwefeast.com\/complex\/image\/upload\/naxxy8t6f0a0wgalvi5m.gif",
      "display_url" : "images.firstwefeast.com\/complex\/image\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781114043415265280",
  "text" : "Inconsistent filesystem? \uD83D\uDE31\uD83D\uDE31\uD83D\uDE31 https:\/\/t.co\/nHk3SUIvJw",
  "id" : 781114043415265280,
  "created_at" : "2016-09-28 12:51:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grandmaster Clock \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "HvMythenmetz",
      "indices" : [ 0, 13 ],
      "id_str" : "24688078",
      "id" : 24688078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781100403345788928",
  "geo" : { },
  "id_str" : "781101440873922560",
  "in_reply_to_user_id" : 24688078,
  "text" : "@HvMythenmetz same here, probably for the same reason\u2026",
  "id" : 781101440873922560,
  "in_reply_to_status_id" : 781100403345788928,
  "created_at" : "2016-09-28 12:01:10 +0000",
  "in_reply_to_screen_name" : "HvMythenmetz",
  "in_reply_to_user_id_str" : "24688078",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781100536259080193",
  "geo" : { },
  "id_str" : "781101403699875840",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot cool!  \uD83C\uDF89 Machen wir ein Doodle? :P",
  "id" : 781101403699875840,
  "in_reply_to_status_id" : 781100536259080193,
  "created_at" : "2016-09-28 12:01:01 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781097955671601153",
  "geo" : { },
  "id_str" : "781099308829536256",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich Same here. Aber gehen wir mal wieder was essen in n\u00E4herer Zukunft? \uD83C\uDF5C",
  "id" : 781099308829536256,
  "in_reply_to_status_id" : 781097955671601153,
  "created_at" : "2016-09-28 11:52:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jojo Scoble \uD83D\uDD2C",
      "screen_name" : "Paraphyso",
      "indices" : [ 3, 13 ],
      "id_str" : "290019499",
      "id" : 290019499
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 42, 51 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/GChU6BiQcG",
      "expanded_url" : "https:\/\/www.theguardian.com\/lifeandstyle\/2016\/sep\/27\/tinder-online-dating-apps-blind-dates-love?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/lifeandstyle\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781094630884511744",
  "text" : "RT @Paraphyso: Depressing as fu**, thanks @guardian : Love me Tinder \u2013 tales from the frontline of modern dating https:\/\/t.co\/GChU6BiQcG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 27, 36 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/GChU6BiQcG",
        "expanded_url" : "https:\/\/www.theguardian.com\/lifeandstyle\/2016\/sep\/27\/tinder-online-dating-apps-blind-dates-love?CMP=share_btn_tw",
        "display_url" : "theguardian.com\/lifeandstyle\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "781063252486807552",
    "text" : "Depressing as fu**, thanks @guardian : Love me Tinder \u2013 tales from the frontline of modern dating https:\/\/t.co\/GChU6BiQcG",
    "id" : 781063252486807552,
    "created_at" : "2016-09-28 09:29:25 +0000",
    "user" : {
      "name" : "Jojo Scoble \uD83D\uDD2C",
      "screen_name" : "Paraphyso",
      "protected" : false,
      "id_str" : "290019499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564863846121496576\/UZqFw1vO_normal.jpeg",
      "id" : 290019499,
      "verified" : false
    }
  },
  "id" : 781094630884511744,
  "created_at" : "2016-09-28 11:34:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781035401733672960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241946379163, 8.627511344183995 ]
  },
  "id_str" : "781088365504565248",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer good to know, already had my renewal date for US put down in the calendar.",
  "id" : 781088365504565248,
  "in_reply_to_status_id" : 781035401733672960,
  "created_at" : "2016-09-28 11:09:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/v8CMydgnhU",
      "expanded_url" : "https:\/\/twitter.com\/AhistoricalPics\/status\/780976753858613248",
      "display_url" : "twitter.com\/AhistoricalPic\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241504306792, 8.627498144201892 ]
  },
  "id_str" : "781070093342081024",
  "text" : "Blame TED talks. https:\/\/t.co\/v8CMydgnhU",
  "id" : 781070093342081024,
  "created_at" : "2016-09-28 09:56:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Festival",
      "screen_name" : "mozillafestival",
      "indices" : [ 3, 19 ],
      "id_str" : "348416778",
      "id" : 348416778
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mozfest",
      "indices" : [ 53, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781069223900708864",
  "text" : "RT @mozillafestival: We've extended the deadline for #Mozfest ticket sales! Grab your ticket (and your friend's) today: https:\/\/t.co\/dKLEPm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Erik Westra",
        "screen_name" : "erikwestra",
        "indices" : [ 129, 140 ],
        "id_str" : "16955151",
        "id" : 16955151
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mozillafestival\/status\/780753868397445120\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/zhUcFoqb3z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtXLgUzWYAANvcT.jpg",
        "id_str" : "780753866618986496",
        "id" : 780753866618986496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtXLgUzWYAANvcT.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 715,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 715,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 715,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/zhUcFoqb3z"
      } ],
      "hashtags" : [ {
        "text" : "Mozfest",
        "indices" : [ 32, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/dKLEPmu25D",
        "expanded_url" : "http:\/\/mzl.la\/mozfesttkts",
        "display_url" : "mzl.la\/mozfesttkts"
      } ]
    },
    "geo" : { },
    "id_str" : "780753868397445120",
    "text" : "We've extended the deadline for #Mozfest ticket sales! Grab your ticket (and your friend's) today: https:\/\/t.co\/dKLEPmu25D photo @erikwestra https:\/\/t.co\/zhUcFoqb3z",
    "id" : 780753868397445120,
    "created_at" : "2016-09-27 13:00:02 +0000",
    "user" : {
      "name" : "Mozilla Festival",
      "screen_name" : "mozillafestival",
      "protected" : false,
      "id_str" : "348416778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/924342624621924352\/DwaKYDah_normal.jpg",
      "id" : 348416778,
      "verified" : true
    }
  },
  "id" : 781069223900708864,
  "created_at" : "2016-09-28 09:53:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/ZyCXBwFh49",
      "expanded_url" : "https:\/\/twitter.com\/llaurenmiller\/status\/780570035542695936",
      "display_url" : "twitter.com\/llaurenmiller\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241902780305, 8.627500018746412 ]
  },
  "id_str" : "781068841656909824",
  "text" : "12\/10, would watch. https:\/\/t.co\/ZyCXBwFh49",
  "id" : 781068841656909824,
  "created_at" : "2016-09-28 09:51:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 7, 18 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781062932981485568",
  "geo" : { },
  "id_str" : "781066432750743552",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @plaetzchen wann wird dein Bluetooth-Wearable weitergetrieben? :D",
  "id" : 781066432750743552,
  "in_reply_to_status_id" : 781062932981485568,
  "created_at" : "2016-09-28 09:42:03 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241243638995, 8.62747360611596 ]
  },
  "id_str" : "781064980087115776",
  "text" : "Hearing about the university\u2019s network regulations I feel that our cluster would be better of w\/ having random cables run across corridors\u2026",
  "id" : 781064980087115776,
  "created_at" : "2016-09-28 09:36:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/rOjE8ZFWww",
      "expanded_url" : "https:\/\/www.ncbi.nlm.nih.gov\/m\/pubmed\/20970679\/",
      "display_url" : "ncbi.nlm.nih.gov\/m\/pubmed\/20970\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "781028727153168384",
  "text" : "\u00ABUnivariate analyses comparing all 12 individual star signs showed considerable variation\u2026\u00BB \uD83D\uDE02 https:\/\/t.co\/rOjE8ZFWww",
  "id" : 781028727153168384,
  "created_at" : "2016-09-28 07:12:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05914625643573, 8.8021012010476 ]
  },
  "id_str" : "781028031607496704",
  "text" : "Hell freezes over: for the first time in years it\u2019s quicker to take public transport than taking a car in the Frankfurt metro area.",
  "id" : 781028031607496704,
  "created_at" : "2016-09-28 07:09:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/qhBbagHWRg",
      "expanded_url" : "https:\/\/twitter.com\/humansofny\/status\/771034568401059841",
      "display_url" : "twitter.com\/humansofny\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780903050798137344",
  "text" : "RT @bella_velo: This 5-part series on PTSD is brilliant and rings true to non-war PTSD trauma too https:\/\/t.co\/qhBbagHWRg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/qhBbagHWRg",
        "expanded_url" : "https:\/\/twitter.com\/humansofny\/status\/771034568401059841",
        "display_url" : "twitter.com\/humansofny\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780883183667548160",
    "text" : "This 5-part series on PTSD is brilliant and rings true to non-war PTSD trauma too https:\/\/t.co\/qhBbagHWRg",
    "id" : 780883183667548160,
    "created_at" : "2016-09-27 21:33:53 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 780903050798137344,
  "created_at" : "2016-09-27 22:52:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780776276327968769",
  "geo" : { },
  "id_str" : "780776731552743424",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye I fully agree :D",
  "id" : 780776731552743424,
  "in_reply_to_status_id" : 780776276327968769,
  "created_at" : "2016-09-27 14:30:53 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/bXMxsEb5PI",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BH988d9Dx9F\/?taken-by=gedankenstuecke",
      "display_url" : "instagram.com\/p\/BH988d9Dx9F\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "780773079089815552",
  "geo" : { },
  "id_str" : "780773324687278080",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye totally, even I had to basically cheat to get to https:\/\/t.co\/bXMxsEb5PI",
  "id" : 780773324687278080,
  "in_reply_to_status_id" : 780773079089815552,
  "created_at" : "2016-09-27 14:17:21 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780729788201832448",
  "geo" : { },
  "id_str" : "780771531265802240",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye I somehow suspected as much! Hope you enjoyed the visit!",
  "id" : 780771531265802240,
  "in_reply_to_status_id" : 780729788201832448,
  "created_at" : "2016-09-27 14:10:13 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 3, 11 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/UIHs7KTsBb",
      "expanded_url" : "https:\/\/medium.com\/p\/why-and-how-is-repositive-a-social-enterprise-cf1e7e0222",
      "display_url" : "medium.com\/p\/why-and-how-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780766572289912834",
  "text" : "RT @glyn_dk: I just published \u201CWhy and how is Repositive a social enterprise?\u201D https:\/\/t.co\/UIHs7KTsBb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/medium.com\" rel=\"nofollow\"\u003EMedium\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/UIHs7KTsBb",
        "expanded_url" : "https:\/\/medium.com\/p\/why-and-how-is-repositive-a-social-enterprise-cf1e7e0222",
        "display_url" : "medium.com\/p\/why-and-how-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780388952125665280",
    "text" : "I just published \u201CWhy and how is Repositive a social enterprise?\u201D https:\/\/t.co\/UIHs7KTsBb",
    "id" : 780388952125665280,
    "created_at" : "2016-09-26 12:49:59 +0000",
    "user" : {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "protected" : false,
      "id_str" : "32340834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3409523398\/35ae8a97e778ebb56089e9a9b58ab9b1_normal.png",
      "id" : 32340834,
      "verified" : false
    }
  },
  "id" : 780766572289912834,
  "created_at" : "2016-09-27 13:50:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/780765640089042944\/video\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/lZjCHy0PRh",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/780765608258535424\/pu\/img\/USmct8f0GwA0wL7z.jpg",
      "id_str" : "780765608258535424",
      "id" : 780765608258535424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/780765608258535424\/pu\/img\/USmct8f0GwA0wL7z.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/lZjCHy0PRh"
    } ],
    "hashtags" : [ {
      "text" : "WorldTourismDay",
      "indices" : [ 16, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780765640089042944",
  "text" : "Apparently it's #WorldTourismDay. By chance I did an animated chart of my travels since May 2011 w\/ gganimate, based on 13k geotagged tweets https:\/\/t.co\/lZjCHy0PRh",
  "id" : 780765640089042944,
  "created_at" : "2016-09-27 13:46:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 23, 36 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 43, 56 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780744834139222017",
  "geo" : { },
  "id_str" : "780745775970222080",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest yes, actually @PhilippBayer found @manuelcorpas there initially, looked into my emails :-)",
  "id" : 780745775970222080,
  "in_reply_to_status_id" : 780744834139222017,
  "created_at" : "2016-09-27 12:27:53 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780744076014526464",
  "geo" : { },
  "id_str" : "780744192104488960",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest I think the bioinformatics subreddit (if it existed back then, would have to delve into my email log to be sure)",
  "id" : 780744192104488960,
  "in_reply_to_status_id" : 780744076014526464,
  "created_at" : "2016-09-27 12:21:35 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Co159E2lDA",
      "expanded_url" : "https:\/\/reddit.authorea.com\/users\/101670\/articles\/129524\/_show_article",
      "display_url" : "reddit.authorea.com\/users\/101670\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780739298165420032",
  "text" : "As ~40 % of all my publications are based on collaborations that were born on Reddit\/Twitter I should give it a try. https:\/\/t.co\/Co159E2lDA",
  "id" : 780739298165420032,
  "created_at" : "2016-09-27 12:02:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780659687117221888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239558554289, 8.62755679077489 ]
  },
  "id_str" : "780737664395902976",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog so, when are your folks rejoining the EU then? :p",
  "id" : 780737664395902976,
  "in_reply_to_status_id" : 780659687117221888,
  "created_at" : "2016-09-27 11:55:39 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/wGQN3QnlS4",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=tJYW3jkC75A",
      "display_url" : "youtube.com\/watch?v=tJYW3j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "780730768217796609",
  "text" : "What did I just see? https:\/\/t.co\/wGQN3QnlS4",
  "id" : 780730768217796609,
  "created_at" : "2016-09-27 11:28:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/dL3zKvYIV4",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/rough-sex",
      "display_url" : "smbc-comics.com\/comic\/rough-sex"
    } ]
  },
  "geo" : { },
  "id_str" : "780692791097720832",
  "text" : "how about: let\u2019s take this 10% of the way to bed bug sex https:\/\/t.co\/dL3zKvYIV4",
  "id" : 780692791097720832,
  "created_at" : "2016-09-27 08:57:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780504510070394880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.52346179266509, 7.684944402433638 ]
  },
  "id_str" : "780516135418683393",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon oof, my bad :(",
  "id" : 780516135418683393,
  "in_reply_to_status_id" : 780504510070394880,
  "created_at" : "2016-09-26 21:15:22 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 34, 43 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/nwrVa8tJ65",
      "expanded_url" : "https:\/\/instagram.com\/p\/BK1Q9rDjMrb\/",
      "display_url" : "instagram.com\/p\/BK1Q9rDjMrb\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.9547579205955, 6.947977213171557 ]
  },
  "id_str" : "780501931672363009",
  "text" : "Chris Pureka \uD83D\uDC96 \uD83C\uDF89 (you missed out, @Senficon) https:\/\/t.co\/nwrVa8tJ65",
  "id" : 780501931672363009,
  "created_at" : "2016-09-26 20:18:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "infinome",
      "screen_name" : "InfinoMe",
      "indices" : [ 0, 9 ],
      "id_str" : "2362226100",
      "id" : 2362226100
    }, {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 18, 27 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780439478179553280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17314111074103, 8.62775226678684 ]
  },
  "id_str" : "780439565949661184",
  "in_reply_to_user_id" : 2362226100,
  "text" : "@InfinoMe thanks! @crowd_ai",
  "id" : 780439565949661184,
  "in_reply_to_status_id" : 780439478179553280,
  "created_at" : "2016-09-26 16:11:07 +0000",
  "in_reply_to_screen_name" : "InfinoMe",
  "in_reply_to_user_id_str" : "2362226100",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/oSyuKkEcHO",
      "expanded_url" : "https:\/\/twitter.com\/LGBTSTEM\/status\/780436808811237377",
      "display_url" : "twitter.com\/LGBTSTEM\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241143051964, 8.627508042365983 ]
  },
  "id_str" : "780437622191693824",
  "text" : "See some of you there. So honored you\u2019ll have me! https:\/\/t.co\/oSyuKkEcHO",
  "id" : 780437622191693824,
  "created_at" : "2016-09-26 16:03:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780405016796487684",
  "geo" : { },
  "id_str" : "780408719121276928",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv sorry to hear that! :-(",
  "id" : 780408719121276928,
  "in_reply_to_status_id" : 780405016796487684,
  "created_at" : "2016-09-26 14:08:32 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241609813852, 8.627482097683366 ]
  },
  "id_str" : "780377754936172544",
  "text" : "My backup hard drive seems to have died on me, before it could ever rescue me from any data loss.\uD83D\uDE02",
  "id" : 780377754936172544,
  "created_at" : "2016-09-26 12:05:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779769030076956672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35929321309548, 8.587648909766976 ]
  },
  "id_str" : "779771961429942272",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye it\u2019s great! Wish I had known about it earlier!",
  "id" : 779771961429942272,
  "in_reply_to_status_id" : 779769030076956672,
  "created_at" : "2016-09-24 19:58:17 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/N2Tb9TZt1A",
      "expanded_url" : "http:\/\/fondationbodmer.ch\/en\/museum\/",
      "display_url" : "fondationbodmer.ch\/en\/museum\/"
    } ]
  },
  "in_reply_to_status_id_str" : "779768535514054657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35916030407988, 8.587752063469754 ]
  },
  "id_str" : "779768686131441664",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye https:\/\/t.co\/N2Tb9TZt1A so next time you come to Geneva you\u2019ll have plans :)",
  "id" : 779768686131441664,
  "in_reply_to_status_id" : 779768535514054657,
  "created_at" : "2016-09-24 19:45:16 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35919925840762, 8.587806657991823 ]
  },
  "id_str" : "779767306209615872",
  "text" : "That moment when you get a Google Scholar notification about a new paper that you had forgot you co-authored.",
  "id" : 779767306209615872,
  "created_at" : "2016-09-24 19:39:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/S6EdFD8TzN",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BKwCsojDDgK\/",
      "display_url" : "instagram.com\/p\/BKwCsojDDgK\/"
    } ]
  },
  "geo" : { },
  "id_str" : "779766684072673282",
  "text" : "Up up up https:\/\/t.co\/S6EdFD8TzN",
  "id" : 779766684072673282,
  "created_at" : "2016-09-24 19:37:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779584743516045312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35928949964092, 8.58764345363261 ]
  },
  "id_str" : "779765984332775426",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC have fun!",
  "id" : 779765984332775426,
  "in_reply_to_status_id" : 779584743516045312,
  "created_at" : "2016-09-24 19:34:32 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/779765621881995269\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/U2cyiaklmQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtJIszWW8AAzgTU.jpg",
      "id_str" : "779765620023947264",
      "id" : 779765620023947264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtJIszWW8AAzgTU.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/U2cyiaklmQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779765621881995269",
  "text" : "Kepler's work has a centerfold that's a bit different. https:\/\/t.co\/U2cyiaklmQ",
  "id" : 779765621881995269,
  "created_at" : "2016-09-24 19:33:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779735347982925824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.41713058338886, 8.394365333241938 ]
  },
  "id_str" : "779747377641127936",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze weird conferences I end up at :p",
  "id" : 779747377641127936,
  "in_reply_to_status_id" : 779735347982925824,
  "created_at" : "2016-09-24 18:20:36 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779736326748921856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.96415645311023, 7.450717022292488 ]
  },
  "id_str" : "779736588674818048",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon not a bit. Was a great walk there and the exhibit is great!",
  "id" : 779736588674818048,
  "in_reply_to_status_id" : 779736326748921856,
  "created_at" : "2016-09-24 17:37:44 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manolis Dermitzakis",
      "screen_name" : "dermitzakis",
      "indices" : [ 25, 37 ],
      "id_str" : "19668775",
      "id" : 19668775
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/779734317324984320\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/zZb4z9VdSq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIsOCYWEAAR6bW.jpg",
      "id_str" : "779734305157287936",
      "id" : 779734305157287936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIsOCYWEAAR6bW.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zZb4z9VdSq"
    } ],
    "hashtags" : [ {
      "text" : "PHDA2016",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.94869851425182, 7.437353989488865 ]
  },
  "id_str" : "779734317324984320",
  "text" : "I think this is +\/- what @dermitzakis suggested at #PHDA2016 https:\/\/t.co\/zZb4z9VdSq",
  "id" : 779734317324984320,
  "created_at" : "2016-09-24 17:28:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/K0uXYLwaK0",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BKvzHY8DoPy\/",
      "display_url" : "instagram.com\/p\/BKvzHY8DoPy\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.2020619031, 6.12409548433 ]
  },
  "id_str" : "779732429288402944",
  "text" : "Flow @ Pont de La Jonction https:\/\/t.co\/K0uXYLwaK0",
  "id" : 779732429288402944,
  "created_at" : "2016-09-24 17:21:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 87, 101 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/779731573029629952\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/ezkoWrrU2t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIpu2MWIAIgnZy.jpg",
      "id_str" : "779731570286534658",
      "id" : 779731570286534658,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIpu2MWIAIgnZy.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/ezkoWrrU2t"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779731573029629952",
  "text" : "Saw a first edition of \"On The Origin of Species\" today. Thanks for the recommendation @zoonpolitikon! \uD83D\uDC96 https:\/\/t.co\/ezkoWrrU2t",
  "id" : 779731573029629952,
  "created_at" : "2016-09-24 17:17:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/779627302170812416\/photo\/1",
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/rSn5u4XVOZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtHK5iOWAAAArum.jpg",
      "id_str" : "779627300300128256",
      "id" : 779627300300128256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtHK5iOWAAAArum.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/rSn5u4XVOZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779627302170812416",
  "text" : "Thomas Huxley on labels. https:\/\/t.co\/rSn5u4XVOZ",
  "id" : 779627302170812416,
  "created_at" : "2016-09-24 10:23:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/779626792688779264\/photo\/1",
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/1NnKthBaFt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtHKb19WgAAu3QU.jpg",
      "id_str" : "779626790201491456",
      "id" : 779626790201491456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtHKb19WgAAu3QU.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/1NnKthBaFt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779626792688779264",
  "text" : "Pssst https:\/\/t.co\/1NnKthBaFt",
  "id" : 779626792688779264,
  "created_at" : "2016-09-24 10:21:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779352520514830340",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22214756765472, 6.149014831946594 ]
  },
  "id_str" : "779558029926789120",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks much appreciated \uD83D\uDE18",
  "id" : 779558029926789120,
  "in_reply_to_status_id" : 779352520514830340,
  "created_at" : "2016-09-24 05:48:12 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779319569353740288",
  "geo" : { },
  "id_str" : "779321383373471745",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin dating of the LCA split.",
  "id" : 779321383373471745,
  "in_reply_to_status_id" : 779319569353740288,
  "created_at" : "2016-09-23 14:07:51 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779317916001005568",
  "geo" : { },
  "id_str" : "779319571748679681",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc don\u2019t worry, it\u2019s PNAS, so a &gt;95% chance of being BS in any case.",
  "id" : 779319571748679681,
  "in_reply_to_status_id" : 779317916001005568,
  "created_at" : "2016-09-23 14:00:39 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/2dKeN6TsdR",
      "expanded_url" : "https:\/\/aeon.co\/essays\/why-keeping-a-pet-is-fundamentally-unethical",
      "display_url" : "aeon.co\/essays\/why-kee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779316091042598912",
  "text" : "\u00ABWe love our dogs, but recognise that, if the world were more just and fair, there would be no pets at all\u00BB https:\/\/t.co\/2dKeN6TsdR",
  "id" : 779316091042598912,
  "created_at" : "2016-09-23 13:46:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779312181611466752",
  "geo" : { },
  "id_str" : "779312969394028545",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot you don\u2019t say \uD83D\uDC89\uD83D\uDC89\uD83D\uDC89\uD83D\uDC89",
  "id" : 779312969394028545,
  "in_reply_to_status_id" : 779312181611466752,
  "created_at" : "2016-09-23 13:34:25 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779311009177735168",
  "geo" : { },
  "id_str" : "779311190212304896",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 yes! there\u2019s a free ferry over to it behind the Centraal. (Never was in the museum though).",
  "id" : 779311190212304896,
  "in_reply_to_status_id" : 779311009177735168,
  "created_at" : "2016-09-23 13:27:21 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/QIbwD4ZUxG",
      "expanded_url" : "http:\/\/www.villagevoice.com\/music\/on-blood-bitch-norwegian-singer-jenny-hval-is-inspired-by-vampires-and-menstruation-9128651",
      "display_url" : "villagevoice.com\/music\/on-blood\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779310693338214400",
  "text" : "On 'Blood Bitch,' Norwegian Singer Jenny Hval Is Inspired by Vampires and Menstruation https:\/\/t.co\/QIbwD4ZUxG",
  "id" : 779310693338214400,
  "created_at" : "2016-09-23 13:25:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779308114353020929",
  "geo" : { },
  "id_str" : "779308386273914880",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 the EYE film museum :)",
  "id" : 779308386273914880,
  "in_reply_to_status_id" : 779308114353020929,
  "created_at" : "2016-09-23 13:16:12 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F Rodriguez-Sanchez",
      "screen_name" : "frod_san",
      "indices" : [ 3, 12 ],
      "id_str" : "326299187",
      "id" : 326299187
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/frod_san\/status\/779299913251389441\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/69R8V3wbDr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtChDYnWIAAmvV0.jpg",
      "id_str" : "779299815054254080",
      "id" : 779299815054254080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtChDYnWIAAmvV0.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 667
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 667
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 667
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 667
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/69R8V3wbDr"
    } ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/u66gPoPpo4",
      "expanded_url" : "https:\/\/cran.r-project.org\/web\/packages\/plotluck\/vignettes\/plotluck.html",
      "display_url" : "cran.r-project.org\/web\/packages\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779307776455639040",
  "text" : "RT @frod_san: plotluck: 'I'm feeling lucky' for ggplot https:\/\/t.co\/u66gPoPpo4 #rstats https:\/\/t.co\/69R8V3wbDr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/frod_san\/status\/779299913251389441\/photo\/1",
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/69R8V3wbDr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtChDYnWIAAmvV0.jpg",
        "id_str" : "779299815054254080",
        "id" : 779299815054254080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtChDYnWIAAmvV0.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 667
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 667
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 667
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 667
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/69R8V3wbDr"
      } ],
      "hashtags" : [ {
        "text" : "rstats",
        "indices" : [ 65, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/u66gPoPpo4",
        "expanded_url" : "https:\/\/cran.r-project.org\/web\/packages\/plotluck\/vignettes\/plotluck.html",
        "display_url" : "cran.r-project.org\/web\/packages\/p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779299913251389441",
    "text" : "plotluck: 'I'm feeling lucky' for ggplot https:\/\/t.co\/u66gPoPpo4 #rstats https:\/\/t.co\/69R8V3wbDr",
    "id" : 779299913251389441,
    "created_at" : "2016-09-23 12:42:32 +0000",
    "user" : {
      "name" : "F Rodriguez-Sanchez",
      "screen_name" : "frod_san",
      "protected" : false,
      "id_str" : "326299187",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2726771918\/8eff91c8cabe7eb6736f0ca05c2d3ee4_normal.jpeg",
      "id" : 326299187,
      "verified" : false
    }
  },
  "id" : 779307776455639040,
  "created_at" : "2016-09-23 13:13:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779303150587113472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22146678168097, 6.146073533302175 ]
  },
  "id_str" : "779303866496081921",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps \uD83D\uDC4B",
  "id" : 779303866496081921,
  "in_reply_to_status_id" : 779303150587113472,
  "created_at" : "2016-09-23 12:58:15 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marthe \uD83D\uDD2C\uD83D\uDC69\u200D\uD83D\uDD2C",
      "screen_name" : "MartheHR",
      "indices" : [ 3, 12 ],
      "id_str" : "351597535",
      "id" : 351597535
    }, {
      "name" : "New Scientist",
      "screen_name" : "newscientist",
      "indices" : [ 99, 112 ],
      "id_str" : "19658826",
      "id" : 19658826
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 113, 121 ]
    }, {
      "text" : "lifeofascientist",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779299514888941568",
  "text" : "RT @MartheHR: Must have for every scientist - it would be a thriving business for the card seller .@newscientist #science #lifeofascientist\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "New Scientist",
        "screen_name" : "newscientist",
        "indices" : [ 85, 98 ],
        "id_str" : "19658826",
        "id" : 19658826
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MartheHR\/status\/779287140031164416\/photo\/1",
        "indices" : [ 126, 149 ],
        "url" : "https:\/\/t.co\/EhbPDEWYdm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtCVfo5WgAAD0ky.jpg",
        "id_str" : "779287106321547264",
        "id" : 779287106321547264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtCVfo5WgAAD0ky.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1206,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1206,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 707,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/EhbPDEWYdm"
      } ],
      "hashtags" : [ {
        "text" : "science",
        "indices" : [ 99, 107 ]
      }, {
        "text" : "lifeofascientist",
        "indices" : [ 108, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779287140031164416",
    "text" : "Must have for every scientist - it would be a thriving business for the card seller .@newscientist #science #lifeofascientist https:\/\/t.co\/EhbPDEWYdm",
    "id" : 779287140031164416,
    "created_at" : "2016-09-23 11:51:47 +0000",
    "user" : {
      "name" : "Marthe \uD83D\uDD2C\uD83D\uDC69\u200D\uD83D\uDD2C",
      "screen_name" : "MartheHR",
      "protected" : false,
      "id_str" : "351597535",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846104221095247872\/aFUuEhWX_normal.jpg",
      "id" : 351597535,
      "verified" : false
    }
  },
  "id" : 779299514888941568,
  "created_at" : "2016-09-23 12:40:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778725537367793665",
  "geo" : { },
  "id_str" : "779291481278414848",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest omg! \uD83D\uDC96",
  "id" : 779291481278414848,
  "in_reply_to_status_id" : 778725537367793665,
  "created_at" : "2016-09-23 12:09:02 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PHDA2016",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22153210358888, 6.146244577618923 ]
  },
  "id_str" : "779283984052260864",
  "text" : "\u00ABCome closer to the front. The Wifi is stronger here.\u00BB \uD83D\uDE02 #PHDA2016",
  "id" : 779283984052260864,
  "created_at" : "2016-09-23 11:39:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Muirhead",
      "screen_name" : "jessica_digital",
      "indices" : [ 3, 19 ],
      "id_str" : "273423436",
      "id" : 273423436
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StackOverflow",
      "indices" : [ 25, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/8PgWuNY7G9",
      "expanded_url" : "https:\/\/denaeford.wordpress.com\/2016\/07\/20\/paradise-unplugged-barriers-to-stack-overflow-use\/",
      "display_url" : "denaeford.wordpress.com\/2016\/07\/20\/par\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779265376366518272",
  "text" : "RT @jessica_digital: Why #StackOverflow is a predominantly male resource:\nhttps:\/\/t.co\/8PgWuNY7G9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StackOverflow",
        "indices" : [ 4, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/8PgWuNY7G9",
        "expanded_url" : "https:\/\/denaeford.wordpress.com\/2016\/07\/20\/paradise-unplugged-barriers-to-stack-overflow-use\/",
        "display_url" : "denaeford.wordpress.com\/2016\/07\/20\/par\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779225066550784000",
    "text" : "Why #StackOverflow is a predominantly male resource:\nhttps:\/\/t.co\/8PgWuNY7G9",
    "id" : 779225066550784000,
    "created_at" : "2016-09-23 07:45:07 +0000",
    "user" : {
      "name" : "Jessica Muirhead",
      "screen_name" : "jessica_digital",
      "protected" : false,
      "id_str" : "273423436",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/931438680035745792\/0-01vzPT_normal.jpg",
      "id" : 273423436,
      "verified" : false
    }
  },
  "id" : 779265376366518272,
  "created_at" : "2016-09-23 10:25:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "regretsy",
      "indices" : [ 7, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/ZKgCUR5ULb",
      "expanded_url" : "https:\/\/img0.etsystatic.com\/069\/0\/11562387\/il_570xN.820511472_pcmj.jpg",
      "display_url" : "img0.etsystatic.com\/069\/0\/11562387\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "779257525757677568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.2219052259462, 6.147770037045908 ]
  },
  "id_str" : "779260205641113600",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot #regretsy https:\/\/t.co\/ZKgCUR5ULb",
  "id" : 779260205641113600,
  "in_reply_to_status_id" : 779257525757677568,
  "created_at" : "2016-09-23 10:04:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PHDA2016",
      "indices" : [ 16, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/dcAfaBjQPS",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BKsZRHBj4XF\/",
      "display_url" : "instagram.com\/p\/BKsZRHBj4XF\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.2221718, 6.1482601 ]
  },
  "id_str" : "779253366417391616",
  "text" : "Coffee break at #PHDA2016 @ Campus Biotech https:\/\/t.co\/dcAfaBjQPS",
  "id" : 779253366417391616,
  "created_at" : "2016-09-23 09:37:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779251343693320193",
  "text" : "Any recommendations on how to fix a broken spacebar on an 11\u201C Macbook Air? Askingforafriend.",
  "id" : 779251343693320193,
  "created_at" : "2016-09-23 09:29:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/kVoAPFCuld",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/779241689055629312",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779243187248463872",
  "text" : "Guess now I\u2019ll have to step up and figure my flights out! https:\/\/t.co\/kVoAPFCuld",
  "id" : 779243187248463872,
  "created_at" : "2016-09-23 08:57:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779241365750288384",
  "text" : "csvkit + datamash \uD83D\uDC96",
  "id" : 779241365750288384,
  "created_at" : "2016-09-23 08:49:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779238194953027584",
  "geo" : { },
  "id_str" : "779238833598636032",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed well, but then i\u2019m pretty sure that none of the music festivals would make the top10 in the country indicators? :P",
  "id" : 779238833598636032,
  "in_reply_to_status_id" : 779238194953027584,
  "created_at" : "2016-09-23 08:39:50 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/EJXQmT0nw5",
      "expanded_url" : "http:\/\/www.bloomberg.com\/news\/articles\/2016-09-22\/america-is-not-the-greatest-country-on-earth-it-s-no-28",
      "display_url" : "bloomberg.com\/news\/articles\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779236138666037248",
  "text" : "America Is Not the Greatest Country on Earth. Iceland Is. https:\/\/t.co\/EJXQmT0nw5",
  "id" : 779236138666037248,
  "created_at" : "2016-09-23 08:29:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/Z7oICBUu9L",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/779235057345060864",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779235636565925888",
  "text" : "Another point showing that reference genomes have been a poor workaround all along. https:\/\/t.co\/Z7oICBUu9L",
  "id" : 779235636565925888,
  "created_at" : "2016-09-23 08:27:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 135, 158 ],
      "url" : "https:\/\/t.co\/R1jK0x2WZk",
      "expanded_url" : "https:\/\/twitter.com\/CameronNeylon\/status\/779003443822419969",
      "display_url" : "twitter.com\/CameronNeylon\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779233985721499648",
  "text" : "\u00ABTo make any claim of a truly shared and global conception of this \u201Cscholarly commons\u201D we clearly need to bake in inclusive processes\u00BB https:\/\/t.co\/R1jK0x2WZk",
  "id" : 779233985721499648,
  "created_at" : "2016-09-23 08:20:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/XFzXaMOFZB",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/dinosaurs",
      "display_url" : "smbc-comics.com\/comic\/dinosaurs"
    } ]
  },
  "geo" : { },
  "id_str" : "779216629423104000",
  "text" : "has science gone too far? https:\/\/t.co\/XFzXaMOFZB",
  "id" : 779216629423104000,
  "created_at" : "2016-09-23 07:11:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/wj5RXYBrM8",
      "expanded_url" : "http:\/\/verstaendlich.ch\/2009\/07\/11\/das-gegenteil-ist-dasselbe\/",
      "display_url" : "verstaendlich.ch\/2009\/07\/11\/das\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779051879921844225",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe some reading material for your way home :) https:\/\/t.co\/wj5RXYBrM8",
  "id" : 779051879921844225,
  "created_at" : "2016-09-22 20:16:56 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779051037210664961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22184627131345, 6.149000333337804 ]
  },
  "id_str" : "779051255909978112",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute you\u2019re doing this on purpose to drag me to the Lithuanian woods, don\u2019t you?",
  "id" : 779051255909978112,
  "in_reply_to_status_id" : 779051037210664961,
  "created_at" : "2016-09-22 20:14:28 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779050499903524864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22171506755633, 6.149097522726422 ]
  },
  "id_str" : "779050792212951040",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute leaving Monday morning. You must be kidding me!",
  "id" : 779050792212951040,
  "in_reply_to_status_id" : 779050499903524864,
  "created_at" : "2016-09-22 20:12:37 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Gaiman",
      "screen_name" : "neilhimself",
      "indices" : [ 5, 17 ],
      "id_str" : "18393773",
      "id" : 18393773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22212320097091, 6.14911833625736 ]
  },
  "id_str" : "779031315177992192",
  "text" : "\u00ABMr. @neilhimself must have had some plane tickets paid by you, with all the books you\u2019ve bought lately. He should come over for a reading.\u00BB",
  "id" : 779031315177992192,
  "created_at" : "2016-09-22 18:55:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778988252875350016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22148429410082, 6.14614144346019 ]
  },
  "id_str" : "778988440062918656",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye I don\u2019t think so, but I can ask!",
  "id" : 778988440062918656,
  "in_reply_to_status_id" : 778988252875350016,
  "created_at" : "2016-09-22 16:04:51 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778987533434818560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22153615212446, 6.14626254910133 ]
  },
  "id_str" : "778987864977772546",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena hell if I know anything about soccer. I even missed that Germany apparently won some kind of world cup. :)",
  "id" : 778987864977772546,
  "in_reply_to_status_id" : 778987533434818560,
  "created_at" : "2016-09-22 16:02:34 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 0, 14 ],
      "id_str" : "15154811",
      "id" : 15154811
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 75, 83 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "annoytheeisens",
      "indices" : [ 56, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778986448158547970",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22153615212446, 6.14626254910133 ]
  },
  "id_str" : "778987521468428288",
  "in_reply_to_user_id" : 15154811,
  "text" : "@phylogenomics add to that the left-handed DNA and it\u2019s #annoytheeisens ;) @mbeisen",
  "id" : 778987521468428288,
  "in_reply_to_status_id" : 778986448158547970,
  "created_at" : "2016-09-22 16:01:12 +0000",
  "in_reply_to_screen_name" : "phylogenomics",
  "in_reply_to_user_id_str" : "15154811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 3, 17 ],
      "id_str" : "15154811",
      "id" : 15154811
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 19, 35 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badomics",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778986552403918848",
  "text" : "RT @phylogenomics: @gedankenstuecke nope -- bad bad #badomics word",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "badomics",
        "indices" : [ 33, 42 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "778985094799294470",
    "geo" : { },
    "id_str" : "778986448158547970",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke nope -- bad bad #badomics word",
    "id" : 778986448158547970,
    "in_reply_to_status_id" : 778985094799294470,
    "created_at" : "2016-09-22 15:56:56 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "protected" : false,
      "id_str" : "15154811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751288576403382273\/AKfTiFxx_normal.jpg",
      "id" : 15154811,
      "verified" : true
    }
  },
  "id" : 778986552403918848,
  "created_at" : "2016-09-22 15:57:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yannis Jaquet",
      "screen_name" : "yannis_",
      "indices" : [ 0, 8 ],
      "id_str" : "7128662",
      "id" : 7128662
    }, {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 9, 23 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778978198503776256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22152258143203, 6.146229063482964 ]
  },
  "id_str" : "778985622765703168",
  "in_reply_to_user_id" : 7128662,
  "text" : "@yannis_ @marcelsalathe sure, even have a fridge magnet for you :D",
  "id" : 778985622765703168,
  "in_reply_to_status_id" : 778978198503776256,
  "created_at" : "2016-09-22 15:53:39 +0000",
  "in_reply_to_screen_name" : "yannis_",
  "in_reply_to_user_id_str" : "7128662",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 37, 51 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/778985094799294470\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/c5hWFCXgIB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs-CyVLXYAEnTUR.jpg",
      "id_str" : "778985061748269057",
      "id" : 778985061748269057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs-CyVLXYAEnTUR.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/c5hWFCXgIB"
    } ],
    "hashtags" : [ {
      "text" : "PHDA2016",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22149761589471, 6.146163410239422 ]
  },
  "id_str" : "778985094799294470",
  "text" : "\u201CTechnolomics\u201C heard that one before @phylogenomics? #PHDA2016 https:\/\/t.co\/c5hWFCXgIB",
  "id" : 778985094799294470,
  "created_at" : "2016-09-22 15:51:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Baudis",
      "screen_name" : "mbaudis",
      "indices" : [ 0, 8 ],
      "id_str" : "44348435",
      "id" : 44348435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778981974845296641",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22149822298471, 6.146122483468059 ]
  },
  "id_str" : "778983184579059720",
  "in_reply_to_user_id" : 44348435,
  "text" : "@mbaudis too many workgroups and too little time to get involved in all of them. But all the best for the Metadata! So important!",
  "id" : 778983184579059720,
  "in_reply_to_status_id" : 778981974845296641,
  "created_at" : "2016-09-22 15:43:58 +0000",
  "in_reply_to_screen_name" : "mbaudis",
  "in_reply_to_user_id_str" : "44348435",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Baudis",
      "screen_name" : "mbaudis",
      "indices" : [ 0, 8 ],
      "id_str" : "44348435",
      "id" : 44348435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778982591517036544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22149384649487, 6.146152993358593 ]
  },
  "id_str" : "778982864222298113",
  "in_reply_to_user_id" : 44348435,
  "text" : "@mbaudis not consistently so far. Should clean up that repository :p",
  "id" : 778982864222298113,
  "in_reply_to_status_id" : 778982591517036544,
  "created_at" : "2016-09-22 15:42:42 +0000",
  "in_reply_to_screen_name" : "mbaudis",
  "in_reply_to_user_id_str" : "44348435",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/778982498432933888\/photo\/1",
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/keujg44sK1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs-AZKoWgAAa3uQ.jpg",
      "id_str" : "778982430397071360",
      "id" : 778982430397071360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs-AZKoWgAAa3uQ.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/keujg44sK1"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/778982498432933888\/photo\/1",
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/keujg44sK1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs-AZO-WIAAWmWa.jpg",
      "id_str" : "778982431563063296",
      "id" : 778982431563063296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs-AZO-WIAAWmWa.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/keujg44sK1"
    } ],
    "hashtags" : [ {
      "text" : "PHDA2016",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22150284428488, 6.146128587613763 ]
  },
  "id_str" : "778982498432933888",
  "text" : "Our lack of trust in IT security at least partially informed our decision to offer no privacy-options in openSNP. #PHDA2016 https:\/\/t.co\/keujg44sK1",
  "id" : 778982498432933888,
  "created_at" : "2016-09-22 15:41:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Baudis",
      "screen_name" : "mbaudis",
      "indices" : [ 0, 8 ],
      "id_str" : "44348435",
      "id" : 44348435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778979520661622784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22151463531841, 6.14621400871389 ]
  },
  "id_str" : "778979967908610048",
  "in_reply_to_user_id" : 44348435,
  "text" : "@mbaudis thanks, will make a good addition for the next time I talk about it. Today was a first on that!",
  "id" : 778979967908610048,
  "in_reply_to_status_id" : 778979520661622784,
  "created_at" : "2016-09-22 15:31:11 +0000",
  "in_reply_to_screen_name" : "mbaudis",
  "in_reply_to_user_id_str" : "44348435",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22148919359989, 6.146187458223769 ]
  },
  "id_str" : "778975222678581248",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe well done!",
  "id" : 778975222678581248,
  "created_at" : "2016-09-22 15:12:20 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PHDA2016",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/InJ2zqQyD4",
      "expanded_url" : "https:\/\/twitter.com\/AnneAdamPluen\/status\/778952637102301184",
      "display_url" : "twitter.com\/AnneAdamPluen\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22148477590878, 6.146168112717655 ]
  },
  "id_str" : "778970863513329665",
  "text" : "By the way: come and say Hi if you want some of those openSNP stickers too! #PHDA2016 https:\/\/t.co\/InJ2zqQyD4",
  "id" : 778970863513329665,
  "created_at" : "2016-09-22 14:55:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "varsome",
      "screen_name" : "varsome",
      "indices" : [ 0, 8 ],
      "id_str" : "730290856490639360",
      "id" : 730290856490639360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778965196035489792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22153997463143, 6.146235015956117 ]
  },
  "id_str" : "778965946933313536",
  "in_reply_to_user_id" : 730290856490639360,
  "text" : "@varsome thanks!",
  "id" : 778965946933313536,
  "in_reply_to_status_id" : 778965196035489792,
  "created_at" : "2016-09-22 14:35:28 +0000",
  "in_reply_to_screen_name" : "varsome",
  "in_reply_to_user_id_str" : "730290856490639360",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22149976676059, 6.146167240568399 ]
  },
  "id_str" : "778961293260754944",
  "text" : "\u00ABThe future is bright even with challenges ahead.\u00BB Gosh, that\u2019s a good horoscope\/business presentation. \uD83D\uDD2E\uD83D\uDE02",
  "id" : 778961293260754944,
  "created_at" : "2016-09-22 14:16:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PDHA2016",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22152130191373, 6.146212521970197 ]
  },
  "id_str" : "778954853078958080",
  "text" : "Wait, didn\u2019t Steve Jobs die because he opted not to use any medicine at all? #PDHA2016",
  "id" : 778954853078958080,
  "created_at" : "2016-09-22 13:51:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778946385303461888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22150319356817, 6.146181582124734 ]
  },
  "id_str" : "778954053149716480",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg that\u2019s an episode i would watch!",
  "id" : 778954053149716480,
  "in_reply_to_status_id" : 778946385303461888,
  "created_at" : "2016-09-22 13:48:13 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 53, 69 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AnneAdamPluen\/status\/778952637102301184\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/hcBSZhdbvp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs9lSFfWYAAIHsi.jpg",
      "id_str" : "778952621944102912",
      "id" : 778952621944102912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs9lSFfWYAAIHsi.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/hcBSZhdbvp"
    } ],
    "hashtags" : [ {
      "text" : "PHDA2016",
      "indices" : [ 43, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778952709667979264",
  "text" : "RT @AnneAdamPluen: Guess i'm convinced \uD83D\uDE00\uD83D\uDE00\uD83D\uDE00\n#PHDA2016 @gedankenstuecke https:\/\/t.co\/hcBSZhdbvp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 34, 50 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AnneAdamPluen\/status\/778952637102301184\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/hcBSZhdbvp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs9lSFfWYAAIHsi.jpg",
        "id_str" : "778952621944102912",
        "id" : 778952621944102912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs9lSFfWYAAIHsi.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        } ],
        "display_url" : "pic.twitter.com\/hcBSZhdbvp"
      } ],
      "hashtags" : [ {
        "text" : "PHDA2016",
        "indices" : [ 24, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778952637102301184",
    "text" : "Guess i'm convinced \uD83D\uDE00\uD83D\uDE00\uD83D\uDE00\n#PHDA2016 @gedankenstuecke https:\/\/t.co\/hcBSZhdbvp",
    "id" : 778952637102301184,
    "created_at" : "2016-09-22 13:42:35 +0000",
    "user" : {
      "name" : "Anne A.",
      "screen_name" : "AnneHTTP404",
      "protected" : false,
      "id_str" : "2968079445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/906966012414906373\/McWYMDY5_normal.jpg",
      "id" : 2968079445,
      "verified" : false
    }
  },
  "id" : 778952709667979264,
  "created_at" : "2016-09-22 13:42:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 21, 37 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "privacy",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778951116088303616",
  "text" : "RT @EffyVayena: With @gedankenstuecke we will soon be sharing findings about what motivates openSNP users, and their take on #privacy. Stay\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 5, 21 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "privacy",
        "indices" : [ 109, 117 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "778930262851944448",
    "geo" : { },
    "id_str" : "778950359834300418",
    "in_reply_to_user_id" : 14286491,
    "text" : "With @gedankenstuecke we will soon be sharing findings about what motivates openSNP users, and their take on #privacy. Stay tuned!",
    "id" : 778950359834300418,
    "in_reply_to_status_id" : 778930262851944448,
    "created_at" : "2016-09-22 13:33:32 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 778951116088303616,
  "created_at" : "2016-09-22 13:36:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778950359834300418",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22153608337882, 6.146205842385644 ]
  },
  "id_str" : "778951109712998401",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena yes, those two graphs were already good to drive my point home.",
  "id" : 778951109712998401,
  "in_reply_to_status_id" : 778950359834300418,
  "created_at" : "2016-09-22 13:36:31 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yannis Jaquet",
      "screen_name" : "yannis_",
      "indices" : [ 0, 8 ],
      "id_str" : "7128662",
      "id" : 7128662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778941747388878848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22151369393833, 6.146126088739416 ]
  },
  "id_str" : "778942216844738560",
  "in_reply_to_user_id" : 7128662,
  "text" : "@yannis_ thanks!",
  "id" : 778942216844738560,
  "in_reply_to_status_id" : 778941747388878848,
  "created_at" : "2016-09-22 13:01:11 +0000",
  "in_reply_to_screen_name" : "yannis_",
  "in_reply_to_user_id_str" : "7128662",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778941917224632320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22150613377988, 6.146168398300186 ]
  },
  "id_str" : "778942012410236928",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc no problem, let\u2019s do the coffee!",
  "id" : 778942012410236928,
  "in_reply_to_status_id" : 778941917224632320,
  "created_at" : "2016-09-22 13:00:22 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778941581692903424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22152838757309, 6.14616343189401 ]
  },
  "id_str" : "778941808801964036",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc @AnneAdamPluen I promise we won\u2019t have solved all diseases by the end of the century. Mark my words :p",
  "id" : 778941808801964036,
  "in_reply_to_status_id" : 778941581692903424,
  "created_at" : "2016-09-22 12:59:33 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan Oransky",
      "screen_name" : "ivanoransky",
      "indices" : [ 3, 15 ],
      "id_str" : "15859033",
      "id" : 15859033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/VZ7T1vym6j",
      "expanded_url" : "http:\/\/retractionwatch.com\/2016\/09\/22\/doctor-who-participated-in-fake-chocolate-study-fined-for-violating-physicians-code-of-conduct\/",
      "display_url" : "retractionwatch.com\/2016\/09\/22\/doc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778935962143305728",
  "text" : "RT @ivanoransky: Doctor who participated in fake chocolate study fined for violating code of\u00A0conduct https:\/\/t.co\/VZ7T1vym6j https:\/\/t.co\/5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ivanoransky\/status\/778927363472056320\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/58eaTg1AC7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs9OTteVMAAScCt.jpg",
        "id_str" : "778927361089679360",
        "id" : 778927361089679360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs9OTteVMAAScCt.jpg",
        "sizes" : [ {
          "h" : 599,
          "resize" : "fit",
          "w" : 770
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 770
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 770
        } ],
        "display_url" : "pic.twitter.com\/58eaTg1AC7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/VZ7T1vym6j",
        "expanded_url" : "http:\/\/retractionwatch.com\/2016\/09\/22\/doctor-who-participated-in-fake-chocolate-study-fined-for-violating-physicians-code-of-conduct\/",
        "display_url" : "retractionwatch.com\/2016\/09\/22\/doc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "778927363472056320",
    "text" : "Doctor who participated in fake chocolate study fined for violating code of\u00A0conduct https:\/\/t.co\/VZ7T1vym6j https:\/\/t.co\/58eaTg1AC7",
    "id" : 778927363472056320,
    "created_at" : "2016-09-22 12:02:09 +0000",
    "user" : {
      "name" : "Ivan Oransky",
      "screen_name" : "ivanoransky",
      "protected" : false,
      "id_str" : "15859033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1485171512\/bearcubtwitter_normal.jpg",
      "id" : 15859033,
      "verified" : false
    }
  },
  "id" : 778935962143305728,
  "created_at" : "2016-09-22 12:36:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Su",
      "screen_name" : "andrewsu",
      "indices" : [ 3, 12 ],
      "id_str" : "25743783",
      "id" : 25743783
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 15, 31 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "personalizedmedicine",
      "indices" : [ 61, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/kQGqYOKMK1",
      "expanded_url" : "http:\/\/www.theatlantic.com\/daily-dish\/archive\/2010\/10\/western-educated-industrialized-rich-and-democratic\/181667\/",
      "display_url" : "theatlantic.com\/daily-dish\/arc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778934207347322880",
  "text" : "RT @andrewsu: .@gedankenstuecke detailing many inequities in #personalizedmedicine; overwhelmingly WEIRD (and male) https:\/\/t.co\/kQGqYOKMK1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 1, 17 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "personalizedmedicine",
        "indices" : [ 47, 68 ]
      }, {
        "text" : "PHDA2016",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/kQGqYOKMK1",
        "expanded_url" : "http:\/\/www.theatlantic.com\/daily-dish\/archive\/2010\/10\/western-educated-industrialized-rich-and-democratic\/181667\/",
        "display_url" : "theatlantic.com\/daily-dish\/arc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "778926542302961665",
    "text" : ".@gedankenstuecke detailing many inequities in #personalizedmedicine; overwhelmingly WEIRD (and male) https:\/\/t.co\/kQGqYOKMK1 #PHDA2016",
    "id" : 778926542302961665,
    "created_at" : "2016-09-22 11:58:54 +0000",
    "user" : {
      "name" : "Andrew Su",
      "screen_name" : "andrewsu",
      "protected" : false,
      "id_str" : "25743783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1476691686\/andrew_mug_square_normal.jpg",
      "id" : 25743783,
      "verified" : false
    }
  },
  "id" : 778934207347322880,
  "created_at" : "2016-09-22 12:29:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 35, 51 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AnneAdamPluen\/status\/778929230574972928\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/HFlmLcF1Zs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs9P2c6W8AAJlHw.jpg",
      "id_str" : "778929057450881024",
      "id" : 778929057450881024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs9P2c6W8AAJlHw.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/HFlmLcF1Zs"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/AnneAdamPluen\/status\/778929230574972928\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/HFlmLcF1Zs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs9P2czWIAAZFrs.jpg",
      "id_str" : "778929057421467648",
      "id" : 778929057421467648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs9P2czWIAAZFrs.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/HFlmLcF1Zs"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/AnneAdamPluen\/status\/778929230574972928\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/HFlmLcF1Zs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs9P2edWIAEFsXc.jpg",
      "id_str" : "778929057866063873",
      "id" : 778929057866063873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs9P2edWIAEFsXc.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/HFlmLcF1Zs"
    } ],
    "hashtags" : [ {
      "text" : "GeneticTesting",
      "indices" : [ 19, 34 ]
    }, {
      "text" : "diversity",
      "indices" : [ 69, 79 ]
    }, {
      "text" : "PHDA2016",
      "indices" : [ 81, 90 ]
    }, {
      "text" : "bioethics",
      "indices" : [ 92, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778934164942979073",
  "text" : "RT @AnneAdamPluen: #GeneticTesting @gedankenstuecke : a huge need of #diversity  #PHDA2016  #bioethics https:\/\/t.co\/HFlmLcF1Zs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 16, 32 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AnneAdamPluen\/status\/778929230574972928\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/HFlmLcF1Zs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs9P2c6W8AAJlHw.jpg",
        "id_str" : "778929057450881024",
        "id" : 778929057450881024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs9P2c6W8AAJlHw.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/HFlmLcF1Zs"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AnneAdamPluen\/status\/778929230574972928\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/HFlmLcF1Zs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs9P2czWIAAZFrs.jpg",
        "id_str" : "778929057421467648",
        "id" : 778929057421467648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs9P2czWIAAZFrs.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/HFlmLcF1Zs"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AnneAdamPluen\/status\/778929230574972928\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/HFlmLcF1Zs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs9P2edWIAEFsXc.jpg",
        "id_str" : "778929057866063873",
        "id" : 778929057866063873,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs9P2edWIAEFsXc.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/HFlmLcF1Zs"
      } ],
      "hashtags" : [ {
        "text" : "GeneticTesting",
        "indices" : [ 0, 15 ]
      }, {
        "text" : "diversity",
        "indices" : [ 50, 60 ]
      }, {
        "text" : "PHDA2016",
        "indices" : [ 62, 71 ]
      }, {
        "text" : "bioethics",
        "indices" : [ 73, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778929230574972928",
    "text" : "#GeneticTesting @gedankenstuecke : a huge need of #diversity  #PHDA2016  #bioethics https:\/\/t.co\/HFlmLcF1Zs",
    "id" : 778929230574972928,
    "created_at" : "2016-09-22 12:09:35 +0000",
    "user" : {
      "name" : "Anne A.",
      "screen_name" : "AnneHTTP404",
      "protected" : false,
      "id_str" : "2968079445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/906966012414906373\/McWYMDY5_normal.jpg",
      "id" : 2968079445,
      "verified" : false
    }
  },
  "id" : 778934164942979073,
  "created_at" : "2016-09-22 12:29:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PHDA2016",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/yQJXs60i3T",
      "expanded_url" : "https:\/\/twitter.com\/GigaScience\/status\/778902474941865985",
      "display_url" : "twitter.com\/GigaScience\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778932236091527168",
  "text" : "What happened while I was complaining about how Western European-focussed genetics research is. #PHDA2016 https:\/\/t.co\/yQJXs60i3T",
  "id" : 778932236091527168,
  "created_at" : "2016-09-22 12:21:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/778930262851944448\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/tskSVpik4D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs9Q8QBXEAAWMgF.jpg",
      "id_str" : "778930256581431296",
      "id" : 778930256581431296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs9Q8QBXEAAWMgF.jpg",
      "sizes" : [ {
        "h" : 435,
        "resize" : "fit",
        "w" : 770
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 770
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 770
      } ],
      "display_url" : "pic.twitter.com\/tskSVpik4D"
    } ],
    "hashtags" : [ {
      "text" : "PHDA2016",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/uDdEnwJCoF",
      "expanded_url" : "https:\/\/github.com\/openSNP\/presentations\/tree\/master\/2016",
      "display_url" : "github.com\/openSNP\/presen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778930262851944448",
  "text" : "Find my slides for #PHDA2016 at GitHub (Keynote + PDF): https:\/\/t.co\/uDdEnwJCoF https:\/\/t.co\/tskSVpik4D",
  "id" : 778930262851944448,
  "created_at" : "2016-09-22 12:13:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PHDA2016",
      "indices" : [ 133, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/d9J3UxE5pI",
      "expanded_url" : "https:\/\/s-media-cache-ak0.pinimg.com\/736x\/37\/c9\/a9\/37c9a9acc755a1f4c1323700fd42906a.jpg",
      "display_url" : "s-media-cache-ak0.pinimg.com\/736x\/37\/c9\/a9\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22149435057052, 6.146168457685078 ]
  },
  "id_str" : "778920268198715392",
  "text" : "No coffee until the break! Guess it\u2019s \u201CI came to drink coffee &amp; kick ass. And we\u2019re all out of coffee.\u00BB \uD83D\uDE31https:\/\/t.co\/d9J3UxE5pI #PHDA2016",
  "id" : 778920268198715392,
  "created_at" : "2016-09-22 11:33:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778906195432239104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22199139066974, 6.147886200393454 ]
  },
  "id_str" : "778908124803657728",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps it did work out!",
  "id" : 778908124803657728,
  "in_reply_to_status_id" : 778906195432239104,
  "created_at" : "2016-09-22 10:45:43 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778888899045318656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22149678957162, 6.146114975979471 ]
  },
  "id_str" : "778889990654885888",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc \uD83D\uDC4D",
  "id" : 778889990654885888,
  "in_reply_to_status_id" : 778888899045318656,
  "created_at" : "2016-09-22 09:33:39 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 7, 15 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778885108602396672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22148541156633, 6.146105442265947 ]
  },
  "id_str" : "778887916739231744",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc @betatim looking forward to it! \u2615\uFE0F",
  "id" : 778887916739231744,
  "in_reply_to_status_id" : 778885108602396672,
  "created_at" : "2016-09-22 09:25:25 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778886044469059584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22148541156633, 6.146105442265947 ]
  },
  "id_str" : "778887864679591936",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute thanks \uD83D\uDE02",
  "id" : 778887864679591936,
  "in_reply_to_status_id" : 778886044469059584,
  "created_at" : "2016-09-22 09:25:12 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PHDA2016",
      "indices" : [ 22, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/0iIsdTwNqy",
      "expanded_url" : "https:\/\/www.personalizedhealth2016.ch\/",
      "display_url" : "personalizedhealth2016.ch"
    } ]
  },
  "in_reply_to_status_id_str" : "778885559691468800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22150868623039, 6.146111043829776 ]
  },
  "id_str" : "778885798649274369",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute in Geneva at #PHDA2016 https:\/\/t.co\/0iIsdTwNqy",
  "id" : 778885798649274369,
  "in_reply_to_status_id" : 778885559691468800,
  "created_at" : "2016-09-22 09:17:00 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/778883786616500224\/photo\/1",
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/L0T7KU9a17",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs8mkhUXEAAKnRr.jpg",
      "id_str" : "778883669419298816",
      "id" : 778883669419298816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs8mkhUXEAAKnRr.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/L0T7KU9a17"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778881604102086656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22147441600011, 6.146124443164882 ]
  },
  "id_str" : "778883786616500224",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute :p https:\/\/t.co\/L0T7KU9a17",
  "id" : 778883786616500224,
  "in_reply_to_status_id" : 778881604102086656,
  "created_at" : "2016-09-22 09:09:00 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22149360927391, 6.146128192951483 ]
  },
  "id_str" : "778883612473192448",
  "text" : "Announcing public participation in Nature. Oh, the irony. \uD83D\uDE02",
  "id" : 778883612473192448,
  "created_at" : "2016-09-22 09:08:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PHDA2016",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778880527415775233",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22146551901197, 6.146108981197619 ]
  },
  "id_str" : "778880710165794816",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim will be in Geneva at #PHDA2016 until Saturday. But will then be in ZRH for the rest of the weekend!",
  "id" : 778880710165794816,
  "in_reply_to_status_id" : 778880527415775233,
  "created_at" : "2016-09-22 08:56:46 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/778877935449145344\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/UuZd0ZRsW3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs8hU09W8AAMD4B.jpg",
      "id_str" : "778877902255484928",
      "id" : 778877902255484928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs8hU09W8AAMD4B.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      } ],
      "display_url" : "pic.twitter.com\/UuZd0ZRsW3"
    } ],
    "hashtags" : [ {
      "text" : "PHDA2016",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.22145663931695, 6.146103349719414 ]
  },
  "id_str" : "778877935449145344",
  "text" : "A crowd of 6 performs as good as a single expert #PHDA2016 https:\/\/t.co\/UuZd0ZRsW3",
  "id" : 778877935449145344,
  "created_at" : "2016-09-22 08:45:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778850364065976321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.21966446038699, 6.147232841457262 ]
  },
  "id_str" : "778862341828018176",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim \uD83D\uDC4B",
  "id" : 778862341828018176,
  "in_reply_to_status_id" : 778850364065976321,
  "created_at" : "2016-09-22 07:43:47 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.23025925061927, 6.109460009198457 ]
  },
  "id_str" : "778832380668874752",
  "text" : "Good morning, Europe.",
  "id" : 778832380668874752,
  "created_at" : "2016-09-22 05:44:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 0, 11 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 81, 95 ],
      "id_str" : "12984852",
      "id" : 12984852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778707734216646657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.94597207665345, -77.4518311210698 ]
  },
  "id_str" : "778708147846254592",
  "in_reply_to_user_id" : 20653310,
  "text" : "@rchampieux maybe they\u2019ll let me parachute out over Geneva, that would even beat @CameronNeylon\u2019s getting on-stage story.",
  "id" : 778708147846254592,
  "in_reply_to_status_id" : 778707734216646657,
  "created_at" : "2016-09-21 21:31:04 +0000",
  "in_reply_to_screen_name" : "rchampieux",
  "in_reply_to_user_id_str" : "20653310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ivehearditbothways",
      "indices" : [ 99, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.94555107170988, -77.45180651966713 ]
  },
  "id_str" : "778697211123159041",
  "text" : "I hope the pilots are less confused on whether we\u2019ll go to Zurich or Geneva than the gate desk is. #ivehearditbothways",
  "id" : 778697211123159041,
  "created_at" : "2016-09-21 20:47:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.94552682050757, -77.4518235221326 ]
  },
  "id_str" : "778683786124931072",
  "text" : "\u00ABWe\u2019ll not get a soccer team worth of cats!\u00BB \u2014 \u00ABHow about 10 cats and a dog?\u00BB \u2014 \u00ABYou\u2019re a hard negotiator!\u00BB",
  "id" : 778683786124931072,
  "created_at" : "2016-09-21 19:54:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778681516528246784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.94291272445487, -77.44877078506758 ]
  },
  "id_str" : "778682466672386049",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 ridiculous amounts of Belgian beer?",
  "id" : 778682466672386049,
  "in_reply_to_status_id" : 778681516528246784,
  "created_at" : "2016-09-21 19:49:01 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/JdceE1QD41",
      "expanded_url" : "https:\/\/www.theguardian.com\/environment\/2016\/sep\/16\/norway-wolf-cull-government-wwf-friends-earth-environment-protest",
      "display_url" : "theguardian.com\/environment\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778682119744655360",
  "text" : "Getting voice calls to inform me that Norway plans to cull more than two-thirds of its wolf population \uD83D\uDE31\uD83D\uDE2D https:\/\/t.co\/JdceE1QD41",
  "id" : 778682119744655360,
  "created_at" : "2016-09-21 19:47:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778681025887031296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.9455415966583, -77.45179452730801 ]
  },
  "id_str" : "778681328464080898",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 carry-on only! \uD83D\uDC96\uD83C\uDF89",
  "id" : 778681328464080898,
  "in_reply_to_status_id" : 778681025887031296,
  "created_at" : "2016-09-21 19:44:30 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.9455326788739, -77.45176043474997 ]
  },
  "id_str" : "778680585438892034",
  "text" : "All planes on time so far, I\u2019m always amazed when these travel plans work out.",
  "id" : 778680585438892034,
  "created_at" : "2016-09-21 19:41:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Jason McDermott",
      "screen_name" : "BioDataGanache",
      "indices" : [ 11, 26 ],
      "id_str" : "1040758742",
      "id" : 1040758742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778674777666031616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.94554543392304, -77.45178409031104 ]
  },
  "id_str" : "778677084344287233",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @BioDataGanache not joking about this!",
  "id" : 778677084344287233,
  "in_reply_to_status_id" : 778674777666031616,
  "created_at" : "2016-09-21 19:27:38 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778603844083351553",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.94546177407078, -77.4506540413549 ]
  },
  "id_str" : "778672841059364864",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 in that case it\u2019s completely true. I\u2019m more likely to cry due to oversleeping.",
  "id" : 778672841059364864,
  "in_reply_to_status_id" : 778603844083351553,
  "created_at" : "2016-09-21 19:10:47 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 13, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/wphv8EJxYL",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BKntBICDcV2\/",
      "display_url" : "instagram.com\/p\/BKntBICDcV2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "778593109642977280",
  "text" : "Goodbye SAN. #FutureCommons was great again, can't wait to meet so many of you again in DC! https:\/\/t.co\/wphv8EJxYL",
  "id" : 778593109642977280,
  "created_at" : "2016-09-21 13:53:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778589944814112768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.73231990172782, -117.2023475078095 ]
  },
  "id_str" : "778590710853435393",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 we\u2019re so different :p",
  "id" : 778590710853435393,
  "in_reply_to_status_id" : 778589944814112768,
  "created_at" : "2016-09-21 13:44:25 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778491009143599104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.7325222827799, -117.2011310422022 ]
  },
  "id_str" : "778589792997105665",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 hashtag no sleep till October.",
  "id" : 778589792997105665,
  "in_reply_to_status_id" : 778491009143599104,
  "created_at" : "2016-09-21 13:40:46 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778480819509878784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.73226294537908, -117.2074956269046 ]
  },
  "id_str" : "778589700143587329",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc \uD83D\uDC4B",
  "id" : 778589700143587329,
  "in_reply_to_status_id" : 778480819509878784,
  "created_at" : "2016-09-21 13:40:24 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778477136063688704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88494678458679, -117.2451115993434 ]
  },
  "id_str" : "778477547214385152",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon yup!",
  "id" : 778477547214385152,
  "in_reply_to_status_id" : 778477136063688704,
  "created_at" : "2016-09-21 06:14:45 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/778475409260150785\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/AaI7SLuOX7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs2zQIeUsAAbHXW.jpg",
      "id_str" : "778475400338911232",
      "id" : 778475400338911232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs2zQIeUsAAbHXW.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/AaI7SLuOX7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88494024533196, -117.245123460698 ]
  },
  "id_str" : "778475409260150785",
  "text" : "Packed and managed to fit all the new books again. Now for like 4-5 hours of sleep before heading to Geneva. https:\/\/t.co\/AaI7SLuOX7",
  "id" : 778475409260150785,
  "created_at" : "2016-09-21 06:06:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 3, 16 ],
      "id_str" : "9104202",
      "id" : 9104202
    }, {
      "name" : "Force11.org",
      "screen_name" : "force11rescomm",
      "indices" : [ 88, 103 ],
      "id_str" : "720754110",
      "id" : 720754110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futurecommons",
      "indices" : [ 73, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778389938635087873",
  "text" : "RT @jeroenbosman: Thanks everyone for pushing towards scholarly commons. #futurecommons @force11rescomm. Let's take this further! https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Force11.org",
        "screen_name" : "force11rescomm",
        "indices" : [ 70, 85 ],
        "id_str" : "720754110",
        "id" : 720754110
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jeroenbosman\/status\/778386404287971328\/photo\/1",
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/woWPkoX7ff",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs1iBYEVIAA1jtc.jpg",
        "id_str" : "778386086384967680",
        "id" : 778386086384967680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs1iBYEVIAA1jtc.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/woWPkoX7ff"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/jeroenbosman\/status\/778386404287971328\/photo\/1",
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/woWPkoX7ff",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs1iCWFUIAAJret.jpg",
        "id_str" : "778386103032094720",
        "id" : 778386103032094720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs1iCWFUIAAJret.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/woWPkoX7ff"
      } ],
      "hashtags" : [ {
        "text" : "futurecommons",
        "indices" : [ 55, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/ko6eZi6iIO",
        "expanded_url" : "https:\/\/docs.google.com\/document\/d\/159e_zP-acx-AFOX97tAxban66XLW53Psg1LeqPnK4sU\/edit#",
        "display_url" : "docs.google.com\/document\/d\/159\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "778386404287971328",
    "text" : "Thanks everyone for pushing towards scholarly commons. #futurecommons @force11rescomm. Let's take this further! https:\/\/t.co\/ko6eZi6iIO https:\/\/t.co\/woWPkoX7ff",
    "id" : 778386404287971328,
    "created_at" : "2016-09-21 00:12:35 +0000",
    "user" : {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "protected" : false,
      "id_str" : "9104202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/853627325715558401\/_66XunIl_normal.jpg",
      "id" : 9104202,
      "verified" : false
    }
  },
  "id" : 778389938635087873,
  "created_at" : "2016-09-21 00:26:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beni Wohli",
      "screen_name" : "piquadrat_ch",
      "indices" : [ 0, 13 ],
      "id_str" : "798525322606051329",
      "id" : 798525322606051329
    }, {
      "name" : "Jan Lehnardt",
      "screen_name" : "janl",
      "indices" : [ 14, 19 ],
      "id_str" : "819606",
      "id" : 819606
    }, {
      "name" : "Old acct Mx. Sasha",
      "screen_name" : "erikpub",
      "indices" : [ 20, 28 ],
      "id_str" : "909518971367542785",
      "id" : 909518971367542785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778349773011247105",
  "geo" : { },
  "id_str" : "778349878095122433",
  "in_reply_to_user_id" : 86585371,
  "text" : "@piquadrat_ch @janl @erikpub yes, that\u2019s the one, thanks so much!",
  "id" : 778349878095122433,
  "in_reply_to_status_id" : 778349773011247105,
  "created_at" : "2016-09-20 21:47:26 +0000",
  "in_reply_to_screen_name" : "beniwohli",
  "in_reply_to_user_id_str" : "86585371",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778343858598019072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88871647701303, -117.2423937514078 ]
  },
  "id_str" : "778345522151108608",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest yeah, guess it\u2019s multi-factorial.",
  "id" : 778345522151108608,
  "in_reply_to_status_id" : 778343858598019072,
  "created_at" : "2016-09-20 21:30:08 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hawks",
      "screen_name" : "johnhawks",
      "indices" : [ 3, 13 ],
      "id_str" : "52584039",
      "id" : 52584039
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/johnhawks\/status\/778343794680991744\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/XxsK4DQ71x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs07jOGXEAEZB1U.jpg",
      "id_str" : "778343786871197697",
      "id" : 778343786871197697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs07jOGXEAEZB1U.jpg",
      "sizes" : [ {
        "h" : 698,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 698,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 297,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 524,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/XxsK4DQ71x"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/5SiG1VxCQa",
      "expanded_url" : "http:\/\/for-the-love-of-trees.blogspot.com\/2016\/09\/the-ancestors-are-not-among-us.html",
      "display_url" : "for-the-love-of-trees.blogspot.com\/2016\/09\/the-an\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778344557536620544",
  "text" : "RT @johnhawks: Why is the term \"basal\" so troublesome in phylogenetics? https:\/\/t.co\/5SiG1VxCQa https:\/\/t.co\/XxsK4DQ71x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/johnhawks\/status\/778343794680991744\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/XxsK4DQ71x",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs07jOGXEAEZB1U.jpg",
        "id_str" : "778343786871197697",
        "id" : 778343786871197697,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs07jOGXEAEZB1U.jpg",
        "sizes" : [ {
          "h" : 698,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 698,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 297,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 524,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/XxsK4DQ71x"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/5SiG1VxCQa",
        "expanded_url" : "http:\/\/for-the-love-of-trees.blogspot.com\/2016\/09\/the-ancestors-are-not-among-us.html",
        "display_url" : "for-the-love-of-trees.blogspot.com\/2016\/09\/the-an\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "778343794680991744",
    "text" : "Why is the term \"basal\" so troublesome in phylogenetics? https:\/\/t.co\/5SiG1VxCQa https:\/\/t.co\/XxsK4DQ71x",
    "id" : 778343794680991744,
    "created_at" : "2016-09-20 21:23:16 +0000",
    "user" : {
      "name" : "John Hawks",
      "screen_name" : "johnhawks",
      "protected" : false,
      "id_str" : "52584039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2162500613\/scio12-0442-jhawks-twitter-focus_normal.jpg",
      "id" : 52584039,
      "verified" : false
    }
  },
  "id" : 778344557536620544,
  "created_at" : "2016-09-20 21:26:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778340874501652480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88871994280633, -117.2423876007187 ]
  },
  "id_str" : "778341576145633280",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest and it gets worse with academic rank :p",
  "id" : 778341576145633280,
  "in_reply_to_status_id" : 778340874501652480,
  "created_at" : "2016-09-20 21:14:27 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "indices" : [ 0, 14 ],
      "id_str" : "3209949862",
      "id" : 3209949862
    }, {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 15, 26 ],
      "id_str" : "20653310",
      "id" : 20653310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/D9eoKo6yTe",
      "expanded_url" : "https:\/\/twitter.com\/fredericmarx\/status\/778338510172524544",
      "display_url" : "twitter.com\/fredericmarx\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88871507493304, -117.2423978820476 ]
  },
  "id_str" : "778338872153427968",
  "in_reply_to_user_id" : 3209949862,
  "text" : "@AprilHathcock @rchampieux did you see that checklist? Fits our discussion we just had! https:\/\/t.co\/D9eoKo6yTe",
  "id" : 778338872153427968,
  "created_at" : "2016-09-20 21:03:42 +0000",
  "in_reply_to_screen_name" : "AprilHathcock",
  "in_reply_to_user_id_str" : "3209949862",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frederic Marx",
      "screen_name" : "fredericmarx",
      "indices" : [ 3, 16 ],
      "id_str" : "484596867",
      "id" : 484596867
    }, {
      "name" : "Florian Gilcher",
      "screen_name" : "Argorak",
      "indices" : [ 18, 26 ],
      "id_str" : "27227212",
      "id" : 27227212
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 27, 43 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/rrgaFqXlJw",
      "expanded_url" : "https:\/\/github.com\/erikr\/lessobviouschecklist",
      "display_url" : "github.com\/erikr\/lessobvi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778338687130099712",
  "text" : "RT @fredericmarx: @Argorak @gedankenstuecke This one?\nhttps:\/\/t.co\/rrgaFqXlJw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Florian Gilcher",
        "screen_name" : "Argorak",
        "indices" : [ 0, 8 ],
        "id_str" : "27227212",
        "id" : 27227212
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 9, 25 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/rrgaFqXlJw",
        "expanded_url" : "https:\/\/github.com\/erikr\/lessobviouschecklist",
        "display_url" : "github.com\/erikr\/lessobvi\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "778337385717370880",
    "geo" : { },
    "id_str" : "778338510172524544",
    "in_reply_to_user_id" : 27227212,
    "text" : "@Argorak @gedankenstuecke This one?\nhttps:\/\/t.co\/rrgaFqXlJw",
    "id" : 778338510172524544,
    "in_reply_to_status_id" : 778337385717370880,
    "created_at" : "2016-09-20 21:02:16 +0000",
    "in_reply_to_screen_name" : "Argorak",
    "in_reply_to_user_id_str" : "27227212",
    "user" : {
      "name" : "Frederic Marx",
      "screen_name" : "fredericmarx",
      "protected" : false,
      "id_str" : "484596867",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780130991822217216\/cJrQX6ji_normal.jpg",
      "id" : 484596867,
      "verified" : false
    }
  },
  "id" : 778338687130099712,
  "created_at" : "2016-09-20 21:02:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frederic Marx",
      "screen_name" : "fredericmarx",
      "indices" : [ 0, 13 ],
      "id_str" : "484596867",
      "id" : 484596867
    }, {
      "name" : "Florian Gilcher",
      "screen_name" : "Argorak",
      "indices" : [ 14, 22 ],
      "id_str" : "27227212",
      "id" : 27227212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778338510172524544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88871507493304, -117.2423978820476 ]
  },
  "id_str" : "778338662417170432",
  "in_reply_to_user_id" : 484596867,
  "text" : "@fredericmarx @Argorak yes, exactly, thanks so much!",
  "id" : 778338662417170432,
  "in_reply_to_status_id" : 778338510172524544,
  "created_at" : "2016-09-20 21:02:52 +0000",
  "in_reply_to_screen_name" : "fredericmarx",
  "in_reply_to_user_id_str" : "484596867",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.8887141654489, -117.2423913902598 ]
  },
  "id_str" : "778337113750196225",
  "text" : "There was a \u201Cforgotten accessibility\/inclusivity\u201D-checklist for events some time back floating on Twitter. Does anyone remember the link?",
  "id" : 778337113750196225,
  "created_at" : "2016-09-20 20:56:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravi",
      "screen_name" : "RaviMurugesan",
      "indices" : [ 0, 14 ],
      "id_str" : "228635323",
      "id" : 228635323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778329583036735488",
  "geo" : { },
  "id_str" : "778329776326975489",
  "in_reply_to_user_id" : 228635323,
  "text" : "@RaviMurugesan I know! I think actually \u201Eonly\u201C three people didn\u2019t? :)",
  "id" : 778329776326975489,
  "in_reply_to_status_id" : 778329583036735488,
  "created_at" : "2016-09-20 20:27:34 +0000",
  "in_reply_to_screen_name" : "RaviMurugesan",
  "in_reply_to_user_id_str" : "228635323",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 118, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88871663697977, -117.2423663261096 ]
  },
  "id_str" : "778328376452886528",
  "text" : "On taking up space: Also interesting to see which speakers stick to their self-estimated time limits and which don\u2019t. #FutureCommons",
  "id" : 778328376452886528,
  "created_at" : "2016-09-20 20:22:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 3, 13 ],
      "id_str" : "11385492",
      "id" : 11385492
    }, {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 45, 53 ],
      "id_str" : "173881525",
      "id" : 173881525
    }, {
      "name" : "the Winnower",
      "screen_name" : "theWinnower",
      "indices" : [ 54, 66 ],
      "id_str" : "748018813",
      "id" : 748018813
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 67, 83 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778326060714700800",
  "text" : "RT @jillemery: other speakers at this event: @iaravps @theWinnower @gedankenstuecke it's going to be a great, great workshop; the greatest\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Iara VPS",
        "screen_name" : "iaravps",
        "indices" : [ 30, 38 ],
        "id_str" : "173881525",
        "id" : 173881525
      }, {
        "name" : "the Winnower",
        "screen_name" : "theWinnower",
        "indices" : [ 39, 51 ],
        "id_str" : "748018813",
        "id" : 748018813
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 52, 68 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/2FFH0XxiBd",
        "expanded_url" : "https:\/\/twitter.com\/jillemery\/status\/778321454551007233",
        "display_url" : "twitter.com\/jillemery\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "778324616909508612",
    "text" : "other speakers at this event: @iaravps @theWinnower @gedankenstuecke it's going to be a great, great workshop; the greatest https:\/\/t.co\/2FFH0XxiBd",
    "id" : 778324616909508612,
    "created_at" : "2016-09-20 20:07:03 +0000",
    "user" : {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "protected" : false,
      "id_str" : "11385492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721430293668704256\/uuScw2u1_normal.jpg",
      "id" : 11385492,
      "verified" : false
    }
  },
  "id" : 778326060714700800,
  "created_at" : "2016-09-20 20:12:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 92, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/N5irl8qdXP",
      "expanded_url" : "http:\/\/hechingerreport.org\/five-things-no-one-will-tell-colleges-dont-hire-faculty-color\/",
      "display_url" : "hechingerreport.org\/five-things-no\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778325224143986688",
  "text" : "\u00AB5 things no one will tell you about why colleges don\u2019t hire more faculty of color\u00BB fitting #FutureCommons right now https:\/\/t.co\/N5irl8qdXP",
  "id" : 778325224143986688,
  "created_at" : "2016-09-20 20:09:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 15, 23 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 110, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88871728453821, -117.2423586505197 ]
  },
  "id_str" : "778316880759001088",
  "text" : "Great point by @iaravps: regardless of what we build, nothing will change if we ignore our underlying biases. #FutureCommons",
  "id" : 778316880759001088,
  "created_at" : "2016-09-20 19:36:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 3, 15 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778269563406262272",
  "text" : "RT @ctitusbrown: Fascinating article on errors in publications &amp; how journals do (and mostly don't) deal with them - https:\/\/t.co\/tBH2PwdKN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/tBH2PwdKN9",
        "expanded_url" : "http:\/\/www.nature.com\/news\/reproducibility-a-tragedy-of-errors-1.19264",
        "display_url" : "nature.com\/news\/reproduci\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "778257708382236672",
    "text" : "Fascinating article on errors in publications &amp; how journals do (and mostly don't) deal with them - https:\/\/t.co\/tBH2PwdKN9.",
    "id" : 778257708382236672,
    "created_at" : "2016-09-20 15:41:11 +0000",
    "user" : {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "protected" : false,
      "id_str" : "26616462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662714429742514176\/bwLg2tBG_normal.jpg",
      "id" : 26616462,
      "verified" : false
    }
  },
  "id" : 778269563406262272,
  "created_at" : "2016-09-20 16:28:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CenterForOpenScience",
      "screen_name" : "OSFramework",
      "indices" : [ 0, 12 ],
      "id_str" : "404946566",
      "id" : 404946566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778214017999499264",
  "geo" : { },
  "id_str" : "778233320253435905",
  "in_reply_to_user_id" : 404946566,
  "text" : "@OSFramework the OSF is on there as far as I can tell?",
  "id" : 778233320253435905,
  "in_reply_to_status_id" : 778214017999499264,
  "created_at" : "2016-09-20 14:04:17 +0000",
  "in_reply_to_screen_name" : "OSFramework",
  "in_reply_to_user_id_str" : "404946566",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778108889854275584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88421557753615, -117.2455797718067 ]
  },
  "id_str" : "778111706472058888",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds I actually tried real Asian rep (being on the organisational committee this time), but they all had to cancel :(",
  "id" : 778111706472058888,
  "in_reply_to_status_id" : 778108889854275584,
  "created_at" : "2016-09-20 06:01:02 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/xG83ASas8s",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BKkE7D-jLYG\/",
      "display_url" : "instagram.com\/p\/BKkE7D-jLYG\/"
    } ]
  },
  "geo" : { },
  "id_str" : "778082731687378944",
  "text" : "The fog did give in after all. https:\/\/t.co\/xG83ASas8s",
  "id" : 778082731687378944,
  "created_at" : "2016-09-20 04:05:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778034195041882112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88437777781343, -117.2451274071746 ]
  },
  "id_str" : "778065621112107008",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds great! Will do, and you\u2019re missed here!",
  "id" : 778065621112107008,
  "in_reply_to_status_id" : 778034195041882112,
  "created_at" : "2016-09-20 02:57:54 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futurecommons",
      "indices" : [ 11, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/LoIrWtYdSi",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BKjsswjj_Am\/",
      "display_url" : "instagram.com\/p\/BKjsswjj_Am\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.8794174014, -117.237229037 ]
  },
  "id_str" : "778029460633321476",
  "text" : "Sci-Hub at #futurecommons \uD83D\uDE02 @ UC San Diego https:\/\/t.co\/LoIrWtYdSi",
  "id" : 778029460633321476,
  "created_at" : "2016-09-20 00:34:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/5cFrSmvweD",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1p7RoG_ja-8Gx-7YODw8iHWFsKn5YAVeHv0UYRyzWmL4\/edit",
      "display_url" : "docs.google.com\/document\/d\/1p7\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "778024371080212482",
  "geo" : { },
  "id_str" : "778024817077420032",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds equitable, open, sustainable &amp; research\/culture led. see https:\/\/t.co\/5cFrSmvweD",
  "id" : 778024817077420032,
  "in_reply_to_status_id" : 778024371080212482,
  "created_at" : "2016-09-20 00:15:46 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778024371080212482",
  "geo" : { },
  "id_str" : "778024744931033088",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds traffic light system for the colors and the letters are the 4 categories of the \u201Eprinciples for the commons\u201C draft.",
  "id" : 778024744931033088,
  "in_reply_to_status_id" : 778024371080212482,
  "created_at" : "2016-09-20 00:15:28 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 89, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/U37CI8IT85",
      "expanded_url" : "https:\/\/genomebiology.biomedcentral.com\/articles\/10.1186\/s13059-016-1044-7",
      "display_url" : "genomebiology.biomedcentral.com\/articles\/10.11\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "778007069341265920",
  "text" : "Why we care about bad tools in terms of the commons? That\u2019s why. https:\/\/t.co\/U37CI8IT85 #FutureCommons",
  "id" : 778007069341265920,
  "created_at" : "2016-09-19 23:05:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777987852990898176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88872438496594, -117.2423584131105 ]
  },
  "id_str" : "777987898998005761",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg ja, bitte :D",
  "id" : 777987898998005761,
  "in_reply_to_status_id" : 777987852990898176,
  "created_at" : "2016-09-19 21:49:04 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777981204834447360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88872286188723, -117.2423642107455 ]
  },
  "id_str" : "777987265024831488",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg that\u2019s hilarious!",
  "id" : 777987265024831488,
  "in_reply_to_status_id" : 777981204834447360,
  "created_at" : "2016-09-19 21:46:32 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/777965481915322368\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/2Bbo40oU4A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsvjeafUEAElqJo.jpg",
      "id_str" : "777965472297783297",
      "id" : 777965472297783297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsvjeafUEAElqJo.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/2Bbo40oU4A"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777965188095971329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88871409347799, -117.2423376974493 ]
  },
  "id_str" : "777965481915322368",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski reminds me: look how citizen science was judged to perform in the commons. https:\/\/t.co\/2Bbo40oU4A",
  "id" : 777965481915322368,
  "in_reply_to_status_id" : 777965188095971329,
  "created_at" : "2016-09-19 20:19:59 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/777961950290423808\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/PEgkTb2zf4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsvgQ4bUAAAv50n.jpg",
      "id_str" : "777961941281013760",
      "id" : 777961941281013760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsvgQ4bUAAAv50n.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/PEgkTb2zf4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.8888285160371, -117.2423487995912 ]
  },
  "id_str" : "777961950290423808",
  "text" : "Envy the great weather we have in California. https:\/\/t.co\/PEgkTb2zf4",
  "id" : 777961950290423808,
  "created_at" : "2016-09-19 20:05:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/777956289431252996\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/lc7nAOB6xW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsvbHWPUAAQ0dlS.jpg",
      "id_str" : "777956279926915076",
      "id" : 777956279926915076,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsvbHWPUAAQ0dlS.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/lc7nAOB6xW"
    } ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 83, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88872236877275, -117.2423681300718 ]
  },
  "id_str" : "777956289431252996",
  "text" : "People have clear opinions on how bad Excel is, with it failing in all categories. #FutureCommons https:\/\/t.co\/lc7nAOB6xW",
  "id" : 777956289431252996,
  "created_at" : "2016-09-19 19:43:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/777949055003467776\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/NxjmVWO7xt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsvUhtTUAAAqeZs.jpg",
      "id_str" : "777949036212912128",
      "id" : 777949036212912128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsvUhtTUAAAqeZs.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/NxjmVWO7xt"
    } ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 3, 17 ]
    }, {
      "text" : "icanhazpdf",
      "indices" : [ 44, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88872106223197, -117.2423559003297 ]
  },
  "id_str" : "777949055003467776",
  "text" : "At #FutureCommons: using Sci-Hub to fulfill #icanhazpdf requests. https:\/\/t.co\/NxjmVWO7xt",
  "id" : 777949055003467776,
  "created_at" : "2016-09-19 19:14:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "_katsel",
      "indices" : [ 3, 11 ],
      "id_str" : "892038837052076033",
      "id" : 892038837052076033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777933995854077952",
  "text" : "RT @_katsel: I think being approachable and humble is important. No matter what an important figure you are deemed to be to a certain commu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777921669641936896",
    "text" : "I think being approachable and humble is important. No matter what an important figure you are deemed to be to a certain community.",
    "id" : 777921669641936896,
    "created_at" : "2016-09-19 17:25:53 +0000",
    "user" : {
      "name" : "Katharina",
      "screen_name" : "katheyrina",
      "protected" : false,
      "id_str" : "730326143295959040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/885460122394349569\/oHlt5LK-_normal.jpg",
      "id" : 730326143295959040,
      "verified" : false
    }
  },
  "id" : 777933995854077952,
  "created_at" : "2016-09-19 18:14:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/777932880647380993\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/68g04j01pB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsvF022UsAAtVz6.jpg",
      "id_str" : "777932872518774784",
      "id" : 777932872518774784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsvF022UsAAtVz6.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/68g04j01pB"
    } ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 62, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/SaW8DnEGx6",
      "expanded_url" : "https:\/\/twitter.com\/iaravps\/status\/777928302585446400",
      "display_url" : "twitter.com\/iaravps\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88873199943602, -117.2423768667921 ]
  },
  "id_str" : "777932880647380993",
  "text" : "And we\u2019ve done it! The Scholarly Commons are coming together. #FutureCommons https:\/\/t.co\/SaW8DnEGx6 https:\/\/t.co\/68g04j01pB",
  "id" : 777932880647380993,
  "created_at" : "2016-09-19 18:10:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777917806289362944",
  "geo" : { },
  "id_str" : "777918083352506370",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps yet another thing on my ever increasing to-read list ;)",
  "id" : 777918083352506370,
  "in_reply_to_status_id" : 777917806289362944,
  "created_at" : "2016-09-19 17:11:38 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Kingsley",
      "screen_name" : "dannykay68",
      "indices" : [ 3, 14 ],
      "id_str" : "588914106",
      "id" : 588914106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/IAhgp9NSY8",
      "expanded_url" : "http:\/\/tinyurl.com\/SCSDworkshop",
      "display_url" : "tinyurl.com\/SCSDworkshop"
    } ]
  },
  "geo" : { },
  "id_str" : "777917000605507584",
  "text" : "RT @dannykay68: WORKING TRANSPARENTLY: the Google Doc from FORCE11 Scholarly Commons event is https:\/\/t.co\/IAhgp9NSY8 and open to all #futu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "futurecommons",
        "indices" : [ 118, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/IAhgp9NSY8",
        "expanded_url" : "http:\/\/tinyurl.com\/SCSDworkshop",
        "display_url" : "tinyurl.com\/SCSDworkshop"
      } ]
    },
    "geo" : { },
    "id_str" : "777895515287543808",
    "text" : "WORKING TRANSPARENTLY: the Google Doc from FORCE11 Scholarly Commons event is https:\/\/t.co\/IAhgp9NSY8 and open to all #futurecommons",
    "id" : 777895515287543808,
    "created_at" : "2016-09-19 15:41:58 +0000",
    "user" : {
      "name" : "Danny Kingsley",
      "screen_name" : "dannykay68",
      "protected" : false,
      "id_str" : "588914106",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554609395917545472\/k1N9aWdb_normal.jpeg",
      "id" : 588914106,
      "verified" : false
    }
  },
  "id" : 777917000605507584,
  "created_at" : "2016-09-19 17:07:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/5hf7hbVFY5",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/736294.Entstehung_Und_Entwicklung_Einer_Wissenschaftlichen_Tatsache_Einf_hrung_In_Die_Lehre_Vom_Denkstil_Und_Denkkollektiv",
      "display_url" : "goodreads.com\/book\/show\/7362\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "777916047441616896",
  "geo" : { },
  "id_str" : "777916444096929792",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps I read Kuhn, Feyerabend and Fleck :D https:\/\/t.co\/5hf7hbVFY5",
  "id" : 777916444096929792,
  "in_reply_to_status_id" : 777916047441616896,
  "created_at" : "2016-09-19 17:05:07 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/q50EanunbU",
      "expanded_url" : "https:\/\/twitter.com\/iaravps\/status\/777914840677429250",
      "display_url" : "twitter.com\/iaravps\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777915729198714880",
  "text" : "How come I heard about these for the 1st time today? Wish I had heard about those like 10 years ago! #FutureCommons https:\/\/t.co\/q50EanunbU",
  "id" : 777915729198714880,
  "created_at" : "2016-09-19 17:02:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/777915207272112129\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/qe24EHvfKK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Csu1whVUEAAv3AE.jpg",
      "id_str" : "777915205837656064",
      "id" : 777915205837656064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Csu1whVUEAAv3AE.jpg",
      "sizes" : [ {
        "h" : 297,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 297,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 297,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qe24EHvfKK"
    } ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 14, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777915207272112129",
  "text" : "The view from #FutureCommons before the fog set in. https:\/\/t.co\/qe24EHvfKK",
  "id" : 777915207272112129,
  "created_at" : "2016-09-19 17:00:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 11, 20 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777896102620229632",
  "geo" : { },
  "id_str" : "777896345927417857",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @msandstr fair enough, I guess you can\u2019t easily survive on cellulose alone.",
  "id" : 777896345927417857,
  "in_reply_to_status_id" : 777896102620229632,
  "created_at" : "2016-09-19 15:45:16 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 11, 20 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777829756058406912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.888735460419, -117.2423699374354 ]
  },
  "id_str" : "777893489983954944",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @msandstr because you didn\u2019t have any money with you? \uD83D\uDE02",
  "id" : 777893489983954944,
  "in_reply_to_status_id" : 777829756058406912,
  "created_at" : "2016-09-19 15:33:55 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88494273241859, -117.2451246822439 ]
  },
  "id_str" : "777757093856026624",
  "text" : "\u00ABWhat did you do with your evening?\u00BB \u2014 \u00ABDiscussing the 3 terrors of our days: Brexit, Trump and paywalls.\u00BB",
  "id" : 777757093856026624,
  "created_at" : "2016-09-19 06:31:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/777709922343464960\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/pEH2xGf61e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Csr7DVGVIAA5qi5.jpg",
      "id_str" : "777709920296706048",
      "id" : 777709920296706048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Csr7DVGVIAA5qi5.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/pEH2xGf61e"
    } ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 14, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777709922343464960",
  "text" : "Puzzling the ##FutureCommons https:\/\/t.co\/pEH2xGf61e",
  "id" : 777709922343464960,
  "created_at" : "2016-09-19 03:24:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.884472100651, -117.2449592662938 ]
  },
  "id_str" : "777693039284203521",
  "text" : "\u00ABI didn\u2019t know what the Scholarly Commons meant, but I liked the sound of it.\u00BB Same here. \uD83D\uDE02",
  "id" : 777693039284203521,
  "created_at" : "2016-09-19 02:17:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureCommons",
      "indices" : [ 13, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88444185132514, -117.2449708569402 ]
  },
  "id_str" : "777691510900797440",
  "text" : "Starting the #FutureCommons. The dimmed lights don\u2019t help in fighting jet lag.",
  "id" : 777691510900797440,
  "created_at" : "2016-09-19 02:11:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777685552481132544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88444185132514, -117.2449708569402 ]
  },
  "id_str" : "777691030422335488",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr I love that I can always rely on you to find excuses for my addiction. ;-)",
  "id" : 777691030422335488,
  "in_reply_to_status_id" : 777685552481132544,
  "created_at" : "2016-09-19 02:09:25 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/777673300671463424\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/ntQxi0uxrL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsrZvoJUMAABZ-w.jpg",
      "id_str" : "777673297928400896",
      "id" : 777673297928400896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsrZvoJUMAABZ-w.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/ntQxi0uxrL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777673300671463424",
  "text" : "Someone's not good at \"just browsing\" when it comes to bookstores. https:\/\/t.co\/ntQxi0uxrL",
  "id" : 777673300671463424,
  "created_at" : "2016-09-19 00:58:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777605571226787845",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88420422123943, -117.2452045785831 ]
  },
  "id_str" : "777616592993595392",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice yes, looking at Surfer\u2019s from here :p",
  "id" : 777616592993595392,
  "in_reply_to_status_id" : 777605571226787845,
  "created_at" : "2016-09-18 21:13:37 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777608631252418560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88420422123943, -117.2452045785831 ]
  },
  "id_str" : "777616512714629121",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy unfortunately not. Will already head to Geneva on Wednesday from here. You should invite me at some point :p",
  "id" : 777616512714629121,
  "in_reply_to_status_id" : 777608631252418560,
  "created_at" : "2016-09-18 21:13:18 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777600245551226880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88424210271252, -117.2451589767409 ]
  },
  "id_str" : "777605292510941184",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nah, he\u2019s a US citizen. But experience being a valet?",
  "id" : 777605292510941184,
  "in_reply_to_status_id" : 777600245551226880,
  "created_at" : "2016-09-18 20:28:43 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/pqJmTZn8cu",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BKgpbk6jdbk\/",
      "display_url" : "instagram.com\/p\/BKgpbk6jdbk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "777600061069004800",
  "text" : "Hello Pacific, long time no see. https:\/\/t.co\/pqJmTZn8cu",
  "id" : 777600061069004800,
  "created_at" : "2016-09-18 20:07:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.850199132257, -117.259080251788 ]
  },
  "id_str" : "777565307888099328",
  "text" : "\u00ABThat\u2019s too far for walking there, you\u2019ll need a shuttle.\u00BB \u2014 \u00ABI\u2019m from Europe.\u00BB \u2014 \u00ABOh, okay, it\u2019s a 45 minutes walk.\u00BB",
  "id" : 777565307888099328,
  "created_at" : "2016-09-18 17:49:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/eV9SriD5hC",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Reasons_To_Believe",
      "display_url" : "en.m.wikipedia.org\/wiki\/Reasons_T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "777546641188327424",
  "text" : "Sharing a hotel with a \"progressive creationist ministry\". You'll know what happened if I don't return. \uD83D\uDE02 https:\/\/t.co\/eV9SriD5hC",
  "id" : 777546641188327424,
  "created_at" : "2016-09-18 16:35:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 30, 43 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88435538768105, -117.245205352192 ]
  },
  "id_str" : "777545297526263809",
  "text" : "Another batch of openSNP (and @repositiveio) stickers is on the way through the US. I\u2019m becoming a weird mailman.",
  "id" : 777545297526263809,
  "created_at" : "2016-09-18 16:30:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777538506956480513",
  "text" : "Ok Twitter, any bookstore recommendations around La Jolla?",
  "id" : 777538506956480513,
  "created_at" : "2016-09-18 16:03:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 32.88493887080617, -117.2451314518228 ]
  },
  "id_str" : "777359886921248768",
  "text" : "And only 24 hours after waking up I made it. \uD83C\uDF89",
  "id" : 777359886921248768,
  "created_at" : "2016-09-18 04:13:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.95861495914529, -77.44641142553128 ]
  },
  "id_str" : "777262673356619777",
  "text" : "And IAD \u2708\uFE0F SAN. \uD83D\uDC4B",
  "id" : 777262673356619777,
  "created_at" : "2016-09-17 21:47:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.9454521455112, -77.45013548965964 ]
  },
  "id_str" : "777248813362716672",
  "text" : "\u00ABWith 91050 miles flown you have reached new level 15: Hot Air Balloon!\u00BB aka advanced politician.",
  "id" : 777248813362716672,
  "created_at" : "2016-09-17 20:52:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777248170334154753",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.94540422354699, -77.44985678123366 ]
  },
  "id_str" : "777248275900399617",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach \uD83D\uDC4B",
  "id" : 777248275900399617,
  "in_reply_to_status_id" : 777248170334154753,
  "created_at" : "2016-09-17 20:50:04 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.94542296955444, -77.44275225885615 ]
  },
  "id_str" : "777229981055389696",
  "text" : "Hey there DC, let\u2019s have some more time together in November.",
  "id" : 777229981055389696,
  "created_at" : "2016-09-17 19:37:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777203608907575296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.94539599102438, -77.44279307385187 ]
  },
  "id_str" : "777229790193586176",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps it was okay given that it was dealing with officials.",
  "id" : 777229790193586176,
  "in_reply_to_status_id" : 777203608907575296,
  "created_at" : "2016-09-17 19:36:36 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 3, 17 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 38, 54 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 117, 126 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777229722451320832",
  "text" : "RT @Protohedgehog: Thanks to you all, @gedankenstuecke and I raised more than 1500 euros for flights\/registration to @open_con!! https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 19, 35 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "OpenCon",
        "screen_name" : "open_con",
        "indices" : [ 98, 107 ],
        "id_str" : "2452073258",
        "id" : 2452073258
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/DwOxwK7TAL",
        "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/2097191#\/",
        "display_url" : "indiegogo.com\/projects\/help-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "777094356981452800",
    "text" : "Thanks to you all, @gedankenstuecke and I raised more than 1500 euros for flights\/registration to @open_con!! https:\/\/t.co\/DwOxwK7TAL &lt;3 &lt;3",
    "id" : 777094356981452800,
    "created_at" : "2016-09-17 10:38:27 +0000",
    "user" : {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "protected" : false,
      "id_str" : "352650591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926545912167583744\/cocrzxXo_normal.jpg",
      "id" : 352650591,
      "verified" : true
    }
  },
  "id" : 777229722451320832,
  "created_at" : "2016-09-17 19:36:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/rlVv7UVY0x",
      "expanded_url" : "https:\/\/twitter.com\/MsPhelps\/status\/777015439838875648",
      "display_url" : "twitter.com\/MsPhelps\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45985795282522, 8.553337818019607 ]
  },
  "id_str" : "777083367263207424",
  "text" : "See you there. https:\/\/t.co\/rlVv7UVY0x",
  "id" : 777083367263207424,
  "created_at" : "2016-09-17 09:54:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.46089520666524, 8.552545945329369 ]
  },
  "id_str" : "777078744909484032",
  "text" : "Who knew you can now also be randomly selected for an interview before flying to the US. Asking a PhD student about hobbies is mean though\u2026",
  "id" : 777078744909484032,
  "created_at" : "2016-09-17 09:36:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777070211744796672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.46143459356256, 8.551889827280066 ]
  },
  "id_str" : "777070483195977728",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest well, not needed but feel it\u2019s good to acknowledge the publicly.",
  "id" : 777070483195977728,
  "in_reply_to_status_id" : 777070211744796672,
  "created_at" : "2016-09-17 09:03:35 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777069418195058688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.46137184050313, 8.552329806771466 ]
  },
  "id_str" : "777069917745061888",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest are RT as transparent corrections okay?",
  "id" : 777069917745061888,
  "in_reply_to_status_id" : 777069418195058688,
  "created_at" : "2016-09-17 09:01:20 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 3, 11 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 13, 29 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777069716108181504",
  "text" : "RT @o_guest: @gedankenstuecke the mention of terrorist = beard though on twitter I dunno, context. I realise it's a joke.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "777067085025406976",
    "geo" : { },
    "id_str" : "777067352601010176",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke the mention of terrorist = beard though on twitter I dunno, context. I realise it's a joke.",
    "id" : 777067352601010176,
    "in_reply_to_status_id" : 777067085025406976,
    "created_at" : "2016-09-17 08:51:08 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "protected" : false,
      "id_str" : "3865005196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844972791732584453\/mdSj6vOd_normal.jpg",
      "id" : 3865005196,
      "verified" : false
    }
  },
  "id" : 777069716108181504,
  "created_at" : "2016-09-17 09:00:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 3, 11 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 13, 29 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777069708646514688",
  "text" : "RT @o_guest: @gedankenstuecke though that's not what you mean by this.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "777069324100112384",
    "geo" : { },
    "id_str" : "777069418195058688",
    "in_reply_to_user_id" : 3865005196,
    "text" : "@gedankenstuecke though that's not what you mean by this.",
    "id" : 777069418195058688,
    "in_reply_to_status_id" : 777069324100112384,
    "created_at" : "2016-09-17 08:59:21 +0000",
    "in_reply_to_screen_name" : "o_guest",
    "in_reply_to_user_id_str" : "3865005196",
    "user" : {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "protected" : false,
      "id_str" : "3865005196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844972791732584453\/mdSj6vOd_normal.jpg",
      "id" : 3865005196,
      "verified" : false
    }
  },
  "id" : 777069708646514688,
  "created_at" : "2016-09-17 09:00:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 3, 11 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 13, 29 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777069701574881280",
  "text" : "RT @o_guest: @gedankenstuecke for me it's about the fact that my friends can't have beards so you're conflating and flaunting when no conte\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "777068157026570240",
    "geo" : { },
    "id_str" : "777069324100112384",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke for me it's about the fact that my friends can't have beards so you're conflating and flaunting when no context, even...",
    "id" : 777069324100112384,
    "in_reply_to_status_id" : 777068157026570240,
    "created_at" : "2016-09-17 08:58:58 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "protected" : false,
      "id_str" : "3865005196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844972791732584453\/mdSj6vOd_normal.jpg",
      "id" : 3865005196,
      "verified" : false
    }
  },
  "id" : 777069701574881280,
  "created_at" : "2016-09-17 09:00:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777069418195058688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.46131727541186, 8.552748076999986 ]
  },
  "id_str" : "777069696273248256",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest point taken.",
  "id" : 777069696273248256,
  "in_reply_to_status_id" : 777069418195058688,
  "created_at" : "2016-09-17 09:00:27 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777067352601010176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45332439934385, 8.559509876348343 ]
  },
  "id_str" : "777068157026570240",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest see your point. For me it\u2019s about stat. significant changes in airport security treatment\u2026",
  "id" : 777068157026570240,
  "in_reply_to_status_id" : 777067352601010176,
  "created_at" : "2016-09-17 08:54:20 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777066785476575233",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45291132339119, 8.56092357681038 ]
  },
  "id_str" : "777067085025406976",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest one of my gfs who\u2019s more than welcome to poke fun at my passport ;)",
  "id" : 777067085025406976,
  "in_reply_to_status_id" : 777066785476575233,
  "created_at" : "2016-09-17 08:50:04 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45226324200476, 8.562101459261749 ]
  },
  "id_str" : "777066568660451328",
  "text" : "\u00ABYou totally look German since you were shaved. Not like a terrorist at all.\u00BB \u2014 \u00ABBecause Germans have never been known for violent terror\u2026\u00BB",
  "id" : 777066568660451328,
  "created_at" : "2016-09-17 08:48:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 3, 17 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 42, 58 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 93, 102 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/zKxpGvpZsl",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/2097191#\/updates",
      "display_url" : "indiegogo.com\/projects\/help-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776778793746853888",
  "text" : "RT @Protohedgehog: Just 17 hours left for @gedankenstuecke and mine's crowdfund campaign for @open_con! https:\/\/t.co\/zKxpGvpZsl https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 23, 39 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "OpenCon",
        "screen_name" : "open_con",
        "indices" : [ 74, 83 ],
        "id_str" : "2452073258",
        "id" : 2452073258
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/zKxpGvpZsl",
        "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/2097191#\/updates",
        "display_url" : "indiegogo.com\/projects\/help-\u2026"
      }, {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/gs43hdreTK",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=9jK-NcRmVcw",
        "display_url" : "youtube.com\/watch?v=9jK-Nc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "776778494483234816",
    "text" : "Just 17 hours left for @gedankenstuecke and mine's crowdfund campaign for @open_con! https:\/\/t.co\/zKxpGvpZsl https:\/\/t.co\/gs43hdreTK",
    "id" : 776778494483234816,
    "created_at" : "2016-09-16 13:43:19 +0000",
    "user" : {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "protected" : false,
      "id_str" : "352650591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926545912167583744\/cocrzxXo_normal.jpg",
      "id" : 352650591,
      "verified" : true
    }
  },
  "id" : 776778793746853888,
  "created_at" : "2016-09-16 13:44:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpotifyCares",
      "screen_name" : "SpotifyCares",
      "indices" : [ 0, 13 ],
      "id_str" : "497340309",
      "id" : 497340309
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 77, 83 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/g3iaKYSxEp",
      "expanded_url" : "https:\/\/open.spotify.com\/track\/7KyNDAKwIC3x3GEEVVdxVv",
      "display_url" : "open.spotify.com\/track\/7KyNDAKw\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "776751545979404289",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17243403260877, 8.62749811736733 ]
  },
  "id_str" : "776752246776328199",
  "in_reply_to_user_id" : 497340309,
  "text" : "@SpotifyCares https:\/\/t.co\/g3iaKYSxEp artist turns up as HaBanot Nechama for @Lobot and as \u05D4\u05D1\u05E0\u05D5\u05EA \u05DE\u05D7\u05DE\u05D4 for me. :D",
  "id" : 776752246776328199,
  "in_reply_to_status_id" : 776751545979404289,
  "created_at" : "2016-09-16 11:59:01 +0000",
  "in_reply_to_screen_name" : "SpotifyCares",
  "in_reply_to_user_id_str" : "497340309",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776740180652859392",
  "text" : "Wait, I\u2019m accessing \u201ETrends in Microbiology\u201C through the \u201EGerman Library of Economics\u201C? I fear the worst for the microbiome is yet to come\u2026",
  "id" : 776740180652859392,
  "created_at" : "2016-09-16 11:11:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/jxvCaXSMVi",
      "expanded_url" : "https:\/\/twitter.com\/_emilyrwilliams\/status\/776698094322941953",
      "display_url" : "twitter.com\/_emilyrwilliam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776737762766688256",
  "text" : "Additional advice: Learn to say \u201Eno\u201C. After all, there are things that are totally useless and just a waste of time. https:\/\/t.co\/jxvCaXSMVi",
  "id" : 776737762766688256,
  "created_at" : "2016-09-16 11:01:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 5, 13 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776716065401344000",
  "text" : "Does @spotify choose to (not) transliterate artists names based on whether you\u2019ve the language\u2019s keyboard installed on your device? \uD83E\uDD14",
  "id" : 776716065401344000,
  "created_at" : "2016-09-16 09:35:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776695448253980673",
  "geo" : { },
  "id_str" : "776702718035517440",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe thanks! \uD83D\uDE18",
  "id" : 776702718035517440,
  "in_reply_to_status_id" : 776695448253980673,
  "created_at" : "2016-09-16 08:42:13 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juh",
      "screen_name" : "__juh__",
      "indices" : [ 0, 8 ],
      "id_str" : "20516838",
      "id" : 20516838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776701898330169344",
  "geo" : { },
  "id_str" : "776702290652782592",
  "in_reply_to_user_id" : 20516838,
  "text" : "@__juh__ yay, thanks! :-)",
  "id" : 776702290652782592,
  "in_reply_to_status_id" : 776701898330169344,
  "created_at" : "2016-09-16 08:40:31 +0000",
  "in_reply_to_screen_name" : "__juh__",
  "in_reply_to_user_id_str" : "20516838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776699857532809216",
  "geo" : { },
  "id_str" : "776702230992973824",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon now i need to find any good conference excuse to go :D",
  "id" : 776702230992973824,
  "in_reply_to_status_id" : 776699857532809216,
  "created_at" : "2016-09-16 08:40:16 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seshupik flekh'es",
      "screen_name" : "FrauFledermaus",
      "indices" : [ 0, 15 ],
      "id_str" : "41335337",
      "id" : 41335337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776699436705673216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18676994000064, 8.619912229999866 ]
  },
  "id_str" : "776699769938993152",
  "in_reply_to_user_id" : 41335337,
  "text" : "@FrauFledermaus workshop zur Future of Scholarly Commons. Bin nur 3 Tage da, also mal schauen wie es mit essen ist. \uD83D\uDE02",
  "id" : 776699769938993152,
  "in_reply_to_status_id" : 776699436705673216,
  "created_at" : "2016-09-16 08:30:30 +0000",
  "in_reply_to_screen_name" : "FrauFledermaus",
  "in_reply_to_user_id_str" : "41335337",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776698745425649664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18676994000177, 8.619912229999644 ]
  },
  "id_str" : "776699613030060032",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon CPH is still missing on my list!",
  "id" : 776699613030060032,
  "in_reply_to_status_id" : 776698745425649664,
  "created_at" : "2016-09-16 08:29:52 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/776698540865323008\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/rB0zOTkUd6",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CsdjLWSW8AAc4wS.jpg",
      "id_str" : "776698507356991488",
      "id" : 776698507356991488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CsdjLWSW8AAc4wS.jpg",
      "sizes" : [ {
        "h" : 134,
        "resize" : "crop",
        "w" : 134
      }, {
        "h" : 134,
        "resize" : "fit",
        "w" : 192
      }, {
        "h" : 134,
        "resize" : "fit",
        "w" : 192
      }, {
        "h" : 134,
        "resize" : "fit",
        "w" : 192
      }, {
        "h" : 134,
        "resize" : "fit",
        "w" : 192
      } ],
      "display_url" : "pic.twitter.com\/rB0zOTkUd6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/e95sYhbsog",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/776697253801197569",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776698540865323008",
  "text" : "Please help us out with a tiny bit of money! https:\/\/t.co\/e95sYhbsog https:\/\/t.co\/rB0zOTkUd6",
  "id" : 776698540865323008,
  "created_at" : "2016-09-16 08:25:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10710572471807, 8.74785118150579 ]
  },
  "id_str" : "776692379709542400",
  "text" : "This week\u2019s travel, starting today: FRA \uD83D\uDE99 ZRH \u2708\uFE0F IAD \u2708\uFE0F SAN \u2708\uFE0F IAD \u2708\uFE0F GVA \uD83D\uDE9E ZRH \uD83D\uDE99 FRA.",
  "id" : 776692379709542400,
  "created_at" : "2016-09-16 08:01:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/wUg2rekWI6",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BKZJcSRjJXg\/",
      "display_url" : "instagram.com\/p\/BKZJcSRjJXg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "776544555898404864",
  "text" : "Pre-\u2708\uFE0F-prep: the air shave. Sacrificing hair to the TSA-anti terror gods\u2026 https:\/\/t.co\/wUg2rekWI6",
  "id" : 776544555898404864,
  "created_at" : "2016-09-15 22:13:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 0, 11 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 68, 84 ],
      "id_str" : "383289779",
      "id" : 383289779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776447207985651712",
  "geo" : { },
  "id_str" : "776447403742359552",
  "in_reply_to_user_id" : 20653310,
  "text" : "@rchampieux And wish I\u2019d have a good excuse to come back to PDX! :D @daniellecrobins",
  "id" : 776447403742359552,
  "in_reply_to_status_id" : 776447207985651712,
  "created_at" : "2016-09-15 15:47:41 +0000",
  "in_reply_to_screen_name" : "rchampieux",
  "in_reply_to_user_id_str" : "20653310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 0, 11 ],
      "id_str" : "20653310",
      "id" : 20653310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776447207985651712",
  "geo" : { },
  "id_str" : "776447301078413312",
  "in_reply_to_user_id" : 20653310,
  "text" : "@rchampieux absolutely! Looking forward to it!",
  "id" : 776447301078413312,
  "in_reply_to_status_id" : 776447207985651712,
  "created_at" : "2016-09-15 15:47:16 +0000",
  "in_reply_to_screen_name" : "rchampieux",
  "in_reply_to_user_id_str" : "20653310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 0, 11 ],
      "id_str" : "20653310",
      "id" : 20653310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776446916284387329",
  "geo" : { },
  "id_str" : "776447025546137600",
  "in_reply_to_user_id" : 20653310,
  "text" : "@rchampieux I\u2019m getting on Saturday evening!",
  "id" : 776447025546137600,
  "in_reply_to_status_id" : 776446916284387329,
  "created_at" : "2016-09-15 15:46:11 +0000",
  "in_reply_to_screen_name" : "rchampieux",
  "in_reply_to_user_id_str" : "20653310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 0, 11 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 12, 24 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 25, 41 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "Lilly Winfree",
      "screen_name" : "lilscientista",
      "indices" : [ 42, 56 ],
      "id_str" : "735954684981084162",
      "id" : 735954684981084162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776444050073202689",
  "geo" : { },
  "id_str" : "776446978754510848",
  "in_reply_to_user_id" : 20653310,
  "text" : "@rchampieux @denormalize @daniellecrobins @lilscientista thanks so much!",
  "id" : 776446978754510848,
  "in_reply_to_status_id" : 776444050073202689,
  "created_at" : "2016-09-15 15:46:00 +0000",
  "in_reply_to_screen_name" : "rchampieux",
  "in_reply_to_user_id_str" : "20653310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776426856375586817",
  "geo" : { },
  "id_str" : "776426940387487745",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin I\u2019m lacking a snapchat account.",
  "id" : 776426940387487745,
  "in_reply_to_status_id" : 776426856375586817,
  "created_at" : "2016-09-15 14:26:22 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 0, 16 ],
      "id_str" : "383289779",
      "id" : 383289779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776426566469324800",
  "geo" : { },
  "id_str" : "776426716193558528",
  "in_reply_to_user_id" : 383289779,
  "text" : "@daniellecrobins I can\u2019t will only fly in to SD for a workshop and will have to fly from there straight to Geneva for another conf. \uD83D\uDE22",
  "id" : 776426716193558528,
  "in_reply_to_status_id" : 776426566469324800,
  "created_at" : "2016-09-15 14:25:29 +0000",
  "in_reply_to_screen_name" : "daniellecrobins",
  "in_reply_to_user_id_str" : "383289779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/qFtVML48Dl",
      "expanded_url" : "http:\/\/static4.businessinsider.com\/image\/529f6b1b69bedd6129e32dd6\/c.j.%20craig%20gif.gif",
      "display_url" : "static4.businessinsider.com\/image\/529f6b1b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776426200155783176",
  "text" : "So, what non-imperialist map projections are the cool kids using these days? Asking for a slide deck. https:\/\/t.co\/qFtVML48Dl",
  "id" : 776426200155783176,
  "created_at" : "2016-09-15 14:23:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/cR5lyCaK3O",
      "expanded_url" : "https:\/\/66.media.tumblr.com\/89f275d3c0500c73039aa11d2e7e217a\/tumblr_inline_mynhmmsh8V1qdhtyp.gif",
      "display_url" : "66.media.tumblr.com\/89f275d3c0500c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "776374513156100096",
  "geo" : { },
  "id_str" : "776374920611758081",
  "in_reply_to_user_id" : 14286491,
  "text" : "next time i\u2019ll make use of this and follow my namesake when it comes to the flying modalities\u2026  https:\/\/t.co\/cR5lyCaK3O",
  "id" : 776374920611758081,
  "in_reply_to_status_id" : 776374513156100096,
  "created_at" : "2016-09-15 10:59:40 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776374513156100096",
  "text" : "the never ending story: the boarding pass stubs my funders needed so urgently? they figured out they don\u2019t need them and mailed them back\u2026",
  "id" : 776374513156100096,
  "created_at" : "2016-09-15 10:58:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Howard J. Wu",
      "screen_name" : "MisterWu78",
      "indices" : [ 0, 11 ],
      "id_str" : "22278512",
      "id" : 22278512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776220158704488448",
  "geo" : { },
  "id_str" : "776374162952773632",
  "in_reply_to_user_id" : 22278512,
  "text" : "@MisterWu78 yes, but also very nice, because otherwise we\u2019d maybe never talked to each other.",
  "id" : 776374162952773632,
  "in_reply_to_status_id" : 776220158704488448,
  "created_at" : "2016-09-15 10:56:39 +0000",
  "in_reply_to_screen_name" : "MisterWu78",
  "in_reply_to_user_id_str" : "22278512",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/yR05bUvw0Y",
      "expanded_url" : "https:\/\/twitter.com\/andreasklinger\/status\/776249567163457536",
      "display_url" : "twitter.com\/andreasklinger\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240972897258, 8.627542438177617 ]
  },
  "id_str" : "776356682641408000",
  "text" : "Data Science Parades. With statisticians dancing on 3D pie charts. https:\/\/t.co\/yR05bUvw0Y",
  "id" : 776356682641408000,
  "created_at" : "2016-09-15 09:47:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 0, 11 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 12, 24 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 25, 41 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "Lilly Winfree",
      "screen_name" : "lilscientista",
      "indices" : [ 42, 56 ],
      "id_str" : "735954684981084162",
      "id" : 735954684981084162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776216100392488961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17240972897258, 8.627542438177617 ]
  },
  "id_str" : "776356269745664004",
  "in_reply_to_user_id" : 20653310,
  "text" : "@rchampieux @denormalize @daniellecrobins @lilscientista please bring some of these to San Diego \uD83D\uDC96",
  "id" : 776356269745664004,
  "in_reply_to_status_id" : 776216100392488961,
  "created_at" : "2016-09-15 09:45:33 +0000",
  "in_reply_to_screen_name" : "rchampieux",
  "in_reply_to_user_id_str" : "20653310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillaume M\u00E9ric",
      "screen_name" : "phylogeo",
      "indices" : [ 3, 12 ],
      "id_str" : "139020295",
      "id" : 139020295
    }, {
      "name" : "hyperallergic",
      "screen_name" : "hyperallergic",
      "indices" : [ 81, 95 ],
      "id_str" : "64054704",
      "id" : 64054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/GFeDIVJakG",
      "expanded_url" : "http:\/\/hyperallergic.com\/322626\/the-story-of-charles-darwins-artist\/?utm_source=sumome&utm_medium=twitter&utm_campaign=sumome_share",
      "display_url" : "hyperallergic.com\/322626\/the-sto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776354259562532864",
  "text" : "RT @phylogeo: \"The Story of Charles Darwin\u2019s Artist\" https:\/\/t.co\/GFeDIVJakG via @hyperallergic",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "hyperallergic",
        "screen_name" : "hyperallergic",
        "indices" : [ 67, 81 ],
        "id_str" : "64054704",
        "id" : 64054704
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/GFeDIVJakG",
        "expanded_url" : "http:\/\/hyperallergic.com\/322626\/the-story-of-charles-darwins-artist\/?utm_source=sumome&utm_medium=twitter&utm_campaign=sumome_share",
        "display_url" : "hyperallergic.com\/322626\/the-sto\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "776229391345000448",
    "text" : "\"The Story of Charles Darwin\u2019s Artist\" https:\/\/t.co\/GFeDIVJakG via @hyperallergic",
    "id" : 776229391345000448,
    "created_at" : "2016-09-15 01:21:23 +0000",
    "user" : {
      "name" : "Guillaume M\u00E9ric",
      "screen_name" : "phylogeo",
      "protected" : false,
      "id_str" : "139020295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/922828333032837121\/R7IreRIa_normal.jpg",
      "id" : 139020295,
      "verified" : false
    }
  },
  "id" : 776354259562532864,
  "created_at" : "2016-09-15 09:37:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anarchieprojekte",
      "screen_name" : "la_flora_negra",
      "indices" : [ 0, 15 ],
      "id_str" : "2269700387",
      "id" : 2269700387
    }, {
      "name" : "FairL\u00F6tet",
      "screen_name" : "fairloetet",
      "indices" : [ 16, 27 ],
      "id_str" : "2848685529",
      "id" : 2848685529
    }, {
      "name" : "\u2605 cy\u03F8\u00E9r-\u03BCw\u212E \u2605",
      "screen_name" : "luebbermann",
      "indices" : [ 28, 40 ],
      "id_str" : "38845373",
      "id" : 38845373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776342867623239680",
  "geo" : { },
  "id_str" : "776343396784955392",
  "in_reply_to_user_id" : 2269700387,
  "text" : "@la_flora_negra @fairloetet @luebbermann im Idealfall gleich eine Liste mitschicken mit potentiellen Referentinnen.",
  "id" : 776343396784955392,
  "in_reply_to_status_id" : 776342867623239680,
  "created_at" : "2016-09-15 08:54:24 +0000",
  "in_reply_to_screen_name" : "la_flora_negra",
  "in_reply_to_user_id_str" : "2269700387",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anarchieprojekte",
      "screen_name" : "la_flora_negra",
      "indices" : [ 0, 15 ],
      "id_str" : "2269700387",
      "id" : 2269700387
    }, {
      "name" : "FairL\u00F6tet",
      "screen_name" : "fairloetet",
      "indices" : [ 16, 27 ],
      "id_str" : "2848685529",
      "id" : 2848685529
    }, {
      "name" : "\u2605 cy\u03F8\u00E9r-\u03BCw\u212E \u2605",
      "screen_name" : "luebbermann",
      "indices" : [ 28, 40 ],
      "id_str" : "38845373",
      "id" : 38845373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776342867623239680",
  "geo" : { },
  "id_str" : "776343299678412800",
  "in_reply_to_user_id" : 2269700387,
  "text" : "@la_flora_negra @fairloetet @luebbermann kein fester Cut-off, aber sage auch nur zu wenn genug Frauen unter den Teilnehmenden.",
  "id" : 776343299678412800,
  "in_reply_to_status_id" : 776342867623239680,
  "created_at" : "2016-09-15 08:54:01 +0000",
  "in_reply_to_screen_name" : "la_flora_negra",
  "in_reply_to_user_id_str" : "2269700387",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Appropriate Tributes",
      "screen_name" : "godtributes",
      "indices" : [ 0, 12 ],
      "id_str" : "2566358196",
      "id" : 2566358196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776191984331546624",
  "geo" : { },
  "id_str" : "776192057702506496",
  "in_reply_to_user_id" : 2566358196,
  "text" : "@godtributes \uD83D\uDE4F",
  "id" : 776192057702506496,
  "in_reply_to_status_id" : 776191984331546624,
  "created_at" : "2016-09-14 22:53:02 +0000",
  "in_reply_to_screen_name" : "godtributes",
  "in_reply_to_user_id_str" : "2566358196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/XbfyfK2uHV",
      "expanded_url" : "https:\/\/twitter.com\/kaythaney\/status\/776155142668349441",
      "display_url" : "twitter.com\/kaythaney\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776191980447625218",
  "text" : "omg, awesome! I always use Twitter at conferences to get around that social awkwardness of joining strangers. https:\/\/t.co\/XbfyfK2uHV",
  "id" : 776191980447625218,
  "created_at" : "2016-09-14 22:52:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/776151741049995269\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/NkBPxI6k5Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsVx41oWYAAACsE.jpg",
      "id_str" : "776151732074209280",
      "id" : 776151732074209280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsVx41oWYAAACsE.jpg",
      "sizes" : [ {
        "h" : 489,
        "resize" : "fit",
        "w" : 1135
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 1135
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 1135
      }, {
        "h" : 293,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/NkBPxI6k5Q"
    } ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/Z0WY48mqPF",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/776066353761488896",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11383281700099, 8.753534324548376 ]
  },
  "id_str" : "776151741049995269",
  "text" : "Still in for it. Probably this one. #opencon https:\/\/t.co\/Z0WY48mqPF https:\/\/t.co\/NkBPxI6k5Q",
  "id" : 776151741049995269,
  "created_at" : "2016-09-14 20:12:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacques Fellay",
      "screen_name" : "jacquesfellay",
      "indices" : [ 3, 17 ],
      "id_str" : "106477433",
      "id" : 106477433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776099646909415424",
  "text" : "RT @jacquesfellay: Personalized Health in the Digital Age, 21-22 Sept - Check the final program and register, only a few seats left... http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/ZXbmT1VVkD",
        "expanded_url" : "https:\/\/www.personalizedhealth2016.ch",
        "display_url" : "personalizedhealth2016.ch"
      } ]
    },
    "geo" : { },
    "id_str" : "776089605548478465",
    "text" : "Personalized Health in the Digital Age, 21-22 Sept - Check the final program and register, only a few seats left... https:\/\/t.co\/ZXbmT1VVkD",
    "id" : 776089605548478465,
    "created_at" : "2016-09-14 16:05:55 +0000",
    "user" : {
      "name" : "Jacques Fellay",
      "screen_name" : "jacquesfellay",
      "protected" : false,
      "id_str" : "106477433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261573502071\/57a4ae0f2488f00b7d58f9f1783df1df_normal.jpeg",
      "id" : 106477433,
      "verified" : false
    }
  },
  "id" : 776099646909415424,
  "created_at" : "2016-09-14 16:45:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/dr0qcprmLN",
      "expanded_url" : "https:\/\/www.filepicker.io\/api\/file\/hhl3lgmhSJyr1PsCvY0D",
      "display_url" : "filepicker.io\/api\/file\/hhl3l\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17242442049715, 8.627466250493516 ]
  },
  "id_str" : "776054898563710976",
  "text" : "Updating Xcode\u2026 https:\/\/t.co\/dr0qcprmLN",
  "id" : 776054898563710976,
  "created_at" : "2016-09-14 13:48:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140211788627, 8.753366871413467 ]
  },
  "id_str" : "776042398329831424",
  "text" : "\u00ABWithout siblings or a legally sanctioned partner I will die all alone.\u00BB \u2014 \u00ABCouldn\u2019t you get adopted by younger people to solve this?\u00BB",
  "id" : 776042398329831424,
  "created_at" : "2016-09-14 12:58:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 0, 7 ],
      "id_str" : "87993032",
      "id" : 87993032
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 8, 22 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776038729064521728",
  "geo" : { },
  "id_str" : "776041198410752000",
  "in_reply_to_user_id" : 87993032,
  "text" : "@Koalha @Protohedgehog awesome, see you there!",
  "id" : 776041198410752000,
  "in_reply_to_status_id" : 776038729064521728,
  "created_at" : "2016-09-14 12:53:34 +0000",
  "in_reply_to_screen_name" : "Koalha",
  "in_reply_to_user_id_str" : "87993032",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/a321wDt5y5",
      "expanded_url" : "https:\/\/twitter.com\/kevinschawinski\/status\/776030058758668289",
      "display_url" : "twitter.com\/kevinschawinsk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776030408827891712",
  "text" : "The militant open science branch \uD83D\uDE02 https:\/\/t.co\/a321wDt5y5",
  "id" : 776030408827891712,
  "created_at" : "2016-09-14 12:10:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776019888309665792",
  "geo" : { },
  "id_str" : "776022385837375488",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye and you\u2019ll probably not come by Geneva on the Saturday, right? (thing in Cologne sounds super interesting, but can\u2019t make it)",
  "id" : 776022385837375488,
  "in_reply_to_status_id" : 776019888309665792,
  "created_at" : "2016-09-14 11:38:49 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776018653062062080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237226990702, 8.627554935268314 ]
  },
  "id_str" : "776019113042993152",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye I\u2019ll probably be in Zurich for the weekend after. But then you\u2019ll be away again?",
  "id" : 776019113042993152,
  "in_reply_to_status_id" : 776018653062062080,
  "created_at" : "2016-09-14 11:25:48 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolina Rossini",
      "screen_name" : "carolinarossini",
      "indices" : [ 0, 16 ],
      "id_str" : "57647138",
      "id" : 57647138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775975675794644992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17244136416856, 8.627505861953802 ]
  },
  "id_str" : "776007965459509249",
  "in_reply_to_user_id" : 57647138,
  "text" : "@carolinarossini Switzerland? The left one should work.",
  "id" : 776007965459509249,
  "in_reply_to_status_id" : 775975675794644992,
  "created_at" : "2016-09-14 10:41:31 +0000",
  "in_reply_to_screen_name" : "carolinarossini",
  "in_reply_to_user_id_str" : "57647138",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 12, 26 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775962234786689024",
  "geo" : { },
  "id_str" : "775980823761842176",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo @Protohedgehog see you there? \uD83C\uDF78",
  "id" : 775980823761842176,
  "in_reply_to_status_id" : 775962234786689024,
  "created_at" : "2016-09-14 08:53:40 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/Nokl0keJxn",
      "expanded_url" : "https:\/\/twitter.com\/thattai\/status\/775667881161785344",
      "display_url" : "twitter.com\/thattai\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775980646657323008",
  "text" : "Based on: Twitter poll on which one I should read. https:\/\/t.co\/Nokl0keJxn",
  "id" : 775980646657323008,
  "created_at" : "2016-09-14 08:52:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 3, 11 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "TimesHigherEducation",
      "screen_name" : "timeshighered",
      "indices" : [ 93, 107 ],
      "id_str" : "23602600",
      "id" : 23602600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/1wVZ7npu2l",
      "expanded_url" : "https:\/\/www.timeshighereducation.com\/news\/gender-bias-academic-conference-ratings-revealed",
      "display_url" : "timeshighereducation.com\/news\/gender-bi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775979886959730688",
  "text" : "RT @o_guest: Gender bias in academic conference ratings revealed https:\/\/t.co\/1wVZ7npu2l via @timeshighered",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TimesHigherEducation",
        "screen_name" : "timeshighered",
        "indices" : [ 80, 94 ],
        "id_str" : "23602600",
        "id" : 23602600
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/1wVZ7npu2l",
        "expanded_url" : "https:\/\/www.timeshighereducation.com\/news\/gender-bias-academic-conference-ratings-revealed",
        "display_url" : "timeshighereducation.com\/news\/gender-bi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "775960180903116800",
    "text" : "Gender bias in academic conference ratings revealed https:\/\/t.co\/1wVZ7npu2l via @timeshighered",
    "id" : 775960180903116800,
    "created_at" : "2016-09-14 07:31:38 +0000",
    "user" : {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "protected" : false,
      "id_str" : "3865005196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844972791732584453\/mdSj6vOd_normal.jpg",
      "id" : 3865005196,
      "verified" : false
    }
  },
  "id" : 775979886959730688,
  "created_at" : "2016-09-14 08:49:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/775966610993606656\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/f7zyZuUnqp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsTJhQsWgAASckD.jpg",
      "id_str" : "775966609068425216",
      "id" : 775966609068425216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsTJhQsWgAASckD.jpg",
      "sizes" : [ {
        "h" : 774,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 774,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 514,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 774,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/f7zyZuUnqp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775966610993606656",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk amazingly the \uD83D\uDE99 is still working and now it's a repositive ad as well \uD83D\uDE02 https:\/\/t.co\/f7zyZuUnqp",
  "id" : 775966610993606656,
  "created_at" : "2016-09-14 07:57:11 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 8, 16 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 17, 27 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/D6sIkXhcsR",
      "expanded_url" : "https:\/\/github.com\/MozillaFoundation\/mozfest-program-2016\/issues\/443",
      "display_url" : "github.com\/MozillaFoundat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775965977582247937",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @Seplute @auremoser no official notification, but looks like we\u2019re accepted: https:\/\/t.co\/D6sIkXhcsR \uD83C\uDF89\uD83C\uDF89\uD83C\uDF89  #mozfest",
  "id" : 775965977582247937,
  "created_at" : "2016-09-14 07:54:40 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/8hLnivjxbd",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/775961765729280000",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775962079731654656",
  "text" : "Also: We\u2019ll still happily take your funds as Indiegogo will deduct fees from the total sum. https:\/\/t.co\/8hLnivjxbd",
  "id" : 775962079731654656,
  "created_at" : "2016-09-14 07:39:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775918560958746624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06077875592539, 8.818648457014817 ]
  },
  "id_str" : "775935203965403136",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc great! \uD83C\uDF89",
  "id" : 775935203965403136,
  "in_reply_to_status_id" : 775918560958746624,
  "created_at" : "2016-09-14 05:52:23 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Undark Magazine",
      "screen_name" : "undarkmag",
      "indices" : [ 3, 13 ],
      "id_str" : "3883416257",
      "id" : 3883416257
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/undarkmag\/status\/775798256358023168\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/Is0Ap7WKEZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsQwZqcW8AAWZH_.jpg",
      "id_str" : "775798253262663680",
      "id" : 775798253262663680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsQwZqcW8AAWZH_.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1463,
        "resize" : "fit",
        "w" : 2600
      } ],
      "display_url" : "pic.twitter.com\/Is0Ap7WKEZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/aTz0RrZM10",
      "expanded_url" : "http:\/\/bit.ly\/2cVE9FT",
      "display_url" : "bit.ly\/2cVE9FT"
    } ]
  },
  "geo" : { },
  "id_str" : "775934970409783298",
  "text" : "RT @undarkmag: Exploring the Promise and Perils of Sharing Your DNA https:\/\/t.co\/aTz0RrZM10 https:\/\/t.co\/Is0Ap7WKEZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/undarkmag\/status\/775798256358023168\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/Is0Ap7WKEZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsQwZqcW8AAWZH_.jpg",
        "id_str" : "775798253262663680",
        "id" : 775798253262663680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsQwZqcW8AAWZH_.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1463,
          "resize" : "fit",
          "w" : 2600
        } ],
        "display_url" : "pic.twitter.com\/Is0Ap7WKEZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/aTz0RrZM10",
        "expanded_url" : "http:\/\/bit.ly\/2cVE9FT",
        "display_url" : "bit.ly\/2cVE9FT"
      } ]
    },
    "geo" : { },
    "id_str" : "775798256358023168",
    "text" : "Exploring the Promise and Perils of Sharing Your DNA https:\/\/t.co\/aTz0RrZM10 https:\/\/t.co\/Is0Ap7WKEZ",
    "id" : 775798256358023168,
    "created_at" : "2016-09-13 20:48:12 +0000",
    "user" : {
      "name" : "Undark Magazine",
      "screen_name" : "undarkmag",
      "protected" : false,
      "id_str" : "3883416257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724637778630316032\/sQSOHqwo_normal.jpg",
      "id" : 3883416257,
      "verified" : false
    }
  },
  "id" : 775934970409783298,
  "created_at" : "2016-09-14 05:51:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775817941233364992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06092145709099, 8.818580610425519 ]
  },
  "id_str" : "775819318781173760",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye thanks! let\u2019s see what I can make out of the title.",
  "id" : 775819318781173760,
  "in_reply_to_status_id" : 775817941233364992,
  "created_at" : "2016-09-13 22:11:54 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775818900889939968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06092145709099, 8.818580610425519 ]
  },
  "id_str" : "775819175377965056",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn being a sugar-addicted vegetarian I can understand that much better than the xkcd. \u263A\uFE0F",
  "id" : 775819175377965056,
  "in_reply_to_status_id" : 775818900889939968,
  "created_at" : "2016-09-13 22:11:20 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/UDRRX417ch",
      "expanded_url" : "https:\/\/xkcd.com\/418\/",
      "display_url" : "xkcd.com\/418\/"
    } ]
  },
  "in_reply_to_status_id_str" : "775789887354134528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084393977501, 8.81851592347684 ]
  },
  "id_str" : "775813220930035713",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn https:\/\/t.co\/UDRRX417ch like this?",
  "id" : 775813220930035713,
  "in_reply_to_status_id" : 775789887354134528,
  "created_at" : "2016-09-13 21:47:40 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/0iIsdTwNqy",
      "expanded_url" : "https:\/\/www.personalizedhealth2016.ch\/",
      "display_url" : "personalizedhealth2016.ch"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/lTp56GLCg5",
      "expanded_url" : "https:\/\/twitter.com\/23andMe\/status\/775732663797817344",
      "display_url" : "twitter.com\/23andMe\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0605978908044, 8.818324819764037 ]
  },
  "id_str" : "775796504959324160",
  "text" : "I hadn\u2019t even seen the quartz article, but that one is great. Just what I\u2019ll talk about at https:\/\/t.co\/0iIsdTwNqy! https:\/\/t.co\/lTp56GLCg5",
  "id" : 775796504959324160,
  "created_at" : "2016-09-13 20:41:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Graziano",
      "screen_name" : "marcoeg",
      "indices" : [ 0, 8 ],
      "id_str" : "14198688",
      "id" : 14198688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775720298251378688",
  "geo" : { },
  "id_str" : "775732140206153728",
  "in_reply_to_user_id" : 14198688,
  "text" : "@marcoeg thanks so much! It\u2019s very appreciated! :-)",
  "id" : 775732140206153728,
  "in_reply_to_status_id" : 775720298251378688,
  "created_at" : "2016-09-13 16:25:29 +0000",
  "in_reply_to_screen_name" : "marcoeg",
  "in_reply_to_user_id_str" : "14198688",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775639162179510273",
  "geo" : { },
  "id_str" : "775655378197569536",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski absolutely, ads be gone, cats are here!",
  "id" : 775655378197569536,
  "in_reply_to_status_id" : 775639162179510273,
  "created_at" : "2016-09-13 11:20:27 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/Efm9Jpgqal",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/a-subway-station-in-london-has-been-taken-over-by-cat-photos",
      "display_url" : "atlasobscura.com\/articles\/a-sub\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775638276912844800",
  "text" : "The Citizens Advertising Takeover Service (CATS) that operates in London is awesome! Hate to miss it! https:\/\/t.co\/Efm9Jpgqal",
  "id" : 775638276912844800,
  "created_at" : "2016-09-13 10:12:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/xmU5oRWSRw",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/150",
      "display_url" : "existentialcomics.com\/comic\/150"
    } ]
  },
  "geo" : { },
  "id_str" : "775603862333952000",
  "text" : "I existential anguish on first date. https:\/\/t.co\/xmU5oRWSRw",
  "id" : 775603862333952000,
  "created_at" : "2016-09-13 07:55:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775596697640656896",
  "geo" : { },
  "id_str" : "775602179814125568",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H please make sure G\u00F6ttingen stays in the EU!",
  "id" : 775602179814125568,
  "in_reply_to_status_id" : 775596697640656896,
  "created_at" : "2016-09-13 07:49:04 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Duncan",
      "screen_name" : "ben_colo",
      "indices" : [ 0, 9 ],
      "id_str" : "744427567",
      "id" : 744427567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775528601731014656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11384949716508, 8.753555870790022 ]
  },
  "id_str" : "775564511260573696",
  "in_reply_to_user_id" : 744427567,
  "text" : "@ben_colo awesome, let us know if you need any help!",
  "id" : 775564511260573696,
  "in_reply_to_status_id" : 775528601731014656,
  "created_at" : "2016-09-13 05:19:23 +0000",
  "in_reply_to_screen_name" : "ben_colo",
  "in_reply_to_user_id_str" : "744427567",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/0oIBb7w4c4",
      "expanded_url" : "https:\/\/twitter.com\/froggleston\/status\/775281451109609472",
      "display_url" : "twitter.com\/froggleston\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775335040611934208",
  "text" : "Great, now the next \u201Enext generation short-read aligners\u201C will have motion blur and depth of field. https:\/\/t.co\/0oIBb7w4c4",
  "id" : 775335040611934208,
  "created_at" : "2016-09-12 14:07:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/775288407631261696\/photo\/1",
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/YPTHDREB2Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsJgsjzWAAA3ryP.jpg",
      "id_str" : "775288404502249472",
      "id" : 775288404502249472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsJgsjzWAAA3ryP.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/YPTHDREB2Z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775288407631261696",
  "text" : "Kill me! \uD83D\uDC40 https:\/\/t.co\/YPTHDREB2Z",
  "id" : 775288407631261696,
  "created_at" : "2016-09-12 11:02:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/qM1437ygzR",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/xTiTnuhyBF54B852nK\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/xTiTnuhy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775286505074032640",
  "text" : "\u00ABI told you there\u2019s no \u201Epen\u201C in RPS, and now I lost and will have to do all the chores!\u00BB https:\/\/t.co\/qM1437ygzR",
  "id" : 775286505074032640,
  "created_at" : "2016-09-12 10:54:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775250267885494272",
  "text" : "\u00ABI love you!\u00BB \u2013 \u00ABI\u2019m sorry you feel that way\u2026 wait, what did you say?!\u00BB \uD83D\uDE34",
  "id" : 775250267885494272,
  "created_at" : "2016-09-12 08:30:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3164",
      "screen_name" : "neingeist",
      "indices" : [ 0, 10 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774230234073853952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234943758811, 8.627598784847056 ]
  },
  "id_str" : "774230537267535872",
  "in_reply_to_user_id" : 11193712,
  "text" : "@neingeist 30 minutes of me talking over this slide. Should be fun.",
  "id" : 774230537267535872,
  "in_reply_to_status_id" : 774230234073853952,
  "created_at" : "2016-09-09 12:58:39 +0000",
  "in_reply_to_screen_name" : "neingeist",
  "in_reply_to_user_id_str" : "11193712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774230166629392384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234943758811, 8.627598784847056 ]
  },
  "id_str" : "774230450818670592",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich notfalls bleib ich halt dr\u00FCben \uD83D\uDE02",
  "id" : 774230450818670592,
  "in_reply_to_status_id" : 774230166629392384,
  "created_at" : "2016-09-09 12:58:18 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774229855206567936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238793799348, 8.627597908890204 ]
  },
  "id_str" : "774229941584003072",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich du bist so ein guter Schleuser! \uD83D\uDE0D",
  "id" : 774229941584003072,
  "in_reply_to_status_id" : 774229855206567936,
  "created_at" : "2016-09-09 12:56:17 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/774228665974525952\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/5DyIZqtsjv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr6c3jqXgAACiWp.jpg",
      "id_str" : "774228664233984000",
      "id" : 774228664233984000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr6c3jqXgAACiWp.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5DyIZqtsjv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774228665974525952",
  "text" : "I think this slide deck needs some more work. https:\/\/t.co\/5DyIZqtsjv",
  "id" : 774228665974525952,
  "created_at" : "2016-09-09 12:51:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/nEUEUnmtrS",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/774184146310529024",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17244785589231, 8.627519271448756 ]
  },
  "id_str" : "774225161016991744",
  "text" : "Thanks so much to all of you \uD83D\uDC96\uD83C\uDF89 https:\/\/t.co\/nEUEUnmtrS",
  "id" : 774225161016991744,
  "created_at" : "2016-09-09 12:37:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 3, 17 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774225087960604672",
  "text" : "RT @Protohedgehog: Update to our crowdfunding campaign for #opencon - WE DID IT! Thank you so much everyone, you're awesome :) https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 40, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/zKxpGv8o3L",
        "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/2097191#\/updates",
        "display_url" : "indiegogo.com\/projects\/help-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "774184146310529024",
    "text" : "Update to our crowdfunding campaign for #opencon - WE DID IT! Thank you so much everyone, you're awesome :) https:\/\/t.co\/zKxpGv8o3L",
    "id" : 774184146310529024,
    "created_at" : "2016-09-09 09:54:18 +0000",
    "user" : {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "protected" : false,
      "id_str" : "352650591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926545912167583744\/cocrzxXo_normal.jpg",
      "id" : 352650591,
      "verified" : true
    }
  },
  "id" : 774225087960604672,
  "created_at" : "2016-09-09 12:37:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suhrob Niyozov",
      "screen_name" : "sniyazov",
      "indices" : [ 0, 9 ],
      "id_str" : "96902749",
      "id" : 96902749
    }, {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 10, 18 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774211332434305026",
  "geo" : { },
  "id_str" : "774214184716337152",
  "in_reply_to_user_id" : 96902749,
  "text" : "@sniyazov @iaravps any weird conferences coming up for you? :D",
  "id" : 774214184716337152,
  "in_reply_to_status_id" : 774211332434305026,
  "created_at" : "2016-09-09 11:53:40 +0000",
  "in_reply_to_screen_name" : "sniyazov",
  "in_reply_to_user_id_str" : "96902749",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 10, 24 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774197723071328256",
  "geo" : { },
  "id_str" : "774198397091868672",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @Protohedgehog the location for opencon 2017 is set :P",
  "id" : 774198397091868672,
  "in_reply_to_status_id" : 774197723071328256,
  "created_at" : "2016-09-09 10:50:56 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 10, 24 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774186126525337600",
  "geo" : { },
  "id_str" : "774196211305877504",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @Protohedgehog any suggestions where we should go after Berlin? :D",
  "id" : 774196211305877504,
  "in_reply_to_status_id" : 774186126525337600,
  "created_at" : "2016-09-09 10:42:15 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billy Bragg",
      "screen_name" : "billybragg",
      "indices" : [ 3, 14 ],
      "id_str" : "13496142",
      "id" : 13496142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774193911657066496",
  "text" : "RT @billybragg: Unemployed man declared 'Londoner of the Decade'. Father an immigrant, mother lived all her life on state benefits. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/billybragg\/status\/773916670092009472\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/hYQaqoegKM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr2BGYiWgAErnps.jpg",
        "id_str" : "773916657643323393",
        "id" : 773916657643323393,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr2BGYiWgAErnps.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/hYQaqoegKM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773916670092009472",
    "text" : "Unemployed man declared 'Londoner of the Decade'. Father an immigrant, mother lived all her life on state benefits. https:\/\/t.co\/hYQaqoegKM",
    "id" : 773916670092009472,
    "created_at" : "2016-09-08 16:11:27 +0000",
    "user" : {
      "name" : "Billy Bragg",
      "screen_name" : "billybragg",
      "protected" : false,
      "id_str" : "13496142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432882718708215809\/GRo-Mkr6_normal.jpeg",
      "id" : 13496142,
      "verified" : true
    }
  },
  "id" : 774193911657066496,
  "created_at" : "2016-09-09 10:33:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SavetheLink",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/FW5ODd1JU6",
      "expanded_url" : "https:\/\/juliareda.eu\/2016\/09\/eu-freedom-to-link\/",
      "display_url" : "juliareda.eu\/2016\/09\/eu-fre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "774149773179748352",
  "text" : "RT @Senficon: Freedom to link threatened by EU court decision and copyright plans https:\/\/t.co\/FW5ODd1JU6 #SavetheLink https:\/\/t.co\/DvxDrqZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/773913868263358464\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/DvxDrqZR9D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr1-d6UXEAAaz9R.jpg",
        "id_str" : "773913763313553408",
        "id" : 773913763313553408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr1-d6UXEAAaz9R.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/DvxDrqZR9D"
      } ],
      "hashtags" : [ {
        "text" : "SavetheLink",
        "indices" : [ 92, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/FW5ODd1JU6",
        "expanded_url" : "https:\/\/juliareda.eu\/2016\/09\/eu-freedom-to-link\/",
        "display_url" : "juliareda.eu\/2016\/09\/eu-fre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "773913868263358464",
    "text" : "Freedom to link threatened by EU court decision and copyright plans https:\/\/t.co\/FW5ODd1JU6 #SavetheLink https:\/\/t.co\/DvxDrqZR9D",
    "id" : 773913868263358464,
    "created_at" : "2016-09-08 16:00:19 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 774149773179748352,
  "created_at" : "2016-09-09 07:37:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PacBio",
      "screen_name" : "PacBio",
      "indices" : [ 3, 10 ],
      "id_str" : "39694489",
      "id" : 39694489
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 12, 28 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/j2VWgLPuI7",
      "expanded_url" : "https:\/\/twitter.com\/roberto_lleras\/status\/773920106548113408",
      "display_url" : "twitter.com\/roberto_lleras\u2026"
    }, {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/026CumhGh4",
      "expanded_url" : "https:\/\/twitter.com\/SisnerosNick\/status\/773920010741833728",
      "display_url" : "twitter.com\/SisnerosNick\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "774148654235910144",
  "text" : "RT @PacBio: @gedankenstuecke good news from our user group mtg today: https:\/\/t.co\/j2VWgLPuI7\nhttps:\/\/t.co\/026CumhGh4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/j2VWgLPuI7",
        "expanded_url" : "https:\/\/twitter.com\/roberto_lleras\/status\/773920106548113408",
        "display_url" : "twitter.com\/roberto_lleras\u2026"
      }, {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/026CumhGh4",
        "expanded_url" : "https:\/\/twitter.com\/SisnerosNick\/status\/773920010741833728",
        "display_url" : "twitter.com\/SisnerosNick\/s\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "773429686181490688",
    "geo" : { },
    "id_str" : "774026391222308864",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke good news from our user group mtg today: https:\/\/t.co\/j2VWgLPuI7\nhttps:\/\/t.co\/026CumhGh4",
    "id" : 774026391222308864,
    "in_reply_to_status_id" : 773429686181490688,
    "created_at" : "2016-09-08 23:27:27 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "PacBio",
      "screen_name" : "PacBio",
      "protected" : false,
      "id_str" : "39694489",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649317702356463616\/A-E_9uMC_normal.jpg",
      "id" : 39694489,
      "verified" : false
    }
  },
  "id" : 774148654235910144,
  "created_at" : "2016-09-09 07:33:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774000115476471808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082909219209, 8.818576608900246 ]
  },
  "id_str" : "774004027965239296",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps sounds good too! :)",
  "id" : 774004027965239296,
  "in_reply_to_status_id" : 774000115476471808,
  "created_at" : "2016-09-08 21:58:35 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    }, {
      "name" : "Suhrob Niyozov",
      "screen_name" : "sniyazov",
      "indices" : [ 9, 18 ],
      "id_str" : "96902749",
      "id" : 96902749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773996444558712832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0606870564925, 8.818413264923946 ]
  },
  "id_str" : "773996701019475968",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps @sniyazov \uD83D\uDC96 that was so much fun. Any famous museums in SD we should go to? \uD83D\uDE02",
  "id" : 773996701019475968,
  "in_reply_to_status_id" : 773996444558712832,
  "created_at" : "2016-09-08 21:29:28 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Byers",
      "screen_name" : "ajrbyers",
      "indices" : [ 0, 9 ],
      "id_str" : "84893173",
      "id" : 84893173
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 15, 29 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773846045491159041",
  "geo" : { },
  "id_str" : "773854243912581120",
  "in_reply_to_user_id" : 84893173,
  "text" : "@ajrbyers what @Protohedgehog is saying! Thanks!",
  "id" : 773854243912581120,
  "in_reply_to_status_id" : 773846045491159041,
  "created_at" : "2016-09-08 12:03:23 +0000",
  "in_reply_to_screen_name" : "ajrbyers",
  "in_reply_to_user_id_str" : "84893173",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/MsQTHV0SGg",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/773840450885214208",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773840692602925056",
  "text" : "Thanks so much for helping us out! As Indiegogo &amp; Paypal will deduct some fees, so contributions are still welcome!\uD83D\uDC96 https:\/\/t.co\/MsQTHV0SGg",
  "id" : 773840692602925056,
  "created_at" : "2016-09-08 11:09:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/nT3Oaqjx1W",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/773814860522123264",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "773814860522123264",
  "geo" : { },
  "id_str" : "773815365218557952",
  "in_reply_to_user_id" : 14286491,
  "text" : "It\u2019s funny how many ways you can spell bullshit. And this paper tries to find all of them. https:\/\/t.co\/nT3Oaqjx1W",
  "id" : 773815365218557952,
  "in_reply_to_status_id" : 773814860522123264,
  "created_at" : "2016-09-08 09:28:54 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/TRCkavVwAz",
      "expanded_url" : "http:\/\/www.nature.com\/tp\/journal\/v6\/n8\/full\/tp2016164a.html#conflict-of-interest",
      "display_url" : "nature.com\/tp\/journal\/v6\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773814860522123264",
  "text" : "Supplement: \u00ABDr. Chopra assisted with study design\u00BB vs main text: \u00ABThe funders had no role in data collection,[\u2026]\u00BB \uD83E\uDD14 https:\/\/t.co\/TRCkavVwAz",
  "id" : 773814860522123264,
  "created_at" : "2016-09-08 09:26:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 15, 22 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773627388655796224",
  "geo" : { },
  "id_str" : "773651779095502848",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @mrgunn NYC gets the crocodiles in the sewers, while Berlin can only afford the crocodile lovers. So typical!",
  "id" : 773651779095502848,
  "in_reply_to_status_id" : 773627388655796224,
  "created_at" : "2016-09-07 22:38:52 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wellcome Trust",
      "screen_name" : "wellcometrust",
      "indices" : [ 11, 25 ],
      "id_str" : "19837528",
      "id" : 19837528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/9y6T4FVg0c",
      "expanded_url" : "https:\/\/twitter.com\/SCEdmunds\/status\/773475058434056192",
      "display_url" : "twitter.com\/SCEdmunds\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17242730500303, 8.627586559438454 ]
  },
  "id_str" : "773505387819597824",
  "text" : "Well done, @wellcometrust! https:\/\/t.co\/9y6T4FVg0c",
  "id" : 773505387819597824,
  "created_at" : "2016-09-07 12:57:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Velterop \u24D0 \uD83C\uDDEA\uD83C\uDDFA\uD83D\uDD36",
      "screen_name" : "Villavelius",
      "indices" : [ 9, 21 ],
      "id_str" : "72249574",
      "id" : 72249574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773449634316451840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724532815846, 8.627504253020746 ]
  },
  "id_str" : "773450239898447872",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Villavelius totally took it the other way around!",
  "id" : 773450239898447872,
  "in_reply_to_status_id" : 773449634316451840,
  "created_at" : "2016-09-07 09:18:01 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Velterop \u24D0 \uD83C\uDDEA\uD83C\uDDFA\uD83D\uDD36",
      "screen_name" : "Villavelius",
      "indices" : [ 9, 21 ],
      "id_str" : "72249574",
      "id" : 72249574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773449312089075712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18135495513472, 8.621324750035242 ]
  },
  "id_str" : "773449530423508992",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Villavelius \uD83D\uDE02\uD83D\uDE02\uD83D\uDE0D",
  "id" : 773449530423508992,
  "in_reply_to_status_id" : 773449312089075712,
  "created_at" : "2016-09-07 09:15:12 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Velterop \u24D0 \uD83C\uDDEA\uD83C\uDDFA\uD83D\uDD36",
      "screen_name" : "Villavelius",
      "indices" : [ 9, 21 ],
      "id_str" : "72249574",
      "id" : 72249574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773447229487153152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16572550001467, 8.633190355783272 ]
  },
  "id_str" : "773448161188798465",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Villavelius all is stamp collecting. :p",
  "id" : 773448161188798465,
  "in_reply_to_status_id" : 773447229487153152,
  "created_at" : "2016-09-07 09:09:46 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/PROho7vdma",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2016\/09\/06\/073825",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773444085281595392",
  "text" : "De novo extraction of microbial strains from metagenomes reveals intra-species niche partitioning \uD83D\uDE0D https:\/\/t.co\/PROho7vdma",
  "id" : 773444085281595392,
  "created_at" : "2016-09-07 08:53:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773443365136375808",
  "geo" : { },
  "id_str" : "773443718141673472",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest waiting for the deep learning version. \uD83D\uDE02\uD83D\uDC96",
  "id" : 773443718141673472,
  "in_reply_to_status_id" : 773443365136375808,
  "created_at" : "2016-09-07 08:52:06 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773430590775369728",
  "geo" : { },
  "id_str" : "773442124415135744",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson maybe even two if you publish your own refutation back-to-back!",
  "id" : 773442124415135744,
  "in_reply_to_status_id" : 773430590775369728,
  "created_at" : "2016-09-07 08:45:46 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/BCEn6JgJ9l",
      "expanded_url" : "https:\/\/twitter.com\/pathogenomenick\/status\/773431251462189056",
      "display_url" : "twitter.com\/pathogenomenic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773440448073494528",
  "text" : "Need to rework manuscript I\u2019m currently writing. \u00ABFurthermore, we found taxa usually found on Mars (Loman 2016) [\u2026]\u00BB https:\/\/t.co\/BCEn6JgJ9l",
  "id" : 773440448073494528,
  "created_at" : "2016-09-07 08:39:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773425369101852672",
  "geo" : { },
  "id_str" : "773439523552452608",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest or in any other field for that matter \uD83D\uDE02",
  "id" : 773439523552452608,
  "in_reply_to_status_id" : 773425369101852672,
  "created_at" : "2016-09-07 08:35:26 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773201707711029248",
  "geo" : { },
  "id_str" : "773431244654870528",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 yes, totally :(",
  "id" : 773431244654870528,
  "in_reply_to_status_id" : 773201707711029248,
  "created_at" : "2016-09-07 08:02:33 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 2, 25 ],
      "url" : "https:\/\/t.co\/cj5iilgn4d",
      "expanded_url" : "https:\/\/twitter.com\/dvasudevan\/status\/773282132143771648",
      "display_url" : "twitter.com\/dvasudevan\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773430830077251585",
  "text" : "\uD83D\uDC4D https:\/\/t.co\/cj5iilgn4d",
  "id" : 773430830077251585,
  "created_at" : "2016-09-07 08:00:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/QRb4mQEj99",
      "expanded_url" : "https:\/\/twitter.com\/BioMath\/status\/773344942361939968",
      "display_url" : "twitter.com\/BioMath\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773429686181490688",
  "text" : "tl;dr: \u00ABThe Sequel currently requires about 10 times the input DNA of the RSII\u00BB \uD83D\uDE31 when working on small organisms. https:\/\/t.co\/QRb4mQEj99",
  "id" : 773429686181490688,
  "created_at" : "2016-09-07 07:56:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/KbFWfHCmoh",
      "expanded_url" : "https:\/\/keybase.io\/gedankenstuecke\/sigs\/Oj7IZ2ggvGfd_BrN5v_RTkvLYkfyxR0f0Xi8",
      "display_url" : "keybase.io\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773416083642576896",
  "text" : "Verifying myself: I am gedankenstuecke on Keybase.io. Oj7IZ2ggvGfd_BrN5v_RTkvLYkfyxR0f0Xi8 \/ https:\/\/t.co\/KbFWfHCmoh",
  "id" : 773416083642576896,
  "created_at" : "2016-09-07 07:02:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773290030903074816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11154472919284, 8.752782708990676 ]
  },
  "id_str" : "773291072961277952",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn well, if that\u2019s the baseline there\u2019s little you can\u2019t make look nice in comparison :p",
  "id" : 773291072961277952,
  "in_reply_to_status_id" : 773290030903074816,
  "created_at" : "2016-09-06 22:45:33 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Ih7pJ51AUT",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Knabenschiessen",
      "display_url" : "en.m.wikipedia.org\/wiki\/Knabensch\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "773289049662431232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11119325112416, 8.751874117549585 ]
  },
  "id_str" : "773289469269176320",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn I just wanted to know why they\u2019ll have a day off in Zurich. Turns out: 13 yo\u2019s shooting with assault rifles https:\/\/t.co\/Ih7pJ51AUT",
  "id" : 773289469269176320,
  "in_reply_to_status_id" : 773289049662431232,
  "created_at" : "2016-09-06 22:39:11 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/773281991278096384\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/d0QxLYp32l",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Crs_zsFWAAAbaZ9.jpg",
      "id_str" : "773281918263623680",
      "id" : 773281918263623680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Crs_zsFWAAAbaZ9.jpg",
      "sizes" : [ {
        "h" : 106,
        "resize" : "fit",
        "w" : 200
      }, {
        "h" : 106,
        "resize" : "fit",
        "w" : 200
      }, {
        "h" : 106,
        "resize" : "crop",
        "w" : 106
      }, {
        "h" : 106,
        "resize" : "fit",
        "w" : 200
      }, {
        "h" : 106,
        "resize" : "fit",
        "w" : 200
      } ],
      "display_url" : "pic.twitter.com\/d0QxLYp32l"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/T4Vq0r0mxJ",
      "expanded_url" : "http:\/\/content.time.com\/time\/world\/article\/0,8599,1616393,00.html?iid=fb_share",
      "display_url" : "content.time.com\/time\/world\/art\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773281991278096384",
  "text" : "\u00ABHeidi Get Your Gun\u00BB https:\/\/t.co\/T4Vq0r0mxJ https:\/\/t.co\/d0QxLYp32l",
  "id" : 773281991278096384,
  "created_at" : "2016-09-06 22:09:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 10, 24 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Lisa Matthias",
      "screen_name" : "l_matthia",
      "indices" : [ 25, 35 ],
      "id_str" : "734667419055230976",
      "id" : 734667419055230976
    }, {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 36, 43 ],
      "id_str" : "12432262",
      "id" : 12432262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773271368179847168",
  "geo" : { },
  "id_str" : "773271818044047360",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @Protohedgehog @l_matthia @McDawg don\u2019t think we won\u2019t drag you along. \u263A\uFE0F",
  "id" : 773271818044047360,
  "in_reply_to_status_id" : 773271368179847168,
  "created_at" : "2016-09-06 21:29:02 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/wmnWHMdnMe",
      "expanded_url" : "https:\/\/igg.me\/p\/1861431\/twtr\/1756182",
      "display_url" : "igg.me\/p\/1861431\/twtr\u2026"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/7p3Oy5zMKb",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/773270179543482369",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773270503268163584",
  "text" : "Cmon, who doesn\u2019t want to see this (acid) trip to #opencon? Give a fiver to make it happen! https:\/\/t.co\/wmnWHMdnMe https:\/\/t.co\/7p3Oy5zMKb",
  "id" : 773270503268163584,
  "created_at" : "2016-09-06 21:23:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Matthias",
      "screen_name" : "l_matthia",
      "indices" : [ 0, 10 ],
      "id_str" : "734667419055230976",
      "id" : 734667419055230976
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 11, 25 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 26, 33 ],
      "id_str" : "12432262",
      "id" : 12432262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773266857411346432",
  "geo" : { },
  "id_str" : "773267019886133248",
  "in_reply_to_user_id" : 734667419055230976,
  "text" : "@l_matthia @Protohedgehog @McDawg \u201Eno worries officer, we\u2019re just doing the video messages to fulfill our crowdfunding here!\u201C",
  "id" : 773267019886133248,
  "in_reply_to_status_id" : 773266857411346432,
  "created_at" : "2016-09-06 21:09:58 +0000",
  "in_reply_to_screen_name" : "l_matthia",
  "in_reply_to_user_id_str" : "734667419055230976",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773265819799289856",
  "geo" : { },
  "id_str" : "773265984123797504",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice bear hugs \uD83D\uDE0D",
  "id" : 773265984123797504,
  "in_reply_to_status_id" : 773265819799289856,
  "created_at" : "2016-09-06 21:05:51 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773264184402378752",
  "geo" : { },
  "id_str" : "773264803754303493",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe a case of \u201EWhat you see is all there is\u201C. \uD83D\uDE22",
  "id" : 773264803754303493,
  "in_reply_to_status_id" : 773264184402378752,
  "created_at" : "2016-09-06 21:01:10 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/oc1EcsWMkp",
      "expanded_url" : "https:\/\/m.popkey.co\/df102c\/gr9RJ.gif",
      "display_url" : "m.popkey.co\/df102c\/gr9RJ.g\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "773254857562152964",
  "geo" : { },
  "id_str" : "773263271143104516",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice https:\/\/t.co\/oc1EcsWMkp",
  "id" : 773263271143104516,
  "in_reply_to_status_id" : 773254857562152964,
  "created_at" : "2016-09-06 20:55:05 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Matthias",
      "screen_name" : "l_matthia",
      "indices" : [ 0, 10 ],
      "id_str" : "734667419055230976",
      "id" : 734667419055230976
    }, {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 11, 18 ],
      "id_str" : "12432262",
      "id" : 12432262
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 59, 73 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ICJwJjoEyv",
      "expanded_url" : "https:\/\/media0.giphy.com\/media\/mWGWPhsDj79pS\/200.gif",
      "display_url" : "media0.giphy.com\/media\/mWGWPhsD\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "773261797881249794",
  "geo" : { },
  "id_str" : "773263075189387265",
  "in_reply_to_user_id" : 734667419055230976,
  "text" : "@l_matthia @McDawg shouldn\u2019t have told us this before. Now @Protohedgehog &amp; I will try openaccessing very hard. https:\/\/t.co\/ICJwJjoEyv",
  "id" : 773263075189387265,
  "in_reply_to_status_id" : 773261797881249794,
  "created_at" : "2016-09-06 20:54:18 +0000",
  "in_reply_to_screen_name" : "l_matthia",
  "in_reply_to_user_id_str" : "734667419055230976",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 15, 22 ],
      "id_str" : "12432262",
      "id" : 12432262
    }, {
      "name" : "Lisa Matthias",
      "screen_name" : "l_matthia",
      "indices" : [ 23, 33 ],
      "id_str" : "734667419055230976",
      "id" : 734667419055230976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773260491301019648",
  "geo" : { },
  "id_str" : "773261096975208448",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @McDawg @l_matthia second crowdfunding for posting bail: \u00ABHelp Bastian &amp; Jon to get out of jail\u00BB",
  "id" : 773261096975208448,
  "in_reply_to_status_id" : 773260491301019648,
  "created_at" : "2016-09-06 20:46:26 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 15, 22 ],
      "id_str" : "12432262",
      "id" : 12432262
    }, {
      "name" : "Lisa Matthias",
      "screen_name" : "l_matthia",
      "indices" : [ 23, 33 ],
      "id_str" : "734667419055230976",
      "id" : 734667419055230976
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/773240537646243840\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/7XLHD3twAC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrsaJE4WEAEgxVp.jpg",
      "id_str" : "773240504255385601",
      "id" : 773240504255385601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrsaJE4WEAEgxVp.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/7XLHD3twAC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773227396354957312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397458634625, 8.753463948449799 ]
  },
  "id_str" : "773240537646243840",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @McDawg @l_matthia I rarely drink, but when I do\u2026 https:\/\/t.co\/7XLHD3twAC",
  "id" : 773240537646243840,
  "in_reply_to_status_id" : 773227396354957312,
  "created_at" : "2016-09-06 19:24:44 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773231352791625728",
  "text" : "@quominus \uD83D\uDE0D I wanna join that!",
  "id" : 773231352791625728,
  "created_at" : "2016-09-06 18:48:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 3, 17 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 106, 122 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 73, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773214713245229056",
  "text" : "RT @Protohedgehog: We're less than \u20AC100 away from our funding target for #opencon! Brother, can you spare @gedankenstuecke and I a dime htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 87, 103 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 54, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/DwOxwK7TAL",
        "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/2097191#\/",
        "display_url" : "indiegogo.com\/projects\/help-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "773213470649151488",
    "text" : "We're less than \u20AC100 away from our funding target for #opencon! Brother, can you spare @gedankenstuecke and I a dime https:\/\/t.co\/DwOxwK7TAL",
    "id" : 773213470649151488,
    "created_at" : "2016-09-06 17:37:11 +0000",
    "user" : {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "protected" : false,
      "id_str" : "352650591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926545912167583744\/cocrzxXo_normal.jpg",
      "id" : 352650591,
      "verified" : true
    }
  },
  "id" : 773214713245229056,
  "created_at" : "2016-09-06 17:42:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 9, 22 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/iLB5hkornD",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Mars_Climate_Orbiter",
      "display_url" : "en.m.wikipedia.org\/wiki\/Mars_Clim\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "773201087549542400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392404775528, 8.753428355604743 ]
  },
  "id_str" : "773202189141565440",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @repositiveio but no worries, know who else mixed those up? These folks: https:\/\/t.co\/iLB5hkornD",
  "id" : 773202189141565440,
  "in_reply_to_status_id" : 773201087549542400,
  "created_at" : "2016-09-06 16:52:21 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 9, 22 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/773201749310136320\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/ipPl40rZDR",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Crr22o7WgAA3TNS.jpg",
      "id_str" : "773201704607186944",
      "id" : 773201704607186944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Crr22o7WgAA3TNS.jpg",
      "sizes" : [ {
        "h" : 280,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/ipPl40rZDR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773201087549542400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402530082116, 8.753353920175337 ]
  },
  "id_str" : "773201749310136320",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @repositiveio these stickers need to be at least 2.54 times bigger! \uD83D\uDE02\uD83D\uDE02 https:\/\/t.co\/ipPl40rZDR",
  "id" : 773201749310136320,
  "in_reply_to_status_id" : 773201087549542400,
  "created_at" : "2016-09-06 16:50:37 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    }, {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 9, 22 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773199992316104704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400335194961, 8.753406358881225 ]
  },
  "id_str" : "773200355358302208",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk @repositiveio and do I correctly sense a funny imperial vs metric story in the other stickers? \uD83D\uDE02",
  "id" : 773200355358302208,
  "in_reply_to_status_id" : 773199992316104704,
  "created_at" : "2016-09-06 16:45:04 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 35, 48 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/773198597965934592\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/pjUkt4OzcW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Crrz_1JWEAAuv8N.jpg",
      "id_str" : "773198563971043328",
      "id" : 773198563971043328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Crrz_1JWEAAuv8N.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/pjUkt4OzcW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402242117656, 8.753362225148951 ]
  },
  "id_str" : "773198597965934592",
  "text" : "If anyone in mainland Europe wants @repositiveio stickers: let me know! \uD83D\uDE02 https:\/\/t.co\/pjUkt4OzcW",
  "id" : 773198597965934592,
  "created_at" : "2016-09-06 16:38:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/ZnKOprGbvY",
      "expanded_url" : "https:\/\/twitter.com\/HLWiencko\/status\/773181993114828800",
      "display_url" : "twitter.com\/HLWiencko\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17287548731812, 8.627269130187566 ]
  },
  "id_str" : "773182390613250048",
  "text" : "That's cool. But does anyone know how it works? https:\/\/t.co\/ZnKOprGbvY",
  "id" : 773182390613250048,
  "created_at" : "2016-09-06 15:33:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773099593273839616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17247022599929, 8.627509614460754 ]
  },
  "id_str" : "773100960176635908",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot awww",
  "id" : 773100960176635908,
  "in_reply_to_status_id" : 773099593273839616,
  "created_at" : "2016-09-06 10:10:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773088946876194816",
  "geo" : { },
  "id_str" : "773089896361824256",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest \uD83C\uDF89\uD83D\uDC96",
  "id" : 773089896361824256,
  "in_reply_to_status_id" : 773088946876194816,
  "created_at" : "2016-09-06 09:26:09 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/zSdzIigmQC",
      "expanded_url" : "http:\/\/www.newyorker.com\/humor\/daily-shouts\/additional-ethical-questions-for-driverless-cars",
      "display_url" : "newyorker.com\/humor\/daily-sh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773083200218361856",
  "text" : "Driverless car ethics: \u00ABHow do you react? What if the two other squirrels are known arsonists?\u00BB https:\/\/t.co\/zSdzIigmQC",
  "id" : 773083200218361856,
  "created_at" : "2016-09-06 08:59:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773082448888471552",
  "geo" : { },
  "id_str" : "773083146355081216",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot who would\u2019ve guessed that my little car can drive that fast.",
  "id" : 773083146355081216,
  "in_reply_to_status_id" : 773082448888471552,
  "created_at" : "2016-09-06 08:59:19 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/a3x3JFzwmv",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/772785725091741697",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237370635455, 8.627610078061396 ]
  },
  "id_str" : "773067878912368640",
  "text" : "Down to 101\u20AC now! \uD83D\uDC96\uD83C\uDF89 https:\/\/t.co\/a3x3JFzwmv",
  "id" : 773067878912368640,
  "created_at" : "2016-09-06 07:58:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/z44Xnf96ij",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/the_slatest\/2016\/09\/05\/durex_announced_eggplant_flavored_condom_as_part_of_campaign_for_safe_sex.html",
      "display_url" : "slate.com\/blogs\/the_slat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06075010618165, 8.818500419817807 ]
  },
  "id_str" : "772922195588816896",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \uD83C\uDF46 (purely for academic-linguistic reasons) https:\/\/t.co\/z44Xnf96ij",
  "id" : 772922195588816896,
  "created_at" : "2016-09-05 22:19:46 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/772910968804368384\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/GJmUAr0tDc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Crnua6xWAAAdw9A.jpg",
      "id_str" : "772910957290979328",
      "id" : 772910957290979328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Crnua6xWAAAdw9A.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/GJmUAr0tDc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078087379276, 8.818535650932636 ]
  },
  "id_str" : "772910968804368384",
  "text" : "Either my GPS was weird or I did fall asleep while driving home today. https:\/\/t.co\/GJmUAr0tDc",
  "id" : 772910968804368384,
  "created_at" : "2016-09-05 21:35:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/772832248211107841\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/wSls7bQA4S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Crmm1Y8WYAAeHJt.jpg",
      "id_str" : "772832247229603840",
      "id" : 772832247229603840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Crmm1Y8WYAAeHJt.jpg",
      "sizes" : [ {
        "h" : 372,
        "resize" : "fit",
        "w" : 545
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 545
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 545
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 545
      } ],
      "display_url" : "pic.twitter.com\/wSls7bQA4S"
    } ],
    "hashtags" : [ {
      "text" : "scienceisglobal",
      "indices" : [ 5, 21 ]
    }, {
      "text" : "opencon",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/IYK8UcDVBj",
      "expanded_url" : "http:\/\/igg.me\/p\/1861431\/twtr\/1756182",
      "display_url" : "igg.me\/p\/1861431\/twtr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772832248211107841",
  "text" : "Yep, #scienceisglobal: From where people are crowdfunding us to go to #opencon. Wanna join? https:\/\/t.co\/IYK8UcDVBj https:\/\/t.co\/wSls7bQA4S",
  "id" : 772832248211107841,
  "created_at" : "2016-09-05 16:22:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772791870971846656",
  "geo" : { },
  "id_str" : "772807530007363584",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot gehen wir da hin? :p",
  "id" : 772807530007363584,
  "in_reply_to_status_id" : 772791870971846656,
  "created_at" : "2016-09-05 14:44:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/772767103514476544\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/LeVfmc6ixH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrlrlboWAAAhcds.jpg",
      "id_str" : "772767101887053824",
      "id" : 772767101887053824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrlrlboWAAAhcds.jpg",
      "sizes" : [ {
        "h" : 207,
        "resize" : "fit",
        "w" : 965
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 965
      }, {
        "h" : 146,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 965
      } ],
      "display_url" : "pic.twitter.com\/LeVfmc6ixH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772767103514476544",
  "text" : "The Noun project is sending weird signals when searching for \u201Ehugs\u201C https:\/\/t.co\/LeVfmc6ixH",
  "id" : 772767103514476544,
  "created_at" : "2016-09-05 12:03:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 43, 52 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/OUup4A9Ozx",
      "expanded_url" : "https:\/\/twitter.com\/voxdotcom\/status\/772498259843518465",
      "display_url" : "twitter.com\/voxdotcom\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06066212642783, 8.818563348656037 ]
  },
  "id_str" : "772569439493578752",
  "text" : "Nooooo! I\u2019m so disappointed with this! \/cc @Senficon https:\/\/t.co\/OUup4A9Ozx",
  "id" : 772569439493578752,
  "created_at" : "2016-09-04 22:58:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 3, 11 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772478228351029248",
  "text" : "RT @iaravps: \"if you think there's a thing \u2014 anything \u2014 women didn't do in the past, you're wrong\" 3y old text, still relevant https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/kE5Buejo69",
        "expanded_url" : "http:\/\/aidanmoher.com\/blog\/featured-article\/2013\/05\/we-have-always-fought-challenging-the-women-cattle-and-slaves-narrative-by-kameron-hurley\/",
        "display_url" : "aidanmoher.com\/blog\/featured-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "772399024385171456",
    "text" : "\"if you think there's a thing \u2014 anything \u2014 women didn't do in the past, you're wrong\" 3y old text, still relevant https:\/\/t.co\/kE5Buejo69",
    "id" : 772399024385171456,
    "created_at" : "2016-09-04 11:40:52 +0000",
    "user" : {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "protected" : false,
      "id_str" : "173881525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927263024678866944\/jbPg0pRm_normal.jpg",
      "id" : 173881525,
      "verified" : false
    }
  },
  "id" : 772478228351029248,
  "created_at" : "2016-09-04 16:55:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772475534718763008",
  "text" : "\u00ABTell me more on your feature selection &amp; we\u2019ll find out whom I love more: scientific integrity or you.\u00BB\u2014\u00ABDo you write that in all reviews?\u00BB",
  "id" : 772475534718763008,
  "created_at" : "2016-09-04 16:44:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 32, 41 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772434798229028869",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11160234178872, 8.752931354064902 ]
  },
  "id_str" : "772434969335570432",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @InquisitiveVain @open_con thanks so much \uD83D\uDE0D\uD83D\uDC96",
  "id" : 772434969335570432,
  "in_reply_to_status_id" : 772434798229028869,
  "created_at" : "2016-09-04 14:03:42 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "SSI - software.ac.uk",
      "screen_name" : "SoftwareSaved",
      "indices" : [ 23, 37 ],
      "id_str" : "136301916",
      "id" : 136301916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772398510050246656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10719045535671, 8.725981889300725 ]
  },
  "id_str" : "772416090739793924",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston just like @SoftwareSaved fellows are UK only \uD83D\uDE22",
  "id" : 772416090739793924,
  "in_reply_to_status_id" : 772398510050246656,
  "created_at" : "2016-09-04 12:48:41 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772398022844112896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10571557567464, 8.714262647562395 ]
  },
  "id_str" : "772398504014704641",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps that makes me want to offer a helping hand right away \uD83D\uDE02\uD83D\uDE0D\uD83D\uDC36",
  "id" : 772398504014704641,
  "in_reply_to_status_id" : 772398022844112896,
  "created_at" : "2016-09-04 11:38:48 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772392015417991168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10994650893855, 8.735053958379416 ]
  },
  "id_str" : "772394245445545984",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps I\u2019m pretty sure I\u2019m always performing mediocre compared to those extremes. It just feels like those two. :D",
  "id" : 772394245445545984,
  "in_reply_to_status_id" : 772392015417991168,
  "created_at" : "2016-09-04 11:21:53 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 3, 17 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 44, 60 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772380530377650176",
  "text" : "RT @Protohedgehog: With 46 backers already, @gedankenstuecke and I are only \u20AC258 from achieving our #opencon funding target! https:\/\/t.co\/D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 25, 41 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 81, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/DwOxwK7TAL",
        "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/2097191#\/",
        "display_url" : "indiegogo.com\/projects\/help-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "772379830520348672",
    "text" : "With 46 backers already, @gedankenstuecke and I are only \u20AC258 from achieving our #opencon funding target! https:\/\/t.co\/DwOxwK7TAL",
    "id" : 772379830520348672,
    "created_at" : "2016-09-04 10:24:36 +0000",
    "user" : {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "protected" : false,
      "id_str" : "352650591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926545912167583744\/cocrzxXo_normal.jpg",
      "id" : 352650591,
      "verified" : true
    }
  },
  "id" : 772380530377650176,
  "created_at" : "2016-09-04 10:27:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772374021442707456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114002844056, 8.753332484591388 ]
  },
  "id_str" : "772378973720481793",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer makes becoming an astronaut much more compelling!",
  "id" : 772378973720481793,
  "in_reply_to_status_id" : 772374021442707456,
  "created_at" : "2016-09-04 10:21:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/oWt7tiJKuX",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/rQOT9sBxBtkSk\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/rQOT9sBx\u2026"
    }, {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/rDIgGFowCK",
      "expanded_url" : "http:\/\/mrwgifs.com\/wp-content\/uploads\/2013\/07\/Honey-Boo-Boo-Shows-Off-Her-Non-Existent-Juggling-Skills.gif",
      "display_url" : "mrwgifs.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772368643309072384",
  "text" : "managing my life on good days: https:\/\/t.co\/oWt7tiJKuX \n\nmanaging my life on bad days: https:\/\/t.co\/rDIgGFowCK",
  "id" : 772368643309072384,
  "created_at" : "2016-09-04 09:40:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772366723886387200",
  "geo" : { },
  "id_str" : "772366987783700480",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer the drive to achieve great things, despite all the hardship and against all odds. It\u2019s like going to the moon again.",
  "id" : 772366987783700480,
  "in_reply_to_status_id" : 772366723886387200,
  "created_at" : "2016-09-04 09:33:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772360485819658245",
  "geo" : { },
  "id_str" : "772363533837361152",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer what did I just watch? \uD83D\uDE15 (there\u2019s no emoji that can convey my actual level of confusion).",
  "id" : 772363533837361152,
  "in_reply_to_status_id" : 772360485819658245,
  "created_at" : "2016-09-04 09:19:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772357230171529216",
  "geo" : { },
  "id_str" : "772357767902457858",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer this even seems to be a whole Genre. my TIL :D",
  "id" : 772357767902457858,
  "in_reply_to_status_id" : 772357230171529216,
  "created_at" : "2016-09-04 08:56:56 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 0, 10 ],
      "id_str" : "186529934",
      "id" : 186529934
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 11, 19 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 20, 27 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772173562564182016",
  "geo" : { },
  "id_str" : "772176077036875776",
  "in_reply_to_user_id" : 186529934,
  "text" : "@auremoser @Seplute @sujaik thanks \uD83D\uDC96",
  "id" : 772176077036875776,
  "in_reply_to_status_id" : 772173562564182016,
  "created_at" : "2016-09-03 20:54:57 +0000",
  "in_reply_to_screen_name" : "auremoser",
  "in_reply_to_user_id_str" : "186529934",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/1xFCj8rZKB",
      "expanded_url" : "https:\/\/github.com\/MozillaFoundation\/mozfest-program-2016\/issues\/609",
      "display_url" : "github.com\/MozillaFoundat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "772138960302837760",
  "geo" : { },
  "id_str" : "772139728284028928",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute but guess they might be going through it right now when I see this here :D https:\/\/t.co\/1xFCj8rZKB",
  "id" : 772139728284028928,
  "in_reply_to_status_id" : 772138960302837760,
  "created_at" : "2016-09-03 18:30:31 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/D6sIkWZBBj",
      "expanded_url" : "https:\/\/github.com\/MozillaFoundation\/mozfest-program-2016\/issues\/443",
      "display_url" : "github.com\/MozillaFoundat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "772138960302837760",
  "geo" : { },
  "id_str" : "772139582120923136",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute no changes here since 16 days. https:\/\/t.co\/D6sIkWZBBj",
  "id" : 772139582120923136,
  "in_reply_to_status_id" : 772138960302837760,
  "created_at" : "2016-09-03 18:29:56 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 21, 31 ],
      "id_str" : "186529934",
      "id" : 186529934
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 61, 68 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772138306414993408",
  "geo" : { },
  "id_str" : "772138575324405760",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute but I guess @auremoser knows the timeline for that? @sujaik",
  "id" : 772138575324405760,
  "in_reply_to_status_id" : 772138306414993408,
  "created_at" : "2016-09-03 18:25:56 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772138306414993408",
  "geo" : { },
  "id_str" : "772138498417627136",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute nope, nothing yet!",
  "id" : 772138498417627136,
  "in_reply_to_status_id" : 772138306414993408,
  "created_at" : "2016-09-03 18:25:38 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772136047555801088",
  "geo" : { },
  "id_str" : "772136197460287489",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg sure, sitting on my ass in airplanes all day for months totally builds muscle, right? :D",
  "id" : 772136197460287489,
  "in_reply_to_status_id" : 772136047555801088,
  "created_at" : "2016-09-03 18:16:29 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772135252869480448",
  "geo" : { },
  "id_str" : "772135959316066304",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg weirdest part: our scale claims I\u2019ve gained 3 kg (I believe that) while losing 5 percent points of body fat. All lies. \uD83D\uDE02",
  "id" : 772135959316066304,
  "in_reply_to_status_id" : 772135252869480448,
  "created_at" : "2016-09-03 18:15:32 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772134956667666432",
  "geo" : { },
  "id_str" : "772135107012558853",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg I guess the overall improvement is similar, but height etc. make lots of the difference.",
  "id" : 772135107012558853,
  "in_reply_to_status_id" : 772134956667666432,
  "created_at" : "2016-09-03 18:12:09 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/y0u74kJAN6",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/760106026070863872",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "772134238372192264",
  "geo" : { },
  "id_str" : "772134874190839808",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg c.f. https:\/\/t.co\/y0u74kJAN6",
  "id" : 772134874190839808,
  "in_reply_to_status_id" : 772134238372192264,
  "created_at" : "2016-09-03 18:11:14 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772134238372192264",
  "geo" : { },
  "id_str" : "772134765264863237",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg yeah, so was I. Plus frequent calling in sick for those lessons because of the bullying.",
  "id" : 772134765264863237,
  "in_reply_to_status_id" : 772134238372192264,
  "created_at" : "2016-09-03 18:10:48 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772127949789208576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11244603437382, 8.758248612292817 ]
  },
  "id_str" : "772128403390595072",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg by now you could be faster some days of the week then. 5\u203241\u2033 for the km today.",
  "id" : 772128403390595072,
  "in_reply_to_status_id" : 772127949789208576,
  "created_at" : "2016-09-03 17:45:31 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "QuantifiedSelf",
      "indices" : [ 9, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10935181290853, 8.774956595160788 ]
  },
  "id_str" : "772124849175134208",
  "text" : "Damn you #QuantifiedSelf. Now I know that not running for half a year increases my average time by a whole minute on the kilometer. \uD83D\uDE31",
  "id" : 772124849175134208,
  "created_at" : "2016-09-03 17:31:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 47, 61 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/ERLbKXkt99",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/1756182#\/",
      "display_url" : "indiegogo.com\/projects\/help-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "772106211453964288",
  "text" : "Wanna invest some money over the weekend? Help @Protohedgehog and me get the last 250\u20AC to go to #opencon! https:\/\/t.co\/ERLbKXkt99",
  "id" : 772106211453964288,
  "created_at" : "2016-09-03 16:17:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772100258524438532",
  "geo" : { },
  "id_str" : "772100395439185920",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey at least there\u2019s that! \uD83D\uDC4B",
  "id" : 772100395439185920,
  "in_reply_to_status_id" : 772100258524438532,
  "created_at" : "2016-09-03 15:54:13 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772099675033899008",
  "geo" : { },
  "id_str" : "772099798270930944",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey doh! Sorry to hear that, hope the tech survived that! (and you\u2019re getting closer! :p)",
  "id" : 772099798270930944,
  "in_reply_to_status_id" : 772099675033899008,
  "created_at" : "2016-09-03 15:51:51 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772041998119342081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401780429406, 8.753341138098875 ]
  },
  "id_str" : "772086389211029504",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey I briefly thought you\u2019d be close by and then I saw that it\u2019s the wrong Frankfurt. Dammit! \uD83D\uDE02",
  "id" : 772086389211029504,
  "in_reply_to_status_id" : 772041998119342081,
  "created_at" : "2016-09-03 14:58:34 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772023495949549568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10606342465626, 8.72041647323288 ]
  },
  "id_str" : "772041914325557248",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice totally accurate.",
  "id" : 772041914325557248,
  "in_reply_to_status_id" : 772023495949549568,
  "created_at" : "2016-09-03 12:01:50 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772016230437949440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10571683296012, 8.71751566418327 ]
  },
  "id_str" : "772041361642119168",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente nimm mich mit \uD83D\uDE0D",
  "id" : 772041361642119168,
  "in_reply_to_status_id" : 772016230437949440,
  "created_at" : "2016-09-03 11:59:39 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772032723124748288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11484788045147, 8.68635227030488 ]
  },
  "id_str" : "772032840506740736",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that\u2019s totally what I expected \uD83D\uDE02",
  "id" : 772032840506740736,
  "in_reply_to_status_id" : 772032723124748288,
  "created_at" : "2016-09-03 11:25:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772016686438285312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10935545903641, 8.682066584014038 ]
  },
  "id_str" : "772017696221368321",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that\u2019s one of these stories that make me wanna spend more then a week in Australia :P",
  "id" : 772017696221368321,
  "in_reply_to_status_id" : 772016686438285312,
  "created_at" : "2016-09-03 10:25:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772015258869243904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10767736011194, 8.685775827624543 ]
  },
  "id_str" : "772016165510062080",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u201Cthat bloke didn\u2019t want to go first, so I hit\u2019im with the pack of diapers I wanted to buy!\u201D Australian Parenting 101.",
  "id" : 772016165510062080,
  "in_reply_to_status_id" : 772015258869243904,
  "created_at" : "2016-09-03 10:19:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771990363523325952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10578342718082, 8.712556343533763 ]
  },
  "id_str" : "772011037226926080",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer did you beat each other up over it in the end?",
  "id" : 772011037226926080,
  "in_reply_to_status_id" : 771990363523325952,
  "created_at" : "2016-09-03 09:59:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388522579973, 8.75328710661267 ]
  },
  "id_str" : "771989703079948288",
  "text" : "\u00AB[\u2026] to queer Tolstoy: all happy gay families sing show tunes together; every unhappy gay family is unhappy in its own straight way.\u00BB \uD83D\uDE02",
  "id" : 771989703079948288,
  "created_at" : "2016-09-03 08:34:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/ctYuu0TVXt",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/purity",
      "display_url" : "smbc-comics.com\/comic\/purity"
    } ]
  },
  "geo" : { },
  "id_str" : "771948060184379392",
  "text" : "All the shame! https:\/\/t.co\/ctYuu0TVXt",
  "id" : 771948060184379392,
  "created_at" : "2016-09-03 05:48:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/771815931064573952\/photo\/1",
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/J7ISvjSXKp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrYKdvUXEAE6KRG.jpg",
      "id_str" : "771815892174966785",
      "id" : 771815892174966785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrYKdvUXEAE6KRG.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/J7ISvjSXKp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771810235371651072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140166921172, 8.753341010421547 ]
  },
  "id_str" : "771815931064573952",
  "in_reply_to_user_id" : 14286491,
  "text" : "Yes, yes, yes! https:\/\/t.co\/J7ISvjSXKp",
  "id" : 771815931064573952,
  "in_reply_to_status_id" : 771810235371651072,
  "created_at" : "2016-09-02 21:03:52 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/771810235371651072\/photo\/1",
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/DfVL2xfXdz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrYFUWGXYAA50KX.jpg",
      "id_str" : "771810233228419072",
      "id" : 771810233228419072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrYFUWGXYAA50KX.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/DfVL2xfXdz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771810235371651072",
  "text" : "\uD83D\uDC96\uD83C\uDF08 https:\/\/t.co\/DfVL2xfXdz",
  "id" : 771810235371651072,
  "created_at" : "2016-09-02 20:41:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771806478546169857",
  "geo" : { },
  "id_str" : "771806942742315008",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABThis means that authors should not include unpublished works [read preprints] in the Bibliography.\u00BB That\u2019s even worse. m)",
  "id" : 771806942742315008,
  "in_reply_to_status_id" : 771806478546169857,
  "created_at" : "2016-09-02 20:28:09 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OfficialSMBE",
      "screen_name" : "OfficialSMBE",
      "indices" : [ 10, 23 ],
      "id_str" : "1120098811",
      "id" : 1120098811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/CTVHots2pA",
      "expanded_url" : "https:\/\/twitter.com\/richmeisel\/status\/771390534619308032",
      "display_url" : "twitter.com\/richmeisel\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771806478546169857",
  "text" : "Seriously @OfficialSMBE? That\u2019s disappointing\u2026 https:\/\/t.co\/CTVHots2pA",
  "id" : 771806478546169857,
  "created_at" : "2016-09-02 20:26:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771798237783228416",
  "geo" : { },
  "id_str" : "771798884876185604",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog i guess we know where excessive funds from indiegogo will go to :p",
  "id" : 771798884876185604,
  "in_reply_to_status_id" : 771798237783228416,
  "created_at" : "2016-09-02 19:56:08 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 15, 24 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 25, 33 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771797907506917376",
  "geo" : { },
  "id_str" : "771798091951407105",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @eramirez @mbeisen I\u2019ve seriously entertained getting the CC0 logo inked.",
  "id" : 771798091951407105,
  "in_reply_to_status_id" : 771797907506917376,
  "created_at" : "2016-09-02 19:52:59 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771795120173805569",
  "geo" : { },
  "id_str" : "771795170241155072",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez yes, September!",
  "id" : 771795170241155072,
  "in_reply_to_status_id" : 771795120173805569,
  "created_at" : "2016-09-02 19:41:22 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771793819683598336",
  "geo" : { },
  "id_str" : "771794307732963328",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez reminds me! I\u2019ll come to San Diego on 17th, leaving 21st! Are you around?",
  "id" : 771794307732963328,
  "in_reply_to_status_id" : 771793819683598336,
  "created_at" : "2016-09-02 19:37:56 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 0, 8 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 9, 18 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 19, 33 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771790965094830080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140152492115, 8.753341133555299 ]
  },
  "id_str" : "771791359451729920",
  "in_reply_to_user_id" : 19843630,
  "text" : "@mbeisen @eramirez @Protohedgehog works, see you in DC for #opencon?",
  "id" : 771791359451729920,
  "in_reply_to_status_id" : 771790965094830080,
  "created_at" : "2016-09-02 19:26:13 +0000",
  "in_reply_to_screen_name" : "mbeisen",
  "in_reply_to_user_id_str" : "19843630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 46, 60 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 65, 73 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/771784782334267392\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/top8GzPqC7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrXuKteXgAAZVdE.png",
      "id_str" : "771784778936975360",
      "id" : 771784778936975360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrXuKteXgAAZVdE.png",
      "sizes" : [ {
        "h" : 495,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 688,
        "resize" : "fit",
        "w" : 1667
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 688,
        "resize" : "fit",
        "w" : 1667
      } ],
      "display_url" : "pic.twitter.com\/top8GzPqC7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771778562940473344",
  "geo" : { },
  "id_str" : "771784782334267392",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez maybe? :p Now just need to convince @Protohedgehog and @mbeisen to get these as tattoos w\/ me. \uD83D\uDE02 https:\/\/t.co\/top8GzPqC7",
  "id" : 771784782334267392,
  "in_reply_to_status_id" : 771778562940473344,
  "created_at" : "2016-09-02 19:00:05 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771777375059128321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11251480788934, 8.75592690893333 ]
  },
  "id_str" : "771778294001827840",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez for the current campaign you mean? :)",
  "id" : 771778294001827840,
  "in_reply_to_status_id" : 771777375059128321,
  "created_at" : "2016-09-02 18:34:18 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771776607249846272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11065561794686, 8.759729526945165 ]
  },
  "id_str" : "771777313268764672",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez my life became so much better the day I figured out that I could rebrand my not-caring-for-rules as civil disobedience \uD83D\uDE09",
  "id" : 771777313268764672,
  "in_reply_to_status_id" : 771776607249846272,
  "created_at" : "2016-09-02 18:30:25 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/3IeBya9PZI",
      "expanded_url" : "https:\/\/twitter.com\/eramirez\/status\/771776607249846272",
      "display_url" : "twitter.com\/eramirez\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11048119054186, 8.760093469180875 ]
  },
  "id_str" : "771777066622648320",
  "text" : "I\u2019d wear that for all my teaching :3 https:\/\/t.co\/3IeBya9PZI",
  "id" : 771777066622648320,
  "created_at" : "2016-09-02 18:29:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771775848793767936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10902261366147, 8.76302487217706 ]
  },
  "id_str" : "771776419013722113",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez extra coolness points if you use Sci-hub linka for paywalled content \uD83D\uDE0E",
  "id" : 771776419013722113,
  "in_reply_to_status_id" : 771775848793767936,
  "created_at" : "2016-09-02 18:26:51 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Winifred Searle",
      "screen_name" : "swinsea",
      "indices" : [ 3, 11 ],
      "id_str" : "223576586",
      "id" : 223576586
    }, {
      "name" : "The Nib",
      "screen_name" : "thenib",
      "indices" : [ 45, 52 ],
      "id_str" : "483521999",
      "id" : 483521999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/gzTiQZcjxI",
      "expanded_url" : "https:\/\/thenib.com\/fatness-femininity-and-the-media-we-deserve",
      "display_url" : "thenib.com\/fatness-femini\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771758082057768960",
  "text" : "RT @swinsea: Check out this comic I made for @thenib! Fatness, Femininity, and the Media We Deserve: https:\/\/t.co\/gzTiQZcjxI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Nib",
        "screen_name" : "thenib",
        "indices" : [ 32, 39 ],
        "id_str" : "483521999",
        "id" : 483521999
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/gzTiQZcjxI",
        "expanded_url" : "https:\/\/thenib.com\/fatness-femininity-and-the-media-we-deserve",
        "display_url" : "thenib.com\/fatness-femini\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "771671946266222592",
    "text" : "Check out this comic I made for @thenib! Fatness, Femininity, and the Media We Deserve: https:\/\/t.co\/gzTiQZcjxI",
    "id" : 771671946266222592,
    "created_at" : "2016-09-02 11:31:43 +0000",
    "user" : {
      "name" : "Sarah Winifred Searle",
      "screen_name" : "swinsea",
      "protected" : false,
      "id_str" : "223576586",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722614263185932289\/lSvzl5PU_normal.jpg",
      "id" : 223576586,
      "verified" : true
    }
  },
  "id" : 771758082057768960,
  "created_at" : "2016-09-02 17:13:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 26, 37 ],
      "id_str" : "20342875",
      "id" : 20342875
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 79, 93 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/Smm1Vtunpz",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/771756872940527616",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "771756872940527616",
  "geo" : { },
  "id_str" : "771757122132537344",
  "in_reply_to_user_id" : 352650591,
  "text" : "Please give some money so @LouWoodley and I can enjoy the homemade pancakes of @Protohedgehog! https:\/\/t.co\/Smm1Vtunpz",
  "id" : 771757122132537344,
  "in_reply_to_status_id" : 771756872940527616,
  "created_at" : "2016-09-02 17:10:11 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 3, 14 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771716369310216192",
  "text" : "RT @openSNPorg: Our emails have recently been eaten by most spam filters, including GMail\u2014we just fixed it, so check your spam filters if m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771715971908308992",
    "text" : "Our emails have recently been eaten by most spam filters, including GMail\u2014we just fixed it, so check your spam filters if mails are missing!",
    "id" : 771715971908308992,
    "created_at" : "2016-09-02 14:26:40 +0000",
    "user" : {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "protected" : false,
      "id_str" : "380205172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735374825187909632\/wJEJW1zW_normal.jpg",
      "id" : 380205172,
      "verified" : false
    }
  },
  "id" : 771716369310216192,
  "created_at" : "2016-09-02 14:28:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/cpizUSfDiA",
      "expanded_url" : "http:\/\/www.carolhanisch.org\/CHwritings\/PIP.html",
      "display_url" : "carolhanisch.org\/CHwritings\/PIP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771694109392338945",
  "text" : "Not sure about why, but there\u2019s probably a very good reason why I start prepping my next open data talk by reading https:\/\/t.co\/cpizUSfDiA",
  "id" : 771694109392338945,
  "created_at" : "2016-09-02 12:59:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771684506797506561",
  "geo" : { },
  "id_str" : "771686917175910400",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu \uD83D\uDC96",
  "id" : 771686917175910400,
  "in_reply_to_status_id" : 771684506797506561,
  "created_at" : "2016-09-02 12:31:12 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771674837617999872",
  "geo" : { },
  "id_str" : "771682333468614656",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu vielen Dank! :-)",
  "id" : 771682333468614656,
  "in_reply_to_status_id" : 771674837617999872,
  "created_at" : "2016-09-02 12:13:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771672734837256192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237399630137, 8.627608382867729 ]
  },
  "id_str" : "771673133463969792",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston but totally agree, but any other way to send mails for like 6000 users in some sensible way are too expensive.",
  "id" : 771673133463969792,
  "in_reply_to_status_id" : 771672734837256192,
  "created_at" : "2016-09-02 11:36:26 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771672734837256192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237399630137, 8.627608382867729 ]
  },
  "id_str" : "771672956950818816",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston yeah, well. Just postfix for getting the mail from openSNP out.",
  "id" : 771672956950818816,
  "in_reply_to_status_id" : 771672734837256192,
  "created_at" : "2016-09-02 11:35:44 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771568867713822720",
  "geo" : { },
  "id_str" : "771671395285643269",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds all the best and enjoy the cake etc. ;)",
  "id" : 771671395285643269,
  "in_reply_to_status_id" : 771568867713822720,
  "created_at" : "2016-09-02 11:29:32 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/771670646489088001\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/pkBd8gpOY1",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CrWGH9PUMAAEyFV.jpg",
      "id_str" : "771670382419914752",
      "id" : 771670382419914752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CrWGH9PUMAAEyFV.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/pkBd8gpOY1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/IYK8UcmkcJ",
      "expanded_url" : "http:\/\/igg.me\/p\/1861431\/twtr\/1756182",
      "display_url" : "igg.me\/p\/1861431\/twtr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771670646489088001",
  "text" : "Figuring out what\u2019s wrong with the mail server all morning. Would someone lessen my pain? https:\/\/t.co\/IYK8UcmkcJ https:\/\/t.co\/pkBd8gpOY1",
  "id" : 771670646489088001,
  "created_at" : "2016-09-02 11:26:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 3, 11 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/iXVm9hs2Ic",
      "expanded_url" : "https:\/\/twitter.com\/BathysphereHat\/status\/771178089489412098",
      "display_url" : "twitter.com\/BathysphereHat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771483968944410624",
  "text" : "RT @iaravps: This thread https:\/\/t.co\/iXVm9hs2Ic",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 35 ],
        "url" : "https:\/\/t.co\/iXVm9hs2Ic",
        "expanded_url" : "https:\/\/twitter.com\/BathysphereHat\/status\/771178089489412098",
        "display_url" : "twitter.com\/BathysphereHat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "771482252467462144",
    "text" : "This thread https:\/\/t.co\/iXVm9hs2Ic",
    "id" : 771482252467462144,
    "created_at" : "2016-09-01 22:57:57 +0000",
    "user" : {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "protected" : false,
      "id_str" : "173881525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927263024678866944\/jbPg0pRm_normal.jpg",
      "id" : 173881525,
      "verified" : false
    }
  },
  "id" : 771483968944410624,
  "created_at" : "2016-09-01 23:04:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771479255817588739",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06070785851934, 8.818455503687971 ]
  },
  "id_str" : "771480467279343617",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest sure, the disclaimer is important :3",
  "id" : 771480467279343617,
  "in_reply_to_status_id" : 771479255817588739,
  "created_at" : "2016-09-01 22:50:51 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/DKzV9SGprL",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/771476817593110532",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "771479076976504832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06079342684728, 8.818377868452268 ]
  },
  "id_str" : "771479441159647232",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy \u201Cit\u2019s the birds and the bees not Adams and Steves\u201D? https:\/\/t.co\/DKzV9SGprL",
  "id" : 771479441159647232,
  "in_reply_to_status_id" : 771479076976504832,
  "created_at" : "2016-09-01 22:46:46 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771478319892160512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06081046783403, 8.81835831015932 ]
  },
  "id_str" : "771479064947388416",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest so soon you\u2019ll start doing Cockney instead? Awesome \uD83D\uDE02\uD83D\uDE0D",
  "id" : 771479064947388416,
  "in_reply_to_status_id" : 771478319892160512,
  "created_at" : "2016-09-01 22:45:17 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771477215091499008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06081885474248, 8.818480739663018 ]
  },
  "id_str" : "771477542180093952",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest and there my evening goes punning down the river. Damn Oxbridge people!",
  "id" : 771477542180093952,
  "in_reply_to_status_id" : 771477215091499008,
  "created_at" : "2016-09-01 22:39:14 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/771476817593110532\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/7yFlcXphMk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrTV_5EWgAI00Vo.jpg",
      "id_str" : "771476729814745090",
      "id" : 771476729814745090,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrTV_5EWgAI00Vo.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/7yFlcXphMk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771475982528180224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06087352526379, 8.818583982073532 ]
  },
  "id_str" : "771476817593110532",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest fun read so far. Crushing down biological arguments left and right. :3 https:\/\/t.co\/7yFlcXphMk",
  "id" : 771476817593110532,
  "in_reply_to_status_id" : 771475982528180224,
  "created_at" : "2016-09-01 22:36:21 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/771475721910968320\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/j4Q8W5q3Ro",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrTVFF3WYAMdp2l.jpg",
      "id_str" : "771475719637590019",
      "id" : 771475719637590019,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrTVFF3WYAMdp2l.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/j4Q8W5q3Ro"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771475721910968320",
  "text" : "From the same naive point of view having sex at all doesn't even make sense.  \u00AF\\_(\u30C4)_\/\u00AF https:\/\/t.co\/j4Q8W5q3Ro",
  "id" : 771475721910968320,
  "created_at" : "2016-09-01 22:32:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Becker",
      "screen_name" : "freelanceastro",
      "indices" : [ 0, 15 ],
      "id_str" : "143344335",
      "id" : 143344335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771459347406725120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06080183193679, 8.818535755120953 ]
  },
  "id_str" : "771459797011095552",
  "in_reply_to_user_id" : 143344335,
  "text" : "@freelanceastro thanks! :)",
  "id" : 771459797011095552,
  "in_reply_to_status_id" : 771459347406725120,
  "created_at" : "2016-09-01 21:28:43 +0000",
  "in_reply_to_screen_name" : "freelanceastro",
  "in_reply_to_user_id_str" : "143344335",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/dD6CbWas4d",
      "expanded_url" : "https:\/\/twitter.com\/heyaudy\/status\/771420363888529408",
      "display_url" : "twitter.com\/heyaudy\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06102875811053, 8.818625472494231 ]
  },
  "id_str" : "771437086847238144",
  "text" : "Who\u2019s not doing this daily? https:\/\/t.co\/dD6CbWas4d",
  "id" : 771437086847238144,
  "created_at" : "2016-09-01 19:58:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771414929861738496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06056656116782, 8.81846180372816 ]
  },
  "id_str" : "771435964241543168",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC \uD83D\uDE0D",
  "id" : 771435964241543168,
  "in_reply_to_status_id" : 771414929861738496,
  "created_at" : "2016-09-01 19:54:01 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 9, 15 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 16, 27 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771435369694957569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06107205064041, 8.818636955701576 ]
  },
  "id_str" : "771435421679181825",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Lobot @plaetzchen totes!!!",
  "id" : 771435421679181825,
  "in_reply_to_status_id" : 771435369694957569,
  "created_at" : "2016-09-01 19:51:51 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 9, 15 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 16, 27 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771434572072574976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06080645010508, 8.818615309663576 ]
  },
  "id_str" : "771434769393516545",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Lobot @plaetzchen omg, how did I not know this?! \uD83D\uDC22\uD83D\uDCA8",
  "id" : 771434769393516545,
  "in_reply_to_status_id" : 771434572072574976,
  "created_at" : "2016-09-01 19:49:16 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/3F7NwGWh45",
      "expanded_url" : "https:\/\/twitter.com\/Lobot\/status\/771360513976569856",
      "display_url" : "twitter.com\/Lobot\/status\/7\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "771433000181661696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06108864680869, 8.818590017043816 ]
  },
  "id_str" : "771433166024433664",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest wait till you see https:\/\/t.co\/3F7NwGWh45",
  "id" : 771433166024433664,
  "in_reply_to_status_id" : 771433000181661696,
  "created_at" : "2016-09-01 19:42:53 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/EN0ioI596F",
      "expanded_url" : "https:\/\/twitter.com\/Lobot\/status\/771270326416187392",
      "display_url" : "twitter.com\/Lobot\/status\/7\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "771432374601129984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06068911046459, 8.818337505214227 ]
  },
  "id_str" : "771432531858194432",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest see what I got this morning! https:\/\/t.co\/EN0ioI596F",
  "id" : 771432531858194432,
  "in_reply_to_status_id" : 771432374601129984,
  "created_at" : "2016-09-01 19:40:22 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 27, 36 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 44, 58 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771432107612733440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078794680223, 8.818637785262709 ]
  },
  "id_str" : "771432337271844864",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Senficon please request a @wilbanks cameo! @Protohedgehog",
  "id" : 771432337271844864,
  "in_reply_to_status_id" : 771432107612733440,
  "created_at" : "2016-09-01 19:39:36 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771381602157006848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06078794680223, 8.818637785262709 ]
  },
  "id_str" : "771431959356665857",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest \uD83D\uDC36\uD83D\uDE0D",
  "id" : 771431959356665857,
  "in_reply_to_status_id" : 771381602157006848,
  "created_at" : "2016-09-01 19:38:06 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/VJyyJnJUQr",
      "expanded_url" : "https:\/\/twitter.com\/AcademiaObscura\/status\/771416406416035846",
      "display_url" : "twitter.com\/AcademiaObscur\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06075740146769, 8.818535293571363 ]
  },
  "id_str" : "771429231704285185",
  "text" : "That\u2019s another title that will go into my biography! https:\/\/t.co\/VJyyJnJUQr",
  "id" : 771429231704285185,
  "created_at" : "2016-09-01 19:27:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Academia Obscura",
      "screen_name" : "AcademiaObscura",
      "indices" : [ 0, 16 ],
      "id_str" : "2645602164",
      "id" : 2645602164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771416406416035846",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06083824232668, 8.818455734705237 ]
  },
  "id_str" : "771417118453751808",
  "in_reply_to_user_id" : 2645602164,
  "text" : "@AcademiaObscura thanks!",
  "id" : 771417118453751808,
  "in_reply_to_status_id" : 771416406416035846,
  "created_at" : "2016-09-01 18:39:07 +0000",
  "in_reply_to_screen_name" : "AcademiaObscura",
  "in_reply_to_user_id_str" : "2645602164",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771374706406621184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06101098816004, 8.818414916256247 ]
  },
  "id_str" : "771412803244658688",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC \uD83D\uDD8C (as close as it gets)",
  "id" : 771412803244658688,
  "in_reply_to_status_id" : 771374706406621184,
  "created_at" : "2016-09-01 18:21:59 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771412155040235520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06100866697379, 8.818504836591366 ]
  },
  "id_str" : "771412460343623680",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog yes! Go go go! Already fought today in order to actually get vacation to go!",
  "id" : 771412460343623680,
  "in_reply_to_status_id" : 771412155040235520,
  "created_at" : "2016-09-01 18:20:37 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 30, 44 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/ERLbKXkt99",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/1756182#\/",
      "display_url" : "indiegogo.com\/projects\/help-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771410640191774720",
  "text" : "Only 300\u20AC missing for getting @Protohedgehog and me to#opencon!  https:\/\/t.co\/ERLbKXkt99",
  "id" : 771410640191774720,
  "created_at" : "2016-09-01 18:13:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 7, 18 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771362739319169025",
  "geo" : { },
  "id_str" : "771363096770338816",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @plaetzchen \u270A\u270F\uFE0F\u270A\u270F\uFE0F",
  "id" : 771363096770338816,
  "in_reply_to_status_id" : 771362739319169025,
  "created_at" : "2016-09-01 15:04:28 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 7, 18 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771360513976569856",
  "geo" : { },
  "id_str" : "771360743459581952",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @plaetzchen pls order both cat &amp; dog :D",
  "id" : 771360743459581952,
  "in_reply_to_status_id" : 771360513976569856,
  "created_at" : "2016-09-01 14:55:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771312209976635392",
  "geo" : { },
  "id_str" : "771313402509717504",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps \uD83D\uDE0D",
  "id" : 771313402509717504,
  "in_reply_to_status_id" : 771312209976635392,
  "created_at" : "2016-09-01 11:47:00 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771311764998721537",
  "geo" : { },
  "id_str" : "771311891658346498",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps can I switch that for the non-internet variety in SD? :D",
  "id" : 771311891658346498,
  "in_reply_to_status_id" : 771311764998721537,
  "created_at" : "2016-09-01 11:40:59 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771292448958054400",
  "geo" : { },
  "id_str" : "771305595383144448",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps that\u2019s fine. Guess the travel makes partially up for that :p",
  "id" : 771305595383144448,
  "in_reply_to_status_id" : 771292448958054400,
  "created_at" : "2016-09-01 11:15:58 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/3p3x9hbr4I",
      "expanded_url" : "http:\/\/takehomemessage.com\/post\/131470831070\/8-cccatcggc-bgi-the-genomics-powerhouse-based?utm_content=buffera5240&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "takehomemessage.com\/post\/131470831\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771301202604720129",
  "text" : "I\u2019m still a bit disappointed that the BGI didn\u2019t give out micropigs as guest gifts last year at ICG. https:\/\/t.co\/3p3x9hbr4I",
  "id" : 771301202604720129,
  "created_at" : "2016-09-01 10:58:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 3, 11 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771299326136123392",
  "text" : "RT @o_guest: Over last 2 days, I noticed every time a woman criticises something within academia a man pops up to talk about how she hurt h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771295100043493376",
    "text" : "Over last 2 days, I noticed every time a woman criticises something within academia a man pops up to talk about how she hurt his feelings. \uD83D\uDC80",
    "id" : 771295100043493376,
    "created_at" : "2016-09-01 10:34:16 +0000",
    "user" : {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "protected" : false,
      "id_str" : "3865005196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844972791732584453\/mdSj6vOd_normal.jpg",
      "id" : 3865005196,
      "verified" : false
    }
  },
  "id" : 771299326136123392,
  "created_at" : "2016-09-01 10:51:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771290076647129092",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17246902742374, 8.627390770658707 ]
  },
  "id_str" : "771291473329418240",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps For me it\u2019s: \u201Cwhat are friends?\u201D \uD83D\uDE02",
  "id" : 771291473329418240,
  "in_reply_to_status_id" : 771290076647129092,
  "created_at" : "2016-09-01 10:19:51 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771287501449420800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724781888073, 8.627555295833039 ]
  },
  "id_str" : "771291234040221697",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest that sounds much nicer!",
  "id" : 771291234040221697,
  "in_reply_to_status_id" : 771287501449420800,
  "created_at" : "2016-09-01 10:18:54 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 9, 17 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771285143965274112",
  "geo" : { },
  "id_str" : "771286071816617988",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @kaiblin or polyeros? (too close to polyerroneous)",
  "id" : 771286071816617988,
  "in_reply_to_status_id" : 771285143965274112,
  "created_at" : "2016-09-01 09:58:23 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 9, 17 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771284489750376448",
  "geo" : { },
  "id_str" : "771284974754553856",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @kaiblin polyamorous as well.",
  "id" : 771284974754553856,
  "in_reply_to_status_id" : 771284489750376448,
  "created_at" : "2016-09-01 09:54:02 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 9, 17 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771283815616700416",
  "geo" : { },
  "id_str" : "771283972483641344",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @kaiblin to be fair: you started w\/ the mixing :p",
  "id" : 771283972483641344,
  "in_reply_to_status_id" : 771283815616700416,
  "created_at" : "2016-09-01 09:50:03 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771283375856517120",
  "geo" : { },
  "id_str" : "771283598552997888",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest \uD83D\uDC4D\uD83D\uDC96",
  "id" : 771283598552997888,
  "in_reply_to_status_id" : 771283375856517120,
  "created_at" : "2016-09-01 09:48:34 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/EoZXYovYCX",
      "expanded_url" : "https:\/\/media1.giphy.com\/media\/P8IXl0kmQgmDS\/200.gif",
      "display_url" : "media1.giphy.com\/media\/P8IXl0km\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "771283140493148160",
  "geo" : { },
  "id_str" : "771283544031330305",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest yeah, dating-while-weirdo ends like this: https:\/\/t.co\/EoZXYovYCX",
  "id" : 771283544031330305,
  "in_reply_to_status_id" : 771283140493148160,
  "created_at" : "2016-09-01 09:48:21 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771282532281282560",
  "geo" : { },
  "id_str" : "771282951665491968",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest there\u2019s not a single pillow emoji? I\u2019m disappointed by unicode. Then \uD83D\uDECB\uD83D\uDECF\uD83C\uDFD0 will have to do.",
  "id" : 771282951665491968,
  "in_reply_to_status_id" : 771282532281282560,
  "created_at" : "2016-09-01 09:46:00 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771282383601532928",
  "geo" : { },
  "id_str" : "771282489243566080",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest don\u2019t forget the polyglot again!",
  "id" : 771282489243566080,
  "in_reply_to_status_id" : 771282383601532928,
  "created_at" : "2016-09-01 09:44:09 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771282172120535041",
  "geo" : { },
  "id_str" : "771282305449070593",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest what\u2019s the other kind? \uD83D\uDE31",
  "id" : 771282305449070593,
  "in_reply_to_status_id" : 771282172120535041,
  "created_at" : "2016-09-01 09:43:26 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771280551449853953",
  "geo" : { },
  "id_str" : "771281745819889664",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest don\u2019t tell me that never happened to you! :D",
  "id" : 771281745819889664,
  "in_reply_to_status_id" : 771280551449853953,
  "created_at" : "2016-09-01 09:41:12 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/t9xi3WEjuy",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1893",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771280372348977153",
  "text" : "Being pitied on a first date \u2705\u2705 https:\/\/t.co\/t9xi3WEjuy",
  "id" : 771280372348977153,
  "created_at" : "2016-09-01 09:35:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771277729299824640",
  "text" : "After reviewing for PLOS Comp Biol they sent survey to ask why you sign reviews (if you do). How\u2019s \u201EBecause it's the right thing to do\u201C? \uD83D\uDE02",
  "id" : 771277729299824640,
  "created_at" : "2016-09-01 09:25:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 12, 18 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771275192203108353",
  "geo" : { },
  "id_str" : "771275282992988160",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen @Lobot the frequent flyer\u2019s best friend :D",
  "id" : 771275282992988160,
  "in_reply_to_status_id" : 771275192203108353,
  "created_at" : "2016-09-01 09:15:31 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 7, 18 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771274099968606209",
  "geo" : { },
  "id_str" : "771275069804904448",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @plaetzchen the earplugs, the cutting board and the mug! :D",
  "id" : 771275069804904448,
  "in_reply_to_status_id" : 771274099968606209,
  "created_at" : "2016-09-01 09:14:40 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 7, 18 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771270326416187392",
  "geo" : { },
  "id_str" : "771270585808715776",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @plaetzchen can I suggest some wishes of things I\u2019d like to get gifted?",
  "id" : 771270585808715776,
  "in_reply_to_status_id" : 771270326416187392,
  "created_at" : "2016-09-01 08:56:51 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771268003564486656",
  "geo" : { },
  "id_str" : "771268101690101760",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen ich glaube ende November bin ich wieder in Berlin. :)",
  "id" : 771268101690101760,
  "in_reply_to_status_id" : 771268003564486656,
  "created_at" : "2016-09-01 08:46:59 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771267751260327936",
  "geo" : { },
  "id_str" : "771267860354117632",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen ne, das klappt so genau leider nicht :D",
  "id" : 771267860354117632,
  "in_reply_to_status_id" : 771267751260327936,
  "created_at" : "2016-09-01 08:46:02 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771267170059902976",
  "geo" : { },
  "id_str" : "771267247058759683",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen wie schnell? :p",
  "id" : 771267247058759683,
  "in_reply_to_status_id" : 771267170059902976,
  "created_at" : "2016-09-01 08:43:35 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771266814433189888",
  "geo" : { },
  "id_str" : "771266928329445380",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen schade! \uD83D\uDE13",
  "id" : 771266928329445380,
  "in_reply_to_status_id" : 771266814433189888,
  "created_at" : "2016-09-01 08:42:19 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 12, 18 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771265869200629760",
  "geo" : { },
  "id_str" : "771266169877569536",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen @Lobot und was f\u00E4llt dir ein nach FRA zu kommen ohne bescheid zu sagen? \uD83D\uDE31\uD83D\uDE31\uD83D\uDE31",
  "id" : 771266169877569536,
  "in_reply_to_status_id" : 771265869200629760,
  "created_at" : "2016-09-01 08:39:18 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 12, 18 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771265869200629760",
  "geo" : { },
  "id_str" : "771266051522764800",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen @Lobot i want one for my desk, immediately!",
  "id" : 771266051522764800,
  "in_reply_to_status_id" : 771265869200629760,
  "created_at" : "2016-09-01 08:38:50 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3164",
      "screen_name" : "neingeist",
      "indices" : [ 0, 10 ],
      "id_str" : "11193712",
      "id" : 11193712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/J9ZFyIErmV",
      "expanded_url" : "https:\/\/www.kickstarter.com\/projects\/64ouncegames\/braille-rpg-dice-from-64-oz-games\/description",
      "display_url" : "kickstarter.com\/projects\/64oun\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "771252091486543872",
  "geo" : { },
  "id_str" : "771252570266345472",
  "in_reply_to_user_id" : 11193712,
  "text" : "@neingeist nope, war ein Kickstarter: https:\/\/t.co\/J9ZFyIErmV",
  "id" : 771252570266345472,
  "in_reply_to_status_id" : 771252091486543872,
  "created_at" : "2016-09-01 07:45:16 +0000",
  "in_reply_to_screen_name" : "neingeist",
  "in_reply_to_user_id_str" : "11193712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/771244065568362496\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/9FI8XjHnuO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrQCY8kUAAA9YgA.jpg",
      "id_str" : "771244063785746432",
      "id" : 771244063785746432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrQCY8kUAAA9YgA.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/9FI8XjHnuO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771244065568362496",
  "text" : "What I got from the post office this morning: 3D-printed braille dice! https:\/\/t.co\/9FI8XjHnuO",
  "id" : 771244065568362496,
  "created_at" : "2016-09-01 07:11:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]