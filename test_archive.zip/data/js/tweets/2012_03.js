Grailbird.data.tweets_2012_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/yNOFrr0R",
      "expanded_url" : "http:\/\/j.mp\/GZFvZt",
      "display_url" : "j.mp\/GZFvZt"
    } ]
  },
  "geo" : { },
  "id_str" : "186104921416933376",
  "text" : "Volunteering http:\/\/t.co\/yNOFrr0R",
  "id" : 186104921416933376,
  "created_at" : "2012-03-31 14:57:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186072661103886339",
  "geo" : { },
  "id_str" : "186102841448992768",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer haha, I've already done most of the stuff :D",
  "id" : 186102841448992768,
  "in_reply_to_status_id" : 186072661103886339,
  "created_at" : "2012-03-31 14:49:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186072661103886339",
  "geo" : { },
  "id_str" : "186101401137577985",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks!",
  "id" : 186101401137577985,
  "in_reply_to_status_id" : 186072661103886339,
  "created_at" : "2012-03-31 14:43:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Reiswig",
      "screen_name" : "jenfoolery",
      "indices" : [ 3, 14 ],
      "id_str" : "7120992",
      "id" : 7120992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186061012137549825",
  "text" : "RT @jenfoolery: Google, we need to talk about that top menu bar. I don't want Play. I want to customize it and put Scholar back.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "184381126352179200",
    "text" : "Google, we need to talk about that top menu bar. I don't want Play. I want to customize it and put Scholar back.",
    "id" : 184381126352179200,
    "created_at" : "2012-03-26 20:47:40 +0000",
    "user" : {
      "name" : "Jenny Reiswig",
      "screen_name" : "jenfoolery",
      "protected" : false,
      "id_str" : "7120992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564944066006093824\/mauK6lVE_normal.jpeg",
      "id" : 7120992,
      "verified" : false
    }
  },
  "id" : 186061012137549825,
  "created_at" : "2012-03-31 12:02:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186010374682849280",
  "geo" : { },
  "id_str" : "186047814269272064",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch Thanks. :)",
  "id" : 186047814269272064,
  "in_reply_to_status_id" : 186010374682849280,
  "created_at" : "2012-03-31 11:10:30 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186034649766690816",
  "text" : "urllib is driving me crazy",
  "id" : 186034649766690816,
  "created_at" : "2012-03-31 10:18:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 0, 14 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 38, 46 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186015774115233793",
  "geo" : { },
  "id_str" : "186018722270547968",
  "in_reply_to_user_id" : 12984852,
  "text" : "@CameronNeylon Great choice! Congrats @rmounce @stilettofiend",
  "id" : 186018722270547968,
  "in_reply_to_status_id" : 186015774115233793,
  "created_at" : "2012-03-31 09:14:54 +0000",
  "in_reply_to_screen_name" : "CameronNeylon",
  "in_reply_to_user_id_str" : "12984852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 36, 49 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186009355504713728",
  "geo" : { },
  "id_str" : "186009486933245952",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch Feel free to start it. @PhilippBayer and I are currently knee-deep in genotyping-applications. :)",
  "id" : 186009486933245952,
  "in_reply_to_status_id" : 186009355504713728,
  "created_at" : "2012-03-31 08:38:12 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186007912374738946",
  "geo" : { },
  "id_str" : "186008078435631104",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch Okay. But nevertheless we should define some test cases which might be interesting. :)",
  "id" : 186008078435631104,
  "in_reply_to_status_id" : 186007912374738946,
  "created_at" : "2012-03-31 08:32:36 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186005927911108609",
  "geo" : { },
  "id_str" : "186007004446330880",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Haha! I know this :D",
  "id" : 186007004446330880,
  "in_reply_to_status_id" : 186005927911108609,
  "created_at" : "2012-03-31 08:28:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186006366333313024",
  "geo" : { },
  "id_str" : "186006939547877376",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch Sounds like a good idea. Maybe we should discuss this on the mailinglist ;)",
  "id" : 186006939547877376,
  "in_reply_to_status_id" : 186006366333313024,
  "created_at" : "2012-03-31 08:28:04 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186003841441992704",
  "geo" : { },
  "id_str" : "186004334683762688",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch does it still display the \"known phenotypes\"-list on the phenotype-pages?",
  "id" : 186004334683762688,
  "in_reply_to_status_id" : 186003841441992704,
  "created_at" : "2012-03-31 08:17:43 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186003841441992704",
  "geo" : { },
  "id_str" : "186004160649502722",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch But I've to admit I haven't tested your changes yet.",
  "id" : 186004160649502722,
  "in_reply_to_status_id" : 186003841441992704,
  "created_at" : "2012-03-31 08:17:02 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186003841441992704",
  "geo" : { },
  "id_str" : "186003933662158848",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch ah, you're right!",
  "id" : 186003933662158848,
  "in_reply_to_status_id" : 186003841441992704,
  "created_at" : "2012-03-31 08:16:08 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/tCrjjKc7",
      "expanded_url" : "http:\/\/opensnp.org\/search?utf8=%E2%9C%93&search=inta",
      "display_url" : "opensnp.org\/search?utf8=%E\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "186002747894665216",
  "geo" : { },
  "id_str" : "186003561145057280",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch maybe it's because of the upper\/lower case? But the Solr-Search on the webpage searches sub-strings: http:\/\/t.co\/tCrjjKc7",
  "id" : 186003561145057280,
  "in_reply_to_status_id" : 186002747894665216,
  "created_at" : "2012-03-31 08:14:39 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186002747894665216",
  "geo" : { },
  "id_str" : "186003174501523456",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer Search for \"minGramSize\" in schema.xml in \/solr\/conf",
  "id" : 186003174501523456,
  "in_reply_to_status_id" : 186002747894665216,
  "created_at" : "2012-03-31 08:13:07 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "186000464544923648",
  "geo" : { },
  "id_str" : "186000653821288448",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch but the problem persists as long as you allow kmers, just gets more unlikely",
  "id" : 186000653821288448,
  "in_reply_to_status_id" : 186000464544923648,
  "created_at" : "2012-03-31 08:03:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185997781108932608",
  "geo" : { },
  "id_str" : "185999527998791680",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch and sometimes similar substrings are other variations :D",
  "id" : 185999527998791680,
  "in_reply_to_status_id" : 185997781108932608,
  "created_at" : "2012-03-31 07:58:37 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185997781108932608",
  "geo" : { },
  "id_str" : "185999456162938880",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch that is the problem with unifying the data. sometimes you want to match it (\"right\" and all variations of \"right handed\")",
  "id" : 185999456162938880,
  "in_reply_to_status_id" : 185997781108932608,
  "created_at" : "2012-03-31 07:58:20 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185997819130298368",
  "geo" : { },
  "id_str" : "185998278695981056",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer if not for those linebreaks grep would work fine: grep \"TRUE,TRUE,FALSE,FALSE,FALSE,FALSE\" :D",
  "id" : 185998278695981056,
  "in_reply_to_status_id" : 185997819130298368,
  "created_at" : "2012-03-31 07:53:39 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185997819130298368",
  "geo" : { },
  "id_str" : "185998158512390144",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Ah! the problem are linebreaks in applicants answers. if you use OO make sure you use \" as text separator.",
  "id" : 185998158512390144,
  "in_reply_to_status_id" : 185997819130298368,
  "created_at" : "2012-03-31 07:53:11 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185996271461466112",
  "geo" : { },
  "id_str" : "185997499310419968",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer should work using awk :D",
  "id" : 185997499310419968,
  "in_reply_to_status_id" : 185996271461466112,
  "created_at" : "2012-03-31 07:50:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185995604487450624",
  "geo" : { },
  "id_str" : "185995910973636608",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I'll see how I can filter the data using OO. :)",
  "id" : 185995910973636608,
  "in_reply_to_status_id" : 185995604487450624,
  "created_at" : "2012-03-31 07:44:15 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185994539444604928",
  "geo" : { },
  "id_str" : "185995043801268225",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch the \"male\"-category would also download all \"female\"-files.",
  "id" : 185995043801268225,
  "in_reply_to_status_id" : 185994539444604928,
  "created_at" : "2012-03-31 07:40:48 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/o1mXaH5w",
      "expanded_url" : "http:\/\/opensnp.org\/phenotypes\/60",
      "display_url" : "opensnp.org\/phenotypes\/60"
    } ]
  },
  "in_reply_to_status_id_str" : "185994539444604928",
  "geo" : { },
  "id_str" : "185994894723125248",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch okay, maybe we should narrow the focus for phenotype-searches a bit. otherwise we will run into problems: http:\/\/t.co\/o1mXaH5w",
  "id" : 185994894723125248,
  "in_reply_to_status_id" : 185994539444604928,
  "created_at" : "2012-03-31 07:40:13 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185988044887830529",
  "geo" : { },
  "id_str" : "185993656946270208",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer the web-search would list foobar as well. But for phenotypes it should be more strict I think.",
  "id" : 185993656946270208,
  "in_reply_to_status_id" : 185988044887830529,
  "created_at" : "2012-03-31 07:35:18 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185988044887830529",
  "geo" : { },
  "id_str" : "185993324476370945",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch What happens if I search for \"foo\" and there are users who have entered their variation as \"foobar\"?",
  "id" : 185993324476370945,
  "in_reply_to_status_id" : 185988044887830529,
  "created_at" : "2012-03-31 07:33:58 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Blumtritt",
      "screen_name" : "jbenno",
      "indices" : [ 0, 7 ],
      "id_str" : "10177792",
      "id" : 10177792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185874703192305665",
  "geo" : { },
  "id_str" : "185877328541396993",
  "in_reply_to_user_id" : 10177792,
  "text" : "@jbenno Statistik, Stochastik etc. kommen halt immer noch zu kurz in fast allen Ausbildungen.",
  "id" : 185877328541396993,
  "in_reply_to_status_id" : 185874703192305665,
  "created_at" : "2012-03-30 23:53:03 +0000",
  "in_reply_to_screen_name" : "jbenno",
  "in_reply_to_user_id_str" : "10177792",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185871640004018176",
  "geo" : { },
  "id_str" : "185872616916127745",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye der einfachheit halber: Niemandem. Oder Anteilig in Familien laufende Rechte.",
  "id" : 185872616916127745,
  "in_reply_to_status_id" : 185871640004018176,
  "created_at" : "2012-03-30 23:34:19 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    }, {
      "name" : "jensbest",
      "screen_name" : "jensbest",
      "indices" : [ 8, 17 ],
      "id_str" : "14599545",
      "id" : 14599545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185871386001162241",
  "geo" : { },
  "id_str" : "185871793893027840",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye @jensbest ich denk das ben\u00F6tigt man eigentlich bei allen modernen Diagnostikverfahren (MRI, Serummessungen etc.)",
  "id" : 185871793893027840,
  "in_reply_to_status_id" : 185871386001162241,
  "created_at" : "2012-03-30 23:31:03 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185871072292384768",
  "geo" : { },
  "id_str" : "185871486823829504",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye absolut. Recht auf Nichtwissen sch\u00F6n und gut. Aber das wird meist so weit in den Vordergrund gestellt das der Rest vergessen wird.",
  "id" : 185871486823829504,
  "in_reply_to_status_id" : 185871072292384768,
  "created_at" : "2012-03-30 23:29:50 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185870717471039488",
  "geo" : { },
  "id_str" : "185871154307792897",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye f\u00FCr die L\u00E4nderebene ist das leider nix. Bund bzw. EU.",
  "id" : 185871154307792897,
  "in_reply_to_status_id" : 185870717471039488,
  "created_at" : "2012-03-30 23:28:31 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 86 ],
      "url" : "https:\/\/t.co\/syMNsYmF",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/ENGAGE-submission\/blob\/master\/ENGAGE-draft.md",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "185868377917620225",
  "geo" : { },
  "id_str" : "185870314264203265",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye aber generell muss sich da was \u00E4ndern. Meine Ideen dazu: https:\/\/t.co\/syMNsYmF (jetzt aber erstmal gute Nacht ;))",
  "id" : 185870314264203265,
  "in_reply_to_status_id" : 185868377917620225,
  "created_at" : "2012-03-30 23:25:10 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    }, {
      "name" : "jensbest",
      "screen_name" : "jensbest",
      "indices" : [ 8, 17 ],
      "id_str" : "14599545",
      "id" : 14599545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185868377917620225",
  "geo" : { },
  "id_str" : "185869067834499073",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye @jensbest aber das wird akuter wenn man \"routinem\u00E4ssig\" ganze Genome scannt.",
  "id" : 185869067834499073,
  "in_reply_to_status_id" : 185868377917620225,
  "created_at" : "2012-03-30 23:20:13 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jensbest",
      "screen_name" : "jensbest",
      "indices" : [ 0, 9 ],
      "id_str" : "14599545",
      "id" : 14599545
    }, {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 10, 17 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185866068638699520",
  "geo" : { },
  "id_str" : "185867860495708163",
  "in_reply_to_user_id" : 14599545,
  "text" : "@jensbest @CaeVye das ist eine der Aufgaben die \u00C4rzte dann mit\u00FCbernehmen m\u00FCssen. Bzw. Genetic Counselor.",
  "id" : 185867860495708163,
  "in_reply_to_status_id" : 185866068638699520,
  "created_at" : "2012-03-30 23:15:25 +0000",
  "in_reply_to_screen_name" : "jensbest",
  "in_reply_to_user_id_str" : "14599545",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jensbest",
      "screen_name" : "jensbest",
      "indices" : [ 0, 9 ],
      "id_str" : "14599545",
      "id" : 14599545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185862781684297728",
  "geo" : { },
  "id_str" : "185864481463738368",
  "in_reply_to_user_id" : 14599545,
  "text" : "@jensbest immerhin sieht man langsam ein das es keine L\u00F6sung ist secondary findings einfach zu ignorieren....",
  "id" : 185864481463738368,
  "in_reply_to_status_id" : 185862781684297728,
  "created_at" : "2012-03-30 23:02:00 +0000",
  "in_reply_to_screen_name" : "jensbest",
  "in_reply_to_user_id_str" : "14599545",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/FEdBMqmg",
      "expanded_url" : "http:\/\/j.mp\/H7TolT",
      "display_url" : "j.mp\/H7TolT"
    } ]
  },
  "geo" : { },
  "id_str" : "185862039258935297",
  "text" : "Geneticists debate what to tell patients about clinical genome sequences http:\/\/t.co\/FEdBMqmg",
  "id" : 185862039258935297,
  "created_at" : "2012-03-30 22:52:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "biobank",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185860193685475329",
  "text" : "I see why you would need to apply for access to the biological samples as they are limited. But why limit access to digital data? #biobank",
  "id" : 185860193685475329,
  "created_at" : "2012-03-30 22:44:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/PmcedneB",
      "expanded_url" : "http:\/\/j.mp\/H5VzGK",
      "display_url" : "j.mp\/H5VzGK"
    } ]
  },
  "geo" : { },
  "id_str" : "185858927475441665",
  "text" : "So Biobank provides \u00ABOnly information that does not identify participants\u00BB but you still need to apply for access? http:\/\/t.co\/PmcedneB",
  "id" : 185858927475441665,
  "created_at" : "2012-03-30 22:39:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/xyTJZdGd",
      "expanded_url" : "http:\/\/j.mp\/HruFLt",
      "display_url" : "j.mp\/HruFLt"
    } ]
  },
  "geo" : { },
  "id_str" : "185855881043378176",
  "text" : "The math behind choosing a urinal http:\/\/t.co\/xyTJZdGd",
  "id" : 185855881043378176,
  "created_at" : "2012-03-30 22:27:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/ScZV3lwW",
      "expanded_url" : "http:\/\/j.mp\/GYvb3T",
      "display_url" : "j.mp\/GYvb3T"
    } ]
  },
  "geo" : { },
  "id_str" : "185853995137507328",
  "text" : "The nerd defense: \u201CGlasses can\u2019t hide neck tattoos\u201D http:\/\/t.co\/ScZV3lwW",
  "id" : 185853995137507328,
  "created_at" : "2012-03-30 22:20:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/JJXAc0Qd",
      "expanded_url" : "http:\/\/infobeautiful2.s3.amazonaws.com\/RhetoricalFallacy_SameSexMarriage.png",
      "display_url" : "infobeautiful2.s3.amazonaws.com\/RhetoricalFall\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185852798196391936",
  "text" : "One fallacy every 40 words: http:\/\/t.co\/JJXAc0Qd",
  "id" : 185852798196391936,
  "created_at" : "2012-03-30 22:15:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 3, 18 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    }, {
      "name" : "Info=Beautiful",
      "screen_name" : "infobeautiful",
      "indices" : [ 57, 71 ],
      "id_str" : "54680395",
      "id" : 54680395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185852303448866817",
  "text" : "RT @gedankenabfall: Don't miss the example at the end RT @infobeautiful: The most common errors & manipulations of rhetoric & thought ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.flipboard.com\" rel=\"nofollow\"\u003EFlipboard\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Info=Beautiful",
        "screen_name" : "infobeautiful",
        "indices" : [ 37, 51 ],
        "id_str" : "54680395",
        "id" : 54680395
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 135, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/os8xy7p6",
        "expanded_url" : "http:\/\/bit.ly\/rhetological2",
        "display_url" : "bit.ly\/rhetological2"
      } ]
    },
    "geo" : { },
    "id_str" : "185849915623227392",
    "text" : "Don't miss the example at the end RT @infobeautiful: The most common errors & manipulations of rhetoric & thought http:\/\/t.co\/os8xy7p6 #fb",
    "id" : 185849915623227392,
    "created_at" : "2012-03-30 22:04:07 +0000",
    "user" : {
      "name" : "Martin Ballaschk",
      "screen_name" : "ballaschk",
      "protected" : false,
      "id_str" : "29082973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929738577637986304\/nZwS53cM_normal.jpg",
      "id" : 29082973,
      "verified" : false
    }
  },
  "id" : 185852303448866817,
  "created_at" : "2012-03-30 22:13:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/viuWg4K8",
      "expanded_url" : "http:\/\/j.mp\/H8f6qs",
      "display_url" : "j.mp\/H8f6qs"
    } ]
  },
  "geo" : { },
  "id_str" : "185846677746352128",
  "text" : "For those who feel they can multitask: 130 Simpsons episodes at once http:\/\/t.co\/viuWg4K8",
  "id" : 185846677746352128,
  "created_at" : "2012-03-30 21:51:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hitokkohitori",
      "screen_name" : "HitorinoKikai",
      "indices" : [ 0, 14 ],
      "id_str" : "158855376",
      "id" : 158855376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185780791215796226",
  "geo" : { },
  "id_str" : "185783510940917762",
  "in_reply_to_user_id" : 158855376,
  "text" : "@HitorinoKikai mir w\u00E4re plaintext auf der Krankenkassen-Webseite sogar lieber als gar keinen Zugriff zu haben.",
  "id" : 185783510940917762,
  "in_reply_to_status_id" : 185780791215796226,
  "created_at" : "2012-03-30 17:40:15 +0000",
  "in_reply_to_screen_name" : "HitorinoKikai",
  "in_reply_to_user_id_str" : "158855376",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u043Enasterium",
      "screen_name" : "monasterium",
      "indices" : [ 0, 12 ],
      "id_str" : "15126396",
      "id" : 15126396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185756423228100609",
  "geo" : { },
  "id_str" : "185757067171217408",
  "in_reply_to_user_id" : 15126396,
  "text" : "@monasterium Frag mal die Uni-Bib ob das so stimmt ;)",
  "id" : 185757067171217408,
  "in_reply_to_status_id" : 185756423228100609,
  "created_at" : "2012-03-30 15:55:10 +0000",
  "in_reply_to_screen_name" : "monasterium",
  "in_reply_to_user_id_str" : "15126396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u043Enasterium",
      "screen_name" : "monasterium",
      "indices" : [ 0, 12 ],
      "id_str" : "15126396",
      "id" : 15126396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185747867812638720",
  "geo" : { },
  "id_str" : "185756267934007296",
  "in_reply_to_user_id" : 15126396,
  "text" : "@monasterium Nicht Mikrofilm?",
  "id" : 185756267934007296,
  "in_reply_to_status_id" : 185747867812638720,
  "created_at" : "2012-03-30 15:52:00 +0000",
  "in_reply_to_screen_name" : "monasterium",
  "in_reply_to_user_id_str" : "15126396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185748207857442817",
  "geo" : { },
  "id_str" : "185748692890943488",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog na klar, wer weiss was ich sonst B\u00F6ses damit anfange!",
  "id" : 185748692890943488,
  "in_reply_to_status_id" : 185748207857442817,
  "created_at" : "2012-03-30 15:21:54 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185746765071384576",
  "geo" : { },
  "id_str" : "185747901681639424",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog wird wegen Datenschutz bestimmt abgeschmettert ;)",
  "id" : 185747901681639424,
  "in_reply_to_status_id" : 185746765071384576,
  "created_at" : "2012-03-30 15:18:45 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185746584821186561",
  "text" : "Elektronische Gesundheitskarte mit Lichtbild sch\u00F6n und gut. Aber \u00FCber welche API komm ich jetzt an meine Krankenakten?",
  "id" : 185746584821186561,
  "created_at" : "2012-03-30 15:13:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "masseffect",
      "indices" : [ 47, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185505861291098112",
  "text" : "\u00ABJust one more Quest!\u00BB Suddenly: 4 hours later #masseffect",
  "id" : 185505861291098112,
  "created_at" : "2012-03-29 23:16:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185503621755056129",
  "geo" : { },
  "id_str" : "185505158472548353",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn great new profile picture! :)",
  "id" : 185505158472548353,
  "in_reply_to_status_id" : 185503621755056129,
  "created_at" : "2012-03-29 23:14:10 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185473051096387584",
  "text" : "The Shadow?!",
  "id" : 185473051096387584,
  "created_at" : "2012-03-29 21:06:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Falk",
      "screen_name" : "danfalk",
      "indices" : [ 3, 11 ],
      "id_str" : "16469647",
      "id" : 16469647
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 88, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185457414756249600",
  "text" : "RT @danfalk: If you're an adult, do you suppose you ought to read -- dare one say it -- #books actually written for adults? http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "books",
        "indices" : [ 75, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/gg8yzEnk",
        "expanded_url" : "http:\/\/nyti.ms\/H2SCv2",
        "display_url" : "nyti.ms\/H2SCv2"
      } ]
    },
    "geo" : { },
    "id_str" : "185418592521687040",
    "text" : "If you're an adult, do you suppose you ought to read -- dare one say it -- #books actually written for adults? http:\/\/t.co\/gg8yzEnk",
    "id" : 185418592521687040,
    "created_at" : "2012-03-29 17:30:12 +0000",
    "user" : {
      "name" : "Dan Falk",
      "screen_name" : "danfalk",
      "protected" : false,
      "id_str" : "16469647",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1901822571\/My_Knight_photo_normal.jpg",
      "id" : 16469647,
      "verified" : false
    }
  },
  "id" : 185457414756249600,
  "created_at" : "2012-03-29 20:04:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pierre Lindenbaum",
      "screen_name" : "yokofakun",
      "indices" : [ 0, 10 ],
      "id_str" : "7431072",
      "id" : 7431072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185429299208269825",
  "geo" : { },
  "id_str" : "185431111441195009",
  "in_reply_to_user_id" : 7431072,
  "text" : "@yokofakun So the news is they can measure how much codon bias slows down translation?",
  "id" : 185431111441195009,
  "in_reply_to_status_id" : 185429299208269825,
  "created_at" : "2012-03-29 18:19:56 +0000",
  "in_reply_to_screen_name" : "yokofakun",
  "in_reply_to_user_id_str" : "7431072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/39bxIhBt",
      "expanded_url" : "http:\/\/j.mp\/H4OcEd",
      "display_url" : "j.mp\/H4OcEd"
    } ]
  },
  "geo" : { },
  "id_str" : "185427362039599104",
  "text" : "Mysterious Stone Monolith Likely an Ancient Astronomical Calendar http:\/\/t.co\/39bxIhBt",
  "id" : 185427362039599104,
  "created_at" : "2012-03-29 18:05:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/B6rX9oH8",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=HLNyigUDxT8",
      "display_url" : "youtube.com\/watch?v=HLNyig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185422175497502720",
  "text" : "\u00ABDancing Barefoot\u00BB Patti Smith accompanied by Eddie Vedder & Johnny Depp http:\/\/t.co\/B6rX9oH8",
  "id" : 185422175497502720,
  "created_at" : "2012-03-29 17:44:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/XVvI3VaB",
      "expanded_url" : "http:\/\/j.mp\/GXYToO",
      "display_url" : "j.mp\/GXYToO"
    } ]
  },
  "geo" : { },
  "id_str" : "185419720290336768",
  "text" : "The Ultrabook Ice http:\/\/t.co\/XVvI3VaB",
  "id" : 185419720290336768,
  "created_at" : "2012-03-29 17:34:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/3y0IhLvJ",
      "expanded_url" : "http:\/\/j.mp\/HmeIsg",
      "display_url" : "j.mp\/HmeIsg"
    } ]
  },
  "geo" : { },
  "id_str" : "185415666868822016",
  "text" : "Santorum and his pink balls http:\/\/t.co\/3y0IhLvJ",
  "id" : 185415666868822016,
  "created_at" : "2012-03-29 17:18:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Gitlin",
      "screen_name" : "drgitlin",
      "indices" : [ 3, 12 ],
      "id_str" : "2139671",
      "id" : 2139671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185410370427559936",
  "text" : "RT @drgitlin: One issue with last night's Nova and privacy: your genome might be revealing, but almost certainly less so than your netfl ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "185407993637126144",
    "text" : "One issue with last night's Nova and privacy: your genome might be revealing, but almost certainly less so than your netflix history.",
    "id" : 185407993637126144,
    "created_at" : "2012-03-29 16:48:05 +0000",
    "user" : {
      "name" : "Jonathan Gitlin",
      "screen_name" : "drgitlin",
      "protected" : false,
      "id_str" : "2139671",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455467695299756032\/ve2Aectb_normal.jpeg",
      "id" : 2139671,
      "verified" : true
    }
  },
  "id" : 185410370427559936,
  "created_at" : "2012-03-29 16:57:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185409164565159936",
  "geo" : { },
  "id_str" : "185409428231700481",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon Haha, also wirklich bragging rights. ;)",
  "id" : 185409428231700481,
  "in_reply_to_status_id" : 185409164565159936,
  "created_at" : "2012-03-29 16:53:47 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185408486648184834",
  "geo" : { },
  "id_str" : "185408682744492033",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon Und wie hat es ihm gefallen?",
  "id" : 185408682744492033,
  "in_reply_to_status_id" : 185408486648184834,
  "created_at" : "2012-03-29 16:50:49 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/aw3MUFCO",
      "expanded_url" : "http:\/\/j.mp\/HthIQh",
      "display_url" : "j.mp\/HthIQh"
    } ]
  },
  "geo" : { },
  "id_str" : "185406273804701696",
  "text" : "Paintballing with Hezbollah http:\/\/t.co\/aw3MUFCO",
  "id" : 185406273804701696,
  "created_at" : "2012-03-29 16:41:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 0, 11 ],
      "id_str" : "191004758",
      "id" : 191004758
    }, {
      "name" : "Fiona Jordan",
      "screen_name" : "fiona_jordan",
      "indices" : [ 12, 25 ],
      "id_str" : "130927428",
      "id" : 130927428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185400496100614144",
  "geo" : { },
  "id_str" : "185401092253814784",
  "in_reply_to_user_id" : 191004758,
  "text" : "@PygmyLoris @fiona_jordan awesome! :)",
  "id" : 185401092253814784,
  "in_reply_to_status_id" : 185400496100614144,
  "created_at" : "2012-03-29 16:20:39 +0000",
  "in_reply_to_screen_name" : "PygmyLoris",
  "in_reply_to_user_id_str" : "191004758",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/svB9IqMn",
      "expanded_url" : "http:\/\/j.mp\/HjIWbp",
      "display_url" : "j.mp\/HjIWbp"
    } ]
  },
  "geo" : { },
  "id_str" : "185399597563252736",
  "text" : "Should Science Pull the Trigger on Antiviral Drug? http:\/\/t.co\/svB9IqMn",
  "id" : 185399597563252736,
  "created_at" : "2012-03-29 16:14:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/KC22nIgD",
      "expanded_url" : "http:\/\/www.newyorker.com\/arts\/critics\/atlarge\/2010\/06\/14\/100614crat_atlarge_miller?currentPage=all",
      "display_url" : "newyorker.com\/arts\/critics\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185392988023820289",
  "text" : "Dystopia in young-adult novels http:\/\/t.co\/KC22nIgD",
  "id" : 185392988023820289,
  "created_at" : "2012-03-29 15:48:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/wMj3xGu3",
      "expanded_url" : "http:\/\/nymag.com\/print\/?\/restaurants\/features\/foodies-2012-4\/",
      "display_url" : "nymag.com\/print\/?\/restau\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185390593646661635",
  "text" : "Food hipster: \u00ABThe idea of eating well wasn\u2019t just democratized. It was now, improbably enough, edgy\u00BB http:\/\/t.co\/wMj3xGu3",
  "id" : 185390593646661635,
  "created_at" : "2012-03-29 15:38:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185386026569695232",
  "geo" : { },
  "id_str" : "185387078228525057",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU you are doing it wrong ;)",
  "id" : 185387078228525057,
  "in_reply_to_status_id" : 185386026569695232,
  "created_at" : "2012-03-29 15:24:58 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 0, 15 ],
      "id_str" : "73134122",
      "id" : 73134122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185365034547953664",
  "geo" : { },
  "id_str" : "185367211001643008",
  "in_reply_to_user_id" : 73134122,
  "text" : "@astefanowitsch bei der Qualit\u00E4t der Drehb\u00FCcher brauchen die doch niemals 90 Minuten um eines davon zu schreiben!",
  "id" : 185367211001643008,
  "in_reply_to_status_id" : 185365034547953664,
  "created_at" : "2012-03-29 14:06:01 +0000",
  "in_reply_to_screen_name" : "astefanowitsch",
  "in_reply_to_user_id_str" : "73134122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185344040613576705",
  "geo" : { },
  "id_str" : "185344496832225280",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ Ok, und \u00ABArbeiterfamilie\u00BB ist dann wohl einfach die \"unterste\" Einstufung.",
  "id" : 185344496832225280,
  "in_reply_to_status_id" : 185344040613576705,
  "created_at" : "2012-03-29 12:35:46 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185338159062720513",
  "geo" : { },
  "id_str" : "185339176223375360",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ wie ist \"Arbeiterfamilie\" daf\u00FCr definiert?",
  "id" : 185339176223375360,
  "in_reply_to_status_id" : 185338159062720513,
  "created_at" : "2012-03-29 12:14:37 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edn6099",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/vYJPis0S",
      "expanded_url" : "http:\/\/ow.ly\/9X2uv",
      "display_url" : "ow.ly\/9X2uv"
    } ]
  },
  "geo" : { },
  "id_str" : "185334828844072960",
  "text" : "RT @bella_velo: great info on \"the Twitter experiment\"  http:\/\/t.co\/vYJPis0S #edn6099",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edn6099",
        "indices" : [ 61, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/vYJPis0S",
        "expanded_url" : "http:\/\/ow.ly\/9X2uv",
        "display_url" : "ow.ly\/9X2uv"
      } ]
    },
    "geo" : { },
    "id_str" : "185334290408685568",
    "text" : "great info on \"the Twitter experiment\"  http:\/\/t.co\/vYJPis0S #edn6099",
    "id" : 185334290408685568,
    "created_at" : "2012-03-29 11:55:12 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 185334828844072960,
  "created_at" : "2012-03-29 11:57:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185333673116172289",
  "geo" : { },
  "id_str" : "185334036380647426",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon reine Angst vor dem Shitstorm ;)",
  "id" : 185334036380647426,
  "in_reply_to_status_id" : 185333673116172289,
  "created_at" : "2012-03-29 11:54:12 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/kPM7EF49",
      "expanded_url" : "http:\/\/nymag.com\/print\/?\/news\/frank-rich\/gop-women-problem-2012-4\/",
      "display_url" : "nymag.com\/print\/?\/news\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185333425316700160",
  "text" : "\u00ABThe GOP\u2019s woman problem is that it has a serious problem with women.\u00BB http:\/\/t.co\/kPM7EF49",
  "id" : 185333425316700160,
  "created_at" : "2012-03-29 11:51:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/shdw9eL9",
      "expanded_url" : "http:\/\/j.mp\/Hl4XIN",
      "display_url" : "j.mp\/Hl4XIN"
    } ]
  },
  "geo" : { },
  "id_str" : "185331248179322880",
  "text" : "Diving in radioactive waters: Swimming On The Hot Side http:\/\/t.co\/shdw9eL9",
  "id" : 185331248179322880,
  "created_at" : "2012-03-29 11:43:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/7bo2002N",
      "expanded_url" : "http:\/\/j.mp\/HrK39P",
      "display_url" : "j.mp\/HrK39P"
    } ]
  },
  "geo" : { },
  "id_str" : "185327185920393216",
  "text" : "Yeay: Long-fingered African frog rediscovered after 62 years http:\/\/t.co\/7bo2002N",
  "id" : 185327185920393216,
  "created_at" : "2012-03-29 11:26:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ebbert",
      "screen_name" : "nalfion",
      "indices" : [ 0, 8 ],
      "id_str" : "799167086182408192",
      "id" : 799167086182408192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185327003266850816",
  "text" : "@nalfion stimmt, ich find nur das deploying an sich immer ganz sch\u00E4big. ;)",
  "id" : 185327003266850816,
  "created_at" : "2012-03-29 11:26:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/uYpizDPm",
      "expanded_url" : "http:\/\/geekchick77.dreamwidth.org\/472.html",
      "display_url" : "geekchick77.dreamwidth.org\/472.html"
    } ]
  },
  "geo" : { },
  "id_str" : "185326009896271872",
  "text" : "RT @PhilippBayer: Fighting sexist IRC-jokes with a bot http:\/\/t.co\/uYpizDPm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/uYpizDPm",
        "expanded_url" : "http:\/\/geekchick77.dreamwidth.org\/472.html",
        "display_url" : "geekchick77.dreamwidth.org\/472.html"
      } ]
    },
    "geo" : { },
    "id_str" : "185143427669827584",
    "text" : "Fighting sexist IRC-jokes with a bot http:\/\/t.co\/uYpizDPm",
    "id" : 185143427669827584,
    "created_at" : "2012-03-28 23:16:47 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 185326009896271872,
  "created_at" : "2012-03-29 11:22:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/itUYfweX",
      "expanded_url" : "http:\/\/j.mp\/HpD2aE",
      "display_url" : "j.mp\/HpD2aE"
    } ]
  },
  "geo" : { },
  "id_str" : "185322909391273986",
  "text" : "Down-voting your relationship http:\/\/t.co\/itUYfweX",
  "id" : 185322909391273986,
  "created_at" : "2012-03-29 11:09:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ebbert",
      "screen_name" : "nalfion",
      "indices" : [ 0, 8 ],
      "id_str" : "799167086182408192",
      "id" : 799167086182408192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185321385516728321",
  "text" : "@nalfion also lokal aufgesetzt haben sollte man das relativ fix (zumindest wenn man schon irgendein Ruby auf seinem System hat) ;)",
  "id" : 185321385516728321,
  "created_at" : "2012-03-29 11:03:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ebbert",
      "screen_name" : "nalfion",
      "indices" : [ 0, 8 ],
      "id_str" : "799167086182408192",
      "id" : 799167086182408192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185320948336050176",
  "text" : "@nalfion ist alles nicht so wirklich Rocket Science ;)",
  "id" : 185320948336050176,
  "created_at" : "2012-03-29 11:02:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ebbert",
      "screen_name" : "nalfion",
      "indices" : [ 0, 8 ],
      "id_str" : "799167086182408192",
      "id" : 799167086182408192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185318160457662465",
  "text" : "@nalfion Ist allerdings alles kein St\u00FCck getestet. :P",
  "id" : 185318160457662465,
  "created_at" : "2012-03-29 10:51:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ebbert",
      "screen_name" : "nalfion",
      "indices" : [ 0, 8 ],
      "id_str" : "799167086182408192",
      "id" : 799167086182408192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 52 ],
      "url" : "https:\/\/t.co\/gT06aytk",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/twitter_backup",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185317886104043520",
  "text" : "@nalfion Jo, Code gibt\u2019s hier: https:\/\/t.co\/gT06aytk",
  "id" : 185317886104043520,
  "created_at" : "2012-03-29 10:50:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ebbert",
      "screen_name" : "nalfion",
      "indices" : [ 0, 8 ],
      "id_str" : "799167086182408192",
      "id" : 799167086182408192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/kZkJeyol",
      "expanded_url" : "http:\/\/code.google.com\/apis\/chart\/interactive\/docs\/index.html",
      "display_url" : "code.google.com\/apis\/chart\/int\u2026"
    }, {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/Cigu9Ucc",
      "expanded_url" : "http:\/\/www.patrick-wied.at\/static\/heatmapjs\/",
      "display_url" : "patrick-wied.at\/static\/heatmap\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185317831871692800",
  "text" : "@nalfion Die Visualisierungen kommen \u00FCber Google Chart Tools (http:\/\/t.co\/kZkJeyol) und Heatmap.js (http:\/\/t.co\/Cigu9Ucc)",
  "id" : 185317831871692800,
  "created_at" : "2012-03-29 10:49:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ebbert",
      "screen_name" : "nalfion",
      "indices" : [ 0, 8 ],
      "id_str" : "799167086182408192",
      "id" : 799167086182408192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185317544327000064",
  "text" : "@nalfion Was genau? Das Framework ist Rails. Tweets werden cron-gesteuert regelm\u00E4ssig \u00FCber ein Twitter-Gem in meine DB geladen.",
  "id" : 185317544327000064,
  "created_at" : "2012-03-29 10:48:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/QQ9uaWOa",
      "expanded_url" : "http:\/\/phylomemetic-tree.de\/twitter\/places",
      "display_url" : "phylomemetic-tree.de\/twitter\/places"
    } ]
  },
  "geo" : { },
  "id_str" : "185316641297547264",
  "text" : "Added some heatmaps and visualizations to my twitter backups http:\/\/t.co\/QQ9uaWOa",
  "id" : 185316641297547264,
  "created_at" : "2012-03-29 10:45:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niels-Arne M\u00FCnck",
      "screen_name" : "Wernermuende",
      "indices" : [ 0, 13 ],
      "id_str" : "56502413",
      "id" : 56502413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185283633102336000",
  "geo" : { },
  "id_str" : "185283715646234624",
  "in_reply_to_user_id" : 56502413,
  "text" : "@Wernermuende Das ist cool. Muss ich mir mal anschauen.",
  "id" : 185283715646234624,
  "in_reply_to_status_id" : 185283633102336000,
  "created_at" : "2012-03-29 08:34:14 +0000",
  "in_reply_to_screen_name" : "Wernermuende",
  "in_reply_to_user_id_str" : "56502413",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niels-Arne M\u00FCnck",
      "screen_name" : "Wernermuende",
      "indices" : [ 0, 13 ],
      "id_str" : "56502413",
      "id" : 56502413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185282005242626048",
  "geo" : { },
  "id_str" : "185282737039622144",
  "in_reply_to_user_id" : 56502413,
  "text" : "@Wernermuende Dar\u00FCber (und Principal Coordinates Analysis) hatten wir vor kurzem noch ein Seminar. Wof\u00FCr brauchst du das?",
  "id" : 185282737039622144,
  "in_reply_to_status_id" : 185282005242626048,
  "created_at" : "2012-03-29 08:30:21 +0000",
  "in_reply_to_screen_name" : "Wernermuende",
  "in_reply_to_user_id_str" : "56502413",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lex Nederbragt",
      "screen_name" : "lexnederbragt",
      "indices" : [ 3, 17 ],
      "id_str" : "48966898",
      "id" : 48966898
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "genome",
      "indices" : [ 46, 53 ]
    }, {
      "text" : "assembly",
      "indices" : [ 54, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185259434057019392",
  "text" : "RT @lexnederbragt: A warning for newcomers to #genome #assembly: \u201CThis is not an easy science problem. Expect errors and tread carefully ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/chrome.google.com\/webstore\/detail\/tweet-this-page\/ppilhaolhbpfembaoedfdbkegfedfgip\" rel=\"nofollow\"\u003ETweet-this-page\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "genome",
        "indices" : [ 27, 34 ]
      }, {
        "text" : "assembly",
        "indices" : [ 35, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/kpwhGdev",
        "expanded_url" : "http:\/\/bit.ly\/H2ULa5",
        "display_url" : "bit.ly\/H2ULa5"
      } ]
    },
    "geo" : { },
    "id_str" : "185251685013270528",
    "text" : "A warning for newcomers to #genome #assembly: \u201CThis is not an easy science problem. Expect errors and tread carefully\" http:\/\/t.co\/kpwhGdev",
    "id" : 185251685013270528,
    "created_at" : "2012-03-29 06:26:58 +0000",
    "user" : {
      "name" : "Lex Nederbragt",
      "screen_name" : "lexnederbragt",
      "protected" : false,
      "id_str" : "48966898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1099225219\/DSC01628a_normal.jpg",
      "id" : 48966898,
      "verified" : false
    }
  },
  "id" : 185259434057019392,
  "created_at" : "2012-03-29 06:57:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/Yw3vlYfF",
      "expanded_url" : "http:\/\/j.mp\/GXGoSA",
      "display_url" : "j.mp\/GXGoSA"
    } ]
  },
  "geo" : { },
  "id_str" : "185120131146457088",
  "text" : "\u00ABEs ist wohl noch vieles m\u00F6glich - aber nicht mehr alles\u00BB http:\/\/t.co\/Yw3vlYfF",
  "id" : 185120131146457088,
  "created_at" : "2012-03-28 21:44:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097398151, 8.2831289624 ]
  },
  "id_str" : "185118897794584576",
  "text" : "Ich habe ein Wombat und ich werde es knuddeln!",
  "id" : 185118897794584576,
  "created_at" : "2012-03-28 21:39:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mela Eckenfels",
      "screen_name" : "Felicea",
      "indices" : [ 0, 8 ],
      "id_str" : "3969351",
      "id" : 3969351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 101 ],
      "url" : "https:\/\/t.co\/NKPrxmwV",
      "expanded_url" : "https:\/\/www.privacyinternational.org\/blog\/what-does-twitter-know-about-its-users-nologs",
      "display_url" : "privacyinternational.org\/blog\/what-does\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "185045500519649280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0077536302, 8.2883882772 ]
  },
  "id_str" : "185046782756126721",
  "in_reply_to_user_id" : 3969351,
  "text" : "@Felicea spannend wird dann wieder der Import wenn man alle Daten bekommen hat: https:\/\/t.co\/NKPrxmwV",
  "id" : 185046782756126721,
  "in_reply_to_status_id" : 185045500519649280,
  "created_at" : "2012-03-28 16:52:45 +0000",
  "in_reply_to_screen_name" : "Felicea",
  "in_reply_to_user_id_str" : "3969351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mela Eckenfels",
      "screen_name" : "Felicea",
      "indices" : [ 0, 8 ],
      "id_str" : "3969351",
      "id" : 3969351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185045500519649280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0089246067, 8.2854285954 ]
  },
  "id_str" : "185046256807198720",
  "in_reply_to_user_id" : 3969351,
  "text" : "@Felicea aber eine Funktion um die zumindest schon mal lokal zu sichern schreibe ich mal nach dem Abendessen.",
  "id" : 185046256807198720,
  "in_reply_to_status_id" : 185045500519649280,
  "created_at" : "2012-03-28 16:50:40 +0000",
  "in_reply_to_screen_name" : "Felicea",
  "in_reply_to_user_id_str" : "3969351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mela Eckenfels",
      "screen_name" : "Felicea",
      "indices" : [ 0, 8 ],
      "id_str" : "3969351",
      "id" : 3969351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185045163092082688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0093599769, 8.2833372497 ]
  },
  "id_str" : "185045412695117824",
  "in_reply_to_user_id" : 3969351,
  "text" : "@Felicea das sollte kein Problem sein. Nur die will man vermutlich nicht offen visualisiert haben. ;)",
  "id" : 185045412695117824,
  "in_reply_to_status_id" : 185045163092082688,
  "created_at" : "2012-03-28 16:47:19 +0000",
  "in_reply_to_screen_name" : "Felicea",
  "in_reply_to_user_id_str" : "3969351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mela Eckenfels",
      "screen_name" : "Felicea",
      "indices" : [ 0, 8 ],
      "id_str" : "3969351",
      "id" : 3969351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185043127411806209",
  "geo" : { },
  "id_str" : "185045028987604993",
  "in_reply_to_user_id" : 3969351,
  "text" : "@Felicea bislang wird auch nur die eigene timeline (also eigene tweets & retweets die man selbst gemacht hat) gespeichert.",
  "id" : 185045028987604993,
  "in_reply_to_status_id" : 185043127411806209,
  "created_at" : "2012-03-28 16:45:47 +0000",
  "in_reply_to_screen_name" : "Felicea",
  "in_reply_to_user_id_str" : "3969351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mela Eckenfels",
      "screen_name" : "Felicea",
      "indices" : [ 0, 8 ],
      "id_str" : "3969351",
      "id" : 3969351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185043127411806209",
  "geo" : { },
  "id_str" : "185043203551006720",
  "in_reply_to_user_id" : 3969351,
  "text" : "@Felicea kein stress. ich mach das ja auch nur nebenbei als spielerei",
  "id" : 185043203551006720,
  "in_reply_to_status_id" : 185043127411806209,
  "created_at" : "2012-03-28 16:38:32 +0000",
  "in_reply_to_screen_name" : "Felicea",
  "in_reply_to_user_id_str" : "3969351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mela Eckenfels",
      "screen_name" : "Felicea",
      "indices" : [ 0, 8 ],
      "id_str" : "3969351",
      "id" : 3969351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185040277721989120",
  "geo" : { },
  "id_str" : "185043019492364289",
  "in_reply_to_user_id" : 3969351,
  "text" : "@Felicea wenn du noch ideen hast was da unbedingt nur dazu sollte nur zu. :)",
  "id" : 185043019492364289,
  "in_reply_to_status_id" : 185040277721989120,
  "created_at" : "2012-03-28 16:37:48 +0000",
  "in_reply_to_screen_name" : "Felicea",
  "in_reply_to_user_id_str" : "3969351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "indices" : [ 3, 18 ],
      "id_str" : "19416598",
      "id" : 19416598
    }, {
      "name" : "Larry Parnell",
      "screen_name" : "larry_parnell",
      "indices" : [ 25, 39 ],
      "id_str" : "87569989",
      "id" : 87569989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185042070396862464",
  "text" : "RT @leonidkruglyak: ! RT @larry_parnell: GWAS don't replicate? We've seen differences in results with R, SAS & other GWAS analysis softw ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Larry Parnell",
        "screen_name" : "larry_parnell",
        "indices" : [ 5, 19 ],
        "id_str" : "87569989",
        "id" : 87569989
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "185016512954904577",
    "text" : "! RT @larry_parnell: GWAS don't replicate? We've seen differences in results with R, SAS & other GWAS analysis software w same input data.",
    "id" : 185016512954904577,
    "created_at" : "2012-03-28 14:52:28 +0000",
    "user" : {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "protected" : false,
      "id_str" : "19416598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1095542276\/MyRecentPhoto_normal.jpg",
      "id" : 19416598,
      "verified" : false
    }
  },
  "id" : 185042070396862464,
  "created_at" : "2012-03-28 16:34:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/bPlFsxKB",
      "expanded_url" : "http:\/\/j.mp\/GXeiXC",
      "display_url" : "j.mp\/GXeiXC"
    } ]
  },
  "geo" : { },
  "id_str" : "185041511375835136",
  "text" : "Even a worthless gift can buy you sex. If you are a nursery web spider http:\/\/t.co\/bPlFsxKB",
  "id" : 185041511375835136,
  "created_at" : "2012-03-28 16:31:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/lOvPHzzA",
      "expanded_url" : "http:\/\/j.mp\/H01n4k",
      "display_url" : "j.mp\/H01n4k"
    } ]
  },
  "geo" : { },
  "id_str" : "185040552989949952",
  "text" : "Fool Time http:\/\/t.co\/lOvPHzzA",
  "id" : 185040552989949952,
  "created_at" : "2012-03-28 16:28:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mela Eckenfels",
      "screen_name" : "Felicea",
      "indices" : [ 0, 8 ],
      "id_str" : "3969351",
      "id" : 3969351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 45 ],
      "url" : "https:\/\/t.co\/gT06aytk",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/twitter_backup",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "185037154370600961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097504778, 8.283109805 ]
  },
  "id_str" : "185039801572003840",
  "in_reply_to_user_id" : 3969351,
  "text" : "@Felicea it already is: https:\/\/t.co\/gT06aytk Next thing should be a visualization of tweet-times.",
  "id" : 185039801572003840,
  "in_reply_to_status_id" : 185037154370600961,
  "created_at" : "2012-03-28 16:25:01 +0000",
  "in_reply_to_screen_name" : "Felicea",
  "in_reply_to_user_id_str" : "3969351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eberon",
      "screen_name" : "Eberon",
      "indices" : [ 3, 10 ],
      "id_str" : "14286532",
      "id" : 14286532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/9heJc5Av",
      "expanded_url" : "http:\/\/doycetesterman.com\/index.php\/2012\/03\/mass-effect-tolkein-and-your-bullshit-artistic-process\/",
      "display_url" : "doycetesterman.com\/index.php\/2012\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185036111956025344",
  "text" : "RT @Eberon: Das Problem mit dem ME3-Ende erkl\u00E4rt in HdR-Termini, f\u00FCr die, die Mass Effect nicht kennen: http:\/\/t.co\/9heJc5Av",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/9heJc5Av",
        "expanded_url" : "http:\/\/doycetesterman.com\/index.php\/2012\/03\/mass-effect-tolkein-and-your-bullshit-artistic-process\/",
        "display_url" : "doycetesterman.com\/index.php\/2012\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "185033752051847168",
    "text" : "Das Problem mit dem ME3-Ende erkl\u00E4rt in HdR-Termini, f\u00FCr die, die Mass Effect nicht kennen: http:\/\/t.co\/9heJc5Av",
    "id" : 185033752051847168,
    "created_at" : "2012-03-28 16:00:58 +0000",
    "user" : {
      "name" : "Eberon",
      "screen_name" : "Eberon",
      "protected" : false,
      "id_str" : "14286532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3362717429\/37087dcd60ed7107ee7c55e517417bcd_normal.jpeg",
      "id" : 14286532,
      "verified" : false
    }
  },
  "id" : 185036111956025344,
  "created_at" : "2012-03-28 16:10:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/pfaXwz8i",
      "expanded_url" : "http:\/\/j.mp\/GX4UHM",
      "display_url" : "j.mp\/GX4UHM"
    } ]
  },
  "geo" : { },
  "id_str" : "185028174437031936",
  "text" : "American scientists say: Pure evil causes birth defects http:\/\/t.co\/pfaXwz8i",
  "id" : 185028174437031936,
  "created_at" : "2012-03-28 15:38:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/P1vkTcNp",
      "expanded_url" : "http:\/\/phylomemetic-tree.de\/twitter\/",
      "display_url" : "phylomemetic-tree.de\/twitter\/"
    } ]
  },
  "geo" : { },
  "id_str" : "185027001386672128",
  "text" : "Still a bit shaky, but it looks like my tweet-archiving works http:\/\/t.co\/P1vkTcNp",
  "id" : 185027001386672128,
  "created_at" : "2012-03-28 15:34:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Gaiman",
      "screen_name" : "neilhimself",
      "indices" : [ 3, 15 ],
      "id_str" : "18393773",
      "id" : 18393773
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socool",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/aAvbmg05",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/uk-scotland-highlands-islands-17537147",
      "display_url" : "bbc.co.uk\/news\/uk-scotla\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185018788322873344",
  "text" : "RT @neilhimself: The earliest string instrument was found on Skye. http:\/\/t.co\/aAvbmg05 #socool",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "socool",
        "indices" : [ 71, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http:\/\/t.co\/aAvbmg05",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/uk-scotland-highlands-islands-17537147",
        "display_url" : "bbc.co.uk\/news\/uk-scotla\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "185016504570494978",
    "text" : "The earliest string instrument was found on Skye. http:\/\/t.co\/aAvbmg05 #socool",
    "id" : 185016504570494978,
    "created_at" : "2012-03-28 14:52:26 +0000",
    "user" : {
      "name" : "Neil Gaiman",
      "screen_name" : "neilhimself",
      "protected" : false,
      "id_str" : "18393773",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695563324444921856\/5kJZz_ha_normal.jpg",
      "id" : 18393773,
      "verified" : true
    }
  },
  "id" : 185018788322873344,
  "created_at" : "2012-03-28 15:01:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/MHluTYDj",
      "expanded_url" : "http:\/\/blog.openhelix.eu\/?p=11490&utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ResearchBloggingBiologyEnglish+%28Research+Blogging+-+English+-+Biology%29",
      "display_url" : "blog.openhelix.eu\/?p=11490&utm_s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185008550270074881",
  "text" : "Genomics and Infectious Disease http:\/\/t.co\/MHluTYDj",
  "id" : 185008550270074881,
  "created_at" : "2012-03-28 14:20:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/T9gnoNrs",
      "expanded_url" : "http:\/\/j.mp\/HekacT",
      "display_url" : "j.mp\/HekacT"
    } ]
  },
  "geo" : { },
  "id_str" : "185006358016425984",
  "text" : "Supreme Court orders appeals court to reconsider gene patents http:\/\/t.co\/T9gnoNrs",
  "id" : 185006358016425984,
  "created_at" : "2012-03-28 14:12:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/vtWKxT7C",
      "expanded_url" : "http:\/\/j.mp\/HejMLl",
      "display_url" : "j.mp\/HejMLl"
    } ]
  },
  "geo" : { },
  "id_str" : "185006037307375618",
  "text" : "On speciation: \u00ABAll we do is erect arbitrary lines on that spectrum to make our science easier to do\u00BB http:\/\/t.co\/vtWKxT7C",
  "id" : 185006037307375618,
  "created_at" : "2012-03-28 14:10:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185005530224406529",
  "text" : "Meh, Readability stopped working for the ResearchBlogging-feeds.",
  "id" : 185005530224406529,
  "created_at" : "2012-03-28 14:08:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184912857576644608",
  "geo" : { },
  "id_str" : "184912918343720960",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch Okay, no need to hurry on this. :)",
  "id" : 184912918343720960,
  "in_reply_to_status_id" : 184912857576644608,
  "created_at" : "2012-03-28 08:00:49 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184905806905487361",
  "geo" : { },
  "id_str" : "184906990919749632",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch e.g. I enter \"bar\" as the variation for phenotype \"foo\". The resque-job will look for genotypes of users with \"Foo\" and miss me",
  "id" : 184906990919749632,
  "in_reply_to_status_id" : 184905806905487361,
  "created_at" : "2012-03-28 07:37:16 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184905806905487361",
  "geo" : { },
  "id_str" : "184906781724647425",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch but as params[:variation] gets transformed through :downcase and :camelize this doesn't match the :variation in the database",
  "id" : 184906781724647425,
  "in_reply_to_status_id" : 184905806905487361,
  "created_at" : "2012-03-28 07:36:26 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184905806905487361",
  "geo" : { },
  "id_str" : "184906565478916096",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch and in the zipgenotyping-files the resque-job searches for all users who have entered params[:variation] at this phenotype.",
  "id" : 184906565478916096,
  "in_reply_to_status_id" : 184905806905487361,
  "created_at" : "2012-03-28 07:35:35 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184905806905487361",
  "geo" : { },
  "id_str" : "184906409194954752",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch this starts Resque.enqueue(Zipgenotypingfiles, params[:id], params[:variation], current_user.email)",
  "id" : 184906409194954752,
  "in_reply_to_status_id" : 184905806905487361,
  "created_at" : "2012-03-28 07:34:58 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184905806905487361",
  "geo" : { },
  "id_str" : "184906141015351296",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch on phenotype#show there is the list of \"known phenotypes\" with links to phenotype#get_genotypes",
  "id" : 184906141015351296,
  "in_reply_to_status_id" : 184905806905487361,
  "created_at" : "2012-03-28 07:33:54 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184899919407087616",
  "geo" : { },
  "id_str" : "184905306462097408",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch So the variation-parameter for get_genotypes does not longer fit the variation entered in the database.",
  "id" : 184905306462097408,
  "in_reply_to_status_id" : 184899919407087616,
  "created_at" : "2012-03-28 07:30:35 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184899919407087616",
  "geo" : { },
  "id_str" : "184904991851544578",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch I guess there might be a problem with getting zipped genotyping-files for a variation as you transform the known_phenotypes",
  "id" : 184904991851544578,
  "in_reply_to_status_id" : 184899919407087616,
  "created_at" : "2012-03-28 07:29:20 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/OP25LFfh",
      "expanded_url" : "http:\/\/j.mp\/GU7BnO",
      "display_url" : "j.mp\/GU7BnO"
    } ]
  },
  "geo" : { },
  "id_str" : "184901523694829568",
  "text" : "Der Neger ist verd\u00E4chtig http:\/\/t.co\/OP25LFfh",
  "id" : 184901523694829568,
  "created_at" : "2012-03-28 07:15:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184899919407087616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097475852, 8.2831481267 ]
  },
  "id_str" : "184900170864017409",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer sounds good! I'll also take a look at the changes in a minute :)",
  "id" : 184900170864017409,
  "in_reply_to_status_id" : 184899919407087616,
  "created_at" : "2012-03-28 07:10:10 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/7kwz2wiC",
      "expanded_url" : "http:\/\/j.mp\/GV3Ing",
      "display_url" : "j.mp\/GV3Ing"
    } ]
  },
  "geo" : { },
  "id_str" : "184899725944827905",
  "text" : "I just followed orders! http:\/\/t.co\/7kwz2wiC",
  "id" : 184899725944827905,
  "created_at" : "2012-03-28 07:08:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/nqXm3IoB",
      "expanded_url" : "http:\/\/j.mp\/GYE8b3",
      "display_url" : "j.mp\/GYE8b3"
    } ]
  },
  "geo" : { },
  "id_str" : "184898488994250752",
  "text" : "Militarizing Your Backyard with Python: Computer Vision and the Squirrel Hordes http:\/\/t.co\/nqXm3IoB",
  "id" : 184898488994250752,
  "created_at" : "2012-03-28 07:03:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/184736242590683137\/photo\/1",
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/myWZlNjf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ApBQokUCEAAMskc.png",
      "id_str" : "184736242594877440",
      "id" : 184736242594877440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ApBQokUCEAAMskc.png",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 1366
      } ],
      "display_url" : "pic.twitter.com\/myWZlNjf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184736242590683137",
  "text" : "Played around with self-archiving tweets. http:\/\/t.co\/myWZlNjf",
  "id" : 184736242590683137,
  "created_at" : "2012-03-27 20:18:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096626025, 8.2831211546 ]
  },
  "id_str" : "184604376495689728",
  "text" : "And a last test",
  "id" : 184604376495689728,
  "created_at" : "2012-03-27 11:34:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/UnMcNA05",
      "expanded_url" : "http:\/\/j.mp\/GTgWhD",
      "display_url" : "j.mp\/GTgWhD"
    } ]
  },
  "geo" : { },
  "id_str" : "184552327464759296",
  "text" : "Herman Cain's latest ad... http:\/\/t.co\/UnMcNA05",
  "id" : 184552327464759296,
  "created_at" : "2012-03-27 08:07:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/TguPgBPf",
      "expanded_url" : "http:\/\/j.mp\/GSljYr",
      "display_url" : "j.mp\/GSljYr"
    } ]
  },
  "geo" : { },
  "id_str" : "184550873416990720",
  "text" : "Wie gut das es die Kirche als moralischen Kompass gibt... http:\/\/t.co\/TguPgBPf",
  "id" : 184550873416990720,
  "created_at" : "2012-03-27 08:02:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184511284899885057",
  "geo" : { },
  "id_str" : "184544213478801409",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer making the variation case-insensitive could be a start. ;)",
  "id" : 184544213478801409,
  "in_reply_to_status_id" : 184511284899885057,
  "created_at" : "2012-03-27 07:35:43 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184496412522840064",
  "geo" : { },
  "id_str" : "184542926754418688",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer bei anderem Projekt versuche ich in den n\u00E4chsten Wochen mal verschiedene Phenotyp-Arten (Bool,int,kategorial)",
  "id" : 184542926754418688,
  "in_reply_to_status_id" : 184496412522840064,
  "created_at" : "2012-03-27 07:30:37 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184517671457521664",
  "geo" : { },
  "id_str" : "184529349632991233",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer this is really nice! Great job on this :)",
  "id" : 184529349632991233,
  "in_reply_to_status_id" : 184517671457521664,
  "created_at" : "2012-03-27 06:36:39 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184395204143497216",
  "text" : "Cool, an observant openSNP-user found a bug in the phenotyping-csv we deliver. We mixed chrom. sex and year of birth.",
  "id" : 184395204143497216,
  "created_at" : "2012-03-26 21:43:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 3, 14 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184350965653184512",
  "text" : "RT @openSNPorg: Plus we just released some features which should make it easier\/more fun to enter phenotypes. Includes recommendations!  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/2ouLrbWM",
        "expanded_url" : "http:\/\/opensnp.wordpress.com\/2012\/03\/26\/update-on-the-free-genotypings-and-new-features-on-opensnp\/",
        "display_url" : "opensnp.wordpress.com\/2012\/03\/26\/upd\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "184350905993396224",
    "text" : "Plus we just released some features which should make it easier\/more fun to enter phenotypes. Includes recommendations! http:\/\/t.co\/2ouLrbWM",
    "id" : 184350905993396224,
    "created_at" : "2012-03-26 18:47:35 +0000",
    "user" : {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "protected" : false,
      "id_str" : "380205172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735374825187909632\/wJEJW1zW_normal.jpg",
      "id" : 380205172,
      "verified" : false
    }
  },
  "id" : 184350965653184512,
  "created_at" : "2012-03-26 18:47:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 3, 14 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184350955075153921",
  "text" : "RT @openSNPorg: The deadline for the free genotypings has passed and over 400 people have applied. We're now going through all applications.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "184350677278015489",
    "text" : "The deadline for the free genotypings has passed and over 400 people have applied. We're now going through all applications.",
    "id" : 184350677278015489,
    "created_at" : "2012-03-26 18:46:41 +0000",
    "user" : {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "protected" : false,
      "id_str" : "380205172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735374825187909632\/wJEJW1zW_normal.jpg",
      "id" : 380205172,
      "verified" : false
    }
  },
  "id" : 184350955075153921,
  "created_at" : "2012-03-26 18:47:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/S7sd8Kie",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=4nzmS24F9K0&feature=related",
      "display_url" : "youtube.com\/watch?v=4nzmS2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "184311889059250177",
  "text" : "There is no god! http:\/\/t.co\/S7sd8Kie",
  "id" : 184311889059250177,
  "created_at" : "2012-03-26 16:12:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel SegalHamilton",
      "screen_name" : "rachsh",
      "indices" : [ 3, 10 ],
      "id_str" : "27978499",
      "id" : 27978499
    }, {
      "name" : "Ros Urwin",
      "screen_name" : "RosamundUrwin",
      "indices" : [ 24, 38 ],
      "id_str" : "91584999",
      "id" : 91584999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184310758274895873",
  "text" : "RT @rachsh: Spot on! MT @RosamundUrwin Received a letter calling me a moron for attacking homeopathy. Tempted to reply with this: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ros Urwin",
        "screen_name" : "RosamundUrwin",
        "indices" : [ 12, 26 ],
        "id_str" : "91584999",
        "id" : 91584999
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/mhRArcG5",
        "expanded_url" : "http:\/\/bit.ly\/EEhF5",
        "display_url" : "bit.ly\/EEhF5"
      } ]
    },
    "geo" : { },
    "id_str" : "184301521750601729",
    "text" : "Spot on! MT @RosamundUrwin Received a letter calling me a moron for attacking homeopathy. Tempted to reply with this: http:\/\/t.co\/mhRArcG5",
    "id" : 184301521750601729,
    "created_at" : "2012-03-26 15:31:21 +0000",
    "user" : {
      "name" : "Rachel SegalHamilton",
      "screen_name" : "rachsh",
      "protected" : false,
      "id_str" : "27978499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923514826827141122\/jZaP7Y1r_normal.jpg",
      "id" : 27978499,
      "verified" : false
    }
  },
  "id" : 184310758274895873,
  "created_at" : "2012-03-26 16:08:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/ZmbaaqAR",
      "expanded_url" : "http:\/\/j.mp\/GQPzDf",
      "display_url" : "j.mp\/GQPzDf"
    } ]
  },
  "geo" : { },
  "id_str" : "184280733156777984",
  "text" : "How Indie Labels Changed The World http:\/\/t.co\/ZmbaaqAR",
  "id" : 184280733156777984,
  "created_at" : "2012-03-26 14:08:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 56, 67 ],
      "id_str" : "3782931",
      "id" : 3782931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/Zkybk5V2",
      "expanded_url" : "http:\/\/j.mp\/GQVs5b",
      "display_url" : "j.mp\/GQVs5b"
    } ]
  },
  "geo" : { },
  "id_str" : "184270486665035778",
  "text" : "\u00DCber Sven Regener und die Urheberrechtsdebatte hat sich @spreeblick ausgelassen: Get the balance right http:\/\/t.co\/Zkybk5V2",
  "id" : 184270486665035778,
  "created_at" : "2012-03-26 13:28:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/3QaujLeV",
      "expanded_url" : "http:\/\/j.mp\/GSH4GB",
      "display_url" : "j.mp\/GSH4GB"
    } ]
  },
  "geo" : { },
  "id_str" : "184238747045466112",
  "text" : "Unicycling leads to new evolutionary psychology explanation for humor? http:\/\/t.co\/3QaujLeV",
  "id" : 184238747045466112,
  "created_at" : "2012-03-26 11:21:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/bpQJ1V1x",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=MGXSPf9b-xI&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=MGXSPf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "184219779446489088",
  "text" : "Abtreibung bis zum 14 Lebensjahr http:\/\/t.co\/bpQJ1V1x",
  "id" : 184219779446489088,
  "created_at" : "2012-03-26 10:06:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/SDpy6Bgj",
      "expanded_url" : "http:\/\/opensnp.org\/phenotypes\/3",
      "display_url" : "opensnp.org\/phenotypes\/3"
    } ]
  },
  "in_reply_to_status_id_str" : "184171787993624577",
  "geo" : { },
  "id_str" : "184172061927809025",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch Handedness. 7 verschiedene Variationen von Rechtsh\u00E4nder ohne Einschr\u00E4nkungen http:\/\/t.co\/SDpy6Bgj",
  "id" : 184172061927809025,
  "in_reply_to_status_id" : 184171787993624577,
  "created_at" : "2012-03-26 06:56:55 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184170827590287360",
  "geo" : { },
  "id_str" : "184171398648958976",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch F\u00FCr L\u00E4ngenangaben hast du recht. Aber sonst haben wir oft das Problem wo Autocomplete nicht reicht",
  "id" : 184171398648958976,
  "in_reply_to_status_id" : 184170827590287360,
  "created_at" : "2012-03-26 06:54:17 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183927891464159232",
  "geo" : { },
  "id_str" : "183936242407321601",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn I know. Trying my best :)",
  "id" : 183936242407321601,
  "in_reply_to_status_id" : 183927891464159232,
  "created_at" : "2012-03-25 15:19:52 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183925450656059392",
  "geo" : { },
  "id_str" : "183926841822806018",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn btw we got an okay for our talk at the republica ;)",
  "id" : 183926841822806018,
  "in_reply_to_status_id" : 183925450656059392,
  "created_at" : "2012-03-25 14:42:30 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183924601196257280",
  "geo" : { },
  "id_str" : "183925218111258624",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn does it work? :P",
  "id" : 183925218111258624,
  "in_reply_to_status_id" : 183924601196257280,
  "created_at" : "2012-03-25 14:36:03 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183868423950974976",
  "text" : "Animal Liberation gibt es also nicht als eBook. W\u00E4re doch mal was f\u00FCr Data Liberation...",
  "id" : 183868423950974976,
  "created_at" : "2012-03-25 10:50:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/183861432402710528\/photo\/1",
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/OjvwJYbS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ao00_6aCEAANTte.jpg",
      "id_str" : "183861432406904832",
      "id" : 183861432406904832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ao00_6aCEAANTte.jpg",
      "sizes" : [ {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/OjvwJYbS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095158024, 8.2827315945 ]
  },
  "id_str" : "183861432402710528",
  "text" : "Und jetzt: Veganes Fr\u00FChst\u00FCck http:\/\/t.co\/OjvwJYbS",
  "id" : 183861432402710528,
  "created_at" : "2012-03-25 10:22:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096909013, 8.2832263492 ]
  },
  "id_str" : "183860752438931456",
  "text" : "Finished \u00ABThe Omnivore's Dilemma\u00BB which is a great take on [fast|slow] food and food production in general.",
  "id" : 183860752438931456,
  "created_at" : "2012-03-25 10:19:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/2VNZKS88",
      "expanded_url" : "http:\/\/j.mp\/H4Hj39",
      "display_url" : "j.mp\/H4Hj39"
    } ]
  },
  "geo" : { },
  "id_str" : "183851735704547328",
  "text" : "Das Geisterschiff http:\/\/t.co\/2VNZKS88",
  "id" : 183851735704547328,
  "created_at" : "2012-03-25 09:44:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/rxGP5VXA",
      "expanded_url" : "http:\/\/j.mp\/GMKNXc",
      "display_url" : "j.mp\/GMKNXc"
    } ]
  },
  "geo" : { },
  "id_str" : "183850406445719553",
  "text" : "Turkish bootleg Star Wars figures of the 1980s http:\/\/t.co\/rxGP5VXA",
  "id" : 183850406445719553,
  "created_at" : "2012-03-25 09:38:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Leutert",
      "screen_name" : "pyth2_0",
      "indices" : [ 0, 8 ],
      "id_str" : "65875890",
      "id" : 65875890
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 18, 27 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183841481931489280",
  "geo" : { },
  "id_str" : "183842554314375168",
  "in_reply_to_user_id" : 65875890,
  "text" : "@pyth2_0 frag mal @Senficon",
  "id" : 183842554314375168,
  "in_reply_to_status_id" : 183841481931489280,
  "created_at" : "2012-03-25 09:07:35 +0000",
  "in_reply_to_screen_name" : "pyth2_0",
  "in_reply_to_user_id_str" : "65875890",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183702966694453248",
  "geo" : { },
  "id_str" : "183703229559865344",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer i'll try to get up early so should be fine for AUS-time ;)",
  "id" : 183703229559865344,
  "in_reply_to_status_id" : 183702966694453248,
  "created_at" : "2012-03-24 23:53:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183701645169926147",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009525274, 8.2830516994 ]
  },
  "id_str" : "183702524073754624",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer but first: Good night! :)",
  "id" : 183702524073754624,
  "in_reply_to_status_id" : 183701645169926147,
  "created_at" : "2012-03-24 23:51:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183701645169926147",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009868471, 8.283205675 ]
  },
  "id_str" : "183702156472369153",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, plus we are not selling our results as good as we could.I think we can do better. Maybe we can talk about this tomorrow.",
  "id" : 183702156472369153,
  "in_reply_to_status_id" : 183701645169926147,
  "created_at" : "2012-03-24 23:49:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183700731805708288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096737418, 8.2831567241 ]
  },
  "id_str" : "183701111901917185",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer great! I think the feedback is great. Definitely found some points which also felt but couldn't articulate.",
  "id" : 183701111901917185,
  "in_reply_to_status_id" : 183700731805708288,
  "created_at" : "2012-03-24 23:45:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183697932778868736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095927064, 8.2831278909 ]
  },
  "id_str" : "183700289877057536",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw: Agree on the paper, but need to get some sleep first. Oh: And try the latest commit, if it works for you we can go prod.",
  "id" : 183700289877057536,
  "in_reply_to_status_id" : 183697932778868736,
  "created_at" : "2012-03-24 23:42:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097194779, 8.283130008 ]
  },
  "id_str" : "183699928189644801",
  "text" : "Haha, love the chapters about mushroom hunting in \u00ABThe Omnivore's Dilemma\u00BB. It's so true!",
  "id" : 183699928189644801,
  "created_at" : "2012-03-24 23:40:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/vGw6YXrK",
      "expanded_url" : "http:\/\/instagr.am\/p\/IkAXkHBwjq\/",
      "display_url" : "instagr.am\/p\/IkAXkHBwjq\/"
    } ]
  },
  "geo" : { },
  "id_str" : "183597812070612993",
  "text" : "\u00ABSchau mal, die Crazy Cat Lady\u00BB \u2014 \u00ABWenn du das twitterst werfe ich mit Katzen nach dir!\u00BB http:\/\/t.co\/vGw6YXrK",
  "id" : 183597812070612993,
  "created_at" : "2012-03-24 16:55:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Without Borders",
      "screen_name" : "DataNoBorders",
      "indices" : [ 3, 17 ],
      "id_str" : "322814200",
      "id" : 322814200
    }, {
      "name" : "Dutiee",
      "screen_name" : "DutieeTweets",
      "indices" : [ 92, 105 ],
      "id_str" : "197589534",
      "id" : 197589534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183569139640696832",
  "text" : "RT @DataNoBorders: How Can A Data Scientist Create Massive Social Impact? We're featured on @DutieeTweets today! Check it out: http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dutiee",
        "screen_name" : "DutieeTweets",
        "indices" : [ 73, 86 ],
        "id_str" : "197589534",
        "id" : 197589534
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/B3N7xKR6",
        "expanded_url" : "http:\/\/dwb.cc\/H0rFpo",
        "display_url" : "dwb.cc\/H0rFpo"
      } ]
    },
    "geo" : { },
    "id_str" : "183567459507372033",
    "text" : "How Can A Data Scientist Create Massive Social Impact? We're featured on @DutieeTweets today! Check it out: http:\/\/t.co\/B3N7xKR6",
    "id" : 183567459507372033,
    "created_at" : "2012-03-24 14:54:27 +0000",
    "user" : {
      "name" : "Data Without Borders",
      "screen_name" : "DataNoBorders",
      "protected" : false,
      "id_str" : "322814200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1549386064\/2_DWB_phase2_Halfglobe_red_outline_normal.jpg",
      "id" : 322814200,
      "verified" : false
    }
  },
  "id" : 183569139640696832,
  "created_at" : "2012-03-24 15:01:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183559228500353025",
  "geo" : { },
  "id_str" : "183560362220720129",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye Dann dr\u00FCck ich auch mal die Daumen :)",
  "id" : 183560362220720129,
  "in_reply_to_status_id" : 183559228500353025,
  "created_at" : "2012-03-24 14:26:15 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/4ohyOPhX",
      "expanded_url" : "http:\/\/www.abstractfonts.com\/download\/10617",
      "display_url" : "abstractfonts.com\/download\/10617"
    } ]
  },
  "in_reply_to_status_id_str" : "183554830361567233",
  "geo" : { },
  "id_str" : "183558498515296257",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 Reicht der Download-Link? http:\/\/t.co\/4ohyOPhX",
  "id" : 183558498515296257,
  "in_reply_to_status_id" : 183554830361567233,
  "created_at" : "2012-03-24 14:18:51 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 50, 57 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183555581523673090",
  "text" : "42 und die #23, was kann da noch schief gehen bei @CaeVye?",
  "id" : 183555581523673090,
  "created_at" : "2012-03-24 14:07:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika",
      "screen_name" : "GreenSkyOverMe",
      "indices" : [ 0, 15 ],
      "id_str" : "345356127",
      "id" : 345356127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183541906188402689",
  "geo" : { },
  "id_str" : "183554645149483008",
  "in_reply_to_user_id" : 345356127,
  "text" : "@GreenSkyOverMe i&lt; Zombie l\u00E4uft nach rechts. &gt;i Zombie l\u00E4uft nach links ;)",
  "id" : 183554645149483008,
  "in_reply_to_status_id" : 183541906188402689,
  "created_at" : "2012-03-24 14:03:32 +0000",
  "in_reply_to_screen_name" : "GreenSkyOverMe",
  "in_reply_to_user_id_str" : "345356127",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183552154747940864",
  "text" : "Deleted broken SNPs and fixed the known phenotypes (turns out 255 chararacters aren't enough to save all the variation).",
  "id" : 183552154747940864,
  "created_at" : "2012-03-24 13:53:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika",
      "screen_name" : "GreenSkyOverMe",
      "indices" : [ 0, 15 ],
      "id_str" : "345356127",
      "id" : 345356127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183538542872502272",
  "geo" : { },
  "id_str" : "183538718446059520",
  "in_reply_to_user_id" : 345356127,
  "text" : "@GreenSkyOverMe Ja, aber daf\u00FCr ist das o dann zu weit in der Mitte find ich. Vielleicht so: 'o'",
  "id" : 183538718446059520,
  "in_reply_to_status_id" : 183538542872502272,
  "created_at" : "2012-03-24 13:00:15 +0000",
  "in_reply_to_screen_name" : "GreenSkyOverMe",
  "in_reply_to_user_id_str" : "345356127",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183535356312948736",
  "geo" : { },
  "id_str" : "183536567313375232",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ Ich dr\u00FCck dir die Daumen :)",
  "id" : 183536567313375232,
  "in_reply_to_status_id" : 183535356312948736,
  "created_at" : "2012-03-24 12:51:42 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Hoyt \u2661 PeerJ",
      "screen_name" : "jasonHoyt",
      "indices" : [ 0, 10 ],
      "id_str" : "16515488",
      "id" : 16515488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183533081775456257",
  "geo" : { },
  "id_str" : "183533251753803776",
  "in_reply_to_user_id" : 16515488,
  "text" : "@jasonHoyt Thanks. This is the prime example for \"people are willing to share very personal phenotypic variation\"",
  "id" : 183533251753803776,
  "in_reply_to_status_id" : 183533081775456257,
  "created_at" : "2012-03-24 12:38:31 +0000",
  "in_reply_to_screen_name" : "jasonHoyt",
  "in_reply_to_user_id_str" : "16515488",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Calkins",
      "screen_name" : "Mister_Robotics",
      "indices" : [ 3, 19 ],
      "id_str" : "14135993",
      "id" : 14135993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/WOmwQOQR",
      "expanded_url" : "http:\/\/m.jalopnik.com\/5895956\/im-batman-getting-pulled-over-in-a-lamborghini",
      "display_url" : "m.jalopnik.com\/5895956\/im-bat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "183528876075520001",
  "text" : "RT @Mister_Robotics: Ummm...  Batman got pulled over by the cops. http:\/\/t.co\/WOmwQOQR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/WOmwQOQR",
        "expanded_url" : "http:\/\/m.jalopnik.com\/5895956\/im-batman-getting-pulled-over-in-a-lamborghini",
        "display_url" : "m.jalopnik.com\/5895956\/im-bat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "183395535657508864",
    "text" : "Ummm...  Batman got pulled over by the cops. http:\/\/t.co\/WOmwQOQR",
    "id" : 183395535657508864,
    "created_at" : "2012-03-24 03:31:17 +0000",
    "user" : {
      "name" : "David Calkins",
      "screen_name" : "Mister_Robotics",
      "protected" : false,
      "id_str" : "14135993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448561478090498048\/yf_3Hs2S_normal.jpeg",
      "id" : 14135993,
      "verified" : false
    }
  },
  "id" : 183528876075520001,
  "created_at" : "2012-03-24 12:21:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183528290085126144",
  "geo" : { },
  "id_str" : "183528803329523714",
  "in_reply_to_user_id" : 131837207,
  "text" : "@rubasam Wir nutzen aber auch sowieso das metrische System. :P",
  "id" : 183528803329523714,
  "in_reply_to_status_id" : 183528290085126144,
  "created_at" : "2012-03-24 12:20:51 +0000",
  "in_reply_to_screen_name" : "n3rdmaedchen",
  "in_reply_to_user_id_str" : "131837207",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 0, 15 ],
      "id_str" : "73134122",
      "id" : 73134122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183527780892409856",
  "geo" : { },
  "id_str" : "183528102960439296",
  "in_reply_to_user_id" : 73134122,
  "text" : "@astefanowitsch nah, comparing the self-reported length with double blind measurements will get its own publication :P",
  "id" : 183528102960439296,
  "in_reply_to_status_id" : 183527780892409856,
  "created_at" : "2012-03-24 12:18:04 +0000",
  "in_reply_to_screen_name" : "astefanowitsch",
  "in_reply_to_user_id_str" : "73134122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183527594061348864",
  "text" : "Cool, the first user of openSNP has entered his penis length.",
  "id" : 183527594061348864,
  "created_at" : "2012-03-24 12:16:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183520738412736512",
  "geo" : { },
  "id_str" : "183522084197113857",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn No way :D",
  "id" : 183522084197113857,
  "in_reply_to_status_id" : 183520738412736512,
  "created_at" : "2012-03-24 11:54:09 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 34, 45 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 50, 63 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183518841878491137",
  "text" : "Finished first photo shooting for @openSNPorg \/cc @iameltonjohn",
  "id" : 183518841878491137,
  "created_at" : "2012-03-24 11:41:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/3vkiEKeU",
      "expanded_url" : "http:\/\/j.mp\/GMaQxu",
      "display_url" : "j.mp\/GMaQxu"
    } ]
  },
  "geo" : { },
  "id_str" : "183500926168993792",
  "text" : "Debatte \u00FCber NPD-Verbot: Triumph der Demokraten? http:\/\/t.co\/3vkiEKeU",
  "id" : 183500926168993792,
  "created_at" : "2012-03-24 10:30:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Mensch)))",
      "screen_name" : "entropie42",
      "indices" : [ 0, 11 ],
      "id_str" : "222440532",
      "id" : 222440532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183498611789807616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097536389, 8.2831860613 ]
  },
  "id_str" : "183499546897285120",
  "in_reply_to_user_id" : 222440532,
  "text" : "@entropie42 das ist ja schon der erste Fehler im System.",
  "id" : 183499546897285120,
  "in_reply_to_status_id" : 183498611789807616,
  "created_at" : "2012-03-24 10:24:35 +0000",
  "in_reply_to_screen_name" : "entropie42",
  "in_reply_to_user_id_str" : "222440532",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/BUFbdhYQ",
      "expanded_url" : "http:\/\/j.mp\/GL13ty",
      "display_url" : "j.mp\/GL13ty"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009762576, 8.2832131023 ]
  },
  "id_str" : "183497960263401472",
  "text" : "\u00ABSchulsystem spiegelt auch unsere Gesellschaft wider.Individualit\u00E4t wird bestraft, Gehorsam &amp; Mittelm\u00E4\u00DFigkeit belohnt.\u00BB http:\/\/t.co\/BUFbdhYQ",
  "id" : 183497960263401472,
  "created_at" : "2012-03-24 10:18:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/QslDwGCC",
      "expanded_url" : "http:\/\/j.mp\/GM6FAw",
      "display_url" : "j.mp\/GM6FAw"
    } ]
  },
  "geo" : { },
  "id_str" : "183485788682592256",
  "text" : "Phylogenetics and the sheep of \u00D6tzi http:\/\/t.co\/QslDwGCC",
  "id" : 183485788682592256,
  "created_at" : "2012-03-24 09:29:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tarzun",
      "screen_name" : "tarzun",
      "indices" : [ 0, 7 ],
      "id_str" : "1632280560",
      "id" : 1632280560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183480513917497345",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095308374, 8.2830622413 ]
  },
  "id_str" : "183484085602234368",
  "in_reply_to_user_id" : 45513907,
  "text" : "@tarzun aber die Streams bitte w\u00E4hrend der Wahl ausmachen ;)",
  "id" : 183484085602234368,
  "in_reply_to_status_id" : 183480513917497345,
  "created_at" : "2012-03-24 09:23:09 +0000",
  "in_reply_to_screen_name" : "klauspeukert",
  "in_reply_to_user_id_str" : "45513907",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/W2Wlfn5P",
      "expanded_url" : "http:\/\/j.mp\/GVgzBO",
      "display_url" : "j.mp\/GVgzBO"
    } ]
  },
  "geo" : { },
  "id_str" : "183483614636417024",
  "text" : "Why Magicians Are a Scientist\u2019s Best Friend http:\/\/t.co\/W2Wlfn5P",
  "id" : 183483614636417024,
  "created_at" : "2012-03-24 09:21:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/buEzYIPY",
      "expanded_url" : "http:\/\/j.mp\/GKVfk0",
      "display_url" : "j.mp\/GKVfk0"
    } ]
  },
  "geo" : { },
  "id_str" : "183482312179204096",
  "text" : "When scientists discuss grants http:\/\/t.co\/buEzYIPY",
  "id" : 183482312179204096,
  "created_at" : "2012-03-24 09:16:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Mulvany",
      "screen_name" : "IanMulvany",
      "indices" : [ 0, 11 ],
      "id_str" : "4339911",
      "id" : 4339911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183429417689817088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097456902, 8.2830543711 ]
  },
  "id_str" : "183476495983968256",
  "in_reply_to_user_id" : 4339911,
  "text" : "@IanMulvany you will have to wait some months before you can use this phrase again :)",
  "id" : 183476495983968256,
  "in_reply_to_status_id" : 183429417689817088,
  "created_at" : "2012-03-24 08:53:00 +0000",
  "in_reply_to_screen_name" : "IanMulvany",
  "in_reply_to_user_id_str" : "4339911",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/dXunOicu",
      "expanded_url" : "http:\/\/www.thespoof.co.uk\/news\/spoof.cfm?headline=s1i104953",
      "display_url" : "thespoof.co.uk\/news\/spoof.cfm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "183312585813274625",
  "text" : "Panic at Daily Mail as paper \"runs out of transgender stories\" http:\/\/t.co\/dXunOicu",
  "id" : 183312585813274625,
  "created_at" : "2012-03-23 22:01:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika",
      "screen_name" : "GreenSkyOverMe",
      "indices" : [ 0, 15 ],
      "id_str" : "345356127",
      "id" : 345356127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183310544260956161",
  "geo" : { },
  "id_str" : "183310835911888897",
  "in_reply_to_user_id" : 345356127,
  "text" : "@GreenSkyOverMe Die Arme gleichzeitig \u00FCber und unter dem Kopf? So verrenken sich ja meist nicht mal Zombies ;)",
  "id" : 183310835911888897,
  "in_reply_to_status_id" : 183310544260956161,
  "created_at" : "2012-03-23 21:54:43 +0000",
  "in_reply_to_screen_name" : "GreenSkyOverMe",
  "in_reply_to_user_id_str" : "345356127",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183306209527480320",
  "geo" : { },
  "id_str" : "183306561509261312",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye Der Vorteil ist also Reduktion der Zeit = (Gesamtaufwand\/Teilnehmer im Projekt) und nicht viel mehr",
  "id" : 183306561509261312,
  "in_reply_to_status_id" : 183306209527480320,
  "created_at" : "2012-03-23 21:37:44 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183306209527480320",
  "geo" : { },
  "id_str" : "183306446975410176",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye Das auch. Aber gerade bei OS sind imho 95% der Dinge die eine Person genauso hinbekommen h\u00E4tte bei l\u00E4ngerer Zeit.",
  "id" : 183306446975410176,
  "in_reply_to_status_id" : 183306209527480320,
  "created_at" : "2012-03-23 21:37:17 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Teach",
      "screen_name" : "schwarzbart",
      "indices" : [ 0, 12 ],
      "id_str" : "17088945",
      "id" : 17088945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183304400285077505",
  "geo" : { },
  "id_str" : "183304621517848576",
  "in_reply_to_user_id" : 17088945,
  "text" : "@schwarzbart Deshalb hat das imho nix mit \u00ABSchwarmintelligenz\u00BB zu tun. Sind ja eben nicht alles dumme Drohnen.",
  "id" : 183304621517848576,
  "in_reply_to_status_id" : 183304400285077505,
  "created_at" : "2012-03-23 21:30:02 +0000",
  "in_reply_to_screen_name" : "schwarzbart",
  "in_reply_to_user_id_str" : "17088945",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Teach",
      "screen_name" : "schwarzbart",
      "indices" : [ 0, 12 ],
      "id_str" : "17088945",
      "id" : 17088945
    }, {
      "name" : "Nick Haflinger",
      "screen_name" : "Nick_Haflinger",
      "indices" : [ 13, 28 ],
      "id_str" : "94528608",
      "id" : 94528608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183303187082657792",
  "geo" : { },
  "id_str" : "183303732291829760",
  "in_reply_to_user_id" : 17088945,
  "text" : "@schwarzbart @Nick_Haflinger OS ist ganz normales aufbauen auf bestehendem. Nur haben die Zyklen kurze Dauer.",
  "id" : 183303732291829760,
  "in_reply_to_status_id" : 183303187082657792,
  "created_at" : "2012-03-23 21:26:30 +0000",
  "in_reply_to_screen_name" : "schwarzbart",
  "in_reply_to_user_id_str" : "17088945",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183303243399565313",
  "text" : "\u00ABEA will come &amp; eat your 1st born &amp; do nasty things to you. But EA does that anyway even when you buy their software. They just call it DRM\u00BB",
  "id" : 183303243399565313,
  "created_at" : "2012-03-23 21:24:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Mulvany",
      "screen_name" : "IanMulvany",
      "indices" : [ 0, 11 ],
      "id_str" : "4339911",
      "id" : 4339911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183300173672349696",
  "geo" : { },
  "id_str" : "183300924750573568",
  "in_reply_to_user_id" : 4339911,
  "text" : "@IanMulvany You're taking learning German really seriously!",
  "id" : 183300924750573568,
  "in_reply_to_status_id" : 183300173672349696,
  "created_at" : "2012-03-23 21:15:20 +0000",
  "in_reply_to_screen_name" : "IanMulvany",
  "in_reply_to_user_id_str" : "4339911",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/op1AIVTK",
      "expanded_url" : "http:\/\/j.mp\/GV5dN8",
      "display_url" : "j.mp\/GV5dN8"
    } ]
  },
  "geo" : { },
  "id_str" : "183287385579192320",
  "text" : "Science says: To Beat Loneliness just become \"that crazy cat lady\" http:\/\/t.co\/op1AIVTK",
  "id" : 183287385579192320,
  "created_at" : "2012-03-23 20:21:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/MmJoJCRX",
      "expanded_url" : "http:\/\/j.mp\/GSRkP4",
      "display_url" : "j.mp\/GSRkP4"
    } ]
  },
  "geo" : { },
  "id_str" : "183285764744949761",
  "text" : "Also awesome: Historic photos of female scientists at work http:\/\/t.co\/MmJoJCRX",
  "id" : 183285764744949761,
  "created_at" : "2012-03-23 20:15:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/qTvoVK7z",
      "expanded_url" : "http:\/\/bit.ly\/GSrr3k",
      "display_url" : "bit.ly\/GSrr3k"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097564759, 8.2831489261 ]
  },
  "id_str" : "183284711009951744",
  "text" : "Evolution is awesome http:\/\/t.co\/qTvoVK7z",
  "id" : 183284711009951744,
  "created_at" : "2012-03-23 20:10:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika",
      "screen_name" : "GreenSkyOverMe",
      "indices" : [ 0, 15 ],
      "id_str" : "345356127",
      "id" : 345356127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183276362658889728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097483616, 8.2831262687 ]
  },
  "id_str" : "183280486662144000",
  "in_reply_to_user_id" : 345356127,
  "text" : "@GreenSkyOverMe oder einfach \\o\/ umdeuten.",
  "id" : 183280486662144000,
  "in_reply_to_status_id" : 183276362658889728,
  "created_at" : "2012-03-23 19:54:07 +0000",
  "in_reply_to_screen_name" : "GreenSkyOverMe",
  "in_reply_to_user_id_str" : "345356127",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 59, 67 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Ed Summers",
      "screen_name" : "edsu",
      "indices" : [ 68, 73 ],
      "id_str" : "14331818",
      "id" : 14331818
    }, {
      "name" : "Seb Chan",
      "screen_name" : "sebchan",
      "indices" : [ 74, 82 ],
      "id_str" : "14334974",
      "id" : 14334974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/v5YxK8pi",
      "expanded_url" : "http:\/\/bit.ly\/GJZmuP",
      "display_url" : "bit.ly\/GJZmuP"
    } ]
  },
  "geo" : { },
  "id_str" : "183244755168264192",
  "text" : "RT @wilbanks: On CC0 and USG works http:\/\/t.co\/v5YxK8pi cc @mbeisen @edsu @sebchan",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Eisen",
        "screen_name" : "mbeisen",
        "indices" : [ 45, 53 ],
        "id_str" : "19843630",
        "id" : 19843630
      }, {
        "name" : "Ed Summers",
        "screen_name" : "edsu",
        "indices" : [ 54, 59 ],
        "id_str" : "14331818",
        "id" : 14331818
      }, {
        "name" : "Seb Chan",
        "screen_name" : "sebchan",
        "indices" : [ 60, 68 ],
        "id_str" : "14334974",
        "id" : 14334974
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http:\/\/t.co\/v5YxK8pi",
        "expanded_url" : "http:\/\/bit.ly\/GJZmuP",
        "display_url" : "bit.ly\/GJZmuP"
      } ]
    },
    "geo" : { },
    "id_str" : "183243983198224384",
    "text" : "On CC0 and USG works http:\/\/t.co\/v5YxK8pi cc @mbeisen @edsu @sebchan",
    "id" : 183243983198224384,
    "created_at" : "2012-03-23 17:29:04 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 183244755168264192,
  "created_at" : "2012-03-23 17:32:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.flipboard.com\" rel=\"nofollow\"\u003EFlipboard\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/DweJUBpH",
      "expanded_url" : "http:\/\/www.nature.com\/nature\/journal\/v483\/n7390\/full\/483373b.html",
      "display_url" : "nature.com\/nature\/journal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "183242754225221632",
  "text" : "Experiments on non-human primates: As the campaign against animal research intensifies, so must the response: http:\/\/t.co\/DweJUBpH",
  "id" : 183242754225221632,
  "created_at" : "2012-03-23 17:24:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alios",
      "screen_name" : "alios",
      "indices" : [ 0, 6 ],
      "id_str" : "16309072",
      "id" : 16309072
    }, {
      "name" : "ds187",
      "screen_name" : "ds187",
      "indices" : [ 17, 23 ],
      "id_str" : "15895350",
      "id" : 15895350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183231679966609410",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097542201, 8.2831925409 ]
  },
  "id_str" : "183239692127436800",
  "in_reply_to_user_id" : 16309072,
  "text" : "@alios gr\u00FCss den @ds187 mal :)",
  "id" : 183239692127436800,
  "in_reply_to_status_id" : 183231679966609410,
  "created_at" : "2012-03-23 17:12:01 +0000",
  "in_reply_to_screen_name" : "alios",
  "in_reply_to_user_id_str" : "16309072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/VzmDBsda",
      "expanded_url" : "http:\/\/j.mp\/GRxsxa",
      "display_url" : "j.mp\/GRxsxa"
    } ]
  },
  "geo" : { },
  "id_str" : "183238932199247872",
  "text" : "California DoD bases sitting on 7 gigawatts of solar potential http:\/\/t.co\/VzmDBsda",
  "id" : 183238932199247872,
  "created_at" : "2012-03-23 17:09:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/Ousktu4L",
      "expanded_url" : "http:\/\/j.mp\/GUu1WK",
      "display_url" : "j.mp\/GUu1WK"
    } ]
  },
  "geo" : { },
  "id_str" : "183211142087327745",
  "text" : "Again: Is Google evil? http:\/\/t.co\/Ousktu4L",
  "id" : 183211142087327745,
  "created_at" : "2012-03-23 15:18:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobias Wolter",
      "screen_name" : "towo",
      "indices" : [ 0, 5 ],
      "id_str" : "14095571",
      "id" : 14095571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183209970773401604",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096675279, 8.283150652 ]
  },
  "id_str" : "183210136477777921",
  "in_reply_to_user_id" : 14095571,
  "text" : "@towo jo, f\u00FCr mich bleibt es aber bei einer Einreichung ;)",
  "id" : 183210136477777921,
  "in_reply_to_status_id" : 183209970773401604,
  "created_at" : "2012-03-23 15:14:35 +0000",
  "in_reply_to_screen_name" : "towo",
  "in_reply_to_user_id_str" : "14095571",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika",
      "screen_name" : "GreenSkyOverMe",
      "indices" : [ 0, 15 ],
      "id_str" : "345356127",
      "id" : 345356127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183208426405498880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096319756, 8.283086149 ]
  },
  "id_str" : "183209020419608579",
  "in_reply_to_user_id" : 345356127,
  "text" : "@GreenSkyOverMe und wie geht der Zombie-Smilie? :\u20AC",
  "id" : 183209020419608579,
  "in_reply_to_status_id" : 183208426405498880,
  "created_at" : "2012-03-23 15:10:08 +0000",
  "in_reply_to_screen_name" : "GreenSkyOverMe",
  "in_reply_to_user_id_str" : "345356127",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jlerwin",
      "screen_name" : "jlerwin",
      "indices" : [ 0, 8 ],
      "id_str" : "845676824935968772",
      "id" : 845676824935968772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183208070690775041",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009715698, 8.2831882798 ]
  },
  "id_str" : "183208834003767299",
  "in_reply_to_user_id" : 58101133,
  "text" : "@jlerwin it's a great story. Good luck with it!",
  "id" : 183208834003767299,
  "in_reply_to_status_id" : 183208070690775041,
  "created_at" : "2012-03-23 15:09:24 +0000",
  "in_reply_to_screen_name" : "prufrock451",
  "in_reply_to_user_id_str" : "58101133",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobias Wolter",
      "screen_name" : "towo",
      "indices" : [ 0, 5 ],
      "id_str" : "14095571",
      "id" : 14095571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183207381860233216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097115618, 8.2830132265 ]
  },
  "id_str" : "183207736140513280",
  "in_reply_to_user_id" : 14095571,
  "text" : "@towo jo, klingt sinnvoll ;)",
  "id" : 183207736140513280,
  "in_reply_to_status_id" : 183207381860233216,
  "created_at" : "2012-03-23 15:05:02 +0000",
  "in_reply_to_screen_name" : "towo",
  "in_reply_to_user_id_str" : "14095571",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika",
      "screen_name" : "GreenSkyOverMe",
      "indices" : [ 0, 15 ],
      "id_str" : "345356127",
      "id" : 345356127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183195242600742914",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097115618, 8.2830132265 ]
  },
  "id_str" : "183207707371778048",
  "in_reply_to_user_id" : 345356127,
  "text" : "@GreenSkyOverMe ich find die Eckz\u00E4hne sind schon mehr Vampir.",
  "id" : 183207707371778048,
  "in_reply_to_status_id" : 183195242600742914,
  "created_at" : "2012-03-23 15:04:55 +0000",
  "in_reply_to_screen_name" : "GreenSkyOverMe",
  "in_reply_to_user_id_str" : "345356127",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobias Wolter",
      "screen_name" : "towo",
      "indices" : [ 0, 5 ],
      "id_str" : "14095571",
      "id" : 14095571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183201613899505666",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097395283, 8.283137102 ]
  },
  "id_str" : "183206761371676672",
  "in_reply_to_user_id" : 14095571,
  "text" : "@towo fehlen euch noch Submissions? ;)",
  "id" : 183206761371676672,
  "in_reply_to_status_id" : 183201613899505666,
  "created_at" : "2012-03-23 15:01:10 +0000",
  "in_reply_to_screen_name" : "towo",
  "in_reply_to_user_id_str" : "14095571",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/Zh2VtG3c",
      "expanded_url" : "http:\/\/j.mp\/GFym1s",
      "display_url" : "j.mp\/GFym1s"
    } ]
  },
  "geo" : { },
  "id_str" : "183205630214025217",
  "text" : "How One Response to a Reddit Query Became a Big Budget Flick http:\/\/t.co\/Zh2VtG3c",
  "id" : 183205630214025217,
  "created_at" : "2012-03-23 14:56:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/PhrlY9iU",
      "expanded_url" : "http:\/\/j.mp\/GTzSKW",
      "display_url" : "j.mp\/GTzSKW"
    } ]
  },
  "geo" : { },
  "id_str" : "183200996506345472",
  "text" : "Are Walmart's Chinese Factories as Bad as Apple's? http:\/\/t.co\/PhrlY9iU",
  "id" : 183200996506345472,
  "created_at" : "2012-03-23 14:38:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 3, 10 ],
      "id_str" : "71654283",
      "id" : 71654283
    }, {
      "name" : "Cindy Gallop",
      "screen_name" : "cindygallop",
      "indices" : [ 15, 27 ],
      "id_str" : "8622212",
      "id" : 8622212
    }, {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 108, 114 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183198537591435264",
  "text" : "RT @arikia: MT @cindygallop: Will Katniss Everdeen prove to male VCs\/angels they must fund female founders? @wired thinks so http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cindy Gallop",
        "screen_name" : "cindygallop",
        "indices" : [ 3, 15 ],
        "id_str" : "8622212",
        "id" : 8622212
      }, {
        "name" : "WIRED",
        "screen_name" : "WIRED",
        "indices" : [ 96, 102 ],
        "id_str" : "1344951",
        "id" : 1344951
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/fsFnae15",
        "expanded_url" : "http:\/\/ow.ly\/9PWq7",
        "display_url" : "ow.ly\/9PWq7"
      } ]
    },
    "geo" : { },
    "id_str" : "183196037907890176",
    "text" : "MT @cindygallop: Will Katniss Everdeen prove to male VCs\/angels they must fund female founders? @wired thinks so http:\/\/t.co\/fsFnae15",
    "id" : 183196037907890176,
    "created_at" : "2012-03-23 14:18:33 +0000",
    "user" : {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "protected" : false,
      "id_str" : "71654283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897255084073025537\/5uB8YwJG_normal.jpg",
      "id" : 71654283,
      "verified" : false
    }
  },
  "id" : 183198537591435264,
  "created_at" : "2012-03-23 14:28:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/dQ7x7nT6",
      "expanded_url" : "http:\/\/instagr.am\/p\/IhIZWOhwrD\/",
      "display_url" : "instagr.am\/p\/IhIZWOhwrD\/"
    } ]
  },
  "geo" : { },
  "id_str" : "183193041622933504",
  "text" : "Vampire Cat http:\/\/t.co\/dQ7x7nT6",
  "id" : 183193041622933504,
  "created_at" : "2012-03-23 14:06:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team Mendeley",
      "screen_name" : "mendeley_com",
      "indices" : [ 10, 23 ],
      "id_str" : "15803034",
      "id" : 15803034
    }, {
      "name" : "Hojoki",
      "screen_name" : "hojoki",
      "indices" : [ 26, 33 ],
      "id_str" : "86628099",
      "id" : 86628099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/x6BeJVlU",
      "expanded_url" : "http:\/\/instagr.am\/p\/Ig9CqbhwoZ\/",
      "display_url" : "instagr.am\/p\/Ig9CqbhwoZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "183168597978394624",
  "text" : "Cool! The @mendeley_com \/ @hojoki Shirt arrived http:\/\/t.co\/x6BeJVlU",
  "id" : 183168597978394624,
  "created_at" : "2012-03-23 12:29:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/5ljG34lK",
      "expanded_url" : "http:\/\/j.mp\/GHjEWG",
      "display_url" : "j.mp\/GHjEWG"
    } ]
  },
  "geo" : { },
  "id_str" : "183162754503413762",
  "text" : "Brachiopoden sind schon sehr cool http:\/\/t.co\/5ljG34lK",
  "id" : 183162754503413762,
  "created_at" : "2012-03-23 12:06:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/cACvKwLj",
      "expanded_url" : "http:\/\/j.mp\/GNCyMe",
      "display_url" : "j.mp\/GNCyMe"
    } ]
  },
  "geo" : { },
  "id_str" : "183161333691318272",
  "text" : "Ebooks as envisioned 1935 http:\/\/t.co\/cACvKwLj",
  "id" : 183161333691318272,
  "created_at" : "2012-03-23 12:00:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suw",
      "screen_name" : "Suw",
      "indices" : [ 3, 7 ],
      "id_str" : "73843",
      "id" : 73843
    }, {
      "name" : "Charles Arthur",
      "screen_name" : "charlesarthur",
      "indices" : [ 117, 131 ],
      "id_str" : "5959342",
      "id" : 5959342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/iyoZgMAj",
      "expanded_url" : "http:\/\/bit.ly\/GJPtAk",
      "display_url" : "bit.ly\/GJPtAk"
    } ]
  },
  "geo" : { },
  "id_str" : "183148533283684352",
  "text" : "RT @Suw: Why aren't there more women in technology? Here are a few clues  http:\/\/t.co\/iyoZgMAj &lt; great piece from @charlesarthur",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\/mac\" rel=\"nofollow\"\u003EOsfoora for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charles Arthur",
        "screen_name" : "charlesarthur",
        "indices" : [ 108, 122 ],
        "id_str" : "5959342",
        "id" : 5959342
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/iyoZgMAj",
        "expanded_url" : "http:\/\/bit.ly\/GJPtAk",
        "display_url" : "bit.ly\/GJPtAk"
      } ]
    },
    "geo" : { },
    "id_str" : "183137326279565313",
    "text" : "Why aren't there more women in technology? Here are a few clues  http:\/\/t.co\/iyoZgMAj &lt; great piece from @charlesarthur",
    "id" : 183137326279565313,
    "created_at" : "2012-03-23 10:25:15 +0000",
    "user" : {
      "name" : "Suw",
      "screen_name" : "Suw",
      "protected" : false,
      "id_str" : "73843",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479378290437025793\/TmPvQOng_normal.jpeg",
      "id" : 73843,
      "verified" : false
    }
  },
  "id" : 183148533283684352,
  "created_at" : "2012-03-23 11:09:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097346115, 8.2832026511 ]
  },
  "id_str" : "182985231106707458",
  "text" : "\u00ABShame\u00BB, the feeling of actually having paid money to view this movie...",
  "id" : 182985231106707458,
  "created_at" : "2012-03-23 00:20:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "N J Clarke",
      "screen_name" : "compay",
      "indices" : [ 70, 77 ],
      "id_str" : "9793782",
      "id" : 9793782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/0dD78zho",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=b0Ti-gkJiXc",
      "display_url" : "youtube.com\/watch?v=b0Ti-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182871977432842240",
  "text" : "\u00ABHow To Tell People They Sound Racist\u00BB http:\/\/t.co\/0dD78zho \/Link via @compay",
  "id" : 182871977432842240,
  "created_at" : "2012-03-22 16:50:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 49, 62 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spackeria",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/sLfV8Uep",
      "expanded_url" : "http:\/\/n.pr\/GG6PKY",
      "display_url" : "n.pr\/GG6PKY"
    } ]
  },
  "geo" : { },
  "id_str" : "182809744170418176",
  "text" : "Consequences of Privacy Management #spackeria MT @MishaAngrist: Employers are requiring applicants 2 submit Facebook PW http:\/\/t.co\/sLfV8Uep",
  "id" : 182809744170418176,
  "created_at" : "2012-03-22 12:43:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/UTPQh8sZ",
      "expanded_url" : "http:\/\/kindle.amazon.com",
      "display_url" : "kindle.amazon.com"
    } ]
  },
  "in_reply_to_status_id_str" : "182793906608549888",
  "geo" : { },
  "id_str" : "182794255545274368",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Well, with http:\/\/t.co\/UTPQh8sZ they already have some basic functionality.",
  "id" : 182794255545274368,
  "in_reply_to_status_id" : 182793906608549888,
  "created_at" : "2012-03-22 11:42:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182793518337630208",
  "geo" : { },
  "id_str" : "182793642010886144",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Doesn't necessarily sync over the devices. Instead there could be an API.",
  "id" : 182793642010886144,
  "in_reply_to_status_id" : 182793518337630208,
  "created_at" : "2012-03-22 11:39:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182792100407025664",
  "geo" : { },
  "id_str" : "182793350884229121",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Meh, to much work. I'd like to buy a book at amazon and have it automagically in Goodreads",
  "id" : 182793350884229121,
  "in_reply_to_status_id" : 182792100407025664,
  "created_at" : "2012-03-22 11:38:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp12",
      "indices" : [ 65, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/EmJwlRRQ",
      "expanded_url" : "http:\/\/re-publica.de\/12\/sessions\/",
      "display_url" : "re-publica.de\/12\/sessions\/"
    } ]
  },
  "geo" : { },
  "id_str" : "182792053334351872",
  "text" : "Whoops, looks like Fabian and I got a slot about genetics at the #rp12 http:\/\/t.co\/EmJwlRRQ",
  "id" : 182792053334351872,
  "created_at" : "2012-03-22 11:33:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182789913635332096",
  "geo" : { },
  "id_str" : "182791827181666306",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Yeah, importing my books\/ratings etc. would be cool",
  "id" : 182791827181666306,
  "in_reply_to_status_id" : 182789913635332096,
  "created_at" : "2012-03-22 11:32:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182778483523588096",
  "geo" : { },
  "id_str" : "182788879936536576",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer A working import from Amazon Kindle would be cool",
  "id" : 182788879936536576,
  "in_reply_to_status_id" : 182778483523588096,
  "created_at" : "2012-03-22 11:20:39 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182744640368295936",
  "geo" : { },
  "id_str" : "182753324922191872",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch btw. I wont revert it as this isn't in production anyway. ;)",
  "id" : 182753324922191872,
  "in_reply_to_status_id" : 182744640368295936,
  "created_at" : "2012-03-22 08:59:22 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182750819052036096",
  "geo" : { },
  "id_str" : "182751737050959872",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch I just updated my editor to use two spaces instead of real tabs. :)",
  "id" : 182751737050959872,
  "in_reply_to_status_id" : 182750819052036096,
  "created_at" : "2012-03-22 08:53:04 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182744640368295936",
  "geo" : { },
  "id_str" : "182745195635412992",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch ah, ok. The radio buttons also only appear if there are already known variations.",
  "id" : 182745195635412992,
  "in_reply_to_status_id" : 182744640368295936,
  "created_at" : "2012-03-22 08:27:04 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182743700504461312",
  "geo" : { },
  "id_str" : "182744116994646017",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch this is strange. I've got the radio buttons &amp; the multiple headers in Firefox as well o_O",
  "id" : 182744116994646017,
  "in_reply_to_status_id" : 182743700504461312,
  "created_at" : "2012-03-22 08:22:47 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182742572681277440",
  "geo" : { },
  "id_str" : "182743015994040320",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch It isn't a problem of Chrome alone, Safari brings the same result.",
  "id" : 182743015994040320,
  "in_reply_to_status_id" : 182742572681277440,
  "created_at" : "2012-03-22 08:18:24 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182741594359861249",
  "geo" : { },
  "id_str" : "182742113610510336",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch I think this is my fault. After setting up my new machine I forgot to change the TextMate-settings to soft-tabs \/w 2 spaces",
  "id" : 182742113610510336,
  "in_reply_to_status_id" : 182741594359861249,
  "created_at" : "2012-03-22 08:14:49 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/182741141400207361\/photo\/1",
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/8N1rhDpC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aok6GZOCQAAae0f.png",
      "id_str" : "182741141408595968",
      "id" : 182741141408595968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aok6GZOCQAAae0f.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 1349
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 1349
      }, {
        "h" : 1012,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/8N1rhDpC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182516804676104192",
  "geo" : { },
  "id_str" : "182741141400207361",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch Your pull-request brings back the problem of multiple modal- headers http:\/\/t.co\/8N1rhDpC",
  "id" : 182741141400207361,
  "in_reply_to_status_id" : 182516804676104192,
  "created_at" : "2012-03-22 08:10:59 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciLogs",
      "screen_name" : "scilogs",
      "indices" : [ 0, 8 ],
      "id_str" : "14980634",
      "id" : 14980634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182727323676717056",
  "geo" : { },
  "id_str" : "182737647297507328",
  "in_reply_to_user_id" : 14980634,
  "text" : "@scilogs Liegt es auch an dem Webserver das LifeType nicht zwischenspeichert? ;)",
  "id" : 182737647297507328,
  "in_reply_to_status_id" : 182727323676717056,
  "created_at" : "2012-03-22 07:57:04 +0000",
  "in_reply_to_screen_name" : "scilogs",
  "in_reply_to_user_id_str" : "14980634",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 120, 131 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/jAs0AvDX",
      "expanded_url" : "http:\/\/thebloggess.com\/2012\/03\/excerpt-of-lets-pretend-this-never-happened-a-mostly-true-memoir\/",
      "display_url" : "thebloggess.com\/2012\/03\/excerp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182735662225698816",
  "text" : "RT @PhilippBayer: Hilarious excerpt from \"Let's Pretend This Never Happened\", adventures in HR http:\/\/t.co\/jAs0AvDX via @boingboing",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Boing Boing",
        "screen_name" : "BoingBoing",
        "indices" : [ 102, 113 ],
        "id_str" : "5971922",
        "id" : 5971922
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/jAs0AvDX",
        "expanded_url" : "http:\/\/thebloggess.com\/2012\/03\/excerpt-of-lets-pretend-this-never-happened-a-mostly-true-memoir\/",
        "display_url" : "thebloggess.com\/2012\/03\/excerp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "182696849713537024",
    "text" : "Hilarious excerpt from \"Let's Pretend This Never Happened\", adventures in HR http:\/\/t.co\/jAs0AvDX via @boingboing",
    "id" : 182696849713537024,
    "created_at" : "2012-03-22 05:14:57 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 182735662225698816,
  "created_at" : "2012-03-22 07:49:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Clancy",
      "screen_name" : "KateClancy",
      "indices" : [ 3, 14 ],
      "id_str" : "14729597",
      "id" : 14729597
    }, {
      "name" : "Rebecca \u201CI Demand 280-Character Usernames\u201D Watson",
      "screen_name" : "rebeccawatson",
      "indices" : [ 37, 51 ],
      "id_str" : "14188985",
      "id" : 14188985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/jPDiJDgC",
      "expanded_url" : "http:\/\/bit.ly\/GJ96rW",
      "display_url" : "bit.ly\/GJ96rW"
    } ]
  },
  "geo" : { },
  "id_str" : "182606569811361792",
  "text" : "RT @KateClancy: This is fantastic RT @rebeccawatson Calling out racism on Richard Dawkins' site: http:\/\/t.co\/jPDiJDgC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rebecca \u201CI Demand 280-Character Usernames\u201D Watson",
        "screen_name" : "rebeccawatson",
        "indices" : [ 21, 35 ],
        "id_str" : "14188985",
        "id" : 14188985
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/jPDiJDgC",
        "expanded_url" : "http:\/\/bit.ly\/GJ96rW",
        "display_url" : "bit.ly\/GJ96rW"
      } ]
    },
    "geo" : { },
    "id_str" : "182602121101844481",
    "text" : "This is fantastic RT @rebeccawatson Calling out racism on Richard Dawkins' site: http:\/\/t.co\/jPDiJDgC",
    "id" : 182602121101844481,
    "created_at" : "2012-03-21 22:58:32 +0000",
    "user" : {
      "name" : "Kate Clancy",
      "screen_name" : "KateClancy",
      "protected" : false,
      "id_str" : "14729597",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/827538287191527424\/BClQOCKV_normal.jpg",
      "id" : 14729597,
      "verified" : false
    }
  },
  "id" : 182606569811361792,
  "created_at" : "2012-03-21 23:16:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/KzrE2TPy",
      "expanded_url" : "http:\/\/www.alternet.org\/visions\/154518\/why_we_have_to_go_back_to_a_40-hour_work_week_to_keep_our_sanity\/?page=entire",
      "display_url" : "alternet.org\/visions\/154518\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182595598388695042",
  "text" : "\u00ABYou can stay longer if your boss asks; but after six hours, all he's really got left is a butt in a chair\u00BB http:\/\/t.co\/KzrE2TPy",
  "id" : 182595598388695042,
  "created_at" : "2012-03-21 22:32:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/erqRtqKT",
      "expanded_url" : "http:\/\/j.mp\/GBbjYa",
      "display_url" : "j.mp\/GBbjYa"
    } ]
  },
  "geo" : { },
  "id_str" : "182592724925562880",
  "text" : "\u00ABI do not feel that it is reactionary\/inaccurate to describe an unwanted,non-indicated transvaginal ultrasound as rape\u00BB http:\/\/t.co\/erqRtqKT",
  "id" : 182592724925562880,
  "created_at" : "2012-03-21 22:21:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/9wcxBdSW",
      "expanded_url" : "http:\/\/j.mp\/GEBagx",
      "display_url" : "j.mp\/GEBagx"
    } ]
  },
  "geo" : { },
  "id_str" : "182582696587968512",
  "text" : "Most useless scientific calculator ever. But done in Minecraft http:\/\/t.co\/9wcxBdSW",
  "id" : 182582696587968512,
  "created_at" : "2012-03-21 21:41:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182565272585117696",
  "text" : "Am Kiosk tats\u00E4chlich ein Magazin mit \u00ABHom\u00F6opathie f\u00FCr Hunde\u00BB auf dem Cover gesehen...",
  "id" : 182565272585117696,
  "created_at" : "2012-03-21 20:32:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/lXWPStNu",
      "expanded_url" : "http:\/\/www.collegehumor.com\/video\/6743777\/the-hunger-games-game",
      "display_url" : "collegehumor.com\/video\/6743777\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182556895909908482",
  "text" : "The Hunger Games-Game http:\/\/t.co\/lXWPStNu",
  "id" : 182556895909908482,
  "created_at" : "2012-03-21 19:58:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/Dt3o3Okm",
      "expanded_url" : "http:\/\/www.sciencecodex.com\/bioethicists_contribute_to_consensus_opinion_on_the_responsibility_of_biobanks-88256",
      "display_url" : "sciencecodex.com\/bioethicists_c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182552956623790081",
  "text" : "Biobanks and incidental findings http:\/\/t.co\/Dt3o3Okm",
  "id" : 182552956623790081,
  "created_at" : "2012-03-21 19:43:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182511482246934528",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch there were some bugs with the display as all modals got the same ID, but I've fixed it. Will push extend modal soon",
  "id" : 182511482246934528,
  "created_at" : "2012-03-21 16:58:22 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182511152843067393",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch great job on the modal, although my educated guess is that only tested it with one phenotype entered :D",
  "id" : 182511152843067393,
  "created_at" : "2012-03-21 16:57:04 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Horak",
      "screen_name" : "fatmike182",
      "indices" : [ 0, 11 ],
      "id_str" : "15271509",
      "id" : 15271509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182502980841521152",
  "geo" : { },
  "id_str" : "182503168997982210",
  "in_reply_to_user_id" : 15271509,
  "text" : "@fatmike182 andererseits weiss man das meist auch er hinterher. Das Geld f\u00FCrs HGP war ja auch nicht zum Fenster rausgeworfen.",
  "id" : 182503168997982210,
  "in_reply_to_status_id" : 182502980841521152,
  "created_at" : "2012-03-21 16:25:20 +0000",
  "in_reply_to_screen_name" : "fatmike182",
  "in_reply_to_user_id_str" : "15271509",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Horak",
      "screen_name" : "fatmike182",
      "indices" : [ 0, 11 ],
      "id_str" : "15271509",
      "id" : 15271509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182497545115795457",
  "geo" : { },
  "id_str" : "182502778772520960",
  "in_reply_to_user_id" : 15271509,
  "text" : "@fatmike182 Joah, das ist wirklich nicht so viel Geld. Ich kann nur leider nicht so richtig einsch\u00E4tzen was man nachher damit machen kann.",
  "id" : 182502778772520960,
  "in_reply_to_status_id" : 182497545115795457,
  "created_at" : "2012-03-21 16:23:47 +0000",
  "in_reply_to_screen_name" : "fatmike182",
  "in_reply_to_user_id_str" : "15271509",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/FdKbbaV4",
      "expanded_url" : "http:\/\/j.mp\/GDtc5M",
      "display_url" : "j.mp\/GDtc5M"
    } ]
  },
  "geo" : { },
  "id_str" : "182485673268346880",
  "text" : "UK governments split over badger culling http:\/\/t.co\/FdKbbaV4",
  "id" : 182485673268346880,
  "created_at" : "2012-03-21 15:15:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/7JRyhD2H",
      "expanded_url" : "http:\/\/j.mp\/GEdHfn",
      "display_url" : "j.mp\/GEdHfn"
    } ]
  },
  "geo" : { },
  "id_str" : "182485245965250560",
  "text" : "Spatial Structure and evolutionary games http:\/\/t.co\/7JRyhD2H",
  "id" : 182485245965250560,
  "created_at" : "2012-03-21 15:14:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Yam",
      "screen_name" : "philipyam",
      "indices" : [ 3, 13 ],
      "id_str" : "26074603",
      "id" : 26074603
    }, {
      "name" : "(((John Rennie)))",
      "screen_name" : "tvjrennie",
      "indices" : [ 85, 95 ],
      "id_str" : "48564118",
      "id" : 48564118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182464714981384194",
  "text" : "RT @philipyam: You kill a Neandertal, H. erectus, dolphin, chimp, 8 sentient robots, @tvjrennie's neighbor. How many were murders? http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "(((John Rennie)))",
        "screen_name" : "tvjrennie",
        "indices" : [ 70, 80 ],
        "id_str" : "48564118",
        "id" : 48564118
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/bAQjqu0Y",
        "expanded_url" : "http:\/\/smrt.io\/GCB9vS",
        "display_url" : "smrt.io\/GCB9vS"
      } ]
    },
    "geo" : { },
    "id_str" : "182171903597879296",
    "text" : "You kill a Neandertal, H. erectus, dolphin, chimp, 8 sentient robots, @tvjrennie's neighbor. How many were murders? http:\/\/t.co\/bAQjqu0Y",
    "id" : 182171903597879296,
    "created_at" : "2012-03-20 18:29:01 +0000",
    "user" : {
      "name" : "Philip Yam",
      "screen_name" : "philipyam",
      "protected" : false,
      "id_str" : "26074603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416365611623526401\/GK6WJVmt_normal.jpeg",
      "id" : 26074603,
      "verified" : true
    }
  },
  "id" : 182464714981384194,
  "created_at" : "2012-03-21 13:52:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "N J Clarke",
      "screen_name" : "compay",
      "indices" : [ 3, 10 ],
      "id_str" : "9793782",
      "id" : 9793782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182450841788231681",
  "text" : "RT @compay: What's more depressing, the sexism, the non-apology apology, or the idiots commenting on HN who don't see what's wrong? http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/Og72UorY",
        "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=3731229",
        "display_url" : "news.ycombinator.com\/item?id=3731229"
      } ]
    },
    "geo" : { },
    "id_str" : "182447600337825792",
    "text" : "What's more depressing, the sexism, the non-apology apology, or the idiots commenting on HN who don't see what's wrong? http:\/\/t.co\/Og72UorY",
    "id" : 182447600337825792,
    "created_at" : "2012-03-21 12:44:32 +0000",
    "user" : {
      "name" : "N J Clarke",
      "screen_name" : "compay",
      "protected" : false,
      "id_str" : "9793782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732946305694195712\/k30ZKmto_normal.jpg",
      "id" : 9793782,
      "verified" : false
    }
  },
  "id" : 182450841788231681,
  "created_at" : "2012-03-21 12:57:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arndt Gro\u00DFmann",
      "screen_name" : "g1zu",
      "indices" : [ 0, 5 ],
      "id_str" : "484276999",
      "id" : 484276999
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 6, 11 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182434497873186816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1026303504, 8.5431328059 ]
  },
  "id_str" : "182435042281271296",
  "in_reply_to_user_id" : 484276999,
  "text" : "@g1zu @li5a okay f\u00FCr mich",
  "id" : 182435042281271296,
  "in_reply_to_status_id" : 182434497873186816,
  "created_at" : "2012-03-21 11:54:38 +0000",
  "in_reply_to_screen_name" : "g1zu",
  "in_reply_to_user_id_str" : "484276999",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/hlm9f5Sn",
      "expanded_url" : "http:\/\/j.mp\/GGGlNs",
      "display_url" : "j.mp\/GGGlNs"
    } ]
  },
  "geo" : { },
  "id_str" : "182433300399390720",
  "text" : "The Stanford Education Experiment Could Change Higher Learning Forever http:\/\/t.co\/hlm9f5Sn",
  "id" : 182433300399390720,
  "created_at" : "2012-03-21 11:47:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/KQFnwCuT",
      "expanded_url" : "http:\/\/j.mp\/GGnWLz",
      "display_url" : "j.mp\/GGnWLz"
    } ]
  },
  "geo" : { },
  "id_str" : "182431961657257984",
  "text" : "Small sample sizes in neuroimaging and the consequences http:\/\/t.co\/KQFnwCuT",
  "id" : 182431961657257984,
  "created_at" : "2012-03-21 11:42:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/LncBo9G3",
      "expanded_url" : "http:\/\/j.mp\/GCOza5",
      "display_url" : "j.mp\/GCOza5"
    } ]
  },
  "geo" : { },
  "id_str" : "182430174493671426",
  "text" : "Wooden skyscrapers: efficient, fire-safe, environmentally friendly(ier) http:\/\/t.co\/LncBo9G3",
  "id" : 182430174493671426,
  "created_at" : "2012-03-21 11:35:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182257644784979969",
  "geo" : { },
  "id_str" : "182416173890146305",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Did they download the influenza genome-fasta? :P",
  "id" : 182416173890146305,
  "in_reply_to_status_id" : 182257644784979969,
  "created_at" : "2012-03-21 10:39:39 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 3, 13 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/juoFcA1e",
      "expanded_url" : "http:\/\/szmstat.sueddeutsche.de\/texte\/anzeigen\/37123\/2\/1",
      "display_url" : "szmstat.sueddeutsche.de\/texte\/anzeigen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182410904313397248",
  "text" : "RT @fragmente: \"Jetzt reden Sie \u00FCber Beziehungen, das ist ein wesentlich komplexeres Thema als Sexsuche im Internet.\" http:\/\/t.co\/juoFcA1e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/juoFcA1e",
        "expanded_url" : "http:\/\/szmstat.sueddeutsche.de\/texte\/anzeigen\/37123\/2\/1",
        "display_url" : "szmstat.sueddeutsche.de\/texte\/anzeigen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "182410411218444293",
    "text" : "\"Jetzt reden Sie \u00FCber Beziehungen, das ist ein wesentlich komplexeres Thema als Sexsuche im Internet.\" http:\/\/t.co\/juoFcA1e",
    "id" : 182410411218444293,
    "created_at" : "2012-03-21 10:16:45 +0000",
    "user" : {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "protected" : false,
      "id_str" : "7207642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696457425277317120\/emEVfsV-_normal.jpg",
      "id" : 7207642,
      "verified" : false
    }
  },
  "id" : 182410904313397248,
  "created_at" : "2012-03-21 10:18:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097216208, 8.2832093639 ]
  },
  "id_str" : "182235100543598592",
  "text" : "Was ich mir seit Wochen sage: \u00ABUnd morgen reiche ich dann auch wirklich mal was f\u00FCr die SIGINT ein.\u00BB",
  "id" : 182235100543598592,
  "created_at" : "2012-03-20 22:40:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathaniel Reindl",
      "screen_name" : "nrr",
      "indices" : [ 3, 7 ],
      "id_str" : "14498961",
      "id" : 14498961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 54 ],
      "url" : "https:\/\/t.co\/lZckpcV3",
      "expanded_url" : "https:\/\/img.skitch.com\/20120320-fmsc5mciy8e7n3nxhakmegxxg9.png",
      "display_url" : "img.skitch.com\/20120320-fmsc5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182215993999888384",
  "text" : "RT @nrr: I weep for my industry. https:\/\/t.co\/lZckpcV3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 45 ],
        "url" : "https:\/\/t.co\/lZckpcV3",
        "expanded_url" : "https:\/\/img.skitch.com\/20120320-fmsc5mciy8e7n3nxhakmegxxg9.png",
        "display_url" : "img.skitch.com\/20120320-fmsc5\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "182195826955788291",
    "text" : "I weep for my industry. https:\/\/t.co\/lZckpcV3",
    "id" : 182195826955788291,
    "created_at" : "2012-03-20 20:04:04 +0000",
    "user" : {
      "name" : "Nathaniel Reindl",
      "screen_name" : "nrr",
      "protected" : false,
      "id_str" : "14498961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905902837405696000\/kATa6RHQ_normal.jpg",
      "id" : 14498961,
      "verified" : false
    }
  },
  "id" : 182215993999888384,
  "created_at" : "2012-03-20 21:24:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Clancy",
      "screen_name" : "KateClancy",
      "indices" : [ 3, 14 ],
      "id_str" : "14729597",
      "id" : 14729597
    }, {
      "name" : "Joanne Manaster",
      "screen_name" : "sciencegoddess",
      "indices" : [ 23, 38 ],
      "id_str" : "15484063",
      "id" : 15484063
    }, {
      "name" : "LIFE Corporation",
      "screen_name" : "LIFEcorporation",
      "indices" : [ 113, 129 ],
      "id_str" : "2767015705",
      "id" : 2767015705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182186972503212032",
  "text" : "RT @KateClancy: Heh RT @sciencegoddess: How long have you been pipetting? Know the warning signs of science. via @LIFEcorporation http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joanne Manaster",
        "screen_name" : "sciencegoddess",
        "indices" : [ 7, 22 ],
        "id_str" : "15484063",
        "id" : 15484063
      }, {
        "name" : "LIFE Corporation",
        "screen_name" : "LIFEcorporation",
        "indices" : [ 97, 113 ],
        "id_str" : "2767015705",
        "id" : 2767015705
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/vG36owcA",
        "expanded_url" : "http:\/\/twitpic.com\/8z1bin",
        "display_url" : "twitpic.com\/8z1bin"
      } ]
    },
    "geo" : { },
    "id_str" : "182186692889948160",
    "text" : "Heh RT @sciencegoddess: How long have you been pipetting? Know the warning signs of science. via @LIFEcorporation http:\/\/t.co\/vG36owcA",
    "id" : 182186692889948160,
    "created_at" : "2012-03-20 19:27:47 +0000",
    "user" : {
      "name" : "Kate Clancy",
      "screen_name" : "KateClancy",
      "protected" : false,
      "id_str" : "14729597",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/827538287191527424\/BClQOCKV_normal.jpg",
      "id" : 14729597,
      "verified" : false
    }
  },
  "id" : 182186972503212032,
  "created_at" : "2012-03-20 19:28:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/QLAK5O5O",
      "expanded_url" : "http:\/\/j.mp\/GD7vTX",
      "display_url" : "j.mp\/GD7vTX"
    } ]
  },
  "geo" : { },
  "id_str" : "182107768206008320",
  "text" : "\u00ABChemical purity is held up as a sacred shield against future environmental cataclysm &amp; failures of personal health\u00BB http:\/\/t.co\/QLAK5O5O",
  "id" : 182107768206008320,
  "created_at" : "2012-03-20 14:14:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fasel",
      "screen_name" : "fasel",
      "indices" : [ 3, 9 ],
      "id_str" : "21739255",
      "id" : 21739255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/OurfBheu",
      "expanded_url" : "http:\/\/bit.ly\/GCuX34",
      "display_url" : "bit.ly\/GCuX34"
    } ]
  },
  "geo" : { },
  "id_str" : "182103480197058560",
  "text" : "RT @fasel: Sexualit\u00E4t: So. Und nicht anders | ZEIT ONLINE http:\/\/t.co\/OurfBheu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/OurfBheu",
        "expanded_url" : "http:\/\/bit.ly\/GCuX34",
        "display_url" : "bit.ly\/GCuX34"
      } ]
    },
    "geo" : { },
    "id_str" : "182101513160765440",
    "text" : "Sexualit\u00E4t: So. Und nicht anders | ZEIT ONLINE http:\/\/t.co\/OurfBheu",
    "id" : 182101513160765440,
    "created_at" : "2012-03-20 13:49:18 +0000",
    "user" : {
      "name" : "fasel",
      "screen_name" : "fasel",
      "protected" : false,
      "id_str" : "21739255",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/184361247\/hitchhikers_normal.jpg",
      "id" : 21739255,
      "verified" : false
    }
  },
  "id" : 182103480197058560,
  "created_at" : "2012-03-20 13:57:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/7tofMZXL",
      "expanded_url" : "http:\/\/j.mp\/GB948k",
      "display_url" : "j.mp\/GB948k"
    } ]
  },
  "geo" : { },
  "id_str" : "182075765867814913",
  "text" : "Bionic Limbs http:\/\/t.co\/7tofMZXL",
  "id" : 182075765867814913,
  "created_at" : "2012-03-20 12:07:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Horak",
      "screen_name" : "fatmike182",
      "indices" : [ 3, 14 ],
      "id_str" : "15271509",
      "id" : 15271509
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Banksy",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/S8OJ4pEw",
      "expanded_url" : "http:\/\/182.fm\/GAtk9L",
      "display_url" : "182.fm\/GAtk9L"
    } ]
  },
  "geo" : { },
  "id_str" : "182048270586089472",
  "text" : "RT @fatmike182: Richtigstellung: #Banksy hat nicht plagiiert sondern nur schlampig zitiert http:\/\/t.co\/S8OJ4pEw #GoodArtistsCopyGreatArt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Banksy",
        "indices" : [ 17, 24 ]
      }, {
        "text" : "GoodArtistsCopyGreatArtistsSteal",
        "indices" : [ 96, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/S8OJ4pEw",
        "expanded_url" : "http:\/\/182.fm\/GAtk9L",
        "display_url" : "182.fm\/GAtk9L"
      } ]
    },
    "geo" : { },
    "id_str" : "182047114560413696",
    "text" : "Richtigstellung: #Banksy hat nicht plagiiert sondern nur schlampig zitiert http:\/\/t.co\/S8OJ4pEw #GoodArtistsCopyGreatArtistsSteal",
    "id" : 182047114560413696,
    "created_at" : "2012-03-20 10:13:09 +0000",
    "user" : {
      "name" : "Michael Horak",
      "screen_name" : "fatmike182",
      "protected" : false,
      "id_str" : "15271509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1525008256\/avatar_norm_normal.png",
      "id" : 15271509,
      "verified" : false
    }
  },
  "id" : 182048270586089472,
  "created_at" : "2012-03-20 10:17:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "das gute A.",
      "screen_name" : "klinkhart",
      "indices" : [ 0, 10 ],
      "id_str" : "21249264",
      "id" : 21249264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182039002881339392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096987973, 8.2832307298 ]
  },
  "id_str" : "182040364385959938",
  "in_reply_to_user_id" : 21249264,
  "text" : "@klinkhart genau darum geht es ja: MaleConnector von Lego mit dem female-counterpart von Fisherprice verbinden. ;)",
  "id" : 182040364385959938,
  "in_reply_to_status_id" : 182039002881339392,
  "created_at" : "2012-03-20 09:46:19 +0000",
  "in_reply_to_screen_name" : "klinkhart",
  "in_reply_to_user_id_str" : "21249264",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182038793354878976",
  "text" : "RT @edyong209: If you really need to puncture someone's airway with a pen, the BIC soft feel Jumbo is the brand of choice http:\/\/t.co\/fg ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/fgwto6Nl",
        "expanded_url" : "http:\/\/blogs.discovermagazine.com\/discoblog\/2012\/03\/19\/ncbi-rofl-which-brand-of-ball-point-pen-is-best-for-an-emergency-airway-puncture\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+DiscoverDiscoblog+%28Discoblog%29&utm_content=Google+Reader",
        "display_url" : "blogs.discovermagazine.com\/discoblog\/2012\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "182026503641513984",
    "text" : "If you really need to puncture someone's airway with a pen, the BIC soft feel Jumbo is the brand of choice http:\/\/t.co\/fgwto6Nl",
    "id" : 182026503641513984,
    "created_at" : "2012-03-20 08:51:15 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 182038793354878976,
  "created_at" : "2012-03-20 09:40:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loudmouthman",
      "screen_name" : "loudmouthman",
      "indices" : [ 3, 16 ],
      "id_str" : "877781",
      "id" : 877781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/yHizlXzK",
      "expanded_url" : "http:\/\/www.shoeboxblog.com\/wp-content\/uploads\/2008\/12\/rocket-punch-500x495.jpg",
      "display_url" : "shoeboxblog.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182038290508156929",
  "text" : "RT @loudmouthman: Never be too young  http:\/\/t.co\/yHizlXzK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 40 ],
        "url" : "http:\/\/t.co\/yHizlXzK",
        "expanded_url" : "http:\/\/www.shoeboxblog.com\/wp-content\/uploads\/2008\/12\/rocket-punch-500x495.jpg",
        "display_url" : "shoeboxblog.com\/wp-content\/upl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "182024801366458369",
    "text" : "Never be too young  http:\/\/t.co\/yHizlXzK",
    "id" : 182024801366458369,
    "created_at" : "2012-03-20 08:44:29 +0000",
    "user" : {
      "name" : "Loudmouthman",
      "screen_name" : "loudmouthman",
      "protected" : false,
      "id_str" : "877781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000399419478\/6cf7ae41e43c3ab4723e5618a576f738_normal.jpeg",
      "id" : 877781,
      "verified" : false
    }
  },
  "id" : 182038290508156929,
  "created_at" : "2012-03-20 09:38:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/yG3lv8Kr",
      "expanded_url" : "http:\/\/j.mp\/GBod7P",
      "display_url" : "j.mp\/GBod7P"
    } ]
  },
  "geo" : { },
  "id_str" : "182036443571564544",
  "text" : "Compatibility: 3D-printed Toy Construction Kit-Adapter-Set  http:\/\/t.co\/yG3lv8Kr",
  "id" : 182036443571564544,
  "created_at" : "2012-03-20 09:30:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/XWHFp1hB",
      "expanded_url" : "http:\/\/j.mp\/GArTpt",
      "display_url" : "j.mp\/GArTpt"
    } ]
  },
  "geo" : { },
  "id_str" : "182031869771137024",
  "text" : "Interactivity and Reward-Related Neural Activation during a Serious Videogame http:\/\/t.co\/XWHFp1hB",
  "id" : 182031869771137024,
  "created_at" : "2012-03-20 09:12:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181997946064220162",
  "geo" : { },
  "id_str" : "182027612984582145",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch ah, viel Erfolg mit der B\u00FCrokratie. Das ist ja immer das schrecklichste am Studium.",
  "id" : 182027612984582145,
  "in_reply_to_status_id" : 181997946064220162,
  "created_at" : "2012-03-20 08:55:39 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181861229340524544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097204792, 8.2831518316 ]
  },
  "id_str" : "181863095155699713",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn while chewing beef jerky?",
  "id" : 181863095155699713,
  "in_reply_to_status_id" : 181861229340524544,
  "created_at" : "2012-03-19 22:01:55 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niels-Arne M\u00FCnck",
      "screen_name" : "Wernermuende",
      "indices" : [ 53, 66 ],
      "id_str" : "56502413",
      "id" : 56502413
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "homeopathy",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/ZokLZx29",
      "expanded_url" : "http:\/\/bit.ly\/9NPN2T",
      "display_url" : "bit.ly\/9NPN2T"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097325649, 8.2831376896 ]
  },
  "id_str" : "181860571115831296",
  "text" : "I love the disclaimer for corrections #homeopathy RT @Wernermuende: lol ymmd http:\/\/t.co\/ZokLZx29",
  "id" : 181860571115831296,
  "created_at" : "2012-03-19 21:51:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181858734253948928",
  "geo" : { },
  "id_str" : "181858956224905217",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch Aber das steht auch auf der ML zum nachlesen bzw. du wirst es im Code sehen :D",
  "id" : 181858956224905217,
  "in_reply_to_status_id" : 181858734253948928,
  "created_at" : "2012-03-19 21:45:28 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181858734253948928",
  "geo" : { },
  "id_str" : "181858862008246272",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch Super. Ich hoffe deine Arbeit geht gut vorw\u00E4rts? :) Wir haben prinzipiell nun auch ein Modal, nur ein kleineres Problem damit.",
  "id" : 181858862008246272,
  "in_reply_to_status_id" : 181858734253948928,
  "created_at" : "2012-03-19 21:45:06 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181841822870540288",
  "geo" : { },
  "id_str" : "181841915497545729",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall hehe, versteh ich :)",
  "id" : 181841915497545729,
  "in_reply_to_status_id" : 181841822870540288,
  "created_at" : "2012-03-19 20:37:45 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181841208820244480",
  "geo" : { },
  "id_str" : "181841521660801024",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall ah, verstehe. Dann w\u00FCrd ich auch nicht wechseln. So ist es bei mir mit Things. :)",
  "id" : 181841521660801024,
  "in_reply_to_status_id" : 181841208820244480,
  "created_at" : "2012-03-19 20:36:11 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181839347191005185",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097158339, 8.2831271267 ]
  },
  "id_str" : "181839745494691842",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall ich konnte mich nur nicht \u00FCberwinden 40(?) Dollar daf\u00FCr zu zahlen. :)",
  "id" : 181839745494691842,
  "in_reply_to_status_id" : 181839347191005185,
  "created_at" : "2012-03-19 20:29:08 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181839347191005185",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097032637, 8.2831077743 ]
  },
  "id_str" : "181839619145478144",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall aber sonst gebe ich recht: Papers ist extrem gut und stellenweise (hinzuf\u00FCgen \u00FCber Websuche\/Metadaten) m\u00E4chtiger.",
  "id" : 181839619145478144,
  "in_reply_to_status_id" : 181839347191005185,
  "created_at" : "2012-03-19 20:28:38 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    }, {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 16, 25 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181838137289474048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097321305, 8.2831354747 ]
  },
  "id_str" : "181838523622637568",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall @Roterhai Papers lohnt glaube ich nur wenn man komplett auf Mac l\u00E4uft.",
  "id" : 181838523622637568,
  "in_reply_to_status_id" : 181838137289474048,
  "created_at" : "2012-03-19 20:24:17 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    }, {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 16, 25 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181838137289474048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096658385, 8.2832591515 ]
  },
  "id_str" : "181838377564377088",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall @Roterhai joah, \u00FCber eigene Daten oder Google Scholar. Und ist halt Cross-Plattform und f\u00FCr lau. :)",
  "id" : 181838377564377088,
  "in_reply_to_status_id" : 181838137289474048,
  "created_at" : "2012-03-19 20:23:42 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181837510584971265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097711021, 8.2831901693 ]
  },
  "id_str" : "181837599332253696",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai ja, deshalb bin ich da optimistisch :)",
  "id" : 181837599332253696,
  "in_reply_to_status_id" : 181837510584971265,
  "created_at" : "2012-03-19 20:20:36 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181836835079720962",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009891647, 8.2830376178 ]
  },
  "id_str" : "181837381945663488",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai naja, da wird bestimmt ein Fix kommen. Die Programmierer sind fit und die Annotationsm\u00F6glichkeiten sind super. :)",
  "id" : 181837381945663488,
  "in_reply_to_status_id" : 181836835079720962,
  "created_at" : "2012-03-19 20:19:44 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181835609621532672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009760803, 8.2832135787 ]
  },
  "id_str" : "181836141694173184",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai GoodReader ist aber leider noch nicht ans Retina-Display vom neuen iPad angepasst muss ich gerade feststellen ;-)",
  "id" : 181836141694173184,
  "in_reply_to_status_id" : 181835609621532672,
  "created_at" : "2012-03-19 20:14:49 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    }, {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 16, 25 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181834910938574849",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097586783, 8.2832137428 ]
  },
  "id_str" : "181835046783692800",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall @Roterhai oder Mendeley, wenn man das verwendet. :)",
  "id" : 181835046783692800,
  "in_reply_to_status_id" : 181834910938574849,
  "created_at" : "2012-03-19 20:10:28 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Arndt Gro\u00DFmann",
      "screen_name" : "g1zu",
      "indices" : [ 6, 11 ],
      "id_str" : "484276999",
      "id" : 484276999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181825225619546112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098893838, 8.2828874979 ]
  },
  "id_str" : "181825354221092865",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a @g1zu schaffe es heute auch nicht. Viel erfolg mit der Pr\u00FCfung.",
  "id" : 181825354221092865,
  "in_reply_to_status_id" : 181825225619546112,
  "created_at" : "2012-03-19 19:31:57 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ttk \u0CA0_\u0CA0",
      "screen_name" : "simonszu",
      "indices" : [ 0, 9 ],
      "id_str" : "14065732",
      "id" : 14065732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181823005561856001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097531836, 8.2831942179 ]
  },
  "id_str" : "181825118161481729",
  "in_reply_to_user_id" : 14065732,
  "text" : "@simonszu alter, du redest vom Friedensnobelpreis. Wie passt da \"Wert\" \u00FCberhaupt? ;)",
  "id" : 181825118161481729,
  "in_reply_to_status_id" : 181823005561856001,
  "created_at" : "2012-03-19 19:31:00 +0000",
  "in_reply_to_screen_name" : "simonszu",
  "in_reply_to_user_id_str" : "14065732",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 3, 19 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/SQp7J0y3",
      "expanded_url" : "http:\/\/i.imgur.com\/lbJXh.jpg",
      "display_url" : "i.imgur.com\/lbJXh.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "181824416181780480",
  "text" : "RT @The_Smoking_GNU: This will make you smile when you figure it out: http:\/\/t.co\/SQp7J0y3 (via reddit)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/SQp7J0y3",
        "expanded_url" : "http:\/\/i.imgur.com\/lbJXh.jpg",
        "display_url" : "i.imgur.com\/lbJXh.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "181814403891593217",
    "text" : "This will make you smile when you figure it out: http:\/\/t.co\/SQp7J0y3 (via reddit)",
    "id" : 181814403891593217,
    "created_at" : "2012-03-19 18:48:26 +0000",
    "user" : {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "protected" : false,
      "id_str" : "14535787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2761947084\/9f21f669a1629e0af7949d685517ee66_normal.jpeg",
      "id" : 14535787,
      "verified" : false
    }
  },
  "id" : 181824416181780480,
  "created_at" : "2012-03-19 19:28:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181818327407149056",
  "text" : "Chanthropology: \u00AB\/b\/\u2019s anonymity is likely shaping a strong communal identity among a very large set\nof individuals\u00BB",
  "id" : 181818327407149056,
  "created_at" : "2012-03-19 19:04:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181818158523486209",
  "text" : "Chanthropology: \u00AB[T]he median thread spends just \uFB01ve seconds on \/b\/\u2019s \uFB01rst page before being pushed off by newer posts\u00BB",
  "id" : 181818158523486209,
  "created_at" : "2012-03-19 19:03:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 93, 100 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/VQCTGM0i",
      "expanded_url" : "http:\/\/projects.csail.mit.edu\/chanthropology\/4chan.pdf",
      "display_url" : "projects.csail.mit.edu\/chanthropology\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "181817581005574144",
  "text" : "Chanthropology of 4chan &amp; \/b\/: Anonymity and ephemerality http:\/\/t.co\/VQCTGM0i \/Link via @mrgunn",
  "id" : 181817581005574144,
  "created_at" : "2012-03-19 19:01:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181807054074290176",
  "geo" : { },
  "id_str" : "181809975205699584",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai Ja, jede Menge sogar. Die App heisst GoodReader und kann Dropbox-Sync",
  "id" : 181809975205699584,
  "in_reply_to_status_id" : 181807054074290176,
  "created_at" : "2012-03-19 18:30:50 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181804238895202304",
  "geo" : { },
  "id_str" : "181805396325974016",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall ja, schon eingerichtet und sehr zufrieden. :)",
  "id" : 181805396325974016,
  "in_reply_to_status_id" : 181804238895202304,
  "created_at" : "2012-03-19 18:12:38 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/uyuDHXBh",
      "expanded_url" : "http:\/\/j.mp\/FPQIwf",
      "display_url" : "j.mp\/FPQIwf"
    } ]
  },
  "geo" : { },
  "id_str" : "181794611914752000",
  "text" : "\u00AB[North Korean prison] camps are \"complete control districts\" where \"irredeemables\" are worked to death.\u00BB http:\/\/t.co\/uyuDHXBh",
  "id" : 181794611914752000,
  "created_at" : "2012-03-19 17:29:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181792729599184899",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097458294, 8.2831518856 ]
  },
  "id_str" : "181792827833978880",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ okay :)",
  "id" : 181792827833978880,
  "in_reply_to_status_id" : 181792729599184899,
  "created_at" : "2012-03-19 17:22:42 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181791950037463040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097582758, 8.2831331861 ]
  },
  "id_str" : "181792238412640256",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ ok, und das ging?",
  "id" : 181792238412640256,
  "in_reply_to_status_id" : 181791950037463040,
  "created_at" : "2012-03-19 17:20:21 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181790584430788609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097582758, 8.2831331861 ]
  },
  "id_str" : "181790718338150400",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ bl\u00F6de Frage: Hast du mehr als einen Amazon-Account und den falschen genommen? ;)",
  "id" : 181790718338150400,
  "in_reply_to_status_id" : 181790584430788609,
  "created_at" : "2012-03-19 17:14:19 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/181790374761725953\/photo\/1",
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/3V2Y63KR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoXZYffCAAAcQQz.jpg",
      "id_str" : "181790374770114560",
      "id" : 181790374770114560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoXZYffCAAAcQQz.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/3V2Y63KR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181790050894348288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096501643, 8.2831526175 ]
  },
  "id_str" : "181790374761725953",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ das m\u00FCsste in etwa so aussehen auf dem neuen Ger\u00E4t. Vermutlich nur in Deutsch http:\/\/t.co\/3V2Y63KR",
  "id" : 181790374761725953,
  "in_reply_to_status_id" : 181790050894348288,
  "created_at" : "2012-03-19 17:12:58 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181789368502071298",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009750831, 8.2832593191 ]
  },
  "id_str" : "181789522802130944",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ auch im Cloud-Dings nicht?",
  "id" : 181789522802130944,
  "in_reply_to_status_id" : 181789368502071298,
  "created_at" : "2012-03-19 17:09:34 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181788818075156481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096957079, 8.2831498522 ]
  },
  "id_str" : "181789273253617664",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ einfach in die Kindle-App einloggen mit den Amazon-Daten",
  "id" : 181789273253617664,
  "in_reply_to_status_id" : 181788818075156481,
  "created_at" : "2012-03-19 17:08:34 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181779941124354049",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097479823, 8.2830854072 ]
  },
  "id_str" : "181780965608275969",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog leicht esoterisch im Abgang",
  "id" : 181780965608275969,
  "in_reply_to_status_id" : 181779941124354049,
  "created_at" : "2012-03-19 16:35:34 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/OYcuHdRN",
      "expanded_url" : "http:\/\/j.mp\/wazxaC",
      "display_url" : "j.mp\/wazxaC"
    } ]
  },
  "geo" : { },
  "id_str" : "181778741943468032",
  "text" : "\u00ABFor if there is the delicate hint of anything to be sensed in any wine, it is likely that of pesticide and manure.\u00BB http:\/\/t.co\/OYcuHdRN",
  "id" : 181778741943468032,
  "created_at" : "2012-03-19 16:26:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian",
      "screen_name" : "MrEnkapsis",
      "indices" : [ 0, 11 ],
      "id_str" : "115717883",
      "id" : 115717883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181772692125528066",
  "geo" : { },
  "id_str" : "181775574937767937",
  "in_reply_to_user_id" : 115717883,
  "text" : "@MrEnkapsis wenn im Labor nichts l\u00E4uft... A: ...f\u00E4ngt man an zu beten B: ...wiederholt den Versuch C: ...\u00E4ndert einen Parameter am Replikat",
  "id" : 181775574937767937,
  "in_reply_to_status_id" : 181772692125528066,
  "created_at" : "2012-03-19 16:14:08 +0000",
  "in_reply_to_screen_name" : "MrEnkapsis",
  "in_reply_to_user_id_str" : "115717883",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Bedford",
      "screen_name" : "trvrb",
      "indices" : [ 3, 9 ],
      "id_str" : "224896427",
      "id" : 224896427
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Contagion",
      "indices" : [ 33, 43 ]
    }, {
      "text" : "MovieScience",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/BytEGqYc",
      "expanded_url" : "http:\/\/bit.ly\/xsUExc",
      "display_url" : "bit.ly\/xsUExc"
    } ]
  },
  "geo" : { },
  "id_str" : "181761439290232832",
  "text" : "RT @trvrb: I ran the numbers for #Contagion's pandemic spread.... they don't come out well. #MovieScience http:\/\/t.co\/BytEGqYc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Contagion",
        "indices" : [ 22, 32 ]
      }, {
        "text" : "MovieScience",
        "indices" : [ 81, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/BytEGqYc",
        "expanded_url" : "http:\/\/bit.ly\/xsUExc",
        "display_url" : "bit.ly\/xsUExc"
      } ]
    },
    "geo" : { },
    "id_str" : "181760018138406912",
    "text" : "I ran the numbers for #Contagion's pandemic spread.... they don't come out well. #MovieScience http:\/\/t.co\/BytEGqYc",
    "id" : 181760018138406912,
    "created_at" : "2012-03-19 15:12:19 +0000",
    "user" : {
      "name" : "Trevor Bedford",
      "screen_name" : "trvrb",
      "protected" : false,
      "id_str" : "224896427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/532254561386262528\/gHX_F_KC_normal.png",
      "id" : 224896427,
      "verified" : false
    }
  },
  "id" : 181761439290232832,
  "created_at" : "2012-03-19 15:17:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Correlated Risk",
      "screen_name" : "correlatedrisk",
      "indices" : [ 3, 18 ],
      "id_str" : "308464742",
      "id" : 308464742
    }, {
      "name" : "Todd Kuiken",
      "screen_name" : "DrToddOliver",
      "indices" : [ 74, 87 ],
      "id_str" : "116782560",
      "id" : 116782560
    }, {
      "name" : "Carl Zimmer",
      "screen_name" : "carlzimmer",
      "indices" : [ 125, 136 ],
      "id_str" : "14085070",
      "id" : 14085070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/lsjLK1Ds",
      "expanded_url" : "http:\/\/bit.ly\/wlzvlq",
      "display_url" : "bit.ly\/wlzvlq"
    } ]
  },
  "geo" : { },
  "id_str" : "181736554853703682",
  "text" : "RT @correlatedrisk: 'What's the Risk Associated with Citizen Scientists?' @DrToddOliver http:\/\/t.co\/lsjLK1Ds | responding to @CarlZimmer ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Todd Kuiken",
        "screen_name" : "DrToddOliver",
        "indices" : [ 54, 67 ],
        "id_str" : "116782560",
        "id" : 116782560
      }, {
        "name" : "Carl Zimmer",
        "screen_name" : "carlzimmer",
        "indices" : [ 105, 116 ],
        "id_str" : "14085070",
        "id" : 14085070
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/lsjLK1Ds",
        "expanded_url" : "http:\/\/bit.ly\/wlzvlq",
        "display_url" : "bit.ly\/wlzvlq"
      }, {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/h7ACvuGu",
        "expanded_url" : "http:\/\/nyti.ms\/wY0gtj",
        "display_url" : "nyti.ms\/wY0gtj"
      } ]
    },
    "geo" : { },
    "id_str" : "181730554994098177",
    "text" : "'What's the Risk Associated with Citizen Scientists?' @DrToddOliver http:\/\/t.co\/lsjLK1Ds | responding to @CarlZimmer http:\/\/t.co\/h7ACvuGu",
    "id" : 181730554994098177,
    "created_at" : "2012-03-19 13:15:15 +0000",
    "user" : {
      "name" : "Correlated Risk",
      "screen_name" : "correlatedrisk",
      "protected" : false,
      "id_str" : "308464742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1376913927\/tw_avatar_1_normal.jpg",
      "id" : 308464742,
      "verified" : false
    }
  },
  "id" : 181736554853703682,
  "created_at" : "2012-03-19 13:39:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Zelnio",
      "screen_name" : "kzelnio",
      "indices" : [ 3, 11 ],
      "id_str" : "19202541",
      "id" : 19202541
    }, {
      "name" : "grist",
      "screen_name" : "grist",
      "indices" : [ 115, 121 ],
      "id_str" : "7215512",
      "id" : 7215512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/UPDWLNEy",
      "expanded_url" : "http:\/\/grist.org\/factory-farms\/pink-slime-is-the-tip-of-the-iceberg-look-what-else-is-in-industrial-meat\/",
      "display_url" : "grist.org\/factory-farms\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "181732906727780352",
  "text" : "RT @kzelnio: \u2018Pink slime\u2019 is the tip of the iceberg: Look what else is in industrial\u00A0meat http:\/\/t.co\/UPDWLNEy via @grist",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "grist",
        "screen_name" : "grist",
        "indices" : [ 102, 108 ],
        "id_str" : "7215512",
        "id" : 7215512
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/UPDWLNEy",
        "expanded_url" : "http:\/\/grist.org\/factory-farms\/pink-slime-is-the-tip-of-the-iceberg-look-what-else-is-in-industrial-meat\/",
        "display_url" : "grist.org\/factory-farms\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "181732578125029377",
    "text" : "\u2018Pink slime\u2019 is the tip of the iceberg: Look what else is in industrial\u00A0meat http:\/\/t.co\/UPDWLNEy via @grist",
    "id" : 181732578125029377,
    "created_at" : "2012-03-19 13:23:17 +0000",
    "user" : {
      "name" : "Kevin Zelnio",
      "screen_name" : "kzelnio",
      "protected" : false,
      "id_str" : "19202541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/847483816457285632\/b1frtSEL_normal.jpg",
      "id" : 19202541,
      "verified" : false
    }
  },
  "id" : 181732906727780352,
  "created_at" : "2012-03-19 13:24:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181484354420215808",
  "geo" : { },
  "id_str" : "181500749560299520",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Der Schnaps klingt trotzdem sehr verlockend.",
  "id" : 181500749560299520,
  "in_reply_to_status_id" : 181484354420215808,
  "created_at" : "2012-03-18 22:02:05 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181389982441799680",
  "geo" : { },
  "id_str" : "181471322919018496",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU Hast recht. Nicht so nachhaltig wie andere Krankheiten.",
  "id" : 181471322919018496,
  "in_reply_to_status_id" : 181389982441799680,
  "created_at" : "2012-03-18 20:05:09 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181470783728652288",
  "text" : "Ein Lebewesen welches sich von fl\u00FCchtigen Bestandteilen des Weins ern\u00E4hrt. Ist es a) ein Pilz oder b) ein SciLogger? #scilogs12",
  "id" : 181470783728652288,
  "created_at" : "2012-03-18 20:03:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stacy Baker Kunst",
      "screen_name" : "StacyCBaker",
      "indices" : [ 3, 15 ],
      "id_str" : "16486814",
      "id" : 16486814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181463257339527168",
  "text" : "RT @StacyCBaker: On my flight today I was wondering why I've never seen a female pilot despite 100s of flights. Lots of comments here: h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/HBhM95oI",
        "expanded_url" : "http:\/\/www.avweb.com\/blogs\/insider\/WhySoFewWomenPilots_203344-1.html",
        "display_url" : "avweb.com\/blogs\/insider\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "181456174145732608",
    "text" : "On my flight today I was wondering why I've never seen a female pilot despite 100s of flights. Lots of comments here: http:\/\/t.co\/HBhM95oI",
    "id" : 181456174145732608,
    "created_at" : "2012-03-18 19:04:57 +0000",
    "user" : {
      "name" : "Stacy Baker Kunst",
      "screen_name" : "StacyCBaker",
      "protected" : false,
      "id_str" : "16486814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/904806750725038080\/FiPtj_Po_normal.jpg",
      "id" : 16486814,
      "verified" : false
    }
  },
  "id" : 181463257339527168,
  "created_at" : "2012-03-18 19:33:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181456563427483649",
  "geo" : { },
  "id_str" : "181456979754090497",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me I'm already home, watching cat pictures!",
  "id" : 181456979754090497,
  "in_reply_to_status_id" : 181456563427483649,
  "created_at" : "2012-03-18 19:08:09 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181400274731143169",
  "text" : "Zug bekommen und jetzt auf dem Weg nach Mainz.",
  "id" : 181400274731143169,
  "created_at" : "2012-03-18 15:22:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard",
      "screen_name" : "zinken",
      "indices" : [ 0, 7 ],
      "id_str" : "15353398",
      "id" : 15353398
    }, {
      "name" : "schusselhexe",
      "screen_name" : "christorolo",
      "indices" : [ 8, 20 ],
      "id_str" : "292924620",
      "id" : 292924620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181371950935977984",
  "geo" : { },
  "id_str" : "181372177218674688",
  "in_reply_to_user_id" : 15353398,
  "text" : "@zinken @christorolo wir haben hier noch 2 Pl\u00E4tze :)",
  "id" : 181372177218674688,
  "in_reply_to_status_id" : 181371950935977984,
  "created_at" : "2012-03-18 13:31:11 +0000",
  "in_reply_to_screen_name" : "zinken",
  "in_reply_to_user_id_str" : "15353398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "schusselhexe",
      "screen_name" : "christorolo",
      "indices" : [ 0, 12 ],
      "id_str" : "292924620",
      "id" : 292924620
    }, {
      "name" : "Richard",
      "screen_name" : "zinken",
      "indices" : [ 17, 24 ],
      "id_str" : "15353398",
      "id" : 15353398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181370266700619776",
  "geo" : { },
  "id_str" : "181370454043402240",
  "in_reply_to_user_id" : 292924620,
  "text" : "@christorolo den @zinken hatten wir schon. ;)",
  "id" : 181370454043402240,
  "in_reply_to_status_id" : 181370266700619776,
  "created_at" : "2012-03-18 13:24:20 +0000",
  "in_reply_to_screen_name" : "christorolo",
  "in_reply_to_user_id_str" : "292924620",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "schusselhexe",
      "screen_name" : "christorolo",
      "indices" : [ 0, 12 ],
      "id_str" : "292924620",
      "id" : 292924620
    }, {
      "name" : "Quantenwelt",
      "screen_name" : "quantenwelt",
      "indices" : [ 49, 61 ],
      "id_str" : "38418484",
      "id" : 38418484
    }, {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 62, 77 ],
      "id_str" : "73134122",
      "id" : 73134122
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 78, 93 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    }, {
      "name" : "Markus A. Dahlem",
      "screen_name" : "markusdahlem",
      "indices" : [ 94, 107 ],
      "id_str" : "15703122",
      "id" : 15703122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181350903457136640",
  "geo" : { },
  "id_str" : "181351355791835136",
  "in_reply_to_user_id" : 292924620,
  "text" : "@christorolo ja, du musst nach dem Essen mal mit @quantenwelt @astefanowitsch @gedankenabfall @markusdahlem und mir reden.",
  "id" : 181351355791835136,
  "in_reply_to_status_id" : 181350903457136640,
  "created_at" : "2012-03-18 12:08:27 +0000",
  "in_reply_to_screen_name" : "christorolo",
  "in_reply_to_user_id_str" : "292924620",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4013934349, 8.1925370874 ]
  },
  "id_str" : "181343277386174464",
  "text" : "Die lifetypekritische Wordpresseria trifft sich im Kuhstall #scilogs12",
  "id" : 181343277386174464,
  "created_at" : "2012-03-18 11:36:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 3, 18 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181327901222912000",
  "text" : "RT @gedankenabfall: Hat jemand ein kleines Wifi-iPad der ersten Generation abzugeben?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "181327402142674944",
    "text" : "Hat jemand ein kleines Wifi-iPad der ersten Generation abzugeben?",
    "id" : 181327402142674944,
    "created_at" : "2012-03-18 10:33:16 +0000",
    "user" : {
      "name" : "Martin Ballaschk",
      "screen_name" : "ballaschk",
      "protected" : false,
      "id_str" : "29082973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929738577637986304\/nZwS53cM_normal.jpg",
      "id" : 29082973,
      "verified" : false
    }
  },
  "id" : 181327901222912000,
  "created_at" : "2012-03-18 10:35:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 92, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4013889584, 8.1924429332 ]
  },
  "id_str" : "181326113065271297",
  "text" : "Ich h\u00F6re die ganze Zeit \u00ABangemessene Verh\u00FCtung\u00BB. Muss an den ASCII-Arts von gestern liegen. #scilogs12",
  "id" : 181326113065271297,
  "created_at" : "2012-03-18 10:28:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "charly",
      "screen_name" : "oxytocinated",
      "indices" : [ 3, 16 ],
      "id_str" : "437899160",
      "id" : 437899160
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Faultiere",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/5wnJnTC6",
      "expanded_url" : "http:\/\/a.asset.soup.io\/asset\/3015\/2794_f433.jpeg",
      "display_url" : "a.asset.soup.io\/asset\/3015\/279\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "181324812847816705",
  "text" : "RT @oxytocinated: Irgendwer in meiner TL mochte doch #Faultiere, oder?\nhttp:\/\/t.co\/5wnJnTC6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Faultiere",
        "indices" : [ 35, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/5wnJnTC6",
        "expanded_url" : "http:\/\/a.asset.soup.io\/asset\/3015\/2794_f433.jpeg",
        "display_url" : "a.asset.soup.io\/asset\/3015\/279\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "181323058911514624",
    "text" : "Irgendwer in meiner TL mochte doch #Faultiere, oder?\nhttp:\/\/t.co\/5wnJnTC6",
    "id" : 181323058911514624,
    "created_at" : "2012-03-18 10:16:00 +0000",
    "user" : {
      "name" : "charly",
      "screen_name" : "oxytocinated",
      "protected" : false,
      "id_str" : "437899160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1696860929\/ava-gross_normal.jpg",
      "id" : 437899160,
      "verified" : false
    }
  },
  "id" : 181324812847816705,
  "created_at" : "2012-03-18 10:22:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens-Wolfhard",
      "screen_name" : "Drahflow",
      "indices" : [ 0, 9 ],
      "id_str" : "92904426",
      "id" : 92904426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181320782255882241",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4015474991, 8.191967486 ]
  },
  "id_str" : "181321287568863233",
  "in_reply_to_user_id" : 92904426,
  "text" : "@Drahflow danke!",
  "id" : 181321287568863233,
  "in_reply_to_status_id" : 181320782255882241,
  "created_at" : "2012-03-18 10:08:58 +0000",
  "in_reply_to_screen_name" : "Drahflow",
  "in_reply_to_user_id_str" : "92904426",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian",
      "screen_name" : "sebaso",
      "indices" : [ 0, 7 ],
      "id_str" : "10462602",
      "id" : 10462602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181315944101064704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4015466248, 8.1919685089 ]
  },
  "id_str" : "181316405319315456",
  "in_reply_to_user_id" : 10462602,
  "text" : "@sebaso ist doch nicht anders als jetzt schon mit Keyloggern, oder nicht?",
  "id" : 181316405319315456,
  "in_reply_to_status_id" : 181315944101064704,
  "created_at" : "2012-03-18 09:49:34 +0000",
  "in_reply_to_screen_name" : "sebaso",
  "in_reply_to_user_id_str" : "10462602",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "indices" : [ 3, 17 ],
      "id_str" : "19575586",
      "id" : 19575586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/MOUjnTlL",
      "expanded_url" : "http:\/\/www.nytimes.com\/2012\/03\/18\/business\/seeking-ways-to-make-computer-passwords-unnecessary.html",
      "display_url" : "nytimes.com\/2012\/03\/18\/bus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "181316249937121280",
  "text" : "RT @hackernewsbot: Bypassing the Password: Seeking Ways to Make the Computer Password Obsolete... http:\/\/t.co\/MOUjnTlL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/news.ycombinator.com\/\" rel=\"nofollow\"\u003EHacker News Bot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/MOUjnTlL",
        "expanded_url" : "http:\/\/www.nytimes.com\/2012\/03\/18\/business\/seeking-ways-to-make-computer-passwords-unnecessary.html",
        "display_url" : "nytimes.com\/2012\/03\/18\/bus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "181314510567653376",
    "text" : "Bypassing the Password: Seeking Ways to Make the Computer Password Obsolete... http:\/\/t.co\/MOUjnTlL",
    "id" : 181314510567653376,
    "created_at" : "2012-03-18 09:42:02 +0000",
    "user" : {
      "name" : "Hacker News Bot",
      "screen_name" : "hackernewsbot",
      "protected" : false,
      "id_str" : "19575586",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/73596050\/yc500_normal.jpg",
      "id" : 19575586,
      "verified" : false
    }
  },
  "id" : 181316249937121280,
  "created_at" : "2012-03-18 09:48:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Scilogs12",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4017535767, 8.1917088576 ]
  },
  "id_str" : "181315604286930944",
  "text" : "DEFCON IV #Scilogs12",
  "id" : 181315604286930944,
  "created_at" : "2012-03-18 09:46:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 0, 11 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181306194504331264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4017550274, 8.1915779473 ]
  },
  "id_str" : "181306614563872768",
  "in_reply_to_user_id" : 20342875,
  "text" : "@LouWoodley he didn't care much. So we had to use wikipedia to inform ourselves. ;)",
  "id" : 181306614563872768,
  "in_reply_to_status_id" : 181306194504331264,
  "created_at" : "2012-03-18 09:10:40 +0000",
  "in_reply_to_screen_name" : "LouWoodley",
  "in_reply_to_user_id_str" : "20342875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Lingenh\u00F6hl",
      "screen_name" : "lingenhoehl",
      "indices" : [ 0, 12 ],
      "id_str" : "202098194",
      "id" : 202098194
    }, {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 13, 28 ],
      "id_str" : "73134122",
      "id" : 73134122
    }, {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 29, 40 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181305038315077632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4018818151, 8.1914106129 ]
  },
  "id_str" : "181305367207219201",
  "in_reply_to_user_id" : 202098194,
  "text" : "@lingenhoehl @astefanowitsch @LouWoodley but he has no clue hat molds are fungi and not sponges. Instant disapproval from biologists.",
  "id" : 181305367207219201,
  "in_reply_to_status_id" : 181305038315077632,
  "created_at" : "2012-03-18 09:05:42 +0000",
  "in_reply_to_screen_name" : "lingenhoehl",
  "in_reply_to_user_id_str" : "202098194",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181304464542679040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4015846242, 8.1921652557 ]
  },
  "id_str" : "181304600530391041",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Vom Regen in die Kaffeepause!",
  "id" : 181304600530391041,
  "in_reply_to_status_id" : 181304464542679040,
  "created_at" : "2012-03-18 09:02:39 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 0, 11 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181303998329008130",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4017232739, 8.1920247383 ]
  },
  "id_str" : "181304168152170496",
  "in_reply_to_user_id" : 20342875,
  "text" : "@LouWoodley the wines of the tasting weren't that good this year.",
  "id" : 181304168152170496,
  "in_reply_to_status_id" : 181303998329008130,
  "created_at" : "2012-03-18 09:00:56 +0000",
  "in_reply_to_screen_name" : "LouWoodley",
  "in_reply_to_user_id_str" : "20342875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181303077331156993",
  "text" : "\u00ABWahl zwischen Pest und Cholera\u00BB sollte man wirklich nicht verwenden. Schliesslich haben wir erstere ausgerottet.",
  "id" : 181303077331156993,
  "created_at" : "2012-03-18 08:56:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 0, 11 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181299888229851136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4017249417, 8.1921509269 ]
  },
  "id_str" : "181302448433020928",
  "in_reply_to_user_id" : 20342875,
  "text" : "@LouWoodley I hope you'll join us again next year :)",
  "id" : 181302448433020928,
  "in_reply_to_status_id" : 181299888229851136,
  "created_at" : "2012-03-18 08:54:06 +0000",
  "in_reply_to_screen_name" : "LouWoodley",
  "in_reply_to_user_id_str" : "20342875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/YS6T8rAn",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/One-time_pad",
      "display_url" : "en.wikipedia.org\/wiki\/One-time_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "181300697067814913",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4048180862, 8.1884248821 ]
  },
  "id_str" : "181301453040779264",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall klingt nach Crypto http:\/\/t.co\/YS6T8rAn ;) #scilogs12",
  "id" : 181301453040779264,
  "in_reply_to_status_id" : 181300697067814913,
  "created_at" : "2012-03-18 08:50:09 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/jBSlgft7",
      "expanded_url" : "http:\/\/j.mp\/ArzgoS",
      "display_url" : "j.mp\/ArzgoS"
    } ]
  },
  "geo" : { },
  "id_str" : "181293227566055424",
  "text" : "Die Kritik an Arsenic Life wird wohl auch in Science publiziert http:\/\/t.co\/jBSlgft7 #scilogs12",
  "id" : 181293227566055424,
  "created_at" : "2012-03-18 08:17:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181014000862113792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4014228012, 8.1928733979 ]
  },
  "id_str" : "181287146685075456",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer can you send me a screenshot of the \"text not fitting the modal\"? :)",
  "id" : 181287146685075456,
  "in_reply_to_status_id" : 181014000862113792,
  "created_at" : "2012-03-18 07:53:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181197079715123200",
  "text" : "RT @PhilippBayer: \"I will not learn Rails\" - tl;dr: author met some meanies, and doesn't know how to optimise standard Rails https:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 128 ],
        "url" : "https:\/\/t.co\/12xKriiz",
        "expanded_url" : "https:\/\/tyler.menez.es\/articles\/i-will-not-learn-rails.html",
        "display_url" : "tyler.menez.es\/articles\/i-wil\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "181175605008678912",
    "text" : "\"I will not learn Rails\" - tl;dr: author met some meanies, and doesn't know how to optimise standard Rails https:\/\/t.co\/12xKriiz",
    "id" : 181175605008678912,
    "created_at" : "2012-03-18 00:30:04 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 181197079715123200,
  "created_at" : "2012-03-18 01:55:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 4, 11 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4037564587, 8.1890987522 ]
  },
  "id_str" : "181188742034370560",
  "text" : "Der @Evo2Me wollte mich in sein Bett einladen. Konnte aber mein Zimmer gerade noch finden. #scilogs12",
  "id" : 181188742034370560,
  "created_at" : "2012-03-18 01:22:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Horev",
      "screen_name" : "GuyHorev",
      "indices" : [ 0, 9 ],
      "id_str" : "376585264",
      "id" : 376585264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181164322616123393",
  "geo" : { },
  "id_str" : "181187162874707968",
  "in_reply_to_user_id" : 376585264,
  "text" : "@GuyHorev the chances of single SNP or astrological dates determining complex phenotypes could be quite similar ;)",
  "id" : 181187162874707968,
  "in_reply_to_status_id" : 181164322616123393,
  "created_at" : "2012-03-18 01:16:00 +0000",
  "in_reply_to_screen_name" : "GuyHorev",
  "in_reply_to_user_id_str" : "376585264",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quantenwelt",
      "screen_name" : "quantenwelt",
      "indices" : [ 15, 27 ],
      "id_str" : "38418484",
      "id" : 38418484
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181120546401030144",
  "text" : "Gl\u00FCckwunsch an @quantenwelt zum verdienten SciLogs-Preis! #scilogs12",
  "id" : 181120546401030144,
  "created_at" : "2012-03-17 20:51:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/ca7j2yEi",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Approval_voting",
      "display_url" : "en.wikipedia.org\/wiki\/Approval_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "181115546618707969",
  "geo" : { },
  "id_str" : "181115755247583232",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus http:\/\/t.co\/ca7j2yEi",
  "id" : 181115755247583232,
  "in_reply_to_status_id" : 181115546618707969,
  "created_at" : "2012-03-17 20:32:15 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian",
      "screen_name" : "MrEnkapsis",
      "indices" : [ 52, 63 ],
      "id_str" : "115717883",
      "id" : 115717883
    }, {
      "name" : "Quantenwelt",
      "screen_name" : "quantenwelt",
      "indices" : [ 64, 76 ],
      "id_str" : "38418484",
      "id" : 38418484
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 81, 96 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 111, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181115238064734208",
  "text" : "Jetzt h\u00E4tte ich gerne Approval Voting damit ich f\u00FCr @MrEnkapsis @quantenwelt und @gedankenabfall stimmen kann. #scilogs12",
  "id" : 181115238064734208,
  "created_at" : "2012-03-17 20:30:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181110077367910401",
  "geo" : { },
  "id_str" : "181110738436374528",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon sogar Bio-dynamisch! Sprich bei passender Mondphase gepfl\u00FCckt!",
  "id" : 181110738436374528,
  "in_reply_to_status_id" : 181110077367910401,
  "created_at" : "2012-03-17 20:12:19 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 52, 67 ],
      "id_str" : "73134122",
      "id" : 73134122
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 69, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/0ay8stYH",
      "expanded_url" : "http:\/\/instagr.am\/p\/ISVT1qhwpI\/",
      "display_url" : "instagr.am\/p\/ISVT1qhwpI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "181110569175220224",
  "text" : "Manchmal reicht ein Facepalm nicht: Double-Facepalm @astefanowitsch  #scilogs12  http:\/\/t.co\/0ay8stYH",
  "id" : 181110569175220224,
  "created_at" : "2012-03-17 20:11:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181109408519041024",
  "geo" : { },
  "id_str" : "181109613419167744",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ja, der Umwelt zuliebe habe ich mich f\u00FCr die vegetarische Option entschieden!",
  "id" : 181109613419167744,
  "in_reply_to_status_id" : 181109408519041024,
  "created_at" : "2012-03-17 20:07:51 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Smillie",
      "screen_name" : "mequantum",
      "indices" : [ 0, 10 ],
      "id_str" : "47163083",
      "id" : 47163083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181076185718075393",
  "geo" : { },
  "id_str" : "181109080809684992",
  "in_reply_to_user_id" : 47163083,
  "text" : "@mequantum maybe only a combination of multiple genes? ;)",
  "id" : 181109080809684992,
  "in_reply_to_status_id" : 181076185718075393,
  "created_at" : "2012-03-17 20:05:44 +0000",
  "in_reply_to_screen_name" : "mequantum",
  "in_reply_to_user_id_str" : "47163083",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/dXFc7W4H",
      "expanded_url" : "http:\/\/instagr.am\/p\/ISUMj2hwo5\/",
      "display_url" : "instagr.am\/p\/ISUMj2hwo5\/"
    } ]
  },
  "geo" : { },
  "id_str" : "181107941787701249",
  "text" : "Abendessen http:\/\/t.co\/dXFc7W4H",
  "id" : 181107941787701249,
  "created_at" : "2012-03-17 20:01:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/EfbIePtQ",
      "expanded_url" : "http:\/\/de.wikipedia.org\/wiki\/Kellerschimmel",
      "display_url" : "de.wikipedia.org\/wiki\/Kellersch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "181088533342203904",
  "text" : "Der Winzer meint in seinem Keller w\u00E4chst ein Schwamm. Was er eigentlich meint: http:\/\/t.co\/EfbIePtQ #scilogs12",
  "id" : 181088533342203904,
  "created_at" : "2012-03-17 18:44:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 31, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/0gY9lnRV",
      "expanded_url" : "http:\/\/instagr.am\/p\/ISBeGdBwjV\/",
      "display_url" : "instagr.am\/p\/ISBeGdBwjV\/"
    } ]
  },
  "geo" : { },
  "id_str" : "181066716628008960",
  "text" : "Heil und Segen dem Weing\u00E4rtner #scilogs12 http:\/\/t.co\/0gY9lnRV",
  "id" : 181066716628008960,
  "created_at" : "2012-03-17 17:17:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 4, 19 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/xz1NDc74",
      "expanded_url" : "http:\/\/instagr.am\/p\/ISA1QXBwjO\/",
      "display_url" : "instagr.am\/p\/ISA1QXBwjO\/"
    } ]
  },
  "geo" : { },
  "id_str" : "181065520089542656",
  "text" : "Der @gedankenabfall bei der #scilogs12 Weinprobe http:\/\/t.co\/xz1NDc74",
  "id" : 181065520089542656,
  "created_at" : "2012-03-17 17:12:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4038244174, 8.1892189589 ]
  },
  "id_str" : "181051930263552000",
  "text" : "Statt \u00ABk\u00F6nnte ich ein Nichtraucherzimmer bekommen?\u00BB lieber \u00ABk\u00F6nnte ich ein Zimmer mit 3G im o2-Netz bekommen?\u00BB fragen. #scilogs12",
  "id" : 181051930263552000,
  "created_at" : "2012-03-17 16:18:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/78LINu9d",
      "expanded_url" : "http:\/\/j.mp\/zcNS4I",
      "display_url" : "j.mp\/zcNS4I"
    } ]
  },
  "geo" : { },
  "id_str" : "181051589228900354",
  "text" : "Not that surprisingly: No single SNP is correlated with Big 5 of personality traits? http:\/\/t.co\/78LINu9d",
  "id" : 181051589228900354,
  "created_at" : "2012-03-17 16:17:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4038456026, 8.189217223 ]
  },
  "id_str" : "181049950602399745",
  "text" : "ScienceBlogger d\u00FCrfen ruhig bloggen wenn sie im Kino waren. Z.B. wenn sich herausstellt das der Titel \u00ABTree of Life\u00BB irref\u00FChrend ist.",
  "id" : 181049950602399745,
  "created_at" : "2012-03-17 16:10:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    }, {
      "name" : "SciLogs",
      "screen_name" : "scilogs",
      "indices" : [ 34, 42 ],
      "id_str" : "14980634",
      "id" : 14980634
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181037439828242433",
  "geo" : { },
  "id_str" : "181038023432093698",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall was meinst du was @scilogs bislang mit dem Spam macht? #scilogs12",
  "id" : 181038023432093698,
  "in_reply_to_status_id" : 181037439828242433,
  "created_at" : "2012-03-17 15:23:22 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Dirdjaja",
      "screen_name" : "iDitsch",
      "indices" : [ 0, 8 ],
      "id_str" : "213775941",
      "id" : 213775941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181033489695645698",
  "geo" : { },
  "id_str" : "181033979657469953",
  "in_reply_to_user_id" : 213775941,
  "text" : "@iDitsch das ist mir auch schon aufgefallen. Macht doch mal eine Bildergalerie \u00FCber die Jahre. ;-)",
  "id" : 181033979657469953,
  "in_reply_to_status_id" : 181033489695645698,
  "created_at" : "2012-03-17 15:07:18 +0000",
  "in_reply_to_screen_name" : "iDitsch",
  "in_reply_to_user_id_str" : "213775941",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 0, 15 ],
      "id_str" : "73134122",
      "id" : 73134122
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 33, 43 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 69, 79 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181031376890494978",
  "geo" : { },
  "id_str" : "181031809709113346",
  "in_reply_to_user_id" : 73134122,
  "text" : "@astefanowitsch da \u00FCberlasse ich @Fischblog als Blog-Penis-Experten. #scilogs12",
  "id" : 181031809709113346,
  "in_reply_to_status_id" : 181031376890494978,
  "created_at" : "2012-03-17 14:58:41 +0000",
  "in_reply_to_screen_name" : "astefanowitsch",
  "in_reply_to_user_id_str" : "73134122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 0, 15 ],
      "id_str" : "73134122",
      "id" : 73134122
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181030525866217472",
  "geo" : { },
  "id_str" : "181030975768244225",
  "in_reply_to_user_id" : 73134122,
  "text" : "@astefanowitsch Immerhin habe ich die Evolution der S\u00E4ugetier-Anatomie sogar im Studium gelernt! #scilogs12",
  "id" : 181030975768244225,
  "in_reply_to_status_id" : 181030525866217472,
  "created_at" : "2012-03-17 14:55:22 +0000",
  "in_reply_to_screen_name" : "astefanowitsch",
  "in_reply_to_user_id_str" : "73134122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 4, 19 ],
      "id_str" : "73134122",
      "id" : 73134122
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181029789031858176",
  "text" : "Der @astefanowitsch wird zuk\u00FCnftig Spektrum Neo f\u00FCr seine Seminare verwenden. #scilogs12",
  "id" : 181029789031858176,
  "created_at" : "2012-03-17 14:50:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181014000862113792",
  "geo" : { },
  "id_str" : "181016977597411328",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay, but this isn't to bad. And if autocomplete works than the basic functionality is available. :-)",
  "id" : 181016977597411328,
  "in_reply_to_status_id" : 181014000862113792,
  "created_at" : "2012-03-17 13:59:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181012635498713088",
  "geo" : { },
  "id_str" : "181012866936221696",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay, cool. Does the redirect for the modal work? :)",
  "id" : 181012866936221696,
  "in_reply_to_status_id" : 181012635498713088,
  "created_at" : "2012-03-17 13:43:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181011781257396224",
  "geo" : { },
  "id_str" : "181012460453638144",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, so it works now? :) Great!",
  "id" : 181012460453638144,
  "in_reply_to_status_id" : 181011781257396224,
  "created_at" : "2012-03-17 13:41:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181000219163504641",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4016483904, 8.1918923141 ]
  },
  "id_str" : "181000959336529920",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ...could use the link as redirect-target which I use  on the user_is_user.html.erb?",
  "id" : 181000959336529920,
  "in_reply_to_status_id" : 181000219163504641,
  "created_at" : "2012-03-17 12:56:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181000219163504641",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4020446409, 8.1916522936 ]
  },
  "id_str" : "181000718143066112",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer add the error-display back to the new.html.erb? I removed it somewhere along implementing the modal iirc. Otherwise you...",
  "id" : 181000718143066112,
  "in_reply_to_status_id" : 181000219163504641,
  "created_at" : "2012-03-17 12:55:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180995613553471491",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4015443979, 8.1920658013 ]
  },
  "id_str" : "180999128183087104",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ...redirect to current_users home? Or tweak the create.js.erb to work with this?",
  "id" : 180999128183087104,
  "in_reply_to_status_id" : 180995613553471491,
  "created_at" : "2012-03-17 12:48:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180995613553471491",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4016721267, 8.1920088873 ]
  },
  "id_str" : "180998985912287232",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer user_phenotypes_controller (line 62-64) -&gt; redirect to new if save fails. Should only redirect if non-modal, otherwise...",
  "id" : 180998985912287232,
  "in_reply_to_status_id" : 180995613553471491,
  "created_at" : "2012-03-17 12:48:15 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180995613553471491",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4015956718, 8.1918309835 ]
  },
  "id_str" : "180997959394136065",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer somehow I feel that there should be a 3 line-fix for it, but I can't think of one ;)",
  "id" : 180997959394136065,
  "in_reply_to_status_id" : 180995613553471491,
  "created_at" : "2012-03-17 12:44:10 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180995613553471491",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4013443259, 8.192013334 ]
  },
  "id_str" : "180996203884978176",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer but as said: My JS-knowledge is really limited. That's the reason why I procrastinated the modal-stuff for so long :P",
  "id" : 180996203884978176,
  "in_reply_to_status_id" : 180995613553471491,
  "created_at" : "2012-03-17 12:37:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180995613553471491",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4016785876, 8.1916876012 ]
  },
  "id_str" : "180995873830993920",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, depending on if this is a modal view or not it should perform other re-routings i guess.",
  "id" : 180995873830993920,
  "in_reply_to_status_id" : 180995613553471491,
  "created_at" : "2012-03-17 12:35:53 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180994637375356928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4024005683, 8.1918094249 ]
  },
  "id_str" : "180995064699437057",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer uh, indeed, this is strange. Maybe this is a result of my limited JS-knowledge and too extensive copy&amp;paste? ;)",
  "id" : 180995064699437057,
  "in_reply_to_status_id" : 180994637375356928,
  "created_at" : "2012-03-17 12:32:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180992730992885761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4017526006, 8.1916912916 ]
  },
  "id_str" : "180992813532581888",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay, thanks a lot :)",
  "id" : 180992813532581888,
  "in_reply_to_status_id" : 180992730992885761,
  "created_at" : "2012-03-17 12:23:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180992155840544769",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4018461261, 8.1919219584 ]
  },
  "id_str" : "180992614890348544",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer oh, okay. Can you fix it?",
  "id" : 180992614890348544,
  "in_reply_to_status_id" : 180992155840544769,
  "created_at" : "2012-03-17 12:22:56 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vidar Andersen dot com",
      "screen_name" : "blacktar",
      "indices" : [ 0, 9 ],
      "id_str" : "3453971",
      "id" : 3453971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180988821398237185",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4013912524, 8.1930028747 ]
  },
  "id_str" : "180989289839067136",
  "in_reply_to_user_id" : 3453971,
  "text" : "@blacktar sure, I know how important feedback is :)",
  "id" : 180989289839067136,
  "in_reply_to_status_id" : 180988821398237185,
  "created_at" : "2012-03-17 12:09:43 +0000",
  "in_reply_to_screen_name" : "blacktar",
  "in_reply_to_user_id_str" : "3453971",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 72, 82 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4016695266, 8.1920049349 ]
  },
  "id_str" : "180988562626449409",
  "text" : "\u00ABWir begr\u00FCssen auch die G\u00E4ste aus dem Ausland\u00BB, bestimmt die Bayern die @Fischblog schon angesprochen hat. #scilogs12",
  "id" : 180988562626449409,
  "created_at" : "2012-03-17 12:06:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vidar Andersen dot com",
      "screen_name" : "blacktar",
      "indices" : [ 0, 9 ],
      "id_str" : "3453971",
      "id" : 3453971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180977034879709184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.4017291863, 8.1918855221 ]
  },
  "id_str" : "180988016402251776",
  "in_reply_to_user_id" : 3453971,
  "text" : "@blacktar okay, maybe I'm just unlucky between cell towers. Or it really is a problem of the latest iOS release.",
  "id" : 180988016402251776,
  "in_reply_to_status_id" : 180977034879709184,
  "created_at" : "2012-03-17 12:04:40 +0000",
  "in_reply_to_screen_name" : "blacktar",
  "in_reply_to_user_id_str" : "3453971",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180953556814278658",
  "geo" : { },
  "id_str" : "180954283041230849",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall oh, ich komme auch wieder 11:40 an, aber aus der anderen Richtung. :)",
  "id" : 180954283041230849,
  "in_reply_to_status_id" : 180953556814278658,
  "created_at" : "2012-03-17 09:50:37 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vidar Andersen dot com",
      "screen_name" : "blacktar",
      "indices" : [ 0, 9 ],
      "id_str" : "3453971",
      "id" : 3453971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180940343829741568",
  "geo" : { },
  "id_str" : "180941307236188161",
  "in_reply_to_user_id" : 3453971,
  "text" : "@blacktar i know, you locate using cellphone towers, right?",
  "id" : 180941307236188161,
  "in_reply_to_status_id" : 180940343829741568,
  "created_at" : "2012-03-17 08:59:04 +0000",
  "in_reply_to_screen_name" : "blacktar",
  "in_reply_to_user_id_str" : "3453971",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 40, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180932488972091392",
  "text" : "Mache mich dann auch mal auf den Weg zu #scilogs12",
  "id" : 180932488972091392,
  "created_at" : "2012-03-17 08:24:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/KnZccbFP",
      "expanded_url" : "http:\/\/j.mp\/A3PDkt",
      "display_url" : "j.mp\/A3PDkt"
    } ]
  },
  "geo" : { },
  "id_str" : "180928668854530048",
  "text" : "Wait, forensics in Virginia test 214 DNA samples from 70ies\/80ies and over 70 of those ppl got wrongfully convicted? http:\/\/t.co\/KnZccbFP",
  "id" : 180928668854530048,
  "created_at" : "2012-03-17 08:08:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 3, 13 ],
      "id_str" : "22839233",
      "id" : 22839233
    }, {
      "name" : "Kennedy Lewis",
      "screen_name" : "ncbirofl",
      "indices" : [ 106, 115 ],
      "id_str" : "1664474352",
      "id" : 1664474352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/mRNcp0bX",
      "expanded_url" : "http:\/\/bit.ly\/wPTPSx",
      "display_url" : "bit.ly\/wPTPSx"
    } ]
  },
  "geo" : { },
  "id_str" : "180924213417349121",
  "text" : "RT @kaythaney: Scientific paper on \"human mate poaching\" (or how to be a slag) with bonus table FTW. From @ncbirofl : http:\/\/t.co\/mRNcp0bX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kennedy Lewis",
        "screen_name" : "ncbirofl",
        "indices" : [ 91, 100 ],
        "id_str" : "1664474352",
        "id" : 1664474352
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/mRNcp0bX",
        "expanded_url" : "http:\/\/bit.ly\/wPTPSx",
        "display_url" : "bit.ly\/wPTPSx"
      } ]
    },
    "geo" : { },
    "id_str" : "180923215034589184",
    "text" : "Scientific paper on \"human mate poaching\" (or how to be a slag) with bonus table FTW. From @ncbirofl : http:\/\/t.co\/mRNcp0bX",
    "id" : 180923215034589184,
    "created_at" : "2012-03-17 07:47:10 +0000",
    "user" : {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "protected" : false,
      "id_str" : "22839233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932288468029509632\/_I0e0wgc_normal.jpg",
      "id" : 22839233,
      "verified" : false
    }
  },
  "id" : 180924213417349121,
  "created_at" : "2012-03-17 07:51:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/ur3fU5Ib",
      "expanded_url" : "http:\/\/j.mp\/zCJPz3",
      "display_url" : "j.mp\/zCJPz3"
    } ]
  },
  "geo" : { },
  "id_str" : "180905738313531392",
  "text" : "Too bad: Probably all jokes about invisible masturbating have already been done. http:\/\/t.co\/ur3fU5Ib",
  "id" : 180905738313531392,
  "created_at" : "2012-03-17 06:37:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vidar Andersen dot com",
      "screen_name" : "blacktar",
      "indices" : [ 0, 9 ],
      "id_str" : "3453971",
      "id" : 3453971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180787649156624386",
  "geo" : { },
  "id_str" : "180904154745667584",
  "in_reply_to_user_id" : 3453971,
  "text" : "@blacktar i will try this. But I suspect either it's the iOS-update or Gauss, since nothing else has changed. :(",
  "id" : 180904154745667584,
  "in_reply_to_status_id" : 180787649156624386,
  "created_at" : "2012-03-17 06:31:26 +0000",
  "in_reply_to_screen_name" : "blacktar",
  "in_reply_to_user_id_str" : "3453971",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180901932456607744",
  "geo" : { },
  "id_str" : "180903882430496769",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall gern doch, jetzt muss ich nur warten bis meins geliefert wird am Montag. ;)",
  "id" : 180903882430496769,
  "in_reply_to_status_id" : 180901932456607744,
  "created_at" : "2012-03-17 06:30:21 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180894289155469312",
  "geo" : { },
  "id_str" : "180901289062965248",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall hihi, genau das hatte ich erwartet. :)",
  "id" : 180901289062965248,
  "in_reply_to_status_id" : 180894289155469312,
  "created_at" : "2012-03-17 06:20:02 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180887981358460929",
  "geo" : { },
  "id_str" : "180901118270910464",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn sounds like fun ;)",
  "id" : 180901118270910464,
  "in_reply_to_status_id" : 180887981358460929,
  "created_at" : "2012-03-17 06:19:22 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vidar Andersen dot com",
      "screen_name" : "blacktar",
      "indices" : [ 0, 9 ],
      "id_str" : "3453971",
      "id" : 3453971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180781203614474240",
  "geo" : { },
  "id_str" : "180783788782133248",
  "in_reply_to_user_id" : 3453971,
  "text" : "@blacktar tell me which one you suspect, because I have the same problem. ;)",
  "id" : 180783788782133248,
  "in_reply_to_status_id" : 180781203614474240,
  "created_at" : "2012-03-16 22:33:08 +0000",
  "in_reply_to_screen_name" : "blacktar",
  "in_reply_to_user_id_str" : "3453971",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david ropeik",
      "screen_name" : "dropeik",
      "indices" : [ 3, 11 ],
      "id_str" : "19242750",
      "id" : 19242750
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/g2E3nQOn",
      "expanded_url" : "http:\/\/bit.ly\/AyxhK0",
      "display_url" : "bit.ly\/AyxhK0"
    } ]
  },
  "geo" : { },
  "id_str" : "180765861412470784",
  "text" : "RT @dropeik: Remember The Orgasm Scene in Harry Met Sally? Most \"real\/in the moment\" moans are fake too!  http:\/\/t.co\/g2E3nQOn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/g2E3nQOn",
        "expanded_url" : "http:\/\/bit.ly\/AyxhK0",
        "display_url" : "bit.ly\/AyxhK0"
      } ]
    },
    "geo" : { },
    "id_str" : "180751691208073216",
    "text" : "Remember The Orgasm Scene in Harry Met Sally? Most \"real\/in the moment\" moans are fake too!  http:\/\/t.co\/g2E3nQOn",
    "id" : 180751691208073216,
    "created_at" : "2012-03-16 20:25:36 +0000",
    "user" : {
      "name" : "david ropeik",
      "screen_name" : "dropeik",
      "protected" : false,
      "id_str" : "19242750",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/417813475495141376\/w-w0Okd6_normal.jpeg",
      "id" : 19242750,
      "verified" : false
    }
  },
  "id" : 180765861412470784,
  "created_at" : "2012-03-16 21:21:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel MacArthur",
      "screen_name" : "dgmacarthur",
      "indices" : [ 3, 15 ],
      "id_str" : "16629477",
      "id" : 16629477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/tlnDzuM4",
      "expanded_url" : "http:\/\/news.sciencemag.org\/sciencenow\/2012\/03\/examining-his-own-body-stanford-.html",
      "display_url" : "news.sciencemag.org\/sciencenow\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180752849217658880",
  "text" : "RT @dgmacarthur: Mike Snyder's justification for using himself in his pan-omics project is compelling: http:\/\/t.co\/tlnDzuM4 This wasn't  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/tlnDzuM4",
        "expanded_url" : "http:\/\/news.sciencemag.org\/sciencenow\/2012\/03\/examining-his-own-body-stanford-.html",
        "display_url" : "news.sciencemag.org\/sciencenow\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "180752209401749506",
    "text" : "Mike Snyder's justification for using himself in his pan-omics project is compelling: http:\/\/t.co\/tlnDzuM4 This wasn't narcissism.",
    "id" : 180752209401749506,
    "created_at" : "2012-03-16 20:27:39 +0000",
    "user" : {
      "name" : "Daniel MacArthur",
      "screen_name" : "dgmacarthur",
      "protected" : false,
      "id_str" : "16629477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/856238606507180033\/GWLCCqUC_normal.jpg",
      "id" : 16629477,
      "verified" : false
    }
  },
  "id" : 180752849217658880,
  "created_at" : "2012-03-16 20:30:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180749404439973888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097853844, 8.2831662151 ]
  },
  "id_str" : "180749604046897152",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus stimmt, die noch nicht. :)",
  "id" : 180749604046897152,
  "in_reply_to_status_id" : 180749404439973888,
  "created_at" : "2012-03-16 20:17:18 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180746498944933888",
  "geo" : { },
  "id_str" : "180748580695457794",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus Da sind wir aber schon bei der aktuellen Folge der aktuellen Staffel :P",
  "id" : 180748580695457794,
  "in_reply_to_status_id" : 180746498944933888,
  "created_at" : "2012-03-16 20:13:14 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "indices" : [ 0, 14 ],
      "id_str" : "112475924",
      "id" : 112475924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180729713759756288",
  "geo" : { },
  "id_str" : "180730925963939841",
  "in_reply_to_user_id" : 112475924,
  "text" : "@JacquelynGill But it looks like they stopped this (at least the last post was published in November of last year).",
  "id" : 180730925963939841,
  "in_reply_to_status_id" : 180729713759756288,
  "created_at" : "2012-03-16 19:03:05 +0000",
  "in_reply_to_screen_name" : "JacquelynGill",
  "in_reply_to_user_id_str" : "112475924",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "indices" : [ 0, 14 ],
      "id_str" : "112475924",
      "id" : 112475924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/7HneN8Md",
      "expanded_url" : "http:\/\/www.forschungs-blog.de\/category\/dual\/",
      "display_url" : "forschungs-blog.de\/category\/dual\/"
    } ]
  },
  "in_reply_to_status_id_str" : "180729713759756288",
  "geo" : { },
  "id_str" : "180730787853901825",
  "in_reply_to_user_id" : 112475924,
  "text" : "@JacquelynGill There's a german blog which tried this. Left column scientific, right wider public. http:\/\/t.co\/7HneN8Md",
  "id" : 180730787853901825,
  "in_reply_to_status_id" : 180729713759756288,
  "created_at" : "2012-03-16 19:02:32 +0000",
  "in_reply_to_screen_name" : "JacquelynGill",
  "in_reply_to_user_id_str" : "112475924",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u043Enasterium",
      "screen_name" : "monasterium",
      "indices" : [ 0, 12 ],
      "id_str" : "15126396",
      "id" : 15126396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180728481443872768",
  "geo" : { },
  "id_str" : "180728579137617920",
  "in_reply_to_user_id" : 15126396,
  "text" : "@monasterium okay",
  "id" : 180728579137617920,
  "in_reply_to_status_id" : 180728481443872768,
  "created_at" : "2012-03-16 18:53:45 +0000",
  "in_reply_to_screen_name" : "monasterium",
  "in_reply_to_user_id_str" : "15126396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u043Enasterium",
      "screen_name" : "monasterium",
      "indices" : [ 0, 12 ],
      "id_str" : "15126396",
      "id" : 15126396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180727174834298880",
  "geo" : { },
  "id_str" : "180727453134757888",
  "in_reply_to_user_id" : 15126396,
  "text" : "@monasterium Hab schon eine Adresse gefunden. M\u00FCsstest eMail haben.",
  "id" : 180727453134757888,
  "in_reply_to_status_id" : 180727174834298880,
  "created_at" : "2012-03-16 18:49:17 +0000",
  "in_reply_to_screen_name" : "monasterium",
  "in_reply_to_user_id_str" : "15126396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u043Enasterium",
      "screen_name" : "monasterium",
      "indices" : [ 0, 12 ],
      "id_str" : "15126396",
      "id" : 15126396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180727051538534400",
  "geo" : { },
  "id_str" : "180727070513565696",
  "in_reply_to_user_id" : 15126396,
  "text" : "@monasterium jo",
  "id" : 180727070513565696,
  "in_reply_to_status_id" : 180727051538534400,
  "created_at" : "2012-03-16 18:47:46 +0000",
  "in_reply_to_screen_name" : "monasterium",
  "in_reply_to_user_id_str" : "15126396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u043Enasterium",
      "screen_name" : "monasterium",
      "indices" : [ 0, 12 ],
      "id_str" : "15126396",
      "id" : 15126396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180722854973808640",
  "geo" : { },
  "id_str" : "180726956097155072",
  "in_reply_to_user_id" : 15126396,
  "text" : "@monasterium brauchst du noch? wenn ja wohin",
  "id" : 180726956097155072,
  "in_reply_to_status_id" : 180722854973808640,
  "created_at" : "2012-03-16 18:47:18 +0000",
  "in_reply_to_screen_name" : "monasterium",
  "in_reply_to_user_id_str" : "15126396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 49, 60 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/180704636632698880\/photo\/1",
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/mBNUJxKB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoH96NwCEAAEbpY.png",
      "id_str" : "180704636636893184",
      "id" : 180704636636893184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoH96NwCEAAEbpY.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 1510
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 1510
      }, {
        "h" : 904,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/mBNUJxKB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180704636632698880",
  "text" : "Currently testing the recommendation-feature for @openSNPorg http:\/\/t.co\/mBNUJxKB",
  "id" : 180704636632698880,
  "created_at" : "2012-03-16 17:18:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180695369515147266",
  "geo" : { },
  "id_str" : "180697138941014016",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 Und schon gut gefeiert?",
  "id" : 180697138941014016,
  "in_reply_to_status_id" : 180695369515147266,
  "created_at" : "2012-03-16 16:48:49 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180690623337209856",
  "geo" : { },
  "id_str" : "180695222680956928",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 Oh, das wollte mir Facebook also mitteilen. ;-) Alles Gute!",
  "id" : 180695222680956928,
  "in_reply_to_status_id" : 180690623337209856,
  "created_at" : "2012-03-16 16:41:12 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180685641087074305",
  "geo" : { },
  "id_str" : "180685886399324160",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Einfach \u00FCber den Kopf ziehen und 2 L\u00F6cher reinschneiden. Fertig! ;)",
  "id" : 180685886399324160,
  "in_reply_to_status_id" : 180685641087074305,
  "created_at" : "2012-03-16 16:04:06 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180685319459454977",
  "geo" : { },
  "id_str" : "180685439013888000",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Hattest du nicht vor 2(?) Jahren die Kochm\u00FCtze bekommen? ;)",
  "id" : 180685439013888000,
  "in_reply_to_status_id" : 180685319459454977,
  "created_at" : "2012-03-16 16:02:20 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/agkwvrTW",
      "expanded_url" : "http:\/\/www.wired.com\/epicenter\/2012\/03\/wikipedia-didnt-kill-brittanica-windows-did\/",
      "display_url" : "wired.com\/epicenter\/2012\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180655248296263681",
  "text" : "Britannica went bankrupt in 1996, long before Wikipedia [...] What happened in between was Encarta. http:\/\/t.co\/agkwvrTW",
  "id" : 180655248296263681,
  "created_at" : "2012-03-16 14:02:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobias Maier",
      "screen_name" : "weitergen",
      "indices" : [ 0, 10 ],
      "id_str" : "14717573",
      "id" : 14717573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180651084732309504",
  "geo" : { },
  "id_str" : "180651639483547648",
  "in_reply_to_user_id" : 14717573,
  "text" : "@weitergen Bei Tweetbot kann man \u00FCber einen Klick die Haupt-Timeline durch Listen ersetzen.",
  "id" : 180651639483547648,
  "in_reply_to_status_id" : 180651084732309504,
  "created_at" : "2012-03-16 13:48:01 +0000",
  "in_reply_to_screen_name" : "weitergen",
  "in_reply_to_user_id_str" : "14717573",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/gthzUO45",
      "expanded_url" : "http:\/\/j.mp\/AwH8nm",
      "display_url" : "j.mp\/AwH8nm"
    } ]
  },
  "geo" : { },
  "id_str" : "180613975468281856",
  "text" : "Caramel Color Carcinogens -- Bring Back Crystal Pepsi http:\/\/t.co\/gthzUO45",
  "id" : 180613975468281856,
  "created_at" : "2012-03-16 11:18:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Scrimshaw",
      "screen_name" : "JosephScrimshaw",
      "indices" : [ 3, 19 ],
      "id_str" : "80680964",
      "id" : 80680964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180417264925933570",
  "text" : "RT @JosephScrimshaw: People are losing the spirit of the Ides of March. It's not about just stabbing. It's about coming together to stab ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "180315651490066432",
    "text" : "People are losing the spirit of the Ides of March. It's not about just stabbing. It's about coming together to stab in groups.",
    "id" : 180315651490066432,
    "created_at" : "2012-03-15 15:32:56 +0000",
    "user" : {
      "name" : "Joseph Scrimshaw",
      "screen_name" : "JosephScrimshaw",
      "protected" : false,
      "id_str" : "80680964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1201776450\/JSwithYodatwit_normal.jpg",
      "id" : 80680964,
      "verified" : true
    }
  },
  "id" : 180417264925933570,
  "created_at" : "2012-03-15 22:16:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 20, 29 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/raHKMFSH",
      "expanded_url" : "http:\/\/www.g4tv.com\/thefeed\/blog\/post\/721787\/baldurs-gate-enhanced-edition-announced\/?cmpid=sn-120221-twitter-na-twitterfantrack",
      "display_url" : "g4tv.com\/thefeed\/blog\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180392388982882305",
  "text" : "Einmal Nerdgasm f\u00FCr @Senficon: Baldur's Gate Enhanced http:\/\/t.co\/raHKMFSH",
  "id" : 180392388982882305,
  "created_at" : "2012-03-15 20:37:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pierre Lindenbaum",
      "screen_name" : "yokofakun",
      "indices" : [ 3, 13 ],
      "id_str" : "7431072",
      "id" : 7431072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/BaEAlut5",
      "expanded_url" : "http:\/\/sites.google.com\/site\/worlddump1\/",
      "display_url" : "sites.google.com\/site\/worlddump\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180363982476025856",
  "text" : "RT @yokofakun: The World's biggest fake\nconference in computer science http:\/\/t.co\/BaEAlut5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/BaEAlut5",
        "expanded_url" : "http:\/\/sites.google.com\/site\/worlddump1\/",
        "display_url" : "sites.google.com\/site\/worlddump\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "180350428691693569",
    "text" : "The World's biggest fake\nconference in computer science http:\/\/t.co\/BaEAlut5",
    "id" : 180350428691693569,
    "created_at" : "2012-03-15 17:51:07 +0000",
    "user" : {
      "name" : "Pierre Lindenbaum",
      "screen_name" : "yokofakun",
      "protected" : false,
      "id_str" : "7431072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667105051664609280\/jQ6Ile6W_normal.jpg",
      "id" : 7431072,
      "verified" : false
    }
  },
  "id" : 180363982476025856,
  "created_at" : "2012-03-15 18:44:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 61, 70 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/NRYiz2Go",
      "expanded_url" : "http:\/\/j.mp\/xiumcj",
      "display_url" : "j.mp\/xiumcj"
    } ]
  },
  "geo" : { },
  "id_str" : "180358889747910656",
  "text" : "Copyright Math: The $8 billion iPod http:\/\/t.co\/NRYiz2Go \/cc @Senficon",
  "id" : 180358889747910656,
  "created_at" : "2012-03-15 18:24:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/DQX11BSv",
      "expanded_url" : "http:\/\/j.mp\/y9OfE3",
      "display_url" : "j.mp\/y9OfE3"
    } ]
  },
  "geo" : { },
  "id_str" : "180357251918348289",
  "text" : "RNA editing: \u00ABWhy I think nearly all of the RDD sites in Li et al. are false positives\u00BB http:\/\/t.co\/DQX11BSv",
  "id" : 180357251918348289,
  "created_at" : "2012-03-15 18:18:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/tyiVxmDs",
      "expanded_url" : "http:\/\/j.mp\/x64ldC",
      "display_url" : "j.mp\/x64ldC"
    } ]
  },
  "geo" : { },
  "id_str" : "180355612411052032",
  "text" : "The Man Who Broke Atlantic City http:\/\/t.co\/tyiVxmDs",
  "id" : 180355612411052032,
  "created_at" : "2012-03-15 18:11:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "indices" : [ 3, 18 ],
      "id_str" : "19416598",
      "id" : 19416598
    }, {
      "name" : "Willem van Schaik",
      "screen_name" : "WvSchaik",
      "indices" : [ 52, 61 ],
      "id_str" : "18585425",
      "id" : 18585425
    }, {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 130, 140 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/0EpMuZnc",
      "expanded_url" : "http:\/\/goo.gl\/xSAzW",
      "display_url" : "goo.gl\/xSAzW"
    } ]
  },
  "geo" : { },
  "id_str" : "180336855500324864",
  "text" : "RT @leonidkruglyak: FYI: I'm a heavy weapons guy RT @WvSchaik: Awesome! The nine types of peer reviewers: http:\/\/t.co\/0EpMuZnc HT @edyong209",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Willem van Schaik",
        "screen_name" : "WvSchaik",
        "indices" : [ 32, 41 ],
        "id_str" : "18585425",
        "id" : 18585425
      }, {
        "name" : "Ed Yong",
        "screen_name" : "edyong209",
        "indices" : [ 110, 120 ],
        "id_str" : "19767193",
        "id" : 19767193
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/0EpMuZnc",
        "expanded_url" : "http:\/\/goo.gl\/xSAzW",
        "display_url" : "goo.gl\/xSAzW"
      } ]
    },
    "geo" : { },
    "id_str" : "180328000888381440",
    "text" : "FYI: I'm a heavy weapons guy RT @WvSchaik: Awesome! The nine types of peer reviewers: http:\/\/t.co\/0EpMuZnc HT @edyong209",
    "id" : 180328000888381440,
    "created_at" : "2012-03-15 16:22:00 +0000",
    "user" : {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "protected" : false,
      "id_str" : "19416598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1095542276\/MyRecentPhoto_normal.jpg",
      "id" : 19416598,
      "verified" : false
    }
  },
  "id" : 180336855500324864,
  "created_at" : "2012-03-15 16:57:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/BhxbJLAU",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/hFvOMTOpqTQ\/bunnie-huangs-open-geiger-co.html",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.01106023, 8.28296452 ]
  },
  "id_str" : "180321635923017729",
  "text" : "Bunnie Huang's open Geiger counter: design notes and reference http:\/\/t.co\/BhxbJLAU",
  "id" : 180321635923017729,
  "created_at" : "2012-03-15 15:56:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 56, 65 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 66, 78 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/x197whNU",
      "expanded_url" : "http:\/\/gigaom.com\/2012\/03\/14\/this-is-cool-an-open-data-standard-for-food\/",
      "display_url" : "gigaom.com\/2012\/03\/14\/thi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180288040189706240",
  "text" : "An open data standard for food http:\/\/t.co\/x197whNU \/cc @Senficon @herr_schrat",
  "id" : 180288040189706240,
  "created_at" : "2012-03-15 13:43:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179972618043133953",
  "geo" : { },
  "id_str" : "180267084150874113",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch \u00DCbrigens: Hast du irgendwann\u2122 mal Zeit dich an dem Modal-Zeug f\u00FCr die Phenotypen-Eingabe zu versuchen? :)",
  "id" : 180267084150874113,
  "in_reply_to_status_id" : 179972618043133953,
  "created_at" : "2012-03-15 12:19:56 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180245937753571328",
  "text" : "Single Malt und Gin, das perfekte Trainingscamp f\u00FCr #scilogs12",
  "id" : 180245937753571328,
  "created_at" : "2012-03-15 10:55:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/fI6TRDXF",
      "expanded_url" : "http:\/\/j.mp\/yfdEC7",
      "display_url" : "j.mp\/yfdEC7"
    } ]
  },
  "geo" : { },
  "id_str" : "180238171412496384",
  "text" : "Synonymous Codon Ordering: A Subtle but Prevalent Strategy of Bacteria to Improve Translational Efficiency http:\/\/t.co\/fI6TRDXF",
  "id" : 180238171412496384,
  "created_at" : "2012-03-15 10:25:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/ZczpsXtB",
      "expanded_url" : "http:\/\/j.mp\/AqnjuZ",
      "display_url" : "j.mp\/AqnjuZ"
    } ]
  },
  "geo" : { },
  "id_str" : "180237535350489089",
  "text" : "The Republican War on \u03C0 http:\/\/t.co\/ZczpsXtB",
  "id" : 180237535350489089,
  "created_at" : "2012-03-15 10:22:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 70, 83 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/DzYtQKSw",
      "expanded_url" : "http:\/\/j.mp\/zrsFo9",
      "display_url" : "j.mp\/zrsFo9"
    } ]
  },
  "geo" : { },
  "id_str" : "180235801169367040",
  "text" : "How to Pet a Colombian Hercules Beetle Larva http:\/\/t.co\/DzYtQKSw \/cc @Naturalismus",
  "id" : 180235801169367040,
  "created_at" : "2012-03-15 10:15:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rin Raeuber",
      "screen_name" : "rinpaku",
      "indices" : [ 0, 8 ],
      "id_str" : "195489657",
      "id" : 195489657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180213029823193088",
  "geo" : { },
  "id_str" : "180224670287671296",
  "in_reply_to_user_id" : 8018382,
  "text" : "@rinpaku donde esta la biblioteca!",
  "id" : 180224670287671296,
  "in_reply_to_status_id" : 180213029823193088,
  "created_at" : "2012-03-15 09:31:24 +0000",
  "in_reply_to_screen_name" : "rinrae",
  "in_reply_to_user_id_str" : "8018382",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 36, 47 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/Z81GS4io",
      "expanded_url" : "http:\/\/www.biotechnologie.de\/BIO\/Navigation\/DE\/root,did=149634.html?listBlId=74462",
      "display_url" : "biotechnologie.de\/BIO\/Navigation\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180004400599797760",
  "text" : "Oh, Biotechnologie.de hat auch \u00FCber @openSNPorg berichtet: http:\/\/t.co\/Z81GS4io",
  "id" : 180004400599797760,
  "created_at" : "2012-03-14 18:56:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andi Wolfe",
      "screen_name" : "AndiWolfe",
      "indices" : [ 3, 13 ],
      "id_str" : "33752609",
      "id" : 33752609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/v5VXKjZM",
      "expanded_url" : "http:\/\/www.physorg.com\/news\/2012-03-darwin-wallace-mystery.html",
      "display_url" : "physorg.com\/news\/2012-03-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "179976661444476928",
  "text" : "RT @AndiWolfe: The Darwin-Wallace mystery solved: http:\/\/t.co\/v5VXKjZM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/v5VXKjZM",
        "expanded_url" : "http:\/\/www.physorg.com\/news\/2012-03-darwin-wallace-mystery.html",
        "display_url" : "physorg.com\/news\/2012-03-d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "179975041402937344",
    "text" : "The Darwin-Wallace mystery solved: http:\/\/t.co\/v5VXKjZM",
    "id" : 179975041402937344,
    "created_at" : "2012-03-14 16:59:28 +0000",
    "user" : {
      "name" : "Andi Wolfe",
      "screen_name" : "AndiWolfe",
      "protected" : false,
      "id_str" : "33752609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/254419392\/andi.everest.pic.profile.jpg_normal.jpg",
      "id" : 33752609,
      "verified" : false
    }
  },
  "id" : 179976661444476928,
  "created_at" : "2012-03-14 17:05:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179972618043133953",
  "geo" : { },
  "id_str" : "179972760779497472",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch Ganz offensichtlich. Hatte gar nicht dr\u00FCber nachgedacht das der Pfad nicht jedes mal neu erzeugt wird. :)",
  "id" : 179972760779497472,
  "in_reply_to_status_id" : 179972618043133953,
  "created_at" : "2012-03-14 16:50:24 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179971632721444864",
  "geo" : { },
  "id_str" : "179972175862841346",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch Aber ja: funktioniert. Tausend Dank :)",
  "id" : 179972175862841346,
  "in_reply_to_status_id" : 179971632721444864,
  "created_at" : "2012-03-14 16:48:05 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179971632721444864",
  "geo" : { },
  "id_str" : "179971844760285184",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch Ah, ic. Fehlender Wechsel wieder nach oben ins Verzeichnis. H\u00E4tte ich auch drauf kommen k\u00F6nnen m(",
  "id" : 179971844760285184,
  "in_reply_to_status_id" : 179971632721444864,
  "created_at" : "2012-03-14 16:46:46 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179970364900786176",
  "geo" : { },
  "id_str" : "179970774394880000",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch naja, wenn das nicht hilft mach ich mal echo pwd ;)",
  "id" : 179970774394880000,
  "in_reply_to_status_id" : 179970364900786176,
  "created_at" : "2012-03-14 16:42:30 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179970364900786176",
  "geo" : { },
  "id_str" : "179970508618612736",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch cd .. &amp;&amp; cp config\/database.yml.ci config\/database.yml meinste? ;)",
  "id" : 179970508618612736,
  "in_reply_to_status_id" : 179970364900786176,
  "created_at" : "2012-03-14 16:41:27 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/N1uDYaxe",
      "expanded_url" : "http:\/\/j.mp\/em1368",
      "display_url" : "j.mp\/em1368"
    } ]
  },
  "geo" : { },
  "id_str" : "179969887647694849",
  "text" : "The Unexpected Return of 'Duck and Cover' http:\/\/t.co\/N1uDYaxe",
  "id" : 179969887647694849,
  "created_at" : "2012-03-14 16:38:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179958719096950785",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch Ich weiss du bist besch\u00E4ftigt. Aber wenn du mal 5 Minuten hast dann schau mal auf die openSNP-Mailingliste wg. Travis. :)",
  "id" : 179958719096950785,
  "created_at" : "2012-03-14 15:54:36 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179955888050802688",
  "geo" : { },
  "id_str" : "179955915078897664",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat ah, okay :)",
  "id" : 179955915078897664,
  "in_reply_to_status_id" : 179955888050802688,
  "created_at" : "2012-03-14 15:43:28 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    }, {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 23, 32 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179946617594593281",
  "geo" : { },
  "id_str" : "179955564820963329",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Kommt der @snooze82 auch vorbei? ;)",
  "id" : 179955564820963329,
  "in_reply_to_status_id" : 179946617594593281,
  "created_at" : "2012-03-14 15:42:04 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 50, 61 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179920054740193280",
  "text" : "Working on a phenotype-recommendation-feature for @openSNPorg",
  "id" : 179920054740193280,
  "created_at" : "2012-03-14 13:20:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179880210815131648",
  "text" : "Searching for a DAS-server which provides dbSNP-data for the NCBI 36 coordinate system.",
  "id" : 179880210815131648,
  "created_at" : "2012-03-14 10:42:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/M5tjSuBh",
      "expanded_url" : "http:\/\/j.mp\/zoWYPI",
      "display_url" : "j.mp\/zoWYPI"
    } ]
  },
  "geo" : { },
  "id_str" : "179875812475011073",
  "text" : "Visiting a live poultry market http:\/\/t.co\/M5tjSuBh",
  "id" : 179875812475011073,
  "created_at" : "2012-03-14 10:25:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Cockell",
      "screen_name" : "sjcockell",
      "indices" : [ 3, 13 ],
      "id_str" : "15084702",
      "id" : 15084702
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greader",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/33HDL5lr",
      "expanded_url" : "http:\/\/dlvr.it\/1JySBy",
      "display_url" : "dlvr.it\/1JySBy"
    } ]
  },
  "geo" : { },
  "id_str" : "179874038380900352",
  "text" : "RT @sjcockell: Rubber Duck Problem Solving http:\/\/t.co\/33HDL5lr #greader",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "greader",
        "indices" : [ 49, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/33HDL5lr",
        "expanded_url" : "http:\/\/dlvr.it\/1JySBy",
        "display_url" : "dlvr.it\/1JySBy"
      } ]
    },
    "geo" : { },
    "id_str" : "179873523441999873",
    "text" : "Rubber Duck Problem Solving http:\/\/t.co\/33HDL5lr #greader",
    "id" : 179873523441999873,
    "created_at" : "2012-03-14 10:16:04 +0000",
    "user" : {
      "name" : "Simon Cockell",
      "screen_name" : "sjcockell",
      "protected" : false,
      "id_str" : "15084702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671629143310749696\/6M9y-H4J_normal.png",
      "id" : 15084702,
      "verified" : false
    }
  },
  "id" : 179874038380900352,
  "created_at" : "2012-03-14 10:18:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/eb6HglO2",
      "expanded_url" : "http:\/\/j.mp\/xfchBE",
      "display_url" : "j.mp\/xfchBE"
    } ]
  },
  "geo" : { },
  "id_str" : "179867849874087937",
  "text" : "Why passphrases may not be the answer http:\/\/t.co\/eb6HglO2",
  "id" : 179867849874087937,
  "created_at" : "2012-03-14 09:53:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/7QHG1vlm",
      "expanded_url" : "http:\/\/j.mp\/AtVXGw",
      "display_url" : "j.mp\/AtVXGw"
    } ]
  },
  "geo" : { },
  "id_str" : "179866801449078784",
  "text" : "Machine Pareidolia: Hello Little Fella Meets FaceTracker http:\/\/t.co\/7QHG1vlm",
  "id" : 179866801449078784,
  "created_at" : "2012-03-14 09:49:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179847197330898944",
  "text" : "RT @PhilippBayer: \"Does sex speed up evolutionary rate and increase bio diversity?\" An excursion into theoretical biology http:\/\/t.co\/Jn ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/JnpCLC0u",
        "expanded_url" : "http:\/\/www.ploscompbiol.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pcbi.1002414?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ploscompbiol%2FNewArticles+%28Ambra+-+Computational+Biology+New+Articles%29",
        "display_url" : "ploscompbiol.org\/article\/info%3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "179846003480989696",
    "text" : "\"Does sex speed up evolutionary rate and increase bio diversity?\" An excursion into theoretical biology http:\/\/t.co\/JnpCLC0u",
    "id" : 179846003480989696,
    "created_at" : "2012-03-14 08:26:43 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 179847197330898944,
  "created_at" : "2012-03-14 08:31:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i have a 50 character name that says ban the nazis",
      "screen_name" : "sanczny",
      "indices" : [ 3, 11 ],
      "id_str" : "204805926",
      "id" : 204805926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/8644dQol",
      "expanded_url" : "http:\/\/sanczny.wordpress.com\/2012\/03\/13\/popender-trouble\/",
      "display_url" : "sanczny.wordpress.com\/2012\/03\/13\/pop\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "179842819257679872",
  "text" : "RT @sanczny: \u00FCber das genderpopender in der piratenpartei http:\/\/t.co\/8644dQol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/hotot.org\" rel=\"nofollow\"\u003EHotot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/8644dQol",
        "expanded_url" : "http:\/\/sanczny.wordpress.com\/2012\/03\/13\/popender-trouble\/",
        "display_url" : "sanczny.wordpress.com\/2012\/03\/13\/pop\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "179704813720838144",
    "text" : "\u00FCber das genderpopender in der piratenpartei http:\/\/t.co\/8644dQol",
    "id" : 179704813720838144,
    "created_at" : "2012-03-13 23:05:41 +0000",
    "user" : {
      "name" : "i have a 50 character name that says ban the nazis",
      "screen_name" : "sanczny",
      "protected" : false,
      "id_str" : "204805926",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/914897762453524480\/boxCeth0_normal.jpg",
      "id" : 204805926,
      "verified" : false
    }
  },
  "id" : 179842819257679872,
  "created_at" : "2012-03-14 08:14:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 3, 18 ],
      "id_str" : "645353",
      "id" : 645353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/reV1Fl06",
      "expanded_url" : "http:\/\/vonbrunk.tumblr.com\/",
      "display_url" : "vonbrunk.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "179841657628405760",
  "text" : "RT @unimatrixZxero: if you are a nerd, you will have a nerdgasm when you see this: http:\/\/t.co\/reV1Fl06",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/reV1Fl06",
        "expanded_url" : "http:\/\/vonbrunk.tumblr.com\/",
        "display_url" : "vonbrunk.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "179838201400270848",
    "text" : "if you are a nerd, you will have a nerdgasm when you see this: http:\/\/t.co\/reV1Fl06",
    "id" : 179838201400270848,
    "created_at" : "2012-03-14 07:55:43 +0000",
    "user" : {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "protected" : false,
      "id_str" : "645353",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2041971609\/rage_face_me_100px_normal.gif",
      "id" : 645353,
      "verified" : false
    }
  },
  "id" : 179841657628405760,
  "created_at" : "2012-03-14 08:09:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/wbpyJnod",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/inxile\/wasteland-2?ref=user_categories",
      "display_url" : "kickstarter.com\/projects\/inxil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "179680142472380416",
  "text" : "You should give all your money to Brian Fargo so he can create a sequel to \u00ABWasteland\u00BB http:\/\/t.co\/wbpyJnod",
  "id" : 179680142472380416,
  "created_at" : "2012-03-13 21:27:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/Z6KIk0KI",
      "expanded_url" : "http:\/\/i.imgur.com\/eaJdr.jpg",
      "display_url" : "i.imgur.com\/eaJdr.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "179568611197861888",
  "text" : "Why God never received a PhD http:\/\/t.co\/Z6KIk0KI",
  "id" : 179568611197861888,
  "created_at" : "2012-03-13 14:04:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/aFjVEmdv",
      "expanded_url" : "http:\/\/j.mp\/wEQjVv",
      "display_url" : "j.mp\/wEQjVv"
    } ]
  },
  "geo" : { },
  "id_str" : "179530958666612736",
  "text" : "The psychological cost of being a stripper http:\/\/t.co\/aFjVEmdv",
  "id" : 179530958666612736,
  "created_at" : "2012-03-13 11:34:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeorgeMonbiot",
      "screen_name" : "GeorgeMonbiot",
      "indices" : [ 3, 17 ],
      "id_str" : "198584761",
      "id" : 198584761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/Yk8Y3KqR",
      "expanded_url" : "http:\/\/bit.ly\/zmmBQc",
      "display_url" : "bit.ly\/zmmBQc"
    } ]
  },
  "geo" : { },
  "id_str" : "179492882535813120",
  "text" : "RT @GeorgeMonbiot: Even if you won't cut meat consumption for eco & humanitarian reasons, do it for yourself: http:\/\/t.co\/Yk8Y3KqR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/Yk8Y3KqR",
        "expanded_url" : "http:\/\/bit.ly\/zmmBQc",
        "display_url" : "bit.ly\/zmmBQc"
      } ]
    },
    "geo" : { },
    "id_str" : "179483026663800833",
    "text" : "Even if you won't cut meat consumption for eco & humanitarian reasons, do it for yourself: http:\/\/t.co\/Yk8Y3KqR",
    "id" : 179483026663800833,
    "created_at" : "2012-03-13 08:24:22 +0000",
    "user" : {
      "name" : "GeorgeMonbiot",
      "screen_name" : "GeorgeMonbiot",
      "protected" : false,
      "id_str" : "198584761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3594607450\/ff6fbd42964f9a0def79d8acbfa034bd_normal.jpeg",
      "id" : 198584761,
      "verified" : false
    }
  },
  "id" : 179492882535813120,
  "created_at" : "2012-03-13 09:03:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179126483447578624",
  "geo" : { },
  "id_str" : "179490277239697408",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer did you stop and did duck &amp; cover? ;)",
  "id" : 179490277239697408,
  "in_reply_to_status_id" : 179126483447578624,
  "created_at" : "2012-03-13 08:53:11 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaspar Schiess",
      "screen_name" : "kasparschiess",
      "indices" : [ 53, 67 ],
      "id_str" : "102627198",
      "id" : 102627198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/vyciulgs",
      "expanded_url" : "http:\/\/sendthemyourmoney.com\/",
      "display_url" : "sendthemyourmoney.com"
    } ]
  },
  "geo" : { },
  "id_str" : "179485300500856832",
  "text" : "Dear content industry: Shut up and take my money. RT @kasparschiess: Ok guys, let's send them money. Cash. http:\/\/t.co\/vyciulgs",
  "id" : 179485300500856832,
  "created_at" : "2012-03-13 08:33:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179346040703561731",
  "geo" : { },
  "id_str" : "179346342743777280",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn who cares about lactose-intolerance if you can write about penis lengths!",
  "id" : 179346342743777280,
  "in_reply_to_status_id" : 179346040703561731,
  "created_at" : "2012-03-12 23:21:14 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179343955807322113",
  "geo" : { },
  "id_str" : "179345789125009408",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn should be a classic example of either nobody enters it or at least we should expect a bias in entered variation.",
  "id" : 179345789125009408,
  "in_reply_to_status_id" : 179343955807322113,
  "created_at" : "2012-03-12 23:19:02 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179343955807322113",
  "geo" : { },
  "id_str" : "179345516402970624",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn but this would be awesome as well. ;) And I'm interested in who many ppl will give information about your penis-phenotypes.",
  "id" : 179345516402970624,
  "in_reply_to_status_id" : 179343955807322113,
  "created_at" : "2012-03-12 23:17:57 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/pF9EkJ3i",
      "expanded_url" : "http:\/\/opensnp.org\/phenotypes\/64",
      "display_url" : "opensnp.org\/phenotypes\/64"
    } ]
  },
  "in_reply_to_status_id_str" : "179342159261085696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097571023, 8.2831304263 ]
  },
  "id_str" : "179343320642879489",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn what is your variation on this phenotype: http:\/\/t.co\/pF9EkJ3i",
  "id" : 179343320642879489,
  "in_reply_to_status_id" : 179342159261085696,
  "created_at" : "2012-03-12 23:09:14 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 62, 75 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/nlXuQFqt",
      "expanded_url" : "http:\/\/opensnp.org\/phenotypes\/76#description",
      "display_url" : "opensnp.org\/phenotypes\/76#\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097413586, 8.2831424611 ]
  },
  "id_str" : "179342280023482369",
  "text" : "For months I waited for somebody to start this phenotype. Now @iameltonjohn did it: http:\/\/t.co\/nlXuQFqt",
  "id" : 179342280023482369,
  "created_at" : "2012-03-12 23:05:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097542354, 8.283160404 ]
  },
  "id_str" : "179338915029856258",
  "text" : "\u00ABCorn is the protocapitalist plant\u00BB",
  "id" : 179338915029856258,
  "created_at" : "2012-03-12 22:51:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/gP3bnkWE",
      "expanded_url" : "http:\/\/j.mp\/yh4UfN",
      "display_url" : "j.mp\/yh4UfN"
    } ]
  },
  "geo" : { },
  "id_str" : "179287419303108609",
  "text" : "So we just have to put 15 million out of work to save the oceans? http:\/\/t.co\/gP3bnkWE",
  "id" : 179287419303108609,
  "created_at" : "2012-03-12 19:27:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/l8Do0vCW",
      "expanded_url" : "http:\/\/j.mp\/xBCmiz",
      "display_url" : "j.mp\/xBCmiz"
    } ]
  },
  "geo" : { },
  "id_str" : "179285636359012354",
  "text" : "No Pulse: How Doctors Reinvented The Human Heart http:\/\/t.co\/l8Do0vCW",
  "id" : 179285636359012354,
  "created_at" : "2012-03-12 19:20:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raichoo",
      "screen_name" : "raichoo",
      "indices" : [ 3, 11 ],
      "id_str" : "32865583",
      "id" : 32865583
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheist",
      "indices" : [ 30, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/cSkpQ7RL",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=v8-LAnnI_LQ",
      "display_url" : "youtube.com\/watch?v=v8-LAn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "179279471550005249",
  "text" : "RT @raichoo: How To Become An #atheist http:\/\/t.co\/cSkpQ7RL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "atheist",
        "indices" : [ 17, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 26, 46 ],
        "url" : "http:\/\/t.co\/cSkpQ7RL",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=v8-LAnnI_LQ",
        "display_url" : "youtube.com\/watch?v=v8-LAn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "179278767137619968",
    "text" : "How To Become An #atheist http:\/\/t.co\/cSkpQ7RL",
    "id" : 179278767137619968,
    "created_at" : "2012-03-12 18:52:43 +0000",
    "user" : {
      "name" : "raichoo",
      "screen_name" : "raichoo",
      "protected" : false,
      "id_str" : "32865583",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227439864\/Foto_am_30-06-2010_um_16.53__2_normal.jpg",
      "id" : 32865583,
      "verified" : false
    }
  },
  "id" : 179279471550005249,
  "created_at" : "2012-03-12 18:55:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/kuaspgeB",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/R5GPiPtcu8o\/kony-2012-invisible-children.html",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0114095939, 8.2828774149 ]
  },
  "id_str" : "179279265488060416",
  "text" : "Kony 2012's Visible Funding: Invisible Children's anti-gay, creationist Christian right donors http:\/\/t.co\/kuaspgeB",
  "id" : 179279265488060416,
  "created_at" : "2012-03-12 18:54:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 0, 9 ],
      "id_str" : "81582697",
      "id" : 81582697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179197537587179521",
  "geo" : { },
  "id_str" : "179197801710886914",
  "in_reply_to_user_id" : 81582697,
  "text" : "@viirus42 ne, mir ging es um das \"All Files\" als Standard f\u00FCr neue Finder-Windows",
  "id" : 179197801710886914,
  "in_reply_to_status_id" : 179197537587179521,
  "created_at" : "2012-03-12 13:30:59 +0000",
  "in_reply_to_screen_name" : "viirus42",
  "in_reply_to_user_id_str" : "81582697",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179196167173844993",
  "geo" : { },
  "id_str" : "179196346291593216",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen Ah, danke. Das hatte ich bislang \u00FCbersehen. :)",
  "id" : 179196346291593216,
  "in_reply_to_status_id" : 179196167173844993,
  "created_at" : "2012-03-12 13:25:12 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lotterleben",
      "screen_name" : "Lotterleben",
      "indices" : [ 0, 12 ],
      "id_str" : "42195587",
      "id" : 42195587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179195519900454912",
  "geo" : { },
  "id_str" : "179195617451581440",
  "in_reply_to_user_id" : 42195587,
  "text" : "@Lotterleben kann man das eigentlich irgendwie\u2122 abschalten? das nervt mich auch ohne ende",
  "id" : 179195617451581440,
  "in_reply_to_status_id" : 179195519900454912,
  "created_at" : "2012-03-12 13:22:19 +0000",
  "in_reply_to_screen_name" : "Lotterleben",
  "in_reply_to_user_id_str" : "42195587",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "621716753",
      "id" : 621716753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 52 ],
      "url" : "https:\/\/t.co\/wRlwiK3g",
      "expanded_url" : "https:\/\/mybasis.com\/",
      "display_url" : "mybasis.com"
    } ]
  },
  "in_reply_to_status_id_str" : "179193110327328768",
  "geo" : { },
  "id_str" : "179194195532201984",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale gibt ja alternativen: https:\/\/t.co\/wRlwiK3g ;)",
  "id" : 179194195532201984,
  "in_reply_to_status_id" : 179193110327328768,
  "created_at" : "2012-03-12 13:16:40 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "621716753",
      "id" : 621716753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179192374965186560",
  "geo" : { },
  "id_str" : "179192658189758464",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale Welche Daten willst du loggen und mit welchen Tools?",
  "id" : 179192658189758464,
  "in_reply_to_status_id" : 179192374965186560,
  "created_at" : "2012-03-12 13:10:33 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arndt Gro\u00DFmann",
      "screen_name" : "g1zu",
      "indices" : [ 0, 5 ],
      "id_str" : "484276999",
      "id" : 484276999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179186135606636544",
  "geo" : { },
  "id_str" : "179189925579722752",
  "in_reply_to_user_id" : 484276999,
  "text" : "@g1zu Alles klar, ich versuch vorbeizukommen",
  "id" : 179189925579722752,
  "in_reply_to_status_id" : 179186135606636544,
  "created_at" : "2012-03-12 12:59:42 +0000",
  "in_reply_to_screen_name" : "g1zu",
  "in_reply_to_user_id_str" : "484276999",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178958501266202624",
  "text" : "RT @Senficon: Wir \u00E4rgern uns \u00FCber die R\u00FCckst\u00E4ndigkeit der USA, aber in Deutschland zahlen viele Krankenkassen die Pille \u00FCbrigens auch nicht.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "178958047656411137",
    "text" : "Wir \u00E4rgern uns \u00FCber die R\u00FCckst\u00E4ndigkeit der USA, aber in Deutschland zahlen viele Krankenkassen die Pille \u00FCbrigens auch nicht.",
    "id" : 178958047656411137,
    "created_at" : "2012-03-11 21:38:18 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 178958501266202624,
  "created_at" : "2012-03-11 21:40:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1451124795, 7.7208274801 ]
  },
  "id_str" : "178930395843280896",
  "text" : "A weekend full of post-apocalyptic novels. Just finished \u00ABLevel 7\u00BB which is impressive.",
  "id" : 178930395843280896,
  "created_at" : "2012-03-11 19:48:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jensbest",
      "screen_name" : "jensbest",
      "indices" : [ 3, 12 ],
      "id_str" : "14599545",
      "id" : 14599545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/hMM3AWG5",
      "expanded_url" : "http:\/\/bit.ly\/xelTC8",
      "display_url" : "bit.ly\/xelTC8"
    } ]
  },
  "geo" : { },
  "id_str" : "178806103616913409",
  "text" : "RT @jensbest: Student beschwert sich, weil Dozent das Wort \"Altruist\" in Pr\u00FCfung verwendet. http:\/\/t.co\/hMM3AWG5 - dummdreist zum Quadrat.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/hMM3AWG5",
        "expanded_url" : "http:\/\/bit.ly\/xelTC8",
        "display_url" : "bit.ly\/xelTC8"
      } ]
    },
    "geo" : { },
    "id_str" : "178804082650259457",
    "text" : "Student beschwert sich, weil Dozent das Wort \"Altruist\" in Pr\u00FCfung verwendet. http:\/\/t.co\/hMM3AWG5 - dummdreist zum Quadrat.",
    "id" : 178804082650259457,
    "created_at" : "2012-03-11 11:26:29 +0000",
    "user" : {
      "name" : "jensbest",
      "screen_name" : "jensbest",
      "protected" : false,
      "id_str" : "14599545",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879823333239517184\/1ULQsf5I_normal.jpg",
      "id" : 14599545,
      "verified" : false
    }
  },
  "id" : 178806103616913409,
  "created_at" : "2012-03-11 11:34:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178799399688863744",
  "geo" : { },
  "id_str" : "178800236666429440",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer great! :)",
  "id" : 178800236666429440,
  "in_reply_to_status_id" : 178799399688863744,
  "created_at" : "2012-03-11 11:11:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178798166940991488",
  "geo" : { },
  "id_str" : "178798385246109697",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks :)",
  "id" : 178798385246109697,
  "in_reply_to_status_id" : 178798166940991488,
  "created_at" : "2012-03-11 11:03:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178795716196564993",
  "geo" : { },
  "id_str" : "178797818985725952",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer can you apply it? I'm in the wastelands of \"family\"-ville... :)",
  "id" : 178797818985725952,
  "in_reply_to_status_id" : 178795716196564993,
  "created_at" : "2012-03-11 11:01:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/twfADktP",
      "expanded_url" : "http:\/\/i.imgur.com\/P7RwT.jpg",
      "display_url" : "i.imgur.com\/P7RwT.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "178797543164096513",
  "text" : "RT @Senficon: The DRM Monster http:\/\/t.co\/twfADktP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 36 ],
        "url" : "http:\/\/t.co\/twfADktP",
        "expanded_url" : "http:\/\/i.imgur.com\/P7RwT.jpg",
        "display_url" : "i.imgur.com\/P7RwT.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "178794291622187008",
    "text" : "The DRM Monster http:\/\/t.co\/twfADktP",
    "id" : 178794291622187008,
    "created_at" : "2012-03-11 10:47:35 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 178797543164096513,
  "created_at" : "2012-03-11 11:00:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178771636823146496",
  "geo" : { },
  "id_str" : "178776065030885376",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer this was what I was thinking of. :)",
  "id" : 178776065030885376,
  "in_reply_to_status_id" : 178771636823146496,
  "created_at" : "2012-03-11 09:35:10 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178770733747539968",
  "geo" : { },
  "id_str" : "178771310275608577",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch maybe we shouldn't call it like this in production. ;) But it would make it easier to find the phenotypes of interest.",
  "id" : 178771310275608577,
  "in_reply_to_status_id" : 178770733747539968,
  "created_at" : "2012-03-11 09:16:16 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178769989292146688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.089344045, 7.6134321574 ]
  },
  "id_str" : "178770419531264000",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ...use the params and set ownership always using current_user instead of an user_id provided by the params-hash",
  "id" : 178770419531264000,
  "in_reply_to_status_id" : 178769989292146688,
  "created_at" : "2012-03-11 09:12:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178769989292146688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.0893498597, 7.6134731609 ]
  },
  "id_str" : "178770225834106880",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer and I think the only controller where we use massassignments as all is the edit-method of users. Otherwise we manually set...",
  "id" : 178770225834106880,
  "in_reply_to_status_id" : 178769989292146688,
  "created_at" : "2012-03-11 09:11:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178767415423938560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.0893732704, 7.6136915892 ]
  },
  "id_str" : "178769769208619008",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw. I looked at the whitelisting of openSNP and at first glance I couldn't find mass assignment-problems.",
  "id" : 178769769208619008,
  "in_reply_to_status_id" : 178767415423938560,
  "created_at" : "2012-03-11 09:10:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178767153762279424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.0893318114, 7.6134684534 ]
  },
  "id_str" : "178768961012371456",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch thanks, I'd like a disease-recommendation-feature for openSNP (users who've entered phenotype A also entered phenotype B)",
  "id" : 178768961012371456,
  "in_reply_to_status_id" : 178767153762279424,
  "created_at" : "2012-03-11 09:06:56 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178767415423938560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.0893667769, 7.613811332 ]
  },
  "id_str" : "178768106703945728",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay, enjoy your coffee :)",
  "id" : 178768106703945728,
  "in_reply_to_status_id" : 178767415423938560,
  "created_at" : "2012-03-11 09:03:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178766315274772480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.0894452521, 7.6135441927 ]
  },
  "id_str" : "178766866636996608",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay, I will have a look into it later. Is there urgent stuff? :)",
  "id" : 178766866636996608,
  "in_reply_to_status_id" : 178766315274772480,
  "created_at" : "2012-03-11 08:58:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178764770047037441",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.0863237075, 7.6205508487 ]
  },
  "id_str" : "178764888938782720",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks, i totally forgot to look into the todo :)",
  "id" : 178764888938782720,
  "in_reply_to_status_id" : 178764770047037441,
  "created_at" : "2012-03-11 08:50:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178076028026101761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.0869233552, 7.6192351959 ]
  },
  "id_str" : "178764412927225857",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer do you still have the link to the recommendation engine gem for ruby?",
  "id" : 178764412927225857,
  "in_reply_to_status_id" : 178076028026101761,
  "created_at" : "2012-03-11 08:48:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/bZKCchiq",
      "expanded_url" : "http:\/\/j.mp\/zIWnzw",
      "display_url" : "j.mp\/zIWnzw"
    } ]
  },
  "geo" : { },
  "id_str" : "178756753062764544",
  "text" : "Nazi rules for jazz performers http:\/\/t.co\/bZKCchiq",
  "id" : 178756753062764544,
  "created_at" : "2012-03-11 08:18:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Elsbernd",
      "screen_name" : "CodonAUG",
      "indices" : [ 3, 12 ],
      "id_str" : "146283306",
      "id" : 146283306
    }, {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 14, 28 ],
      "id_str" : "16066596",
      "id" : 16066596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/4DpAaMpx",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=WyVJtYni8oQ",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "178753880560123904",
  "text" : "RT @CodonAUG: @onetruecathal Ceiling fan centrifuge in action: http:\/\/t.co\/4DpAaMpx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "C\u24D0thal G\u24D0rvey",
        "screen_name" : "onetruecathal",
        "indices" : [ 0, 14 ],
        "id_str" : "16066596",
        "id" : 16066596
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/4DpAaMpx",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=WyVJtYni8oQ",
        "display_url" : "youtube.com\/watch?feature=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "178750705698471936",
    "in_reply_to_user_id" : 16066596,
    "text" : "@onetruecathal Ceiling fan centrifuge in action: http:\/\/t.co\/4DpAaMpx",
    "id" : 178750705698471936,
    "created_at" : "2012-03-11 07:54:23 +0000",
    "in_reply_to_screen_name" : "onetruecathal",
    "in_reply_to_user_id_str" : "16066596",
    "user" : {
      "name" : "Joseph Elsbernd",
      "screen_name" : "CodonAUG",
      "protected" : false,
      "id_str" : "146283306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646907858068508672\/uZNbccmo_normal.jpg",
      "id" : 146283306,
      "verified" : false
    }
  },
  "id" : 178753880560123904,
  "created_at" : "2012-03-11 08:07:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/lQF0CJcG",
      "expanded_url" : "http:\/\/j.mp\/zrcJ8M",
      "display_url" : "j.mp\/zrcJ8M"
    } ]
  },
  "geo" : { },
  "id_str" : "178654988141199360",
  "text" : "rs9449312: A Novel, Functional and Replicable Risk Gene Region for Alcohol Dependence Identified by GWAS http:\/\/t.co\/lQF0CJcG",
  "id" : 178654988141199360,
  "created_at" : "2012-03-11 01:34:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178638653894045697",
  "text" : "Ich war ernsthaft mal wieder im Kino...",
  "id" : 178638653894045697,
  "created_at" : "2012-03-11 00:29:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Cole",
      "screen_name" : "NickColeBooks",
      "indices" : [ 0, 14 ],
      "id_str" : "253237492",
      "id" : 253237492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178531048379006977",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.089376324, 7.613447828 ]
  },
  "id_str" : "178531309008855041",
  "in_reply_to_user_id" : 253237492,
  "text" : "@NickColeBooks thanks for writing the book. I really look forward to the sequel :)",
  "id" : 178531309008855041,
  "in_reply_to_status_id" : 178531048379006977,
  "created_at" : "2012-03-10 17:22:35 +0000",
  "in_reply_to_screen_name" : "NickColeBooks",
  "in_reply_to_user_id_str" : "253237492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/7VmoXtQO",
      "expanded_url" : "http:\/\/j.mp\/xg88AE",
      "display_url" : "j.mp\/xg88AE"
    } ]
  },
  "geo" : { },
  "id_str" : "178411895282348032",
  "text" : "University of Toronto refines stance on non-human research primates http:\/\/t.co\/7VmoXtQO",
  "id" : 178411895282348032,
  "created_at" : "2012-03-10 09:28:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/ISQs4v5f",
      "expanded_url" : "http:\/\/j.mp\/AdE17x",
      "display_url" : "j.mp\/AdE17x"
    } ]
  },
  "geo" : { },
  "id_str" : "178409940199809024",
  "text" : "Personal Genomics: Health insurance remains (and will remain) relevant http:\/\/t.co\/ISQs4v5f",
  "id" : 178409940199809024,
  "created_at" : "2012-03-10 09:20:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5008195388, 7.4995929262 ]
  },
  "id_str" : "178404382675697665",
  "text" : "Every time I travel by train I wish Reeder would cache the Readability-versions of articles as well.",
  "id" : 178404382675697665,
  "created_at" : "2012-03-10 08:58:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/ENdxsFT6",
      "expanded_url" : "http:\/\/j.mp\/yjyHCj",
      "display_url" : "j.mp\/yjyHCj"
    } ]
  },
  "geo" : { },
  "id_str" : "178403401703489536",
  "text" : "In Defense of Beards: Debunking Research That Facial Hair Isn't Sexy http:\/\/t.co\/ENdxsFT6",
  "id" : 178403401703489536,
  "created_at" : "2012-03-10 08:54:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/xBDYPAkG",
      "expanded_url" : "http:\/\/j.mp\/yjZPZc",
      "display_url" : "j.mp\/yjZPZc"
    } ]
  },
  "geo" : { },
  "id_str" : "178401858862333952",
  "text" : "Why you shouldn't start an affair with your professor http:\/\/t.co\/xBDYPAkG",
  "id" : 178401858862333952,
  "created_at" : "2012-03-10 08:48:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178071349250625536",
  "geo" : { },
  "id_str" : "178262228364042240",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks for your tip. Just finished on the beach and absolutely loved it.",
  "id" : 178262228364042240,
  "in_reply_to_status_id" : 178071349250625536,
  "created_at" : "2012-03-09 23:33:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 61, 74 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/pQf269Id",
      "expanded_url" : "http:\/\/j.mp\/yaV9x0",
      "display_url" : "j.mp\/yaV9x0"
    } ]
  },
  "geo" : { },
  "id_str" : "178203377363189761",
  "text" : "And i thought the Stormtrooper with the lawnmower, posted by @PhilippBayer, was awesome! http:\/\/t.co\/pQf269Id",
  "id" : 178203377363189761,
  "created_at" : "2012-03-09 19:39:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178181801418829825",
  "text" : "RT @wilbanks: Awesome takedown of real cost of \"adding value\" for machine learning journal. biggest cost = tax accountant http:\/\/t.co\/1P ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/1Po0xjSB",
        "expanded_url" : "http:\/\/hvrd.me\/xLQt5Z",
        "display_url" : "hvrd.me\/xLQt5Z"
      } ]
    },
    "geo" : { },
    "id_str" : "178135826448924674",
    "text" : "Awesome takedown of real cost of \"adding value\" for machine learning journal. biggest cost = tax accountant http:\/\/t.co\/1Po0xjSB",
    "id" : 178135826448924674,
    "created_at" : "2012-03-09 15:11:05 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 178181801418829825,
  "created_at" : "2012-03-09 18:13:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.instapaper.com\/\" rel=\"nofollow\"\u003EInstapaper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/BnEDxpGy",
      "expanded_url" : "http:\/\/j.mp\/xuQX2L",
      "display_url" : "j.mp\/xuQX2L"
    } ]
  },
  "geo" : { },
  "id_str" : "178137020286238721",
  "text" : "The NYPD Tapes Confirmed http:\/\/t.co\/BnEDxpGy",
  "id" : 178137020286238721,
  "created_at" : "2012-03-09 15:15:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178134305455882241",
  "text" : "RT @wilbanks: Eat fruit, don't drink it. Exception: in countries where juice is actually made in front of you (ie Brazil). http:\/\/t.co\/9 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/9phiVF1L",
        "expanded_url" : "http:\/\/bit.ly\/x4toJw",
        "display_url" : "bit.ly\/x4toJw"
      } ]
    },
    "geo" : { },
    "id_str" : "178132652409360384",
    "text" : "Eat fruit, don't drink it. Exception: in countries where juice is actually made in front of you (ie Brazil). http:\/\/t.co\/9phiVF1L",
    "id" : 178132652409360384,
    "created_at" : "2012-03-09 14:58:28 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 178134305455882241,
  "created_at" : "2012-03-09 15:05:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucomo",
      "screen_name" : "Lucomo",
      "indices" : [ 0, 7 ],
      "id_str" : "47782352",
      "id" : 47782352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178118174808612865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.9339248723, 6.9313658729 ]
  },
  "id_str" : "178118664279687168",
  "in_reply_to_user_id" : 47782352,
  "text" : "@Lucomo okay, das glaub ich auch nicht. Ist aber vermutlich Konsequenz seines kaputten Anfangs.",
  "id" : 178118664279687168,
  "in_reply_to_status_id" : 178118174808612865,
  "created_at" : "2012-03-09 14:02:53 +0000",
  "in_reply_to_screen_name" : "Lucomo",
  "in_reply_to_user_id_str" : "47782352",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucomo",
      "screen_name" : "Lucomo",
      "indices" : [ 0, 7 ],
      "id_str" : "47782352",
      "id" : 47782352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178116695230136320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.7311732617, 7.1030455164 ]
  },
  "id_str" : "178117071610183680",
  "in_reply_to_user_id" : 47782352,
  "text" : "@Lucomo und zumindest was ich an Emp\u00F6rung \u00FCber seinen Artikel gelesen habe bezieht sich auf die Fehler in genau dem Teil.",
  "id" : 178117071610183680,
  "in_reply_to_status_id" : 178116695230136320,
  "created_at" : "2012-03-09 13:56:33 +0000",
  "in_reply_to_screen_name" : "Lucomo",
  "in_reply_to_user_id_str" : "47782352",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucomo",
      "screen_name" : "Lucomo",
      "indices" : [ 0, 7 ],
      "id_str" : "47782352",
      "id" : 47782352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178115796831186944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.7307883563, 7.1021940405 ]
  },
  "id_str" : "178116338219364352",
  "in_reply_to_user_id" : 47782352,
  "text" : "@Lucomo Ok, ich hab beide Studien nicht gelesen. Seine \u00ABKritik\u00BB an dem Publishing-Modus h\u00E4tte er sich dann aber schenken k\u00F6nnen.",
  "id" : 178116338219364352,
  "in_reply_to_status_id" : 178115796831186944,
  "created_at" : "2012-03-09 13:53:38 +0000",
  "in_reply_to_screen_name" : "Lucomo",
  "in_reply_to_user_id_str" : "47782352",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucomo",
      "screen_name" : "Lucomo",
      "indices" : [ 0, 7 ],
      "id_str" : "47782352",
      "id" : 47782352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178114276505042944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.6576716021, 7.1852719619 ]
  },
  "id_str" : "178114541790560257",
  "in_reply_to_user_id" : 47782352,
  "text" : "@Lucomo Confirmation-Bias? ;)",
  "id" : 178114541790560257,
  "in_reply_to_status_id" : 178114276505042944,
  "created_at" : "2012-03-09 13:46:30 +0000",
  "in_reply_to_screen_name" : "Lucomo",
  "in_reply_to_user_id_str" : "47782352",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucomo",
      "screen_name" : "Lucomo",
      "indices" : [ 0, 7 ],
      "id_str" : "47782352",
      "id" : 47782352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178112921077948416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.6472788525, 7.1932734994 ]
  },
  "id_str" : "178113184958398465",
  "in_reply_to_user_id" : 47782352,
  "text" : "@Lucomo Die Kritik an PLoS ist nicht \u00FCberzogen sondern faktisch einfach an den Haaren herbeigezogen (a.k.a. falsch)",
  "id" : 178113184958398465,
  "in_reply_to_status_id" : 178112921077948416,
  "created_at" : "2012-03-09 13:41:07 +0000",
  "in_reply_to_screen_name" : "Lucomo",
  "in_reply_to_user_id_str" : "47782352",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucomo",
      "screen_name" : "Lucomo",
      "indices" : [ 0, 7 ],
      "id_str" : "47782352",
      "id" : 47782352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178110351215312896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.5308458767, 7.2833489584 ]
  },
  "id_str" : "178112093382381568",
  "in_reply_to_user_id" : 47782352,
  "text" : "@Lucomo Der Blogpost von John Bargh ist aber auch einfach voller Unfug und wird v\u00F6llig zu recht kritisiert.",
  "id" : 178112093382381568,
  "in_reply_to_status_id" : 178110351215312896,
  "created_at" : "2012-03-09 13:36:46 +0000",
  "in_reply_to_screen_name" : "Lucomo",
  "in_reply_to_user_id_str" : "47782352",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Letters of Note",
      "screen_name" : "LettersOfNote",
      "indices" : [ 3, 17 ],
      "id_str" : "72831048",
      "id" : 72831048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/0X3Sro75",
      "expanded_url" : "http:\/\/bit.ly\/nndzzz",
      "display_url" : "bit.ly\/nndzzz"
    } ]
  },
  "geo" : { },
  "id_str" : "178109025685213184",
  "text" : "RT @LettersOfNote: Charles Bukowski died this day in 1994. In 1985 a library banned one of his books. His response: http:\/\/t.co\/0X3Sro75",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/0X3Sro75",
        "expanded_url" : "http:\/\/bit.ly\/nndzzz",
        "display_url" : "bit.ly\/nndzzz"
      } ]
    },
    "geo" : { },
    "id_str" : "178104175828275200",
    "text" : "Charles Bukowski died this day in 1994. In 1985 a library banned one of his books. His response: http:\/\/t.co\/0X3Sro75",
    "id" : 178104175828275200,
    "created_at" : "2012-03-09 13:05:19 +0000",
    "user" : {
      "name" : "Letters of Note",
      "screen_name" : "LettersOfNote",
      "protected" : false,
      "id_str" : "72831048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718895500494303232\/jDNCstR5_normal.jpg",
      "id" : 72831048,
      "verified" : true
    }
  },
  "id" : 178109025685213184,
  "created_at" : "2012-03-09 13:24:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Cole",
      "screen_name" : "NickColeBooks",
      "indices" : [ 53, 67 ],
      "id_str" : "253237492",
      "id" : 253237492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.3496141343, 7.5903698979 ]
  },
  "id_str" : "178107099925057536",
  "text" : "Just finished the \u00ABThe Old Man and the Wasteland\u00BB by @nickcolebooks which has given me a good time.",
  "id" : 178107099925057536,
  "created_at" : "2012-03-09 13:16:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kegelklub",
      "screen_name" : "kegelklub",
      "indices" : [ 0, 10 ],
      "id_str" : "260979523",
      "id" : 260979523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178083005552787457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0013526469, 8.2599926101 ]
  },
  "id_str" : "178085457085730816",
  "in_reply_to_user_id" : 260979523,
  "text" : "@kegelklub bzw. Ist zumindest unwahrscheinlich. :)",
  "id" : 178085457085730816,
  "in_reply_to_status_id" : 178083005552787457,
  "created_at" : "2012-03-09 11:50:56 +0000",
  "in_reply_to_screen_name" : "kegelklub",
  "in_reply_to_user_id_str" : "260979523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kegelklub",
      "screen_name" : "kegelklub",
      "indices" : [ 0, 10 ],
      "id_str" : "260979523",
      "id" : 260979523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178083005552787457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0004341168, 8.263243515 ]
  },
  "id_str" : "178085199085707265",
  "in_reply_to_user_id" : 260979523,
  "text" : "@kegelklub Frauen 6%, M\u00E4nner 7%, insgesamt 8%, sollte bei der geringen Anzahl an Teilnehmern die weder M\/F angegeben haben auch nicht gehen.",
  "id" : 178085199085707265,
  "in_reply_to_status_id" : 178083005552787457,
  "created_at" : "2012-03-09 11:49:54 +0000",
  "in_reply_to_screen_name" : "kegelklub",
  "in_reply_to_user_id_str" : "260979523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kegelklub",
      "screen_name" : "kegelklub",
      "indices" : [ 0, 10 ],
      "id_str" : "260979523",
      "id" : 260979523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178083005552787457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.998572787, 8.2671063465 ]
  },
  "id_str" : "178084972417130496",
  "in_reply_to_user_id" : 260979523,
  "text" : "@kegelklub okay, eine kleine Ungereimtheit noch auf Seite 22 zu Gleichberechtigung in der Gesellschaft, Antwort \u00ABVollst\u00E4ndig gleichberecht.\u00BB",
  "id" : 178084972417130496,
  "in_reply_to_status_id" : 178083005552787457,
  "created_at" : "2012-03-09 11:49:00 +0000",
  "in_reply_to_screen_name" : "kegelklub",
  "in_reply_to_user_id_str" : "260979523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/BWPoEnbM",
      "expanded_url" : "http:\/\/j.mp\/z67fno",
      "display_url" : "j.mp\/z67fno"
    } ]
  },
  "geo" : { },
  "id_str" : "178083430674857984",
  "text" : "A Yale Professor's Rampage on PLoS and a Group That Failed To Replicate His Research http:\/\/t.co\/BWPoEnbM",
  "id" : 178083430674857984,
  "created_at" : "2012-03-09 11:42:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178081163057954816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0073239694, 8.2828867307 ]
  },
  "id_str" : "178081441303891968",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog plus each category would consist of only a single blog :P",
  "id" : 178081441303891968,
  "in_reply_to_status_id" : 178081163057954816,
  "created_at" : "2012-03-09 11:34:58 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178071349250625536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097335648, 8.2831671331 ]
  },
  "id_str" : "178074940598263808",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer just bought on the beach. Sounds like a good read for a weekend full of train travel :)",
  "id" : 178074940598263808,
  "in_reply_to_status_id" : 178071349250625536,
  "created_at" : "2012-03-09 11:09:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178071102378082304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097494391, 8.2831854707 ]
  },
  "id_str" : "178074390246854656",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, found it at BoingBoing and sounded interesting. Plus: Only 1 Dollar. :P",
  "id" : 178074390246854656,
  "in_reply_to_status_id" : 178071102378082304,
  "created_at" : "2012-03-09 11:06:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 90, 106 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/RgdBxxIp",
      "expanded_url" : "http:\/\/yelpingwithcormac.tumblr.com\/post\/12634112681\/the-taco-trilogy",
      "display_url" : "yelpingwithcormac.tumblr.com\/post\/126341126\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "178051829538631680",
  "text" : "RT @PhilippBayer: Yelping with Cormac McCarthy - The Taco Trilogy http:\/\/t.co\/RgdBxxIp cc @gedankenstuecke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 72, 88 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/RgdBxxIp",
        "expanded_url" : "http:\/\/yelpingwithcormac.tumblr.com\/post\/12634112681\/the-taco-trilogy",
        "display_url" : "yelpingwithcormac.tumblr.com\/post\/126341126\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "178045123731529728",
    "text" : "Yelping with Cormac McCarthy - The Taco Trilogy http:\/\/t.co\/RgdBxxIp cc @gedankenstuecke",
    "id" : 178045123731529728,
    "created_at" : "2012-03-09 09:10:40 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 178051829538631680,
  "created_at" : "2012-03-09 09:37:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178045123731529728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095145226, 8.2831429401 ]
  },
  "id_str" : "178049988012683264",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer haha, I'm currently reading \u00ABThe old man and the wasteland\u00BB, you might enjoy it.",
  "id" : 178049988012683264,
  "in_reply_to_status_id" : 178045123731529728,
  "created_at" : "2012-03-09 09:29:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/hQZanC5M",
      "expanded_url" : "http:\/\/discovermagazine.com\/2011\/dec\/17-lethal-gene-emerged-ancient-palestine",
      "display_url" : "discovermagazine.com\/2011\/dec\/17-le\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "178042936284549120",
  "text" : "RT @PhilippBayer: \"The Lethal Gene That Emerged in Ancient Palestine and Spread Around the Globe\" http:\/\/t.co\/hQZanC5M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/hQZanC5M",
        "expanded_url" : "http:\/\/discovermagazine.com\/2011\/dec\/17-lethal-gene-emerged-ancient-palestine",
        "display_url" : "discovermagazine.com\/2011\/dec\/17-le\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "178042480988651520",
    "text" : "\"The Lethal Gene That Emerged in Ancient Palestine and Spread Around the Globe\" http:\/\/t.co\/hQZanC5M",
    "id" : 178042480988651520,
    "created_at" : "2012-03-09 09:00:09 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 178042936284549120,
  "created_at" : "2012-03-09 09:01:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/BcAaCcm7",
      "expanded_url" : "http:\/\/j.mp\/wdInsm",
      "display_url" : "j.mp\/wdInsm"
    } ]
  },
  "geo" : { },
  "id_str" : "178041477920866304",
  "text" : "The Origin of Gender Symbols http:\/\/t.co\/BcAaCcm7",
  "id" : 178041477920866304,
  "created_at" : "2012-03-09 08:56:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kegelklub",
      "screen_name" : "kegelklub",
      "indices" : [ 0, 10 ],
      "id_str" : "260979523",
      "id" : 260979523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097726339, 8.2832514 ]
  },
  "id_str" : "178040243566559232",
  "in_reply_to_user_id" : 260979523,
  "text" : "@kegelklub Orange (= Alle Beteiligten) sticht deutlich \u00FCber M\u00E4nner und Frauen heraus. W\u00FCrde erwarten das es sich dazwischen befindet.",
  "id" : 178040243566559232,
  "created_at" : "2012-03-09 08:51:16 +0000",
  "in_reply_to_screen_name" : "kegelklub",
  "in_reply_to_user_id_str" : "260979523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kegelklub",
      "screen_name" : "kegelklub",
      "indices" : [ 0, 10 ],
      "id_str" : "260979523",
      "id" : 260979523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00976311, 8.2832226219 ]
  },
  "id_str" : "178040061160464384",
  "in_reply_to_user_id" : 260979523,
  "text" : "@kegelklub kann es sein das die Grafik rechts auf Seite 13 falsch ist, oder kann ich den Graphen nicht lesen?",
  "id" : 178040061160464384,
  "created_at" : "2012-03-09 08:50:33 +0000",
  "in_reply_to_screen_name" : "kegelklub",
  "in_reply_to_user_id_str" : "260979523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scilogs12",
      "indices" : [ 77, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097458695, 8.2831732219 ]
  },
  "id_str" : "178038890446340096",
  "text" : "Mal zur Reiseplanung: Reist eigentlich irgendwer von\/\u00FCber Mainz\/Frankfurt zu #scilogs12 an?",
  "id" : 178038890446340096,
  "created_at" : "2012-03-09 08:45:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team Mendeley",
      "screen_name" : "mendeley_com",
      "indices" : [ 3, 16 ],
      "id_str" : "15803034",
      "id" : 15803034
    }, {
      "name" : "Hojoki",
      "screen_name" : "hojoki",
      "indices" : [ 47, 54 ],
      "id_str" : "86628099",
      "id" : 86628099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177896085241606144",
  "text" : "RT @mendeley_com: Mendeley is now available in @hojoki! Retweet this to win one of 10 t-shirts with the awesome Hojoki-Mendeley robot: h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hojoki",
        "screen_name" : "hojoki",
        "indices" : [ 29, 36 ],
        "id_str" : "86628099",
        "id" : 86628099
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/Wv6XG0Qq",
        "expanded_url" : "http:\/\/blog.mendeley.com\/academic-features\/mendeley-now-available-in-hojoki\/",
        "display_url" : "blog.mendeley.com\/academic-featu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "177893577047814144",
    "text" : "Mendeley is now available in @hojoki! Retweet this to win one of 10 t-shirts with the awesome Hojoki-Mendeley robot: http:\/\/t.co\/Wv6XG0Qq",
    "id" : 177893577047814144,
    "created_at" : "2012-03-08 23:08:28 +0000",
    "user" : {
      "name" : "Team Mendeley",
      "screen_name" : "mendeley_com",
      "protected" : false,
      "id_str" : "15803034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608592552497967104\/bQwEG0C0_normal.png",
      "id" : 15803034,
      "verified" : false
    }
  },
  "id" : 177896085241606144,
  "created_at" : "2012-03-08 23:18:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/RuFsJZWG",
      "expanded_url" : "http:\/\/j.mp\/xAEv4c",
      "display_url" : "j.mp\/xAEv4c"
    } ]
  },
  "geo" : { },
  "id_str" : "177878866696749056",
  "text" : "Warner wants you to go to a depot and pay to rip your DVDs to DRM-locked formats http:\/\/t.co\/RuFsJZWG",
  "id" : 177878866696749056,
  "created_at" : "2012-03-08 22:10:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/readnowapp.mischneider.net\" rel=\"nofollow\"\u003EReadNow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/8wEscpvk",
      "expanded_url" : "http:\/\/bit.ly\/wHARqE",
      "display_url" : "bit.ly\/wHARqE"
    } ]
  },
  "geo" : { },
  "id_str" : "177795863026999296",
  "text" : "International Slutty Women\u2019s Day http:\/\/t.co\/8wEscpvk",
  "id" : 177795863026999296,
  "created_at" : "2012-03-08 16:40:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Fisher",
      "screen_name" : "42",
      "indices" : [ 3, 6 ],
      "id_str" : "699433",
      "id" : 699433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/wvR637BU",
      "expanded_url" : "http:\/\/omfgdogs.com\/",
      "display_url" : "omfgdogs.com"
    } ]
  },
  "geo" : { },
  "id_str" : "177793196322062336",
  "text" : "RT @42: OMFGDOGS http:\/\/t.co\/wvR637BU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 29 ],
        "url" : "http:\/\/t.co\/wvR637BU",
        "expanded_url" : "http:\/\/omfgdogs.com\/",
        "display_url" : "omfgdogs.com"
      } ]
    },
    "geo" : { },
    "id_str" : "177544046468800513",
    "text" : "OMFGDOGS http:\/\/t.co\/wvR637BU",
    "id" : 177544046468800513,
    "created_at" : "2012-03-07 23:59:33 +0000",
    "user" : {
      "name" : "Lauren Fisher",
      "screen_name" : "42",
      "protected" : false,
      "id_str" : "699433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/647022727065378816\/B89W19VQ_normal.jpg",
      "id" : 699433,
      "verified" : false
    }
  },
  "id" : 177793196322062336,
  "created_at" : "2012-03-08 16:29:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/LDru25ZF",
      "expanded_url" : "http:\/\/j.mp\/A4gzp2",
      "display_url" : "j.mp\/A4gzp2"
    } ]
  },
  "geo" : { },
  "id_str" : "177788545761681408",
  "text" : "Working Undercover in a Slaughterhouse http:\/\/t.co\/LDru25ZF",
  "id" : 177788545761681408,
  "created_at" : "2012-03-08 16:11:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/56RGpBFJ",
      "expanded_url" : "http:\/\/j.mp\/z7FRg4",
      "display_url" : "j.mp\/z7FRg4"
    } ]
  },
  "geo" : { },
  "id_str" : "177717904459038721",
  "text" : "The QWERTY Effect: How Typing May Shape the Meaning of Words http:\/\/t.co\/56RGpBFJ",
  "id" : 177717904459038721,
  "created_at" : "2012-03-08 11:30:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 87, 96 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/Yx6KMlma",
      "expanded_url" : "http:\/\/j.mp\/xTHiYd",
      "display_url" : "j.mp\/xTHiYd"
    } ]
  },
  "geo" : { },
  "id_str" : "177713263709138944",
  "text" : "The paper on the crowdcomputing-game Phylo has been published http:\/\/t.co\/Yx6KMlma \/cc @RoterHai",
  "id" : 177713263709138944,
  "created_at" : "2012-03-08 11:11:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/RRWyTpn4",
      "expanded_url" : "http:\/\/j.mp\/wqOvzL",
      "display_url" : "j.mp\/wqOvzL"
    } ]
  },
  "geo" : { },
  "id_str" : "177712963908665345",
  "text" : "Detection of IL28B SNP DNA from Buccal Epithelial Cells, Small Amounts of Serum, and Dried Blood Spots http:\/\/t.co\/RRWyTpn4",
  "id" : 177712963908665345,
  "created_at" : "2012-03-08 11:10:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 80 ],
      "url" : "https:\/\/t.co\/KfeyZk2I",
      "expanded_url" : "https:\/\/tsaoutofourpants.wordpress.com\/2012\/03\/06\/1b-of-nude-body-scanners-made-worthless-by-blog-how-anyone-can-get-anything-past-the-tsas-nude-body-scanners\/",
      "display_url" : "tsaoutofourpants.wordpress.com\/2012\/03\/06\/1b-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "177711215752118272",
  "text" : "$1B of TSA Nude Body Scanners Made Worthless By Sewing Kit https:\/\/t.co\/KfeyZk2I",
  "id" : 177711215752118272,
  "created_at" : "2012-03-08 11:03:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177690193258754048",
  "geo" : { },
  "id_str" : "177691903922413568",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ Ich hab es heute Nacht um halb 4 gemacht :P",
  "id" : 177691903922413568,
  "in_reply_to_status_id" : 177690193258754048,
  "created_at" : "2012-03-08 09:47:05 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 0, 15 ],
      "id_str" : "73134122",
      "id" : 73134122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177680036701282305",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097399721, 8.283103669 ]
  },
  "id_str" : "177681206488469505",
  "in_reply_to_user_id" : 73134122,
  "text" : "@astefanowitsch da muss ich mich bedeckt halten. Weil mein Studiengang \u00D6kologie im Namen hat werde ich auch f\u00FCr einen Treehugger gehalten ;)",
  "id" : 177681206488469505,
  "in_reply_to_status_id" : 177680036701282305,
  "created_at" : "2012-03-08 09:04:35 +0000",
  "in_reply_to_screen_name" : "astefanowitsch",
  "in_reply_to_user_id_str" : "73134122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 0, 15 ],
      "id_str" : "73134122",
      "id" : 73134122
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 16, 26 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177678727730315264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098306476, 8.2833229395 ]
  },
  "id_str" : "177679546429083648",
  "in_reply_to_user_id" : 73134122,
  "text" : "@astefanowitsch @Fischblog aber auch: Wie kommt man auf die Idee das ein Naturwissenschaftler einen Doktor in !NaWi vergeben kann?",
  "id" : 177679546429083648,
  "in_reply_to_status_id" : 177678727730315264,
  "created_at" : "2012-03-08 08:57:59 +0000",
  "in_reply_to_screen_name" : "astefanowitsch",
  "in_reply_to_user_id_str" : "73134122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "indices" : [ 3, 10 ],
      "id_str" : "47876842",
      "id" : 47876842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/HgYhNLg5",
      "expanded_url" : "http:\/\/www.physorg.com\/news\/2012-02-gene-gut-bacteria-beetle.html",
      "display_url" : "physorg.com\/news\/2012-02-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "177676223273639936",
  "text" : "RT @brembs: Gene found to have jumped from gut bacteria to beetle http:\/\/t.co\/HgYhNLg5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/HgYhNLg5",
        "expanded_url" : "http:\/\/www.physorg.com\/news\/2012-02-gene-gut-bacteria-beetle.html",
        "display_url" : "physorg.com\/news\/2012-02-g\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "177634411280478208",
    "text" : "Gene found to have jumped from gut bacteria to beetle http:\/\/t.co\/HgYhNLg5",
    "id" : 177634411280478208,
    "created_at" : "2012-03-08 05:58:38 +0000",
    "user" : {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "protected" : false,
      "id_str" : "47876842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524937570984013824\/uPSUsTcU_normal.png",
      "id" : 47876842,
      "verified" : false
    }
  },
  "id" : 177676223273639936,
  "created_at" : "2012-03-08 08:44:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/p2gdO1WK",
      "expanded_url" : "http:\/\/j.mp\/wxmKIo",
      "display_url" : "j.mp\/wxmKIo"
    } ]
  },
  "geo" : { },
  "id_str" : "177489306829594625",
  "text" : "Animated GIFs - The Birth of a Medium http:\/\/t.co\/p2gdO1WK",
  "id" : 177489306829594625,
  "created_at" : "2012-03-07 20:22:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177484765891538944",
  "geo" : { },
  "id_str" : "177485669147484161",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Ich hatte doch vermutet, dass das dein Humor ist. ;)",
  "id" : 177485669147484161,
  "in_reply_to_status_id" : 177484765891538944,
  "created_at" : "2012-03-07 20:07:35 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/QO62PJbU",
      "expanded_url" : "http:\/\/boingboing.net\/2012\/03\/07\/teenager-launches-lego-space-s.html?utm_source=dlvr.it&utm_medium=twitter",
      "display_url" : "boingboing.net\/2012\/03\/07\/tee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "177484794488291330",
  "text" : "Wow, Teenager launches Lego Space Shuttle into stratosphere http:\/\/t.co\/QO62PJbU",
  "id" : 177484794488291330,
  "created_at" : "2012-03-07 20:04:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/8AcbS0Ai",
      "expanded_url" : "http:\/\/occamstypewriter.org\/rpg\/2009\/05\/11\/on_whizzy_things_and_how_they_fall_apart\/",
      "display_url" : "occamstypewriter.org\/rpg\/2009\/05\/11\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "177481019178491904",
  "geo" : { },
  "id_str" : "177481346388738048",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog ich bezweifle es: http:\/\/t.co\/8AcbS0Ai",
  "id" : 177481346388738048,
  "in_reply_to_status_id" : 177481019178491904,
  "created_at" : "2012-03-07 19:50:25 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177480297275863040",
  "geo" : { },
  "id_str" : "177480461629661184",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog DIY Biologen die \u00FCberlegen selbst Ultrazentrifugen zu bauen. Da k\u00F6nnte selbst ein leeres Eppi zum t\u00F6d. Projektil werden. ;)",
  "id" : 177480461629661184,
  "in_reply_to_status_id" : 177480297275863040,
  "created_at" : "2012-03-07 19:46:54 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177479414349692928",
  "text" : "\u00ABA direct hit from a rubber bullet to the eye stands a good chance of\nkilling you, & I expect an eppendorf @ 50,000 rpm to the eye does too\u00BB",
  "id" : 177479414349692928,
  "created_at" : "2012-03-07 19:42:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michael_nielsen",
      "screen_name" : "michael_nielsen",
      "indices" : [ 3, 19 ],
      "id_str" : "15626406",
      "id" : 15626406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/SI7nRbZa",
      "expanded_url" : "http:\/\/bit.ly\/znXRfc",
      "display_url" : "bit.ly\/znXRfc"
    } ]
  },
  "geo" : { },
  "id_str" : "177464994101870592",
  "text" : "RT @michael_nielsen: On virtual economies: \"How I Helped Destroy Star Wars Galaxies\" http:\/\/t.co\/SI7nRbZa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/chrome.google.com\/webstore\/detail\/tweet-this-page\/ppilhaolhbpfembaoedfdbkegfedfgip\" rel=\"nofollow\"\u003ETweet-this-page\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/SI7nRbZa",
        "expanded_url" : "http:\/\/bit.ly\/znXRfc",
        "display_url" : "bit.ly\/znXRfc"
      } ]
    },
    "geo" : { },
    "id_str" : "177463324303310849",
    "text" : "On virtual economies: \"How I Helped Destroy Star Wars Galaxies\" http:\/\/t.co\/SI7nRbZa",
    "id" : 177463324303310849,
    "created_at" : "2012-03-07 18:38:48 +0000",
    "user" : {
      "name" : "michael_nielsen",
      "screen_name" : "michael_nielsen",
      "protected" : false,
      "id_str" : "15626406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2756243281\/6d3d0ade1bd4364b75d7d0151dce38e5_normal.png",
      "id" : 15626406,
      "verified" : false
    }
  },
  "id" : 177464994101870592,
  "created_at" : "2012-03-07 18:45:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 0, 7 ],
      "id_str" : "34880281",
      "id" : 34880281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177454939604389888",
  "geo" : { },
  "id_str" : "177455127995752448",
  "in_reply_to_user_id" : 34880281,
  "text" : "@otacke Nicht direkt neu. Ging vor 1-2 Wochen rum. Aber nach dem PacBio-Debakel erstmal auf Rohdaten von der Technologie warten ;)",
  "id" : 177455127995752448,
  "in_reply_to_status_id" : 177454939604389888,
  "created_at" : "2012-03-07 18:06:14 +0000",
  "in_reply_to_screen_name" : "otacke",
  "in_reply_to_user_id_str" : "34880281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/eFWJhceE",
      "expanded_url" : "http:\/\/j.mp\/zWwy6Q",
      "display_url" : "j.mp\/zWwy6Q"
    } ]
  },
  "geo" : { },
  "id_str" : "177445231887790080",
  "text" : "Digital camera mounted to the business-end of a drill http:\/\/t.co\/eFWJhceE",
  "id" : 177445231887790080,
  "created_at" : "2012-03-07 17:26:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/lHZ2yZ0g",
      "expanded_url" : "http:\/\/j.mp\/chpQ3E",
      "display_url" : "j.mp\/chpQ3E"
    } ]
  },
  "geo" : { },
  "id_str" : "177444071688781824",
  "text" : "Lost in Space http:\/\/t.co\/lHZ2yZ0g",
  "id" : 177444071688781824,
  "created_at" : "2012-03-07 17:22:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/GGX5TPtT",
      "expanded_url" : "http:\/\/j.mp\/znKGGG",
      "display_url" : "j.mp\/znKGGG"
    } ]
  },
  "geo" : { },
  "id_str" : "177438719979175937",
  "text" : "Identifying targets of natural selection in human and dog evolution http:\/\/t.co\/GGX5TPtT",
  "id" : 177438719979175937,
  "created_at" : "2012-03-07 17:01:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 33, 42 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/5Elc2GW6",
      "expanded_url" : "http:\/\/webdemo.visionobjects.com\/equation.html",
      "display_url" : "webdemo.visionobjects.com\/equation.html"
    } ]
  },
  "geo" : { },
  "id_str" : "177363726490542083",
  "text" : "Works on touchscreen-devices! RT @BobOHara: Wow, web equation even recognises my hand-writing. http:\/\/t.co\/5Elc2GW6",
  "id" : 177363726490542083,
  "created_at" : "2012-03-07 12:03:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177354442839035904",
  "geo" : { },
  "id_str" : "177357800442302464",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Erst das Original, dann weisst du besser was genau kritisiert wird.",
  "id" : 177357800442302464,
  "in_reply_to_status_id" : 177354442839035904,
  "created_at" : "2012-03-07 11:39:29 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "viola vo\u00DF",
      "screen_name" : "v_i_o_l_a",
      "indices" : [ 67, 77 ],
      "id_str" : "14937469",
      "id" : 14937469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/dyyCAt83",
      "expanded_url" : "http:\/\/bit.ly\/Arqswg",
      "display_url" : "bit.ly\/Arqswg"
    } ]
  },
  "geo" : { },
  "id_str" : "177352530609704960",
  "text" : "\u00ABI put the numbers into this magic box and out came my thesis!\u00BB MT @v_i_o_l_a: :D The methodology translator: http:\/\/t.co\/dyyCAt83",
  "id" : 177352530609704960,
  "created_at" : "2012-03-07 11:18:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/jH7Shasb",
      "expanded_url" : "http:\/\/cinelerra.org\/",
      "display_url" : "cinelerra.org"
    } ]
  },
  "in_reply_to_status_id_str" : "177175290290774016",
  "geo" : { },
  "id_str" : "177349441945219072",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce Cinelerra looks quite powerful: http:\/\/t.co\/jH7Shasb",
  "id" : 177349441945219072,
  "in_reply_to_status_id" : 177175290290774016,
  "created_at" : "2012-03-07 11:06:16 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ewan Birney",
      "screen_name" : "ewanbirney",
      "indices" : [ 0, 11 ],
      "id_str" : "183548902",
      "id" : 183548902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177316473398759425",
  "geo" : { },
  "id_str" : "177316961687048192",
  "in_reply_to_user_id" : 183548902,
  "text" : "@ewanbirney But you're right: it's quite hidden",
  "id" : 177316961687048192,
  "in_reply_to_status_id" : 177316473398759425,
  "created_at" : "2012-03-07 08:57:12 +0000",
  "in_reply_to_screen_name" : "ewanbirney",
  "in_reply_to_user_id_str" : "183548902",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ewan Birney",
      "screen_name" : "ewanbirney",
      "indices" : [ 0, 11 ],
      "id_str" : "183548902",
      "id" : 183548902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/20SyZAp3",
      "expanded_url" : "http:\/\/support.google.com\/mobile\/bin\/answer.py?hl=en&answer=139206",
      "display_url" : "support.google.com\/mobile\/bin\/ans\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "177316473398759425",
  "geo" : { },
  "id_str" : "177316784490299392",
  "in_reply_to_user_id" : 183548902,
  "text" : "@ewanbirney I think I do, see here: http:\/\/t.co\/20SyZAp3",
  "id" : 177316784490299392,
  "in_reply_to_status_id" : 177316473398759425,
  "created_at" : "2012-03-07 08:56:30 +0000",
  "in_reply_to_screen_name" : "ewanbirney",
  "in_reply_to_user_id_str" : "183548902",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177175290290774016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097275688, 8.2830689354 ]
  },
  "id_str" : "177305630523133953",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce sorry, in this case I was lazy and used the software already available on my machine.",
  "id" : 177305630523133953,
  "in_reply_to_status_id" : 177175290290774016,
  "created_at" : "2012-03-07 08:12:11 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ewan Birney",
      "screen_name" : "ewanbirney",
      "indices" : [ 0, 11 ],
      "id_str" : "183548902",
      "id" : 183548902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177177185466056705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097334827, 8.283202135 ]
  },
  "id_str" : "177305422670204928",
  "in_reply_to_user_id" : 183548902,
  "text" : "@ewanbirney yes, it is quite stupid as setting it up would be much more fun on a larger screen.",
  "id" : 177305422670204928,
  "in_reply_to_status_id" : 177177185466056705,
  "created_at" : "2012-03-07 08:11:21 +0000",
  "in_reply_to_screen_name" : "ewanbirney",
  "in_reply_to_user_id_str" : "183548902",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Saunders",
      "screen_name" : "neilfws",
      "indices" : [ 3, 11 ],
      "id_str" : "14162706",
      "id" : 14162706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/T2gCHpuh",
      "expanded_url" : "http:\/\/bit.ly\/xrZXnf",
      "display_url" : "bit.ly\/xrZXnf"
    } ]
  },
  "geo" : { },
  "id_str" : "177305014040133633",
  "text" : "RT @neilfws: Top 12 reasons you know you are a Big Data biologist http:\/\/t.co\/T2gCHpuh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/T2gCHpuh",
        "expanded_url" : "http:\/\/bit.ly\/xrZXnf",
        "display_url" : "bit.ly\/xrZXnf"
      } ]
    },
    "geo" : { },
    "id_str" : "177139895784058880",
    "text" : "Top 12 reasons you know you are a Big Data biologist http:\/\/t.co\/T2gCHpuh",
    "id" : 177139895784058880,
    "created_at" : "2012-03-06 21:13:36 +0000",
    "user" : {
      "name" : "Neil Saunders",
      "screen_name" : "neilfws",
      "protected" : false,
      "id_str" : "14162706",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835449341384876032\/G_TEkp8j_normal.jpg",
      "id" : 14162706,
      "verified" : false
    }
  },
  "id" : 177305014040133633,
  "created_at" : "2012-03-07 08:09:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "indices" : [ 3, 15 ],
      "id_str" : "6705042",
      "id" : 6705042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/AOT6wr9x",
      "expanded_url" : "http:\/\/post.ly\/5p6C1",
      "display_url" : "post.ly\/5p6C1"
    } ]
  },
  "geo" : { },
  "id_str" : "177302473650872320",
  "text" : "RT @bengoldacre: US execution on hold as drug co says \"not in my name\" & demands return of medicine used for killing. http:\/\/t.co\/AOT6wr9x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/AOT6wr9x",
        "expanded_url" : "http:\/\/post.ly\/5p6C1",
        "display_url" : "post.ly\/5p6C1"
      } ]
    },
    "geo" : { },
    "id_str" : "177241665587777536",
    "text" : "US execution on hold as drug co says \"not in my name\" & demands return of medicine used for killing. http:\/\/t.co\/AOT6wr9x",
    "id" : 177241665587777536,
    "created_at" : "2012-03-07 03:58:00 +0000",
    "user" : {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "protected" : false,
      "id_str" : "6705042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523118410419286016\/qXTUFTZR_normal.png",
      "id" : 6705042,
      "verified" : true
    }
  },
  "id" : 177302473650872320,
  "created_at" : "2012-03-07 07:59:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ewan Birney",
      "screen_name" : "ewanbirney",
      "indices" : [ 0, 11 ],
      "id_str" : "183548902",
      "id" : 183548902
    }, {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "indices" : [ 12, 27 ],
      "id_str" : "19416598",
      "id" : 19416598
    }, {
      "name" : "Albert Vernon Smith",
      "screen_name" : "avsmith",
      "indices" : [ 28, 36 ],
      "id_str" : "5762302",
      "id" : 5762302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/DydGqlAW",
      "expanded_url" : "http:\/\/m.google.com\/sync",
      "display_url" : "m.google.com\/sync"
    } ]
  },
  "in_reply_to_status_id_str" : "177166738788597760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00974612, 8.2831208809 ]
  },
  "id_str" : "177174282084954113",
  "in_reply_to_user_id" : 183548902,
  "text" : "@ewanbirney @leonidkruglyak @avsmith visit http:\/\/t.co\/DydGqlAW from your iPhone.",
  "id" : 177174282084954113,
  "in_reply_to_status_id" : 177166738788597760,
  "created_at" : "2012-03-06 23:30:15 +0000",
  "in_reply_to_screen_name" : "ewanbirney",
  "in_reply_to_user_id_str" : "183548902",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177173403155963904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097453284, 8.2831237053 ]
  },
  "id_str" : "177173865242431489",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce i used iMovie, but I'm sure there are open source, non-mac alternatives. I will take a look tomorrow, if you want. :)",
  "id" : 177173865242431489,
  "in_reply_to_status_id" : 177173403155963904,
  "created_at" : "2012-03-06 23:28:35 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/btvZ5gRj",
      "expanded_url" : "http:\/\/j.mp\/xOCOF5",
      "display_url" : "j.mp\/xOCOF5"
    } ]
  },
  "geo" : { },
  "id_str" : "177173493992009728",
  "text" : "Lawrence v Texas: How Laws Against Sodomy Became Unconstitutional http:\/\/t.co\/btvZ5gRj",
  "id" : 177173493992009728,
  "created_at" : "2012-03-06 23:27:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/GKgmIOqN",
      "expanded_url" : "http:\/\/j.mp\/xGcCCv",
      "display_url" : "j.mp\/xGcCCv"
    } ]
  },
  "geo" : { },
  "id_str" : "177169695873572864",
  "text" : "Sounds familiar? Sleep less and waste more time online http:\/\/t.co\/GKgmIOqN",
  "id" : 177169695873572864,
  "created_at" : "2012-03-06 23:12:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/cNwH5vRR",
      "expanded_url" : "http:\/\/j.mp\/wL91pW",
      "display_url" : "j.mp\/wL91pW"
    } ]
  },
  "geo" : { },
  "id_str" : "177169220822503424",
  "text" : "Using tools from evolutionary biology in cultural evolution http:\/\/t.co\/cNwH5vRR",
  "id" : 177169220822503424,
  "created_at" : "2012-03-06 23:10:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fatherland",
      "indices" : [ 93, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097239251, 8.2831178275 ]
  },
  "id_str" : "177145297384910849",
  "text" : "Are there any movies featuring Rutger Hauer where his character doesn't die in pouring rain? #fatherland",
  "id" : 177145297384910849,
  "created_at" : "2012-03-06 21:35:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177097957563305984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097561825, 8.2831564141 ]
  },
  "id_str" : "177098698080272385",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn and what did you find out about us? ;)",
  "id" : 177098698080272385,
  "in_reply_to_status_id" : 177097957563305984,
  "created_at" : "2012-03-06 18:29:54 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177060097493704705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0085582433, 8.2831299789 ]
  },
  "id_str" : "177094218521649152",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn it never reassigned those numbers. Those are the primary keys of the database :)",
  "id" : 177094218521649152,
  "in_reply_to_status_id" : 177060097493704705,
  "created_at" : "2012-03-06 18:12:06 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kia",
      "screen_name" : "nad_no_ennas",
      "indices" : [ 0, 13 ],
      "id_str" : "1702539380",
      "id" : 1702539380
    }, {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 14, 22 ],
      "id_str" : "621716753",
      "id" : 621716753
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 23, 32 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177084339547418624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0092974553, 8.2831677077 ]
  },
  "id_str" : "177093659035049984",
  "in_reply_to_user_id" : 102096393,
  "text" : "@nad_no_ennas @Scytale @Senficon wenn das noch aktuell ist: Such im xkcd-Blog nach ballpit, da gibt es einen Calculator.",
  "id" : 177093659035049984,
  "in_reply_to_status_id" : 177084339547418624,
  "created_at" : "2012-03-06 18:09:53 +0000",
  "in_reply_to_screen_name" : "kianelazin",
  "in_reply_to_user_id_str" : "102096393",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Klinger \u270C\uFE0F",
      "screen_name" : "andreasklinger",
      "indices" : [ 3, 18 ],
      "id_str" : "14946149",
      "id" : 14946149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/kawpw9I5",
      "expanded_url" : "http:\/\/i.imgur.com\/EJQar.png",
      "display_url" : "i.imgur.com\/EJQar.png"
    } ]
  },
  "geo" : { },
  "id_str" : "176970614760939522",
  "text" : "RT @andreasklinger: When marketeers make graphs: http:\/\/t.co\/kawpw9I5 (that roughly equals 0,3% growth)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/kawpw9I5",
        "expanded_url" : "http:\/\/i.imgur.com\/EJQar.png",
        "display_url" : "i.imgur.com\/EJQar.png"
      } ]
    },
    "geo" : { },
    "id_str" : "176970445650792448",
    "text" : "When marketeers make graphs: http:\/\/t.co\/kawpw9I5 (that roughly equals 0,3% growth)",
    "id" : 176970445650792448,
    "created_at" : "2012-03-06 10:00:16 +0000",
    "user" : {
      "name" : "Andreas Klinger \u270C\uFE0F",
      "screen_name" : "andreasklinger",
      "protected" : false,
      "id_str" : "14946149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458856003732140032\/EN5TET65_normal.jpeg",
      "id" : 14946149,
      "verified" : true
    }
  },
  "id" : 176970614760939522,
  "created_at" : "2012-03-06 10:00:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/7LaSciZm",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Keep_Calm_and_Carry_On#Trademark_claims",
      "display_url" : "en.wikipedia.org\/wiki\/Keep_Calm\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096719658, 8.2829239206 ]
  },
  "id_str" : "176969125967577089",
  "text" : "Public Domain, how it should(n't) work: http:\/\/t.co\/7LaSciZm",
  "id" : 176969125967577089,
  "created_at" : "2012-03-06 09:55:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/ClxfqG4g",
      "expanded_url" : "http:\/\/j.mp\/xSnATM",
      "display_url" : "j.mp\/xSnATM"
    } ]
  },
  "geo" : { },
  "id_str" : "176967617406447616",
  "text" : "Plagiat: Noch ein FDP-Politiker verliert Doktortitel http:\/\/t.co\/ClxfqG4g",
  "id" : 176967617406447616,
  "created_at" : "2012-03-06 09:49:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/cFAaAkgU",
      "expanded_url" : "http:\/\/j.mp\/A8738A",
      "display_url" : "j.mp\/A8738A"
    } ]
  },
  "geo" : { },
  "id_str" : "176966221663711232",
  "text" : "A famous copyright infringement: Keep calm and carry an on http:\/\/t.co\/cFAaAkgU",
  "id" : 176966221663711232,
  "created_at" : "2012-03-06 09:43:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/eBjYpMOc",
      "expanded_url" : "http:\/\/j.mp\/z5SluB",
      "display_url" : "j.mp\/z5SluB"
    } ]
  },
  "geo" : { },
  "id_str" : "176964884263739392",
  "text" : "Visualizing Your DNA Genotype Profile in a Blanket http:\/\/t.co\/eBjYpMOc",
  "id" : 176964884263739392,
  "created_at" : "2012-03-06 09:38:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katrin K.",
      "screen_name" : "_atrinki_",
      "indices" : [ 0, 10 ],
      "id_str" : "41897282",
      "id" : 41897282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176779208079572993",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0092411446, 8.2839492377 ]
  },
  "id_str" : "176961887181869056",
  "in_reply_to_user_id" : 41897282,
  "text" : "@_atrinki_ danke, ich versuch es damit mal :)",
  "id" : 176961887181869056,
  "in_reply_to_status_id" : 176779208079572993,
  "created_at" : "2012-03-06 09:26:16 +0000",
  "in_reply_to_screen_name" : "_atrinki_",
  "in_reply_to_user_id_str" : "41897282",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/xAp6aD6K",
      "expanded_url" : "http:\/\/j.mp\/yq68Nz",
      "display_url" : "j.mp\/yq68Nz"
    } ]
  },
  "geo" : { },
  "id_str" : "176954560399683584",
  "text" : "Luv and War at 30,000 Feet http:\/\/t.co\/xAp6aD6K",
  "id" : 176954560399683584,
  "created_at" : "2012-03-06 08:57:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176894170131210241",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097841585, 8.2835128484 ]
  },
  "id_str" : "176949591671980032",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn i used to be #1 but because of a bug in production I had to delete it :P",
  "id" : 176949591671980032,
  "in_reply_to_status_id" : 176894170131210241,
  "created_at" : "2012-03-06 08:37:24 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annie Murphy Paul",
      "screen_name" : "anniemurphypaul",
      "indices" : [ 3, 19 ],
      "id_str" : "105810697",
      "id" : 105810697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176776439935410177",
  "text" : "RT @anniemurphypaul: BRILLIANT: What if students had to study music for 12 years before playing an instrument? That\u2019s how we treat scien ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/t1au8qJT",
        "expanded_url" : "http:\/\/bit.ly\/wJhBtH",
        "display_url" : "bit.ly\/wJhBtH"
      } ]
    },
    "geo" : { },
    "id_str" : "176713704035987458",
    "text" : "BRILLIANT: What if students had to study music for 12 years before playing an instrument? That\u2019s how we treat science: http:\/\/t.co\/t1au8qJT",
    "id" : 176713704035987458,
    "created_at" : "2012-03-05 17:00:04 +0000",
    "user" : {
      "name" : "Annie Murphy Paul",
      "screen_name" : "anniemurphypaul",
      "protected" : false,
      "id_str" : "105810697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2120251878\/annie_murphy_paul.head_shot_normal.jpg",
      "id" : 105810697,
      "verified" : false
    }
  },
  "id" : 176776439935410177,
  "created_at" : "2012-03-05 21:09:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Horak",
      "screen_name" : "fatmike182",
      "indices" : [ 0, 11 ],
      "id_str" : "15271509",
      "id" : 15271509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176775102732566528",
  "geo" : { },
  "id_str" : "176775252506976256",
  "in_reply_to_user_id" : 15271509,
  "text" : "@fatmike182 Das weiss ich eben nicht. M\u00FCsste man mal ausprobieren. Aber die ToDo f\u00FCr Features und Bugs ist momentan schon arg lang ;)",
  "id" : 176775252506976256,
  "in_reply_to_status_id" : 176775102732566528,
  "created_at" : "2012-03-05 21:04:39 +0000",
  "in_reply_to_screen_name" : "fatmike182",
  "in_reply_to_user_id_str" : "15271509",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176774684363325440",
  "text" : "Hat jemand hier gute Tipps zu Django-Tutorials?",
  "id" : 176774684363325440,
  "created_at" : "2012-03-05 21:02:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Horak",
      "screen_name" : "fatmike182",
      "indices" : [ 0, 11 ],
      "id_str" : "15271509",
      "id" : 15271509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176766561313501184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0079581149, 8.2822955122 ]
  },
  "id_str" : "176769281881686016",
  "in_reply_to_user_id" : 15271509,
  "text" : "@fatmike182 man k\u00F6nnte sich die Flanking Regions aus dem Referenzgenom ziehen und schauen was unter Voraussetzung der Gleichheit passiert.",
  "id" : 176769281881686016,
  "in_reply_to_status_id" : 176766561313501184,
  "created_at" : "2012-03-05 20:40:55 +0000",
  "in_reply_to_screen_name" : "fatmike182",
  "in_reply_to_user_id_str" : "15271509",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Horak",
      "screen_name" : "fatmike182",
      "indices" : [ 0, 11 ],
      "id_str" : "15271509",
      "id" : 15271509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176734375197671424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095839191, 8.2828499837 ]
  },
  "id_str" : "176764290630561792",
  "in_reply_to_user_id" : 15271509,
  "text" : "@fatmike182 jo, aber ich wei\u00DF nicht wie das ohne Sequenzinformationen funktioniert.",
  "id" : 176764290630561792,
  "in_reply_to_status_id" : 176734375197671424,
  "created_at" : "2012-03-05 20:21:05 +0000",
  "in_reply_to_screen_name" : "fatmike182",
  "in_reply_to_user_id_str" : "15271509",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miss Bosy",
      "screen_name" : "Ertraeglichkeit",
      "indices" : [ 0, 16 ],
      "id_str" : "4004999973",
      "id" : 4004999973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176681938189422592",
  "geo" : { },
  "id_str" : "176682127545483266",
  "in_reply_to_user_id" : 127577609,
  "text" : "@Ertraeglichkeit Interessant. VISA hat ja letztes Jahr schon ein Patent auf pers. Werbung via DNA filed.",
  "id" : 176682127545483266,
  "in_reply_to_status_id" : 176681938189422592,
  "created_at" : "2012-03-05 14:54:36 +0000",
  "in_reply_to_screen_name" : "nattsuhon",
  "in_reply_to_user_id_str" : "127577609",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/9cEgTFKV",
      "expanded_url" : "http:\/\/j.mp\/xxvUUJ",
      "display_url" : "j.mp\/xxvUUJ"
    } ]
  },
  "geo" : { },
  "id_str" : "176677040462905344",
  "text" : "Awesome story about a insect which was thought to be extinct: http:\/\/t.co\/9cEgTFKV",
  "id" : 176677040462905344,
  "created_at" : "2012-03-05 14:34:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/ms7fcmTP",
      "expanded_url" : "http:\/\/j.mp\/xkofH0",
      "display_url" : "j.mp\/xkofH0"
    } ]
  },
  "geo" : { },
  "id_str" : "176633154642247680",
  "text" : "The Genetics of Glee or, what makes us sing in groups? http:\/\/t.co\/ms7fcmTP",
  "id" : 176633154642247680,
  "created_at" : "2012-03-05 11:40:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 3, 13 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/18VZYG7f",
      "expanded_url" : "http:\/\/bit.ly\/xkDivx",
      "display_url" : "bit.ly\/xkDivx"
    } ]
  },
  "geo" : { },
  "id_str" : "176631396624904193",
  "text" : "RT @Fischblog: Und ich denk noch, den Glatzkopf kennste doch... http:\/\/t.co\/18VZYG7f \u00DCber die miesen Bedingungen f\u00FCr Forscher in D, mit  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Markus A. Dahlem",
        "screen_name" : "markusdahlem",
        "indices" : [ 121, 134 ],
        "id_str" : "15703122",
        "id" : 15703122
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/18VZYG7f",
        "expanded_url" : "http:\/\/bit.ly\/xkDivx",
        "display_url" : "bit.ly\/xkDivx"
      } ]
    },
    "geo" : { },
    "id_str" : "176629810817286144",
    "text" : "Und ich denk noch, den Glatzkopf kennste doch... http:\/\/t.co\/18VZYG7f \u00DCber die miesen Bedingungen f\u00FCr Forscher in D, mit @markusdahlem u.a.",
    "id" : 176629810817286144,
    "created_at" : "2012-03-05 11:26:43 +0000",
    "user" : {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "protected" : false,
      "id_str" : "14700783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929627167125921792\/t5PPk1W-_normal.jpg",
      "id" : 14700783,
      "verified" : false
    }
  },
  "id" : 176631396624904193,
  "created_at" : "2012-03-05 11:33:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 3, 10 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/jgQTD6NP",
      "expanded_url" : "http:\/\/chrisacky.posterous.com\/github-you-have-let-us-all-down",
      "display_url" : "chrisacky.posterous.com\/github-you-hav\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "176453456830283776",
  "text" : "RT @lsanoj: Github und Rails. Was f\u00FCr ein Desaster. http:\/\/t.co\/jgQTD6NP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/jgQTD6NP",
        "expanded_url" : "http:\/\/chrisacky.posterous.com\/github-you-have-let-us-all-down",
        "display_url" : "chrisacky.posterous.com\/github-you-hav\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "176449445544730624",
    "text" : "Github und Rails. Was f\u00FCr ein Desaster. http:\/\/t.co\/jgQTD6NP",
    "id" : 176449445544730624,
    "created_at" : "2012-03-04 23:30:00 +0000",
    "user" : {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "protected" : false,
      "id_str" : "18918915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775302578825469952\/37E8D163_normal.jpg",
      "id" : 18918915,
      "verified" : false
    }
  },
  "id" : 176453456830283776,
  "created_at" : "2012-03-04 23:45:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 3, 11 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/vOtOqbzv",
      "expanded_url" : "http:\/\/bit.ly\/ybfmvI",
      "display_url" : "bit.ly\/ybfmvI"
    } ]
  },
  "geo" : { },
  "id_str" : "176412068285657088",
  "text" : "RT @moeffju: My little ponyxploitation: http:\/\/t.co\/vOtOqbzv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 47 ],
        "url" : "http:\/\/t.co\/vOtOqbzv",
        "expanded_url" : "http:\/\/bit.ly\/ybfmvI",
        "display_url" : "bit.ly\/ybfmvI"
      } ]
    },
    "geo" : { },
    "id_str" : "176411228925739008",
    "text" : "My little ponyxploitation: http:\/\/t.co\/vOtOqbzv",
    "id" : 176411228925739008,
    "created_at" : "2012-03-04 20:58:09 +0000",
    "user" : {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "protected" : false,
      "id_str" : "5618832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932002257356382209\/LjA5HenC_normal.jpg",
      "id" : 5618832,
      "verified" : false
    }
  },
  "id" : 176412068285657088,
  "created_at" : "2012-03-04 21:01:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/BuzLCb5R",
      "expanded_url" : "http:\/\/j.mp\/ztTnXv",
      "display_url" : "j.mp\/ztTnXv"
    } ]
  },
  "geo" : { },
  "id_str" : "176406147115397120",
  "text" : "4 reasons why all women should play Mass Effect http:\/\/t.co\/BuzLCb5R",
  "id" : 176406147115397120,
  "created_at" : "2012-03-04 20:37:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/Snh1k4aZ",
      "expanded_url" : "http:\/\/www.mercurynews.com\/crime-courts\/ci_20096845?source=most_viewed",
      "display_url" : "mercurynews.com\/crime-courts\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "176399374363009024",
  "text" : "I accidentally all the Crystal Meth http:\/\/t.co\/Snh1k4aZ",
  "id" : 176399374363009024,
  "created_at" : "2012-03-04 20:11:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens-Wolfhard",
      "screen_name" : "Drahflow",
      "indices" : [ 25, 34 ],
      "id_str" : "92904426",
      "id" : 92904426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176397290360143872",
  "text" : "Gewundert wieso ich eine @drahflow Chart im Posteingang habe. War aber noch nur \"draft flow chart\"",
  "id" : 176397290360143872,
  "created_at" : "2012-03-04 20:02:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176366234856730624",
  "text" : "4\/4 Tasks done for today!",
  "id" : 176366234856730624,
  "created_at" : "2012-03-04 17:59:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176339062792261633",
  "geo" : { },
  "id_str" : "176339328853753857",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn Yes, and it would be 10 days to the deadline :D",
  "id" : 176339328853753857,
  "in_reply_to_status_id" : 176339062792261633,
  "created_at" : "2012-03-04 16:12:26 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176335454973599746",
  "geo" : { },
  "id_str" : "176335483725549568",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall genau",
  "id" : 176335483725549568,
  "in_reply_to_status_id" : 176335454973599746,
  "created_at" : "2012-03-04 15:57:10 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176334356183384066",
  "geo" : { },
  "id_str" : "176334853875310593",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Wenn du ohne SIM hinkommst hast du einmal 100\u20AC zuviel bezahlt kannst aber jederzeit problemlos aufr\u00FCsten.",
  "id" : 176334853875310593,
  "in_reply_to_status_id" : 176334356183384066,
  "created_at" : "2012-03-04 15:54:39 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176334356183384066",
  "geo" : { },
  "id_str" : "176334750854823936",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Deshalb die 3G-Version kaufen und erstmal keine extra-SIM anschaffen und schauen ob du ohne SIM auskommst.",
  "id" : 176334750854823936,
  "in_reply_to_status_id" : 176334356183384066,
  "created_at" : "2012-03-04 15:54:15 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176334356183384066",
  "geo" : { },
  "id_str" : "176334577302913025",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Ich denk es ist einfacher sp\u00E4ter eine SIM zu kaufen als ein WiFi-Pad f\u00FCr ein 3G-Pad zu tauschen.",
  "id" : 176334577302913025,
  "in_reply_to_status_id" : 176334356183384066,
  "created_at" : "2012-03-04 15:53:34 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176331607152660480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097656294, 8.2830120063 ]
  },
  "id_str" : "176333100450709505",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall betreib die 3G-Version erstmal ohne SIM und Schau wie schnell es dich nervt. ;)",
  "id" : 176333100450709505,
  "in_reply_to_status_id" : 176331607152660480,
  "created_at" : "2012-03-04 15:47:41 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176332066152120320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097281015, 8.2831681748 ]
  },
  "id_str" : "176332400538820609",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Leg die 100\u20AC drauf. ;)",
  "id" : 176332400538820609,
  "in_reply_to_status_id" : 176332066152120320,
  "created_at" : "2012-03-04 15:44:55 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 37, 50 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176328252229562368",
  "text" : "Just submitted the ENGAGE-submission @PhilippBayer and I wrote.",
  "id" : 176328252229562368,
  "created_at" : "2012-03-04 15:28:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176322540740947968",
  "geo" : { },
  "id_str" : "176322851266240512",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Extra Volumentarif (~15\u20AC bei o2 mit 1 GB bevor Drosselung) abgeschlossen",
  "id" : 176322851266240512,
  "in_reply_to_status_id" : 176322540740947968,
  "created_at" : "2012-03-04 15:06:58 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176321950237466626",
  "geo" : { },
  "id_str" : "176322021335109632",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Der Stromverbrauch d\u00FCrfte der gravierende Nachteil sein :P",
  "id" : 176322021335109632,
  "in_reply_to_status_id" : 176321950237466626,
  "created_at" : "2012-03-04 15:03:40 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176300534012198912",
  "geo" : { },
  "id_str" : "176300694914080768",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Ich hab das 3G-Pad.",
  "id" : 176300694914080768,
  "in_reply_to_status_id" : 176300534012198912,
  "created_at" : "2012-03-04 13:38:55 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/T03MOndp",
      "expanded_url" : "http:\/\/j.mp\/xGYmlN",
      "display_url" : "j.mp\/xGYmlN"
    } ]
  },
  "geo" : { },
  "id_str" : "176265235529863168",
  "text" : "Why do married men earn more? What about only man who earn more do marry? http:\/\/t.co\/T03MOndp",
  "id" : 176265235529863168,
  "created_at" : "2012-03-04 11:18:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/ubyiTT1i",
      "expanded_url" : "http:\/\/j.mp\/wHAQov",
      "display_url" : "j.mp\/wHAQov"
    } ]
  },
  "geo" : { },
  "id_str" : "176264433134338048",
  "text" : "An Upside to Privacy Loss: Reversing the Bystander Effect http:\/\/t.co\/ubyiTT1i",
  "id" : 176264433134338048,
  "created_at" : "2012-03-04 11:14:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/hJeaJkFW",
      "expanded_url" : "http:\/\/j.mp\/zjSvjs",
      "display_url" : "j.mp\/zjSvjs"
    } ]
  },
  "geo" : { },
  "id_str" : "176263833122377728",
  "text" : "Stuff on Scouts Head http:\/\/t.co\/hJeaJkFW",
  "id" : 176263833122377728,
  "created_at" : "2012-03-04 11:12:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KT Pickard",
      "screen_name" : "kthomaspickard",
      "indices" : [ 0, 15 ],
      "id_str" : "267282720",
      "id" : 267282720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176079622239289345",
  "geo" : { },
  "id_str" : "176079788593782785",
  "in_reply_to_user_id" : 267282720,
  "text" : "@kthomaspickard Oh, you are right, this is missing from the FAQ. We started at the end of September 2011.",
  "id" : 176079788593782785,
  "in_reply_to_status_id" : 176079622239289345,
  "created_at" : "2012-03-03 23:01:07 +0000",
  "in_reply_to_screen_name" : "kthomaspickard",
  "in_reply_to_user_id_str" : "267282720",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KT Pickard",
      "screen_name" : "kthomaspickard",
      "indices" : [ 0, 15 ],
      "id_str" : "267282720",
      "id" : 267282720
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 52, 63 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176075257365536768",
  "geo" : { },
  "id_str" : "176078118094774274",
  "in_reply_to_user_id" : 267282720,
  "text" : "@kthomaspickard Thanks! Let me (or in general us at @openSNPorg) know if you encounter any problems with the website. :)",
  "id" : 176078118094774274,
  "in_reply_to_status_id" : 176075257365536768,
  "created_at" : "2012-03-03 22:54:29 +0000",
  "in_reply_to_screen_name" : "kthomaspickard",
  "in_reply_to_user_id_str" : "267282720",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176065664895823872",
  "text" : "Passende Uhrzeit zum Paper schreiben.",
  "id" : 176065664895823872,
  "created_at" : "2012-03-03 22:05:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/readnowapp.mischneider.net\" rel=\"nofollow\"\u003EReadNow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/Ih1BNx0k",
      "expanded_url" : "http:\/\/slate.me\/zMqNa1",
      "display_url" : "slate.me\/zMqNa1"
    } ]
  },
  "geo" : { },
  "id_str" : "175986266968567809",
  "text" : "Mitt Romney\u2019s Abortion Record http:\/\/t.co\/Ih1BNx0k",
  "id" : 175986266968567809,
  "created_at" : "2012-03-03 16:49:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/readnowapp.mischneider.net\" rel=\"nofollow\"\u003EReadNow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/6tSSOnGa",
      "expanded_url" : "http:\/\/bit.ly\/xO5am1",
      "display_url" : "bit.ly\/xO5am1"
    } ]
  },
  "geo" : { },
  "id_str" : "175984381880582144",
  "text" : "Interesting: Signatures of Selection in the Genomes of Commercial and Non-Commercial Chicken Breeds http:\/\/t.co\/6tSSOnGa",
  "id" : 175984381880582144,
  "created_at" : "2012-03-03 16:42:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/aeW2208b",
      "expanded_url" : "http:\/\/www.thingiverse.com\/thing:1483",
      "display_url" : "thingiverse.com\/thing:1483"
    } ]
  },
  "geo" : { },
  "id_str" : "175981117277609986",
  "text" : "Funny: Reading how DIYBiologists want to scale the Dremelfuge (http:\/\/t.co\/aeW2208b) into an ultracentrifuge.",
  "id" : 175981117277609986,
  "created_at" : "2012-03-03 16:29:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/FLeIbBf5",
      "expanded_url" : "http:\/\/j.mp\/zzHT3a",
      "display_url" : "j.mp\/zzHT3a"
    } ]
  },
  "geo" : { },
  "id_str" : "175943326787305472",
  "text" : "BitTorrent Pirates Go Nuts After TV Release Groups Dump Xvid http:\/\/t.co\/FLeIbBf5",
  "id" : 175943326787305472,
  "created_at" : "2012-03-03 13:58:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fasel",
      "screen_name" : "fasel",
      "indices" : [ 0, 6 ],
      "id_str" : "21739255",
      "id" : 21739255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175924029973209089",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096565973, 8.2832313372 ]
  },
  "id_str" : "175924391106977792",
  "in_reply_to_user_id" : 21739255,
  "text" : "@fasel oh, das hatte ich in Readability nicht mal gesehen.",
  "id" : 175924391106977792,
  "in_reply_to_status_id" : 175924029973209089,
  "created_at" : "2012-03-03 12:43:38 +0000",
  "in_reply_to_screen_name" : "fasel",
  "in_reply_to_user_id_str" : "21739255",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/KueSNoGQ",
      "expanded_url" : "http:\/\/j.mp\/xnAFS4",
      "display_url" : "j.mp\/xnAFS4"
    } ]
  },
  "geo" : { },
  "id_str" : "175923578687062017",
  "text" : "\u00ABIf you\u2019re going to do something about design, at least design your own website\u00BB http:\/\/t.co\/KueSNoGQ",
  "id" : 175923578687062017,
  "created_at" : "2012-03-03 12:40:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/CGi8UPSr",
      "expanded_url" : "http:\/\/j.mp\/y4rGdn",
      "display_url" : "j.mp\/y4rGdn"
    } ]
  },
  "geo" : { },
  "id_str" : "175920949160448000",
  "text" : "Should You Get a Vasectomy? http:\/\/t.co\/CGi8UPSr",
  "id" : 175920949160448000,
  "created_at" : "2012-03-03 12:29:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/H87VZyXO",
      "expanded_url" : "http:\/\/j.mp\/zWT91O",
      "display_url" : "j.mp\/zWT91O"
    } ]
  },
  "geo" : { },
  "id_str" : "175918898535858177",
  "text" : "TED: \u00ABWhere the very smart and the very rich pretend they have something in common for a very short time\u00BB http:\/\/t.co\/H87VZyXO",
  "id" : 175918898535858177,
  "created_at" : "2012-03-03 12:21:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/IlEdwZbP",
      "expanded_url" : "http:\/\/gedankenstuecke.github.com\/blog\/2012\/03\/03\/meta-startups-privacy-policy-generator\/",
      "display_url" : "gedankenstuecke.github.com\/blog\/2012\/03\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "175913521081630721",
  "text" : "My experience with using a privacy policy generator: http:\/\/t.co\/IlEdwZbP",
  "id" : 175913521081630721,
  "created_at" : "2012-03-03 12:00:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan D\u00F6rner \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Doener",
      "indices" : [ 3, 10 ],
      "id_str" : "14742504",
      "id" : 14742504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/3qcxHudj",
      "expanded_url" : "http:\/\/www.readersupportednews.org\/news-section2\/328-121\/10198-focus-ibm-at-auschwitz-new-documents",
      "display_url" : "readersupportednews.org\/news-section2\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "175893420659847169",
  "text" : "RT @Doener: \"IBM's Tom Watson had a deal with Hitler that earned him a personal 1% on all Nazi business profits.\"\n\nhttp:\/\/t.co\/3qcxHudj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/3qcxHudj",
        "expanded_url" : "http:\/\/www.readersupportednews.org\/news-section2\/328-121\/10198-focus-ibm-at-auschwitz-new-documents",
        "display_url" : "readersupportednews.org\/news-section2\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "175884602601254912",
    "text" : "\"IBM's Tom Watson had a deal with Hitler that earned him a personal 1% on all Nazi business profits.\"\n\nhttp:\/\/t.co\/3qcxHudj",
    "id" : 175884602601254912,
    "created_at" : "2012-03-03 10:05:31 +0000",
    "user" : {
      "name" : "Stephan D\u00F6rner \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Doener",
      "protected" : false,
      "id_str" : "14742504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747584187343978497\/58SLoGA5_normal.jpg",
      "id" : 14742504,
      "verified" : true
    }
  },
  "id" : 175893420659847169,
  "created_at" : "2012-03-03 10:40:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marie Le Conte",
      "screen_name" : "youngvulgarian",
      "indices" : [ 3, 18 ],
      "id_str" : "268809577",
      "id" : 268809577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/p4ORMYKU",
      "expanded_url" : "http:\/\/ubersuper.com\/uploads\/yapb_cache\/r9mjr.dhneskbirlkwso40wg0o8wskw.b630v2bhy3kksswk44g08wgcw.th.jpeg",
      "display_url" : "ubersuper.com\/uploads\/yapb_c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "175890252488114176",
  "text" : "RT @youngvulgarian: Officially the best Venn diagram ever. http:\/\/t.co\/p4ORMYKU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/p4ORMYKU",
        "expanded_url" : "http:\/\/ubersuper.com\/uploads\/yapb_cache\/r9mjr.dhneskbirlkwso40wg0o8wskw.b630v2bhy3kksswk44g08wgcw.th.jpeg",
        "display_url" : "ubersuper.com\/uploads\/yapb_c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "175568200698830848",
    "text" : "Officially the best Venn diagram ever. http:\/\/t.co\/p4ORMYKU",
    "id" : 175568200698830848,
    "created_at" : "2012-03-02 13:08:15 +0000",
    "user" : {
      "name" : "Marie Le Conte",
      "screen_name" : "youngvulgarian",
      "protected" : false,
      "id_str" : "268809577",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/902282855740559360\/iMlDBtD8_normal.jpg",
      "id" : 268809577,
      "verified" : false
    }
  },
  "id" : 175890252488114176,
  "created_at" : "2012-03-03 10:27:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/IBlAdDbx",
      "expanded_url" : "http:\/\/j.mp\/A0M42j",
      "display_url" : "j.mp\/A0M42j"
    } ]
  },
  "geo" : { },
  "id_str" : "175724287079104512",
  "text" : "5 Things to Know About SAMtools Mpileup http:\/\/t.co\/IBlAdDbx",
  "id" : 175724287079104512,
  "created_at" : "2012-03-02 23:28:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/IPV3RObD",
      "expanded_url" : "http:\/\/j.mp\/zj5Nxm",
      "display_url" : "j.mp\/zj5Nxm"
    } ]
  },
  "geo" : { },
  "id_str" : "175723713487044608",
  "text" : "You are naked in public! Did your brain make you do it? http:\/\/t.co\/IPV3RObD",
  "id" : 175723713487044608,
  "created_at" : "2012-03-02 23:26:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tarzun",
      "screen_name" : "tarzun",
      "indices" : [ 0, 7 ],
      "id_str" : "1632280560",
      "id" : 1632280560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/fRGE5O2Z",
      "expanded_url" : "https:\/\/twitter.com\/ABS0LEM\/status\/175659240030081026",
      "display_url" : "twitter.com\/ABS0LEM\/status\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "175666799558406144",
  "geo" : { },
  "id_str" : "175666957960478720",
  "in_reply_to_user_id" : 45513907,
  "text" : "@tarzun http:\/\/t.co\/fRGE5O2Z",
  "id" : 175666957960478720,
  "in_reply_to_status_id" : 175666799558406144,
  "created_at" : "2012-03-02 19:40:41 +0000",
  "in_reply_to_screen_name" : "klauspeukert",
  "in_reply_to_user_id_str" : "45513907",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175664322616373249",
  "text" : "Organspende was an inside job!",
  "id" : 175664322616373249,
  "created_at" : "2012-03-02 19:30:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Wei\u00DF",
      "screen_name" : "pfadintegral",
      "indices" : [ 0, 13 ],
      "id_str" : "102668707",
      "id" : 102668707
    }, {
      "name" : "GA",
      "screen_name" : "tollwutbezirk",
      "indices" : [ 14, 28 ],
      "id_str" : "98841515",
      "id" : 98841515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/Bk4pLEJt",
      "expanded_url" : "http:\/\/www.emu-verlag.de\/product_info.php\/products_id\/1441",
      "display_url" : "emu-verlag.de\/product_info.p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "175663378684067842",
  "geo" : { },
  "id_str" : "175663677092003840",
  "in_reply_to_user_id" : 102668707,
  "text" : "@pfadintegral @tollwutbezirk F\u00FCr eine Internetpartei viel wichtiger: Denkt denn niemand an die Katzen? http:\/\/t.co\/Bk4pLEJt",
  "id" : 175663677092003840,
  "in_reply_to_status_id" : 175663378684067842,
  "created_at" : "2012-03-02 19:27:38 +0000",
  "in_reply_to_screen_name" : "pfadintegral",
  "in_reply_to_user_id_str" : "102668707",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GA",
      "screen_name" : "tollwutbezirk",
      "indices" : [ 0, 14 ],
      "id_str" : "98841515",
      "id" : 98841515
    }, {
      "name" : "Simon Wei\u00DF",
      "screen_name" : "pfadintegral",
      "indices" : [ 15, 28 ],
      "id_str" : "102668707",
      "id" : 102668707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/kERggJl9",
      "expanded_url" : "http:\/\/www.emu-verlag.de\/product_info.php\/cPath\/21_25_66\/products_id\/307",
      "display_url" : "emu-verlag.de\/product_info.p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "175662394851340288",
  "geo" : { },
  "id_str" : "175663072340480000",
  "in_reply_to_user_id" : 98841515,
  "text" : "@tollwutbezirk @pfadintegral Vom Gleichen Autor auch sehr sch\u00F6n: http:\/\/t.co\/kERggJl9",
  "id" : 175663072340480000,
  "in_reply_to_status_id" : 175662394851340288,
  "created_at" : "2012-03-02 19:25:14 +0000",
  "in_reply_to_screen_name" : "tollwutbezirk",
  "in_reply_to_user_id_str" : "98841515",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175660631976972290",
  "geo" : { },
  "id_str" : "175661526244528128",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher Oh, Vernunft, nicht Verstand. Aber das \u00E4ndert ja nix :D",
  "id" : 175661526244528128,
  "in_reply_to_status_id" : 175660631976972290,
  "created_at" : "2012-03-02 19:19:06 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175660631976972290",
  "geo" : { },
  "id_str" : "175661445445468161",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher Du hast doch angefangen! Bei den Piraten von Verstand zu sprechen... ;)",
  "id" : 175661445445468161,
  "in_reply_to_status_id" : 175660631976972290,
  "created_at" : "2012-03-02 19:18:46 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175660053506961408",
  "geo" : { },
  "id_str" : "175660375377842176",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher Tja, die Schnittmenge ist halt zu klein :P",
  "id" : 175660375377842176,
  "in_reply_to_status_id" : 175660053506961408,
  "created_at" : "2012-03-02 19:14:31 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175641309514702849",
  "geo" : { },
  "id_str" : "175641519829684224",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Oh, wohin hat es dich denn verschlagen?",
  "id" : 175641519829684224,
  "in_reply_to_status_id" : 175641309514702849,
  "created_at" : "2012-03-02 17:59:36 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175638008647786496",
  "geo" : { },
  "id_str" : "175638158791286784",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce If you need any help for the technical side of the videos let me know. I just struggled with this for the openSNP-videos myself.",
  "id" : 175638158791286784,
  "in_reply_to_status_id" : 175638008647786496,
  "created_at" : "2012-03-02 17:46:14 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175636771940483073",
  "geo" : { },
  "id_str" : "175637369200971777",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce Gratulations and good luck for the further application! :)",
  "id" : 175637369200971777,
  "in_reply_to_status_id" : 175636771940483073,
  "created_at" : "2012-03-02 17:43:06 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenHelix Staff",
      "screen_name" : "OpenHelix",
      "indices" : [ 3, 13 ],
      "id_str" : "41592143",
      "id" : 41592143
    }, {
      "name" : "Kristi Holmes",
      "screen_name" : "kristiholmes",
      "indices" : [ 23, 36 ],
      "id_str" : "18999920",
      "id" : 18999920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175620065486573569",
  "text" : "RT @OpenHelix: Nice MT @kristiholmes: GPS@WUSTL will award 99 clinical-grade exome sequences to rare disease advocacy groups http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kristi Holmes",
        "screen_name" : "kristiholmes",
        "indices" : [ 8, 21 ],
        "id_str" : "18999920",
        "id" : 18999920
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/jSGMJnkD",
        "expanded_url" : "http:\/\/bit.ly\/yop7m0",
        "display_url" : "bit.ly\/yop7m0"
      } ]
    },
    "geo" : { },
    "id_str" : "175608474808492034",
    "text" : "Nice MT @kristiholmes: GPS@WUSTL will award 99 clinical-grade exome sequences to rare disease advocacy groups http:\/\/t.co\/jSGMJnkD",
    "id" : 175608474808492034,
    "created_at" : "2012-03-02 15:48:17 +0000",
    "user" : {
      "name" : "OpenHelix Staff",
      "screen_name" : "OpenHelix",
      "protected" : false,
      "id_str" : "41592143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/222377965\/OH_puzzle_normal.jpg",
      "id" : 41592143,
      "verified" : false
    }
  },
  "id" : 175620065486573569,
  "created_at" : "2012-03-02 16:34:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175586238592581632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0045938166, 8.2898139417 ]
  },
  "id_str" : "175601662621261825",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ naja, k\u00F6nnten halt.",
  "id" : 175601662621261825,
  "in_reply_to_status_id" : 175586238592581632,
  "created_at" : "2012-03-02 15:21:13 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/c16pZZCM",
      "expanded_url" : "http:\/\/instagr.am\/p\/HrIuQUBwge\/",
      "display_url" : "instagr.am\/p\/HrIuQUBwge\/"
    } ]
  },
  "geo" : { },
  "id_str" : "175593936411299840",
  "text" : "BAM!!! http:\/\/t.co\/c16pZZCM",
  "id" : 175593936411299840,
  "created_at" : "2012-03-02 14:50:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/53wLHEBC",
      "expanded_url" : "http:\/\/j.mp\/w2aykY",
      "display_url" : "j.mp\/w2aykY"
    } ]
  },
  "geo" : { },
  "id_str" : "175563559848259585",
  "text" : "Smoking Dose Modifies the Association between SNP and Prevalence of Metabolic Syndrome http:\/\/t.co\/53wLHEBC",
  "id" : 175563559848259585,
  "created_at" : "2012-03-02 12:49:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/TSDh4J1K",
      "expanded_url" : "http:\/\/j.mp\/wr5k1L",
      "display_url" : "j.mp\/wr5k1L"
    } ]
  },
  "geo" : { },
  "id_str" : "175532671559147521",
  "text" : "deutsche datenschutz paradox-paradoxien http:\/\/t.co\/TSDh4J1K",
  "id" : 175532671559147521,
  "created_at" : "2012-03-02 10:47:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 101 ],
      "url" : "https:\/\/t.co\/Jw9zEEnz",
      "expanded_url" : "https:\/\/www.iubenda.com\/en",
      "display_url" : "iubenda.com\/en"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9434504449, 7.2667752944 ]
  },
  "id_str" : "175347259708420098",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks this might be of interest for you: A privacy policy generator-startup https:\/\/t.co\/Jw9zEEnz",
  "id" : 175347259708420098,
  "created_at" : "2012-03-01 22:30:19 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.instapaper.com\/\" rel=\"nofollow\"\u003EInstapaper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/JynGWxxs",
      "expanded_url" : "http:\/\/j.mp\/x31LkP",
      "display_url" : "j.mp\/x31LkP"
    } ]
  },
  "geo" : { },
  "id_str" : "175345193694932992",
  "text" : "How Google\u2014and 104 Other Companies\u2014Are Tracking Me on the Web http:\/\/t.co\/JynGWxxs",
  "id" : 175345193694932992,
  "created_at" : "2012-03-01 22:22:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Arndt Gro\u00DFmann",
      "screen_name" : "g1zu",
      "indices" : [ 6, 11 ],
      "id_str" : "484276999",
      "id" : 484276999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175341912285396993",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9432989397, 7.26697615 ]
  },
  "id_str" : "175342312623316996",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a @g1zu das ist auf jeden Fall etwas woran ich teilnehmen w\u00FCrde. :)",
  "id" : 175342312623316996,
  "in_reply_to_status_id" : 175341912285396993,
  "created_at" : "2012-03-01 22:10:39 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/mBV7tVav",
      "expanded_url" : "http:\/\/instagr.am\/p\/HpWLQEhwgs\/",
      "display_url" : "instagr.am\/p\/HpWLQEhwgs\/"
    } ]
  },
  "geo" : { },
  "id_str" : "175342085283647488",
  "text" : "Und der Tag endet wie er angefangen hat.  http:\/\/t.co\/mBV7tVav",
  "id" : 175342085283647488,
  "created_at" : "2012-03-01 22:09:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "indices" : [ 3, 18 ],
      "id_str" : "19416598",
      "id" : 19416598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/l3c4s6mi",
      "expanded_url" : "http:\/\/bit.ly\/AzsfcH",
      "display_url" : "bit.ly\/AzsfcH"
    } ]
  },
  "geo" : { },
  "id_str" : "175243259453513730",
  "text" : "RT @leonidkruglyak: \"How could one common gene variant possibly predict so many diverse behaviors?\" http:\/\/t.co\/l3c4s6mi via @dgmacarthu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel MacArthur",
        "screen_name" : "dgmacarthur",
        "indices" : [ 105, 117 ],
        "id_str" : "16629477",
        "id" : 16629477
      }, {
        "name" : "Joe Pickrell",
        "screen_name" : "joe_pickrell",
        "indices" : [ 118, 131 ],
        "id_str" : "314758565",
        "id" : 314758565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/l3c4s6mi",
        "expanded_url" : "http:\/\/bit.ly\/AzsfcH",
        "display_url" : "bit.ly\/AzsfcH"
      } ]
    },
    "geo" : { },
    "id_str" : "175241076821594113",
    "text" : "\"How could one common gene variant possibly predict so many diverse behaviors?\" http:\/\/t.co\/l3c4s6mi via @dgmacarthur @joe_pickrell",
    "id" : 175241076821594113,
    "created_at" : "2012-03-01 15:28:23 +0000",
    "user" : {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "protected" : false,
      "id_str" : "19416598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1095542276\/MyRecentPhoto_normal.jpg",
      "id" : 19416598,
      "verified" : false
    }
  },
  "id" : 175243259453513730,
  "created_at" : "2012-03-01 15:37:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/FrSHj3A9",
      "expanded_url" : "http:\/\/bit.ly\/vZOvZQ",
      "display_url" : "bit.ly\/vZOvZQ"
    } ]
  },
  "geo" : { },
  "id_str" : "175238253857865729",
  "text" : "Blasphemy: Nintendo rejects indie game on religious grounds http:\/\/t.co\/FrSHj3A9",
  "id" : 175238253857865729,
  "created_at" : "2012-03-01 15:17:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/bYYpWJtG",
      "expanded_url" : "http:\/\/bit.ly\/wvW3wd",
      "display_url" : "bit.ly\/wvW3wd"
    } ]
  },
  "geo" : { },
  "id_str" : "175233069358399489",
  "text" : "Scientists exempted from tougher UK immigration rules http:\/\/t.co\/bYYpWJtG",
  "id" : 175233069358399489,
  "created_at" : "2012-03-01 14:56:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/ENUyUmkF",
      "expanded_url" : "http:\/\/www.newscientist.com\/blogs\/culturelab\/2012\/02\/its-the-hair-famous-red-heads-team-up-for-orangutans.html",
      "display_url" : "newscientist.com\/blogs\/culturel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "175230514175803392",
  "text" : "Save all the sexy redheads! http:\/\/t.co\/ENUyUmkF",
  "id" : 175230514175803392,
  "created_at" : "2012-03-01 14:46:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/vSMcJ8Ta",
      "expanded_url" : "http:\/\/j.mp\/yOEcJ5",
      "display_url" : "j.mp\/yOEcJ5"
    } ]
  },
  "geo" : { },
  "id_str" : "175110921746776064",
  "text" : "Icebound, long-abandoned Communist flying saucer in the cliffs of Bulgaria http:\/\/t.co\/vSMcJ8Ta",
  "id" : 175110921746776064,
  "created_at" : "2012-03-01 06:51:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "datalove",
      "indices" : [ 15, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/dF334gf5",
      "expanded_url" : "http:\/\/instagr.am\/p\/Hm7CMGBwpF\/",
      "display_url" : "instagr.am\/p\/Hm7CMGBwpF\/"
    } ]
  },
  "geo" : { },
  "id_str" : "175000947628580865",
  "text" : "Feels familiar #datalove http:\/\/t.co\/dF334gf5",
  "id" : 175000947628580865,
  "created_at" : "2012-02-29 23:34:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scytale",
      "screen_name" : "Scytale",
      "indices" : [ 0, 8 ],
      "id_str" : "621716753",
      "id" : 621716753
    }, {
      "name" : "antiprodukt",
      "screen_name" : "antiprodukt",
      "indices" : [ 9, 21 ],
      "id_str" : "149089037",
      "id" : 149089037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174999709700734976",
  "geo" : { },
  "id_str" : "174999844430163968",
  "in_reply_to_user_id" : 8308632,
  "text" : "@Scytale @antiprodukt Steht das nicht eh schon im Pad?",
  "id" : 174999844430163968,
  "in_reply_to_status_id" : 174999709700734976,
  "created_at" : "2012-02-29 23:29:48 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]